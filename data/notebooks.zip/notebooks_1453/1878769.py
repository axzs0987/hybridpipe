import pandas as pd
# In[None]

# DA Assignment 6
#Authors:
# Suraj K A- 01FB16ECS406
# Simran Bhatia - 01FB16ECS383

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
#print(os.listdir("../input"))


# In[None]

import seaborn as sns
import matplotlib.pyplot as plt


# In[None]

#importing data
data_file = "../input/Absenteeism_at_work.csv"
df= pd.read_csv(data_file)
df.head()

# In[None]

df.describe()

# In[None]

#Preprocessing data - stage 1 (Removing outliers in label)
sns.boxplot(df['Absenteeism time in hours'])
median = np.median(df['Absenteeism time in hours'])
q75, q25 = np.percentile(df['Absenteeism time in hours'], [75 ,25])
iqr = q75 - q25
print("Lower outlier bound:",q25 - (1.5*iqr))
print("Upper outlier bound:",q75 + (1.5*iqr))
#dropping the following outliers above 17
df= df[df['Absenteeism time in hours']<=17]
df= df[df['Absenteeism time in hours']>=-7]

# In[None]

#Splitting data into training and testing
from sklearn.model_selection import train_test_split
y=df['Absenteeism time in hours']
X=df.drop('Absenteeism time in hours',axis=1)#Extracting only the features
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1878769.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
import cufflinks as cf
cf.go_offline()

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

train = pd.read_csv('../input/titanic_train.csv')
train.head()

# In[None]

#There is going to be some missing data in the dataset. So lets check that
train.isnull()

# In[None]

sns.heatmap(train.isnull(),yticklabels=False, cbar=False, cmap='viridis')

# W# e#  # n# o# t# i# c# e#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # a#  # l# o# t#  # o# f#  # c# a# b# i# n#  # i# n# f# o# r# m# a# t# i# o# n#  # m# i# s# s# i# n# g#  # a# n# d#  # t# h# e# r# e#  # i# s#  # s# o# m# e#  # i# n# f# o# r# m# a# t# i# o# n#  # m# i# s# s# i# n# g#  # i# n#  # t# h# e#  # A# g# e#  # c# o# l# u# m# n

# In[None]

sns.set_style('whitegrid')

# In[None]

sns.countplot(x='Survived', data=train)

# T# h# e# r# e#  # a# r# e#  # m# o# r# e#  # c# o# u# n# t#  # o# n#  # t# h# e#  # 0#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# e# y#  # d# i# d#  # n# o# t#  # s# u# r# v# i# v# e# d# .#  # W# e#  # c# a# n#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # b# a# s# e# d#  # o# n#  # s# e# x# .

# In[None]

sns.countplot(x='Survived', hue='Sex', data=train, palette='RdBu_r')

# F# r# o# m#  # t# h# e#  # d# a# t# a#  # i# t#  # l# o# o# k# s#  # l# i# k# e#  # t# h# e# r# e#  # a# r# e#  # m# o# r# e#  # f# e# m# a# l# e#  # s# u# r# v# i# v# o# r# s#  # t# h# a# n#  # m# a# l# e# .#  # T# h# e#  # u# n# s# u# r# v# i# v# e# d#  # c# o# u# n# t#  # f# o# r#  # m# a# l# e#  # i# s#  # *# *# v# e# r# y#  # h# i# g# h# *# *#  # c# o# m# p# a# r# e# d#  # t# o#  # f# e# m# a# l# e# s# .

# In[None]

sns.countplot(x='Survived', hue='Pclass', data=train)

# W# h# e# n#  # t# h# e#  # g# r# a# p# h#  # i# s#  # d# i# s# t# r# i# b# u# t# e# d#  # b# y#  # p# a# s# s# e# n# g# e# r#  # c# l# a# s# s# .#  # T# h# i# s#  # l# o# o# k# s#  # l# i# k# e# s#  # t# h# e#  # p# e# o# p# l# e#  # w# h# o#  # d# i# d#  # n# o# t#  # s# u# r# v# i# v# e#  # a# r# e#  # w# a# y#  # m# o# r# e#  # h# i# g# h# e# r#  # o# n#  # t# h# e#  # c# l# a# s# s#  # 3# .#  # T# h# e#  # h# i# g# h# e# r#  # c# l# a# s# s#  # p# a# s# s# e# n# g# e# r# s#  # s# e# e# m# s#  # t# o#  # h# a# v# e#  # l# e# s# s# e# r#  # d# e# a# t# h#  # r# a# t# e# .#  # T# h# e#  # o# t# h# e# r#  # r# e# a# s# o# n#  # a# l# s# o#  # c# o# u# l# d#  # b# e#  # w# e#  # h# a# v# e#  # f# a# i# r# l# y#  # l# o# w# e# r#  # t# o# t# a# l#  # c# o# u# n# t#  # o# f#  # C# l# a# s# s#  # 1#  # a# n# d#  # 2#  # p# a# s# s# e# n# g# e# r# s

# In[None]

sns.distplot(train['Age'].dropna(), kde=False, bins=30)

# I# t#  # l# o# o# k# s#  # l# i# k# e#  # t# h# e# r# e#  # w# e# r# e#  # a#  # l# o# t#  # o# f#  # y# o# u# n# g#  # p# a# s# s# e# n# g# e# r# s#  # o# n#  # t# h# e#  # t# i# t# a# n# i# c# .#  

# In[None]

train['Age'].plot.hist(bins=20)
#doing the same thing using pandas native plotting. 

# In[None]

train.info()

# In[None]

sns.countplot(x='SibSp', data=train)

# F# r# o# m#  # t# h# e#  # c# h# a# r# t#  # i# t#  # l# o# o# k# s#  # l# i# k# e#  # m# o# s# t#  # o# f#  # t# h# e#  # p# e# o# p# l# e#  # w# h# e# r# e#  # s# i# n# g# l# e# s#  # a# n# d#  # w# i# t# h# o# u# t#  # c# h# i# l# d# r# e# n# .#  # I# t#  # c# o# u# l# d#  # b# e#  # p# o# s# s# i# b# l# e#  # t# h# a# t#  # t# h# e# y#  # d# i# d#  # n# o# t#  # h# a# v# e#  # a#  # s# p# o# u# s# e#  # o# n# b# o# a# r# d#  # a# s#  # w# e# l# l# .#  #  # T# h# e#  # s# e# c# o# n# d#  # h# i# g# h# e# s# t#  # o# p# t# i# o# n#  # i# s#  # 1#  # w# h# i# c# h#  # m# e# a# n# s#  # c# a# s# e# s#  # w# h# e# r# e#  # t# h# e# y#  # h# a# v# e#  # a#  # s# p# o# u# s# e#  # b# u# t#  # n# o#  # c# h# i# l# d# r# e# n#  # o# n#  # b# o# a# r# d# .#  

# In[None]

train['Fare'].hist(bins=40, figsize=(10,4))

# I# t#  # l# o# o# k# s#  # l# i# k# e#  # m# o# s# t#  # o# f#  # t# h# e#  # p# a# s# s# e# n# g# e# r# s#  # w# e# r# e#  # i# n#  # t# h# e#  # c# h# e# a# p# e# r#  # C# l# a# s# s#  # 3# .#  # T# h# i# s#  # c# o# u# l# d#  # b# e#  # o# n# e#  # o# f#  # t# h# e#  # r# e# a# s# o# n# s#  # w# h# e# r# e#  # w# e#  # s# a# w#  # m# o# r# e#  # n# o# n# -# s# u# r# v# i# v# o# r# s#  # i# n#  # t# h# e#  # b# a# r# c# h# a# r# t# s#  # d# i# s# p# l# a# y# e# d#  # e# a# r# l# i# e# r# .#  

# In[None]

plt.figure(figsize=(10,7))
sns.boxplot(x='Pclass',y='Age', data=train)

# In[None]

def impute_age(cols):
    Age = cols[0]
    Pclass = cols[1]
    
    if pd.isnull(Age):
        
        if Pclass == 1:
            return 37
        elif Pclass == 2:
            return 29
        else:
            return 24
    else:
        return Age
    
#This function helps in getting the suitable possible age for the missing values in the Age column. 

# In[None]

train['Age'] = train[['Age', 'Pclass']].apply(impute_age, axis=1)

# In[None]

sns.heatmap(train.isnull(), yticklabels=False, cbar=False, cmap='viridis')

# In[None]

train.drop('Cabin', axis=1, inplace=True)
#Since there are loads of information missing in the cabin column, it is better we drop it completely

# In[None]

train.head()

# In[None]

plt.figure(figsize=(10,7))
sns.heatmap(train.isnull(), yticklabels=False, cbar=False, cmap='viridis')

# N# o# w#  # t# h# a# t#  # w# e#  # h# a# v# e#  # c# o# m# p# l# e# t# e# l# y#  # r# e# m# o# v# e# d#  # C# a# b# i# n#  # c# o# l# u# m# n# .#  # W# e#  # c# a# n#  # s# e# e#  # i# f#  # t# h# e# r# e#  # i# s#  # a# n# y# t# h# i# n# g#  # e# l# s# e#  # t# h# a# t#  # h# a# s#  # m# i# s# s# i# n# g#  # i# n# f# o# r# m# a# t# i# o# n# .#  # W# e#  # n# o# t# i# c# e#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # c# h# a# r# t#  # t# h# a# t#  # t# h# e#  # e# m# b# a# r# k# e# d#  # c# o# l# u# m# n#  # h# a# s#  # l# i# t# t# l# e#  # m# i# s# s# i# n# g#  # i# n# f# o# r# m# a# t# i# o# n# .#  # W# e#  # w# i# l# l#  # r# u# n#  # t# r# a# i# n# .# d# r# o# p# n# a#  # o# n# c# e#  # t# o#  # e# n# s# u# r# e#  # a# l# l#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # a# r# e#  # f# u# l# l# y#  # r# e# m# o# v# e# d#  # f# r# o# m#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

train.dropna(inplace=True)

# In[None]

plt.figure(figsize=(10,7))
sns.heatmap(train.isnull(), yticklabels=False, cbar=False, cmap='viridis')

# N# o# w#  # w# h# e# n#  # w# e#  # r# u# n#  # t# h# e#  # h# e# a# t# m# a# p#  # a# g# a# i# n#  # w# e#  # n# o# t# i# c# e#  # t# h# e# r# e#  # i# s#  # n# o#  # m# i# s# s# i# n# g#  # d# a# t# a#  # a# t#  # a# l# l# .#  

# In[None]

sex = pd.get_dummies(train['Sex'], drop_first=True)

# In[None]

embark = pd.get_dummies(train['Embarked'], drop_first=True)

# In[None]

train = pd.concat([train,sex,embark], axis=1)

# In[None]

train.head()

# N# o# w#  # t# h# a# t#  # w# e#  # h# a# v# e#  # c# r# e# a# t# e# d#  # n# e# w#  # c# o# l# u# m# n# s#  # t# h# a# t#  # t# h# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l#  # c# a# n#  # u# n# d# e# r# s# t# a# n# d# ,#  # w# e#  # c# a# n#  # d# r# o# p#  # t# h# e#  # c# o# l# u# m# n# s#  # t# h# a# t#  # h# a# v# e#  # b# e# e# n#  # c# o# n# v# e# r# t# e# d#  # t# o#  # d# u# m# m# y#  # c# o# l# u# m# n# s# .#  # T# h# i# s#  # o# p# t# i# m# i# z# e# s#  # t# h# a# t#  # t# h# e#  # d# a# t# a# s# e# t#  # t# o#  # b# e#  # a# d# d# r# e# s# s# e# d#  # b# y#  # t# h# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m

# In[None]

train.drop(['Sex', 'Embarked', 'Name', 'Ticket'], axis=1, inplace=True)

# In[None]

train.head()

# W# e#  # c# a# n#  # d# r# o# p#  # t# h# e#  # p# a# s# s# e# n# g# e# r#  # I# D#  # a# s#  # w# e# l# l#  # a# s#  # i# t#  # w# o# u# l# d# n# t#  # g# i# v# e#  # a# n# y#  # i# n# s# i# g# h# t# .

# In[None]

train.drop('PassengerId', axis=1, inplace=True)

# In[None]

train.head()

# In[None]

X = train.drop('Survived', axis=1)
y = train['Survived']

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1382730.npy", { "accuracy_score": score })

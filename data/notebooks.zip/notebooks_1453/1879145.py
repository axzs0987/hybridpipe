import pandas as pd
# In[None]



import numpy as np 
import pandas as pd 
import warnings
warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)

import seaborn as sns
import matplotlib.pyplot as plt



# In[None]



data = pd.read_csv('../input/bird.csv')



# In[None]



data.head(3)



# In[None]

data['type'].unique()

# In[None]



data.describe()



# In[None]



data.isnull().any()



# In[None]

data = data.dropna()

# In[None]

data.describe()

# In[None]

data.isnull().any()



# In[None]

data['type'].unique()

# In[None]



#we can assign the  SW,W,T,R,P,SO as 0,1,2,3,4,5 respectively for the types .



# In[None]

data.type[data.type == 'SW'] = 0
data.type[data.type == 'W'] = 1
data.type[data.type == 'T'] = 2
data.type[data.type == 'R'] = 3
data.type[data.type == 'P'] = 4
data.type[data.type == 'SO'] = 5


# In[None]



data['type'].unique()



# In[None]



data = data.drop('id',axis=1)



# In[None]



data.head(3)



# In[None]

y = data['type']

# In[None]



x = data.drop('type',axis=1)



# In[None]

plt.figure(figsize=(2,1))
sns.pairplot(x,height = 2.5)
plt.show()

# In[None]

plt.figure(figsize=(40,20))
cm = np.corrcoef(x.values.T)
sns.set(font_scale = 1.5)
hm = sns.heatmap(cm,cbar = True , annot=True,square=True,fmt='.1f',annot_kws={'size':15})
plt.show()

# In[None]


x

# In[None]



y = y.astype('int')



# In[None]



y.head(10)



# In[None]

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
x = scaler.fit_transform(x)


# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1879145.npy", { "accuracy_score": score })

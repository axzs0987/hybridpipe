import pandas as pd
# In[None]

'''
Importing libs and the dataset and setting X and y 
'''
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

dataset = pd.read_csv('../input/indian-liver-patient-records/indian_liver_patient.csv')
dataset = dataset.fillna(dataset.mean())
X = dataset.iloc[:, [0,1,2,3,4,5,6,7,8,9]].values
y = dataset.iloc[:, 10].values

# In[None]

##Encoding Male,Female into 0 and 1 and adding the training and testing sets 
from sklearn.preprocessing import LabelEncoder
labelencoder = LabelEncoder()
X[:, 1] = labelencoder.fit_transform(X[:, 1])

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7639936.npy", { "accuracy_score": score })

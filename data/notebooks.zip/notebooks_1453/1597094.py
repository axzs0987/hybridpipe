import pandas as pd
# ## ##  # *# *# C# h# u# r# n#  # P# r# e# d# i# c# t# i# o# n#  # o# f#  # T# e# l# c# o#  # C# u# s# t# o# m# e# r# s#  # u# s# i# n# g#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # A# l# g# o# r# i# t# h# m# s# *# *# 
# 
# I# n#  # t# h# i# s#  # k# e# r# n# e# l# ,#  # I#  # w# a# n# t#  # t# o#  # a# p# p# l# y#  # s# o# m# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# l# g# o# r# i# t# h# m#  # o# n#  # T# e# l# c# o#  # c# u# s# t# o# m# e# r# s#  # c# h# u# r# n#  # d# a# t# a#  # s# e# t# .

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv("../input/WA_Fn-UseC_-Telco-Customer-Churn.csv")
data.head()

# In[None]

data.info()

# T# o# t# a# l# C# h# a# r# g# e# s#  # c# o# l# u# m# n#  # i# s#  # s# e# e# n#  # a# s#  # o# b# j# e# c# t#  # t# y# p# e# ,#  # b# u# t#  # i# n# c# l# u# d# e# s#  # n# u# m# e# r# i# c#  # t# y# p# e#  # v# a# l# u# e# s# .#  # C# o# n# v# e# r# t#  # t# h# i# s#  # c# o# l# u# m# n#  # t# o#  # n# u# m# e# r# i# c# .#  

# In[None]

data.TotalCharges = pd.to_numeric(data.TotalCharges, errors='coerce')
data.info()

# T# h# e# r# e#  # a# r# e#  # 1# 1#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # T# o# t# a# l# C# h# a# r# g# e# s#  # c# o# l# u# m# n# .#  # W# e#  # c# a# n#  # f# i# l# l#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  # m# e# d# i# a# n#  # d# a# t# a# ,#  # s# e# t#  # i# t#  # t# o#  # 0#  # o# r#  # d# e# l# e# t# e#  # t# h# e# s# e#  # r# o# w# s# ,#  # i# t#  # i# s#  # u# p#  # t# o#  # y# o# u# .#  # I#  # p# r# e# f# e# r#  # d# e# l# e# t# i# n# g#  # t# h# e# s# e#  # c# o# l# u# m# n# s#  # b# e# c# a# u# s# e#  # i# t#  # i# s#  # a#  # s# m# a# l# l#  # p# a# r# t#  # c# o# m# p# a# r# e# d#  # t# o#  # a# l# l#  # d# a# t# a# .

# In[None]

#delete rows including null values
data.dropna(inplace = True)

# W# e#  # d# o# n# '# t#  # n# e# e# d#  # c# u# s# t# o# m# e# r# I# D#  # c# o# l# u# m# n#  # f# o# r#  # a# n# a# l# y# z# i# n# g# ,#  # s# o#  # w# e#  # c# a# n#  # d# r# o# p#  # t# h# i# s#  # c# o# l# u# m# n# .#  

# In[None]

data.drop(["customerID"],axis=1,inplace = True)

# R# e# p# l# a# c# e#  # t# e# x# t#  # c# o# l# u# m# n# s#  # t# o#  # i# n# t# e# g# e# r# s# .#  # T# h# e#  # c# o# l# u# m# n# s#  # b# e# l# o# w#  # i# n# c# l# u# d# e# s#  # s# i# m# i# l# a# r#  # t# e# x# t#  # v# a# l# u# e# s#  # s# o#  # I#  # c# h# a# n# g# e# d#  # t# h# e# m#  # o# n# c# e# .

# In[None]

data.gender = [1 if each == "Male" else 0 for each in data.gender]

columns_to_convert = ['Partner', 
                      'Dependents', 
                      'PhoneService', 
                      'MultipleLines',
                      'OnlineSecurity',
                      'OnlineBackup',
                      'DeviceProtection',
                      'TechSupport',
                      'StreamingTV',
                      'StreamingMovies',
                      'PaperlessBilling', 
                      'Churn']

for item in columns_to_convert:
    data[item] = [1 if each == "Yes" else 0 if each == "No" else -1 for each in data[item]]
    
data.head()

# L# e# t# '# s#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # C# h# u# r# n#  # v# a# l# u# e# s# .#  # A# s#  # y# o# u#  # c# a# n#  # s# e# e#  # b# e# l# o# w# ,#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# s#  # i# m# b# a# l# a# n# c# e# d# .#  # B# u# t#  # f# o# r#  # n# o# w# ,#  # I#  # w# i# l# l#  # i# g# n# o# r# e#  # t# h# i# s# .

# In[None]

sns.countplot(x="Churn",data=data);

# In[None]

sns.pairplot(data,vars = ['tenure','MonthlyCharges','TotalCharges'], hue="Churn")

# P# e# o# p# l# e#  # h# a# v# i# n# g#  # l# o# w# e# r#  # t# e# n# u# r# e#  # a# n# d#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # a# r# e#  # t# e# n# d#  # t# o#  # c# h# u# r# n#  # m# o# r# e# .# 
# A# l# s# o#  # a# s#  # y# o# u#  # c# a# n#  # s# e# e#  # b# e# l# o# w# ;#  # h# a# v# i# n# g#  # m# o# n# t# h# -# t# o# -# m# o# n# t# h#  # c# o# n# t# r# a# c# t#  # a# n# d#  # f# i# b# e# r#  # o# b# t# i# c#  # i# n# t# e# r# n# e# t#  # h# a# v# e#  # a#  # r# e# a# l# l# y#  # h# u# g# e#  # e# f# f# e# c# t#  # o# n#  # c# h# u# r# n#  # p# r# o# b# a# b# i# l# i# t# y# .

# In[None]

sns.set(style="whitegrid")
g1=sns.catplot(x="Contract", y="Churn", data=data,kind="bar")
g1.set_ylabels("Churn Probability")

g2=sns.catplot(x="InternetService", y="Churn", data=data,kind="bar")
g2.set_ylabels("Churn Probability")

# C# o# n# v# e# r# t#  # r# e# m# a# i# n# i# n# g#  # t# e# x# t#  # b# a# s# e# d#  # c# o# l# u# m# n# s#  # t# o#  # d# u# m# m# y#  # c# o# l# u# m# n# s#  # u# s# i# n# g#  # p# a# n# d# a# s#  # g# e# t# _# d# u# m# m# i# e# s#  # f# u# n# c# t# i# o# n# .#  # T# h# i# s#  # f# u# n# c# t# i# o# n#  # c# r# e# a# t# e# s#  # n# e# w#  # c# o# l# u# m# n# s#  # n# a# m# e# d#  # a# s#  # v# a# l# u# e# s#  # o# f#  # t# h# e#  # r# e# l# a# t# e# d#  # c# o# l# u# m# n# s# .# 
# 
# N# o# w#  # o# u# r#  # d# a# t# a#  # s# e# t#  # o# n# l# y#  # h# a# v# e#  # i# n# t# e# g# e# r#  # a# n# d#  # n# u# m# e# r# i# c# a# l#  # c# o# l# u# m# n# s#  # s# o#  # t# h# a# t#  # w# e#  # c# a# n#  # a# p# p# l# y#  # s# t# a# t# i# s# t# i# c# a# l#  # m# o# d# e# l# s# .

# In[None]

data = pd.get_dummies(data=data)
data.head()

# L# e# t# '# s#  # s# e# e#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # c# h# u# r# n#  # a# n# d#  # t# h# e#  # r# e# m# a# i# n# i# n# g#  # c# o# l# u# m# n# s# .#  # C# u# s# t# o# m# e# r# s#  # h# a# v# i# n# g#  # m# o# n# t# h# -# t# o# -# m# o# n# t# h#  # c# o# n# t# r# a# c# t# ,#  # h# a# v# i# n# g#  # f# i# b# e# r#  # o# p# t# i# c#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # a# n# d#  # u# s# i# n# g#  # e# l# e# c# t# r# o# n# i# c#  # p# a# y# m# e# n# t#  # a# r# e#  # t# e# n# d#  # t# o#  # c# h# u# r# n#  # m# o# r# e#  # w# h# e# r# e# a# s#  # p# e# o# p# l# e#  # h# a# v# i# n# g#  # t# w# o# -# y# e# a# r#  # c# o# n# t# r# a# c# t#  # a# n# d#  # h# a# v# i# n# g#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # a# r# e#  # t# e# n# d#  # t# o#  # n# o# t#  # c# h# u# r# n# .

# In[None]

data.corr()['Churn'].sort_values()

# *# *# P# r# e# p# a# r# e#  # x#  # a# n# d#  # y# *# *# 
# 
# F# i# r# s# t# ,#  # s# e# p# e# r# a# t# e#  # x#  # a# n# d#  # y#  # v# a# l# u# e# s# .#  # y#  # w# o# u# l# d#  # b# e#  # o# u# r#  # c# l# a# s# s#  # w# h# i# c# h#  # i# s#  # C# h# u# r# n#  # c# o# l# u# m# n#  # i# n#  # t# h# i# s#  # d# a# t# a# s# e# t# .#  # x#  # w# o# u# l# d#  # b# e#  # t# h# e#  # r# e# m# a# i# n# g#  # c# o# l# u# m# n# s# .# 
# A# l# s# o# ,#  # a# p# p# l# y#  # n# o# r# m# a# l# i# z# a# t# i# o# n#  # t# o#  # x#  # i# n#  # o# r# d# e# r#  # t# o#  # s# c# a# l# e#  # a# l# l#  # v# a# l# u# e# s#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .

# In[None]

#assign Class_att column as y attribute
y = data.Churn.values

#drop Class_att column, remain only numerical columns
new_data = data.drop(["Churn"],axis=1)

#Normalize values to fit between 0 and 1. 
x = (new_data-np.min(new_data))/(np.max(new_data)-np.min(new_data)).values

# *# *# S# p# l# i# t# t# i# n# g#  # D# a# t# a# *# *# 
# 
# S# p# l# i# t#  # t# h# e#  # d# a# t# a#  # s# e# t#  # a# s#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # w# i# t# h#  # %# 2# 0# -# %# 8# 0#  # r# a# t# i# o# .

# In[None]

#Split data into Train and Test 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1597094.npy", { "accuracy_score": score })

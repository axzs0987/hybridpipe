import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
loans = pd.read_csv("../input/lending-club-data/loan_data.csv")
loans.info()
loans.describe()
loans.head()
print("Toplam sütun sayısı (veri öznitelik sayısı):", len(loans.columns))
print("Toplam satır sayısı (veri sayısı):", len(loans.index))
print("Toplam sınıf sayısı: 2 (Borç alanlarının içinden borcunun ödeyenler ve ödemeyenler (1, 0))")
#sns.set_style("whitegrid")
#fig = plt.figure(figsize=(15,4))
#sns.distplot(loans[loans["credit.policy"] == 1]["fico"], kde=False, label="Credit Policy = 1")
#sns.distplot(loans[loans["credit.policy"] == 0]["fico"], kde=False, label="Credit Policy = 0")
#plt.legend(loc=0)
#fig = plt.figure(figsize=(15,4))
#sns.distplot(loans[loans["not.fully.paid"] == 0]["fico"], kde=False, label="Not Fully Paid = 0")
#sns.distplot(loans[loans["not.fully.paid"] == 1]["fico"], kde=False, label="Not Fully Paid = 1")
#plt.legend(loc=0)
#fig = plt.figure(figsize=(10,6))
#sns.countplot(x="purpose", data=loans, hue="not.fully.paid")
final_data = pd.get_dummies(loans, columns=["purpose"], drop_first=True)
final_data.head()
X = final_data.drop("not.fully.paid", axis=1)
y = final_data["not.fully.paid"]
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.tree import DecisionTreeClassifier
dtree = DecisionTreeClassifier()
#dtree.fit(X_train, y_train)
#predictions = dtree.predict(X_test)
from sklearn.metrics import confusion_matrix, classification_report
#print(confusion_matrix(y_test, predictions))
#print(classification_report(y_test, predictions))
from sklearn.model_selection import cross_val_score
#print(cross_val_score(dtree, X, y, cv=10))
final_data.drop("not.fully.paid", axis=1).iloc[100]
#dtree.predict([final_data.drop("not.fully.paid", axis=1).iloc[100]])
final_data["not.fully.paid"].iloc[100]
from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=200)
#rfc.fit(X_train, y_train)
#rfc_predictions = rfc.predict(X_test)
#print(confusion_matrix(y_test, predictions))
#print(classification_report(y_test, predictions))
#print(cross_val_score(rfc, X, y, cv=10))
final_data.drop("not.fully.paid", axis=1).iloc[100]
#rfc.predict([final_data.drop("not.fully.paid", axis=1).iloc[100]])
final_data["not.fully.paid"].iloc[100]



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aonursert_ml-proje-1-decision-tree-ve-rain-forest-ile-ml/testY.csv",encoding="gbk")


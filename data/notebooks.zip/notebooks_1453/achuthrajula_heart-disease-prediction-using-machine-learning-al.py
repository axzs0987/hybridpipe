import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import RFE
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn import tree
from sklearn.cluster import KMeans
from sklearn.model_selection import cross_val_score
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
import seaborn as sns
import shap
import warnings  
warnings.filterwarnings('ignore')
data = pd.read_csv('/kaggle/input/heart-disease-uci/heart.csv')
data.columns = ['age', 'sex', 'chest_pain_type', 'resting_blood_pressure', 'cholesterol', 'fasting_blood_sugar', 'rest_ecg', 'max_heart_rate_achieved',       'exercise_induced_angina', 'st_depression', 'st_slope', 'num_major_vessels', 'thalassemia', 'target']
X = data.iloc[:,0:13]
y = data.iloc[:,13]
data.head()
#plt.figure(figsize=(12,10))
cor = data.corr()
#sns.heatmap(cor, annot=True, cmap='coolwarm')
#plt.show()
cor_target = abs(cor["target"])
relevant_features = cor_target[cor_target>0.4]
relevant_features
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
classifiers = [LogisticRegression, MLPClassifier, KNeighborsClassifier, tree.DecisionTreeClassifier, RandomForestClassifier, SVC]
#for model in classifiers:
#    classifier = model()
#    classifier.fit(X_train,y_train)
#    y_pred = classifier.predict(X_test) 
#    print("{} model accuracy: {}".format(model, np.amax(cross_val_score(estimator=classifier, X=X_train, y=y_train, cv=10), axis = 0)))
model = RandomForestClassifier()
#model.fit(X_train, y_train)
#explainer = shap.TreeExplainer(model)
#shap_values = explainer.shap_values(X_test)
#shap.summary_plot(shap_values[1], X_test, plot_type="bar")
#shap.summary_plot(shap_values[1], X_test)
shap.initjs()
#shap_values = explainer.shap_values(X_train.iloc[:50])
#shap.force_plot(explainer.expected_value[1], shap_values[1], X_test.iloc[:50])
#f, axes = plt.subplots(1, 2, figsize=(20, 10))
#sns.lineplot(X_train['chest_pain_type'],y_train,ax=axes[0])
#sns.lineplot(X_test['chest_pain_type'],y_pred,ax=axes[0])
#sns.lineplot(X_train['exercise_induced_angina'],y_train,ax=axes[1])
#sns.lineplot(X_test['exercise_induced_angina'],y_pred,ax=axes[1])




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/achuthrajula_heart-disease-prediction-using-machine-learning-al.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/achuthrajula_heart-disease-prediction-using-machine-learning-al/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

df=pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

df.head()

# In[None]

df['quality'].unique()

# In[None]

df.info()

# In[None]

df.describe()

# In[None]

df.corr()

# In[None]

bins = [2,4,6,9]
labels= ['bad','medium','good']
df['quality']=pd.cut(df['quality'],bins=bins, labels=labels)
df.head()

# In[None]

df['quality'].replace('medium',1,inplace=True)
df['quality'].replace('good',2,inplace=True)
df['quality'].replace('bad',0,inplace=True)

# In[None]

df['quality'].head()

# In[None]

fig, ax = plt.subplots(figsize=(15,7))
sns.heatmap(df.corr(),annot=True)

# In[None]

x = df.drop('quality',axis=1)
y=df['quality']

# In[None]

x.head()
y.head()

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9211850.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
from plotnine import *
import statsmodels.api as sm
import statsmodels.formula.api as smf
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
import warnings
warnings.filterwarnings('ignore')

# 1# .#  # *# *# D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n# *# *

# In[None]

wine_df = pd.read_csv('../input/winequality-red.csv')

# In[None]

wine_df.describe()

# In[None]

wine_df.info()

# In[None]

wine_df.head()

# *# *# 2# .#  # W# i# n# e#  # Q# u# l# a# i# t# y#  # C# o# r# r# e# l# a# t# i# o# n#  # H# e# a# t# m# a# p# *# *# 
# 
# T# o#  # d# e# t# e# r# m# i# n# e#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # b# e# t# w# e# e# n#  # e# a# c# h#  # v# a# r# i# a# b# l# e#  # a# n# d#  # w# i# n# e#  # q# u# a# l# i# t# y# ,#  # a#  # c# o# r# r# e# l# a# t# i# o# n#  # h# e# a# t# m# a# p#  # i# s#  # m# a# d# e# .

# In[None]

plt.subplots(figsize=(20,15))
ax = plt.axes()
ax.set_title("Wine Quality Correlation Heatmap")
corr = wine_df.corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values,
           center=0)


# In[None]

corr = wine_df.corr()
corr

# *# *# 3# .#  # F# a# c# e# t#  # P# l# o# t# *# *# 
# 
# F# a# c# e# t#  # p# l# o# t# s#  # a# r# e#  # u# s# e# d#  # h# e# r# e#  # t# o#  # p# l# o# t#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # b# e# t# w# e# e# n#  # s# e# t#  # v# a# r# i# a# b# l# e# s#  # i# n#  # m# u# l# t# i# p# l# e#  # s# u# b# s# e# t# s#  # o# f#  # t# h# e#  # d# a# t# a#  # w# i# t# h#  # t# h# e#  # r# e# s# u# l# t# s#  # a# p# p# e# a# r# i# n# g#  # a# s#  # p# a# n# e# l# s#  # i# n#  # a#  # l# a# r# g# e# r#  # f# i# g# u# r# e# .# 
# 
# F# i# r# s# t# ,#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # "# q# u# a# l# i# t# y# "# ,#  # "# v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y# "# ,#  # "# c# i# t# r# i# c#  # a# c# i# d# "# ,#  # a# n# d#  # "# a# l# c# o# h# o# l# "#  # a# r# e#  # t# r# a# n# s# f# e# r# e# d#  # t# o#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a# .

# In[None]

bins_quality = [0, 5.5, 6, 7, 8]
group_quality = ['bad','average','above average','good']
wine_df['binned_quality'] = pd.cut(wine_df['quality'], bins = bins_quality, labels = group_quality)
wine_df.head()

# In[None]

bins_volatile_acid = [0, 0.5, 0.7, 2]
group_volatile_acid = ['low','average','high']
wine_df['binned_volatile_acid'] = pd.cut(wine_df['volatile acidity'], bins = bins_volatile_acid, labels = group_volatile_acid)
wine_df.head()

# In[None]

bins_citric_acid = [-0.1, 0.3, 0.6, 1]
group_citric_acid = ['low','average','high']
wine_df['binned_citric_acid'] = pd.cut(wine_df['citric acid'], bins = bins_citric_acid, labels = group_citric_acid)
wine_df.head()

# In[None]

bins_alcohol = [0, 10, 11, 15]
group_alcohol = ['low','average','high']
wine_df['binned_alcohol'] = pd.cut(wine_df['alcohol'], bins = bins_alcohol, labels = group_alcohol)
wine_df.head()

# In[None]

wine_df.info()

# T# w# o#  # f# a# c# e# t#  # p# l# o# t# s#  # a# r# e#  # m# a# d# e#  # a# s#  # f# o# l# l# o# w# ,#  # w# i# t# h#  # "# s# u# l# p# h# a# t# e# s# "#  # a# s#  # x# -# a# x# i# s#  # a# n# d#  # "# c# h# l# o# r# i# d# e# s# "#  # a# s#  # y# _# a# x# i# s# .

# In[None]

ggplot(wine_df, aes(x='sulphates', y='chlorides', color='binned_alcohol', shape='binned_volatile_acid')) + geom_point() +\
    facet_wrap('binned_quality', ncol=2) + scale_color_brewer(type = 'qual', palette = 'Dark2')

# In[None]

ggplot(wine_df, aes(x='sulphates', y='chlorides', color='binned_alcohol', size='binned_citric_acid')) + geom_point() +\
    facet_wrap('binned_quality', ncol=2) + scale_color_brewer(type = 'qual', palette = 'Dark2')

# *# *# 4# .#  # C# r# e# a# t# e#  # T# r# a# i# n# i# n# g#  # a# n# d#  # T# e# s# t#  # S# e# t# s# *# *# 
# 
# W# e# ’# l# l#  # u# s# e#  # t# h# e#  # t# r# a# i# n# _# t# e# s# t# _# s# p# l# i# t#  # m# e# t# h# o# d#  # t# o#  # s# p# l# i# t#  # t# h# e#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t#  # d# a# t# a# s# e# t# .

# In[None]

new_wine_df = pd.read_csv('../input/winequality-red.csv')
features_df = new_wine_df.drop(['quality'], axis = 1)
y = new_wine_df['quality']
features_df.head()

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features_df, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2671465.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

bank = pd.read_csv('/kaggle/input/bank-marketing-dataset/bank.csv')

# In[None]

bank.head()

# In[None]

bank.info()

# In[None]

sns.distplot(bank['balance'])


# In[None]


sns.FacetGrid(data=bank,hue='deposit',size=6).map(sns.distplot,'age').add_legend()

# In[None]

sns.set_style('whitegrid')
sns.boxplot(x='age',y='education',data=bank)


# In[None]

num1 = bank[['age','balance','day','duration','campaign','pdays','previous']]

# In[None]

cat = bank[['job','marital','education','housing','contact','month','poutcome','default','loan','deposit']]

# In[None]

from sklearn.preprocessing import LabelEncoder
lab = LabelEncoder()
cat1 = cat.apply(lab.fit_transform)

# In[None]

cat1

# In[None]

data = num1.join(cat1)

# In[None]

bank.head()

# In[None]

data.head()

# In[None]

data.corr()

# In[None]

X = data.drop('deposit',axis=1)

# In[None]

y = data['deposit']

# In[None]

sns.heatmap(data.isnull())

# A# s#  # w# e#  # s# e# e#  # w# e#  # h# a# v# e#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # n# o# w#  # w# e#  # w# i# l# l#  # m# o# v# e#  # t# o# w# a# r# d# s#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # s# t# e# p# s

# In[None]

data.isnull().sum()

# In[None]

X['pdays'].describe()

# H# e# r# e# .# .# .# .# m# o# s# t#  # o# f#  # t# h# e#  # e# n# t# r# i# e# s#  # i# n#  # c# o# l# u# m# n#  # '# p# d# a# y# s# '#  # i# s#  # n# e# g# a# t# i# v# e# (# i# .# e#  # -# 1# )

# In[None]

X = X.drop('pdays',axis=1)

# In[None]

X

# In[None]

plt.figure(figsize=(15,15))
sns.heatmap(data.corr())

# In[None]

from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import f_regression
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.model_selection import cross_val_score
logit = LogisticRegression()
pred = logit.fit(X,y)

# In[None]

pred.score(X,y)

# In[None]

coef = pred.coef_

# In[None]

coef.round(3)

# In[None]

f_regression(X,y)

# In[None]

p_values = f_regression(X,y)[1]

# In[None]

p_values

# In[None]

regressor_OLS = sm.OLS(y,X)
result = regressor_OLS.fit()
result.summary()

# ##  # M# L#  # M# o# d# e# l# l# i# n# g# *# *# *# *

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8537203.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
dataset = pd.read_csv('/kaggle/input/heart-disease/heart.csv')
dataset.head()
dataset.columns
categorical = ['sex', 'cp', 'restecg', 'slope', 'thal']
do_not_touch = ['fbs', 'exang']
non_categorical = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'ca']
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
ct = ColumnTransformer(transformers=[('encoder',OneHotEncoder(),categorical)],remainder='passthrough')
X = ct.fit_transform(dataset[categorical+do_not_touch+non_categorical])
y = dataset['target'].values
X[0,:]
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train[:,-6:] = scaler.fit_transform(X_train[:,-6:])
X_test[:,-6:] = scaler.transform(X_test[:,-6:])
X_train[0,:]
from sklearn.svm import SVC
estimator = SVC()
parameters = [{'kernel':['rbf'],               'C':[1,10,100,1000],               'gamma':[1,0.1,0.001,0.0001],            },            {'kernel':['poly'],               'C':[1,10,100,1000],               'gamma':[1,0.1,0.001,0.0001],             'degree':range(1,5)}             ]
from sklearn.model_selection import GridSearchCV
 
grid_search = GridSearchCV(    estimator=estimator,    param_grid=parameters,    scoring = 'accuracy',    n_jobs = 10,    cv = 10,    verbose=True)
#grid_search.fit(X_train, y_train)
#grid_search.best_estimator_
#y_pred = grid_search.best_estimator_.predict(X_test)
from sklearn.metrics import confusion_matrix, accuracy_score
#print(confusion_matrix(y_test,y_pred))
#accuracy_score(y_test,y_pred)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/abhishekthakur237_heart-disease-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekthakur237_heart-disease-prediction/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekthakur237_heart-disease-prediction/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekthakur237_heart-disease-prediction/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekthakur237_heart-disease-prediction/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/abhishekthakur237_heart-disease-prediction/testY.csv",encoding="gbk")


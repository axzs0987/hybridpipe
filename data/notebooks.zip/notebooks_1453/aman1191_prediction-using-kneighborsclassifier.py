import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
cancer = pd.read_csv('/kaggle/input/breast-cancer-prediction-dataset/Breast_cancer_data.csv')
cancer.head()
cancer.shape
malignant = len(cancer[cancer['diagnosis'] == 0 ])
benign  = len(cancer[cancer['diagnosis'] == 1 ])
print(pd.Series(data = [malignant, benign], index = ["malignant", "benign"]))
X = cancer.drop('diagnosis', axis = 1)
y = cancer['diagnosis']
print(X.shape)
print(y.shape)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 1)
#predict = knn.fit(X_train, y_train)
#print(predict)
means = cancer.mean()[:-1].values.reshape(1, -1)
#label = predict.predict(means)
#print(label)
#knn.predict(X_test)
#knn.score(X_test,y_test)
import matplotlib.pyplot as plt
mal_train_X = X_train[y_train==0]
mal_train_y = y_train[y_train==0]
ben_train_X = X_train[y_train==1]
ben_train_y = y_train[y_train==1]
mal_test_X = X_test[y_test==0]
mal_test_y = y_test[y_test==0]
ben_test_X = X_test[y_test==1]
ben_test_y = y_test[y_test==1]
#scores = [knn.score(mal_train_X, mal_train_y), knn.score(ben_train_X, ben_train_y),               knn.score(mal_test_X, mal_test_y), knn.score(ben_test_X, ben_test_y)]
#plt.figure()
#bars = plt.bar(np.arange(4), scores, color=['#4c72b0','#4c72b0','#55a868','#55a868'])
#for bar in bars:
#    height = bar.get_height()
#    plt.gca().text(bar.get_x() + bar.get_width()/2, height*.90, '{0:.{1}f}'.format(height, 2),                      ha='center', color='w', fontsize=11)
#plt.tick_params(top='off', bottom='off', left='off', right='off', labelleft='off', labelbottom='on')
for spine in plt.gca().spines.values():
    spine.set_visible(False)
#    plt.xticks([0,1,2,3], ['Malignant\nTraining', 'Benign\nTraining', 'Malignant\nTest', 'Benign\nTest'], alpha=0.8);
#    plt.title('Training and Test Accuracies for Malignant and Benign Cells', alpha=0.8)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aman1191_prediction-using-kneighborsclassifier.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aman1191_prediction-using-kneighborsclassifier/testY.csv",encoding="gbk")


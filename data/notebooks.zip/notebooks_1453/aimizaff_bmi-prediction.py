import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn import svm
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import os
#print(os.listdir("../input"))
BMI = pd.read_csv('../input/500-person-gender-height-weight-bodymassindex/500_Person_Gender_Height_Weight_Index.csv')
BMI.tail()
gender_label = LabelEncoder()
BMI['Gender'] = gender_label.fit_transform(BMI['Gender'])
bins = (-1,0,1,2,3,4,5)
health_status = ['Extremely Underweight','Underweight', 'Normal', 'Overweight', 'Obese', 'Extremely Obese']
BMI['Index'] = pd.cut(BMI['Index'], bins = bins, labels = health_status)
BMI['Index'].value_counts()
#sns.countplot(BMI['Index'])
BMI.info()
BMI['Index']
BMI.tail()
X = BMI.drop('Index', axis = 1)
y = BMI['Index']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)
rfc = RandomForestClassifier(n_estimators=200)
#rfc.fit(X_train, y_train)
#pred_rfc = rfc.predict(X_test)
#print(classification_report(y_test, pred_rfc))
#print(confusion_matrix(y_test, pred_rfc))
clf = svm.SVC()
#clf.fit(X_train, y_train)
#pred_clf = clf.predict(X_test)
#print(classification_report(y_test, pred_clf))
#print(confusion_matrix(y_test, pred_clf))
mlpc = MLPClassifier(hidden_layer_sizes=(3,3,3), max_iter = 500)
#mlpc.fit(X_train, y_train)
#pred_mlpc = mlpc.predict(X_test)
#print(classification_report(y_test, pred_mlpc))
#print(confusion_matrix(y_test, pred_mlpc))
from sklearn.metrics import accuracy_score
#cm = accuracy_score(y_test, pred_rfc)
#cm
Xnew = [[1,175,35]] 
Xnew = sc.transform(Xnew)
#ynew = rfc.predict(Xnew)
#ynew



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aimizaff_bmi-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aimizaff_bmi-prediction/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aimizaff_bmi-prediction/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aimizaff_bmi-prediction/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aimizaff_bmi-prediction/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aimizaff_bmi-prediction/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aimizaff_bmi-prediction/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aimizaff_bmi-prediction/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aimizaff_bmi-prediction/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aimizaff_bmi-prediction/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aimizaff_bmi-prediction/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aimizaff_bmi-prediction/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aimizaff_bmi-prediction/testY.csv",encoding="gbk")


import pandas as pd
# A# s# s# i# g# n# m# e# n# t#  # 6#  # -#  # T# e# a# m#  # M# e# m# b# e# r# s# 
# 1# .#  # P# r# a# j# w# a# l#  # K# i# r# a# n#  # K# u# m# a# r#  # -#  # 0# 1# F# B# 1# 6# E# C# S# 2# 6# 0# 
# 2# .#  # R# a# h# u# l#  # S# h# i# v# a# p# r# a# s# a# d#  # -#  # 0# 1# F# B# 1# 6# E# C# S# 2# 9# 1# 
# 3# .#  # R# a# s# y# a#  # R# a# m# e# s# h#  # -#  # 0# 1# F# B# 1# 6# E# C# S# 2# 9# 9

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# M# e# t# h# o# d#  # 1#  # :#  # D# e# c# i# s# i# o# n#  # T# r# e# e# *# *# 
# 
# W# e#  # h# a# v# e#  # u# s# e# d#  # t# h# e#  # d# e# c# i# s# i# o# n#  # t# r# e# e#  # a# p# p# r# o# a# c# h#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e#  # d# a# t# a# .#  # T# h# e#  # a# c# c# u# r# a# c# y#  # p# r# o# v# i# d# e# d#  # b# y#  # t# h# i# s#  # a# l# g# o# r# i# t# h# m#  # w# a# s#  # c# o# n# s# i# s# t# e# n# t# l# y#  # h# i# g# h# e# r#  # t# h# a# n#  # t# h# o# s# e#  # o# f#  # o# t# h# e# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# l# g# o# r# i# t# h# m# s# .#  # T# h# e#  # a# d# v# a# n# t# a# g# e#  # o# f#  # t# h# i# s#  # a# p# p# r# o# a# c# h#  # w# o# u# l# d#  # b# e#  # t# h# a# t#  # w# e#  # d# o# n# '# t#  # n# e# e# d#  # t# o#  # w# o# r# r# y#  # a# b# o# u# t#  # h# o# w#  # m# a# n# y#  # c# l# u# s# t# e# r# s#  # n# e# e# d#  # t# o#  # b# e#  # c# h# o# s# e# n# .#  # T# h# e#  # d# i# s# a# d# v# a# n# t# a# g# e#  # i# s#  # t# h# a# t#  # i# t#  # h# a# s#  # t# h# e#  # t# e# n# d# e# n# c# y#  # t# o#  # o# v# e# r# f# i# t# .#  # S# o# l# u# t# i# o# n#  # t# o#  # o# v# e# r# c# o# m# e#  # t# h# i# s#  # i# s# s# u# e#  # w# o# u# l# d#  # b# e#  # t# o#  # u# s# e#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# .

# In[None]

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.model_selection import train_test_split

dataset = pd.read_csv('../input/Absenteeism_at_work.csv')
X = dataset.iloc[:,1:-1]
y = dataset.iloc[:,-1]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1829499.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
data = pd.read_csv('../input/Breast_cancer_data.csv')
data.head()
data.info()
data.describe()
data.corr()
data['diagnosis'].value_counts()
y = data.diagnosis.values
x = data.drop('diagnosis', axis=1)
x.head(3)
x = (x-np.min(x))/(np.max(x)-np.min(x))
x.describe()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
print('x_train.shape:', x_train.shape)
print('y_train.shape:', y_train.shape)
print('x_test.shape :', x_test.shape)
print('y_test.shape :', x_test.shape)
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression() 
#lr.fit(x_train, y_train)
#print('Scenario_1 score of the logistic regression: ', lr.score(x_test, y_test))
from sklearn.model_selection import GridSearchCV
grid = {'C': np.logspace(-3,3,7), 'penalty': ['l1', 'l2']}
lr = LogisticRegression() 
#lr_cv = GridSearchCV(lr, grid, cv=10) 
#lr_cv.fit(x_train, y_train)
#print('best paremeters for logistic regression: ', lr_cv.best_params_)
#print('best score for logistic regression after grid search cv:', lr_cv.best_score_)
lr_tuned = LogisticRegression(C=100.0, penalty='l1')
#lr_tuned.fit(x_train, y_train)
#print('Scenario_2 (tuned) logistic regression score: ', lr_tuned.score(x_test, y_test))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/akdagmelih_grid-search-cross-validation-for-log-regression.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/akdagmelih_grid-search-cross-validation-for-log-regression/testY.csv",encoding="gbk")


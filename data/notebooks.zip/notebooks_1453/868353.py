import pandas as pd
# In[2]

import pandas as pd
import seaborn as sb
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import SGDClassifier
# Reading wine quality dataset
df = pd.read_csv('../input/winequality-red.csv', engine = 'python', error_bad_lines = False)
width = len(df.columns)
print(df.columns)

# In[3]

# Binning values of quality attribute
df['quality'] = pd.cut(df['quality'], (2, 6.5, 8), labels = [0, 1])

# In[4]

# Dividing dataframe to data and target labels
data = df.iloc[:, [1, 2, 4, 6, 9, 10, 11]] # Features selected after visualising trends in data
data = data.sample(frac = 1)
X = data.iloc[:, :6]
Y = data.iloc[:, 6]
sc = StandardScaler()
print('Bad wine : %d, Good wine : %d'%(Counter(Y)[0], Counter(Y)[1]))

# In[9]

# Training and evaluating Random Forest classifier
X = sc.fit_transform(X)    
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/868353.npy", { "accuracy_score": score })

import pandas as pd
# ##  # *# *# I# N# S# T# I# T# U# T# O#  # D# E#  # E# D# U# C# A# Ç# Ã# O#  # S# U# P# E# R# I# O# R#  # D# E#  # B# R# A# S# Í# L# I# A#  # -#  # I# E# S# B# *# *# 
# 
# *# *# T# R# A# B# A# L# H# O#  # F# I# N# A# L#  # D# A#  # M# A# T# É# R# I# A# :#  # *# *#  # D# a# t# a#  # M# i# n# i# n# g#  # e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # I# I# 
# 
# 
# 
# *#  # *# *# P# r# o# f# e# s# s# o# r# :#  # *# *#  # M# a# r# c# o# s# 
# *#  # *# *# C# a# m# p# u# s# :#  # *# *#  # A# s# a#  # N# o# r# t# e# 
# *#  # *# *# A# l# u# n# a# :#  # *# *#  # L# a# í# s#  # A# .#  # d# e#  # S# o# u# z# a

# ##  # *# *# I# n# t# r# o# d# u# ç# ã# o# *# *# 
# 
# O#  # p# r# e# s# e# n# t# e#  # t# r# a# b# a# l# h# o#  # t# e# m#  # o#  # f# o# c# o#  # p# r# i# n# c# i# p# a# l#  # d# e#  # i# m# p# l# e# m# e# n# t# a# r#  # o#  # m# o# d# e# l# o#  # R# a# n# d# o# m# F# o# r# e# s# t#  # p# a# r# a#  # o#  # c# o# n# j# u# n# t# o#  # d# e#  # d# a# d# o# s#  # d# e#  # H# o# m# e#  # E# q# u# i# t# y#  # (# H# M# E# Q# )#  # e#  # a# n# a# l# i# s# a# r#  # s# e#  # o#  # m# o# d# e# l# o#  # é#  # c# a# p# a# z#  # d# e#  # d# e# f# i# n# i# r#  # s# e#  # é#  # u# m#  # b# o# m#  # p# a# g# a# d# o# r#  # o# u#  # n# ã# o# .# 
# S# e# r# á#  # u# t# i# l# i# z# a# d# o#  # a#  # b# i# b# l# i# o# t# e# c# a#  # *# *# s# c# i# k# i# t# -# l# e# a# r# n# *# *#  # *# R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# e# r# *# 
# 


# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sn
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

#Ler o arquivo e gravar no DataFrame
df = pd.read_csv('/kaggle/input/hmeq-data/hmeq.csv')

# In[None]

#Apresentar o cabeçalho e os 5 primeiros registros
df.head()

# ##  # D# i# c# i# o# n# á# r# i# o#  # d# e#  # d# a# d# o# s# 
# 
# *#  # B# A# D# :#  # 1#  # =#  # c# l# i# e# n# t# e#  # i# n# a# d# i# m# p# l# e# n# t# e#  # n# o#  # e# m# p# r# é# s# t# i# m# o#  # 0#  # =#  # e# m# p# r# é# s# t# i# m# o#  # r# e# e# m# b# o# l# s# a# d# o# 
# *#  # L# O# A# N# :#  # M# o# n# t# a# n# t# e#  # d# o#  # p# e# d# i# d# o#  # d# e#  # e# m# p# r# é# s# t# i# m# o# 
# *#  # M# O# R# T# D# U# E# :#  # V# a# l# o# r#  # d# e# v# i# d# o#  # d# a#  # h# i# p# o# t# e# c# a#  # e# x# i# s# t# e# n# t# e# 
# *#  # V# A# L# U# E# :#  # V# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # a# t# u# a# l# 
# *#  # R# E# A# S# O# N# :#  # D# e# b# t# C# o# n#  # =#  # c# o# n# s# o# l# i# d# a# ç# ã# o#  # d# a#  # d# í# v# i# d# a#  # H# o# m# e# I# m# p#  # =#  # m# e# l# h# o# r# i# a#  # d# a#  # c# a# s# a# 
# *#  # J# O# B# S# :#  # S# e# i# s#  # c# a# t# e# g# o# r# i# a# s#  # o# c# u# p# a# c# i# o# n# a# i# s# 
# *#  # Y# O# J# :#  # A# n# o# s#  # n# o#  # e# m# p# r# e# g# o#  # a# t# u# a# l# 
# *#  # D# E# R# O# G# :#  # N# ú# m# e# r# o#  # d# e#  # p# r# i# n# c# i# p# a# i# s#  # r# e# l# a# t# ó# r# i# o# s#  # d# e# p# r# e# c# i# a# t# i# v# o# s# 
# *#  # D# E# L# I# N# Q# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # i# n# a# d# i# m# p# l# e# n# t# e# s# 
# *#  # C# L# A# G# E# :#  # I# d# a# d# e#  # d# a#  # l# i# n# h# a#  # c# o# m# e# r# c# i# a# l#  # m# a# i# s#  # a# n# t# i# g# a#  # e# m#  # m# e# s# e# s# 
# *#  # N# I# N# Q# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # r# e# c# e# n# t# e# s# 
# *#  # C# L# N# O# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o# 
# *#  # D# E# B# T# I# N# C# :#  # R# á# c# i# o#  # d# í# v# i# d# a#  # /#  # r# e# n# d# i# m# e# n# t# o

# ##  # T# r# a# n# s# f# o# r# m# a# ç# ã# o#  # d# e#  # D# a# d# o# s# 
# 
# E# s# s# a#  # e# t# a# p# a#  # é#  # e# x# e# c# u# t# a# d# a#  # p# a# r# a#  # t# r# a# n# s# f# o# r# m# a# r#  # o# s#  # d# a# d# o# s#  # o# r# i# g# i# n# a# i# s#  # e# m#  # f# o# r# m# a# t# o# s#  # m# a# i# s#  # a# p# r# o# p# r# i# a# d# o# s#  # e#  # a# d# e# q# u# a# d# o# s#  # p# a# r# a#  # a#  # a# p# l# i# c# a# ç# ã# o#  # d# o#  # m# o# d# e# l# o# :# 
# 1# .#  # T# r# a# s# n# f# o# r# m# a# r#  # o# s#  # d# a# d# o# s#  # o# b# j# e# c# t# 
# 1# .#  # R# e# t# i# r# a# r#  # o# s#  # r# e# g# i# s# t# r# o# s#  # m# i# s# s# i# n# g#  # :#  # h# t# t# p# s# :# /# /# s# i# g# m# o# i# d# a# l# .# a# i# /# c# o# m# o# -# t# r# a# t# a# r# -# d# a# d# o# s# -# a# u# s# e# n# t# e# s# -# c# o# m# -# p# a# n# d# a# s# /# 


# In[None]

# Verificar quais são as colunas objetct
df.select_dtypes('object').head()

# In[None]

# Analisando os registros  da coluna REASON
df['REASON'].value_counts()

# In[None]

# Analisando os registros com os valores missing
pd.isnull(df).sum()

# In[None]

#Apresentar a quantidade de registros e colunas
df.shape

# In[None]

#Deletar os registros com dados nulos
df_all = (df.dropna(axis=0))

# In[None]

#Verificar se ainda existe registros nulos
pd.isnull(df_all).sum()

# In[None]

#Apresentar a quantidade de registros e colunas após a exclusão dos registros nulos
df_all.shape

# In[None]

# Transformar os registros 'DebtCon' em 1 e 'HomeImp' em 0
# Na coluna REASON
mapeamento = { 'DebtCon': 1, 'HomeImp': 0}

df_all['REASON'] = df_all['REASON'].replace(mapeamento).astype(int)


# In[None]

#Verificar a transformação da coluna 'REASON'
df_all.head()

# In[None]

# Analisando os dados da coluna JOB
df['JOB'].value_counts()

# In[None]

# Transformar 'Other' em 0, 'ProfExe' em 1, 'Office'em 2, 'Mgr'em 3, 'Self'em 4, 'Sales' em 5
# nas coluna JOB
mapeamento = { 'Other': 0, 'ProfExe': 1, 'Office': 2, 'Mgr': 3, 'Self': 4, 'Sales': 5}

df_all['JOB'] = df_all['JOB'].replace(mapeamento).astype(int)

# In[None]

#Verificar a transformação da coluna 'JOB'
df_all.head()

# ##  # A# n# a# l# i# s# e#  # E# x# p# l# o# r# a# t# ó# r# i# a# 
# 
# A#  # A# n# á# l# i# s# e#  # E# x# p# l# o# r# a# t# ó# r# i# a#  # d# e#  # D# a# d# o# s#  # c# o# n# s# i# s# t# e#  # e# m#  # a# n# a# l# i# s# a# r#  # b# a# s# e# s#  # d# e#  # d# a# d# o# s#  # e#  # e# x# t# r# a# i# r#  # i# n# f# o# r# m# a# ç# õ# e# s#  # ú# t# e# i# s#  # d# o# s#  # d# a# d# o# s#  # a# t# r# a# v# é# s#  # d# e#  # t# é# c# n# i# c# a# s#  # d# e#  # v# i# s# u# a# l# i# z# a# ç# õ# e# s# .

# In[None]

#Quantidade de registros por tipo de trabalho
df.groupby('JOB')['JOB'].count()

# In[None]

#Descrever os dados quantitativos
df_all.describe()

# In[None]

import seaborn as sns

sns.set_style('darkgrid')
sns.distplot(df['YOJ'])

# ##  # M# o# d# e# l# o#  # R# a# n# d# o# m#  # F# o# r# e# s# t# 
# 
# R# a# n# d# o# m#  # F# o# r# e# s# t#  # é#  # u# m#  # a# l# g# o# r# i# t# m# o#  # d# e#  # a# p# r# e# n# d# i# z# a# g# e# m#  # d# e#  # m# á# q# u# i# n# a#  # f# l# e# x# í# v# e# l#  # e#  # f# á# c# i# l#  # d# e#  # u# s# a# r#  # q# u# e#  # p# r# o# d# u# z#  # e# x# c# e# l# e# n# t# e# s#  # r# e# s# u# l# t# a# d# o# s#  # a#  # m# a# i# o# r# i# a#  # d# a# s#  # v# e# z# e# s# ,#  # m# e# s# m# o#  # s# e# m#  # a# j# u# s# t# e#  # d# e#  # h# i# p# e# r# p# a# r# â# m# e# t# r# o# s# .# 
# *#  # h# t# t# p# s# :# /# /# m# e# d# i# u# m# .# c# o# m# /# m# a# c# h# i# n# a# -# s# a# p# i# e# n# s# /# o# -# a# l# g# o# r# i# t# m# o# -# d# a# -# f# l# o# r# e# s# t# a# -# a# l# e# a# t# %# C# 3# %# B# 3# r# i# a# -# 3# 5# 4# 5# f# 6# b# a# b# d# f# 8

# In[None]

# Definindo as colunas para treinamento
feats = [c for c in df_all.columns if c not in ['BAD']]

# In[None]

#Apresentar as colunas
feats

# In[None]

# importando a biblioteca para definir teste e treino

from sklearn.model_selection import train_test_split

# In[None]

# Separar os dataframes
y_varible = df_all["BAD"]
x_varible = df_all.drop(["BAD"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/8867982.npy", { "accuracy_score": score })

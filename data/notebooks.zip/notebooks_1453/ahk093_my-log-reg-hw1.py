import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
df = pd.read_csv("../input/voice.csv")
df.head()
df.info()
df.label = [1 if each == "male" else 0 for each in df.label]
df.label.head()
x_data = df.drop(["label"],axis = 1)
y = df.label.values
x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data))
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
#lr.fit(x_train,y_train) 
#print("Test Accuracy: %{}".format(lr.score(x_test,y_test)*100))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ahk093_my-log-reg-hw1.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/ahk093_my-log-reg-hw1/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/ahk093_my-log-reg-hw1/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/ahk093_my-log-reg-hw1/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/ahk093_my-log-reg-hw1/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/ahk093_my-log-reg-hw1/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/ahk093_my-log-reg-hw1/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ahk093_my-log-reg-hw1/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ahk093_my-log-reg-hw1/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ahk093_my-log-reg-hw1/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ahk093_my-log-reg-hw1/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ahk093_my-log-reg-hw1/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ahk093_my-log-reg-hw1/testY.csv",encoding="gbk")


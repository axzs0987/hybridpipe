import pandas as pd
# In[None]

import numpy as np 
import pandas as pd 
from patsy import dmatrices 
from sklearn.linear_model import LogisticRegression 
from sklearn.model_selection import train_test_split, cross_val_score 
from sklearn import metrics 
import matplotlib.pyplot as plt 

# 1# .#  # R# e# a# d#  # D# a# t# a#  # .# .# /# i# n# p# u# t# /# H# R# _# c# o# m# m# a# _# s# e# p# .# c# s# v

# In[None]

data = pd.read_csv("../input/HR_comma_sep.csv")
data.head()
data.columns

# In[None]

data.left = data.left.astype(int)

# 2# .#  # R# e# l# a# t# i# o# n# s#  # (# l# e# f# t#  # a# n# d#  # s# a# l# a# r# y# )

# In[None]

pd.crosstab(data.salary, data.left).plot(kind = 'bar', stacked = True)



# In[None]

tmp = pd.crosstab(data.salary, data.left)
tmp.div(tmp.sum(axis =1), axis = 0).plot(kind = 'bar', stacked = True)

# L# e# f# t#  # v# s# .#  # s# a# t# i# s# f# a# c# t# i# o# n#  # l# e# v# e# l

# In[None]

plt.subplot(121)
data[data['left'] == 0]['satisfaction_level'].hist(bins = 50)
plt.subplot(122)
data[data['left'] == 1]['satisfaction_level'].hist(bins = 50)

# d# m# a# t# r# i# c# e# s#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s# ;

# In[None]

y, X = dmatrices('left ~ satisfaction_level + last_evaluation + number_project + average_montly_hours + time_spend_company + Work_accident + promotion_last_5years + C(sales) + C(salary)',data, return_type = 'dataframe')

# In[None]

X = X.rename(columns = {
    'C(sales)[T.RandD]': 'Department: Random',
    'C(sales)[T.accounting]': 'Department: Accounting',
    'C(sales)[T.hr]': 'Department: HR',
    'C(sales)[T.management]': 'Department: Management',
    'C(sales)[T.marketing]': 'Department: Marketing',
    'C(sales)[T.product_mng]': 'Department: Product_Management',
    'C(sales)[T.sales]': 'Department: Sales',
    'C(sales)[T.support]': 'Department: Support',
    'C(sales)[T.technical]': 'Department: Technical',
    'C(salary)[T.low]': 'Salary: Low',
    'C(salary)[T.medium]': 'Salary: Medium'}) 
y = np.ravel(y) # 将y变成np的一维数组

# T# r# a# i# n# i# n# g#  # d# a# t# a#  # u# s# e#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n

# In[None]

model = LogisticRegression()
model.fit(X,y)
pd.DataFrame(list(zip(X.columns, np.transpose(model.coef_))))

# S# c# o# r# e#  # o# f#  # t# h# e#  # m# o# d# e# l

# In[None]

print(model.score(X,y))
model.coef_

# P# r# e# d# i# c# t#  # i# f#  # o# n# e#  # e# m# p# l# o# y# e# e#  # w# i# l# l#  # l# e# a# v# e# :#  # (# e# .# g# .#  # h# i# g# h#  # s# a# l# a# r# y#  # H# R# ,#  # s# a# t# i# s# f# a# c# t# i# o# n#  # l# e# v# e# l#  # 0# .# 5# ,#  # e# v# a# l# u# t# i# o# n#  # l# a# s# t#  # t# i# m# e#  # 0# .# 7# ,#  # 4#  # p# r# o# j# e# c# t# s# ,#  # 1# 6# 0# h# r# /# m# o# n# t# h# ,#  # 3#  # y# e# a# r# s# ,#  # n# o#  # p# r# o# m# o# t# i# o# n#  # i# n#  # l# a# s# t#  # 5#  # y# e# a# r# s# ,#  # n# o#  # i# n# j# u# r# y# )

# In[None]

model.predict_proba([[1,0,0,1,0,0,0,0,0,0,0,0, 0.5, 0.7, 4.0, 160, 3.0, 0, 0]])

# In[None]

model.predict_proba(X)
pred = model.predict(X)
(abs(pred-y)).sum() / len(y)

# S# p# l# i# t#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # d# a# t# a

# In[None]

from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(Xtrain, ytrain)
y_pred = model.predict(Xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/1674265.npy", { "accuracy_score": score })

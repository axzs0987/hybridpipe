import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns  

# In[None]

df = pd.read_csv("../input/winequality-red.csv", encoding='ISO-8859-1')

# In[None]

df.head()

# In[None]

df.columns

# In[None]

df.corr()

# In[None]

df['quality'].unique()

# In[None]

df = df.drop(['residual sugar', 'density'], 1)

z = []
for each in df['quality']:
    if each>=3 and each<7:
        z.append(0)
    else:
        z.append(1)

df['quality'] = z        

y = np.array(df['quality'])
y = y.reshape(-1, 1)
x = np.array(df.drop(['quality'], 1))

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5296337.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
train = pd.read_csv('../input/mobile-price-classification/train.csv')
test = pd.read_csv('../input/mobile-price-classification/train.csv')
X_train = train.drop(["price_range"],axis=1)
y_train = train["price_range"]
print(train.columns)
print(train.head())
print(test.columns)
print(test.head())
train.info()
train.describe()
import statsmodels.api as sm
SL = 0.05
X_train_arr=X_train.values
X_opt = X_train_arr[:, [0, 1, 2, 3, 4, 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]]
X=np.append(arr=np.ones((2000,1)).astype(int),values=X_train,axis=1)
regressor_ols=sm.OLS(endog=y_train,exog=X_opt).fit()
print(regressor_ols.summary())
li=[]
def backwardElimination(x, sl):
    numVars = len(x[0])
    for i in range(0, numVars):
        regressor_OLS = sm.OLS(y_train, x).fit()
        maxVar = max(regressor_OLS.pvalues)
        if maxVar > sl:
            for j in range(0, numVars - i):
                if (regressor_OLS.pvalues[j] == maxVar):
                    x = np.delete(x, j, 1)
                    li.append(j)
    regressor_OLS.summary()
    return x
X_Modeled = backwardElimination(X_opt, SL)
test=test.values
test=np.delete(test,5,1)
test=np.delete(test,6,1)
test=np.delete(test,12,1)
len(X_Modeled[0])
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_Modeled= sc.fit_transform(X_Modeled)
test = sc.fit_transform(test)
len(test[0])
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train1, X_test1, y_train1, y_test1 = train_test_split(X_Modeled, y_train, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.svm import SVC
classifier = SVC(kernel = 'rbf', random_state = 0)
#classifier.fit(X_train1, y_train1)
#y_pred_SVC= classifier.predict(X_test1)
#acc_SVC= round(classifier.score(X_train1,y_train1) * 100, 2)
#print(acc_SVC)
from sklearn.metrics import confusion_matrix
#cm_SVC= confusion_matrix(y_test1, y_pred_SVC)
#print(cm_SVC)
import sklearn
from sklearn.linear_model import LogisticRegression
classifier=LogisticRegression(random_state=0)
#classifier.fit(X_train1,y_train1)
#y_pred_logistic= classifier.predict(X_test1)
#acc_logistic= round(classifier.score(X_train1,y_train1) * 100, 2)
#print(acc_SVC)
from sklearn.metrics import confusion_matrix
#cm_logistic= confusion_matrix(y_test1, y_pred_logistic)
#print(cm_logistic)
from sklearn.neighbors import KNeighborsClassifier
classifier=KNeighborsClassifier(n_neighbors=5,metric='minkowski',p=2)
#classifier.fit(X_train1,y_train1)
#y_pred_knn= classifier.predict(X_test1)
#acc_knn= round(classifier.score(X_train1,y_train1) * 100, 2)
#print(acc_knn)
from sklearn.metrics import confusion_matrix
#cm_knn= confusion_matrix(y_test1, y_pred_knn)
#print(cm_knn)
from sklearn.ensemble import RandomForestClassifier
classifier=RandomForestClassifier(n_estimators=10,criterion="entropy",random_state=0)
#classifier.fit(X_train1,y_train1)
#y_pred_random= classifier.predict(X_test1)
#acc_random= round(classifier.score(X_train1,y_train1) * 100, 2)
#print(acc_random)
from sklearn.metrics import confusion_matrix
#cm_random= confusion_matrix(y_test1, y_pred_random)
from sklearn.metrics import classification_report,confusion_matrix
#print(classification_report(y_test1,y_pred_random))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train1, y_train1)
y_pred = model.predict(X_test1)
score = accuracy_score(y_test1, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/archit9406_mobile-price-classification.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train1).__name__ == "ndarray":
    np.save("hi_res_data/archit9406_mobile-price-classification/trainX.npy", X_train1)
if type(X_train1).__name__ == "Series":
    X_train1.to_csv("hi_res_data/archit9406_mobile-price-classification/trainX.csv",encoding="gbk")
if type(X_train1).__name__ == "DataFrame":
    X_train1.to_csv("hi_res_data/archit9406_mobile-price-classification/trainX.csv",encoding="gbk")

if type(X_test1).__name__ == "ndarray":
    np.save("hi_res_data/archit9406_mobile-price-classification/testX.npy", X_test1)
if type(X_test1).__name__ == "Series":
    X_test1.to_csv("hi_res_data/archit9406_mobile-price-classification/testX.csv",encoding="gbk")
if type(X_test1).__name__ == "DataFrame":
    X_test1.to_csv("hi_res_data/archit9406_mobile-price-classification/testX.csv",encoding="gbk")

if type(y_train1).__name__ == "ndarray":
    np.save("hi_res_data/archit9406_mobile-price-classification/trainY.npy", y_train1)
if type(y_train1).__name__ == "Series":
    y_train1.to_csv("hi_res_data/archit9406_mobile-price-classification/trainY.csv",encoding="gbk")
if type(y_train1).__name__ == "DataFrame":
    y_train1.to_csv("hi_res_data/archit9406_mobile-price-classification/trainY.csv",encoding="gbk")

if type(y_test1).__name__ == "ndarray":
    np.save("hi_res_data/archit9406_mobile-price-classification/testY.npy", y_test1)
if type(y_test1).__name__ == "Series":
    y_test1.to_csv("hi_res_data/archit9406_mobile-price-classification/testY.csv",encoding="gbk")
if type(y_test1).__name__ == "DataFrame":
    y_test1.to_csv("hi_res_data/archit9406_mobile-price-classification/testY.csv",encoding="gbk")


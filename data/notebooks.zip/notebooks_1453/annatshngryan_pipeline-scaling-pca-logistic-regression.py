import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
df= pd.read_csv("../input/College.csv")
df.drop(columns="Unnamed: 0", inplace=True)
df.head()
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, f1_score
X = df.drop('Private', axis=1)
y = df['Private']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
steps = [('scaler', StandardScaler()),         ('pca', PCA(n_components=.95)),         ('clf', LogisticRegression())]
pipe_lr = Pipeline(steps)
#pipe_lr.fit(X_train, y_train)
#train_predictions = pipe_lr.predict(X_train)
#test_predictions = pipe_lr.predict(X_test)
print("TRAIN:")
#print(classification_report(y_train, train_predictions))
print("TEST:")
#print(classification_report(y_test, test_predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/annatshngryan_pipeline-scaling-pca-logistic-regression.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/annatshngryan_pipeline-scaling-pca-logistic-regression/testY.csv",encoding="gbk")


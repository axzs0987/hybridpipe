import pandas as pd
# *# *# I# n# t# r# o# d# u# c# e#  # W# i# n# e# Q# u# a# l# i# t# y#  # M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # U# s# i# n# g#  # E# n# s# e# m# b# l# e#  # m# e# t# h# o# d# s#  # -#  # R# a# n# d# o# m# F# o# r# e# s# t# ,#  # G# r# a# d# i# e# n# t# B# o# o# s# t# i# n# g# ,#  # X# G# B# o# o# s# t# *# *# 
# 
# b# y# .#  # Y# H# J# 
# 
#  # 
# B# a# s# i# c#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# 1# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# 2# .#  # D# e# c# i# s# i# o# n#  # T# r# e# e# 
# 3# .#  # S# V# M#  # (# u# s# e#  # G# r# i# d# S# e# a# r# c# h# C# V# )# 
# 
# E# n# s# e# m# b# l# e#  # m# e# t# h# o# d# s# 
# 4# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # (# u# s# e#  # R# a# n# d# o# m# i# z# e# d# S# e# a# r# c# h# C# V# )# 
# 5# .#  # G# r# a# d# i# e# n# t# B# o# o# s# t# i# n# g#  # (# u# s# e#  # R# a# n# d# o# m# i# z# e# d# S# e# a# r# c# h# C# V# )# 
# 6# .#  # X# G# B# o# o# s# t#  # (# u# s# e#  # R# a# n# d# o# m# i# z# e# d# S# e# a# r# c# h# C# V# )# 
#  

# In[None]

import numpy as np
import pandas as pd
from time import time
import scipy.stats as st

import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

# data Read
data = pd.read_csv('../input/winequality-red.csv')

# In[None]

# data Check
data.head(10)

# In[None]

data.info()

# In[None]

data.describe()

# In[None]

# Correlation Analysis
data.corr()

# In[None]

data.corr()['quality'].sort_values(ascending=False)

# In[None]

# Seaborn Heatmap, cmap param = Blues, Greys, OrRd, RdBu_r, Reds
plt.figure(figsize=(10,10))
sns.heatmap(data.corr(), cmap='RdBu_r', annot=True, linewidths=0.5)

# In[None]

# volatile acidity, citric acid, sulphates, alcohol
# fixed acidity, chlorides, total sulfur dioxide, density
# Use Boxplot
fig, axs = plt.subplots(2, 4, figsize = (20,10)) 
ax1 = plt.subplot2grid((5,15), (0,0), rowspan=2, colspan=3) 
ax2 = plt.subplot2grid((5,15), (0,4), rowspan=2, colspan=3)
ax3 = plt.subplot2grid((5,15), (0,8), rowspan=2, colspan=3)
ax4 = plt.subplot2grid((5,15), (0,12), rowspan=2, colspan=3)

ax5 = plt.subplot2grid((5,15), (3,0), rowspan=2, colspan=3) 
ax6 = plt.subplot2grid((5,15), (3,4), rowspan=2, colspan=3)
ax7 = plt.subplot2grid((5,15), (3,8), rowspan=2, colspan=3)
ax8 = plt.subplot2grid((5,15), (3,12), rowspan=3, colspan=3)

sns.boxplot(x='quality',y='volatile acidity', data = data, ax=ax1)
sns.boxplot(x='quality',y='citric acid', data = data, ax=ax2)
sns.boxplot(x='quality',y='sulphates', data = data, ax=ax3)
sns.boxplot(x='quality',y='alcohol', data = data, ax=ax4)

sns.boxplot(x='quality',y='fixed acidity', data = data, ax=ax5)
sns.boxplot(x='quality',y='chlorides', data = data, ax=ax6)
sns.boxplot(x='quality',y='total sulfur dioxide', data = data, ax=ax7)
sns.boxplot(x='quality',y='density', data = data, ax=ax8)

# In[None]

# See the Quality value
sns.countplot(x='quality', data=data)

# In[None]

# Dividing Quality as bad(0), good(1), Excellent(2)
# Bad quality is 3~4 / Good quality is 5~6 / Excellent quality is 7~8
data['quality'] = pd.cut(data['quality'], bins = [1,4.5,6.5,10], labels = [0,1,2])
sns.countplot(x='quality', data=data)

# In[None]

X = data.iloc[:,:-1]
y = data['quality']

# In[None]

# Sscale standization
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)

# In[None]

# PCA - Principal Component Analysis
from sklearn.decomposition import PCA
pca = PCA()
pca.fit_transform(X)

# In[None]

# PCA Components - Barplot
plt.figure(figsize=(6,6))
sns.barplot(x=list(range(len(pca.explained_variance_))), y=pca.explained_variance_, palette="Blues_d")
plt.ylabel('Explained variance Value')
plt.xlabel('Principal components')
plt.grid(True)
plt.tight_layout()

# In[None]

# PCA Components Ratio - plot
plt.figure(figsize=(6,6))
plt.plot(np.cumsum(pca.explained_variance_ratio_), 'ro-')
plt.ylabel('Explained variance ratio')
plt.xlabel('Principal components')
plt.grid(True)
plt.tight_layout()

# In[None]

# Components 0 ~ 8 is explain the data 95% more
pca_comp = PCA(n_components = 8)
X = pca_comp.fit_transform(X)

# L# o# o# k#  # P# C# A#  # r# a# t# i# o#  # p# l# o# t# .#  # W# e#  # U# s# e#  # C# o# m# p# o# n# e# n# t# s#  # 0#  # ~#  # 8# 


# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/802893.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('/kaggle/input/adult-census-income/adult.csv')
df.head()

# In[None]

df['native.country'].unique()

# In[None]

df.isnull().sum()

# In[None]

df.describe()

# In[None]

df['capital.gain'] = df['capital.gain'].replace(0,df['capital.gain'].mean())
df['capital.loss'] = df['capital.loss'].replace(0,df['capital.loss'].mean())

# In[None]

df.head()

# In[None]

#df['workclass']=df['workclass'].replace('?','undef')
df['occupation'] = df['occupation'].replace('?','occu')
df['native.country'] = df['native.country'].replace('?','country')

# In[None]

df["sex"] = df["sex"].map({"Male": 0, "Female":1})

# In[None]

g=sns.barplot(x='sex',y='income',data=df)
g=g.set_ylabel('income >50k')
plt.show()


# In[None]

# df.fillna(df.mean(),inplace=True)

df['workclass'].unique

# In[None]

df=df.drop(columns='workclass',axis=1)

# In[None]

from sklearn.preprocessing import StandardScaler , LabelEncoder ,OneHotEncoder
label = LabelEncoder()
df['marital.status'] = label.fit_transform(df['marital.status'])
df['race'] = label.fit_transform(df['race'])
df['sex'] = label.fit_transform(df['sex'])
df['education'] = label.fit_transform(df['education'])
#df['workclass'] = label.fit_transform(df['workclass'])
df['occupation'] = label.fit_transform(df['occupation'])
df['native.country'] = label.fit_transform(df['native.country'])
df['relationship'] = label.fit_transform(df['relationship'])
df['income'] = label.fit_transform(df['income'])

# In[None]

df['native.country'].unique()


# In[None]

df.columns

# In[None]

X = df.drop(columns='income')
y=df['income']


# In[None]

scaler = StandardScaler()
X_scaled=scaler.fit_transform(X)


# In[None]

fig,ax=plt.subplots(figsize=(25,15),facecolor='white')
sns.boxplot(data=df,ax=ax,width=0.5,fliersize=4)

# In[None]

q=df['fnlwgt'].quantile(0.80)
data_cleaned = df[df['fnlwgt']<q]
q=df['age'].quantile(0.99)
data_cleaned = df[df['age']<q]
q=df['education'].quantile(0.99)
data_cleaned = df[df['education']<q]
q=df['education.num'].quantile(0.99)
data_cleaned=df[df['education.num']<q]
q=df['capital.gain'].quantile(0.95)
data_cleaned=df[df['capital.gain']<q]
q=df['race'].quantile(0.99)
data_cleaned=df[df['race']<q]
q=df['capital.loss'].quantile(0.98)
data_cleaned=df[df['capital.loss']<q]
q=df['education.num'].quantile(0.99)
data_cleaned=df[df['education.num']<q]
q=df['native.country'].quantile(0.98)
data_cleaned=df[df['native.country']<q]
q=df['hours.per.week'].quantile(0.98)
data_cleaned=df[df['hours.per.week']<q]

# In[None]

df.plot()

# In[None]

sns.heatmap(df.corr())

# In[None]

y.unique

# In[None]

from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8813226.npy", { "accuracy_score": score })

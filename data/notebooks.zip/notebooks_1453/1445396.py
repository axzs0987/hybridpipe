import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# U# s# e#  # S# t# a# n# d# a# r# d# S# c# a# l# e# r#  # t# o#  # n# o# r# m# a# l# i# z# e#  # t# h# e#  # d# a# t# a# ,#  # a# n# d#  # S# G# D# C# l# a# s# s# i# f# i# e# r#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e# m#  # a# t#  # f# i# r# s# t# .

# In[None]

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import SGDClassifier

wine = pd.read_csv('../input/winequality-red.csv')
x = wine.drop('quality', axis = 1)
y = wine['quality']

# Split data to 'train' and 'test'
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1445396.npy", { "accuracy_score": score })

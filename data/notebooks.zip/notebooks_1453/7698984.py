import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
pd.set_option('display.max_rows', 30)

# ##  # D# a# t# a#  # C# l# e# a# n# i# n# g

# ## I# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # D# a# t# a# 
# C# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n# ,#  # a# l# s# o#  # k# n# o# w# n#  # a# s#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n# ,#  # c# u# s# t# o# m# e# r#  # t# u# r# n# o# v# e# r# ,#  # o# r#  # c# u# s# t# o# m# e# r#  # d# e# f# e# c# t# i# o# n# ,#  # i# s#  # t# h# e#  # l# o# s# s#  # o# f#  # c# l# i# e# n# t# s#  # o# r#  # c# u# s# t# o# m# e# r# s# .# 
# 
# T# e# l# e# p# h# o# n# e#  # s# e# r# v# i# c# e#  # c# o# m# p# a# n# i# e# s# ,#  # I# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r# s# ,#  # p# a# y#  # T# V#  # c# o# m# p# a# n# i# e# s# ,#  # i# n# s# u# r# a# n# c# e#  # f# i# r# m# s# ,#  # a# n# d#  # a# l# a# r# m#  # m# o# n# i# t# o# r# i# n# g#  # s# e# r# v# i# c# e# s# ,#  # o# f# t# e# n#  # u# s# e#  # c# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n#  # a# n# a# l# y# s# i# s#  # a# n# d#  # c# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n#  # r# a# t# e# s#  # a# s#  # o# n# e#  # o# f#  # t# h# e# i# r#  # k# e# y#  # b# u# s# i# n# e# s# s#  # m# e# t# r# i# c# s#  # b# e# c# a# u# s# e#  # t# h# e#  # c# o# s# t#  # o# f#  # r# e# t# a# i# n# i# n# g#  # a# n#  # e# x# i# s# t# i# n# g#  # c# u# s# t# o# m# e# r#  # i# s#  # f# a# r#  # l# e# s# s#  # t# h# a# n#  # a# c# q# u# i# r# i# n# g#  # a#  # n# e# w#  # o# n# e# .#  # C# o# m# p# a# n# i# e# s#  # f# r# o# m#  # t# h# e# s# e#  # s# e# c# t# o# r# s#  # o# f# t# e# n#  # h# a# v# e#  # c# u# s# t# o# m# e# r#  # s# e# r# v# i# c# e#  # b# r# a# n# c# h# e# s#  # w# h# i# c# h#  # a# t# t# e# m# p# t#  # t# o#  # w# i# n#  # b# a# c# k#  # d# e# f# e# c# t# i# n# g#  # c# l# i# e# n# t# s# ,#  # b# e# c# a# u# s# e#  # r# e# c# o# v# e# r# e# d#  # l# o# n# g# -# t# e# r# m#  # c# u# s# t# o# m# e# r# s#  # c# a# n#  # b# e#  # w# o# r# t# h#  # m# u# c# h#  # m# o# r# e#  # t# o#  # a#  # c# o# m# p# a# n# y#  # t# h# a# n#  # n# e# w# l# y#  # r# e# c# r# u# i# t# e# d#  # c# l# i# e# n# t# s# .# 
# 
# C# o# m# p# a# n# i# e# s#  # u# s# u# a# l# l# y#  # m# a# k# e#  # a#  # d# i# s# t# i# n# c# t# i# o# n#  # b# e# t# w# e# e# n#  # v# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # a# n# d#  # i# n# v# o# l# u# n# t# a# r# y#  # c# h# u# r# n# .#  # V# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # a#  # d# e# c# i# s# i# o# n#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r#  # t# o#  # s# w# i# t# c# h#  # t# o#  # a# n# o# t# h# e# r#  # c# o# m# p# a# n# y#  # o# r#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r# ,#  # i# n# v# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # c# i# r# c# u# m# s# t# a# n# c# e# s#  # s# u# c# h#  # a# s#  # a#  # c# u# s# t# o# m# e# r# '# s#  # r# e# l# o# c# a# t# i# o# n#  # t# o#  # a#  # l# o# n# g# -# t# e# r# m#  # c# a# r# e#  # f# a# c# i# l# i# t# y# ,#  # d# e# a# t# h# ,#  # o# r#  # t# h# e#  # r# e# l# o# c# a# t# i# o# n#  # t# o#  # a#  # d# i# s# t# a# n# t#  # l# o# c# a# t# i# o# n# .#  # I# n#  # m# o# s# t#  # a# p# p# l# i# c# a# t# i# o# n# s# ,#  # i# n# v# o# l# u# n# t# a# r# y#  # r# e# a# s# o# n# s#  # f# o# r#  # c# h# u# r# n#  # a# r# e#  # e# x# c# l# u# d# e# d#  # f# r# o# m#  # t# h# e#  # a# n# a# l# y# t# i# c# a# l#  # m# o# d# e# l# s# .#  # A# n# a# l# y# s# t# s#  # t# e# n# d#  # t# o#  # c# o# n# c# e# n# t# r# a# t# e#  # o# n#  # v# o# l# u# n# t# a# r# y#  # c# h# u# r# n# ,#  # b# e# c# a# u# s# e#  # i# t#  # t# y# p# i# c# a# l# l# y#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # f# a# c# t# o# r# s#  # o# f#  # t# h# e#  # c# o# m# p# a# n# y# -# c# u# s# t# o# m# e# r#  # r# e# l# a# t# i# o# n# s# h# i# p#  # w# h# i# c# h#  # c# o# m# p# a# n# i# e# s#  # c# o# n# t# r# o# l# ,#  # s# u# c# h#  # a# s#  # h# o# w#  # b# i# l# l# i# n# g#  # i# n# t# e# r# a# c# t# i# o# n# s#  # a# r# e#  # h# a# n# d# l# e# d#  # o# r#  # h# o# w#  # a# f# t# e# r# -# s# a# l# e# s#  # h# e# l# p#  # i# s#  # p# r# o# v# i# d# e# d# .# 
# 
# p# r# e# d# i# c# t# i# v# e#  # a# n# a# l# y# t# i# c# s#  # u# s# e#  # c# h# u# r# n#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l# s#  # t# h# a# t#  # p# r# e# d# i# c# t#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n#  # b# y#  # a# s# s# e# s# s# i# n# g#  # t# h# e# i# r#  # p# r# o# p# e# n# s# i# t# y#  # o# f#  # r# i# s# k#  # t# o#  # c# h# u# r# n# .#  # S# i# n# c# e#  # t# h# e# s# e#  # m# o# d# e# l# s#  # g# e# n# e# r# a# t# e#  # a#  # s# m# a# l# l#  # p# r# i# o# r# i# t# i# z# e# d#  # l# i# s# t#  # o# f#  # p# o# t# e# n# t# i# a# l#  # d# e# f# e# c# t# o# r# s# ,#  # t# h# e# y#  # a# r# e#  # e# f# f# e# c# t# i# v# e#  # a# t#  # f# o# c# u# s# i# n# g#  # c# u# s# t# o# m# e# r#  # r# e# t# e# n# t# i# o# n#  # m# a# r# k# e# t# i# n# g#  # p# r# o# g# r# a# m# s#  # o# n#  # t# h# e#  # s# u# b# s# e# t#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r#  # b# a# s# e#  # w# h# o#  # a# r# e#  # m# o# s# t#  # v# u# l# n# e# r# a# b# l# e#  # t# o#  # c# h# u# r# n# .# 
# 
# O# n# l# y#  # 7# 0# 4# 3#  # r# o# w# s# 
# T# h# e# r# e#  # a# r# e#  # 2# 1#  # c# o# l# u# m# n# s#  # w# i# t# h#  # 1# 9#  # f# e# a# t# u# r# e# s# 
# O# n# l# y#  # 1# 1#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .

# In[None]

raw_data = pd.read_csv('/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv')
raw_data.head()

# In[None]

print ('Rows:', raw_data.shape[0])
print ('Columns:', raw_data.shape[1])
print ('Missing Values:',raw_data.isnull().sum().values.sum())
print ('Numerical Columns:', raw_data.describe().columns.values.shape[0])
print ('Categorical Columns:', raw_data.shape[1] - raw_data.describe().columns.values.shape[0])
print ('Unique Values:\n', raw_data.nunique())

# In[None]


#Display all columns
##Type of Total Charges is String, Converting to int after converting null values from TotalCharges to numpy null

type(raw_data['TotalCharges'][0])
raw_data['TotalCharges'] = raw_data['TotalCharges'].replace(' ', np.NaN)
raw_data['TotalCharges'] = raw_data['TotalCharges'].astype(float)

#Dropping null rows from total charges
raw_data = raw_data.dropna()

raw_data = raw_data.reset_index(drop=True)


# In[None]


categorical_columns_with_2_categories = [ 'gender', 'SeniorCitizen', 'Partner', 'Dependents',
        'PhoneService','PaperlessBilling']

categorical_columns_with_3_categories = [  'MultipleLines', 'InternetService',
       'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
       'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract']

categorical_columns_with_4_categories=['PaymentMethod']

###Below code used to  check what are the categories, and whether we need to modify some of them or not
print('2 categories:')
for i in categorical_columns_with_2_categories:
    print( i , raw_data[i].unique(),'\n')

print('\n3 categories:')
for i in categorical_columns_with_3_categories:
    print( i , raw_data[i].unique(),'\n')   

print('\n4 categories:')
for i in categorical_columns_with_4_categories:
    print( i , raw_data[i].unique(),'\n')     



# In[None]

print('Checking if there are any null rows in Categorical columns\nActual rows:', raw_data.shape[0])
for i in categorical_columns_with_2_categories:
    print('Not null rows in ', i ,':',raw_data[i][raw_data[i]==raw_data[i].unique()[0]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[1]].count())

for i in categorical_columns_with_3_categories:
    print('Not null rows in ', i ,':',raw_data[i][raw_data[i]==raw_data[i].unique()[0]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[1]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[2]].count())

for i in categorical_columns_with_4_categories:
    print('Not null rows in ', i ,':',raw_data[i][raw_data[i]==raw_data[i].unique()[0]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[1]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[2]].count() + raw_data[i][raw_data[i]==raw_data[i].unique()[3]].count())
    

# ## C# r# e# a# t# i# n# g#  # C# h# e# c# k# p# o# i# n# t

# In[None]

raw_data_1 = raw_data.copy()

# In[None]

raw_data_1 = raw_data.drop('customerID',axis =1)

# In[None]

#Replacing 'No internet service' with 'No'
columns_1 = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
       'TechSupport', 'StreamingTV', 'StreamingMovies']

for i in columns_1:
       raw_data_1[i]=raw_data_1[i].replace('No internet service','No')

columns_2 = ['MultipleLines']
for i in columns_2:
       raw_data_1[i]=raw_data_1[i].replace('No phone service','No')
        
columns_3 = ['Churn']
for i in columns_3:
    raw_data_1[i]=raw_data_1[i].replace('Yes',1)
    raw_data_1[i]=raw_data_1[i].replace('No',0)

# In[None]



##Confirming whether replacement was successfull or not
for i in categorical_columns_with_3_categories:
    print( i , raw_data_1[i].unique(),'\n') 

# In[None]

##When we look at tenure, total unique values are 72 in record of 7032, so it is a categorical number hidden under numbers, if taken as quantitatively it will distrub our model
##As there are 72 unique values in tenure, so we can not create each column of OHE for tenure, so we will create groups based on tenure and later create OHE based on those groups.
##using Sorted function to check whether there are any missing values
#sorted(raw_data_1['tenure'].unique())

# ##  #  # E# x# p# l# o# r# a# t# i# o# n#  # o# f#  # D# a# t# a

# In[None]

temp_c = ['SeniorCitizen']
##Creating Categories for Senior Citizen under YES and NO it will make extraction of dummies easier later on
for i in temp_c:
    raw_data_1[i]=raw_data_1[i].replace(1,'Yes')
    raw_data_1[i]=raw_data_1[i].replace(0,'No')

# In[None]

raw_data_1.head()
numerical_features=['MonthlyCharges','TotalCharges','tenure']
categorical_features = [
 'gender',
 'SeniorCitizen',
 'Partner',
 'Dependents',
 'PhoneService',
 'MultipleLines',
 'InternetService',
 'OnlineSecurity',
 'OnlineBackup',
 'DeviceProtection',
 'TechSupport',
 'StreamingTV',
 'StreamingMovies',
 'Contract',
 'PaperlessBilling',
 'PaymentMethod',
]


# In[None]

#Creating Checkpoint
raw_data_2 = raw_data_1.copy()

# ## C# u# s# t# o# m# e# r#  # A# t# t# r# i# t# i# o# n

# In[None]

temp =raw_data_2.groupby(['Churn']).count()['gender']
p2 = raw_data_2['Churn'].value_counts().values

# In[None]

fig1, ax1= plt.subplots(1)
explode = (0.2,0)

labels = ['No','Yes']

#p2 = [temp[0],temp[1]]
ax1.set_title('Customer Churn in Data ')
ax1.pie(p2, explode=explode, autopct='%1.1f%%',
        shadow=True,labels=labels, startangle=90)


plt.tight_layout()
plt.show()


# ## C# u# s# t# o# m# e# r#  # A# t# t# r# i# t# i# o# n#  # A# c# c# o# r# d# i# n# g#  # t# o#  # D# i# f# f# e# r# e# n# t#  # c# a# t# e# g# o# r# i# e# s

# In[None]

def non_churn(cat_col):
    temp = raw_data_2.groupby(['Churn',cat_col])['Churn'].count()
    return temp[0]
def churn(cat_col):
    temp = raw_data_2.groupby(['Churn',cat_col])['Churn'].count()
    return temp[1]

def pie_cat(cat_col,explode=(0.2,0)):
    p2= non_churn(cat_col)
    p3 = churn(cat_col)
    fig1,(ax2,ax3) = plt.subplots(1,2,figsize=(10,10))

    labels = raw_data_2[cat_col].unique()
    ax3.pie(p3, explode=explode, autopct='%1.1f%%',
        shadow=True,labels=labels, startangle=90)
    ax2.pie(p2,  autopct='%1.1f%%',
        shadow=True,labels=labels, startangle=90)
    ax2.set_title('Non Churn customers')
    ax3.set_title(' Churn customers')
    plt.suptitle('Churn Distribution in '+ cat_col,fontsize='15')
    plt.tight_layout()
    plt.show()


# In[None]

#for i in range(16):
#    pie_cat(categorical_features[i])
ex = (0.1,0.1,0.1)

pie_cat(categorical_features[0])
#pie_cat(categorical_features[1])
#pie_cat(categorical_features[2])

# In[None]

#pie_cat(categorical_features[3])
#pie_cat(categorical_features[4])
#pie_cat(categorical_features[5])

# In[None]

ex = (0.1,0.1,0.1)

pie_cat(categorical_features[6],ex)
#pie_cat(categorical_features[7])
#pie_cat(categorical_features[8])

# In[None]

pie_cat(categorical_features[9])
#pie_cat(categorical_features[10])
#pie_cat(categorical_features[11])


# In[None]

ex = (0.1,0.1,0.1)
#pie_cat(categorical_features[12])
pie_cat(categorical_features[13],ex)
#pie_cat(categorical_features[14])

# In[None]

ex = (0.1,0.1,0.1,0.1)
pie_cat(categorical_features[15],ex)

# In[None]

raw_data_3 = raw_data_2.copy()
def tenure_lab(raw_data_3) :
    
    if raw_data_3["tenure"] <= 12 :
        return "Tenure_0-12"
    elif (raw_data_3["tenure"] > 12) & (raw_data_3["tenure"] <= 24 ):
        return "Tenure_12-24"
    elif (raw_data_3["tenure"] > 24) & (raw_data_3["tenure"] <= 48) :
        return "Tenure_24-48"
    elif (raw_data_3["tenure"] > 48) & (raw_data_3["tenure"] <= 60) :
        return "Tenure_48-60"
    elif raw_data_3["tenure"] > 60 :
        return "Tenure_gt_60"
    
raw_data_3['tenure'] = raw_data_2.apply(lambda raw_data_2:tenure_lab(raw_data_2),axis = 1)


# In[None]

def tenure_non_churn(cat_col):
    temp = raw_data_3.groupby(['Churn',cat_col])['Churn'].count()
    return temp[0]
def tenure_churn(cat_col):
    temp = raw_data_3.groupby(['Churn',cat_col])['Churn'].count()
    return temp[1]

def tenure_pie_cat(cat_col,explode=(0.1,0.1,0.1,0.1,0.1)):
    p2= tenure_non_churn(cat_col)
    p3 = tenure_churn(cat_col)
    fig1,(ax2,ax3) = plt.subplots(1,2,figsize=(10,10))

    labels = raw_data_3[cat_col].unique()
    ax3.pie(p3, autopct='%1.1f%%',
        shadow=True,explode=explode,labels=labels, startangle=90)
    ax2.pie(p2,  autopct='%1.1f%%',
        shadow=True,labels=labels,startangle=90)
    ax2.set_title('Non Churn customers')
    ax3.set_title(' Churn customers')
    plt.suptitle('Churn Distribution in '+ cat_col,fontsize='15')
    plt.tight_layout()
    plt.show()


# In[None]

tenure_pie_cat('tenure')


# ##  # C# u# s# t# o# m# e# r#  # A# t# t# r# i# t# i# o# n#  # A# c# c# o# r# d# i# n# g#  # t# o#  # C# h# a# r# g# e# s#  # a# n# d#  # t# e# n# u# r# e

# In[None]

fig,(ax1,ax2,ax3) = plt.subplots(1,3,figsize=(18,7))

sns.distplot(raw_data_2[raw_data_2.Churn==0]['TotalCharges']
             ,bins=30,kde=False,color='Green',ax=ax1,label=['Not Churn'])
sns.distplot(raw_data_2[raw_data_2.Churn==1]['TotalCharges']
             ,bins=30,kde=False,color='Black',ax=ax1,label=['Churned'])

sns.distplot(raw_data_2[raw_data_2.Churn==0]['MonthlyCharges']
             ,bins=30,kde=False,color='Green',ax=ax2,label=['Not Churn'])
sns.distplot(raw_data_2[raw_data_2.Churn==1]['MonthlyCharges']
             ,bins=30,kde=False,color='Black',ax=ax2,label=['Churned'])

sns.distplot(raw_data_2[raw_data_2.Churn==0]['tenure']
             ,bins=30,kde=False,color='Green',ax=ax3,label=['Not Churn'])
sns.distplot(raw_data_2[raw_data_2.Churn==1]['tenure']
             ,bins=30,kde=False,color='Black',ax=ax3,label=['Churned'])
plt.legend()

# ##  # R# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # N# u# m# e# r# i# c# a# l#  # V# a# r# i# a# b# l# e# s

# In[None]



# In[None]

fig,(ax1,ax2,ax3) = plt.subplots(1,3,figsize=(18,7))
sns.scatterplot(raw_data_2['TotalCharges'],
                raw_data_2['tenure'],color='Black',ax=ax1,hue=raw_data_2['Churn'])
sns.scatterplot(raw_data_2['MonthlyCharges'],
                raw_data_2['tenure'],color='Black',ax=ax2,hue=raw_data_2['Churn'])
sns.scatterplot(raw_data_2['MonthlyCharges'],
                raw_data_2['TotalCharges'],color='Black',ax=ax3,hue=raw_data_2['Churn'])

# In[None]

#fig,(ax1,ax2,ax3) = plt.subplots(1,3,figsize=(18,7))
#sns.scatterplot(raw_data_2[raw_data_2.Churn==1]['TotalCharges'],
#                raw_data_2[raw_data_2.Churn==1]['tenure'],color='Black',ax=ax1)
#sns.scatterplot(raw_data_2[raw_data_2.Churn==1]['MonthlyCharges'],
#                raw_data_2[raw_data_2.Churn==1]['tenure'],color='Black',ax=ax2)
#sns.scatterplot(raw_data_2[raw_data_2.Churn==1]['MonthlyCharges'],
#                raw_data_2[raw_data_2.Churn==1]['TotalCharges'],color='Black',ax=ax3)

# In[None]

plt.figsize=(200,10)
plt.xticks(rotation=90)
sns.countplot(raw_data_3['tenure'],hue=raw_data_3['Churn'])
plt.show()


# In[None]

#sns.scatterplot(raw_data_3[raw_data_3.Churn==1]['MonthlyCharges'],
 #               raw_data_3[raw_data_3.Churn==1]['TotalCharges'],color='Black',hue=raw_data_3['tenure'])

# In[None]

plt.xticks(rotation=90)
sns.boxplot( raw_data_3['tenure'],raw_data_3['TotalCharges'],color='Orange',hue=raw_data_3['Churn'])

# In[None]



# In[None]

plt.xticks(rotation=90)
sns.boxplot( raw_data_3['tenure'],raw_data_3['MonthlyCharges'],color='Orange',hue=raw_data_3['Churn'])

# In[None]

plt.xticks(rotation=90)
sns.barplot(raw_data_3['tenure'],
            raw_data_3['MonthlyCharges'],hue=raw_data_3['Churn'],
            estimator=np.mean).set_title('Average Distribution of Monthly Charges According to Tenure')
plt.show()

# In[None]

plt.xticks(rotation=90)
sns.barplot(raw_data_3['tenure']
            ,raw_data_3['TotalCharges'],hue=raw_data_3['Churn'],
            estimator=np.median).set_title('Average Distribution of Total Charges According to Tenure')
plt.show()

# In[None]

import plotly.offline as py#visualization
py.init_notebook_mode(connected=True)#visualization
import plotly.graph_objs as go#visualization
import plotly.tools as tls#visualization
import plotly.figure_factory as ff#visualization



trace1 = go.Scatter3d(x = raw_data_2[raw_data_2.Churn==1]["MonthlyCharges"],
                      y = raw_data_2[raw_data_2.Churn==1]["TotalCharges"],
                      z = raw_data_2[raw_data_2.Churn==1]["tenure"],
                      mode = "markers",
                      name = "Churn customers",
                      
                      marker = dict(size = 1,color = "red")
                     )


layout = go.Layout(dict(title = "Monthly charges,total charges & tenure in customer attrition",
                        scene = dict(camera = dict(up=dict(x= 0 , y=0, z=0),
                                                   center=dict(x=0, y=0, z=0),
                                                   eye=dict(x=1.25, y=1.25, z=1.25)),
                                     xaxis  = dict(title = "monthly charges(x)",
                                                   gridcolor='rgb(255, 255, 255)',
                                                   zerolinecolor='rgb(255, 255, 255)',
                                                   showbackground=True,
                                                   backgroundcolor='rgb(230, 230,230)'),
                                     yaxis  = dict(title = "total charges(y)",
                                                   gridcolor='rgb(255, 255, 255)',
                                                   zerolinecolor='rgb(255, 255, 255)',
                                                   showbackground=True,
                                                   backgroundcolor='rgb(230, 230,230)'
                                                  ),
                                     zaxis  = dict(title = "tenure(z)",
                                                   gridcolor='rgb(255, 255, 255)',
                                                   zerolinecolor='rgb(255, 255, 255)',
                                                   showbackground=True,
                                                   backgroundcolor='rgb(230, 230,230)'
                                                  )
                                    ),
                        height = 700,
                       )
                  )
                  

data = trace1
fig  = go.Figure(data = data,layout = layout)
py.iplot(fig)

# ##  # D# a# t# a#  # P# r# e# -# p# r# o# c# e# s# s# i# n# g

# In[None]

#Creating Checkpoint
raw_data_4 = raw_data_2.copy()

# ## ## ## C# r# e# a# t# i# n# g#  # C# a# t# e# g# o# r# i# e# s#  # f# o# r#  # T# e# n# u# r# e# ,#  # c# o# d# e#  # i# s#  # c# o# u# r# t# e# s# y#  # o# f#  # P# a# v# a# n#  # R# a# j# 


# In[None]

input = raw_data_4.drop('Churn',axis=1)
target = raw_data_4['Churn']
input = pd.get_dummies(input,drop_first=True)

# In[None]

fig,ax = plt.subplots(figsize=(20,20))
sns.heatmap(input.corr(),cmap='coolwarm').set_title('Correlatiion Matrix')
plt.show()

# In[None]

from sklearn.preprocessing import StandardScaler
num_cols=['MonthlyCharges','TotalCharges','tenure']
std = StandardScaler()
scaled = std.fit_transform(input[num_cols])
scaled = pd.DataFrame(scaled,columns=num_cols)
input_2 = input.drop('MonthlyCharges',axis =1)
input_2 = input_2.drop('TotalCharges',axis =1)
input_2 = input_2.drop('tenure',axis =1)
scaled_input = pd.merge(scaled, input_2, left_index=True, right_index=True)


# In[None]

scaled_input.head()

# B# u# i# l# d# i# n# g#  # a#  # M# o# d# e# l

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,accuracy_score,classification_report
from sklearn.metrics import roc_auc_score,roc_curve,scorer
from sklearn.metrics import f1_score
import statsmodels.api as sm
from sklearn.metrics import precision_score,recall_score
#from yellowbrick.classifier import DiscriminationThreshold
from sklearn.feature_selection import f_regression
from sklearn.feature_selection import chi2

# In[None]

score, pvalue = chi2(input,target)

# In[None]

#pvalue.round(3)

# In[None]

#reg_summary['P Values'] = pvalue.round(3)

# In[None]



# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(scaled_input, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7698984.npy", { "accuracy_score": score })

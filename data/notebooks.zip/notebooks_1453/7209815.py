import pandas as pd
# In[None]

# libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# In[None]

# read csv
data = pd.read_csv("../input/voicegender/voice.csv")
print(data.info())

# In[None]

#get first five rows
data.head()

# In[None]

# learn data's columns
data.columns

# In[None]

# get information abaut data
data.info()

# In[None]

# set label column for logistic regression 
data.label = [1 if each == "male" else 0 for each in data.label]

# In[None]

# get y and x_data
y=data.label.values
x_data = data.drop(["label"],axis=1)

# In[None]

# normalization with x_data
x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data)).values

# In[None]

# train test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7209815.npy", { "accuracy_score": score })

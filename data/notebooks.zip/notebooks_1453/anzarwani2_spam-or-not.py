import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
path = '../input/spambase/spambase_csv.csv'
df = pd.read_csv(path)
df
X = df.iloc[:,:-1].values
y = df.iloc[:,57].values
print(X)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#sns.heatmap(df.corr())
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
#logreg.fit(x_train, y_train)
#pred = logreg.predict(x_test)
#score = logreg.score(x_test,y_test)
#print(score)
from sklearn import metrics
#cm = metrics.confusion_matrix(y_test, pred)
#plt.figure(figsize = (9,9))
#sns.heatmap(cm, annot = True, fmt = ".3f", linewidths= .5, square = True, cmap = 'Blues_r')
#plt.ylabel('actual')
#plt.xlabel('predicted')
#all_sample_title = 'accuracy score : {0}'. format(score)
#plt.title(all_sample_title, size  = 15)
#print(pred)
#my_submission = pd.DataFrame({'chance': pred})
#my_submission.to_csv('submission.csv', index=False)
#my_submission



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anzarwani2_spam-or-not.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/anzarwani2_spam-or-not/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/anzarwani2_spam-or-not/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/anzarwani2_spam-or-not/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/anzarwani2_spam-or-not/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/anzarwani2_spam-or-not/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/anzarwani2_spam-or-not/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anzarwani2_spam-or-not/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anzarwani2_spam-or-not/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anzarwani2_spam-or-not/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anzarwani2_spam-or-not/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anzarwani2_spam-or-not/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anzarwani2_spam-or-not/testY.csv",encoding="gbk")


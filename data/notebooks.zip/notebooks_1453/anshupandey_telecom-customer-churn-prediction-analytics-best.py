import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import seaborn as sns 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df = pd.read_csv(os.path.join(dirname, filename))
df.shape
df.head()
df.info()
print(df['international plan'].unique())
print(df['voice mail plan'].unique())
df.describe(include='all')
df.isnull().sum()
df.duplicated().sum()
df.skew()
df['number vmail messages'].describe()
df['number vmail messages'][df['number vmail messages']>0].describe()
                
                
                
df['vmail_messages'] = pd.cut(df['number vmail messages'],bins=[0,1,38,52],                             labels=['No VM plan','Normal Users','High Frequency users'],                             include_lowest=True)
df.head(20)
cor = df.corr()
#plt.figure(figsize=(15,10))
#sns.heatmap(cor.round(3),annot=True,cmap='coolwarm')
#plt.show()
df.columns
numerics =['account length','number vmail messages',       'total day minutes', 'total day calls', 'total day charge',       'total eve minutes', 'total eve calls', 'total eve charge',       'total night minutes', 'total night calls', 'total night charge',       'total intl minutes', 'total intl calls', 'total intl charge',       'customer service calls']
xnum = df[numerics]
y = df['churn']
from sklearn.feature_selection import f_classif
fval,pval = f_classif(xnum,y)
for i in range(len(numerics)):print(numerics[i],pval[i])
categories = ['state','area code','phone number', 'international plan',       'voice mail plan','vmail_messages']
y = df['churn']
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import chi2
for col in categories:
    xcat = LabelEncoder().fit_transform(df[col]).reshape(-1,1)
    cval,pval = chi2(xcat,y)
    print(col,pval)
x = df[['international plan','vmail_messages','total day minutes','total eve minutes',     'total night minutes','total intl minutes','customer service calls']]
y = df['churn']
x.head()
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder,OrdinalEncoder,StandardScaler
preprocessor = ColumnTransformer([('ohe',OneHotEncoder(),[1]),                                ('ode',OrdinalEncoder(),[0]),                                 ('sc',StandardScaler(),[2,3,4,5,6])],remainder='passthrough')
x_new = preprocessor.fit_transform(x)
pd.DataFrame(x_new).head()
from sklearn.model_selection import train_test_split
xtrain,xtest,ytrain,ytest = train_test_split(x_new,y,test_size=0.2,random_state=5)
print(x.shape)
print(xtrain.shape)
print(xtest.shape)
print(y.shape)
print(ytrain.shape)
print(ytest.shape)
from sklearn.linear_model import LogisticRegression
model = LogisticRegression(class_weight='balanced')
#model.fit(xtrain,ytrain)
from sklearn import metrics
#ypred = model.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred))
#print("Recall : ",metrics.recall_score(ytest,ypred))
#print("F1 score : ",metrics.f1_score(ytest,ypred))
#print("Precision : ",metrics.precision_score(ytest,ypred))
#ypred2 = model.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder,OrdinalEncoder,StandardScaler
preprocessor = ColumnTransformer([('ohe',OneHotEncoder(),[1]),                                ('ode',OrdinalEncoder(),[0])],                                remainder="passthrough")
x_new = preprocessor.fit_transform(x)
pd.DataFrame(x_new)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x_new, y, train_size=0.8, test_size=1-0.8, random_state=0)
print(x.shape)
print(xtrain.shape)
print(xtest.shape)
print(y.shape)
print(ytrain.shape)
print(ytest.shape)
from sklearn.tree import DecisionTreeClassifier
model2 = DecisionTreeClassifier(random_state=5,class_weight={0:0.5,1:0.5})
#model2.fit(xtrain,ytrain)
import graphviz
from sklearn import tree
fname = ['International plan', 'vmail_NO_Plan','vmail_Normal','vmail_HF', 'Total day minutes',       'Total eve minutes', 'Total night minutes', 'Total intl minutes',       'Customer service calls']
cname = ['Not Leaving','Leaving']
#graphdata = tree.export_graphviz(model2,feature_names=fname,class_names=cname,                                filled=True,rounded=True)
#graph = graphviz.Source(graphdata)
#graph
#ypred2 = model2.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model2.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
param_grid = {"max_depth":np.arange(3,25,2),              "min_samples_leaf":np.arange(3,50,2),              "min_samples_split":np.arange(10,120,5)}
from sklearn.model_selection import GridSearchCV
grid_search = GridSearchCV(DecisionTreeClassifier(random_state=5),                          param_grid=param_grid,n_jobs=-1,                          scoring='recall',verbose=True,cv=5)
#grid_search.fit(x_new,y)
#print(grid_search.best_score_)
#print(grid_search.best_params_)
model2 = DecisionTreeClassifier(criterion='gini',random_state=5,                               max_depth=8,min_samples_leaf=5,min_samples_split=20)
#model2.fit(xtrain,ytrain)
#ypred2 = model2.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model2.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
#model2.feature_importances_
#for i in range(len(fname)):print(fname[i],model2.feature_importances_[i])
from sklearn.ensemble import RandomForestClassifier
model4 = RandomForestClassifier(n_estimators=100,random_state=5,                               max_depth=8,oob_score=True)
#model4.fit(xtrain,ytrain)
#ypred2 = model4.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model4.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
#model4.oob_score_
from sklearn.ensemble import AdaBoostClassifier
model5 = AdaBoostClassifier(n_estimators=120,random_state=5,learning_rate=0.2)
#model5.fit(xtrain,ytrain)
#ypred2 = model5.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model5.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
from sklearn.ensemble import GradientBoostingClassifier
model6 = GradientBoostingClassifier(learning_rate=0.1,n_estimators=150,random_state=5)
#model6.fit(xtrain,ytrain)
#ypred2 = model6.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model6.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
from xgboost import XGBClassifier
model7 = XGBClassifier(learning_rate=0.005,n_estimators=120,max_depth=8)
#model7.fit(xtrain,ytrain)
#ypred2 = model7.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model7.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))
from mlxtend.classifier import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier,GradientBoostingClassifier
log_model = LogisticRegression()
dt_model = DecisionTreeClassifier(random_state=5,max_depth=10)
rf_model = RandomForestClassifier(n_estimators=100,random_state=5,max_depth=10)
gb_model = GradientBoostingClassifier(learning_rate=0.01,n_estimators=120,random_state=5)
model8 = StackingClassifier(classifiers=[dt_model,rf_model,gb_model],                           meta_classifier=log_model)
#model8.fit(xtrain,ytrain)
#ypred2 = model8.predict(xtest)
#print("Accuracy : ",metrics.accuracy_score(ytest,ypred2))
#print("Recall : ",metrics.recall_score(ytest,ypred2))
#print("F1 score : ",metrics.f1_score(ytest,ypred2))
#print("Precision : ",metrics.precision_score(ytest,ypred2))
#ypred2 = model8.predict(xtrain)
#print("Accuracy : ",metrics.accuracy_score(ytrain,ypred2))
#print("Recall : ",metrics.recall_score(ytrain,ypred2))
#print("F1 score : ",metrics.f1_score(ytrain,ypred2))
#print("Precision : ",metrics.precision_score(ytrain,ypred2))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anshupandey_telecom-customer-churn-prediction-analytics-best.npy", { "accuracy_score": score })
import pandas as pd
if type(xtrain).__name__ == "ndarray":
    np.save("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainX.npy", xtrain)
if type(xtrain).__name__ == "Series":
    xtrain.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainX.csv",encoding="gbk")
if type(xtrain).__name__ == "DataFrame":
    xtrain.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainX.csv",encoding="gbk")

if type(xtest).__name__ == "ndarray":
    np.save("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testX.npy", xtest)
if type(xtest).__name__ == "Series":
    xtest.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testX.csv",encoding="gbk")
if type(xtest).__name__ == "DataFrame":
    xtest.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testX.csv",encoding="gbk")

if type(ytrain).__name__ == "ndarray":
    np.save("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainY.npy", ytrain)
if type(ytrain).__name__ == "Series":
    ytrain.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainY.csv",encoding="gbk")
if type(ytrain).__name__ == "DataFrame":
    ytrain.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/trainY.csv",encoding="gbk")

if type(ytest).__name__ == "ndarray":
    np.save("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testY.npy", ytest)
if type(ytest).__name__ == "Series":
    ytest.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testY.csv",encoding="gbk")
if type(ytest).__name__ == "DataFrame":
    ytest.to_csv("hi_res_data/anshupandey_telecom-customer-churn-prediction-analytics-best/testY.csv",encoding="gbk")


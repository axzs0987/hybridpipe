import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
import pandas as pd
import  numpy as np
df=pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")
df.shape
df.head(5)
df.info()
def missing_data():
    total = df.isnull().sum().sort_values(ascending=False)
    percent = 100 * (df.isnull().sum()/df.isnull().count()).sort_values(ascending=False)
    missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
    return  missing_data
missing_data = missing_data()
missing_data.head(100)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
#plt.figure(figsize = (20,10))        
#sns.heatmap(df.corr(),annot = True)
#plt.show()
df['BusinessTravel'].astype('category').value_counts()
df['Department'].astype('category').value_counts()
df['Over18'].astype('category').value_counts()
df['MaritalStatus'].astype('category').value_counts()
df['OverTime'].astype('category').value_counts()
varlist =  ['Attrition','OverTime']
def binary_map(x):
    return x.map({'Yes': 1, "No": 0})
df[varlist] = df[varlist].apply(binary_map)
df.head()
varlist =  ['Over18']
def binary_map(x):
    return x.map({'Y': 1, "N": 0})
df[varlist] = df[varlist].apply(binary_map)
df.head()
varlist =  ['Gender']
def binary_map(x):
    return x.map({'Male': 1, "Female": 0})
df[varlist] = df[varlist].apply(binary_map)
df.head()
#plt.figure(figsize = (20,10))        
#sns.heatmap(df.corr(),annot = True)
#plt.show()
def missing_data():
    total = df.isnull().sum().sort_values(ascending=False)
    percent = 100 * (df.isnull().sum()/df.isnull().count()).sort_values(ascending=False)
    missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
    return  missing_data
missing_data = missing_data()
missing_data.head(100)
non_numeric = df.select_dtypes(['object'])
df[non_numeric.columns] = non_numeric.apply(lambda x: x.str.strip())
df[non_numeric.columns] = non_numeric.apply(lambda x: x.str.upper())
dummies = pd.get_dummies(non_numeric, drop_first=True)
dummies.head()
non_numeric.columns
df=df.drop(list(non_numeric.columns), axis=1)
df.head()
df_final= pd.concat([df,dummies], axis=1)
df_final.head()
df_final.shape
cor_mat= df_final[:].corr()
cor=cor_mat.sort_values(['Attrition'],ascending=False)
print("The most correlated/important features (numeric) for the target are :")
cor.Attrition
df_final.head()
def missing_data():
    total = df_final.isnull().sum().sort_values(ascending=False)
    percent = 100 * (df_final.isnull().sum()/df_final.isnull().count()).sort_values(ascending=False)
    missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
    return  missing_data
missing_data = missing_data()
missing_data.head(100)
#sns.countplot(x='Attrition',data=df_final)
Attrition_total = df_final[df_final['Attrition']==1]
print(len(Attrition_total))
print(len(df_final[df_final['Attrition']==0]))
from sklearn.preprocessing import scale
X=pd.DataFrame(scale(df_final.drop(['Attrition'],axis=1)))
y = df_final['Attrition']
X.columns=df_final.drop('Attrition',axis=1).columns
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import classification_report,confusion_matrix,roc_curve,auc,precision_score, recall_score, f1_score
X_train.info()
import statsmodels.api as sm
logm1 = sm.GLM(y_train,(sm.add_constant(X_train)), family = sm.families.Binomial())
logm1.fit().summary()
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
from sklearn.feature_selection import RFE
rfe = RFE(logreg, 15)             
rfe = rfe.fit(X_train, y_train)
rfe.support_
list(zip(X_train.columns, rfe.support_, rfe.ranking_))
col = X_train.columns[rfe.support_]
X_train.columns[~rfe.support_]
X_train_sm = sm.add_constant(X_train[col])
logm2 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm2.fit()
res.summary()
y_train_pred = res.predict(X_train_sm)
y_train_pred[:10]
y_train_pred = y_train_pred.values.reshape(-1)
y_train_pred[:10]
y_train_pred_final = pd.DataFrame({'Attrition':y_train.values, 'Attrition_Prob':y_train_pred})
y_train_pred_final['EmployeeNumber'] = y_train.index
y_train_pred_final.head()
y_train_pred_final['predicted'] = y_train_pred_final.Attrition_Prob.map(lambda x: 1 if x > 0.5 else 0)
y_train_pred_final.head()
from sklearn import metrics
confusion = metrics.confusion_matrix(y_train_pred_final.Attrition, y_train_pred_final.predicted )
print(confusion)
 
print(metrics.accuracy_score(y_train_pred_final.Attrition, y_train_pred_final.predicted))
from statsmodels.stats.outliers_influence import variance_inflation_factor
vif = pd.DataFrame()
vif['Features'] = X_train[col].columns
vif['VIF'] = [variance_inflation_factor(X_train[col].values, i) for i in range(X_train[col].shape[1])]
vif['VIF'] = round(vif['VIF'], 2)
vif = vif.sort_values(by = "VIF", ascending = False)
vif
TP = confusion[1,1] 
TN = confusion[0,0] 
FP = confusion[0,1] 
FN = confusion[1,0] 
TP / float(TP+FN)
TN / float(TN+FP)
print(FP/ float(TN+FP))
print (TP / float(TP+FP))
print (TN / float(TN+ FN))
def draw_roc( actual, probs ):
    fpr, tpr, thresholds = metrics.roc_curve( actual, probs,                                              drop_intermediate = False )
    auc_score = metrics.roc_auc_score( actual, probs )
#    plt.figure(figsize=(5, 5))
#    plt.plot( fpr, tpr, label='ROC curve (area = %0.2f)' % auc_score )
#    plt.plot([0, 1], [0, 1], 'k--')
#    plt.xlim([0.0, 1.0])
#    plt.ylim([0.0, 1.05])
#    plt.xlabel('False Positive Rate or [1 - True Negative Rate]')
#    plt.ylabel('True Positive Rate')
#    plt.title('Receiver operating characteristic example')
#    plt.legend(loc="lower right")
#    plt.show()
    return None
fpr, tpr, thresholds = metrics.roc_curve( y_train_pred_final.Attrition, y_train_pred_final.Attrition_Prob, drop_intermediate = False )
draw_roc(y_train_pred_final.Attrition, y_train_pred_final.Attrition_Prob)
numbers = [float(x)/10 for x in range(10)]
for i in numbers:
    y_train_pred_final[i]= y_train_pred_final.Attrition_Prob.map(lambda x: 1 if x > i else 0)
y_train_pred_final.head()
cutoff_df = pd.DataFrame( columns = ['prob','accuracy','sensi','speci'])
from sklearn.metrics import confusion_matrix
num = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
for i in num:
    cm1 = metrics.confusion_matrix(y_train_pred_final.Attrition, y_train_pred_final[i] )
    total1=sum(sum(cm1))
    accuracy = (cm1[0,0]+cm1[1,1])/total1
    
    speci = cm1[0,0]/(cm1[0,0]+cm1[0,1])
    sensi = cm1[1,1]/(cm1[1,0]+cm1[1,1])
    cutoff_df.loc[i] =[ i ,accuracy,sensi,speci]
print(cutoff_df)
cutoff_df.plot.line(x='prob', y=['accuracy','sensi','speci'])
#plt.show()
y_train_pred_final['final_predicted'] = y_train_pred_final.Attrition_Prob.map( lambda x: 1 if x > 0.2 else 0)
y_train_pred_final.head()
metrics.accuracy_score(y_train_pred_final.Attrition, y_train_pred_final.final_predicted)
confusion2 = metrics.confusion_matrix(y_train_pred_final.Attrition, y_train_pred_final.final_predicted )
confusion2
TP = confusion2[1,1] 
TN = confusion2[0,0] 
FP = confusion2[0,1] 
FN = confusion2[1,0] 
TP / float(TP+FN)
TN / float(TN+FP)
print(FP/ float(TN+FP))
print (TP / float(TP+FP))
print (TN / float(TN+ FN))
confusion = metrics.confusion_matrix(y_train_pred_final.Attrition, y_train_pred_final.predicted )
confusion
confusion[1,1]/(confusion[0,1]+confusion[1,1])
confusion[1,1]/(confusion[1,0]+confusion[1,1])
from sklearn.metrics import precision_recall_curve
y_train_pred_final.Attrition, y_train_pred_final.predicted
p, r, thresholds = precision_recall_curve(y_train_pred_final.Attrition, y_train_pred_final.Attrition_Prob)
#plt.plot(thresholds, p[:-1], "g-")
#plt.plot(thresholds, r[:-1], "r-")
#plt.show()
from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier()
#rfc.fit(X_train,y_train)
#predictions_rf = rfc.predict(X_test)
#print(classification_report(y_test,predictions_rf))
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score
#print(accuracy_score(y_test,predictions_rf))
from sklearn.model_selection import KFold
from sklearn.model_selection import GridSearchCV
scoring = {'AUC': 'roc_auc'}
param_grid = {
    'max_depth': [4,8,10],    'min_samples_leaf': range(50,100,200),    'min_samples_split': range(50,100,200),    'n_estimators': [100,200,300],     'max_features': [10,15,20],    'criterion': ["entropy", "gini"]
}
rf = RandomForestClassifier(class_weight='balanced_subsample')
grid_search = GridSearchCV(estimator = rf, param_grid = param_grid,                           cv = 5, n_jobs = -1,verbose = 1,scoring='roc_auc')
#grid_search.fit(X_train, y_train)
#train_results = grid_search.cv_results_
#print('Precision of',grid_search.best_score_,'using',grid_search.best_params_)
rfc = RandomForestClassifier(bootstrap=True,                             max_depth=8,                             min_samples_leaf=50,                              min_samples_split=50,                             max_features=15,                             n_estimators=100,                             criterion='entropy',                             class_weight='balanced_subsample')
#rfc.fit(X_train,y_train)
#predictions = rfc.predict(X_test)
#print(confusion_matrix(y_test,predictions))
#print(classification_report(y_test,predictions))
from sklearn.metrics import classification_report,confusion_matrix, accuracy_score
#print(accuracy_score(y_test,predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anidata_kernel80b4ecf447.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anidata_kernel80b4ecf447/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anidata_kernel80b4ecf447/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anidata_kernel80b4ecf447/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anidata_kernel80b4ecf447/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anidata_kernel80b4ecf447/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anidata_kernel80b4ecf447/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anidata_kernel80b4ecf447/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anidata_kernel80b4ecf447/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anidata_kernel80b4ecf447/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anidata_kernel80b4ecf447/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anidata_kernel80b4ecf447/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anidata_kernel80b4ecf447/testY.csv",encoding="gbk")


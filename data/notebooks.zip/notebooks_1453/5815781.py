import pandas as pd
# *# *# I# N# T# R# O# D# U# C# T# I# O# N# *# *# 
# 
# I# n#  # t# h# i# s#  # k# e# r# n# e# l#  # w# e#  # w# i# l# l#  # t# r# y#  # t# o#  # i# d# e# n# t# i# f# y#  # g# e# n# d# e# r#  # v# o# i# c# e# s#  # b# y#  # u# s# i# n# g#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n# .#  # T# h# i# s#  # k# e# r# n# e# l#  # h# a# s#  # b# e# e# n#  # p# r# e# p# a# r# e# d#  # w# i# t# h#  # t# h# e#  # p# u# r# p# o# s# e#  # o# f#  # p# r# a# c# t# i# c# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s# .#  

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

# import data
data = pd.read_csv('../input/voicegender/voice.csv')


# In[None]

data.head()

# In[None]

data.info()

# In[None]

data.label.unique()

# In[None]

data.label=[1 if each =="female" else 0 for each in data.label]

# In[None]

data.label.unique()

# In[None]

y = data.label.values
print(y)

# In[None]

x_data = data.drop(["label"], axis=1)
# normalization of x_data
x = (x_data-np.min(x_data)) / (np.max(x_data)-np.min(x_data)).values
print(x)

# In[None]

# train-test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5815781.npy", { "accuracy_score": score })

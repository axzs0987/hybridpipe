import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns  

# In[None]

df = pd.read_csv('../input/Mall_Customers.csv', 
                 encoding='ISO-8859-1')

# In[None]

df.columns

# In[None]

df['Annual Income'] = [x*1000 for x in df['Annual Income (k$)']]
df = df.drop(['Annual Income (k$)'], axis=1)

# In[None]

def box_plots(variable):
    cols = ['Annual Income', 'Spending Score (1-100)', 'Age']
    i=0
    plt.figure(figsize=(30, 20))
    for each in cols:
        i+=1
        plt.subplot(1, 3, i)
        sns.boxplot(x=variable, y=each, data=df)        

# In[None]

box_plots('Gender')

# In[None]

#Annual Income is Left-Skewed.
sns.countplot(x='Gender', data=df)

# In[None]

from sklearn.preprocessing import MinMaxScaler
cols = ['Age', 'Annual Income', 'Spending Score (1-100)']

mss = MinMaxScaler()
def scaler(value):
    x = np.array(df[value]).reshape(-1, 1)
    return mss.fit_transform(x)

for each in cols:
    df[each] = scaler(each)

# In[None]

df = df.drop(['CustomerID'], axis=1)
from sklearn.preprocessing import LabelEncoder

lb = LabelEncoder()
df['Gender'] = lb.fit_transform(df['Gender'])

# In[None]

from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor, AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

x = np.array(df.drop(['Gender'], axis=1))
y = np.array(df['Gender'])

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5296236.npy", { "accuracy_score": score })

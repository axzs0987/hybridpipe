import pandas as pd
# P# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a# n#  # a# d# u# l# t# '# s#  # i# n# c# o# m# e#  # e# x# c# e# e# d# s#  # o# r#  # i# s#  # b# e# l# o# w#  # $# 5# 0# K# /# y# r#  # b# a# s# e# d#  # o# n#  # c# e# n# s# u# s#  # d# a# t# a# .#  # D# a# t# a#  # A# n# a# l# y# s# i# s# ,#  # D# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n# ,#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n#  # a# n# d#  # R# e# d# u# c# t# i# o# n# ,#  # a# b# o# u# t#  # 1# 0#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # m# o# d# e# l# s# /# e# s# t# i# m# a# t# o# r# s# .#  # M# u# l# t# i# l# a# y# e# r#  # P# e# r# c# e# p# t# r# o# n# (# D# e# e# p#  # L# e# a# r# n# i# n# g# /# A# r# t# i# f# i# c# i# a# l#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k# )# .#  # D# a# t# a# s# e# t#  # s# p# l# i# t# t# e# d#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # d# a# t# a# .

# In[None]

import numpy
import pandas
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.ensemble import ExtraTreesClassifier


import matplotlib.pyplot as plt
from pandas.tools.plotting import scatter_matrix

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error



from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.constraints import maxnorm

# fix random seed for reproducibility
seed = 7
numpy.random.seed(seed)


# In[None]

# load dataset
dataframe = pandas.read_csv("../input/adult.csv")

dataframe = dataframe.replace({'?': numpy.nan}).dropna()


# In[None]


# Assign names to Columns
dataframe.columns = ['age', 'workclass', 'fnlwgt', 'education', 'education_num', 'marital_status', 'occupation', 'relationship', 'race', 'sex', 'capital_gain', 'capital_loss', 'hours_per_week', 'native_country', 'income']

# Encode Data
dataframe.workclass.replace(('Private', 'Self-emp-not-inc', 'Self-emp-inc', 'Federal-gov', 'Local-gov', 'State-gov', 'Without-pay', 'Never-worked'),(1,2,3,4,5,6,7,8), inplace=True)
dataframe.education.replace(('Bachelors', 'Some-college', '11th', 'HS-grad', 'Prof-school', 'Assoc-acdm', 'Assoc-voc', '9th', '7th-8th', '12th', 'Masters', '1st-4th', '10th', 'Doctorate', '5th-6th', 'Preschool'),(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16), inplace=True)
dataframe.marital_status.replace(('Married-civ-spouse', 'Divorced', 'Never-married', 'Separated', 'Widowed', 'Married-spouse-absent', 'Married-AF-spouse'),(1,2,3,4,5,6,7), inplace=True)
dataframe.occupation.replace(('Tech-support', 'Craft-repair', 'Other-service', 'Sales', 'Exec-managerial', 'Prof-specialty', 'Handlers-cleaners', 'Machine-op-inspct', 'Adm-clerical', 'Farming-fishing', 'Transport-moving', 'Priv-house-serv', 'Protective-serv', 'Armed-Forces'),(1,2,3,4,5,6,7,8,9,10,11,12,13,14), inplace=True)
dataframe.relationship.replace(('Wife', 'Own-child', 'Husband', 'Not-in-family', 'Other-relative', 'Unmarried'),(1,2,3,4,5,6), inplace=True)
dataframe.race.replace(('White', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other', 'Black'),(1,2,3,4,5), inplace=True)
dataframe.sex.replace(('Female', 'Male'),(1,2), inplace=True)
dataframe.native_country.replace(('United-States', 'Cambodia', 'England', 'Puerto-Rico', 'Canada', 'Germany', 'Outlying-US(Guam-USVI-etc)', 'India', 'Japan', 'Greece', 'South', 'China', 'Cuba', 'Iran', 'Honduras', 'Philippines', 'Italy', 'Poland', 'Jamaica', 'Vietnam', 'Mexico', 'Portugal', 'Ireland', 'France', 'Dominican-Republic', 'Laos', 'Ecuador', 'Taiwan', 'Haiti', 'Columbia', 'Hungary', 'Guatemala', 'Nicaragua', 'Scotland', 'Thailand', 'Yugoslavia', 'El-Salvador', 'Trinadad&Tobago', 'Peru', 'Hong', 'Holand-Netherlands'),(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41), inplace=True)
dataframe.income.replace(('<=50K', '>50K'),(0,1), inplace=True)

# In[None]

print("Head:", dataframe.head())

# In[None]

print("Statistical Description:", dataframe.describe())

# In[None]

print("Shape:", dataframe.shape)

# In[None]

print("Data Types:", dataframe.dtypes)

# In[None]

print("Correlation:", dataframe.corr(method='pearson'))

# '# m# a# r# i# t# a# l# _# s# t# a# t# u# s# '#  # h# a# s#  # t# h# e#  # h# i# g# h# e# s# t#  # c# o# r# r# e# l# a# t# i# o# n#  # w# i# t# h#  # t# h# e#  # l# e# v# e# l#  # o# f#  # i# n# c# o# m# e# (# w# h# i# c# h#  # i# s#  # a#  # n# e# g# a# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n# )# ,#  # f# o# l# l# o# w# e# d#  # b# y#  # '# e# d# u# c# a# t# i# o# n# _# n# u# m# '#  # w# h# i# c# h#  # i# s#  # a#  # p# o# s# i# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n# ,#  # '# f# n# l# w# g# t# '#  # h# a# s#  # t# h# e#  # l# e# a# s# t#  # c# o# r# r# e# l# a# t# i# o# n#  

# In[None]

dataset = dataframe.values


X = dataset[:,0:14]
Y = dataset[:,14] 

# In[None]

# feature extraction
test = SelectKBest(score_func=chi2, k=3)
fit = test.fit(X, Y)

# scores
numpy.set_printoptions(precision=3)
print(fit.scores_)
features = fit.transform(X)

# summarise selected features
print(features[0:10,:])

#  # '# r# e# l# a# t# i# o# n# s# h# i# p# '# ,#  # '# c# a# p# i# t# a# l# _# l# o# s# s# '#  # a# n# d#  # '# c# a# p# i# t# a# l# _# g# a# i# n# '#  # w# e# r# e#  # t# o# p#  # 3#  # s# e# l# e# c# t# e# d#  # f# e# a# t# u# r# e# s#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # '# I# n# c# o# m# e# '# 
#  # u# s# i# n# g#  # c# h# i# -# s# q# u# a# r# e# d#  # (# c# h# i# 2# )#  # s# t# a# t# i# s# t# i# c# a# l#  # t# e# s# t# ,#  # U# n# i# v# a# r# i# a# t# e#  # S# e# l# e# c# t# i# o# n# s

# In[None]

#Feature Selection
model = LogisticRegression()
rfe = RFE(model, 3)
fit = rfe.fit(X, Y)

print("Number of Features: ", fit.n_features_)
print("Selected Features: ", fit.support_)
print("Feature Ranking: ", fit.ranking_)

# '# e# d# u# c# a# t# i# o# n# _# n# u# m# '# ,#  # '# m# a# r# i# t# a# l# _# s# t# a# t# u# s# '#  # a# n# d#  # '# s# e# x# '#  # w# e# r# e#  # t# o# p#  # 3#  # s# e# l# e# c# t# e# d#  # f# e# a# t# u# r# e# s# /# f# e# a# t# u# r# e#  # c# o# m# b# i# n# a# t# i# o# n#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # '# I# n# c# o# m# e# '# 
#  # u# s# i# n# g#  # R# e# c# u# r# s# i# v# e#  # F# e# a# t# u# r# e#  # E# l# i# m# i# n# a# t# i# o# n# ,#  # t# h# e#  # 1# s# t#  # a# n# d#  # 2# n#  # a# r# e#  # a# t# u# a# l# l# y#  # t# h# e#  # t# w# o#  # a# t# t# r# i# b# u# t# e# s#  # w# i# t# h#  # t# h# e#  # h# i# g# h# e# s# t#  # c# o# r# r# e# l# a# t# i# o# n#  # w# i# t# h#  # t# h# e#  # 
#  # '# I# n# c# o# m# e# '#  # c# l# a# s# s

#  # D# i# m# e# n# s# i# o# n# a# l# i# t# y#  # R# e# d# u# c# t# i# o# n# :#  # P# r# i# n# c# i# p# a# l#  # C# o# m# p# o# n# e# n# t#  # A# n# a# l# y# s# i# s# :#  

# In[None]

pca = PCA(n_components=3)
fit = pca.fit(X)

print("Explained Varience: ", fit.explained_variance_ratio_)

# In[None]

model = ExtraTreesClassifier()
model.fit(X, Y)
print("Feature Importance: ", model.feature_importances_)


# In[None]



# '# a# g# e# '# ,#  # '# f# n# l# w# g# t# '#  # a# n# d#  # '# m# a# r# i# t# a# l# _# s# t# a# t# u# s# '#  # a# r# e#  # t# h# e#  # t# o# p#  # 3#  # f# e# a# t# u# r# e# s#  # u# s# i# n# g#  # F# e# a# t# u# r# e#  # I# m# p# o# r# t# a# n# c# e#  # f# r# o# m#  # E# x# t# r# a#  # T# r# e# e# s# (# B# a# g# g# e# d#  # d# e# c# i# s# i# o# n#  # t# r# e# e# s# )

# *# *# V# I# S# U# A# L# I# Z# A# T# I# O# N# *# *

# In[None]

plt.hist((dataframe.income))

# M# o# s# t#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# '# s#  # s# a# m# p# l# e# s#  # f# a# l# l#  # w# i# t# h# i# n#  # t# h# e#  # '# <# =# 5# 0# K# '#  # '# i# n# c# o# m# e# '#  # o# u# t# p# u# t#  # c# l# a# s# s

# In[None]

dataframe.hist()

# In[None]

dataframe.plot(kind='density', subplots=True, layout=(4,4), sharex=False, sharey=False)

# T# h# e# r# e#  # a# r# e#  # a#  # m# i# x# t# u# r# e#  # o# f#  # p# o# s# i# t# i# v# e#  # s# k# e# w# s#  # a# n# d#  # n# e# g# a# t# i# v# e#  # s# k# e# w# s#  # t# h# e#  # o# t# h# e# r#  # a# t# t# r# i# b# u# t# e# s

# In[None]

scatter_matrix(dataframe)

# In[None]

fig = plt.figure()
ax = fig.add_subplot(111)
cax = ax.matshow(dataframe.corr(), vmin=-1, vmax=1)
fig.colorbar(cax)
ticks = numpy.arange(0,15,1)
ax.set_xticks(ticks)
ax.set_yticks(ticks)
ax.set_xticklabels(dataframe.columns)
ax.set_yticklabels(dataframe.columns)

# '# m# a# r# i# t# a# l# _# s# t# a# t# u# s# '#  # h# a# s#  # t# h# e#  # h# i# g# h# e# s# t#  # p# o# s# i# t# i# v# e#  # c# o# r# e# l# a# t# i# o# n#  # a# s#  # e# x# p# e# c# t# e# d

# 
# 
# 
# 
# 
# 
# *# *# M# A# C# H# I# N# E#  # L# E# A# R# N# I# N# G#  # E# S# T# I# M# A# T# O# R# S# /# M# O# D# E# L# S# *# *

# In[None]

# Split Data to Train and Test
from sklearn.model_selection import train_test_split
X_Train, X_Test, Y_Train, Y_Test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_Train, Y_Train)
y_pred = model.predict(X_Test)
score = accuracy_score(Y_Test, y_pred)
import numpy as np
np.save("prenotebook_res/351382.npy", { "accuracy_score": score })

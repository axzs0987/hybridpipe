import pandas as pd
# ##  # F# i# n# d# i# n# g#  # P# u# l# s# a# r#  # S# t# a# r# s# 
# 
# H# e# r# e#  # w# e#  # h# a# v# e#  # a#  # d# a# t# a# s# e# t#  # w# i# t# h#  # 1# 5#  # t# h# o# u# s# a# n# d#  # s# t# a# r# s# .#  # O# u# r#  # t# a# s# k#  # i# s#  # t# o#  # j# u# d# g# e#  # w# h# e# t# h# e# r#  # a#  # s# t# a# r#  # i# s#  # a#  # p# u# l# s# a# r#  # o# r#  # n# o# t#  # b# a# s# e# d#  # o# n#  # c# e# r# t# a# i# n#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # t# h# e#  # d# a# t# a# s# e# t#  # h# a# s#  # g# i# v# e# n#  # t# o#  # u# s#  # a# b# o# u# t#  # t# h# e# m# .#  # A#  # p# u# l# s# a# r#  # i# s#  # a#  # r# a# r# e#  # t# y# p# e#  # o# f#  # s# t# a# r#  # w# h# i# c# h#  # p# r# o# d# u# c# e# s#  # r# a# d# i# o#  # e# m# i# s# s# i# o# n#  # t# h# a# t#  # i# s#  # d# e# t# e# c# t# a# b# l# e#  # o# n#  # E# a# r# t# h# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.
dataset = pd.read_csv('/kaggle/input/predicting-a-pulsar-star/pulsar_stars.csv')[:15000]
X = np.array([np.array(dataset).T[0], np.array(dataset).T[4]])
y = np.array(dataset).T[8]
X = X.astype(np.float64)
y = y.astype(int)
dataset.head()

# T# h# i# s#  # d# a# t# a# s# e# t#  # h# a# s#  # 8#  # f# e# a# t# u# r# e# s#  # w# h# i# c# h#  # w# e#  # c# a# n#  # u# s# e#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # t# a# r# g# e# t# _# c# l# a# s# s# .#  # W# e#  # w# i# l# l#  # s# i# m# p# l# y#  # b# e#  # u# s# i# n# g#  # t# w# o#  # f# o# r#  # t# h# i# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# :#  # '# M# e# a# n#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# '#  # a# n# d#  # '# M# e# a# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# '# .# 
# 
# ##  # P# l# o# t# t# i# n# g#  # d# a# t# a# 
# F# o# r#  # v# i# s# u# a# l# i# s# i# n# g#  # d# a# t# a# ,#  # w# e#  # w# i# l# l#  # f# i# r# s# t#  # u# s# e#  # a#  # s# c# a# t# t# e# r#  # p# l# o# t# ,#  # t# h# e# n#  # a#  # b# a# r#  # g# r# a# p# h# .

# In[None]

import matplotlib.pyplot as plt
import collections
plt.scatter(X[0], X[1], c=y)
plt.title('Stars', fontsize=15)
plt.xlabel('Mean of the integrated profile', fontsize=13)
plt.ylabel('Mean of the DM-SNR curve', fontsize=13)
plt.show()

plt.bar(range(0, 2), [collections.Counter(y)[0], collections.Counter(y)[1]])
plt.title('Stars', fontsize=15)
plt.xlabel('Regular                            Pulsar', fontsize=13)
plt.ylabel('Number of stars', fontsize=13)
plt.show()

# T# h# e#  # d# a# t# a# p# o# i# n# t# s#  # h# a# v# e#  # a#  # r# e# l# a# t# i# v# e# l# y#  # '# c# l# a# s# s# i# f# i# a# b# l# e# '#  # b# o# r# d# e# r# ,#  # a# s#  # s# h# o# w# n#  # i# n#  # t# h# e#  # s# c# a# t# t# e# r#  # p# l# o# t# .#  # A# s#  # f# o# r#  # t# h# e#  # b# a# r#  # p# l# o# t# ,#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # t# h# e#  # p# u# l# s# a# r#  # s# t# a# r# s#  # a# r# e#  # m# u# c# h#  # l# e# s# s#  # i# n#  # n# u# m# b# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # r# e# g# u# l# a# r#  # s# t# a# r# s# .# 
# 
# ##  # S# p# l# i# t# t# i# n# g#  # d# a# t# a#  # a# n# d#  # c# r# e# a# t# i# n# g#  # m# o# d# e# l# s# 
# N# e# x# t#  # u# p# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # s# c# i# k# i# t# -# l# e# a# r# n# '# s#  # t# r# a# i# n# _# t# e# s# t# _# s# p# l# i# t#  # t# o#  # s# p# l# i# t#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # s# e# t# s# ,#  # w# h# i# c# h#  # w# i# l# l#  # h# e# l# p#  # o# u# r#  # m# o# d# e# l# '# s#  # a# c# c# u# r# a# c# y# .#  # A# f# t# e# r# w# a# r# d# s# ,#  # w# e#  # w# i# l# l#  # c# r# e# a# t# e#  # m# u# l# t# i# p# l# e#  # m# o# d# e# l# s#  # w# h# i# c# h#  # w# i# l# l#  # l# a# t# e# r#  # b# e#  # u# s# e# d#  # f# o# r#  # f# i# t# t# i# n# g#  # t# h# e#  # t# r# a# i# n#  # d# a# t# a# .

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X.T, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7480673.npy", { "accuracy_score": score })

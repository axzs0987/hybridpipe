import pandas as pd
# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from IPython.display import Image as PImage
from subprocess import check_call
from PIL import Image, ImageDraw, ImageFont
from sklearn.tree import export_graphviz
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, roc_curve, auc

# In[None]

turnover = pd.read_csv("../input/turnover.csv")
turnover.head()

# In[None]

# converting salary into categories
turnover["salary"] = turnover["salary"].astype('category').cat.reorder_categories(['low', 'medium', 'high']).cat.codes
turnover.head()

# In[None]

# converting department into dummies
department = pd.get_dummies(turnover["sales"])
department.head()

# In[None]

turnover = turnover.drop(["sales"], axis=1)
turnover.head()

# In[None]

# creating correlation matrix
turnover.corr()

# In[None]

# plotting the correlation matrix
# as seaborn is based on matplotlib, we need to use plt.show() to see the plot
sns.heatmap(turnover.corr())
plt.show()

# In[None]

turnover.info()

# In[None]

turnover.describe()

# In[None]

# joining the departments
turnover = turnover.join(department)
turnover.head()

# In[None]

# the percentage of leavers
turnover['left'].value_counts()/len(turnover)*100

# ## ##  # D# e# c# i# s# i# o# n#  # T# r# e# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n

# In[None]

from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier(random_state=42)

# In[None]

X = turnover.drop(['left'], axis=1)
y = turnover['left']

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/487962.npy", { "accuracy_score": score })

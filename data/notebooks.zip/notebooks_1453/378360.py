import pandas as pd
# ## ##  # I# m# p# o# r# t# i# n# g#  # t# h# e#  # D# a# t# a

# In[None]

import pandas as pd
df = pd.read_csv("../input/KaggleV2-May-2016.csv")


# ## ##  # D# e# s# c# r# i# p# t# i# v# e#  # S# u# m# m# a# r# y

# In[None]

df.describe()

# ## ##  # N# u# m# b# e# r#  # o# f#  # R# o# w# s#  # a# n# d#  # C# o# l# u# m# n# s

# In[None]

df.shape

# T# h# e#  # o# r# i# g# i# n# a# l#  # d# a# t# a# s# e# t#  # h# a# s#  # 1# 1# 0# ,# 5# 2# 7#  # r# e# c# o# r# d# s#  # a# n# d#  # 1# 4#  # f# e# a# t# u# r# e# s#  # (# i# n# p# u# t#  # v# a# r# i# a# b# l# e# s# )

# ## ##  # C# o# l# u# m# n#  # N# a# m# e# s

# In[None]

df.columns

# ## ##  # T# a# r# g# e# t#  # V# a# r# i# a# b# l# e# 


# In[None]

no_show = df["No-show"].value_counts()
print(no_show)

Percent_no_show = no_show["Yes"]/ no_show.sum() * 100
print("Percent who didn't show up to their appointment:",Percent_no_show )

# ## ##  # R# e# c# o# d# e#  # T# a# r# g# e# t#  # V# a# r# i# a# b# l# e# 
# 0#  # =#  #  # D# i# d#  # n# o# t#  # s# h# o# w#  # u# p#  # t# o#  # a# p# p# o# i# n# t# m# e# n# t# 
# 
# 1#  # =#  #  # S# h# o# w# e# d#  # u# p#  # t# o#  # a# p# p# o# i# n# t# m# e# n# t

# In[None]

df['No-show'].replace("No", 0,inplace=True)
df['No-show'].replace("Yes", 1,inplace=True)


# ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # A# n# a# l# y# s# i# s#  # o# n#  # F# e# a# t# u# r# e# s# 
# C# o# u# n# t#  # o# f#  # M# a# l# e#  # v# s#  # F# e# m# a# l# e

# In[None]

df["Gender"].value_counts()

# ## ##  # S# e# e# i# n# g#  # h# o# w#  # e# a# c# h#  # f# e# a# t# u# r# e#  # r# e# l# a# t# e# s#  # t# o#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .# 


# In[None]

Exploratory_Analysis = ['Gender','Hipertension','Alcoholism','Diabetes']
for r in Exploratory_Analysis :
    print(df.groupby(r)['No-show'].mean())
#df.groupby('Hipertension')['No-show'].mean()

# A# s#  # s# h# o# w# n#  # a# b# o# v# e# ,#  # g# e# n# d# e# r#  # d# o# e# s#  # n# o# t#  # s# e# e# m#  # t# o#  # a# f# f# e# c# t#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # s# h# o# w# s#  # u# p#  # t# o#  # a# n#  # a# p# p# o# i# n# t# m# e# n# t#  # o# r#  # n# o# t# ,#  # a# s#  # b# o# t# h#  # m# a# l# e# s#  # a# n# d#  # f# e# m# a# l# e# s#  # d# o# n# '# t#  # s# h# o# w#  # u# p#  # t# o#  # a# p# p# r# o# x# i# m# a# t# e# l# y#  # 2# 0#  # p# e# r# c# e# n# t#  # o# f#  # t# h# e# i# r#  # a# p# p# o# i# n# t# m# e# n# t# s# .#  # D# i# a# b# e# t# e# s#  # a# n# d#  # A# l# c# o# h# o# l# i# s# m#  # d# o# n# '# t#  # s# e# e# m#  # t# o#  # a# f# f# e# c# t#  # n# o# -# s# h# o# w# s#  # a# s#  # w# e# l# l# .# 
# 
# H# y# p# e# r# t# e# n# s# i# o# n#  # s# e# e# m# s#  # t# o#  # h# a# v# e#  # a#  # s# m# a# l# l#  # a# f# f# e# c# t# ,#  # a# s#  # a#  # p# a# t# i# e# n# t#  # w# h# o#  # h# a# s#  # h# y# p# e# r# t# e# n# s# i# o# n#  # i# s#  # 3# %#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # s# h# o# w#  # u# p#  # t# h# a# n#  # a#  # p# a# t# i# e# n# t#  # w# h# o#  # d# o# e# s# n# '# t#  # h# a# v# e#  # h# y# p# e# r#  # t# e# n# s# i# o# n# .

# ## ##  # H# a# n# d# i# c# a# p# 
# 
# T# h# e#  # f# e# a# t# u# r# e#  # "# h# a# n# d# i# c# a# p# "#  # h# a# s#  # 4#  # c# a# t# e# g# o# r# i# e# s#  # (# e# x# p# l# a# n# a# t# i# o# n#  # w# a# s#  # n# o# t#  # p# r# o# v# i# d# e# d#  # o# n#  # w# h# a# t#  # e# a# c# h#  # c# a# t# e# g# o# r# y#  # s# t# a# n# d# s#  # f# o# r# )# ,#  # t# h# e# r# e# f# o# r# e#  # I#  # w# i# l# l#  # c# o# n# v# e# r# t#  # i# t#  # t# o#  # a#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e#  # a# n# d#  # c# r# e# a# t# e#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e# s#  # t# o#  # p# r# e# p# a# r# e#  # i# t#  # f# o# r#  # m# o# d# e# l# i# n# g# .

# In[None]

#Convert to Categorical
df['Handcap'] = pd.Categorical(df['Handcap'])
#Convert to Dummy Variables
Handicap = pd.get_dummies(df['Handcap'], prefix = 'Handicap')
df = pd.concat([df, Handicap], axis=1)


# In[None]

## See how each type of handicap affects whether a patient will show up to an appointment 
handicaps = ["Handicap_1", "Handicap_2", "Handicap_3", "Handicap_4"]
for h in handicaps:
    print(df.groupby(h)['No-show'].mean())
    

# W# h# a# t#  # s# t# a# n# d# s#  # o# u# t#  # i# s#  # a#  # p# a# t# i# e# n# t#  # w# h# o#  # i# s#  # h# a# n# d# i# c# a# p# _# 4#  # i# s#  # 1# 3#  # %#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # n# o# t#  # s# h# o# w#  # u# p#  # t# o#  # a# n#  # a# p# p# o# i# n# t# m# e# n# t#  # t# h# a# n#  # a#  # p# e# r# s# o# n#  # w# h# o#  # i# s#  # n# o# t#  # h# a# n# d# i# c# a# p# _# 4# .#  

# ## ##  # W# h# e# t# h# e# r#  # t# h# e#  # p# a# t# i# e# n# t#  # r# e# c# e# i# v# e# d#  # a#  # t# e# x# t#  # r# e# m# i# n# d# e# r# 


# In[None]

df.groupby('SMS_received')['No-show'].mean()

# U# n# e# x# p# e# c# e# d# a# t# e# l# y# ,#  # p# a# t# i# e# n# t# s#  # w# h# o#  # r# e# c# e# i# v# e# d#  # a#  # t# e# x# t#  # r# e# m# i# n# d# e# r#  # d# i# d#  # n# o# t#  # s# h# o# w#  # u# p#  # t# o#  # 2# 7# %#  # p# e# r# s# o# n#  # o# f#  # t# h# e# i# r#  # a# p# p# o# i# n# t# m# e# n# t# s# ,#  # w# h# e# r# e#  # a# s#  # p# a# t# i# e# n# t# s#  # w# h# o#  # d# i# d#  # n# o# t#  # r# e# c# e# i# v# e#  # a#  # t# e# x# t#  # r# e# m# i# n# d# e# r#  # d# i# d#  # n# o# t#  # s# h# o# w#  # u# p#  # t# o#  # 1# 7# %#  # o# f#  # t# h# e# i# r#  # a# p# p# o# i# n# t# m# e# n# t# s

# ## ##  # F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g

# ## ##  # A# g# e# 


# In[None]

min_age = df.Age.min()
print("Min Age:", min_age)
max_age = df.Age.max()
print("Max Age:", max_age)


# D# u# e#  # t# o#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # m# i# n# i# m# u# m#  # a# g# e#  # i# s#  # s# a# i# d#  # t# o#  # b# e#  # -# 1# ,#  # I#  # w# i# l# l#  # r# e# m# o# v# e#  # i# n#  # t# h# e#  # n# e# x# t#  # l# i# n# e#  # a# l# l#  # r# e# c# o# r# d# s#  # w# h# e# r# e#  # a# g# e#  # i# s#  # <#  # 0# .#  # I#  # w# i# l# l#  # a# l# s# o#  # t# r# e# a# t#  # a# s#  # o# u# t# l# i# e# r# s#  # a# n# y#  # a# g# e#  # a# b# o# v# e#  # a#  # 1# 0# 0#  # d# u# e#  # t# o#  # t# h# e#  # l# a# c# k#  # o# f#  # p# e# o# p# l# e#  # t# h# a# t#  # l# i# v# e#  # m# o# r# e#  # t# h# a# n#  # a#  # 1# 0# 0#  # y# e# a# r# s# .#  #  

# In[None]

df = df[(df.Age >= 0) & (df.Age <= 100)]

# ## ##  # W# a# i# t#  # T# i# m# e# 
# I# n#  # m# y#  # e# x# p# e# r# i# e# n# c# e# ,#  # i# f#  # I#  # s# c# h# e# d# u# l# e#  # a# n#  # a# p# p# o# i# n# t# m# e# n# t#  # f# a# r#  # i# n#  # a# d# v# a# n# c# e#  # a# n# d#  # n# o#  # o# n# e#  # r# e# m# i# n# d# s#  # m# e# ,#  # I#  # t# e# n# d#  # t# o#  # f# o# r# g# e# t#  # a# b# o# u# t#  # i# t# .#  # O# r#  # b# y#  # t# h# e#  # t# i# m# e#  # m# y#  # a# p# p# o# i# n# t# m# e# n# t#  # d# a# y#  # a# r# r# i# v# e# s# ,#  # I#  # f# e# e# l#  # b# e# t# t# e# r#  # a# n# d#  # d# o# n# '# t#  # b# o# t# h# e# r#  # s# h# o# w# i# n# g#  # u# p# .#  # I# n#  # t# h# i# s#  # s# e# c# t# i# o# n# ,#  # I#  # w# i# l# l#  # c# r# e# a# t# e#  # a#  # v# a# r# i# a# b# l# e#  # c# a# l# l# e# d#  # "# w# a# i# t# _# t# i# m# e# "#  # t# o#  # s# e# e#  # i# f#  # t# h# e#  # t# i# m# e#  # b# e# t# w# e# e# n#  # t# h# e#  # d# a# t# e#  # a# n#  # a# p# p# o# i# n# t# m# e# n# t#  # w# a# s#  # s# c# h# e# d# u# l# e# d#  # a# n# d#  # t# h# e#  # d# a# t# e#  # w# a# s#  # t# h# e#  # a# p# p# o# i# n# t# m# e# n# t#  # i# s# ,#  #  # h# a# s#  # a# n#  # a# f# f# e# c# t#  # o# n#  # n# o# -# s# h# o# w# s# .

# In[None]

import numpy as np

# Converts the two variables to datetime variables
df['ScheduledDay'] = pd.to_datetime(df['ScheduledDay'])
df['AppointmentDay'] = pd.to_datetime(df['AppointmentDay'])

# Create a variable called "AwaitingTime" by subtracting the date the patient made the appointment and the date of the appointment.
df['AwaitingTime'] = df["AppointmentDay"].sub(df["ScheduledDay"], axis=0)

# Convert the result "AwaitingTime" to number of days between appointment day and scheduled day. 
df["AwaitingTime"] = (df["AwaitingTime"] / np.timedelta64(1, 'D')).abs()


# ## ##  # N# u# m# b# e# r#  # o# f#  # A# p# p# o# i# n# t# m# e# n# t# s#  # M# i# s# s# e# d#  # i# n#  # t# h# e#  # P# a# s# t# 
# S# i# n# c# e#  # P# a# t# i# e# n# t# I# d#  # i# s#  # a# v# a# i# l# a# b# l# e# ,#  # I#  # c# r# e# a# t# e# d#  # a#  # n# e# w#  # v# a# r# i# a# b# l# e#  # t# h# a# t#  # a# d# d# s#  # h# o# w#  # m# a# n# y#  # a# p# p# o# i# n# t# m# e# n# t# s#  # t# h# e#  # p# a# t# i# e# n# t#  # h# a# s#  # m# i# s# s# e# d#  # i# n#  # t# h# e#  # p# a# s# t# .#  

# In[None]

# Number of Appointments Missed by Patient
df['Num_App_Missed'] = df.groupby('PatientId')['No-show'].apply(lambda x: x.cumsum())


# ## ##  # L# e# t# '# s#  # t# a# k# e#  # a#  # l# o# o# k#  # w# h# a# t#  # c# o# l# u# m# n# s#  # w# e#  # h# a# v# e#  # a# f# t# e# r#  # t# h# e#  # f# e# a# t# u# r# e#  # e# n# g# i# n# e# e# r# i# n# g

# In[None]

df.columns

# ## ##  # I#  # w# i# l# l#  # d# r# o# p#  # c# o# l# u# m# n# s#  # t# h# a# t#  # w# o# n# '# t#  # b# e#  # u# s# e# d#  # f# o# r#  # m# o# d# e# l# i# n# g# 
# D# r# o# p#  # b# o# t# h#  # I# D#  # i# n# d# i# c# a# t# o# r# s#  # a# s#  # t# h# e# y#  # a# r# e#  # u# n# i# q# u# e#  # v# a# l# u# e# s# .#  # D# r# o# p#  # A# g# e# ,#  # S# c# h# e# d# u# l# e# d# D# a# y# ,#  # a# n# d#  # A# p# p# o# i# n# t# m# e# n# t# D# a# y#  # b# e# c# a# u# s# e#  # I#  # e# n# g# i# n# e# e# r# e# d#  # v# a# r# i# a# b# l# e# s#  # t# h# a# t#  # w# i# l# l#  # t# a# k# e#  # t# h# e#  # p# l# a# c# e#  # o# f#  # t# h# e# s# e# .#  # I#  # a# l# s# o#  # d# r# o# p# p# e# d#  # N# e# i# g# h# b# o# u# r# h# o# o# d#  # b# e# c# a# u# s# e#  # t# h# e# r# e#  # a# r# e#  # m# o# r# e#  # t# h# a# n#  # 8# 8#  # n# e# i# g# h# b# o# u# r# h# o# o# d# s# ,#  # a# n# d#  # i# t#  # w# a# s#  # c# o# n# s# i# d# e# r# a# b# l# y#  # s# l# o# w# i# n# g#  # m# y#  # m# o# d# e# l#  # d# o# w# n# .#  

# In[None]

df.drop(['PatientId', 'AppointmentID', 'ScheduledDay', 'Handcap', 'AppointmentDay', 'Neighbourhood'], axis=1, inplace=True)

# ## ##  # T# h# e# s# e#  # a# r# e#  # t# h# e#  # f# i# n# a# l#  # f# e# a# t# u# r# e# s#  # a# n# d#  #  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e

# In[None]

X = df[['Gender', 'Diabetes','Hipertension', 'Scholarship', 'SMS_received',
        'Handicap_0','Handicap_1','Handicap_2','Handicap_3','Handicap_4', 'Num_App_Missed', 'Age', 'AwaitingTime']]

y = df["No-show"]

# In[None]

#This will create dummies for the remaining variables (Gender)
X_train1 = pd.get_dummies(X)

# ## ##  # I# n#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # c# o# d# e# ,#  # I#  # s# c# a# l# e# d#  # t# h# e#  # d# a# t# a#  # s# o#  # t# h# a# t#  # a# l# l#  # v# a# l# u# e# s#  # a# r# e#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .#  # 
# T# h# e#  # f# o# l# l# o# w# i# n# g#  # e# x# p# l# a# n# a# t# i# o# n#  # i# s#  # f# r# o# m#  # M# a# c# h# i# n# e# L# e# a# r# n# i# n# g# M# a# s# t# e# r# y# .# c# o# m#  # a# n# d#  # e# x# p# l# a# i# n# s#  # h# o# w#  # t# h# i# s#  # s# c# a# l# i# n# g#  # w# o# r# k# s# :# 
# 
# S# t# a# n# d# a# r# d# i# z# a# t# i# o# n#  # i# s#  # a#  # u# s# e# f# u# l#  # t# e# c# h# n# i# q# u# e#  # t# o#  # t# r# a# n# s# f# o# r# m#  # a# t# t# r# i# b# u# t# e# s#  # w# i# t# h#  # a#  # G# a# u# s# s# i# a# n#  # d# i# s# t# r# i# b# u# t# i# o# n#  # a# n# d#  # d# i# f# f# e# r# i# n# g#  # m# e# a# n# s#  # a# n# d#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n# s#  # t# o#  # a#  # s# t# a# n# d# a# r# d#  # G# a# u# s# s# i# a# n#  # d# i# s# t# r# i# b# u# t# i# o# n#  # w# i# t# h#  # a#  # m# e# a# n#  # o# f#  # 0#  # a# n# d#  # a#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # 1# .# 
# 
# I# t#  # i# s#  # m# o# s# t#  # s# u# i# t# a# b# l# e#  # f# o# r#  # t# e# c# h# n# i# q# u# e# s#  # t# h# a# t#  # a# s# s# u# m# e#  # a#  # G# a# u# s# s# i# a# n#  # d# i# s# t# r# i# b# u# t# i# o# n#  # i# n#  # t# h# e#  # i# n# p# u# t#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # w# o# r# k#  # b# e# t# t# e# r#  # w# i# t# h#  # r# e# s# c# a# l# e# d#  # d# a# t# a# ,#  # s# u# c# h#  # a# s#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# ,#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # a# n# d#  # l# i# n# e# a# r#  # d# i# s# c# r# i# m# i# n# a# t# e#  # a# n# a# l# y# s# i# s# .# 
# 


# In[None]

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler().fit(X_train1)
rescaledX2 = scaler.transform(X_train1)
# summarize transformed data
np.set_printoptions(precision=3)
print(rescaledX2[0:5,:])

# ## ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 


# In[None]

from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import train_test_split

# Create Training and Test Dataset with 75% Training and 25% Test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(rescaledX2, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/378360.npy", { "accuracy_score": score })

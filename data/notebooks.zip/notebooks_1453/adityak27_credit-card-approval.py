import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data = pd.read_csv('../input/svm-classification/UniversalBank.csv')
data.head()
data.drop(["ID","ZIP Code"],axis=1,inplace=True)
data.head()
data.shape
data.info()
data.describe() 
data[data['Experience'] < 0] = 0
data.describe()
#plt.rcParams['figure.figsize'] = (15, 15)
#plt.style.use('ggplot')
#sns.heatmap(data.corr() ,annot = True)
#plt.title('Heatmap', fontsize = 30)
#sns.distplot(data['Age'])
#sns.distplot(data['Experience'])
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import confusion_matrix,mean_squared_error,accuracy_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
X = data.iloc[:,:-1]
y = data["CreditCard"]
from sklearn.model_selection import train_test_split
trainx, testx, trainy, testy = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
print(trainx.shape)
print(testx.shape)
print(trainy.shape)
print(testy.shape)
X = trainx
y = trainy
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score 
model = LogisticRegression()
#model.fit(X , y)
#predicted_classes = model.predict(X)
#accuracy = accuracy_score(y,predicted_classes)
#parameters = model.coef_
#print(accuracy)
#print(parameters)
#print(model)
#model.fit(testx , testy)
#predicted_classes_test = model.predict(testx)
#accuracy = accuracy_score(testy,predicted_classes_test)
#print(accuracy)
from sklearn.naive_bayes import GaussianNB
NB = GaussianNB()
#NB.fit(X , y)
#NB_train_pred = NB.predict(X)
#print(accuracy_score(y,NB_train_pred))
#NB_test_pred = NB.predict(testx)
#print(accuracy_score(testy,NB_test_pred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(trainx, trainy)
y_pred = model.predict(testx)
score = accuracy_score(testy, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/adityak27_credit-card-approval.npy", { "accuracy_score": score })
import pandas as pd
if type(trainx).__name__ == "ndarray":
    np.save("hi_res_data/adityak27_credit-card-approval/trainX.npy", trainx)
if type(trainx).__name__ == "Series":
    trainx.to_csv("hi_res_data/adityak27_credit-card-approval/trainX.csv",encoding="gbk")
if type(trainx).__name__ == "DataFrame":
    trainx.to_csv("hi_res_data/adityak27_credit-card-approval/trainX.csv",encoding="gbk")

if type(testx).__name__ == "ndarray":
    np.save("hi_res_data/adityak27_credit-card-approval/testX.npy", testx)
if type(testx).__name__ == "Series":
    testx.to_csv("hi_res_data/adityak27_credit-card-approval/testX.csv",encoding="gbk")
if type(testx).__name__ == "DataFrame":
    testx.to_csv("hi_res_data/adityak27_credit-card-approval/testX.csv",encoding="gbk")

if type(trainy).__name__ == "ndarray":
    np.save("hi_res_data/adityak27_credit-card-approval/trainY.npy", trainy)
if type(trainy).__name__ == "Series":
    trainy.to_csv("hi_res_data/adityak27_credit-card-approval/trainY.csv",encoding="gbk")
if type(trainy).__name__ == "DataFrame":
    trainy.to_csv("hi_res_data/adityak27_credit-card-approval/trainY.csv",encoding="gbk")

if type(testy).__name__ == "ndarray":
    np.save("hi_res_data/adityak27_credit-card-approval/testY.npy", testy)
if type(testy).__name__ == "Series":
    testy.to_csv("hi_res_data/adityak27_credit-card-approval/testY.csv",encoding="gbk")
if type(testy).__name__ == "DataFrame":
    testy.to_csv("hi_res_data/adityak27_credit-card-approval/testY.csv",encoding="gbk")


import pandas as pd
# ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 


# ## ##  # S# u# a# d#  # E# m# r# e#  # U# M# A# R# 
# 


# ## ##  # T# a# b# l# e#  # o# f#  # C# o# n# t# e# n# t# s# 
# *# *# *# 
# *#  # [# 1# .#  # I# n# t# r# o# d# u# c# t# i# o# n# ]# (# ## c# )#  # <# b# r# ># 
# *#  # [# 2# .#  # I# m# p# o# r# t# i# n# g#  # d# a# t# a# s# e# t#  # a# n# d#  # d# a# t# a#  # p# r# e# p# r# o# c# e# s# s# i# n# g# ]# (# ## 2# )#  # <# b# r# ># 
# *#  # [# 3# .#  # N# o# r# m# a# l# i# z# a# t# i# o# n#  # ]# (# ## 3# )#  # <# b# r# ># 
# *#  # [# 4# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## 4# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 1# .#  # T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# ]# (# ## 4# .# 1# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 2# .#  # P# a# r# a# m# e# t# e# r#  # I# n# i# t# i# a# l# i# z# e#  # a# n# d#  # S# i# g# m# o# i# d#  # F# u# n# c# t# i# o# n# ]# (# ## 4# .# 2# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 3# .#  # F# o# r# w# a# r# d#  # &#  # B# a# c# k# w# a# r# d#  # P# r# o# p# a# g# a# t# i# o# n# ]# (# ## 4# .# 3# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 4# .#  # U# p# d# a# t# i# n# g# (# l# e# a# r# n# i# n# g# )#  # P# a# r# a# m# e# t# e# r# s# ]# (# ## 4# .# 4# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 5# .#  # P# r# e# d# i# c# t# ]# (# ## 4# .# 5# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 6# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## 4# .# 6# )#  # <# b# r# ># 
#  #  # *#  # [# 4# .# 7# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # s# k# l# e# a# r# n# ]# (# ## 4# .# 7# )#  # <# b# r# ># 
# *#  # [# 5# .# C# o# n# c# l# u# s# i# o# n# ]# (# ## 5# )#  # <# b# r# >#  #  #  #  

# ## ##  # 1# .# I# n# t# r# o# d# u# c# t# i# o# n# 
# <# a#  # i# d# =# "# c# "# ># <# /# a# ># 
# I# n#  # t# h# i# s#  # k# e# r# n# e# l# ,#  # i#  # w# i# l# l#  # w# o# r# k#  # o# n#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# .# 
# ## ## ##  # W# h# a# t#  # i# s#  # t# h# e#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# *#  # W# h# e# n#  # d# a# t# a#  # h# a# v# e#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # (# o# u# t# p# u# t# s#  # :#  # 0#  # o# r#  # 1# )# ,#  # w# e#  # c# a# n#  # u# s# e#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n# .# 
# *#  # L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # a#  # p# r# e# d# i# c# t# i# v# e#  # a# n# a# l# y# s# i# s# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt 


# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# ## ##  # 2# .# I# m# p# o# r# t# i# n# g#  # d# a# t# a# s# e# t#  # a# n# d#  # d# a# t# a#  # p# r# e# p# r# o# c# e# s# s# i# n# g# 
# <# a#  # i# d# =# "# 2# "# ># <# /# a# >

# *#  # F# i# r# s# t#  # o# f#  # a# l# l#  # i#  # a# m#  # l# o# o# k# i# n# g#  # t# o#  # d# a# t# a# .# 
# *#  # I#  # a# m#  # c# h# e# c# h# i# n# g#  # t# h# e#  # c# o# l# u# m# s#  # a# n# d#  # i#  # m# u# s# t#  # d# r# o# p#  # t# h# e#  # c# o# l# u# m# n# s#  # w# h# i# c# h#  # i# s#  # n# o# t#  # r# e# l# a# t# i# n# g#  # w# i# t# h#  # m# y#  # p# r# e# d# i# c# t# i# o# n# s# .# 
# *#  # I# f#  # i#  # u# s# e#  # t# h# e#  # u# n# u# s# e# f# u# l# y#  # c# o# l# u# m# n# s#  # o# n#  # m# y#  # L# o# g# i# s# t# i# c# s#  # m# o# d# e# l# ,# i# t#  # n# e# g# a# t# i# v# e# l# y#  # a# f# f# e# c# t# s#  # o# n#  # m# o# d# e# l# .# 
# *#  # T# h# e# n#  # i#  # w# i# l# l#  # d# e# t# e# r# m# i# n# a# t# e#  # t# o#  # x# ,# y#  # v# a# l# u# e# s# 


# In[None]

data = pd.read_csv("../input/voice.csv")

# In[None]

data.head()

# In[None]

data.info()

# In[None]

data.label.value_counts()

# *#  # I#  # w# a# n# t#  # t# o#  # p# u# t#  # b# o# u# n# d# r# y#  # l# i# k# e#  # f# e# m# a# l# e#  # :#  # 0#  # ,#  # m# a# l# e#  # :#  # 1# 
# *#  # W# e# i# l#  # T# h# e#  # m# o# d# e# l#  # c# a# n#  # d# e# t# e# r# m# i# n# e#  # w# h# i# c# h#  # d# a# t# a#  # b# e# l# o# n# g# s#  # t# o#  # w# h# i# c# h#  # c# l# a# s# s#  # (# 0#  # o# r#  # 1# )# .

# In[None]

data.label = [0 if each=='female' else 1 for each in data.label]

# In[None]

data.head()

# In[None]

# I determined x and y
# y : outputs 
# x : features
y = data.label.values
x_data = data.drop(["label"],axis=1) 

# In[None]

y

# In[None]

x_data.head()

# In[None]

data.head()

# ## ##  # 3# .# N# o# r# m# a# l# i# z# a# t# i# o# n# 
# <# a#  # i# d# =# "# 3# "# ># <# /# a# >

# In[None]

#. I muss make all my data's values between 0 and 1. Because no one data should be affected by the size of other data. 
#normalization =(x-min(x))/(max(x)-min(x))
x = (x_data - np.min(x_data)) / (np.max(x_data)-np.min(x_data)).values

# In[None]

x.head()

# ## ##  # 4# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# <# a#  # i# d# =# "# 4# "# ># <# /# a# >

# ## ## ##  # 4# .# 1# .#  # T# r# a# i# n#  # a# n# d#  # T# e# s# t#  # S# p# l# i# t# 
# <# a#  # i# d# =# "# 4# .# 1# "# ># <# /# a# >

# In[None]

# we need x_train,x_test,y_train,y_test 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2005481.npy", { "accuracy_score": score })

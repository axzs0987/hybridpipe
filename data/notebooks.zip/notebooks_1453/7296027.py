import pandas as pd
# In[None]

#Gerekli Kütüphaneler Geliştirme Ortamına Dahil Ediliyor
import numpy as np # linear algebra
import pandas as pd # Veri işleme

# Visiualization tools
import matplotlib.pyplot as plt
import seaborn as sns

#Model Seçimi
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score


#Makine Öğrenmesi Modelleri
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC




#Metrikler
from sklearn.metrics import accuracy_score, confusion_matrix,classification_report

from sklearn.externals import joblib

#Sistem Kütüphaneleri
import os
#print(os.listdir("../input"))

# In[None]

import warnings
#Sonuçların okunmasını zorlaştırdığı için uyarıları kapatıyoruz
warnings.filterwarnings("ignore")
print("Uyarılar Kapatıldı")

# [# İ# ç# i# n# d# e# k# i# l# e# r#  # M# e# n# ü# s# ü# n# e#  # G# i# t# ]# (# ## 0# .# )# 
# 
# <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 2# .# "# ># <# /# a# ># *# *# V# e# r# i#  # S# e# t# i#  # H# a# k# k# ı# n# d# a#  # B# a# ğ# l# a# m# s# a# l#  # D# e# ğ# e# r# l# e# n# d# i# r# m# e# *# *#  # 
# 
# B# u#  # v# e# r# i#  # s# e# t# i# ,#  # H# i# n# d# i# s# t# a# n# '# ı# n#  # A# n# d# h# r# a#  # P# r# a# d# e# s# h#  # k# e# n# t# i# n# i# n#  # K# u# z# e# y# d# o# ğ# u# s# u# n# d# a# n#  # t# o# p# l# a# n# a# n#  # 4# 1# 6#  # k# a# r# a# c# i# ğ# e# r#  # h# a# s# t# a# s# ı#  # v# e#  # 1# 6# 7#  # k# a# r# a# c# i# ğ# e# r#  # d# ı# ş# ı#  # h# a# s# t# a#  # k# a# y# d# ı# n# ı#  # i# ç# e# r# m# e# k# t# e# d# i# r# .#  # "# D# a# t# a# s# e# t# "#  # s# ü# t# u# n# u# ,#  # g# r# u# p# l# a# r# ı#  # k# a# r# a# c# i# ğ# e# r#  # h# a# s# t# a# s# ı#  # v# e# y# a#  # o# l# m# a# y# a# n#  # (# h# a# s# t# a# l# ı# k# s# ı# z# )#  # a# y# ı# r# a# n#  # s# ı# n# ı# f# l# a# r#  # i# ç# e# r# i# r# .#  # B# u#  # v# e# r# i#  # s# e# t# i#  # 4# 4# 1#  # e# r# k# e# k#  # h# a# s# t# a#  # k# a# y# d# ı#  # v# e#  # 1# 4# 2#  # k# a# d# ı# n#  # h# a# s# t# a#  # k# a# y# d# ı# n# ı#  # i# ç# e# r# m# e# k# t# e# d# i# r# .# 
# 
# Y# a# ş# l# a# r# ı#  # 8# 9# '# u#  # a# ş# a# n#  # h# e# r# h# a# n# g# i#  # b# i# r#  # h# a# s# t# a#  # y# a# ş# ı#  # "# 9# 0# "#  #  # o# l# a# r# a# k#  # b# e# l# i# r# l# e# n# m# i# ş# t# i# r# .# 
# 
# S# ü# t# u# n# l# a# r# :# 
# 
# *#  # H# a# s# t# a# n# ı# n#  # y# a# ş# ı# 
# *#  # H# a# s# t# a# n# ı# n#  # C# i# n# s# i# y# e# t# i# 
# *#  # T# o# p# l# a# m#  # B# i# l# i# r# u# b# i# n# 
# *#  # D# o# ğ# r# u# d# a# n#  # b# i# l# i# r# u# b# i# n# 
# *#  # A# l# k# a# l# i#  # F# o# s# f# o# t# a# z# 
# *#  # A# l# a# m# i# n#  # A# m# i# n# o# t# r# a# n# s# f# e# r# a# z# 
# *#  # A# s# p# a# r# t# a# t#  # A# m# i# n# o# t# r# a# n# s# f# e# r# a# z# 
# *#  # T# o# p# l# a# m#  # P# r# o# t# i# e# n# s# 
# *#  # A# l# b# ü# m# i# n# 
# *#  # A# l# b# u# m# i# n#  # v# e#  # G# l# o# b# u# l# i# n#  # O# r# a# n# ı# 
# *#  # V# e# r# i#  # k# ü# m# e# s# i# (# H# e# d# e# f#  # d# e# ğ# i# ş# k# e# n# )# :#  # a# l# a# n# ı#  # i# k# i#  # k# ü# m# e# y# e#  # a# y# ı# r# m# a# k#  # i# ç# i# n#  # k# u# l# l# a# n# ı# l# a# n#  # a# l# a# n#  # (# k# a# r# a# c# i# ğ# e# r#  # h# a# s# t# a# l# ı# ğ# ı#  # o# l# a# n#  # y# a#  # d# a#  # h# a# s# t# a# l# ı# ğ# ı#  # o# l# m# a# y# a# n# )# 
# 


# In[None]

#veri setini pandas DataFrame olarak yüklüyoruz
dataset=pd.read_csv('../input/indian_liver_patient.csv')

#veri setine ait ilk beş satır; 
dataset.head()

# In[None]

# veri setindeki sayısal özelliklere ait özet istatistiksel bilgiler
# Gender özelliği sayısal olmayan değerler içerdiği için,istatistiksel verileri yoktur
dataset.describe().T

# Y# u# k# a# r# ı# d# a# k# i#  # t# a# b# l# o# d# a#  # v# e# r# i#  # s# e# t# i# n# i# n#  # i# s# t# a# t# i# k# s# e# l#  # ö# z# e# t# i#  # v# a# r# d# ı# r# .#  # H# e# r#  # b# i# r#  # ö# z# e# l# l# i# k#  # i# ç# i# n#  # a# d# e# t# ,#  # o# r# t# a# l# a# m# ,#  # s# t# a# n# d# a# r# t#  # s# a# p# m# a# ,#  # m# i# n# u# m# u# m#  # v# e#  # m# a# k# s# i# m# u# m#  # d# e# ğ# e# r# l# e# r#  # i# ç# e# r# m# e# k# t# e# d# i# r# .#  # T# a# b# l# o# d# a# k# i#  # d# e# ğ# e# r# l# e# r#  # v# e# r# i#  # s# e# t# i# n# i# n#  # ö# z# e# t# i# n# i#  # s# u# n# m# a# k# l# a#  # b# e# r# a# b# e# r#  # m# a# k# i# n# e#  # ö# ğ# r# e# n# m# e# s# i#  # m# o# d# e# l# i#  # i# ç# i# n#  # b# i# r#  # a# n# l# a# m#  # i# f# a# d# e#  # e# t# m# e# m# e# k# t# e# d# i# r# .#  # S# a# d# e# c# e#  # ö# z# e# l# l# i# k# l# e# r# i# n#  # d# e# ğ# e# r#  # a# r# a# l# ı# k# l# a# r# ı# n# ı# n#  # b# i# r# b# i# r# i# n# d# e# n#  # ç# o# k#  # f# a# r# k# l# ı#  # o# l# d# u# ğ# u#  # g# ö# r# ü# n# ü# y# o# r#  # o# l# m# a# s# ı# ,#  # n# o# r# m# a# l# l# e# ş# t# i# r# m# e#  # i# ş# l# e# m# i# n# i# n#  # y# a# p# ı# l# m# a# s# ı#  # g# e# r# e# k# i# t# i# ğ# i# n# i#  # g# ö# s# t# e# r# i# y# o# r# .#  

# In[None]

dataset.info()

# In[None]

#eksik veriler 'Albumin_and_Globulin_Ratio' sütununun ortalaması ile doldurulu
dataset['Albumin_and_Globulin_Ratio'].fillna(dataset['Albumin_and_Globulin_Ratio'].mean(), inplace=True)
dataset.info()

# In[None]

#'Dataset' sütünun adı 'target' olarak değitiriliyor
dataset.rename(columns={'Dataset':'target'},inplace=True)
dataset.head()

# 
# 
# ##  # <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 5# .# 2# .# "# ># <# /# a# ># *# *# C# i# n# s# i# y# e# t#  # T# e# ş# h# i# s# i#  # v# e#  #  # Y# ü# z# d# e# l# e# r# i# *# *#  #  # 
# 
# c# o# u# n# t# p# l# o# t# (# )#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# e# r# l# e# r# i# n#  # d# a# ğ# ı# l# ı# m# ı# n# ı#  # ö# z# e# t# l# e# m# e# d# e#  # b# a# ş# a# r# ı# l# ı#  # o# l# s# a# d# a# ,#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# e# r# l# e# r# i# n#  # y# ü# z# d# e# l# i# k#  # d# i# l# i# m# i#  # h# a# k# k# ı# n# d# a#  # a# ç# ı# k# l# a# y# ı# c# ı#  # d# e# ğ# i# l# d# i# r# .#  # P# i# e#  # c# h# a# r# t#  # y# ü# z# d# e# l# i# k#  # d# i# l# i# m# l# e# r# i#  # g# ö# s# t# e# r# m# e# d# e#  # d# a# h# a#  # b# a# ş# a# r# ı# l# ı# d# ı# r# .#  # S# e# a# b# o# r# n#  # k# ü# t# ü# p# h# a# n# e# s# i# n# d# e#  # p# i# e#  # c# h# a# r# t#  # o# l# m# a# d# ı# ğ# ı#  # i# ç# i# n#  # p# a# n# d# a# s#  # k# ü# t# ü# p# h# a# n# e# s# i# n# d# e#  # y# e# r#  # a# l# a# n#  # p# i# e#  # ç# i# z# i# m#  # f# o# n# k# s# i# y# o# n# u#  # k# u# l# l# a# n# ı# l# a# c# a# k# t# ı# r# .

# In[None]

target_counts=dataset['target'].value_counts().values
gender_counts=dataset['Gender'].value_counts().values

fig1, axes=plt.subplots(nrows=1, ncols=2,figsize=(10,5))
fig1.suptitle("Teşhis ve Cinsiyet Yüzdeleri")

target_sizes=dataset.groupby('target').size()
axes[0].pie(
    x=target_counts,
    labels=['patient({})'.format(target_sizes[1]),'not patient({})'.format(target_sizes[2])],
    autopct='%1.1f%%'
)
axes[0].set_title("Hasta Teşhis Yüzdeleri")

gender_sizes=dataset.groupby('Gender').size()
axes[1].pie(
    x=gender_counts, 
    labels=['male({})'.format(gender_sizes['Male']), 'female({})'.format(gender_sizes['Female'])], 
    autopct="%1.1f%%"
)
axes[1].set_title("Hastaların Cinsiyet Yüzdeleri")

# [# İ# ç# i# n# d# e# k# i# l# e# r#  # M# e# n# ü# s# ü# n# e#  # G# i# t# ]# (# ## 0# .# )# 
# 
# ##  # <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 5# .# e# 5# .# "# ># <# /# a# ># *# *# M# e# t# i# n#  # D# e# ğ# e# r# l# e# r# i# n# i# n#  # S# a# y# ı# s# a# l#  # D# e# ğ# e# r# l# e# r# e#  # D# ö# n# ü# ş# t# ü# r# ü# l# m# e# s# i# *# *#  #  # 
# 
# B# u#  # n# o# k# t# a# d# a# n#  # s# o# n# r# a#  # y# a# p# ı# l# a# c# a# k#  # g# ö# r# s# e# l# l# e# ş# t# i# r# m# e# l# e# r#  # i# ç# i# n#  # v# e# r# i#  # s# e# t# i# n# d# e# k# i#  # t# ü# m#  # ö# z# e# l# l# i# k# l# e# r# i# n#  # s# a# y# ı# s# a# l#  # d# e# ğ# e# r#  # i# ç# e# r# m# e# s# i#  # g# e# r# e# k# i# y# o# r# .#  # V# e# r# i#  # s# e# t# i# n# d# e#  # s# a# d# e# c# e#  # '# G# e# n# d# e# r# '#  # ö# z# e# l# l# i# ğ# i#  # s# a# y# ı# s# a# l#  # d# e# ğ# e# r#  # i# ç# e# r# m# e# m# e# k# t# e# d# i# r# .#  # B# u#  # ö# z# e# l# l# i# ğ# i# n#  # t# u# t# u# ğ# u#  # d# e# ğ# e# r# l# e# r# i# n#  # s# a# y# ı# s# a# l#  # d# ö# n# ü# ş# t# ü# r# ü# l# m# e# s# i#  # g# e# r# e# k# i# r# .#  # '# G# e# n# d# e# r# '#  # d# e# ğ# i# ş# k# e# n# i# n# d# e#  # i# k# i#  # f# a# r# k# l# ı#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# e# r#  # v# a# r# d# ı# r# ;#  # M# a# l# e# ,#  # F# e# m# a# l# e# .#  # B# u#  # i# k# i#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# e# r# i#  # n# o# m# i# n# a# l#  # y# a# p# ı# d# a# d# ı# r# .#  # Y# a# n# i#  # a# r# a# l# a# r# ı# n# d# a#  # b# ü# y# ü# k# l# ü# k#  # k# ü# ç# ü# k# l# ü# k#  # d# u# r# u# m# u#  # y# o# k# t# u# r# .#  # B# u#  # n# e# d# e# n# l# e#  # O# n# e# H# o# t#  # E# n# c# o# d# i# n# g#  # y# ö# n# t# e# m# i# y# l# e#  # s# a# y# ı# s# a# l# a#  # d# ö# n# ü# ş# t# ü# r# ü# l# m# e# s# i#  # g# e# r# e# k# i# r# .#  #  # 
# 
# P# a# n# d# a# s#  # D# a# t# a# F# r# a# m# e#  # n# e# s# n# e# s# i# n# d# e#  # y# e# r#  # a# l# a# n#  # g# e# t# _# d# u# m# m# i# e# s# (# )#  # f# o# n# k# s# i# y# o# n# u#  # v# e# r# i#  # s# e# t# i# n# d# e#  # s# t# r# i# n# g#  # o# l# a# n#  # ö# z# e# l# l# i# k# l# e# r# i# n#  # s# a# y# ı# s# a# l#  # d# e# ğ# e# r# e#  # d# ö# n# ü# ş# ü# m# ü# n# ü#  # O# n# e# H# o# t#  # E# n# c# o# d# i# n# g#  # y# ö# n# t# e# m# i# y# l# e#  # y# a# p# m# a# k# t# a# d# ı# r# .#  

# In[None]

dataset=pd.get_dummies(dataset)

# In[None]

corr_matrix=dataset.corr()
fig, ax = plt.subplots(figsize=(12,12))
sns.heatmap(corr_matrix,annot=True,linewidths=.5, ax=ax)

# 
# 
# ##  # <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 6# .# "# ># <# /# a# ># *# *# M# a# k# i# n# e#  # Ö# ğ# r# e# n# m# e# s# i#  # M# o# d# e# l# i# n# i# n#  # K# u# l# l# a# n# ı# l# m# a# s# ı# *# *#  #  # 
# 
# V# e# r# i#  # s# e# t# i# n# i# n#  # m# a# k# i# n# e#  # ö# ğ# r# e# n# m# e# s# i#  # m# o# d# e# l# i# n# e#  # v# e# r# i# l# m# e# d# e# n#  # ö# n# c# e#  # y# a# p# ı# l# m# a# s# ı#  # g# e# r# e# k# e# n#  # i# ş# l# e# m# l# e# r# :# 
# 1# .#  # V# e# r# i#  # s# e# t# i# n# i# n#  # d# a# t# a#  # v# e#  # t# a# r# g# e# t#  # o# l# a# r# a# k#  # a# y# r# ı# ş# t# ı# r# ı# l# m# a# s# ı# ;#  # X# ,#  # y# 
# 1# .#  # D# a# t# a#  # k# ı# s# m# ı# n# ı# n#  # n# o# r# m# a# l# l# e# ş# t# i# r# i# l# m# e# s# i#  # 
# 1# .#  # D# a# t# a#  # v# e#  # t# a# r# g# e# t#  # ı# n#  # e# ğ# i# t# i# m#  # v# e#  # t# e# s# t#  # k# ü# m# e# l# e# r# i# n# e#  # a# y# r# ı# ş# l# t# ı# r# ı# l# m# a# s# ı

# 
# ##  # <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 6# .# 1# .# "# ># <# /# a# ># *# *# V# e# r# i#  # S# e# t# i# n# i# n#  # '# d# a# t# a# '#  # v# e#  # '# t# a# r# g# e# t# '#  # O# l# a# r# a# k#  # A# y# r# ı# ş# t# ı# r# ı# l# m# a# s# ı# *# *#  #  

# In[None]

#Veri seti data ve target olarak ayrıştırılır
X=dataset.drop('target', axis=1) #data
y=dataset['target'] # target

# 
# 
# ##  # <# a#  # c# l# a# s# s# =# "# a# n# c# h# o# r# "#  # i# d# =# "# 6# .# 3# .# "# ># <# /# a# ># *# *# V# e# r# i#  # S# e# t# i# n# i# n#  # E# ğ# i# t# i# m#  # v# e#  # T# e# s# t#  # B# ö# l# ü# m# l# e# r# i# n# e#  # A# y# r# ı# ş# t# ı# r# ı# l# m# a# s# ı# *# *#  #  

# In[None]

#Eğitim ve test kümelerine ayrıştırılır
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7296027.npy", { "accuracy_score": score })

import pandas as pd
# ##  # A# l# a# d# d# i# n#  # A# w# e# s# o# m# e#  # S# e# s# s# i# o# n#  

# S# o# u# r# c# e# :# 
# 
# P# a# u# l# o#  # C# o# r# t# e# z# ,#  # U# n# i# v# e# r# s# i# t# y#  # o# f#  # M# i# n# h# o# ,#  # G# u# i# m# a# r# Ã# £# e# s# ,#  # P# o# r# t# u# g# a# l# ,#  # h# t# t# p# :# /# /# w# w# w# 3# .# d# s# i# .# u# m# i# n# h# o# .# p# t# /# p# c# o# r# t# e# z# 
# 
# 
# D# a# t# a#  # S# e# t#  # I# n# f# o# r# m# a# t# i# o# n# :# 
# 
# T# h# i# s#  # d# a# t# a#  # a# p# p# r# o# a# c# h#  # s# t# u# d# e# n# t#  # a# c# h# i# e# v# e# m# e# n# t#  # i# n#  # s# e# c# o# n# d# a# r# y#  # e# d# u# c# a# t# i# o# n#  # o# f#  # t# w# o#  # P# o# r# t# u# g# u# e# s# e#  # s# c# h# o# o# l# s# .#  # T# h# e#  # d# a# t# a#  # a# t# t# r# i# b# u# t# e# s#  # i# n# c# l# u# d# e#  # s# t# u# d# e# n# t#  # g# r# a# d# e# s# ,#  # d# e# m# o# g# r# a# p# h# i# c# ,#  # s# o# c# i# a# l#  # a# n# d#  # s# c# h# o# o# l#  # r# e# l# a# t# e# d#  # f# e# a# t# u# r# e# s# )#  # a# n# d#  # i# t#  # w# a# s#  # c# o# l# l# e# c# t# e# d#  # b# y#  # u# s# i# n# g#  # s# c# h# o# o# l#  # r# e# p# o# r# t# s#  # a# n# d#  # q# u# e# s# t# i# o# n# n# a# i# r# e# s# .#  # T# w# o#  # d# a# t# a# s# e# t# s#  # a# r# e#  # p# r# o# v# i# d# e# d#  # r# e# g# a# r# d# i# n# g#  # t# h# e#  # p# e# r# f# o# r# m# a# n# c# e#  # i# n#  # t# w# o#  # d# i# s# t# i# n# c# t#  # s# u# b# j# e# c# t# s# :#  # M# a# t# h# e# m# a# t# i# c# s#  # (# m# a# t# )#  # a# n# d#  # P# o# r# t# u# g# u# e# s# e#  # l# a# n# g# u# a# g# e#  # (# p# o# r# )# .#  # I# n#  # [# C# o# r# t# e# z#  # a# n# d#  # S# i# l# v# a# ,#  # 2# 0# 0# 8# ]# ,#  # t# h# e#  # t# w# o#  # d# a# t# a# s# e# t# s#  # w# e# r# e#  # m# o# d# e# l# e# d#  # u# n# d# e# r#  # b# i# n# a# r# y# /# f# i# v# e# -# l# e# v# e# l#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# n# d#  # r# e# g# r# e# s# s# i# o# n#  # t# a# s# k# s# .#  # I# m# p# o# r# t# a# n# t#  # n# o# t# e# :#  # t# h# e#  # t# a# r# g# e# t#  # a# t# t# r# i# b# u# t# e#  # G# 3#  # h# a# s#  # a#  # s# t# r# o# n# g#  # c# o# r# r# e# l# a# t# i# o# n#  # w# i# t# h#  # a# t# t# r# i# b# u# t# e# s#  # G# 2#  # a# n# d#  # G# 1# .#  # T# h# i# s#  # o# c# c# u# r# s#  # b# e# c# a# u# s# e#  # G# 3#  # i# s#  # t# h# e#  # f# i# n# a# l#  # y# e# a# r#  # g# r# a# d# e#  # (# i# s# s# u# e# d#  # a# t#  # t# h# e#  # 3# r# d#  # p# e# r# i# o# d# )# ,#  # w# h# i# l# e#  # G# 1#  # a# n# d#  # G# 2#  # c# o# r# r# e# s# p# o# n# d#  # t# o#  # t# h# e#  # 1# s# t#  # a# n# d#  # 2# n# d#  # p# e# r# i# o# d#  # g# r# a# d# e# s# .#  # I# t#  # i# s#  # m# o# r# e#  # d# i# f# f# i# c# u# l# t#  # t# o#  # p# r# e# d# i# c# t#  # G# 3#  # w# i# t# h# o# u# t#  # G# 2#  # a# n# d#  # G# 1# ,#  # b# u# t#  # s# u# c# h#  # p# r# e# d# i# c# t# i# o# n#  # i# s#  # m# u# c# h#  # m# o# r# e#  # u# s# e# f# u# l#  # (# s# e# e#  # p# a# p# e# r#  # s# o# u# r# c# e#  # f# o# r#  # m# o# r# e#  # d# e# t# a# i# l# s# )# .# 
# 
# 
# A# t# t# r# i# b# u# t# e#  # I# n# f# o# r# m# a# t# i# o# n# :# 
# 
# ##  # A# t# t# r# i# b# u# t# e# s#  # f# o# r#  # b# o# t# h#  # s# t# u# d# e# n# t# -# m# a# t# .# c# s# v#  # (# M# a# t# h#  # c# o# u# r# s# e# )#  # a# n# d#  # s# t# u# d# e# n# t# -# p# o# r# .# c# s# v#  # (# P# o# r# t# u# g# u# e# s# e#  # l# a# n# g# u# a# g# e#  # c# o# u# r# s# e# )#  # d# a# t# a# s# e# t# s# :# 
# 1# .#  # s# c# h# o# o# l#  # -#  # s# t# u# d# e# n# t# '# s#  # s# c# h# o# o# l#  # (# b# i# n# a# r# y# :#  # '# G# P# '#  # -#  # G# a# b# r# i# e# l#  # P# e# r# e# i# r# a#  # o# r#  # '# M# S# '#  # -#  # M# o# u# s# i# n# h# o#  # d# a#  # S# i# l# v# e# i# r# a# )# 
# 2# .#  # s# e# x#  # -#  # s# t# u# d# e# n# t# '# s#  # s# e# x#  # (# b# i# n# a# r# y# :#  # '# F# '#  # -#  # f# e# m# a# l# e#  # o# r#  # '# M# '#  # -#  # m# a# l# e# )# 
# 3# .#  # a# g# e#  # -#  # s# t# u# d# e# n# t# '# s#  # a# g# e#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1# 5#  # t# o#  # 2# 2# )# 
# 4# .#  # a# d# d# r# e# s# s#  # -#  # s# t# u# d# e# n# t# '# s#  # h# o# m# e#  # a# d# d# r# e# s# s#  # t# y# p# e#  # (# b# i# n# a# r# y# :#  # '# U# '#  # -#  # u# r# b# a# n#  # o# r#  # '# R# '#  # -#  # r# u# r# a# l# )# 
# 5# .#  # f# a# m# s# i# z# e#  # -#  # f# a# m# i# l# y#  # s# i# z# e#  # (# b# i# n# a# r# y# :#  # '# L# E# 3# '#  # -#  # l# e# s# s#  # o# r#  # e# q# u# a# l#  # t# o#  # 3#  # o# r#  # '# G# T# 3# '#  # -#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 3# )# 
# 6# .#  # P# s# t# a# t# u# s#  # -#  # p# a# r# e# n# t# '# s#  # c# o# h# a# b# i# t# a# t# i# o# n#  # s# t# a# t# u# s#  # (# b# i# n# a# r# y# :#  # '# T# '#  # -#  # l# i# v# i# n# g#  # t# o# g# e# t# h# e# r#  # o# r#  # '# A# '#  # -#  # a# p# a# r# t# )# 
# 7# .#  # M# e# d# u#  # -#  # m# o# t# h# e# r# '# s#  # e# d# u# c# a# t# i# o# n#  # (# n# u# m# e# r# i# c# :#  # 0#  # -#  # n# o# n# e# ,#  # 1#  # -#  # p# r# i# m# a# r# y#  # e# d# u# c# a# t# i# o# n#  # (# 4# t# h#  # g# r# a# d# e# )# ,#  # 2#  # â# €# “#  # 5# t# h#  # t# o#  # 9# t# h#  # g# r# a# d# e# ,#  # 3#  # â# €# “#  # s# e# c# o# n# d# a# r# y#  # e# d# u# c# a# t# i# o# n#  # o# r#  # 4#  # â# €# “#  # h# i# g# h# e# r#  # e# d# u# c# a# t# i# o# n# )# 
# 8# .#  # F# e# d# u#  # -#  # f# a# t# h# e# r# '# s#  # e# d# u# c# a# t# i# o# n#  # (# n# u# m# e# r# i# c# :#  # 0#  # -#  # n# o# n# e# ,#  # 1#  # -#  # p# r# i# m# a# r# y#  # e# d# u# c# a# t# i# o# n#  # (# 4# t# h#  # g# r# a# d# e# )# ,#  # 2#  # â# €# “#  # 5# t# h#  # t# o#  # 9# t# h#  # g# r# a# d# e# ,#  # 3#  # â# €# “#  # s# e# c# o# n# d# a# r# y#  # e# d# u# c# a# t# i# o# n#  # o# r#  # 4#  # â# €# “#  # h# i# g# h# e# r#  # e# d# u# c# a# t# i# o# n# )# 
# 9# .#  # M# j# o# b#  # -#  # m# o# t# h# e# r# '# s#  # j# o# b#  # (# n# o# m# i# n# a# l# :#  # '# t# e# a# c# h# e# r# '# ,#  # '# h# e# a# l# t# h# '#  # c# a# r# e#  # r# e# l# a# t# e# d# ,#  # c# i# v# i# l#  # '# s# e# r# v# i# c# e# s# '#  # (# e# .# g# .#  # a# d# m# i# n# i# s# t# r# a# t# i# v# e#  # o# r#  # p# o# l# i# c# e# )# ,#  # '# a# t# _# h# o# m# e# '#  # o# r#  # '# o# t# h# e# r# '# )# 
# 1# 0# .#  # F# j# o# b#  # -#  # f# a# t# h# e# r# '# s#  # j# o# b#  # (# n# o# m# i# n# a# l# :#  # '# t# e# a# c# h# e# r# '# ,#  # '# h# e# a# l# t# h# '#  # c# a# r# e#  # r# e# l# a# t# e# d# ,#  # c# i# v# i# l#  # '# s# e# r# v# i# c# e# s# '#  # (# e# .# g# .#  # a# d# m# i# n# i# s# t# r# a# t# i# v# e#  # o# r#  # p# o# l# i# c# e# )# ,#  # '# a# t# _# h# o# m# e# '#  # o# r#  # '# o# t# h# e# r# '# )# 
# 1# 1# .#  # r# e# a# s# o# n#  # -#  # r# e# a# s# o# n#  # t# o#  # c# h# o# o# s# e#  # t# h# i# s#  # s# c# h# o# o# l#  # (# n# o# m# i# n# a# l# :#  # c# l# o# s# e#  # t# o#  # '# h# o# m# e# '# ,#  # s# c# h# o# o# l#  # '# r# e# p# u# t# a# t# i# o# n# '# ,#  # '# c# o# u# r# s# e# '#  # p# r# e# f# e# r# e# n# c# e#  # o# r#  # '# o# t# h# e# r# '# )# 
# 1# 2# .#  # g# u# a# r# d# i# a# n#  # -#  # s# t# u# d# e# n# t# '# s#  # g# u# a# r# d# i# a# n#  # (# n# o# m# i# n# a# l# :#  # '# m# o# t# h# e# r# '# ,#  # '# f# a# t# h# e# r# '#  # o# r#  # '# o# t# h# e# r# '# )# 
# 1# 3# .#  # t# r# a# v# e# l# t# i# m# e#  # -#  # h# o# m# e#  # t# o#  # s# c# h# o# o# l#  # t# r# a# v# e# l#  # t# i# m# e#  # (# n# u# m# e# r# i# c# :#  # 1#  # -#  # <# 1# 5#  # m# i# n# .# ,#  # 2#  # -#  # 1# 5#  # t# o#  # 3# 0#  # m# i# n# .# ,#  # 3#  # -#  # 3# 0#  # m# i# n# .#  # t# o#  # 1#  # h# o# u# r# ,#  # o# r#  # 4#  # -#  # ># 1#  # h# o# u# r# )# 
# 1# 4# .#  # s# t# u# d# y# t# i# m# e#  # -#  # w# e# e# k# l# y#  # s# t# u# d# y#  # t# i# m# e#  # (# n# u# m# e# r# i# c# :#  # 1#  # -#  # <# 2#  # h# o# u# r# s# ,#  # 2#  # -#  # 2#  # t# o#  # 5#  # h# o# u# r# s# ,#  # 3#  # -#  # 5#  # t# o#  # 1# 0#  # h# o# u# r# s# ,#  # o# r#  # 4#  # -#  # ># 1# 0#  # h# o# u# r# s# )# 
# 1# 5# .#  # f# a# i# l# u# r# e# s#  # -#  # n# u# m# b# e# r#  # o# f#  # p# a# s# t#  # c# l# a# s# s#  # f# a# i# l# u# r# e# s#  # (# n# u# m# e# r# i# c# :#  # n#  # i# f#  # 1# <# =# n# <# 3# ,#  # e# l# s# e#  # 4# )# 
# 1# 6# .#  # s# c# h# o# o# l# s# u# p#  # -#  # e# x# t# r# a#  # e# d# u# c# a# t# i# o# n# a# l#  # s# u# p# p# o# r# t#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 1# 7# .#  # f# a# m# s# u# p#  # -#  # f# a# m# i# l# y#  # e# d# u# c# a# t# i# o# n# a# l#  # s# u# p# p# o# r# t#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 1# 8# .#  # p# a# i# d#  # -#  # e# x# t# r# a#  # p# a# i# d#  # c# l# a# s# s# e# s#  # w# i# t# h# i# n#  # t# h# e#  # c# o# u# r# s# e#  # s# u# b# j# e# c# t#  # (# M# a# t# h#  # o# r#  # P# o# r# t# u# g# u# e# s# e# )#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 1# 9# .#  # a# c# t# i# v# i# t# i# e# s#  # -#  # e# x# t# r# a# -# c# u# r# r# i# c# u# l# a# r#  # a# c# t# i# v# i# t# i# e# s#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 2# 0# .#  # n# u# r# s# e# r# y#  # -#  # a# t# t# e# n# d# e# d#  # n# u# r# s# e# r# y#  # s# c# h# o# o# l#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 2# 1# .#  # h# i# g# h# e# r#  # -#  # w# a# n# t# s#  # t# o#  # t# a# k# e#  # h# i# g# h# e# r#  # e# d# u# c# a# t# i# o# n#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 2# 2# .#  # i# n# t# e# r# n# e# t#  # -#  # I# n# t# e# r# n# e# t#  # a# c# c# e# s# s#  # a# t#  # h# o# m# e#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 2# 3# .#  # r# o# m# a# n# t# i# c#  # -#  # w# i# t# h#  # a#  # r# o# m# a# n# t# i# c#  # r# e# l# a# t# i# o# n# s# h# i# p#  # (# b# i# n# a# r# y# :#  # y# e# s#  # o# r#  # n# o# )# 
# 2# 4# .#  # f# a# m# r# e# l#  # -#  # q# u# a# l# i# t# y#  # o# f#  # f# a# m# i# l# y#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # b# a# d#  # t# o#  # 5#  # -#  # e# x# c# e# l# l# e# n# t# )# 
# 2# 5# .#  # f# r# e# e# t# i# m# e#  # -#  # f# r# e# e#  # t# i# m# e#  # a# f# t# e# r#  # s# c# h# o# o# l#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # l# o# w#  # t# o#  # 5#  # -#  # v# e# r# y#  # h# i# g# h# )# 
# 2# 6# .#  # g# o# o# u# t#  # -#  # g# o# i# n# g#  # o# u# t#  # w# i# t# h#  # f# r# i# e# n# d# s#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # l# o# w#  # t# o#  # 5#  # -#  # v# e# r# y#  # h# i# g# h# )# 
# 2# 7# .#  # D# a# l# c#  # -#  # w# o# r# k# d# a# y#  # a# l# c# o# h# o# l#  # c# o# n# s# u# m# p# t# i# o# n#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # l# o# w#  # t# o#  # 5#  # -#  # v# e# r# y#  # h# i# g# h# )# 
# 2# 8# .#  # W# a# l# c#  # -#  # w# e# e# k# e# n# d#  # a# l# c# o# h# o# l#  # c# o# n# s# u# m# p# t# i# o# n#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # l# o# w#  # t# o#  # 5#  # -#  # v# e# r# y#  # h# i# g# h# )# 
# 2# 9# .#  # h# e# a# l# t# h#  # -#  # c# u# r# r# e# n# t#  # h# e# a# l# t# h#  # s# t# a# t# u# s#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 1#  # -#  # v# e# r# y#  # b# a# d#  # t# o#  # 5#  # -#  # v# e# r# y#  # g# o# o# d# )# 
# 3# 0# .#  # a# b# s# e# n# c# e# s#  # -#  # n# u# m# b# e# r#  # o# f#  # s# c# h# o# o# l#  # a# b# s# e# n# c# e# s#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 0#  # t# o#  # 9# 3# )# 
# 
# ##  # t# h# e# s# e#  # g# r# a# d# e# s#  # a# r# e#  # r# e# l# a# t# e# d#  # w# i# t# h#  # t# h# e#  # c# o# u# r# s# e#  # s# u# b# j# e# c# t# ,#  # M# a# t# h#  # o# r#  # P# o# r# t# u# g# u# e# s# e# :# 
# 3# 1# .#  # G# 1#  # -#  # f# i# r# s# t#  # p# e# r# i# o# d#  # g# r# a# d# e#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 0#  # t# o#  # 2# 0# )# 
# 3# 1# .#  # G# 2#  # -#  # s# e# c# o# n# d#  # p# e# r# i# o# d#  # g# r# a# d# e#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 0#  # t# o#  # 2# 0# )# 
# 3# 2# .#  # G# 3#  # -#  # f# i# n# a# l#  # g# r# a# d# e#  # (# n# u# m# e# r# i# c# :#  # f# r# o# m#  # 0#  # t# o#  # 2# 0# ,#  # o# u# t# p# u# t#  # t# a# r# g# e# t# )

# In[None]


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import accuracy_score
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn import metrics
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.neighbors import KNeighborsClassifier
from mlxtend.plotting import plot_decision_regions
from sklearn import tree
from sklearn.neighbors import NearestNeighbors
from sklearn import preprocessing
from pandas.plotting import parallel_coordinates


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))


# In[None]

df = pd.read_csv('/kaggle/input/student-grade-prediction/student-mat.csv', engine='python', header=0)
df.head()

# ## ##  # R# e# p# l# a# c# e#  # c# o# l# u# m# s#  # w# i# t# h#  # b# i# n# a# r# y#  # d# a# t# a# 


# In[None]

sexDummies = pd.get_dummies(df['sex'], prefix = 'sex')
parentDummies = pd.get_dummies(df['Pstatus'], prefix = 'parent')
fJobDummies = pd.get_dummies(df['Fjob'], prefix = 'fjob')
df = pd.concat([df, sexDummies, parentDummies, fJobDummies], axis=1)
df = df.drop(["sex", "Pstatus", 'Fjob'], axis=1)
df.head()


# In[None]

def getGoodGrade(g3, med):
    if(g3 > med): 
        return 1
    return 0

med = df['G3'].median();
df['grade'] = df.apply(lambda x: getGoodGrade(x['G3'], med), axis=1)
print(med)

# In[None]

plt.figure(figsize=(5,5))
plt.tight_layout()
seabornInstance.distplot(df['grade'])

# In[None]

plt.figure(figsize=(5,5))
plt.tight_layout()
seabornInstance.distplot(df['G3'])

# In[None]

plt.figure(figsize=(5,5))
plt.tight_layout()
seabornInstance.distplot(df['absences'])

# In[None]



# In[None]



binaryValues = df[["sex_M", "sex_F", "parent_A", "parent_T", "fjob_at_home", "failures", "fjob_at_home" , "fjob_health",  "fjob_other" , "fjob_services" , "fjob_teacher"]]
nominalValues = df[["Fedu", "Medu", "absences"]]
nominal_normValues=(nominalValues-nominalValues.min())/(nominalValues.max()-nominalValues.min())

X = pd.concat([binaryValues, nominal_normValues], axis=1)
y = df['grade']
X.head()

# ##  # L# i# n# e# a# r#  # R# e# g# r# e# s# s# i# o# n

# In[None]

y = df['G3']
X = pd.concat([nominalValues, binaryValues], axis=1);
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8566497.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("../input/heart-disease-uci/heart.csv")
data.head()
import seaborn as sns
x=data.iloc[:,0:13]
y=data.iloc[:,13:]
from sklearn.model_selection import cross_val_score
from catboost import CatBoostClassifier
cat=CatBoostClassifier(iterations=5)
#cross_val_score(cat,x,y,cv=3)
cat=CatBoostClassifier(iterations=50)
#cross_val_score(cat,x,y,cv=3)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42)
cat=CatBoostClassifier(iterations=150,learning_rate=1)
#cat.fit(X_train,y_train)
#ypred=cat.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(n_estimators=20)
#gb.fit(X_train,y_train)
#ypred=gb.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(n_estimators=10)
#gb.fit(X_train,y_train)
#ypred=gb.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()
#rfc.fit(X_train,y_train)
#ypred=rfc.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.decomposition import PCA
pca=PCA(n_components=3)
x_pca=pca.fit_transform(x)
from sklearn.model_selection import train_test_split
xp_train, xp_test, y_train, y_test = train_test_split(x_pca, y, test_size=0.25, random_state=42)
cat=CatBoostClassifier(iterations=150,learning_rate=1)
#cat.fit(xp_train,y_train)
#ypred=cat.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(n_estimators=10)
#gb.fit(xp_train,y_train)
#ypred=gb.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()
#rfc.fit(xp_train,y_train)
#ypred=rfc.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.decomposition import PCA
pca=PCA(n_components=10)
x_pca=pca.fit_transform(x)
from sklearn.model_selection import train_test_split
xp_train, xp_test, y_train, y_test = train_test_split(x_pca, y, test_size=0.25, random_state=42)
cat=CatBoostClassifier(iterations=150,learning_rate=1)
#cat.fit(xp_train,y_train)
#ypred=cat.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(n_estimators=10)
#gb.fit(xp_train,y_train)
#ypred=gb.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()
#rfc.fit(xp_train,y_train)
#ypred=rfc.predict(xp_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
import category_encoders as ce
count_encode=ce.CountEncoder(cols=["sex","cp","slope","thal"])
x_count=count_encode.fit_transform(x)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
Xco_train, Xco_test, y_train, y_test = train_test_split(x_count, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()
#rfc.fit(Xco_train,y_train)
#ypred=rfc.predict(Xco_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(n_estimators=10)
#gb.fit(Xco_train,y_train)
#ypred=gb.predict(Xco_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
from sklearn.model_selection import cross_val_score
from catboost import CatBoostClassifier
cat=CatBoostClassifier(iterations=5)
#cross_val_score(cat,x_count,y,cv=3)
cat=CatBoostClassifier(verbose=0)
#cat.fit(Xco_train,y_train)
#ypred=cat.predict(Xco_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(Xco_train, y_train)
y_pred = model.predict(Xco_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_classificationwithnewestfanciermethods.npy", { "accuracy_score": score })
import pandas as pd
if type(Xco_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainX.npy", Xco_train)
if type(Xco_train).__name__ == "Series":
    Xco_train.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainX.csv",encoding="gbk")
if type(Xco_train).__name__ == "DataFrame":
    Xco_train.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainX.csv",encoding="gbk")

if type(Xco_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationwithnewestfanciermethods/testX.npy", Xco_test)
if type(Xco_test).__name__ == "Series":
    Xco_test.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/testX.csv",encoding="gbk")
if type(Xco_test).__name__ == "DataFrame":
    Xco_test.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationwithnewestfanciermethods/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_classificationwithnewestfanciermethods/testY.csv",encoding="gbk")


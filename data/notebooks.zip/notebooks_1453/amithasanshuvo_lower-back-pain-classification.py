import pandas as pd
import seaborn as sns
data = pd.read_csv('../input/lower-back-pain-symptoms-dataset/Dataset_spine.csv')
data.head()
data.tail()
data.info()
data.shape
del data["Unnamed: 13"]
data.describe()
data.rename(columns = {    "Col1" : "pelvic_incidence",     "Col2" : "pelvic_tilt",    "Col3" : "lumbar_lordosis_angle",    "Col4" : "sacral_slope",     "Col5" : "pelvic_radius",    "Col6" : "degree_spondylolisthesis",     "Col7" : "pelvic_slope",    "Col8" : "direct_tilt",    "Col9" : "thoracic_slope",     "Col10" :"cervical_tilt",     "Col11" : "sacrum_angle",    "Col12" : "scoliosis_slope",     "Class_att" : "class"}, inplace=True)
data.head()
data.shape
data["class"].value_counts().sort_index().plot.barh()
data.corr()
#sns.heatmap(data[data.columns[0:13]].corr(),annot=True,cmap='viridis',square=True, vmax=1.0, vmin=-1.0, linewidths=0.2)
X = data.iloc[:,:-1].values
y = data.iloc[:,-1].values
from sklearn.preprocessing import StandardScaler
ss = StandardScaler()
X = ss.fit_transform(X)
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
print(X_train.shape, y_test.shape)
print(y_train.shape, y_test.shape)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,classification_report,roc_auc_score,auc
lr = LogisticRegression()
#lr.fit(X_train,y_train)
#y_pred = lr.predict(X_test)
import matplotlib.pyplot as plt
#cm = confusion_matrix(y_test,y_pred)
#plt.figure(figsize=(5,5))
#sns.heatmap(cm,annot=True,linewidths=.3)
#plt.show()
#print(classification_report(y_test,y_pred))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amithasanshuvo_lower-back-pain-classification.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/amithasanshuvo_lower-back-pain-classification/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amithasanshuvo_lower-back-pain-classification/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amithasanshuvo_lower-back-pain-classification/testY.csv",encoding="gbk")


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data = pd.read_csv('../input/500-person-gender-height-weight-bodymassindex/500_Person_Gender_Height_Weight_Index.csv')
data.head()
data.isnull().any()
data.info()
#sns.set_style('whitegrid')
#plt.rcParams['figure.figsize'] = (6, 6)
#sns.countplot(data['Index'], palette='YlGnBu')
#ax = plt.gca()
#ax.set_title("Histogram of Index")
#plt.rcParams['figure.figsize'] = (30, 10)
#sns.countplot(data['Height'], palette='YlGnBu')
#ax = plt.gca()
#ax.set_title("Histogram of Height")
#plt.rcParams['figure.figsize'] = (30, 10)
#sns.countplot(data['Weight'], palette='YlGnBu')
#ax = plt.gca()
#ax.set_title("Histogram of Weight")
#sns.jointplot(x='Weight', y='Height', data=data, kind='kde')
#sns.lmplot(x='Height', y='Weight', hue='Gender', data=data,           fit_reg=True, height=7, aspect=1.25, palette = "Accent")
#ax = plt.gca()
#ax.set_title("Height Vs Weight Data Grouped by Gender")
#sns.lmplot(x='Height', y='Weight', hue='Index', data=data,           fit_reg=True, height=7, aspect=1.25, palette='Accent')
#ax = plt.gca()
#ax.set_title("Height Vs Weight Data Grouped by Index")
male_data = data[data['Gender']=='Male']
female_data = data[data['Gender']=='Female']
male_data = data[data['Gender']=='Male']
female_data = data[data['Gender']=='Female']
#sns.lmplot(x='Height', y='Weight', hue='Index', data=male_data,           fit_reg=True, height=7, aspect=1.25,palette='Accent')
#ax = plt.gca()
#ax.set_title("Male Height Vs Weight Data Grouped by Index")
#sns.lmplot(x='Height', y='Weight', hue='Index', data=female_data,           fit_reg=True, height=7, aspect=1.25,palette='Accent')
#ax = plt.gca()
#ax.set_title("Female Height Vs Weight Data Grouped by Index")
data.corr()
#plt.rcParams['figure.figsize'] = (8, 7)
#sns.heatmap(data.corr(), annot=True)
#plt.rcParams['figure.figsize'] = (8, 7)
#sns.heatmap(male_data.corr(), annot=True)
#plt.rcParams['figure.figsize'] = (8, 7)
#sns.heatmap(female_data.corr(), annot=True)
data["Gender"] = data["Gender"].astype('category')
data["Gender_Enc"] = data["Gender"].cat.codes
data.head()
dummies = pd.get_dummies(data['Gender'])
data = data.join(dummies)
data.head()
data = data.drop(columns=['Male', 'Female'], axis=1)
data.head()
features = list(data.columns.values)
features.remove('Gender')
features.remove('Index')
X = data[features]
y = data['Index']
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.model_selection import *
from sklearn.metrics import confusion_matrix,classification_report, accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 3)
#knn.fit(X_train, y_train)
#y_pred = knn.predict(X_test)
from sklearn.metrics import confusion_matrix,classification_report, accuracy_score
from sklearn.model_selection import cross_val_score
#print(confusion_matrix(y_test,y_pred))
#print(classification_report(y_test,y_pred))
#score = np.mean(y_pred == y_test)
#print(score)
#error = np.mean(y_pred != y_test)
#print(error)
#sns.regplot(x=y_test, y=y_pred)
#fig = sns.jointplot(x=y_test, y=y_pred, kind='hex')
#x0, x1 = fig.ax_joint.get_xlim()
#y0, y1 = fig.ax_joint.get_ylim()
#lims = [max(x0, y0), min(x1, y1)]
#fig.ax_joint.plot(lims, lims, ':k')    
#df = pd.DataFrame({ 'ytest':y_test,'ypred':y_pred})
#sns.residplot('ytest','ypred',data=df) 



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aishmore_bmi-data-eda.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aishmore_bmi-data-eda/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aishmore_bmi-data-eda/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aishmore_bmi-data-eda/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aishmore_bmi-data-eda/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aishmore_bmi-data-eda/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aishmore_bmi-data-eda/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aishmore_bmi-data-eda/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aishmore_bmi-data-eda/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aishmore_bmi-data-eda/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aishmore_bmi-data-eda/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aishmore_bmi-data-eda/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aishmore_bmi-data-eda/testY.csv",encoding="gbk")


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
df = pd.read_csv("../input/churndata1/Churn_Modelling.csv")
df.head()
df.dtypes
np.unique(df.Gender)
df['Geography'] = df['Geography'].str.replace('France','1')
df['Geography'] = df['Geography'].str.replace('Germany','2')
df['Geography'] = df['Geography'].str.replace('Spain','3')
df['Gender'] = df['Gender'].str.replace('Female','0')
df['Gender'] = df['Gender'].str.replace('Male','1')
df.head(3)
df['Geography'] = df['Geography'].astype(int)
df['Gender'] = df['Gender'].astype(int)
df.dtypes
df.groupby(['Exited']).CreditScore.mean().plot.bar(color ='red')
#plt.ylim(600,660)
#plt.xticks([0,1],['Current','Exited'])
#plt.title('Average Credit Score by Exited')
#plt.xlabel('')
#plt.ylabel('Credit Score')
#plt.style.use('default')
df.groupby(['Gender']).Exited.count().plot.bar(color ='blue')
#plt.title('Count of Gender by Exited')
#plt.ylim(4000,5500)
#plt.ylabel('Total Number')
df.groupby(['Geography']).Exited.count().plot.pie(autopct='%.1f%%', labels = ['France','Germany','Spain'])
#plt.ylabel('')
df.groupby(['Tenure']).Exited.count().sort_values(ascending=False).head().plot.bar(color ='darkred')
#plt.ylim(900,1050)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df[['CreditScore', 'Geography', 'Gender', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary']], df.Exited, train_size=0.8, test_size=1-0.8, random_state=0)
Model = LogisticRegression()
#Model.fit(X_train,y_train)
#Model.predict(X_test)
#Model.score(X_test,y_test)
#Model.predict_proba(X_test)
#Model.coef_



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alexanderb43_bank-churn-modeling.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/alexanderb43_bank-churn-modeling/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/alexanderb43_bank-churn-modeling/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alexanderb43_bank-churn-modeling/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alexanderb43_bank-churn-modeling/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alexanderb43_bank-churn-modeling/testY.csv",encoding="gbk")


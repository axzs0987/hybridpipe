import pandas as pd
# In[17]

import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.metrics import classification_report, confusion_matrix 
from sklearn.preprocessing import StandardScaler 


# I# m# p# o# r# t#  # D# a# t# a# s# e# t#  # u# s# i# n# g#  # P# a# n# d# a# s

# In[3]

data_sky= pd.read_csv("../input/Skyserver_SQL2_27_2018 6_51_39 PM.csv",header = 0)
data_sky.head()

# In[5]

#Dropping the id feature
data_sky.drop(columns = ['objid'], inplace = True)
data_sky.head()

#Converting non-numeric data to numeric dataset
diag_map = {'STAR':1, 'GALAXY':2, 'QSO':3}
data_sky['class'] = data_sky['class'].map(diag_map)

#Preparing the data set
class_all = list(data_sky.shape)[0]
class_categories = list(data_sky['class'].value_counts())

print("The dataset has {} classes, {} stars, {} galaxies and {} quasars.".format(class_all, 
                                                                                 class_categories[0], 
                                                                                 class_categories[1],
                                                                                 class_categories[2]))
data_sky.describe()

# In[6]

#Creating training and test datasets
y = data_sky["class"].values
X = data_sky.drop(["class"], axis = 1)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4178815.npy", { "accuracy_score": score })

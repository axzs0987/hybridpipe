import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# Read Data
df = pd.read_csv("../input/voice.csv")
# First 5 Rows of Data
df.head()
df.columns
df.info()

sns.pairplot(df, hue='label', vars=['skew', 'kurt',
 'sp.ent', 'sfm', 'mode','meanfun',
 'meandom','dfrange'])
plt.show()

sns.countplot(df.label)
plt.show()

sns.scatterplot(x = 'skew', y = 'kurt', hue = 'label', data = df)
plt.show()

plt.figure(figsize=(20,10))
sns.heatmap(df.corr(), annot=True, linewidth=.5, fmt='.2f', linecolor = 'grey')
plt.show()

X = df.drop(['label'],axis=1)
y = df.label


from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2483517.npy", { "accuracy_score": score })

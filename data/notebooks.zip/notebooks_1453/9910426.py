import pandas as pd
# In[None]

from sklearn import linear_model
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# In[None]

dataset=pd.read_csv("/kaggle/input/advertising/advertising.csv")
dataset.head

# In[None]

dataset.isnull().sum()

# In[None]

sns.pairplot(dataset)

# In[None]

sns.pairplot(dataset,hue="Clicked on Ad")

# In[None]

y=dataset["Clicked on Ad"]
x=dataset.drop(["City","Ad Topic Line","Country","Timestamp"],axis=1)
x.head

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9910426.npy", { "accuracy_score": score })

import pandas as pd
# ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # o# f#  # D# i# g# i# t# a# l#  # S# k# y# 
# 
# T# h# i# s#  # k# e# r# n# e# l#  # i# s#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# a# s# k#  # w# i# t# h#  # K# N# N#  # a# n# d#  # R# a# n# d# o# m#  # F# o# r# e# s# t

# In[None]

# importing libraries
import numpy as np # linear algebra
import pandas as pd # data processing
import matplotlib.pyplot as plt
import seaborn as sns    # plots

from sklearn.model_selection import train_test_split  # for train-test split

from sklearn.neighbors import KNeighborsClassifier  # KNN
from sklearn.ensemble import RandomForestClassifier  # Random Forest

from sklearn.metrics import classification_report,confusion_matrix  # model performance report

import warnings
warnings.filterwarnings('ignore')

# L# e# t#  # u# s#  # n# o# w#  # s# t# a# r# t#  # o# f# f#  # w# i# t# h#  # l# o# a# d# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

# load data
df = pd.read_csv("../input/Skyserver_SQL2_27_2018 6_51_39 PM.csv")
df.head()

# ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # a# n# a# l# y# s# i# s

# In[None]

# a look into the data
df.info()

# L# o# o# k# s#  # l# i# k# e#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # h# e# r# e# .

# In[None]

df.describe()

# L# e# t# '# s#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # t# h# e#  # t# a# r# g# e# t#  # c# l# a# s# s#  # f# i# r# s# t# ,#  # t# o#  # h# a# v# e#  # a# n#  # i# d# e# a#  # o# f#  # i# t# s#  # d# i# s# t# r# i# b# u# t# i# o# n

# In[None]

# plot target class distribution
sns.countplot(x='class',data=df)

# H# e# r# e#  # w# e#  # s# e# e#  # t# h# a# t#  # a# p# p# r# o# x#  # 5# 0# 0# 0#  # o# f#  # t# h# e#  # t# a# r# g# e# t#  # c# l# a# s# s#  # i# s#  # '# G# a# l# a# x# y# '# ,#  # w# h# i# c# h#  # i# s#  # a# b# o# u# t#  # 5# 0# %#  # o# f#  # t# o# t# a# l# ,# 
# w# h# i# l# e# ,#  # w# e#  # h# a# v# e#  # 4# 0# %#  # a# s#  # '# S# t# a# r# '#  # a# n# d#  # o# n# l# y#  # 1# 0# %# ,#  # '# Q# S# O# '# .# 
# 
# L# e# t#  # u# s#  # n# o# w#  # s# t# u# d# y#  # t# h# e#  # r# e# l# a# t# i# o# n#  # w# i# t# h#  # s# o# m# e#  # f# e# a# t# u# r# e# s

# In[None]

plt.figure(figsize=(10,6))
sns.boxplot(x='class',y='dec',data=df,palette='coolwarm')

# In[None]

plt.figure(figsize=(10,6))
sns.violinplot(x='class',y='dec',data=df,palette='plasma')

# In[None]

# chnange target class to numeric
num = {'STAR':1,'GALAXY':2,'QSO':3}
df.replace({'class':num},inplace=True)

# In[None]

df.head()

# In[None]

df.corr()['class'].drop('class')

# w# e#  # c# a# n#  # s# e# e#  # s# o# m# e#  # t# h# e#  # v# e# r# y#  # l# o# w#  # c# o# r# r# e# l# a# t# e# d#  # v# a# r# i# a# b# l# e# s# ,#  # w# e#  # w# i# l# l#  # d# r# o# p#  # t# h# e# m#  # l# a# t# e# r# .# 
# 
# F# o# r#  # n# o# w# ,#  # w# e#  # w# i# l# l#  # s# t# u# d# y#  # t# h# e#  # r# e# l# a# t# i# o# n#  # w# i# t# h#  # s# o# m# e#  # g# o# o# d#  # c# o# r# r# e# l# a# t# e# d#  # v# a# r# i# a# b# l# e# s# .

# In[None]

plt.figure(figsize=(10,6))
sns.boxenplot(x='class',y='redshift',data=df,palette='winter')

# In[None]

plt.figure(figsize=(10,6))
sns.violinplot(x='class',y='mjd',data=df)

# In[None]

# an algorithm to find pairs with high correlation
# later we will drop one feature from each pair
features = ['ra', 'dec', 'u', 'g', 'r', 'i', 'z', 
            'run', 'camcol', 'field', 'specobjid', 
            'redshift', 'plate', 'mjd', 'fiberid']
for i in features:
    for j in features:
        if (df.corr()[i][j] >= 0.9) & (i != j):
            print(i,'\t',j)
        else:
            pass

# In[None]

# we also found some triplets, good that we got more features to drop
df.drop(['i','r','specobjid','mjd','objid','rerun'],axis=1,inplace=True)

# In[None]

# a function to select features wrt threshold
correlation = df.corr()['class'].drop('class')
def feat_select(threshold):
    abs_corr = correlation.abs()
    feat = abs_corr[abs_corr>threshold].index.tolist()
    X = df[feat]
    return X

# ## ##  # M# o# d# e# l# l# i# n# g

# In[None]

# using Random Forest
threshold = 0
rfc = RandomForestClassifier(n_estimators=100)
X = feat_select(threshold)
y = df['class']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2672686.npy", { "accuracy_score": score })

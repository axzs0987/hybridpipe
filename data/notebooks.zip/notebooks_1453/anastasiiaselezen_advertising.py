import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings                       
warnings.filterwarnings("ignore")
dataset = pd.read_csv('../input/advertising.csv')
dataset.head()
dataset.info()
dataset.duplicated().sum()
dataset.isnull().sum()
corrm = dataset.corr()
corrm['Clicked on Ad'].sort_values(ascending = False)
dataset['Clicked on Ad'].value_counts()
#sns.countplot(x = 'Clicked on Ad', data = dataset)
dataset.describe()
categ_cols = ['Ad Topic Line', 'City', 'Country']
dataset[categ_cols].describe(include = ['O'])
dataset['Timestamp'] = pd.to_datetime(dataset['Timestamp'])
dataset['Timestamp']
dataset['Year'] = dataset['Timestamp'].dt.year
dataset['Month'] = dataset['Timestamp'].dt.month
dataset['Day'] = dataset['Timestamp'].dt.day
dataset['Hour'] = dataset['Timestamp'].dt.hour
dataset['Weekday'] = dataset['Timestamp'].dt.dayofweek
dataset = dataset.drop(['Timestamp'], axis=1)
dataset.head(10)
#sns.pairplot(dataset, hue = 'Clicked on Ad',              vars = ['Daily Time Spent on Site', 'Age', 'Area Income', 'Daily Internet Usage'], palette = 'Greens_r')
dataset = dataset.drop(['Year'], axis=1)
#fig = plt.figure(figsize = (12,10))
#sns.heatmap(dataset.corr(), cmap='Greens', annot = True)
X = dataset.iloc[:,[0,1,2,3,6,9,10,11,12]].values
y = dataset.iloc[:,8].values
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.preprocessing import StandardScaler
standardScaler = StandardScaler()
X_train = standardScaler.fit_transform(X_train)
X_test = standardScaler.transform(X_test)
from sklearn.linear_model import LogisticRegression
log_rg = LogisticRegression()
#log_rg.fit(X_train, y_train)
#y_log_rg = log_rg.predict(X_test)
from sklearn.metrics import confusion_matrix
#cm = confusion_matrix(y_test, y_log_rg)
#sns.heatmap(cm,annot=True,fmt='3.0f',cmap="Greens")
#plt.title('Confusion matrix for Logistic Regression', y=1.05, size=15)
from sklearn.metrics import classification_report
#cr = classification_report(y_test, y_log_rg)
#print(cr)
from sklearn.naive_bayes import GaussianNB
naive_b = GaussianNB()
#naive_b.fit(X_train, y_train)
#y_naive = naive_b.predict(X_test)
from sklearn.metrics import confusion_matrix
#naive_cm = confusion_matrix(y_test, y_naive)
#sns.heatmap(naive_cm,annot=True,fmt='3.0f',cmap="Blues")
#plt.title('Confusion matrix for Naive Bayes', y=1.05, size=15)
from sklearn.metrics import classification_report
#naive_cr = classification_report(y_test, y_naive)
#print(naive_cr)
from sklearn.ensemble import RandomForestClassifier
randm_frst = RandomForestClassifier()
#randm_frst.fit(X_train, y_train)
#y_frst = randm_frst.predict(X_test)
from sklearn.metrics import confusion_matrix
#frst_cm = confusion_matrix(y_test, y_frst)
#sns.heatmap(frst_cm,annot=True,fmt='3.0f',cmap="Reds")
#plt.title('Confusion matrix for Random Forest', y=1.05, size=15)
from sklearn.metrics import classification_report
#frst_cr = classification_report(y_test, y_frst)
#print(frst_cr)
from sklearn.neighbors import KNeighborsClassifier
kneighbors = KNeighborsClassifier()
#kneighbors.fit(X_train, y_train)
#y_knn = kneighbors.predict(X_test)
from sklearn.metrics import confusion_matrix
#knn_cm = confusion_matrix(y_test, y_knn)
#sns.heatmap(knn_cm,annot=True,fmt='3.0f',cmap="mako")
#plt.title('Confusion matrix for K-Nearest Neighbors', y=1.05, size=15)
from sklearn.metrics import classification_report
#knn_cr = classification_report(y_test, y_knn)
#print(knn_cr)
from sklearn.metrics import f1_score
#f1_log = f1_score(y_test, y_log_rg)
#f1_naive = f1_score(y_test, y_naive)
#f1_frst = f1_score(y_test, y_frst)
#f1_knn = f1_score(y_test, y_knn)
from pandas import DataFrame
#scores = {'Model':  ['Logistic Regression','Naive_Bayes', 'Random Forest', 'KNN'],           'f1 score': [f1_log, f1_naive, f1_frst, f1_knn]}
#f1_scores = DataFrame (scores, columns = ['Model','f1 score'])
#f1_scores
#sns.barplot(x="Model", y="f1 score", data=f1_scores, palette="Greens_r")
from sklearn.model_selection import GridSearchCV
param_frst = [{"n_estimators": [10,100,200,300,500], "criterion": ["gini", "entropy"]}]
#grid_search_frst = GridSearchCV(estimator=randm_frst,                          param_grid=param_frst,                          scoring = 'accuracy',                          cv=10)
#grid_search_frst = grid_search_frst.fit(X_train, y_train)
#best_acc_frst = grid_search_frst.best_score_
#best_acc_frst
#best_params_frst = grid_search_frst.best_params_
#best_params_frst
from sklearn.model_selection import GridSearchCV
param_knn = [{"n_neighbors": range(1,10), "weights": ["uniform", "distance"]}]
#grid_search_knn = GridSearchCV(estimator=kneighbors,                          param_grid=param_knn,                          scoring = 'accuracy',                          cv=10)
#grid_search_knn = grid_search_knn.fit(X_train, y_train)
#best_acc_knn = grid_search_knn.best_score_
#best_acc_knn
#best_params_knn = grid_search_knn.best_params_
#best_params_knn
from sklearn.ensemble import RandomForestClassifier
randm_frst_imp = RandomForestClassifier(n_estimators=100, criterion='gini')
#randm_frst_imp.fit(X_train, y_train)
#y_frst_imp = randm_frst_imp.predict(X_test)
from sklearn.neighbors import KNeighborsClassifier
kneighbors_imp = KNeighborsClassifier(n_neighbors=5, weights= 'uniform')
#kneighbors_imp.fit(X_train, y_train)
#y_knn_imp = kneighbors_imp.predict(X_test)
#f1_frst_imp = f1_score(y_test, y_frst_imp)
#f1_knn_imp = f1_score(y_test, y_knn_imp)
#scores_imp = {'Model':  ['Logistic Regression','Naive_Bayes', 'Random Forest', 'KNN'],           'f1 score': [f1_log, f1_naive, f1_frst_imp, f1_knn_imp]}
#f1_scores_imp = DataFrame (scores_imp, columns = ['Model','f1 score'])
#f1_scores_imp.sort_values(by=['f1 score'], ascending=False)
#frst_imp_cm = confusion_matrix(y_test, y_frst_imp)
#sns.heatmap(frst_imp_cm,annot=True,fmt='3.0f',cmap="PuBu_r")
#plt.title('Confusion matrix for Random Forest with hyperparameters', y=1.05, size=15)
from sklearn.metrics import roc_auc_score
#lr_auc = roc_auc_score(y_test, log_rg.predict(X_test))
#rf_roc_auc = roc_auc_score(y_test, randm_frst_imp.predict(X_test))
from sklearn.metrics import roc_curve
#fpr, tpr, thresholds = roc_curve(y_test, log_rg.predict_proba(X_test)[:,1])
#rf_fpr, rf_tpr, rf_thresholds = roc_curve(y_test, randm_frst_imp.predict_proba(X_test)[:,1])
#plt.figure()
#plt.plot(rf_fpr, rf_tpr, label='Random Forest Classifier (area = %0.2f)' % rf_roc_auc)
#plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % lr_auc)
#plt.plot([0,1], [0,1],label='Base Rate')
#plt.xlim([0.0, 1.0])
#plt.ylim([0.0, 1.10])
#plt.xlabel('False Positive Rate')
#plt.ylabel('True Positive Rate')
#plt.title('ROC Curve')
#plt.legend(loc="lower right")
#plt.show()



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anastasiiaselezen_advertising.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anastasiiaselezen_advertising/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anastasiiaselezen_advertising/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anastasiiaselezen_advertising/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anastasiiaselezen_advertising/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anastasiiaselezen_advertising/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anastasiiaselezen_advertising/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anastasiiaselezen_advertising/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anastasiiaselezen_advertising/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anastasiiaselezen_advertising/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anastasiiaselezen_advertising/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anastasiiaselezen_advertising/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anastasiiaselezen_advertising/testY.csv",encoding="gbk")


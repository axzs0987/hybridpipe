import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
ad_data = pd.read_csv('../input/advertising/advertising.csv')
ad_data.head()
ad_data.info()
ad_data.describe()
#sns.set_style('whitegrid')
ad_data['Age'].hist(bins=30)
#plt.xlabel('Age')
#sns.jointplot(x='Age',y='Area Income',data=ad_data)
#sns.jointplot(x='Age',y='Daily Time Spent on Site',data=ad_data,color='red',kind='kde')
#sns.jointplot(x='Daily Time Spent on Site',y='Daily Internet Usage',data=ad_data,color='green')
#sns.pairplot(ad_data,hue='Clicked on Ad',palette='bwr')
from sklearn.model_selection import train_test_split
X = ad_data[['Daily Time Spent on Site', 'Age', 'Area Income','Daily Internet Usage', 'Male']]
y = ad_data['Clicked on Ad']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression()
#logmodel.fit(X_train,y_train)
#predictions = logmodel.predict(X_test)
from sklearn.metrics import classification_report
#print(classification_report(y_test,predictions))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/arpitsomani_advertisement-logistic-regression.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/arpitsomani_advertisement-logistic-regression/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/arpitsomani_advertisement-logistic-regression/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/arpitsomani_advertisement-logistic-regression/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/arpitsomani_advertisement-logistic-regression/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/arpitsomani_advertisement-logistic-regression/testY.csv",encoding="gbk")


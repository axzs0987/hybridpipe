import pandas as pd
# T# h# i# s#  # a#  # n# o# t# e# b# o# o# k#  # f# o# r#  # t# h# e#  # M# e# d# i# c# a# l#  # N# o#  # S# h# o# w#  # A# p# p# o# i# n# t# m# e# n# t# s#  # d# a# t# a# .#  # W# e#  # w# i# l# l#  # a# p# p# l# y#  # s# o# m# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l# s#  # o# n#  # i# t#  # s# o#  # s# e# e#  # i# f#  # w# e#  # c# o# u# l# d#  # p# r# e# d# i# c# t#  # s# h# o# w# i# n# g#  # o# r#  # n# o# t#  # s# h# o# w# i# n# g#  # p# r# o# p# a# b# i# l# i# t# y#  # c# o# r# r# e# c# t# l# y# .

# In[None]

#Importing Libraries

import numpy as np 
import pandas as pd 

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import MinMaxScaler

from sklearn.feature_selection import SelectPercentile
from sklearn.feature_selection import f_classif 

from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import GradientBoostingClassifier

from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score

# In[None]

#Reading Data in

data = pd.read_csv('../input/noshowappointments/KaggleV2-May-2016.csv')

# In[None]

data.info()

# In[None]

data.shape

# In[None]

data.head(10)

# In[None]

data.tail(10)

# In[None]

#Renaming columns to have all the headers in lowercase to avoid confusing

data.rename(columns = lambda x: x.strip().lower().replace("-", "_"), inplace=True)

# In[None]

#Checking columns new names

data.head()

# In[None]

#Creating a list contains columns names for faster itering over them

columns_list = data.columns.to_list()
columns_list

# In[None]

#Exploring unique values for each column to understand what we are dealing with

for column in columns_list:
    print(data[column].unique())
    print('')

# In[None]

# Now we'll start manpulating our data to prepare it for further exploring

#Removing unwanted data .. we don't need patientid and appointmentid

data.drop(['patientid', 'appointmentid'], axis = 1, inplace = True)

# In[None]

#Checking modifications

data.head()

# F# i# x# i# n# g#  # a# g# e#  # c# o# l# u# m# n#  # i# s# s# u# e# s# 
# 
# F# r# o# m#  # u# n# i# q# u# e#  # v# a# l# u# e# s#  # s# h# o# w# i# n# g#  # w# e#  # f# o# u# n# d#  # a# g# e# s#  # w# i# t# h#  # 0# ,#  # -# 1#  # v# a# l# u# e# s# 
# 
# '# 0# '#  # v# a# l# u# e# s#  # m# a# y#  # r# e# p# r# e# s# e# n# t#  # b# a# b# i# e# s#  # w# i# t# h#  # o# n# l# y#  # m# o# n# t# h# s#  # a# g# e#  # b# u# t# '# -# 1# '#  # d# o# e# s# n# '# t#  # m# a# k# e#  # a# n# y#  # s# e# n# s# e#  # w# e#  # n# e# e# d#  # t# o#  # c# o# r# r# e# c# t#  # t# h# a# t

# In[None]

#We will drop rows with ages as '-1'

data = data[data.age >= 0]

# In[None]

#Checking modifications

data.age.unique()

# In[None]

#Now we need to deal with date columns 

#First we will convert them to datetime type instead of object

data['scheduledday'] = pd.to_datetime(data['scheduledday']).astype('datetime64[ns]')

data['appointmentday'] = pd.to_datetime(data['appointmentday']).astype('datetime64[ns]')

# In[None]

#Checking modificatoins

data.info()

# In[None]

data.head()

# In[None]

#We notice from tha data that all appointments time at zero hour
#So we will remove time component and deal with date and days only

data['scheduledday'] = data['scheduledday'].dt.date
data['appointmentday'] = data['appointmentday'].dt.date

# In[None]

data.head()

# In[None]

#Now we will create a new column that calculate the waiting time between scheduled and appointment

data['waiting_time_days'] = data['appointmentday'] - data['scheduledday']

data['waiting_time_days'] = data['waiting_time_days'].dt.days

# In[None]

data['waiting_time_days'].unique()

# In[None]

#Trere are some waiting days vaues in negative and that doesn't make sense
#We will drop those rows too

data = data[data.waiting_time_days >= 0]

# In[None]

#Check the data now
data['waiting_time_days'].unique()

# In[None]

data.info()

# In[None]

#We notice that the date type turned to object again, so I'll change it back

data['scheduledday'] = data['scheduledday'].astype('datetime64[ns]')

data['appointmentday'] = data['appointmentday'].astype('datetime64[ns]')

# In[None]

#Now we will get the weekday for scheduledday to see later if the weekday make a difference or not

data['scheduled_weekday'] = data['scheduledday'].apply(lambda time: time.dayofweek)

# In[None]

data.scheduled_weekday.unique()

# In[None]

data.head()

# In[None]

data.shape

# In[None]

data.info()

# In[None]

#We have here three columns (gender, neighbourhood, no_show) with object type that need to e changed to str
#So we can transform them with label encoder

data['gender'] = data['gender'].astype(str)

data['neighbourhood'] = data['neighbourhood'].astype(str)

data['no_show'] = data['no_show'].astype(str)

# In[None]

#Applying LabelEncoder on the following Features [gender, neighbourhood, no_show]

Encoder = LabelEncoder()

data['gender'] = Encoder.fit_transform(data['gender'])

data['neighbourhood'] = Encoder.fit_transform(data['neighbourhood'])

data['no_show'] = Encoder.fit_transform(data['no_show'])

# In[None]

#Now I'll drop [scheduledday, appointmentday] features, the give us no valuable info anymore

data = data.drop(['scheduledday', 'appointmentday'] , axis = 1, inplace = False)

# In[None]

#Checking the new data shape
data.shape

# In[None]

#Now we could proceed to classifications models
#First we will split features from output

#X Data
X = data.drop(['no_show'], axis = 1, inplace = False)

#y Data
y = data['no_show']

# In[None]

#Features shape

X.shape

# In[None]

#We'll try three normalizer to see what fit data the best

#Standard Scaler for Data

#scaler = StandardScaler(copy = True, with_mean = True, with_std = True)

#X = scaler.fit_transform(X)

# In[None]

#MinMaxScaler for Data

scaler = MinMaxScaler(copy = True, feature_range = (0, 1))

X = scaler.fit_transform(X)

#We foumd that min max scaler is the beat scaler to use with my data

# In[None]

#Normalizing Data

#scaler = Normalizer(copy = True, norm = 'l2') 

#X = scaler.fit_transform(X)

# In[None]

#Feature Selection by Percentile

FeatureSelection = SelectPercentile(score_func = f_classif, percentile = 50)

X = FeatureSelection.fit_transform(X, y)


# In[None]

#Splitting data (0.75 for train, 0.25 for test)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10554521.npy", { "accuracy_score": score })

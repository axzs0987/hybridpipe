import pandas as pd
# -#  # *# *# B# u# s# i# n# e# s# s#  # u# n# d# e# r# s# t# a# n# d# i# n# g# *# *# 
# 
# B# u# i# l# d#  # a#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # t# e# m# p# l# a# t# e#  # t# o#  # d# e# t# e# r# m# i# n# e#  # i# f#  # a# n#  # e# m# p# l# o# y# e# e#  # w# i# l# l#  # s# t# a# y#  # o# r#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .#  # W# e# ’# r# e#  # d# e# a# l# i# n# g#  # w# i# t# h#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # i# s# s# u# e# .#  # W# e#  # w# i# l# l#  # u# s# e#  # t# w# o#  # o# f#  # t# h# e#  # m# o# s# t#  # u# s# e# d#  # a# l# g# o# r# i# t# h# m# s#  # t# o#  # s# o# l# v# e#  # t# h# i# s#  # p# r# o# b# l# e# m# :#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k#  # a# n# d#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# .# 
# 
# *# *# T# u# r# n# o# v# e# r# *# *#  # d# e# s# i# g# n# a# t# e# s#  # i# n#  # a# n#  # e# n# t# e# r# p# r# i# s# e#  # t# h# e#  # r# e# n# e# w# a# l#  # o# f#  # t# h# e#  # w# o# r# k# f# o# r# c# e# ,#  # f# o# l# l# o# w# i# n# g#  # r# e# c# r# u# i# t# m# e# n# t#  # a# n# d#  # d# e# p# a# r# t# u# r# e# s#  # o# f#  # t# h# e#  # s# t# a# f# f# .#  # I# t#  # i# s#  # a#  # v# a# l# u# a# b# l# e#  # i# n# d# i# c# a# t# o# r#  # w# h# i# c# h#  # c# a# n#  # q# u# i# t# e#  # e# a# s# i# l# y#  # r# e# f# l# e# c# t#  # t# h# e#  # w# o# r# k#  # e# n# v# i# r# o# n# m# e# n# t#  # w# i# t# h# i# n#  # t# h# e#  # c# o# m# p# a# n# y# .#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # c# a# n#  # h# e# l# p#  # t# o#  # a# n# a# l# y# z# e#  # a# n# d#  # p# r# e# d# i# c# t#  # t# h# i# s#  # r# a# t# e#  # a# n# d#  # t# h# u# s#  # m# a# k# e#  # t# h# e#  # R# i# g# h# t#  # d# e# c# i# s# i# o# n# s# .

# In[None]

#importing the algorithme library
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

#The others library
from  sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_selection import SelectKBest
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn import model_selection

#this library import all library like pandas, numpy, matplotlib,seaborn.
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

#Evaluate our algorithme
from sklearn.metrics import roc_auc_score, roc_curve, accuracy_score,confusion_matrix,classification_report

# In[None]

data = pd.read_csv('/kaggle/input/ibm-attrition-analysis/WA_Fn-UseC_-HR-Employee-Attrition.csv')

# In[None]

data.head()

# In[None]

data.shape

# In[None]

data.info()

# In[None]

data.columns

# In[None]

# list of numeric variable
num_vars = [var for var in data.columns if data[var].dtypes != 'O']

print('Number of variable numeric: ', len(num_vars))

# show
data[num_vars].head()

# In[None]

# list of categorical variable
cat_vars = [var for var in data.columns if data[var].dtypes == 'O']

print('Number of variable categoric: ', len(cat_vars))

# show
data[cat_vars].head()

# In[None]

#display each values for each variable
for var in cat_vars:
    print(var, len(data[var].unique()), ' categories')

# In[None]

data["Age"].mode()
data["Age"].mean()

# In[None]

#Calculate the %(move) and %(stay) in Dataset
move = data[data['Attrition'] == "Yes"]
stay = data[data['Attrition'] == "No"]
print("moves: %i (%.1f%%)" %(len(move),(len(move)) / len(data)*100))
print("stay: %i (%.1f%%)" %(len(stay),(len(stay)) / len(data)*100))
print("Total: %i" %len(data))

# T# h# e#  # e# n# t# e# r# p# r# i# s# e#  # r# e# c# o# r# d# e# d#  # o# n# l# y#  # 2# 3# 7#  # d# e# p# a# r# t# u# r# e# s#  # e# i# t# h# e# r#  # *# *# 1# 6# .# 1# %# *# *#  # a# g# a# i# n# s# t#  # 1# 2# 3# 3#  # o# r#  # *# *# (# 8# 3# .# 9# %# )# *# *#  # o# u# t#  # o# f#  # a#  # t# o# t# a# l#  # o# f#  # 1# 4# 7# 0# .#  # F# o# r#  # t# h# e#  # m# o# d# e# l# l# i# n# g#  # o# f#  # o# u# r#  # m# o# d# e# l#  # w# e#  # c# a# n#  # s# a# y#  # g# o# l# d#  # a# n# d#  # a# l# r# e# a# d# y#  # t# h# a# t#  # t# h# e#  # d# a# t# a# s# e# t#  # i# s#  # u# n# b# a# l# a# n# c# e# d# .#  # I# n#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # s# e# c# t# i# o# n# s# ,#  # i# f#  # n# e# c# e# s# s# a# r# y# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # t# h# e#  # *# *# s# m# o# t# e# (# )# *# *#  # t# e# c# h# n# i# q# u# e#  # t# o#  # b# a# l# a# n# c# e#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n#  # o# r# d# e# r#  # t# o#  # m# a# k# e#  # i# t#  # e# f# f# i# c# i# e# n# t#  # i# n#  # o# r# d# e# r#  # t# o#  # h# a# v# e#  # a#  # b# e# t# t# e# r#  # *# *# a# c# c# u# r# a# c# y# *# *# .

# -#  # *# *# D# a# t# a#  # V# i# z# *# *# 
# 
# A# s#  # a#  # D# a# t# a#  # S# c# i# e# n# t# i# s# t# ,#  # y# o# u# r#  # j# o# b#  # i# s#  # n# o# t#  # o# n# l# y#  # t# o#  # i# n# t# e# r# p# r# e# t#  # a# n# d#  # a# n# a# l# y# z# e#  # t# h# e#  # d# a# t# a# ,#  # b# u# t#  # a# l# s# o#  # t# o#  # c# o# m# m# u# n# i# c# a# t# e#  # a# n# d#  # p# r# e# s# e# n# t#  # y# o# u# r#  # f# i# n# d# i# n# g# s# .#  # T# h# a# t# ’# s#  # w# h# y#  # i# t# ’# s#  # v# e# r# y#  # i# m# p# o# r# t# a# n# t#  # f# o# r#  # y# o# u#  # t# o#  # h# a# v# e#  # t# h# o# s# e#  # s# k# i# l# l# s# .

# In[None]

#Viz
import matplotlib.ticker as mtick
ax = (data['Attrition'].value_counts()*100.0 /len(data))\
.plot.pie(autopct='%.1f%%', labels = ['Stay', 'Move'],figsize =(5,5), fontsize = 12 )                                                                           
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.set_ylabel('Attrition',fontsize = 12)
ax.set_title('% Statistique RH', fontsize = 12)

# L# e# t# ’# s#  # c# r# e# a# t# e#  # s# o# m# e#  # i# n# t# e# r# e# s# t# i# n# g#  # v# i# z#  # o# n#  # t# h# e#  # i# m# p# a# c# t#  # o# f#  # a# t# t# r# i# t# i# o# n# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r#  # v# a# r# i# a# b# l# e# s

# In[None]

pd.crosstab(data["Department"],data["Attrition"]).plot(kind='bar')
plt.title('Attrition par Departement')
plt.xlabel('Department')
plt.ylabel('Fréquence')
plt.show()

# W# e#  # n# o# t# e#  # m# o# r# e#  # d# e# p# a# r# t# u# r# e# s#  # i# n#  # t# h# e#  # R# D#  # d# e# p# a# r# t# m# e# n# t# .#  # T# h# i# s#  # c# a# n#  # b# e#  # e# x# p# l# a# i# n# e# d#  # i# n#  # t# h# e#  # e# x# t# e# n# t#  # t# h# a# t#  # h# a# l# f#  # o# f#  # t# h# e#  # e# m# p# l# o# y# e# e# s#  # a# r# e#  # i# n#  # t# h# i# s#  # d# e# p# a# r# t# m# e# n# t# .

# In[None]

data["Department"].value_counts()

# In[None]

table=pd.crosstab(data["EducationField"], data["Attrition"])
table.div(table.sum(1).astype(float), axis=0).plot(kind='bar', stacked=True)
plt.title("Attrition en fonction de l'education")
plt.xlabel('Education')
plt.ylabel('Proportion Employé')
plt.show()

# -#  # *# *# D# a# t# a#  # P# r# o# c# e# s# s# i# n# g# *# *# 
# 
# 
# A# n#  # i# m# p# o# r# t# a# n# t#  # p# a# r# t#  # o# f#  # d# a# t# a#  # s# c# i# e# n# c# e#  # i# s#  # t# h# e#  # m# a# n# u# a# l#  # c# o# l# l# e# c# t# i# o# n#  # a# n# d#  # c# l# e# a# n# i# n# g#  # o# f#  # d# a# t# a# .#  # T# h# i# s#  # p# r# o# c# e# s# s#  # i# s#  # a# l# s# o#  # k# n# o# w# n#  # a# s#  # D# a# t# a#  # W# r# a# n# g# l# i# n# g#  # A# l# t# h# o# u# g# h#  # e# x# c# i# t# i# n# g#  # i# t#  # i# s#  # v# e# r# y#  # i# m# p# o# r# t# a# n# t#  # t# o#  # k# n# o# w#  # t# h# a# t#  # i# t#  # i# s#  # a#  # t# e# d# i# o# u# s#  # t# a# s# k#  # t# h# a# t#  # c# a# n#  # t# a# k# e#  # u# p#  # 8# 0# %#  # o# f#  # t# h# e#  # w# o# r# k#  # o# f#  # a#  # D# a# t# a#  # S# c# i# e# n# t# i# s# t# .

# In[None]

#Identified the nan values
data_nan = pd.isnull(data).sum()
data_nan

# O# u# r#  # d# a# t# a# s# e# t#  # i# s#  # c# l# e# a# n# .#  # A# c# t# u# a# l# l# y#  # I#  # d# i# d# n# ’# t#  # e# x# p# e# c# t#  # i# t# .#  # I# n#  # t# h# e#  # r# e# a# l#  # w# o# r# l# d#  # y# o# u#  # p# r# o# b# a# b# l# y#  # w# o# n# ’# t#  # h# a# v# e#  # d# a# t# a#  # t# h# a# t#  # c# l# e# a# n# .# 
# 
# T# h# a# n# k#  # y# o# u#  # I# B# M# !# !# !# !

# In[None]

#find the outliers
def find_outliers(df, var):
    df = df.copy()
    
    if 0 in data[var].unique():
        pass
    else:
        df[var] = np.log(df[var])
        df.boxplot(column=var)
        plt.title(var)
        plt.ylabel(var)
        plt.show()
    
for var in num_vars:
    find_outliers(data, var)

# S# o# m# e#  # v# a# r# i# a# b# l# e# s#  # h# a# v# e#  # e# x# t# r# e# m# e# s# .#  # T# h# i# s#  # i# s#  # t# h# e#  # c# a# s# e#  # o# f#  # D# a# i# l# y# r# a# t# e# ,#  # E# m# p# l# o# y# e# e# n# u# m# b# e# r# .#  # H# o# w# e# v# e# r# ,#  # i# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # k# n# o# w#  # t# h# a# t#  # t# h# e#  # m# a# n# a# g# e# m# e# n# t#  # o# f#  # i# t# s#  # o# u# t# l# i# e# r# s#  # r# e# q# u# i# r# e# s#  # a# n#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # o# f#  # t# h# e#  # b# u# s# i# n# e# s# s#  # a# n# d#  # t# h# i# s#  # i# s#  # o# f# t# e# n#  # s# u# b# j# e# c# t# i# v# e# .#  # F# r# o# m#  # m# y#  # l# i# t# t# l# e#  # e# x# p# e# r# i# e# n# c# e# ,#  # I#  # a# l# w# a# y# s#  # l# e# f# t#  # i# t# s#  # v# a# l# u# e# s#  # b# e# c# a# u# s# e#  # t# h# e# y#  # d# i# d#  # n# o# t#  # i# n# t# e# r# f# e# r# e#  # w# i# t# h#  # t# h# e#  # p# e# r# f# o# r# m# a# n# c# e#  # o# f#  # m# y#  # m# o# d# e# l# s#  # a# l# l#  # t# h# e#  # m# o# r# e#  # i# f#  # w# e#  # m# a# k# e#  # t# h# e#  # s# c# a# l# i# n# g#  # u# p#  # I# n#  # o# u# r#  # c# a# s# e# ,#  # w# e#  # d# e# c# i# d# e#  # t# o#  # k# e# e# p#  # t# h# e# m#  # i# n#  # o# u# r#  # m# o# d# e# l# .

# -#  # *# *# T# r# a# n# s# f# o# r# m# i# n# g#  # t# h# e#  # d# a# t# a#  # i# n#  # t# h# e#  # r# i# g# h# t#  # f# o# r# m# a# t# *# *# 
# 
# W# e#  # u# s# e#  # L# a# b# e# l# E# n# c# o# d# e# r#  # t# e# c# h# n# i# q# u# e

# In[None]


lb = LabelEncoder() 
data['Attrition'] = lb.fit_transform(data['Attrition'])
data['BusinessTravel'] = lb.fit_transform(data['BusinessTravel'])
data['Department'] = lb.fit_transform(data['Department'])
data['EducationField'] = lb.fit_transform(data['EducationField'])
data['Gender'] = lb.fit_transform(data['Gender'])
data['JobRole'] = lb.fit_transform(data['JobRole'])
data['MaritalStatus'] = lb.fit_transform(data['MaritalStatus'])
data['Over18'] = lb.fit_transform(data['Over18'])
data['OverTime'] = lb.fit_transform(data['OverTime'])

# In[None]

data.info()

# i# t#  # i# s#  # g# o# o# d# ,#  # a# l# l#  # m# y#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # t# r# a# n# s# f# o# r# m# i# n# g#  # i# n#  # n# u# m# e# r# i# c# a# l#  # t# y# p# e

# In[None]

data.head()

# -#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n

# In[None]

X = data.drop(["Attrition"], axis = 1)
y = data["Attrition"]

# In[None]

X.shape

# In[None]

y.shape

# In[None]

#function for normalizing our data

def normalisation(train_df, test_df):
    from sklearn.preprocessing import StandardScaler
    sc_X = StandardScaler()
    train_df = sc_X.fit_transform(train_df)
    test_df =  sc_X.transform(test_df)
    return train_df, test_df


# -#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g# 
# 
# I# n#  # t# h# i# s#  # s# e# c# t# i# o# n# ,#  # w# e#  # w# i# l# l#  # c# r# e# a# t# e#  # o# u# r#  # *# *# M# L#  # m# o# d# e# l# s# *# *#  # a# n# d#  # a# l# s# o#  # *# *# e# v# a# l# u# a# t# e#  # t# h# e# m# *# *# .#  # 
# 
# l# e# t# ’# s#  # g# o

# In[None]

#Split our dataset in train ans test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7870634.npy", { "accuracy_score": score })

import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns
df = pd.read_csv('../input/heart.csv')
df.head()
updated_cols = ['Age', 'Sex', 'ChestPainType', 'RestingBP', 'SerumCholestoral', 'FastingBloodSugar', 'RestingECG',                'MaxHeartRate', 'ExeriseEnducedAngina', 'OldPeak', 'SlopeOldPeak', 'MajorVessels', 'Thal', 'Output']
df.columns = updated_cols
df.head()
df.describe()
#plt.figure(figsize=(15,7))
#plt.xlabel('Number of People')
#plt.ylabel('Age')
#plt.title('Age')
#plt.plot(df.Age)
print("Min Age: ", df.Age.min())
print("Mean Age: ", df.Age.mean())
print("Max Age: ", df.Age.max())
#sns.set(style="darkgrid")
#plt.figure(figsize=(8,4))
#plt.title('Male v/s Female')
#sns.countplot(x="Sex", data=df)
print("Number of Males: ", (df.Sex==1).sum())
print("Number of Females: ", (df.Sex==0).sum())
print("Total People: ", df.Sex.count())
#sns.set(style="darkgrid")
#plt.figure(figsize=(12,6))
#plt.title('Chest Pain Type')
#sns.countplot(x="ChestPainType", data=df)
print("Number of Chest Pain Type 0: ", (df.ChestPainType==0).sum())
print("Number of Chest Pain Type 1: ", (df.ChestPainType==1).sum())
print("Number of Chest Pain Type 2: ", (df.ChestPainType==2).sum())
print("Number of Chest Pain Type 3: ", (df.ChestPainType==3).sum())
#sns.set(style="darkgrid")
#plt.figure(figsize=(12,6))
#plt.title('Resting Blood Pressure')
#plt.plot(df.RestingBP)
print("Highest value: ", df.RestingBP.max())
print("Mean value: ", df.RestingBP.mean())
print("Lowest value: ", df.RestingBP.min())
#sns.set(style="darkgrid")
#plt.figure(figsize=(13,6))
#plt.title('Serum Cholestoral')
#plt.xlabel("Number of People")
#plt.ylabel("Serum Cholestoral count")
#plt.plot(df["SerumCholestoral"])
print("Highest value: ", df.SerumCholestoral.max())
print("Mean value: ", df.SerumCholestoral.mean())
print("Lowest value: ", df.SerumCholestoral.min())
print("Fasting Blood Sugar > 120 mg/dl ?")
print("Yes: 1")
print("No: 0")
#sns.set(style="darkgrid")
#plt.figure(figsize=(9,5))
#plt.title('Fasting Blood Sugar')
#sns.countplot(x='FastingBloodSugar', data=df)
#plt.show()
#sns.countplot(x='RestingECG', data=df)
#plt.title("Resting ECG")
#plt.show()
#plt.figure(figsize=(9,4))
#plt.plot(df.MaxHeartRate)
print("Highest value: ", df.MaxHeartRate.max())
print("Mean value: ", df.MaxHeartRate.mean())
print("Lowest value: ", df.MaxHeartRate.min())
#plt.xlabel("Number of Poeple")
#plt.ylabel("Heart Rate")
#plt.title("Max Heart Rate")
#plt.show()
#plt.figure(figsize=(7,4))
#sns.countplot(x='ExeriseEnducedAngina', data=df)
#plt.title("Exercise Enduced Angina")
#plt.show()
print("Highest value: ", df.OldPeak.max())
print("Mean value: ", df.OldPeak.mean())
print("Lowest value: ", df.OldPeak.min())
#plt.figure(figsize=(9, 4))
#plt.title("Old Peak")
#plt.plot(df.OldPeak)
#plt.show()
#plt.figure(figsize=(9, 4))
#sns.countplot(x='SlopeOldPeak', data=df)
#plt.title("Slope Old Peak")
#plt.show()
#plt.figure(figsize=(9, 4))
#sns.countplot(data=df, x='MajorVessels')
#plt.title("Major Vessels")
#plt.show()
#plt.figure(figsize=(10, 6))
#sns.countplot(x='Thal', data=df)
#plt.title("Thal")
#plt.show()
#sns.countplot(x='Output', data=df)
#plt.title("Output")
#plt.show()
X = df.drop('Output', axis=1)
X.head()
y = df.Output
y.head()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
#rf = model.fit(X_train, y_train)
#rf_score = rf.score(X_test, y_test)
#print("Score using Random Forest without any hyperparameter tuning: ", rf_score)
from sklearn.model_selection import GridSearchCV
grid_param = {  
    'n_estimators': [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000],    'criterion': ['gini', 'entropy'],    'max_depth': [10, 20, 30, 40, 50, 60, 70, 80, 90, 100],     'bootstrap': [True, False]
}
#gd_sr = GridSearchCV(estimator=rf,                       param_grid=grid_param,                     scoring='accuracy',                     cv=10,                     n_jobs=-1)
#gd_sr.fit(X_train, y_train)
#best_parameters = gd_sr.best_params_ 
#best_score = gd_sr.best_score_
#print("Best paramaters for RandomForestClassifier: ", best_parameters)
#print("Best score for RandomForestClassifier: ", best_score )
from sklearn.svm import SVC
svc = SVC()
grid_param = {  
      'C':[1,10,100,1000],      'gamma':[1,0.1,0.001,0.0001],       'kernel':['linear','rbf']
}
gd_sr = GridSearchCV(estimator=svc,                       param_grid=grid_param,                     scoring='accuracy',                     cv=10,                     n_jobs=-1)
#gd_sr.fit(X_train, y_train)
#best_parameters = gd_sr.best_params_  
#best_score = gd_sr.best_score_
#print("Best parameters for SVC: ", best_parameters)  
#print("Best score for SVC: ", best_score)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amreshgiri_heart-disease-classifier.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/amreshgiri_heart-disease-classifier/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/amreshgiri_heart-disease-classifier/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amreshgiri_heart-disease-classifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amreshgiri_heart-disease-classifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amreshgiri_heart-disease-classifier/testY.csv",encoding="gbk")


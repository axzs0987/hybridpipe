import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import seaborn as sns
heart_data=pd.read_csv('../input/heart.csv')
heart_data.head()
X = heart_data.iloc[:,:-1]
y = heart_data.iloc[:,-1]
corr = heart_data.corr(method='pearson')
type(corr)
#ax = sns.heatmap(corr,cmap='YlGnBu',square=True)
best_features = corr['target'][(abs(corr['target']>0.3)) & (abs(corr['target']!=1))]
best_features_col = list(best_features.index)
input_values_x_0 = heart_data[best_features_col[0]][heart_data['target']==0]
input_values_y_0 = heart_data[best_features_col[1]][heart_data['target']==0]
input_values_z_0 = heart_data[best_features_col[2]][heart_data['target']==0]
output_values_0 = heart_data['target'][heart_data['target']==0]
input_values_x_1 = heart_data[best_features_col[0]][heart_data['target']==1]
input_values_y_1 = heart_data[best_features_col[1]][heart_data['target']==1]
input_values_z_1 = heart_data[best_features_col[2]][heart_data['target']==1]
output_values_1 = heart_data['target'][heart_data['target']==1]
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
#fig = plt.figure()
#ax = fig.add_subplot(111,projection='3d')
#ax.scatter(input_values_x_0,input_values_y_0,input_values_z_0,c='r',marker='o')
#ax.scatter(input_values_x_1,input_values_y_1,input_values_z_1,c='g',marker='^')
#ax.set_xlabel('X Label')
#ax.set_ylabel('Y Label')
#ax.set_zlabel('Z Label')
#plt.show()
from sklearn.preprocessing import StandardScaler
scaler=StandardScaler()
X_scaled=scaler.fit_transform(X[best_features_col])
type(X_scaled)
X_scaled_df=pd.DataFrame(X_scaled)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_scaled_df, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.svm import SVC
clf = SVC(kernel='rbf')
#clf.fit(X_train,y_train)
#preds=clf.predict(X_test)
from sklearn.metrics import accuracy_score
#acc=accuracy_score(y_test,preds)
#print(acc)
from sklearn.neighbors import KNeighborsClassifier
clf_rf=KNeighborsClassifier(n_neighbors=10)
#clf_rf.fit(X_train,y_train)
#preds_rf = clf_rf.predict(X_test)
#acc_rf = accuracy_score(y_test,preds_rf)
#print(acc_rf)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ajayago_heart-disease-uci-1.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ajayago_heart-disease-uci-1/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ajayago_heart-disease-uci-1/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ajayago_heart-disease-uci-1/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ajayago_heart-disease-uci-1/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ajayago_heart-disease-uci-1/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ajayago_heart-disease-uci-1/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ajayago_heart-disease-uci-1/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ajayago_heart-disease-uci-1/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ajayago_heart-disease-uci-1/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ajayago_heart-disease-uci-1/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ajayago_heart-disease-uci-1/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ajayago_heart-disease-uci-1/testY.csv",encoding="gbk")


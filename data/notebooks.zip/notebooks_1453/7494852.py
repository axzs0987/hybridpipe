import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

telco_raw = pd.read_csv("/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv",skipinitialspace=True)

# In[None]

telco_raw.head()

# In[None]

telco_raw.dtypes

# In[None]

telco_raw.isnull().mean()

# *# *# S# e# p# a# r# a# t# e#  # t# h# e#  # i# d# e# n# t# i# f# i# e# r#  # &#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# *# *

# In[None]

custid = ['customerID']
target = ['Churn']

# *# *# S# e# p# a# r# a# t# e#  # c# a# t# e# g# o# r# i# c# a# l#  # a# n# d#  # n# u# m# e# r# i# c#  # c# o# l# u# m# n#  # n# a# m# e# s#  # a# s#  # l# i# s# t# s# *# *

# In[None]

categorical = telco_raw.nunique()[telco_raw.nunique()<10].keys().tolist()
categorical.remove(target[0])
numerical = [col for col in telco_raw.columns if col not in custid+target+categorical]

# *# *# O# n# e# -# h# o# t#  # e# n# c# o# d# i# n# g#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# *# *

# In[None]

telco_raw = pd.get_dummies(data=telco_raw, columns=categorical, drop_first=True)

# *# *# S# c# a# l# i# n# g#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s# *# *

# In[None]

# Import StandardScaler library
from sklearn.preprocessing import StandardScaler
# Initialize StandardScaler instance
scaler = StandardScaler()


# In[None]

# Fit the scaler to numerical columns
scaled_numerical = scaler.fit_transform(telco_raw[numerical])

# In[None]

# Build a DataFrame
scaled_numerical = pd.DataFrame(scaled_numerical, columns=numerical)

# In[None]

# Drop non-scaled numerical columns
telco_raw = telco_raw.drop(columns=numerical, axis=1)

# In[None]

# Merge the non-numerical with the scaled numerical data
telco = telco_raw.merge(right=scaled_numerical, how='left', left_index=True, right_index=True)

# In[None]

from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# In[None]

cols    = [col for col in telco_raw.columns if col not in custid+target]

# In[None]

cols

# In[None]

X = telco_raw[cols]
Y = telco_raw['Churn']

# In[None]

# 1. Split data to training and testing
from sklearn.model_selection import train_test_split
train_X, test_X, train_Y, test_Y = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(train_X, train_Y)
y_pred = model.predict(test_X)
score = accuracy_score(test_Y, y_pred)
import numpy as np
np.save("prenotebook_res/7494852.npy", { "accuracy_score": score })

import pandas as pd
# ##  # I# B# M# _# H# R# _# A# n# a# l# y# t# i# c# s# _# E# m# p# l# o# y# e# e# _# A# t# t# r# i# t# i# o# n# _# P# e# r# f# o# r# m# a# n# c# e#  

# ## ## ##  # T# h# e#  # d# a# t# a# s# e# t#  # i# s#  # a# b# o# u# t#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n# .#  # T# h# i# s#  # a# n# a# l# y# s# i# s#  # c# a# n#  # d# i# s# c# o# v# e# r#  # i# f#  # a# n# y#  # p# a# r# t# i# c# u# l# a# r#  # f# a# c# t# o# r# s#  # o# r#  # p# a# t# t# e# r# n# s#  # t# h# a# t#  # l# e# a# d#  # t# o#  # a# t# t# r# i# t# i# o# n# .#  # I# f#  # s# o# ,#  # e# m# p# l# o# y# e# r# s#  # c# a# n#  # t# a# k# e#  # c# e# r# t# a# i# n#  # p# r# e# c# a# u# s# i# o# n#  # t# o#  # p# r# e# v# e# n# t#  # a# t# t# r# i# t# i# o# n#  # w# h# i# c# h#  # i# n#  # e# m# p# l# o# y# e# r#  # o# f#  # v# i# e# w# ,#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n#  # i# s#  # a#  # l# o# s# s#  # t# o#  # c# o# m# p# a# n# y# ,#  # i# n#  # b# o# t# h#  # m# o# n# e# t# a# r# y#  # a# n# d#  # n# o# n# -# m# o# n# e# t# a# r# y# .#  

# ## ## ## ##  # i# m# p# o# r# t#  # m# o# d# u# l# e# s#  # a# n# d#  # d# a# t# a#  # i# n# p# u# t#  

# In[None]

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import seaborn as sns 
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix

# In[None]

data=pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')

# In[None]

data.head()

# A# t# t# r# i# t# i# o# n#  # w# i# l# l#  # b# e#  # t# h# e#  # l# a# b# e# l#  # c# o# l# u# m# n#  # a# n# d#  # r# e# m# a# i# n# i# n# g#  # w# i# l# l#  # b# e#  # f# e# a# t# u# r# e

# In[None]

data.describe()

# E# m# p# l# o# y# e# e# C# o# u# n# t#  # c# a# n#  # b# e#  # d# e# l# e# t# e# d#  # a# s#  # i# t# s#  # v# a# l# u# e#  # a# l# w# a# y# s#  # e# q# u# a# l#  # 1

# In[None]

del data['EmployeeCount']

# ## ## ## ##  # C# h# e# c# k#  # i# f#  # a# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s

# In[None]

data.isnull().any()

# T# h# e# r# e#  # i# s#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e

# ## ## ## ##  # D# a# t# a#  # e# x# p# l# o# r# a# t# i# o# n

# In[None]

data.shape

# T# h# e# r# e#  # a# r# e#  # 1# 4# 7# 0#  # r# e# c# o# r# d# s#  # a# n# d#  # 3# 5#  # v# a# r# i# a# b# l# e# s

# In[None]

data.groupby('Attrition').size()

# T# h# e# r# e#  # a# r# e#  # 2# 3# 7#  # a# t# t# r# i# t# i# o# n# s#  # i# n#  # d# a# t# a# s# e# t#  

# L# e# t# '# s#  # c# h# a# n# g# e#  # A# t# t# r# i# t# i# o# n#  # t# o#  # b# i# n# a# r# y# :#  # 1#  # i# s#  # Y# e# s#  # ,#  # 0#  # i# s#  # N# o#  

# In[None]

data['Attrition']=data['Attrition'].apply(lambda x : 1 if x=='Yes' else 0)

# T# h# e# r# e#  # a# r# e#  # m# a# n# y#  # r# e# a# s# o# n# s#  # c# a# u# s# i# n# g#  # a# t# t# r# i# t# i# o# n# ,#  # f# r# o# m#  # p# e# r# s# o# n# a# l#  # r# e# l# a# t# e# d#  # (# e# g#  # a# g# e# ,#  # f# a# m# i# l# y# )#  # t# o#  # j# o# b#  # r# e# l# a# t# e# d#  # (# e# g#  # s# a# l# a# r# y# ,#  # b# o# r# e# d#  # i# n#  # p# o# s# i# t# i# o# n# )# 
# <# b# r# >#  # B# e# f# o# r# e#  # d# i# g# g# i# n# g#  # i# n#  # d# e# e# p# ,#  # l# e# t# '# s#  # h# a# v# e#  # a#  # p# r# e# l# i# m# a# r# y#  # f# i# n# d# i# n# g#  # f# i# r# s# t

# F# i# r# s# t#  # i# s#  # a# b# o# u# t#  # a# g# e#  # (# M# a# y# b# e#  # o# l# d#  # e# n# o# u# g# h#  # t# o#  # r# e# t# i# r# e# )

# In[None]

sns.boxplot(x='Attrition',y='Age',data=data)

# I# n#  # a# v# e# r# a# g# e# ,#  # a# t# t# r# i# t# e# d#  # e# m# p# l# o# y# e# e# s#  # a# r# e#  # y# o# u# n# g# e# r#  # t# h# a# n#  # n# o# n# -# a# t# t# r# i# t# e# d#  # e# m# p# l# o# y# e# e# s

# S# e# c# o# n# d#  # i# s#  # s# a# l# a# r# y#  # (# U# n# s# a# t# i# s# f# a# c# t# o# r# y#  # i# n#  # s# a# l# a# r# y# ?# ?# )# (# D# a# i# l# y# R# a# t# e#  # i# n#  # d# a# t# a# )#  

# In[None]

sns.boxplot(x='Attrition',y='DailyRate',data=data)

# T# h# e# r# e#  # i# s#  # l# e# s# s#  # d# i# f# f# e# r# e# n# c# e#  # f# o# r#  # d# a# i# l# y#  # r# a# t# e#  # b# e# t# w# e# e# n#  # a# t# t# r# i# t# e# d#  # a# n# d#  # n# o# n# -# a# t# t# r# i# t# e# d#  # e# m# p# l# o# y# e# e# s#  # t# h# a# n#  # a# g# e# .# 
# <# b# r# ># M# a# y# b# e#  # w# a# g# e#  # i# s#  # n# o# t#  # a# s#  # a# n#  # i# m# p# o# r# t# a# n# t#  # f# a# c# t# o# r#  # t# h# a# n#  # e# x# p# e# c# t# e# d

# N# e# x# t#  # i# s#  # d# u# r# a# t# i# o# n#  # o# f#  # w# o# r# k#  # i# n#  # c# o# m# p# a# n# y#  # (# B# o# r# e# d# ,#  # n# o#  # f# u# r# t# h# e# r#  # e# x# c# i# t# m# e# n# t#  # f# r# o# m#  # w# o# r# k# ?# )

# In[None]

sns.boxplot(x='Attrition',y='YearsAtCompany',data=data)

# T# h# e# r# e#  # a# r# e#  # m# a# n# y#  # e# x# t# r# e# m# e#  # c# a# s# e# s#  # i# n#  # b# o# t# h#  # a# t# t# r# i# t# e# d#  # a# n# d#  # n# o# n# -# a# t# t# r# i# t# e# d#  # e# m# p# l# o# y# e# e# s# .#  # H# a# r# d#  # t# o#  # d# e# t# e# r# m# i# n# e#  # i# f#  # d# u# r# a# t# i# o# n#  # o# f#  # w# o# r# k#  # i# s#  # r# e# l# a# t# e# d#  # a# t#  # t# h# i# s#  # m# o# m# e# n# t

# ## ## ## ##  # D# a# t# a#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n

# T# h# e# r# e#  # a# r# e#  # t# h# r# e# e#  # t# e# x# t#  # c# a# t# e# g# o# r# i# e# s# ,#  # B# u# s# i# n# e# s# s# T# r# a# v# e# l# ,#  # D# e# p# a# r# t# m# e# n# t#  # a# n# d#  # E# d# u# c# a# t# i# o# n# F# i# e# l# d# .#  # M# o# r# e# o# v# e# r# ,#  # E# d# u# c# a# t# i# o# n# ,#  # E# n# v# i# r# o# n# m# e# n# t# S# a# t# i# s# f# a# c# t# i# o# n# ,#  # J# o# b# I# n# v# o# l# v# e# m# e# n# t# ,#  # J# o# b# S# a# t# i# s# f# a# c# t# i# o# n# ,#  # P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# ,#  # R# e# l# a# t# i# o# n# s# h# i# p# S# a# t# i# s# f# a# c# t# i# o# n#  # a# n# d#  # W# o# r# k# L# i# f# e# B# a# l# a# n# c# e#  # a# r# e#  # a# l# s# o#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a# .#  # F# i# r# s# t#  # n# e# e# d#  # t# o#  # s# e# p# a# r# a# t# e#  # i# n# t# o#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e# s

# In[None]

num_cat=['Education', 'EnvironmentSatisfaction', 'JobInvolvement', 'JobSatisfaction', 'PerformanceRating', 'RelationshipSatisfaction' , 'WorkLifeBalance']
for i in num_cat:
    data[i]=data[i].astype('category')

# In[None]

data=pd.get_dummies(data)

# In[None]

data.info()

# F# r# o# m#  # t# h# e#  # l# a# s# t#  # r# e# s# u# l# t# ,#  # a# p# p# a# r# e# n# t# l# y#  # t# h# e# r# e#  # i# s#  # o# n# l# y#  # o# n# e#  # v# a# r# i# a# b# l# e#  # f# o# r#  # o# v# e# r# 1# 8# .#  # C# a# n#  # d# o# u# b# l# e#  # c# h# e# c# k#  # a# n# d#  # i# f#  # s# o#  # t# h# e# n#  # i# t#  # c# a# n#  # b# e#  # d# e# l# e# t# e# d

# In[None]

data['Age'].describe()

# A# l# l#  # e# m# p# l# o# y# e# e# s#  # a# r# e#  # o# v# e# r#  # 1# 8# .#  # S# o#  # i# t#  # c# a# n#  # b# e#  # d# e# l# e# t# e# d#  

# In[None]

del data['Over18_Y']

# In[None]

data.shape

# A# f# t# e# r#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n# ,#  # t# h# e# r# e#  # a# r# e#  # 7# 4#  # v# a# r# i# a# b# l# e# s#  

# ## ## ## ##  # M# o# d# e# l# l# i# n# g

# F# i# r# s# t#  # i# s#  # t# o#  # s# e# p# a# r# a# t# e#  # f# e# a# t# u# r# e#  # s# e# t#  # a# n# d#  # l# a# b# e# l#  # s# e# t

# In[None]

X=data[data.columns.difference(['Attrition'])]
y=data['Attrition']

# S# e# c# o# n# d#  # i# s#  # t# o#  # s# e# p# a# r# a# t# e#  # t# r# a# i# n# i# n# g#  # s# e# t#  # a# n# d#  # t# e# s# t#  # s# e# t#  

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1667792.npy", { "accuracy_score": score })

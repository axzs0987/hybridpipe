import pandas as pd
# In[None]

# Importing necessary libraries

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import seaborn as sns
os.getcwd()

# In[None]


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df=pd.read_csv('/kaggle/input/bank-marketing-dataset/bank.csv')

# In[None]

df.head()

# In[None]

df.shape

# In[None]

df.describe()

# ##  # U# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # d# a# t# a#  # w# i# t# h#  # t# h# e#  # h# e# l# p#  # o# f#  # v# i# s# u# a# l# i# s# a# t# i# o# n

# In[None]

# Let's see how the data is distributed

fig=plt.figure(figsize=(25,6))
sns.countplot(x='age',data=df)


# T# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # i# s#  # r# i# g# h# t# l# y#  # s# k# e# w# e# d# .#  # I# t#  # s# h# o# w# s#  # m# o# s# t#  # o# f#  # t# h# e#  # p# e# o# p# l# e#  # b# e# l# o# n# g# s#  # t# o#  # a# g# e#  # g# r# e# a# t# h# e# r#  # t# h# a# n#  # 3# 0# .

# In[None]


fig=plt.figure(figsize=(25,8))
sns.countplot(x='job',data=df)


# M# a# n# a# g# e# m# e# n# t# ,#  # t# e# c# h# n# i# c# i# a# n# s#  # a# n# d#  # b# l# u# e#  # c# o# l# l# a# r# s#  # j# o# b# s#  # a# r# e#  # h# i# g# h# l# y#  # t# a# r# g# e# t# e# d#  # f# o# r#  # c# o# m# p# a# i# g# n#  

# In[None]

fig=plt.figure(figsize=(12,5))
sns.countplot(x='marital',data=df)

# M# o# s# t#  # m# a# r# r# i# e# d#  # p# e# o# p# l# e#  # w# e# r# e#  # t# a# r# g# e# t# e# d#  

# In[None]

sns.distplot(df.balance,hist=True,kde=False)

# M# a# j# o# r# i# t# y#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # w# e# r# e#  # t# a# r# g# e# t# e# d# ,#  # h# a# d#  # b# a# l# a# n# c# e#  # l# e# s# s#  # t# h# a# n#  # 2# 0# 0# 0# 0#  

# In[None]

fig=plt.figure(figsize=(20,20))
ax1=fig.add_subplot(331)
ax2=fig.add_subplot(332)
ax3=fig.add_subplot(333)


sns.countplot(x='loan',data=df,ax=ax1)
ax1.set_title('Loan Taken ')

sns.countplot(x='contact',data=df,ax=ax2)
ax2.set_title('Contact Medium ')

sns.countplot(x='marital',data=df)
ax3.set_title('Marital Staus')


# In[None]

sns.pairplot(df,hue='deposit')

# In[None]

fig=plt.figure(1,figsize=(18,5))

sns.boxplot(x='job',y='balance',data=df,hue='deposit')

# R# e# t# i# r# e# d#  # P# e# o# p# l# e#  # a# n# d#  # m# a# n# a# g# e# m# e# n# t#  # s# u# b# s# c# r# i# b# e# d#  # t# o#  # t# h# e#  # t# e# r# m#  # d# e# p# o# s# i# t# e#  # h# a# v# e#  # m# o# r# e#  # b# a# l# a# n# c# e#  # i# n#  # t# h# e# i# r#  # a# c# c# o# u# n# t# 
# 
# E# s# p# e# c# i# a# l# l# y#  # i# n#  # m# a# n# a# g# e# m# e# n# t# ,#  # p# e# o# p# l# e#  # s# u# b# s# c# r# i# b# e# d#  # t# o#  # t# e# r# m#  # d# e# p# o# s# i# t#  # h# a# v# e#  # m# o# r# e#  # t# h# a# n#  # m# e# d# i# a# n#  # b# a# l# a# n# c# e

# In[None]

fig=plt.figure(1,figsize=(13,8))

p=sns.boxplot(x='marital',y='balance',data=df,hue='deposit')
p.set_title('Marital Status vs Subscription')

# M# a# r# r# i# e# d#  # p# e# o# p# l# e#  # w# i# t# h#  # h# i# g# h# e# r#  # b# a# l# a# n# c# e#  # h# a# d#  # m# a# j# o# r# i# t# y#  # o# f#  # s# u# b# s# c# r# i# p# t# i# o# n# .# 
# D# i# v# o# r# c# e# d#  # p# e# o# p# l# e#  # h# a# v# i# n# g#  # l# e# s# s#  # b# a# l# a# n# c# e#  # t# h# e# i# r#  # a# c# c# o# u# n# t# s# .

# In[None]

fig=plt.figure(1,figsize=(8,5))

p=sns.boxplot(x='housing',y='balance',data=df,hue='deposit')
p.set_title('housing loan vs Subscription')

# P# e# o# p# l# e#  # w# i# t# h# o# u# t#  # h# o# u# s# i# n# g#  # l# o# a# n# ,#  # w# h# o#  # h# a# v# e#  # s# u# b# s# c# r# i# b# e# d#  # t# o#  # t# h# e#  # t# e# r# m#  # d# e# p# o# s# i# t#  # h# a# v# e#  # m# o# r# e#  # b# a# l# a# n# c# e#  

# In[None]


p=sns.barplot(x='contact',y='balance',data=df,hue='deposit')
p.set_title('Medium vs Subscription')

# T# e# l# e# p# h# o# n# e#  # w# a# s#  # t# h# e#  # m# o# s# t#  # i# n# f# l# u# e# n# c# i# a# l#  # m# e# d# i# u# m#  # f# o# r#  # r# e# a# c# h# i# n# g#  # o# u# t#  # t# o#  # t# h# e#  # c# u# s# t# o# m# e# r# s

# In[None]


p=sns.barplot(x='deposit',y='campaign',data=df)
p.set_title('Contact made vs Subscribed')

# In[None]

fig=plt.figure(1,figsize=(13,8))

p=sns.boxplot(x='education',y='balance',data=df,hue='deposit')
p.set_title('Contact made vs Subscribed')

# In[None]

df['marital/education']=np.nan

lst = [df]

for col in lst:
    col.loc[(col.marital=='single') & (col.education=='primary'),'marital/education']='Single_primary'
    col.loc[(col.marital=='single') & (col.education=='secondary'),'marital/education']='Single_secondary'
    col.loc[(col.marital=='single') & (col.education=='tertiary'),'marital/education']='Single_tertiary'
    col.loc[(col.marital=='married') & (col.education=='primary'),'marital/education']='married_Primary'
    col.loc[(col.marital=='married') & (col.education=='secondary'),'marital/education']='married_secondary'
    col.loc[(col.marital=='married') & (col.education=='tertiary'),'marital/education']='married_tertiary'
    col.loc[(col.marital=='divorced') & (col.education=='primary'),'marital/education']='divorced_primary'
    col.loc[(col.marital=='divorced') & (col.education=='secondary'),'marital/education']='divorced_secondary'
    col.loc[(col.marital=='divorced') & (col.education=='tertiary'),'marital/education']='divorced_tertiary'



    


# In[None]


df.head()

# In[None]

fig=plt.figure(figsize=(20,7))
sns.barplot(x='marital/education',y='balance',data=df)

# D# i# v# o# r# c# e# d#  # p# e# o# p# l# e#  # w# i# t# h#  # t# e# r# t# i# a# r# y#  # e# d# u# c# a# t# i# o# n#  # h# a# s#  # h# i# g# h# e# s# t#  # b# a# l# a# n# c# e#  # i# n#  # t# h# e# i# r#  # a# c# c# o# u# n# t# s#  # f# o# l# l# o# w# e# d#  # b# y#  # m# a# r# r# i# e# d#  # a# n# d#  # s# i# n# g# l# e#  # p# e# o# p# l# e#  # w# i# t# h#  # s# a# m# e#  # e# d# u# c# a# t# i# o# n#  # l# e# v# e# l# .# 
# 


# In[None]

fig=plt.figure(figsize=(20,7))
sns.barplot(x='marital/education',y='balance',data=df,hue='loan')

# M# a# r# r# i# e# d#  # p# e# o# p# l# e#  # w# e# r# e#  # a# m# o# n# g# s# t#  # t# h# e#  # o# n# e# s#  # w# h# o#  # h# a# s#  # t# a# k# e# n#  # t# h# e#  # m# o# s# t#  # l# o# a# n# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .#  # 
# 


# In[None]

fig=plt.figure(figsize=(5,4))
sns.boxplot(x='deposit',y='duration',data=df)

# In[None]

df.groupby(['deposit']).mean()
df.duration.describe()

# T# h# e#  # m# o# r# e#  # t# h# e#  # c# a# l# l#  # d# u# r# a# t# i# o# n# ,#  # m# o# r# e#  # p# e# o# p# l# e#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # b# u# y#  # t# h# e#  # t# e# r# m#  # d# e# p# o# s# i# t# .

# In[None]

fig=plt.figure(figsize=(20,7))
sns.barplot(x='marital/education',y='duration',data=df,hue='loan')

# S# i# n# g# l# e#  # a# n# d#  # d# i# v# o# r# c# e# d#  # p# e# o# p# l# e#  # h# a# v# e#  # m# o# r# e#  # c# a# l# l#  # d# u# r# a# t# i# o# n# .# 
# 
# S# p# e# c# i# f# i# c# a# l# l# y# ,#  # s# i# n# g# l# e#  # &#  # D# i# v# o# r# c# e# d#  # p# e# o# p# l# e#  # w# i# t# h#  # p# r# i# m# a# r# y#  # l# e# v# e# l#  # o# f#  # e# d# u# c# a# t# i# o# n#  # h# a# s#  # m# o# r# e#  # m# o# r# e#  # c# a# l# l#  # d# u# r# a# t# i# o# n# .

# In[None]

fig=plt.figure(figsize=(20,7))
sns.barplot(x='marital/education',y='duration',data=df)

# ##  # E# v# a# l# u# a# t# i# n# g#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # v# a# r# i# o# u# s#  # f# e# a# t# u# r# e# s

# In[None]

from sklearn.preprocessing import StandardScaler,LabelEncoder
copy=df.copy()
copy['deposit'] = LabelEncoder().fit_transform(copy['deposit'])
copy['marital'] = LabelEncoder().fit_transform(copy['marital'])
copy['job'] = LabelEncoder().fit_transform(copy['job'])

copy['education'] = LabelEncoder().fit_transform(copy['education'])
copy['loan'] = LabelEncoder().fit_transform(copy['loan'])
copy['housing'] = LabelEncoder().fit_transform(copy['housing'])


# In[None]


copy.head()

# In[None]

corr=copy.corr()

# In[None]

fig = plt.figure(figsize=(12,8))

sns.heatmap(corr,annot=True)

# D# u# r# a# t# i# o# n#  # i# s#  # h# i# g# h# l# y#  # c# o# r# e# l# a# t# e# d#  # w# i# t# h#  # d# e# p# o# s# i# t# .#  # 
# 
# L# o# a# n#  # a# n# d#  # h# o# u# s# i# n# g#  # h# a# s#  # i# m# p# a# c# t#  # o# n#  # s# u# b# s# c# r# i# b# i# n# g#  # t# o#  # t# e# r# m#  # d# e# p# o# s# i# t# .

# ##  # C# r# e# a# t# i# n# g#  # t# h# e#  # M# o# d# e# l# s

# In[None]



df=df.drop('marital/education',axis=1)


# In[None]

from sklearn.preprocessing import StandardScaler,LabelEncoder
df['deposit'] = LabelEncoder().fit_transform(df['deposit'])

df.head()

# In[None]

from sklearn.model_selection import train_test_split

X=df.drop('deposit',axis=1)
X=pd.get_dummies(X)
y=df['deposit']

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7787955.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

#01FB16ECS419 Tejas Prashanth
#01FB16ECS416 Tanmaya Udupa
#01FB16ECS426 VS Meghana
#Assignment6

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns #For the correlation plot
from sklearn.model_selection import train_test_split
import statsmodels.api as sm
import math as m
from sklearn import linear_model
from sklearn.preprocessing import PolynomialFeatures
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix,accuracy_score
import graphviz
from sklearn import svm
from sklearn.preprocessing import MinMaxScaler
#import sys
#print(sys.path)
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
print(os.listdir("."))

# Any results you write to the current directory are saved as output.

# In[None]

df=pd.read_csv("../input/Absenteeism_at_work.csv")
print(df.iloc[0,])
print(df.columns)
#Summary stats
print(df.describe())



#Split into training and testing
X=df[df.columns.difference(['Absenteeism time in hours'])]
y=df[['Absenteeism time in hours']]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1795954.npy", { "accuracy_score": score })

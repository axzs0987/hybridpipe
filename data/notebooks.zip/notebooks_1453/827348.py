import pandas as pd
# ##  # P# r# e# d# i# c# t#  # P# a# t# i# e# n# t#  # N# o# -# S# h# o# w

# ## ## ##  # P# r# o# b# l# e# m# 
# A#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # l# a# b# e# l#  # o# f#  # t# h# e#  # N# o# -# S# h# o# w#  # c# l# a# s# s# .#  # L# a# b# e# l# s#  # =#  # {# Y# e# s# ,#  # N# o# }# 
# 
# ## ## ##  # D# a# t# a# s# e# t# 
# 1# 1# 0# 5# 2# 7#  # (# 8# 8# 2# 0# 8#  # S# h# o# w#  # /#  # 2# 2# 3# 1# 9#  # N# o# -# s# h# o# w# )#  # p# a# t# i# e# n# t# s#  # w# i# t# h#  # a# p# p# o# i# n# t# m# e# n# t# s#  # r# a# n# g# i# n# g#  # i# n#  # d# a# t# e#  # f# r# o# m#  # 4# /# 2# 9# /# 2# 0# 1# 6#  # -#  # 6# /# 0# 7# /# 2# 0# 1# 6# 
# 
# ## ## ##  # F# e# a# t# u# r# e# s# 
# -#  # A# P# P# _# D# E# L# T# A#  # :#  # D# a# y# s#  # f# r# o# m#  # w# h# e# n#  # a# p# p# o# i# n# t# m# e# n# t#  # s# c# h# e# d# u# l# e# d#  # t# o#  # a# p# p# o# i# n# t# m# e# n# t#  # d# a# y# 
# -#  # H# O# L# I# D# A# Y# _# D# E# L# T# A#  # :#  # D# a# y# s#  # f# r# o# m#  # a# p# p# o# i# n# t# m# e# n# t#  # d# a# y#  # t# o#  # n# e# a# r# e# s# t#  # U# S#  # F# e# d# e# r# a# l#  # H# o# l# i# d# a# y# 
# -#  # N# A# T# _# H# O# L# I# D# A# Y#  # :#  # 1#  # i# f#  # a# p# p# o# i# n# t# m# e# n# t#  # d# a# y#  # i# s#  # a#  # U# S#  # F# e# d# e# r# a# l#  # H# o# l# i# d# a# y# ,#  # 0#  # o# t# h# e# r# w# i# s# e# 
# -#  # D# A# Y# _# O# F# _# M# O# N# T# H#  # :#  # D# a# y#  # o# f#  # m# o# n# t# h#  # f# r# o# m#  # 1# -# 3# 1# 
# -#  # D# A# Y# _# O# F# _# W# E# E# K#  # :#  # D# a# y#  # o# f#  # w# e# e# k#  # f# r# o# m#  # 0#  # (# M# o# n# d# a# y# )#  # -#  # 6#  # (# S# u# n# d# a# y# )# 
# -#  # W# E# E# K# E# N# D#  # :#  # 1#  # i# f#  # D# a# y#  # o# f#  # w# e# e# k#  # =# =#  # 5#  # o# r#  # 6#  # (# S# a# t# u# r# d# a# y#  # o# r#  # S# u# n# d# a# y# )# ,#  # 0#  # o# t# h# e# r# w# i# s# e# 
# -#  # G# E# N# D# E# R#  # :#  # 1#  # -#  # F# e# m# a# l# e# ,#  # 0#  # -#  # M# a# l# e# 
# -#  # A# G# E#  # :#  # B# u# c# k# e# t# i# z# e# d#  # 1#  # =#  # '# x# x# -# 2# 4# '# ,#  # 2# =# '# 2# 5# -# 3# 4# '# ,# 3# =# '# 3# 5# -# 4# 9# '# ,# 4# =# '# 5# 0# -# x# x# '# 
# 
# ## ## ##  # A# l# g# o# r# i# t# h# m# 
# -#  # L# o# g# i# s# i# t# c#  # R# e# g# r# e# s# s# i# o# n# 
# 
# ## ## ##  # L# i# t# e# r# a# t# u# r# e#  # R# e# v# i# e# w# 
# -#  # [# A#  # p# r# o# b# a# b# i# l# i# s# t# i# c#  # m# o# d# e# l#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # t# h# e#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # n# o# -# s# h# o# w#  # i# n#  # h# o# s# p# i# t# a# l#  # a# p# p# o# i# n# t# m# e# n# t# s# ]# (# h# t# t# p# s# :# /# /# l# i# n# k# .# s# p# r# i# n# g# e# r# .# c# o# m# /# a# r# t# i# c# l# e# /# 1# 0# .# 1# 0# 0# 7# /# s# 1# 0# 7# 2# 9# -# 0# 1# 1# -# 9# 1# 4# 8# -# 9# )# 
# -#  # [# M# a# c# h# i# n# e# -# L# e# a# r# n# i# n# g# -# B# a# s# e# d#  # N# o#  # S# h# o# w#  # P# r# e# d# i# c# t# i# o# n#  # i# n# 
# O# u# t# p# a# t# i# e# n# t#  # V# i# s# i# t# s# ]# (# h# t# t# p# :# /# /# w# w# w# .# i# j# i# m# a# i# .# o# r# g# /# j# o# u# r# n# a# l# /# s# i# t# e# s# /# d# e# f# a# u# l# t# /# f# i# l# e# s# /# f# i# l# e# s# /# 2# 0# 1# 7# /# 0# 3# /# i# j# i# m# a# i# _# 4# _# 7# _# 4# _# p# d# f# _# 1# 1# 8# 8# 5# .# p# d# f# )# 
# -#  # [# P# a# t# i# e# n# t#  # N# o# -# S# h# o# w#  # P# r# e# d# i# c# t# i# v# e#  # M# o# d# e# l#  # D# e# v# e# l# o# p# m# e# n# t#  # u# s# i# n# g#  # M# u# l# t# i# p# l# e#  # D# a# t# a#  # S# o# u# r# c# e# s#  # f# o# r#  # a# n#  # E# f# f# e# c# t# i# v# e#  # O# v# e# r# b# o# o# k# i# n# g#  # A# p# p# r# o# a# c# h# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# t# h# i# e# m# e# -# c# o# n# n# e# c# t# .# c# o# m# /# p# r# o# d# u# c# t# s# /# e# j# o# u# r# n# a# l# s# /# a# b# s# t# r# a# c# t# /# 1# 0# .# 4# 3# 3# 8# /# A# C# I# -# 2# 0# 1# 4# -# 0# 4# -# R# A# -# 0# 0# 2# 6# )# 
# -#  # [# P# r# e# d# i# c# t# i# n# g#  # a# p# p# o# i# n# t# m# e# n# t#  # m# i# s# s# e# s#  # i# n#  # h# o# s# p# i# t# a# l# s#  # u# s# i# n# g#  # d# a# t# a#  # a# n# a# l# y# t# i# c# s# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# n# c# b# i# .# n# l# m# .# n# i# h# .# g# o# v# /# p# m# c# /# a# r# t# i# c# l# e# s# /# P# M# C# 5# 4# 2# 7# 1# 8# 4# /# )# 


# In[2]

import pandas as pd
import numpy as np
import time
from datetime import datetime, date
import matplotlib.pyplot as plt
from pandas.tseries.holiday import USFederalHolidayCalendar as calendar
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE#import LinearRegression
from sklearn import model_selection
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, confusion_matrix
import seaborn as sns

# In[5]

#Read in data
data = pd.read_csv("../input/KaggleV2-May-2016.csv", header=0)
data.head()

# ##  # F# e# a# t# u# r# e# s

# ## ## ##  # D# A# Y# _# O# F# _# W# E# E# K

# In[6]

data['DAY_OF_WEEK'] = pd.to_datetime(data['AppointmentDay']).dt.weekday
data.head()

# In[7]

data.DAY_OF_WEEK.hist()
plt.title('Days of Week Histogram')
plt.xlabel('Day of Week')
plt.ylabel('Freq')
plt.show()

# ## ## ##  # W# E# E# K# E# N# D

# In[8]

data['WEEKEND'] = data['DAY_OF_WEEK'].apply(lambda x: 1 if (x== 5 or x==6) else 0)

# ## ## ##  # D# A# Y# _# O# F# _# M# O# N# T# H

# In[9]

data['DAY_OF_MONTH'] = pd.to_datetime(data['AppointmentDay']).dt.day

# In[10]

data.DAY_OF_MONTH.hist()
plt.title('Days of Month Histogram')
plt.xlabel('Day of Month')
plt.ylabel('Freq')
plt.show()

# ## ## ##  # A# P# P# _# D# E# L# T# A

# In[11]

data['AppointmentDay'] = pd.to_datetime(data['AppointmentDay']).dt.date
data['ScheduledDay'] = pd.to_datetime(data['ScheduledDay']).dt.date

# In[12]

#Calculate distance from when appointment scheduled to appointment day
data['APP_DELTA'] = abs(data['ScheduledDay'] - data['AppointmentDay']).astype('int64')

# In[13]

#Sanity check
data[['ScheduledDay','AppointmentDay','APP_DELTA']].head()
data['APP_DELTA'].mean()

# In[14]

data.APP_DELTA.hist()
plt.title('APP_DELTA Histogram')
plt.xlabel('APP_DELTA')
plt.ylabel('Freq')
plt.show()

# ## ## ##  # H# O# L# I# D# A# Y# _# D# E# L# T# A

# In[15]

dr = pd.date_range(start='2016-04-28', end='2016-06-08')
df = pd.DataFrame()
df['date'] = dr
cal = calendar()
holidays = cal.holidays(start=dr.min(), end=dr.max())
holidays=pd.to_datetime(holidays).date

# In[16]

#Sanity check : https://www.timeanddate.com/holidays/us/2016
holidays

# In[17]

def time_delta(holidays, pivot):
    nearest=min(holidays, key=lambda x: abs(x-pivot))
    timedelta=abs(nearest-pivot).days
    return timedelta

# In[18]

data['AppointmentDay'] = pd.to_datetime(data['AppointmentDay'])
data['HOLIDAY_DELTA'] = data['AppointmentDay'].dt.date.apply(lambda x: time_delta(holidays,x))

# In[19]

data.HOLIDAY_DELTA.hist()
plt.title('HOLIDAY_DELTA Histogram')
plt.xlabel('HOLIDAY_DELTA')
plt.ylabel('Freq')
plt.show()

# ## ## ##  # N# A# T# _# H# O# L# I# D# A# Y

# In[20]

data['NAT_HOLIDAY'] = data['AppointmentDay'].dt.date.astype('datetime64[ns]').isin(holidays)*1

# ## ## ##  # G# e# n# d# e# r# 
# 1#  # -#  # F# ,#  # 0#  # -#  # M

# In[21]

data['Gender'] = data['Gender'].apply(lambda x: 1 if x=='F' else 0)

# ## ## ##  # A# g# e# 
# 1#  # =#  # '# x# x# -# 2# 4# '# ,#  # 2# =# '# 2# 5# -# 3# 4# '# ,# 3# =# '# 3# 5# -# 4# 9# '# ,# 4# =# '# 5# 0# -# x# x# '

# In[22]

data['AGE_B'] = data.Age.apply(lambda x: 4 if x>49 else( 3 if x >34 else(2 if x >23 else(1))))

# In[23]

#Sanity check
data.dropna(how='any', inplace=True)
data[['Age','AGE_B']].head()

# In[24]

data.Age.hist()
plt.title('Age Histogram')
plt.xlabel('Age')
plt.ylabel('Freq')
plt.show()

# In[25]

data.AGE_B.hist()
plt.title('Age Histogram (Bucketized)')
plt.xlabel('Age')
plt.ylabel('Freq')
plt.show()

# ## ##  # T# a# r# g# e# t

# In[26]

data['No-show'] = data['No-show'].apply(lambda x: 1 if x=='Yes' else 0)
#Sanity check
data['No-show'].sum()

# In[27]

#Sanity check
data.groupby('No-show').count()

# ##  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n# 
# "# t# h# e#  # g# o# a# l#  # o# f#  # r# e# c# u# r# s# i# v# e#  # f# e# a# t# u# r# e#  # e# l# i# m# i# n# a# t# i# o# n#  # (# R# F# E# )#  # i# s#  # t# o#  # s# e# l# e# c# t#  # f# e# a# t# u# r# e# s#  # b# y#  # r# e# c# u# r# s# i# v# e# l# y#  # c# o# n# s# i# d# e# r# i# n# g#  # s# m# a# l# l# e# r#  # a# n# d#  # s# m# a# l# l# e# r#  # s# e# t# s#  # o# f#  # f# e# a# t# u# r# e# s# .#  # F# i# r# s# t# ,#  # t# h# e#  # e# s# t# i# m# a# t# o# r#  # i# s#  # t# r# a# i# n# e# d#  # o# n#  # t# h# e#  # i# n# i# t# i# a# l#  # s# e# t#  # o# f#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # e# a# c# h#  # f# e# a# t# u# r# e#  # i# s#  # o# b# t# a# i# n# e# d#  # e# i# t# h# e# r#  # t# h# r# o# u# g# h#  # a#  # c# o# e# f# _#  # a# t# t# r# i# b# u# t# e#  # o# r#  # t# h# r# o# u# g# h#  # a#  # f# e# a# t# u# r# e# _# i# m# p# o# r# t# a# n# c# e# s# _#  # a# t# t# r# i# b# u# t# e# .#  # T# h# e# n# ,#  # t# h# e#  # l# e# a# s# t#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # a# r# e#  # p# r# u# n# e# d#  # f# r# o# m#  # c# u# r# r# e# n# t#  # s# e# t#  # o# f#  # f# e# a# t# u# r# e# s# .# "# 
# -#  # [# D# o# c# u# m# e# n# t# a# t# i# o# n# ]# (# h# t# t# p# :# /# /# s# c# i# k# i# t# -# l# e# a# r# n# .# o# r# g# /# s# t# a# b# l# e# /# m# o# d# u# l# e# s# /# g# e# n# e# r# a# t# e# d# /# s# k# l# e# a# r# n# .# f# e# a# t# u# r# e# _# s# e# l# e# c# t# i# o# n# .# R# F# E# .# h# t# m# l# )# 


# In[28]

data_in = data.drop(['ScheduledDay','AppointmentDay','PatientId', 'AppointmentID','Neighbourhood', 'Age'], axis=1)

# In[29]

#from sklearn import datasets
from sklearn.feature_selection import RFE
#data_in = data_in.dropna(how='any')
data_in = data_in.drop(['No-show'], axis=1)
names = data_in.columns.values

# In[30]

logreg = LogisticRegression()
rfe=RFE(logreg)
rfe=rfe.fit(data_in, data['No-show'])
print("Features sorted by rank:")
print(sorted(zip(map(lambda x: round(x,4), rfe.ranking_),names)))

# ##  # T# r# a# i# n# /# T# e# s# t#  # D# a# t# a#  # S# p# l# i# t

# In[31]

X = data_in[['AGE_B','APP_DELTA','DAY_OF_MONTH','DAY_OF_WEEK','Gender','HOLIDAY_DELTA','Hipertension','SMS_received','Scholarship','Diabetes','Alcoholism','Handcap','NAT_HOLIDAY','WEEKEND']]
y = data['No-show']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/827348.npy", { "accuracy_score": score })

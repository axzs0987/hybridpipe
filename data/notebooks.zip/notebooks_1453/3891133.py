import pandas as pd
# In[None]

import numpy as np 
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("whitegrid")

from sklearn.preprocessing import MinMaxScaler, StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV

from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# In[None]

df = pd.read_csv('../input/winequality-red.csv')
df.head()

# In[None]

df.describe()

# In[None]

df.info()

# In[None]

qty_cnt = df['quality'].value_counts().sort_index()
qty_cnt.plot(kind='bar')

# In[None]

plt.figure(figsize=(10, 8))
sns.pairplot(df, hue="quality", palette="husl")
plt.plot()

# In[None]

plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), cmap='RdBu', center=0, annot=True)
plt.plot()

# In[None]

for i in df.columns[:-1]:
    plt.figure()
    sns.boxplot(x=df['quality'], y=df[i])
    plt.plot()

# In[None]

for i in df.columns[:-1]:
    plt.figure()
    sns.barplot(x=df['quality'], y=df[i])
    plt.plot()

# In[None]

'''for i in df.columns[:-1]:
    plt.figure()
    for qn in range(3, 9):
        ax = sns.kdeplot(df[df['quality']==qn][i], shade=True)
        ax.set_label(s=qn)
    plt.plot()'''

# In[None]

df.isna().sum()

# In[None]

bins = (2, 5, 8)
group_names = ['bad', 'good']
df['quality'] = pd.cut(df['quality'], 
                       bins = bins, 
                       labels = group_names)

# In[None]

enc = LabelEncoder()
df['quality'] = enc.fit_transform(df['quality'])
sns.countplot(df['quality'])

# In[None]

mm = StandardScaler()
for i in ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']:
    df[i] =  mm.fit_transform(df[i].values.reshape(-1,1))

# In[None]

X = df.drop(['quality'], axis=1)
y = df['quality']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3891133.npy", { "accuracy_score": score })

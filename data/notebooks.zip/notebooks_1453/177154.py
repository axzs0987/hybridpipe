import pandas as pd
# ##  # W# h# a# t#  # m# a# k# e# s#  # y# o# u#  # s# o# u# n# d#  # l# i# k# e#  # a#  # f# e# m# a# l# e# /# m# a# l# e

# D# a# t# a#  # i# s#  # f# r# o# m#  # K# a# g# g# l# e# '# s#  # [# G# e# n# d# e# r#  # R# e# c# o# g# n# i# t# i# o# n#  # b# y#  # V# o# i# c# e# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# p# r# i# m# a# r# y# o# b# j# e# c# t# s# /# v# o# i# c# e# g# e# n# d# e# r# )

# In[None]

import pandas as pd

# In[None]

xy = pd.read_csv('../input/voice.csv')

X = xy.drop('label', axis='columns')
y = xy['label']

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/177154.npy", { "accuracy_score": score })

import pandas as pd
# T# e# a# m#  # N# a# m# e# :# -# D# a# t# a#  # D# u# o# 
# 
# A# s# s# i# g# n# m# e# n# t#  # 6# 
# 
# H# a# r# s# h# v# a# r# d# h# a# n#  # S# u# r# o# l# i# a#  # :# -#  # 0# 1# F# B# 1# 6# E# C# S# 4# 0# 8# 
# 
# M# a# n# m# a# t# h#  # S# a# h# o# o#  # :# -#  # 0# 1# F# B# 1# 6# E# C# S# 4# 8# 8

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler  
from sklearn.neighbors import KNeighborsClassifier  
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score  
import random
from sklearn import metrics
import sklearn
from math import sqrt
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor
import seaborn as sns

# In[None]

df=pd.read_csv("../input/Absenteeism_at_work.csv")

#Dropping outliers as they affect KNN,KMEANS AND SVM
sns.boxplot(df['Absenteeism time in hours'])
median = np.median(df['Absenteeism time in hours'])
q75, q25 = np.percentile(df['Absenteeism time in hours'], [75 ,25])
iqr = q75 - q25
print("Lower outlier bound:",q25 - (1.5*iqr))
print("Upper outlier bound:",q75 + (1.5*iqr))
#dropping the following outliers above 17
df= df[df['Absenteeism time in hours']<=17]
df= df[df['Absenteeism time in hours']>=-7]


#Separating Lables and Attributes
X = df.iloc[:, :-1].values  
Y = df.iloc[:, 14].values  

#Spliting the dataset
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1830210.npy", { "accuracy_score": score })

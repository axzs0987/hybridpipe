import pandas as pd
# T# h# e#  # b# a# s# i# c#  # o# u# t# l# i# n# e#  # o# f#  # t# h# i# s#  # w# o# r# k# b# o# o# k#  # i# s#  # a# s#  # f# o# l# l# o# w# s# :# 
# 
# 1# .#  # *# *# L# o# a# d# i# n# g#  # D# a# t# a# *# *# 
# 2# .#  # *# *# E# D# A#  # &#  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# *# *# 
# 3# .#  # *# *# P# r# e# p# r# o# c# e# s# s# i# n# g# *# *# 
# 4# .#  # *# *# C# r# e# a# t# i# n# g#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t#  # s# e# t# s# *# *# 
# 5# .#  # *# *# R# a# n# d# o# m#  # F# o# r# e# s# t# *# *# 
# 6# .#  # *# *# X# G# B# o# o# s# t# *# *# 
# 7# .#  # *# *# N# e# u# r# a# l#  # N# e# t# w# o# r# k# *# *

# *# *# L# o# a# d# i# n# g#  # D# a# t# a# *# *

# In[10]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sklearn as sk
import seaborn as sns
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

data = pd.read_csv('../input/voice.csv')

# *# *# E# D# A#  # &#  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# *# *

# In[11]

data.head(10)

# In[12]

data.describe()

# In[13]

data.info()

# In[14]

correlation = data.corr()
correlation

# In[15]

# Plotting correlation matrix
plt.figure(figsize=(15,15))
sns.heatmap(correlation, square=True)

# *# *# P# r# e# p# r# o# c# e# s# s# i# n# g# *# *

# In[16]

# Importing sklearn libraries
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn import metrics

# In[17]

X = data.iloc[:,:-1].values
y = data.iloc[:,-1].values

# In[18]

print(y)

# In[19]

# Encoding label (male=1 and female=0)
encoder = LabelEncoder()
y = encoder.fit_transform(y)
print(y)

# In[20]

# Standarizing features
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)

# ## ## ##  # C# r# e# a# t# i# n# g#  # T# r# a# i# n# i# n# g#  # a# n# d#  # T# e# s# t#  # s# e# t# s

# In[21]

# 70-30% of train and test
from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(Xtrain, ytrain)
y_pred = model.predict(Xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/322282.npy", { "accuracy_score": score })

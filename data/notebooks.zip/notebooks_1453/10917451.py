import pandas as pd
# 
# 
# ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # A#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # P# e# r# s# p# e# c# t# i# v# e# :#  # S# u# r# v# e# y#  # 
# 


# *# *# A# b# s# t# r# a# c# t# :# *# *#  # I# n#  # t# h# i# s#  # w# o# r# k#  #  # t# h# e#  # A# d# u# l# t# s#  # I# n# c# o# m# e#  # C# e# n# s# u# s#  # d# a# t# a# s# e# t#  # i# n#  # K# a# g# g# l# e#  # w# e# b# s# i# t# e#  # i# s#  # s# e# l# e# c# t# e# d#  # a# s#  # s# u# b# j# e# c# t#  # f# o# r#  # a# p# p# l# y# i# n# g#  # d# i# v# e# r# s# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# e# c# h# n# i# q# u# e# s# .#  # T# h# i# s#  # d# a# t# a#  # w# a# s#  # e# x# t# r# a# c# t# e# d#  # f# r# o# m#  # t# h# e#  # 1# 9# 9# 4#  # C# e# n# s# u# s#  # b# u# r# e# a# u#  # d# a# t# a# b# a# s# e#  # b# y#  # R# o# n# n# y#  # K# o# h# a# v# i#  # a# n# d#  # B# a# r# r# y#  # B# e# c# k# e# r#  # (# D# a# t# a#  # M# i# n# i# n# g#  # a# n# d#  # V# i# s# u# a# l# i# z# a# t# i# o# n# ,#  # S# i# l# i# c# o# n#  # G# r# a# p# h# i# c# s# )# .#  # A#  # s# e# t#  # o# f#  # r# e# a# s# o# n# a# b# l# y#  # c# l# e# a# n#  # r# e# c# o# r# d# s#  # w# a# s#  # e# x# t# r# a# c# t# e# d#  # u# s# i# n# g#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # c# o# n# d# i# t# i# o# n# s# :#  # (# (# A# A# G# E# ># 1# 6# )#  # &# &#  # (# A# G# I# ># 1# 0# 0# )#  # &# &#  # (# A# F# N# L# W# G# T# ># 1# )#  # &# &#  # (# H# R# S# W# K# ># 0# )# )# .#  # T# h# e#  # p# r# e# d# i# c# t# i# o# n#  # t# a# s# k#  # i# s#  # t# o#  # d# e# t# e# r# m# i# n# e#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # m# a# k# e# s#  # o# v# e# r#  # 5# 0# K#  # d# o# l# l# a# r# s#  # a#  # y# e# a# r# .# 
# 2# 4# 7#  # c# o# d# i# n# g#  # l# i# t# e# r# a# r# y#  # w# o# r# k# s#  # w# e# r# e#  # w# r# i# t# t# e# n#  # o# n#  # t# h# i# s#  # d# a# t# a# s# e# t#  # i# n#  # K# a# g# g# l# e#  # i# n#  # d# i# f# f# e# r# e# n# t#  # c# o# m# p# u# t# i# n# g#  # l# a# n# g# u# a# g# e# s# ,#  # i# n#  # t# h# i# s#  # w# o# r# k#  # w# e#  # c# o# n# s# i# d# e# r#  # o# n# l# y#  # t# h# e#  # t# o# p#  # n# o# t# e# b# o# o# k# s#  # w# r# i# t# t# e# n#  # i# n#  # p# y# t# h# o# n#  # .# T# h# e#  # t# a# s# k#  #  #  # i# s#  # t# o#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # t# h# e#  # p# a# r# t# i# c# u# l# a# r#  # a# d# u# l# t#  # e# a# r# n# s#  # m# o# r# e#  # o# r#  # l# e# s# s#  # t# h# a# n#  # $# 5# 0# 0# 0# 0# ,#  # b# y#  # f# i# n# d# i# n# g#  # p# a# t# t# e# r# n# s#  # i# n#  # t# h# e#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# .# 
# 
# *# *# K# e# y# w# o# r# d# s# *# *# —# K# a# g# g# l# e# ,#  # D# a# t# a#  # S# c# i# e# n# t# i# s# t# s# ,#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # E# n# g# i# n# e# e# r# s# ,# P# y# t# h# o# n# 
# 
# ##  # I# .#  # I# N# T# R# O# D# U# C# T# I# O# N# 
# 
# 
# H# u# m# a# n#  # d# e# p# e# n# d# e# n# c# e#  # o# n#  # d# a# t# a#  # i# n# s# i# g# h# t# s#  # i# n#  # s# o# c# i# e# t# y#  # h# a# s#  # i# n# c# r# e# a# s# e# d#  # o# v# e# r#  # t# h# e#  # p# a# s# t#  # t# w# o#  # d# e# c# a# d# e# s# .#  # W# i# t# h#  # t# h# e#  # e# m# e# r# g# i# n# g#  # t# e# c# h# n# o# l# o# g# i# e# s#  # t# h# e# r# e#  # i# s#  # a#  # h# u# g# e#  # d# e# m# a# n# d#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # w# h# i# c# h#  # h# a# s#  # i# t# s#  # a# p# p# l# i# c# a# t# i# o# n# s#  # i# n#  # a# l# l#  # t# y# p# e# s#  # o# f#  # t# h# e#  # i# n# d# u# s# t# r# i# e# s# .#  # B# y#  # M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g# ,#  # a# u# t# o# m# a# t# e# d#  # d# e# c# i# s# i# o# n# s#  # w# i# l# l#  # b# e#  # p# r# e# d# i# c# t# e# d#  # b# a# s# e# d#  # o# n#  # s# a# m# p# l# e#  # d# a# t# a#  # i# n# p# u# t# s# .# .#  # P# r# o# b# l# e# m# s#  # r# e# l# a# t# i# n# g#  # t# o#  # s# i# g# n# i# f# i# c# a# n# t#  # d# o# m# a# i# n# s#  # o# f#  # s# o# c# i# a# l#  # l# i# f# e# ,#  # r# e# t# a# i# l#  # s# e# c# t# o# r#  # a# n# d#  # p# u# b# l# i# c#  # s# a# f# e# t# y#  # h# a# v# e#  # b# e# e# n#  # a# d# d# r# e# s# s# e# d#  # b# y#  # u# s# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# e# c# h# n# i# q# u# e# s# .#  # T# h# e# s# e#  # t# h# r# e# e#  # d# o# m# a# i# n# s#  # p# l# a# y#  # a#  # v# e# r# y#  # i# m# p# o# r# t# a# n# t#  # r# o# l# e#  # i# n#  # d# a# i# l# y#  # h# u# m# a# n#  # l# i# f# e# ,#  # b# r# i# n# g# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# e# c# h# n# i# q# u# e# s#  # t# o#  # t# h# e# s# e#  # d# o# m# a# i# n# s#  # c# a# n#  # b# r# i# n# g#  # s# i# g# n# i# f# i# c# a# n# t#  # c# h# a# n# g# e#  # i# n#  # t# h# e#  # l# i# f# e#  # s# t# y# l# e#  # o# f#  # h# u# m# a# n# s# .#  # T# h# e#  # e# c# o# n# o# m# i# c#  # s# t# a# t# u# s#  # p# l# a# y#  # a# n#  # i# m# p# o# r# t# a# n# t#  # r# o# l# e#  # i# n#  # d# e# t# e# r# m# i# n# i# n# g#  # t# h# e#  # s# o# c# i# a# l#  # l# i# f# e#  # o# f#  # a# n#  # i# n# d# i# v# i# d# u# a# l# ,#  # t# h# e# r# e#  # i# s#  # a#  # s# i# g# n# i# f# i# c# a# n# t#  # i# n# t# e# r# e# s# t#  # i# n#  # t# h# e# s# e#  # d# a# y# s#  # f# r# o# m#  # g# o# v# e# r# n# m# e# n# t#  # t# o#  # s# t# a# n# d# a# r# d# i# z# e#  # t# h# e# s# e#  # s# o# c# i# a# l#  # s# u# r# v# e# y#  # p# l# a# t# f# o# r# m# s#  # i# n#  # t# h# e# i# r#  # c# o# u# n# t# r# y#  # a# n# d#  # t# h# e# r# e#  # i# s#  # a#  # t# r# e# m# e# n# d# o# u# s#  # s# c# o# p# e#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# e# c# h# n# i# q# u# e# s#  # t# o#  # b# e#  # i# m# p# l# e# m# e# n# t#  # i# n#  # t# h# e# s# e#  # s# u# r# v# e# y#  # t# o#  # o# b# t# a# i# n#  # i# n# t# e# r# e# s# t# i# n# g#  # i# n# s# i# g# h# t# s#  # o# n#  # s# o# c# i# a# l#  # a# n# d#  # e# c# o# n# o# m# i# c#  # l# i# f# e#  # o# f#  # c# i# t# i# z# e# n# s# .# 
# R# a# w#  # d# a# t# a#  # i# s#  # l# i# k# e#  # c# r# u# d# e#  # o# i# l# ,#  # b# y#  # p# r# o# c# e# s# s# i# n# g#  # w# e#  # c# a# n#  # g# e# t#  # d# e# s# i# r# e# d#  # p# r# o# d# u# c# t# s# .#  # S# i# m# i# l# a# r# l# y#  # b# y#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # t# h# e#  # d# a# t# a#  # w# e#  # c# a# n#  # d# r# a# w#  # i# n# s# i# g# h# t# s#  # o# n#  # w# h# a# t#  # f# a# c# t# o# r# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # d# e# p# e# n# d# s#  # o# n# .#  # O# u# r#  # d# a# t# a# s# e# t#  # c# o# n# t# a# i# n# s#  # 1# 4#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # o# n# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # w# i# t# h#  # 3# 2# 5# 6# 1#  # s# a# m# p# l# e# s# .#  # 
# 
# ##  # I# I# .#  # D# A# T# A#  # D# E# S# C# R# I# P# T# I# O# N# 
# 
# T# h# i# s#  # d# a# t# a# s# e# t#  # i# s#  # e# x# t# r# a# c# t# e# d#  # f# r# o# m#  # 1# 9# 9# 4#  # C# e# n# s# u# s#  # i# n#  # s# u# c# h#  # w# a# y#  # t# o#  # t# o#  # f# o# c# u# s#  # o# n#  # a# d# u# l# t# s# ,#  # t# o#  # s# t# u# d# y#  # t# h# e# i# r#  # i# n# c# o# m# e# .# T# h# i# s#  # d# a# t# a# s# e# t#  # c# o# n# t# a# i# n# s#  # 3# 2# 5# 1# 6#  # s# a# m# p# l# e# s#  # a# n# d#  # 1# 5#  # v# a# r# i# a# b# l# e# s#  # i# n#  # w# h# i# c# h#  # 1# 4#  # a# r# e#  # i# n# d# e# p# e# n# d# e# n# t#  # b# u# t#  # I# n# c# o# m# e#  # v# a# r# i# a# b# l# e#  # i# s#  # a#  # t# a# r# g# e# t#  # o# r#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e#  # a# s#  # i# t#  # d# e# p# e# n# d# s#  # u# p# o# n#  # t# h# e# s# e#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# .# 
# 
# i# n# c# o# m# e# :#  # ># 5# 0# K# ,#  # <# =# 5# 0# K#  # 
# 
# a# g# e# :#  # a# g# e#  # o# f#  # a#  # p# e# r# s# o# n# 
# 
# w# o# r# k# c# l# a# s# s# :#  # P# r# i# v# a# t# e# ,#  # S# e# l# f# -# e# m# p# -# n# o# t# -# i# n# c# ,#  # S# e# l# f# -# e# m# p# -# i# n# c# ,#  # F# e# d# e# r# a# l# -# g# o# v# ,#  # L# o# c# a# l# -# g# o# v# ,#  # S# t# a# t# e# -# g# o# v# ,#  # W# i# t# h# o# u# t# -# p# a# y# ,#  # N# e# v# e# r# -# w# o# r# k# e# d# 
# 
# f# n# l# w# g# t# :#  # T# h# e#  # w# e# i# g# h# t#  # g# i# v# e# n#  # b# y#  # t# h# e#  # c# e# n# s# u# s#  # b# o# a# r# d# 
# 
# e# d# u# c# a# t# i# o# n# _# n# u# m# :#  # C# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e#  # o# f#  # t# h# e#  # e# d# u# c# a# t# i# o# n# 
# 
# 
# 
# e# d# u# c# a# t# i# o# n# :#  # B# a# c# h# e# l# o# r# s# ,#  # S# o# m# e# -# c# o# l# l# e# g# e# ,#  # 1# 1# t# h# ,#  # H# S# -# g# r# a# d# ,#  # P# r# o# f# -# s# c# h# o# o# l# ,#  # A# s# s# o# c# -# a# c# d# m# ,#  # A# s# s# o# c# -# v# o# c# ,#  # 9# t# h# ,#  # 7# t# h# -# 8# t# h# ,#  # 1# 2# t# h# ,#  # M# a# s# t# e# r# s# ,#  # 1# s# t# -# 4# t# h# ,#  # 1# 0# t# h# ,#  # D# o# c# t# o# r# a# t# e# ,#  # 5# t# h# -# 6# t# h# ,#  # P# r# e# s# c# h# o# o# l#  # e# d# u# c# a# t# i# o# n# -# n# u# m# :#  # c# o# n# t# i# n# u# o# u# s# 
# m# a# r# i# t# a# l# -# s# t# a# t# u# s# :#  # M# a# r# r# i# e# d# -# c# i# v# -# s# p# o# u# s# e# ,#  # D# i# v# o# r# c# e# d# ,#  # N# e# v# e# r# -# m# a# r# r# i# e# d# ,#  # S# e# p# a# r# a# t# e# d# ,#  # W# i# d# o# w# e# d# ,#  # M# a# r# r# i# e# d# -# s# p# o# u# s# e# -# a# b# s# e# n# t# ,#  # M# a# r# r# i# e# d# -# A# F# -# s# p# o# u# s# e# 
# 
# o# c# c# u# p# a# t# i# o# n# :#  # T# e# c# h# -# s# u# p# p# o# r# t# ,#  # C# r# a# f# t# -# r# e# p# a# i# r# ,#  # O# t# h# e# r# -# s# e# r# v# i# c# e# ,#  # S# a# l# e# s# ,#  # E# x# e# c# -# m# a# n# a# g# e# r# i# a# l# ,#  # P# r# o# f# -# s# p# e# c# i# a# l# t# y# ,#  # H# a# n# d# l# e# r# s# -# c# l# e# a# n# e# r# s# ,#  # M# a# c# h# i# n# e# -# o# p# -# i# n# s# p# e# c# t# ,#  # A# d# m# -# c# l# e# r# i# c# a# l# ,#  # F# a# r# m# i# n# g# -# f# i# s# h# i# n# g# ,#  # T# r# a# n# s# p# o# r# t# -# m# o# v# i# n# g# ,#  # P# r# i# v# -# h# o# u# s# e# -# s# e# r# v# ,#  # P# r# o# t# e# c# t# i# v# e# -# s# e# r# v# ,#  # A# r# m# e# d# -# F# o# r# c# e# s# 
# 
# r# e# l# a# t# i# o# n# s# h# i# p# :#  # W# i# f# e# ,#  # O# w# n# -# c# h# i# l# d# ,#  # H# u# s# b# a# n# d# ,#  # N# o# t# -# i# n# -# f# a# m# i# l# y# ,#  # O# t# h# e# r# -# r# e# l# a# t# i# v# e# ,#  # U# n# m# a# r# r# i# e# d# 
# r# a# c# e# :#  # W# h# i# t# e# ,#  # A# s# i# a# n# -# P# a# c# -# I# s# l# a# n# d# e# r# ,#  # A# m# e# r# -# I# n# d# i# a# n# -# E# s# k# i# m# o# ,#  # O# t# h# e# r# ,#  # B# l# a# c# k# 
# 
# s# e# x# :#  # F# e# m# a# l# e# ,#  # M# a# l# e# 
# 
# c# a# p# i# t# a# l# -# g# a# i# n# :#  # g# a# i# n#  # i# n#  # c# a# p# i# t# a# l# 
# 
# c# a# p# i# t# a# l# -# l# o# s# s# :#  # l# o# s# s#  # i# n#  # c# a# p# i# t# a# l# 
# 
# h# o# u# r# s# -# p# e# r# -# w# e# e# k# :#  # c# h# o# r# u# s#  # t# h# e#  # p# e# r# s# o# n#  # w# o# r# k# e# d#  # f# o# r#  # a#  # w# e# e# k# 
# 
# n# a# t# i# v# e# -# c# o# u# n# t# r# y# :#  # U# n# i# t# e# d# -# S# t# a# t# e# s# ,#  # C# a# m# b# o# d# i# a# ,#  # E# n# g# l# a# n# d# ,#  # P# u# e# r# t# o# -# R# i# c# o# ,#  # C# a# n# a# d# a# ,#  # G# e# r# m# a# n# y# ,#  # O# u# t# l# y# i# n# g# -# U# S# (# G# u# a# m# -# U# S# V# I# -# e# t# c# )# ,#  # I# n# d# i# a# ,#  # J# a# p# a# n# ,#  # G# r# e# e# c# e# ,#  # S# o# u# t# h# ,#  # C# h# i# n# a# ,#  # C# u# b# a# ,#  # I# r# a# n# ,#  # H# o# n# d# u# r# a# s# ,#  # P# h# i# l# i# p# p# i# n# e# s# ,#  # I# t# a# l# y# ,#  # P# o# l# a# n# d# ,#  # J# a# m# a# i# c# a# ,#  # V# i# e# t# n# a# m# ,#  # M# e# x# i# c# o# ,#  # P# o# r# t# u# g# a# l# ,#  # I# r# e# l# a# n# d# ,#  # F# r# a# n# c# e# ,#  # D# o# m# i# n# i# c# a# n# -# R# e# p# u# b# l# i# c# ,#  # L# a# o# s# ,#  # E# c# u# a# d# o# r# ,#  # T# a# i# w# a# n# ,#  # H# a# i# t# i# ,#  # C# o# l# u# m# b# i# a# ,#  # H# u# n# g# a# r# y# ,#  # G# u# a# t# e# m# a# l# a# ,#  # N# i# c# a# r# a# g# u# a# ,#  # S# c# o# t# l# a# n# d# ,#  # T# h# a# i# l# a# n# d# ,#  # Y# u# g# o# s# l# a# v# i# a# ,#  # E# l# -# S# a# l# v# a# d# o# r# ,#  # T# r# i# n# a# d# a# d# &# T# o# b# a# g# o# ,#  # P# e# r# u# ,#  # H# o# n# g# ,#  # H# o# l# a# n# d# -# N# e# t# h# e# r# l# a# n# d# s# 
# 
# ##  # I# I# I# .#  # D# A# T# A#  # P# R# E# P# R# O# C# E# S# S# I# N# G# 
# 
# B# e# f# o# r# e#  # g# o# i# n# g#  # i# n# t# o#  # d# a# t# a#  # p# r# e# p# r# o# c# e# s# s# i# n# g# ,#  # I#  # w# o# u# l# d#  # l# i# k# e#  # t# o#  # m# e# n# t# i# o# n#  # a# b# o# u# t#  # t# h# e#  # l# i# b# r# a# r# i# e# s#  # t# h# a# t#  # w# e# r# e#  # i# m# p# o# r# t# e# d#  # a# n# d#  # r# e# a# d# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t# .#  # D# i# f# f# e# r# e# n# t#  # n# o# t# e# b# o# o# k# s#  # d# i# d#  # i# t#  # i# n#  # d# i# f# f# e# r# e# n# t#  # s# t# y# l# e# ,#  # o# n# e#  # c# a# n#  # i# m# p# o# r# t#  # a# l# l#  # t# h# e#  # l# i# b# r# a# r# i# e# s#  # i# n#  # s# i# n# g# l# e#  # s# t# e# p#  # l# i# k# e#  # i# n#  # [# 2# ]# [# 3# ]# [# 6# ]# ,#  # o# r#  # m# u# l# t# i# p# l# e#  # s# t# e# p# s#  # w# h# e# n# e# v# e# r#  # t# h# e# y#  # r# e# q# u# i# r# e# d#  # l# i# k# e#  # i# n#  # [# 1# ]# [# 4# ]# [# 5# ]# .#  # A# l# l#  # t# h# e#  # n# o# t# e# b# o# o# k# s#  # r# e# a# d# _# c# s# v#  # f# u# n# c# t# i# o# n#  # i# n#  # p# a# n# d# a# s#  # t# o#  # r# e# a# d#  # t# h# e#  # d# a# t# a# .# 
# 
# M# o# s# t#  # p# o# p# u# l# a# r#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # l# i# b# r# a# r# i# e# s#  # w# r# i# t# t# e# n#  # i# n#  # p# y# t# h# o# n#  # c# o# m# p# u# t# i# n# g#  # l# a# n# g# u# a# g# e#  # a# r# e#  # P# a# n# d# a# s# ,#  # N# u# m# p# y# ,#  # S# k# l# e# a# r# n# .#  # 
# 
# U# s# i# n# g#  # .# i# n# f# o#  # o# r#  # .# d# e# s# c# r# i# b# e#  # c# a# n#  # h# e# l# p#  # u# s#  # u# n# d# e# r# s# t# a# n# d#  # m# o# r# e#  # a# b# o# u# t#  # t# h# e#  # d# a# t# a#  # [# 1# ]# [# 5# ]# .# 
# 
# ## ##  # A# .#  # H# a# n# d# l# i# n# g#  # M# i# s# s# i# n# g#  # v# a# l# u# e# s# 
# 
# M# o# s# t#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# s#  # w# i# l# l#  # h# a# v# e#  # n# u# l# l#  # v# a# l# u# e# s# ,#  # w# e#  # h# a# v# e#  # t# o#  # p# r# o# c# e# s# s#  # t# h# e# m#  # b# e# f# o# r# e#  # b# u# i# l# d# i# n# g#  # a#  # m# o# d# e# l# .#  # T# h# e#  # w# a# y# s#  # o# f#  # t# r# e# a# t# i# n# g#  # t# h# e# s# e#  #  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# s#  # t# o#  # d# r# o# p#  # t# h# e#  # s# a# m# p# l# e# s#  # t# h# a# t#  # h# a# v# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # r# e# p# l# a# c# e#  # t# h# e# m#  # w# i# t# h#  # m# e# a# n#  # o# r#  # m# e# d# i# a# n#  # o# r#  # m# o# d# e#  # ,#  # t# r# e# a# t#  # a# l# l#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # a# s#  # a#  # n# e# w#  # c# l# a# s# s# (# p# o# s# s# i# b# l# e#  # o# n# l# y#  # i# n#  # f# e# w#  # c# a# s# e# s# )# .# I# n#  # t# h# i# s#  # d# a# t# a# s# e# t#  # n# u# l# l#  # v# a# l# u# e# s#  # a# r# e#  # i# n#  # t# h# e#  # i# n#  # t# h# e#  # f# o# r# m#  # o# f#  # ‘# ?# ’#  # s# o#  # r# e# p# l# a# c# e#  # i# t#  # w# i# t# h#  # ‘# n# p# .# n# a# n# ’# .# 
# 
# 
# 
# W# e#  # c# a# n#  # a# l# s# o#  # t# r# y#  # b# y#  # m# e# r# g# i# n# g#  # d# i# f# f# e# r# e# n# t#  # c# a# t# e# g# o# r# i# e# s#  # i# n#  # a#  # p# a# r# t# i# c# u# l# a# r#  # c# a# t# e# g# o# r# i# c# a# l#  # c# o# l# u# m# n#  # o# r#  # c# o# l# u# m# n# s#  #  # l# i# k# e#  # i# n#  # [# 2# ]# [# 3# ]# [# 6# ]# .# 
# 
# ## ##  # B# .#  # L# a# b# e# l#  # E# n# c# o# d# i# n# g# 
# G# e# n# e# r# a# l# l# y#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # o# f#  # t# w# o#  # k# i# n# d# s#  # o# f#  # d# a# t# a# t# y# p# e# s#  # w# h# i# c# h#  # i# s#  # N# u# m# e# r# i# c# a# l#  # a# n# d#  # S# t# r# i# n# g# ,#  # m# o# s# t#  # o# f#  # t# h# e#  # a# l# g# o# r# i# t# h# m# s#  # w# o# r# k# s#  # b# e# t# t# e# r#  # w# i# t# h#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # s# o#  # i# n#  # o# r# d# e# r#  # t# o#  # d# r# a# w#  # i# n# s# i# g# h# t# s#  # f# r# o# m#  #  # t# h# e#  # s# t# r# i# n# g#  # v# a# r# i# a# b# l# e# s# ,#  # w# e#  # n# e# e# d#  # t# o#  # e# n# c# o# d# e#  # t# h# e# m#  # .# T# h# i# s#  # c# a# n#  # b# e#  # d# o# n# e#  # b# y#  # t# h# e#  # l# a# b# e# l#  # e# n# c# o# d# e# r#  # o# r#  # o# n# e# h# o# t#  # e# n# c# o# d# e# r#  # f# r# o# m#  # s# k# l# e# a# r# n#  # l# i# b# r# a# r# y#  # l# i# k# e#  # i# n#  # [# 4# ]# [# 5# ]# [# 6# ]# .# 
# 
# ## ##  # C# .#  # S# c# a# l# i# n# g# 
# T# h# e#  # v# a# r# i# a# b# l# e# s#  # m# i# g# h# t#  # b# e#  # i# n#  # d# i# f# f# e# r# e# n# t#  # r# a# n# g# e# s# ,#  # t# h# e#  # h# u# g# e#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # m# a# g# n# i# t# u# d# e#  # o# f#  # v# a# r# i# a# b# l# e# s#  # m# i# g# h# t#  # e# f# f# e# c# t#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n#  # o# f#  #  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .#  # .# M# i# n# M# a# x# S# c# a# l# e# r# ,#  # S# t# a# n# d# a# r# d# S# c# a# l# e# r# ,#  #  # R# o# b# u# s# t# S# c# a# l# e# r#  # a# n# d#  # N# o# r# m# a# l# i# z# e# r#  # c# a# n#  # h# e# l# p#  # u# s#  # t# o#  # b# r# i# n# g#  # e# n# t# i# r# e#  # d# a# t# a#  # o# n# t# o#  # a#  # u# n# i# f# o# r# m#  # s# c# a# l# e# d#  # r# a# n# g# e#  # o# f#  # v# a# l# u# e# s# .#  # 
# 
# ## ##  # D# .#  # C# o# r# r# e# l# a# t# i# o# n# 
# C# o# r# r# e# l# a# t# i# o# n# ,#  # i# s#  # a#  # s# t# a# t# i# s# t# i# c# a# l#  # t# e# c# h# n# i# q# u# e#  # t# o#  # d# e# t# e# r# m# i# n# e# s#  # h# o# w#  # o# n# e#  # v# a# r# i# a# b# l# e# s#  # v# a# r# i# e# s#  # w# i# t# h#  # t# h# e#  # o# t# h# e# r#  # v# a# r# i# a# b# l# e# ,#  # t# h# i# s#  # g# i# v# e# s#  # t# h# e#  # i# d# e# a#  # o# n#  # d# e# g# r# e# e#  # o# f#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # o# f#  # t# h# e#  # t# w# o#  # v# a# r# i# a# b# l# e# s# .#  # I# t# ’# s#  # a#  # b# i# -# v# a# r# i# a# t# e#  # a# n# a# l# y# s# i# s#  # m# e# a# s# u# r# e#  # w# h# i# c# h#  # d# e# s# c# r# i# b# e# s#  # t# h# e#  # a# s# s# o# c# i# a# t# i# o# n#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # v# a# r# i# a# b# l# e# s# .#  # I# n#  # m# o# s# t#  # o# f#  # t# h# e#  # a# n# a# l# y# s# i# s#  # w# o# r# k# s#  # i# t#  # i# s#  # u# s# e# f# u# l#  # t# o#  # e# x# p# r# e# s# s#  # o# n# e#  # v# a# r# i# a# b# l# e#  # i# n#  # t# e# r# m# s#  # o# f#  #  # o# t# h# e# r# s# .# 
# 
# 
# A# s#  # w# e#  # o# b# s# e# r# v# e#  # t# h# e# r# e#  # a# r# e#  # v# a# r# i# o# u# s#  # d# a# t# a#  # t# y# p# e# s#  # a# c# r# o# s# s#  # t# h# e#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # o# f#  # d# a# t# a# s# e# t# .#  # T# o#  # m# a# i# n# t# a# i# n#  # u# n# i# f# o# r# m# i# t# y#  # t# h# e#  # c# o# l# u# m# n# s#  # [#  # w# o# r# k# c# l# a# s# s# ,#  # e# d# u# c# a# t# i# o# n# ,#  # m# a# r# i# t# a# l# _# s# t# a# t# u# s# ,#  # o# c# c# u# p# a# t# i# o# n# ,#  # r# e# l# a# t# i# o# n# s# h# i# p# ,#  # r# a# c# e# ,#  # s# e# x#  # ,#  # n# a# t# i# v# e# _# c# o# u# n# t# r# y# ]#  # w# e# r# e#  # e# n# c# o# d# e# d#  # i# n# t# o#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# .#  # T# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # ‘# i# n# c# o# m# e# ’#  # i# s#  # a# l# s# o#  # c# a# t# e# g# o# r# i# z# e# d#  # t# o#  # f# o# r# m#  # ‘# T# w# o# ’#  # c# a# t# e# g# o# r# i# e# s#  # f# o# r#  # m# o# r# e#  # t# h# a# n#  # 5# 0# k#  # d# o# l# l# a# r# s# /# y# e# a# r#  # o# r#  # l# e# s# s#  # t# h# a# n#  # 5# 0# k#  # d# o# l# l# a# r# s#  # y# e# a# r# .#  # T# h# e#  # d# a# t# a# s# e# t#  # i# s#  # m# a# d# e#  # s# p# l# i# t#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # d# a# t# a# s# e# t# s#  # w# i# t# h#  # 7# 0# :# 3# 0#  # r# a# t# i# o#  # a# n# d#  # s# c# a# l# i# n# g#  # o# f#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # i# s#  # m# a# d# e#  # u# s# i# n# g#  # s# t# a# n# d# a# r# d#  # s# c# a# l# i# n# g#  # t# e# c# h# n# i# q# u# e# s#  # t# o#  # o# b# t# a# i# n#  # d# a# t# a#  # o# f#  # z# e# r# o#  # m# e# a# n#  # a# n# d#  # u# n# i# t#  # v# a# r# i# a# n# c# e# .# 
# 
# ##  # I# V# .#  #  # M# O# D# E# L#  # B# U# I# L# D# I# N# G# 
# 
# D# i# f# f# e# r# e# n# t#  # C# l# a# s# s# i# f# a# c# t# i# o# n#  # a# l# g# o# r# i# t# h# m# s#  # a# r# e#  # a# p# p# l# i# e# d#  # o# n#  # t# h# e#  # d# a# t# a# s# e# t#  # a# n# d#  # d# i# f# f# e# r# e# n# t#  # r# e# s# u# l# t# s#  # y# i# e# '# l# d# e# d# .# 
# 
# ## ##  # A# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# :# 
# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # i# s#  # a#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # p# r# i# m# a# r# i# l# y#  # u# s# e# d#  # f# o# r#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ;#  # t# h# i# s#  # i# s#  # a#  # p# r# e# d# i# c# t# i# v# e#  # a# n# a# l# y# s# i# s#  # a# l# g# o# r# i# t# h# m#  # w# h# i# c# h#  # i# s#  # b# a# s# e# d#  # o# n#  # p# r# o# b# a# b# i# l# i# t# y#  # c# o# n# c# e# p# t# .# 
# 
# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # u# s# e# s#  # a#  # S# i# g# m# o# i# d#  # o# r#  # l# o# g# i# s# t# i# c#  # f# u# n# c# t# i# o# n#  # a# s#  # c# o# s# t#  # f# u# n# c# t# i# o# n# .# 
# T# h# e#  # h# y# p# o# t# h# e# s# i# s#  # o# f#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # t# e# n# d# s#  # t# o#  # l# i# m# i# t#  # t# h# e#  # c# o# s# t#  # f# u# n# c# t# i# o# n#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .#  # T# h# e# r# e# f# o# r# e#  # l# i# n# e# a# r#  # f# u# n# c# t# i# o# n# s#  # f# a# i# l#  # t# o#  # r# e# p# r# e# s# e# n# t#  # i# t#  # a# s#  # i# t#  # c# a# n#  # h# a# v# e#  # a#  # v# a# l# u# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 1#  # o# r#  # l# e# s# s#  # t# h# a# n#  # 0#  # w# h# i# c# h#  # i# s#  # n# o# t#  # p# o# s# s# i# b# l# e#  # a# s#  # p# e# r#  # t# h# e#  # h# y# p# o# t# h# e# s# i# s#  # o# f#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n# .# 
# 
# *# *# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # h# y# p# e# r#  # p# a# r# a# m# e# t# e# r# s# :# *# *# 
# 
# *# S# o# l# v# e# r# *#  # i# n#  # [# ‘# n# e# w# t# o# n# -# c# g# ’# ,#  # ‘# l# b# f# g# s# ’# ,#  # ‘# l# i# b# l# i# n# e# a# r# ’# ,#  # ‘# s# a# g# ’# ,#  # ‘# s# a# g# a# ’# ]# 
# R# e# g# u# l# a# r# i# z# a# t# i# o# n#  # (# p# e# n# a# l# t# y# )#  # c# a# n#  # s# o# m# e# t# i# m# e# s#  # b# e#  # h# e# l# p# f# u# l# .# 
# 
# *# P# e# n# a# l# t# y# *#  # i# n#  # [# ‘# n# o# n# e# ’# ,#  # ‘# l# 1# ’# ,#  # ‘# l# 2# ’# ,#  # ‘# e# l# a# s# t# i# c# n# e# t# ’# ]# 
# 
# N# o# t# e# :#  # n# o# t#  # a# l# l#  # s# o# l# v# e# r# s#  # s# u# p# p# o# r# t#  # a# l# l#  # r# e# g# u# l# a# r# i# z# a# t# i# o# n#  # t# e# r# m# s# .# 
# 
# T# h# e#  # *# C#  # p# a# r# a# m# e# t# e# r# *#  # c# o# n# t# r# o# l# s#  # t# h# e#  # p# e# n# a# l# t# y#  # s# t# r# e# n# g# t# h# ,#  # w# h# i# c# h#  # c# a# n#  # a# l# s# o#  # b# e#  # e# f# f# e# c# t# i# v# e# .# 
# C#  # i# n#  # [# 1# 0# 0# ,#  # 1# 0# ,#  # 1# .# 0# ,#  # 0# .# 1# ,#  # 0# .# 0# 1# ]# 
# 
# ## ##  # B# .#  # K# N# N# :# 
# I# n#  # k# -# N# N#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ,#  # t# h# e#  # o# u# t# p# u# t#  # i# s#  # a#  # c# l# a# s# s#  # m# e# m# b# e# r# s# h# i# p# .#  # A# n#  # o# b# j# e# c# t#  # i# s#  # c# l# a# s# s# i# f# i# e# d#  # b# y#  # a#  # p# l# u# r# a# l# i# t# y#  # v# o# t# e#  # o# f#  # i# t# s#  # n# e# i# g# h# b# o# r# s# ,#  # w# i# t# h#  # t# h# e#  # o# b# j# e# c# t#  # b# e# i# n# g#  # a# s# s# i# g# n# e# d#  # t# o#  # t# h# e#  # c# l# a# s# s#  # m# o# s# t#  # c# o# m# m# o# n#  # a# m# o# n# g#  # i# t# s#  # k#  # n# e# a# r# e# s# t#  # n# e# i# g# h# b# o# r# s#  # (# k#  # i# s#  # a#  # p# o# s# i# t# i# v# e#  # i# n# t# e# g# e# r# ,#  # t# y# p# i# c# a# l# l# y#  # s# m# a# l# l# )# .#  # I# f#  # k#  # =#  # 1# ,#  # t# h# e# n#  # t# h# e#  # o# b# j# e# c# t#  # i# s#  # s# i# m# p# l# y#  # a# s# s# i# g# n# e# d#  # t# o#  # t# h# e#  # c# l# a# s# s#  # o# f#  # t# h# a# t#  # s# i# n# g# l# e#  # n# e# a# r# e# s# t#  # n# e# i# g# h# b# o# r# .# 
# 
# *# *# K# N# N#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s# :# -# *# *# 
# 
# *# n# _# n# e# i# g# h# b# o# r# s# *#  # i# n#  # [# 1#  # t# o#  # 2# 1# ]# 
# 
# *# m# e# t# r# i# c# *#  # i# n#  # [# ‘# e# u# c# l# i# d# e# a# n# ’# ,#  # ‘# m# a# n# h# a# t# t# a# n# ’# ,#  # ‘# m# i# n# k# o# w# s# k# i# ’# ]# 
# 
# *# w# e# i# g# h# t# s# *#  # i# n#  # [# ‘# u# n# i# f# o# r# m# ’# ,#  # ‘# d# i# s# t# a# n# c# e# ’# ]# 
# 
# ## ##  # C# .#  # S# V# M# :# 
# 
# “# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e# ”#  # (# S# V# M# )#  # i# s#  # a#  # s# u# p# e# r# v# i# s# e# d#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # w# h# i# c# h#  # c# a# n#  # b# e#  # u# s# e# d#  # f# o# r#  # b# o# t# h#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # o# r#  # r# e# g# r# e# s# s# i# o# n#  # c# h# a# l# l# e# n# g# e# s# .#  # H# o# w# e# v# e# r# ,#  #  # i# t#  # i# s#  # m# o# s# t# l# y#  # u# s# e# d#  # i# n#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# s# .#  # I# n#  # t# h# e#  # S# V# M#  # a# l# g# o# r# i# t# h# m# ,#  # w# e#  # p# l# o# t#  # e# a# c# h#  # d# a# t# a#  # i# t# e# m#  # a# s#  # a#  # p# o# i# n# t#  # i# n#  # n# -# d# i# m# e# n# s# i# o# n# a# l#  # s# p# a# c# e#  # (# w# h# e# r# e#  # n#  # i# s#  # n# u# m# b# e# r#  # o# f#  # f# e# a# t# u# r# e# s#  # y# o# u#  # h# a# v# e# )#  # w# i# t# h#  # t# h# e#  # v# a# l# u# e#  # o# f#  # e# a# c# h#  # f# e# a# t# u# r# e#  # b# e# i# n# g#  # t# h# e#  # v# a# l# u# e#  # o# f#  # a#  # p# a# r# t# i# c# u# l# a# r#  # c# o# o# r# d# i# n# a# t# e# .#  # T# h# e# n# ,#  # w# e#  # p# e# r# f# o# r# m#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # b# y#  # f# i# n# d# i# n# g#  # t# h# e#  # h# y# p# e# r# -# p# l# a# n# e#  # t# h# a# t#  # d# i# f# f# e# r# e# n# t# i# a# t# e# s#  # t# h# e#  # t# w# o#  # c# l# a# s# s# e# s#  # v# e# r# y#  # w# e# l# l# .# 
# 
# I# n#  # t# h# e#  # S# V# M#  # c# l# a# s# s# i# f# i# e# r# ,#  # i# t#  # i# s#  # e# a# s# y#  # t# o#  # h# a# v# e#  # a#  # l# i# n# e# a# r#  # h# y# p# e# r# -# p# l# a# n# e#  # b# e# t# w# e# e# n#  # t# h# e# s# e#  # t# w# o#  # c# l# a# s# s# e# s# .#  # B# u# t# ,#  # a# n# o# t# h# e# r#  # b# u# r# n# i# n# g#  # q# u# e# s# t# i# o# n#  # w# h# i# c# h#  # a# r# i# s# e# s#  # i# s# ,#  # s# h# o# u# l# d#  # w# e#  # n# e# e# d#  # t# o#  # a# d# d#  # t# h# i# s#  # f# e# a# t# u# r# e#  # m# a# n# u# a# l# l# y#  # t# o#  # h# a# v# e#  # a#  # h# y# p# e# r# -# p# l# a# n# e# .#  # N# o# ,#  # t# h# e#  # S# V# M#  #  # a# l# g# o# r# i# t# h# m#  # h# a# s#  # a#  # t# e# c# h# n# i# q# u# e#  # c# a# l# l# e# d#  # t# h# e#  # k# e# r# n# e# l#  # t# r# i# c# k# .#  # T# h# e#  # S# V# M#  # k# e# r# n# e# l#  # i# s#  # a#  # f# u# n# c# t# i# o# n#  # t# h# a# t#  # t# a# k# e# s#  # l# o# w#  # d# i# m# e# n# s# i# o# n# a# l#  # i# n# p# u# t#  # s# p# a# c# e#  # a# n# d#  # t# r# a# n# s# f# o# r# m# s#  # i# t#  # t# o#  # a#  # h# i# g# h# e# r#  # d# i# m# e# n# s# i# o# n# a# l#  # s# p# a# c# e#  # i# .# e# .#  # i# t#  # c# o# n# v# e# r# t# s#  # n# o# t#  # s# e# p# a# r# a# b# l# e#  # p# r# o# b# l# e# m#  # t# o#  # s# e# p# a# r# a# b# l# e#  # p# r# o# b# l# e# m# .#  # I# t#  # i# s#  # m# o# s# t# l# y#  # u# s# e# f# u# l#  # i# n#  # n# o# n# -# l# i# n# e# a# r#  # s# e# p# a# r# a# t# i# o# n#  # p# r# o# b# l# e# m# .#  # S# i# m# p# l# y#  # p# u# t# ,#  # i# t#  # d# o# e# s#  # s# o# m# e#  # e# x# t# r# e# m# e# l# y#  # c# o# m# p# l# e# x#  # d# a# t# a#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n# s# ,#  # t# h# e# n#  # f# i# n# d# s#  # o# u# t#  # t# h# e#  # p# r# o# c# e# s# s#  # t# o#  # s# e# p# a# r# a# t# e#  # t# h# e#  # d# a# t# a#  # b# a# s# e# d#  # o# n#  # t# h# e#  # l# a# b# e# l# s#  # o# r#  # o# u# t# p# u# t# s#  # y# o# u# ’# v# e#  # d# e# f# i# n# e# d# .# 
# 
# *# *# S# V# M#  # H# y# p# e# r# p# a# r# a# m# e# t# e# r# s# :# -# *# *# 
# 
# *# C#  # p# a# r# a# m# e# t# e# r# *# :#  # I# t#  # h# a# n# d# l# e# s#  # t# h# e#  # t# r# a# d# e# o# f# f#  # b# e# t# w# e# e# n#  # t# h# e#  # t# w# o#  # g# o# a# l# s#  # b# e# l# o# w# .# 
# 
# I# n# c# r# e# a# s# e#  # t# h# e#  # d# i# s# t# a# n# c# e#  # o# f#  # d# e# c# i# s# i# o# n#  # b# o# u# n# d# a# r# y#  # t# o#  # c# l# a# s# s# e# s#  # (# o# r#  # s# u# p# p# o# r# t#  # v# e# c# t# o# r# s# )# 
# 
# M# a# x# i# m# i# z# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # p# o# i# n# t# s#  # t# h# a# t#  # a# r# e#  # c# o# r# r# e# c# t# l# y#  # c# l# a# s# s# i# f# i# e# d#  # i# n#  # t# h# e#  # t# r# a# i# n# i# n# g#  # s# e# t# 
# 
# *# K# e# r# n# e# l# *# :#  # L# i# n# e# a# r# ,#  # R# B# F# ,#  # P# o# l# y# 
# 
# *# G# a# m# m# a# *# :#  # O# n# e#  # o# f#  # t# h# e#  # c# o# m# m# o# n# l# y#  # u# s# e# d#  # k# e# r# n# e# l#  # f# u# n# c# t# i# o# n# s#  # i# s#  # r# a# d# i# a# l#  # b# a# s# i# s#  # f# u# n# c# t# i# o# n#  # (# R# B# F# )# .#  # G# a# m# m# a#  # p# a# r# a# m# e# t# e# r#  # o# f#  # R# B# F#  # c# o# n# t# r# o# l# s#  # t# h# e#  # d# i# s# t# a# n# c# e#  # o# f#  # i# n# f# l# u# e# n# c# e#  # o# f#  # a#  # s# i# n# g# l# e#  # t# r# a# i# n# i# n# g#  # p# o# i# n# t# .#  # L# o# w#  # v# a# l# u# e# s#  # o# f#  # g# a# m# m# a#  # i# n# d# i# c# a# t# e# s#  # a#  # l# a# r# g# e#  # s# i# m# i# l# a# r# i# t# y#  # r# a# d# i# u# s#  # w# h# i# c# h#  # r# e# s# u# l# t# s#  # i# n#  # m# o# r# e#  # p# o# i# n# t# s#  # b# e# i# n# g#  # g# r# o# u# p# e# d#  # t# o# g# e# t# h# e# r# .#  # F# o# r#  # h# i# g# h#  # v# a# l# u# e# s#  # o# f#  # g# a# m# m# a# ,#  # t# h# e#  # p# o# i# n# t# s#  # n# e# e# d#  # t# o#  # b# e#  # v# e# r# y#  # c# l# o# s# e#  # t# o#  # e# a# c# h#  # o# t# h# e# r#  # i# n#  # o# r# d# e# r#  # t# o#  # b# e#  # c# o# n# s# i# d# e# r# e# d#  # i# n#  # t# h# e#  # s# a# m# e#  # g# r# o# u# p#  # (# o# r#  # c# l# a# s# s# )# .#  # T# h# e# r# e# f# o# r# e# ,#  # m# o# d# e# l# s#  # w# i# t# h#  # v# e# r# y#  # l# a# r# g# e#  # g# a# m# m# a#  # v# a# l# u# e# s#  # t# e# n# d#  # t# o#  # o# v# e# r# f# i# t# .# 
# 
# A# s#  # t# h# e#  # g# a# m# m# a#  # d# e# c# r# e# a# s# e# s# ,#  # t# h# e#  # r# e# g# i# o# n# s#  # s# e# p# a# r# a# t# i# n# g#  # d# i# f# f# e# r# e# n# t#  # c# l# a# s# s# e# s#  # g# e# t#  # m# o# r# e#  # g# e# n# e# r# a# l# i# z# e# d# .#  # V# e# r# y#  # l# a# r# g# e#  # g# a# m# m# a#  # v# a# l# u# e# s#  # r# e# s# u# l# t#  # i# n#  # t# o# o#  # s# p# e# c# i# f# i# c#  # c# l# a# s# s#  # r# e# g# i# o# n# s#  # (# o# v# e# r# f# i# t# t# i# n# g# )# .# 
# 
# ## ##  # D# .#  # D# e# c# i# s# i# o# n#  # T# r# e# e# :# 
# D# e# c# i# s# i# o# n#  # t# r# e# e#  # i# s#  # a#  # t# y# p# e#  # o# f#  # s# u# p# e# r# v# i# s# e# d#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # (# h# a# v# i# n# g#  # a#  # p# r# e# -# d# e# f# i# n# e# d#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# )#  # t# h# a# t#  # i# s#  # m# o# s# t# l# y#  # u# s# e# d#  # i# n#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# s# .#  # I# t#  # w# o# r# k# s#  # f# o# r#  # b# o# t# h#  # c# a# t# e# g# o# r# i# c# a# l#  # a# n# d#  # c# o# n# t# i# n# u# o# u# s#  # i# n# p# u# t#  # a# n# d#  # o# u# t# p# u# t#  # v# a# r# i# a# b# l# e# s# .#  # I# n#  # t# h# i# s#  # t# e# c# h# n# i# q# u# e# ,#  # w# e#  # s# p# l# i# t#  # t# h# e#  # p# o# p# u# l# a# t# i# o# n#  # o# r#  # s# a# m# p# l# e#  # i# n# t# o#  # t# w# o#  # o# r#  # m# o# r# e#  # h# o# m# o# g# e# n# e# o# u# s#  # s# e# t# s#  # (# o# r#  # s# u# b# -# p# o# p# u# l# a# t# i# o# n# s# )#  # b# a# s# e# d#  # o# n#  # m# o# s# t#  # s# i# g# n# i# f# i# c# a# n# t#  # s# p# l# i# t# t# e# r#  # /#  # d# i# f# f# e# r# e# n# t# i# a# t# o# r#  # i# n#  # i# n# p# u# t#  # v# a# r# i# a# b# l# e# s# .# 
# 
# *# *# D# e# c# i# s# i# o# n#  # T# r# e# e#  # H# y# p# e# r# p# a# r# a# m# e# t# e# r# s# *# *# 
# 
# *# R# O# O# T#  # N# o# d# e# *# :#  # I# t#  # r# e# p# r# e# s# e# n# t# s#  # e# n# t# i# r# e#  # p# o# p# u# l# a# t# i# o# n#  # o# r#  # s# a# m# p# l# e#  # a# n# d#  # t# h# i# s#  # f# u# r# t# h# e# r#  # g# e# t# s#  # d# i# v# i# d# e# d#  # i# n# t# o#  # t# w# o#  # o# r#  # m# o# r# e#  # h# o# m# o# g# e# n# e# o# u# s#  # s# e# t# s# .# 
# 
# *# S# P# L# I# T# T# I# N# G# *# :#  # I# t#  # i# s#  # a#  # p# r# o# c# e# s# s#  # o# f#  # d# i# v# i# d# i# n# g#  # a#  # n# o# d# e#  # i# n# t# o#  # t# w# o#  # o# r#  # m# o# r# e#  # s# u# b# -# n# o# d# e# s# .# 
# D# e# c# i# s# i# o# n#  # N# o# d# e# :#  # W# h# e# n#  # a#  # s# u# b# -# n# o# d# e#  # s# p# l# i# t# s#  # i# n# t# o#  # f# u# r# t# h# e# r#  # s# u# b# -# n# o# d# e# s# ,#  # t# h# e# n#  # i# t#  # i# s#  # c# a# l# l# e# d#  # d# e# c# i# s# i# o# n#  # n# o# d# e# .# 
# 
# *# L# e# a# f# /#  # T# e# r# m# i# n# a# l#  # N# o# d# e# *# :#  # N# o# d# e# s#  # d# o#  # n# o# t#  # s# p# l# i# t#  # i# s#  # c# a# l# l# e# d#  # L# e# a# f#  # o# r#  # T# e# r# m# i# n# a# l#  # n# o# d# e# .# 
# P# r# u# n# i# n# g# :#  # W# h# e# n#  # w# e#  # r# e# m# o# v# e#  # s# u# b# -# n# o# d# e# s#  # o# f#  # a#  # d# e# c# i# s# i# o# n#  # n# o# d# e# ,#  # t# h# i# s#  # p# r# o# c# e# s# s#  # i# s#  # c# a# l# l# e# d#  # p# r# u# n# i# n# g# .#  # Y# o# u#  # c# a# n#  # s# a# y#  # o# p# p# o# s# i# t# e#  # p# r# o# c# e# s# s#  # o# f#  # s# p# l# i# t# t# i# n# g# .# 
# 
# *# B# r# a# n# c# h#  # /#  # S# u# b# -# T# r# e# e# *# :#  # A#  # s# u# b#  # s# e# c# t# i# o# n#  # o# f#  # e# n# t# i# r# e#  # t# r# e# e#  # i# s#  # c# a# l# l# e# d#  # b# r# a# n# c# h#  # o# r#  # s# u# b# -# t# r# e# e# 
# P# a# r# e# n# t#  # a# n# d#  # C# h# i# l# d#  # N# o# d# e# :#  # A#  # n# o# d# e# ,#  # w# h# i# c# h#  # i# s#  # d# i# v# i# d# e# d#  # i# n# t# o#  # s# u# b# -# n# o# d# e# s#  # i# s#  # c# a# l# l# e# d#  # p# a# r# e# n# t#  # n# o# d# e#  # o# f#  # s# u# b# -# n# o# d# e# s#  # w# h# e# r# e#  # a# s#  # s# u# b# -# n# o# d# e# s#  # a# r# e#  # t# h# e#  # c# h# i# l# d#  # o# f#  # p# a# r# e# n# t#  # n# o# d# e# .# 
# 
# ## ##  # E# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t# :# 
# R# a# n# d# o# m#  # f# o# r# e# s# t# s#  # o# r#  # r# a# n# d# o# m#  # d# e# c# i# s# i# o# n#  # f# o# r# e# s# t# s#  # a# r# e#  # a# n#  # e# n# s# e# m# b# l# e#  # l# e# a# r# n# i# n# g#  # m# e# t# h# o# d#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ,#  # r# e# g# r# e# s# s# i# o# n#  # a# n# d#  # o# t# h# e# r#  # t# a# s# k# s#  # t# h# a# t#  # o# p# e# r# a# t# e#  # b# y#  # c# o# n# s# t# r# u# c# t# i# n# g#  # a#  # m# u# l# t# i# t# u# d# e#  # o# f#  # d# e# c# i# s# i# o# n#  # t# r# e# e# s#  # a# t#  # t# r# a# i# n# i# n# g#  # t# i# m# e#  # a# n# d#  # o# u# t# p# u# t# t# i# n# g#  # t# h# e#  # c# l# a# s# s#  # t# h# a# t#  # i# s#  # t# h# e#  # m# o# d# e#  # o# f#  # t# h# e#  # c# l# a# s# s# e# s#  # (# c# l# a# s# s# i# f# i# c# a# t# i# o# n# )#  # o# r#  # m# e# a# n#  # p# r# e# d# i# c# t# i# o# n#  # (# r# e# g# r# e# s# s# i# o# n# )#  # o# f#  # t# h# e#  # i# n# d# i# v# i# d# u# a# l#  # t# r# e# e# s# .#  # R# a# n# d# o# m#  # d# e# c# i# s# i# o# n#  # f# o# r# e# s# t# s#  # c# o# r# r# e# c# t#  # f# o# r#  # d# e# c# i# s# i# o# n#  # t# r# e# e# s# '#  # h# a# b# i# t#  # o# f#  # o# v# e# r# f# i# t# t# i# n# g#  # t# o#  # t# h# e# i# r#  # t# r# a# i# n# i# n# g#  # s# e# t# .# 
# 
# R# a# n# d# o# m#  # f# o# r# e# s# t#  # i# s#  # l# i# k# e#  # b# o# o# t# s# t# r# a# p# p# i# n# g#  # a# l# g# o# r# i# t# h# m#  # w# i# t# h#  # D# e# c# i# s# i# o# n#  # t# r# e# e#  # (# C# A# R# T# )#  # m# o# d# e# l# .#  # S# a# y# ,#  # w# e#  # h# a# v# e#  # 1# 0# 0# 0#  # o# b# s# e# r# v# a# t# i# o# n#  # i# n#  # t# h# e#  # c# o# m# p# l# e# t# e#  # p# o# p# u# l# a# t# i# o# n#  # w# i# t# h#  # 1# 0#  # v# a# r# i# a# b# l# e# s# .#  # R# a# n# d# o# m#  # f# o# r# e# s# t#  # t# r# i# e# s#  # t# o#  # b# u# i# l# d#  # m# u# l# t# i# p# l# e#  # C# A# R# T#  # m# o# d# e# l# s#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t#  # s# a# m# p# l# e# s#  # a# n# d#  # d# i# f# f# e# r# e# n# t#  # i# n# i# t# i# a# l#  # v# a# r# i# a# b# l# e# s# .#  # F# o# r#  # i# n# s# t# a# n# c# e# ,#  # i# t#  # w# i# l# l#  # t# a# k# e#  # a#  # r# a# n# d# o# m#  # s# a# m# p# l# e#  # o# f#  # 1# 0# 0#  # o# b# s# e# r# v# a# t# i# o# n#  # a# n# d#  # 5#  # r# a# n# d# o# m# l# y#  # c# h# o# s# e# n#  # i# n# i# t# i# a# l#  # v# a# r# i# a# b# l# e# s#  # t# o#  # b# u# i# l# d#  # a#  # C# A# R# T#  # m# o# d# e# l# .#  # I# t#  # w# i# l# l#  # r# e# p# e# a# t#  # t# h# e#  # p# r# o# c# e# s# s#  # (# s# a# y# )#  # 1# 0#  # t# i# m# e# s#  # a# n# d#  # t# h# e# n#  # m# a# k# e#  # a#  # f# i# n# a# l#  # p# r# e# d# i# c# t# i# o# n#  # o# n#  # e# a# c# h#  # o# b# s# e# r# v# a# t# i# o# n# .#  # F# i# n# a# l#  # p# r# e# d# i# c# t# i# o# n#  # i# s#  # a#  # f# u# n# c# t# i# o# n#  # o# f#  # e# a# c# h#  # p# r# e# d# i# c# t# i# o# n# .#  # T# h# i# s#  # f# i# n# a# l#  # p# r# e# d# i# c# t# i# o# n#  # c# a# n#  # s# i# m# p# l# y#  # b# e#  # t# h# e#  # m# e# a# n#  # o# f#  # e# a# c# h#  # p# r# e# d# i# c# t# i# o# n# .# 
# 
# F# o# r#  # a#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# e# r# ,#  # t# h# e# r# e#  # a# r# e#  # s# e# v# e# r# a# l#  # d# i# f# f# e# r# e# n# t#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# h# a# t#  # c# a# n#  # b# e#  # a# d# j# u# s# t# e# d# .# B# u# t#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # f# o# u# r#  # p# a# r# a# m# e# t# e# r# s#  # a# r# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t# 
# 
# *# *# R# a# n# d# o# m#  # F# o# r# e# s# t#  # H# y# p# e# r# p# a# r# a# m# e# t# e# r# s# :# -# *# *# 
# 
# *# n# _# e# s# t# i# m# a# t# o# r# s# *# :#  # T# h# e#  # n# _# e# s# t# i# m# a# t# o# r# s#  # p# a# r# a# m# e# t# e# r#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # t# r# e# e# s#  # i# n#  # t# h# e#  # f# o# r# e# s# t#  # o# f#  # t# h# e#  # m# o# d# e# l# .#  # T# h# e#  # d# e# f# a# u# l# t#  # v# a# l# u# e#  # f# o# r#  # t# h# i# s#  # p# a# r# a# m# e# t# e# r#  # i# s#  # 1# 0# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# a# t#  # 1# 0#  # d# i# f# f# e# r# e# n# t#  # d# e# c# i# s# i# o# n#  # t# r# e# e# s#  # w# i# l# l#  # b# e#  # c# o# n# s# t# r# u# c# t# e# d#  # i# n#  # t# h# e#  # r# a# n# d# o# m#  # f# o# r# e# s# t# .# 
# 
# *# m# a# x# _# d# e# p# t# h# *# :#  # T# h# e#  # m# a# x# _# d# e# p# t# h#  # p# a# r# a# m# e# t# e# r#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # m# a# x# i# m# u# m#  # d# e# p# t# h#  # o# f#  # e# a# c# h#  # t# r# e# e# .#  # T# h# e#  # d# e# f# a# u# l# t#  # v# a# l# u# e#  # f# o# r#  # m# a# x# _# d# e# p# t# h#  # i# s#  # N# o# n# e# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# a# t#  # e# a# c# h#  # t# r# e# e#  # w# i# l# l#  # e# x# p# a# n# d#  # u# n# t# i# l#  # e# v# e# r# y#  # l# e# a# f#  # i# s#  # p# u# r# e# .#  # A#  # p# u# r# e#  # l# e# a# f#  # i# s#  # o# n# e#  # w# h# e# r# e#  # a# l# l#  # o# f#  # t# h# e#  # d# a# t# a#  # o# n#  # t# h# e#  # l# e# a# f#  # c# o# m# e# s#  # f# r# o# m#  # t# h# e#  # s# a# m# e#  # c# l# a# s# s# .# 
# 
# *# m# i# n# _# s# a# m# p# l# e# s# _# s# p# l# i# t# *# :#  # T# h# e#  # m# i# n# _# s# a# m# p# l# e# s# _# s# p# l# i# t#  # p# a# r# a# m# e# t# e# r#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # m# i# n# i# m# u# m#  # n# u# m# b# e# r#  # o# f#  # s# a# m# p# l# e# s#  # r# e# q# u# i# r# e# d#  # t# o#  # s# p# l# i# t#  # a# n#  # i# n# t# e# r# n# a# l#  # l# e# a# f#  # n# o# d# e# .#  # T# h# e#  # d# e# f# a# u# l# t#  # v# a# l# u# e#  # f# o# r#  # t# h# i# s#  # p# a# r# a# m# e# t# e# r#  # i# s#  # 2# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# a# t#  # a# n#  # i# n# t# e# r# n# a# l#  # n# o# d# e#  # m# u# s# t#  # h# a# v# e#  # a# t#  # l# e# a# s# t#  # t# w# o#  # s# a# m# p# l# e# s#  # b# e# f# o# r# e#  # i# t#  # c# a# n#  # b# e#  # s# p# l# i# t#  # t# o#  # h# a# v# e#  # a#  # m# o# r# e#  # s# p# e# c# i# f# i# c#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .# 
# 
# *# m# i# n# _# s# a# m# p# l# e# s# _# l# e# a# f# *# :#  # T# h# e#  # m# i# n# _# s# a# m# p# l# e# s# _# l# e# a# f#  # p# a# r# a# m# e# t# e# r#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # m# i# n# i# m# u# m#  # n# u# m# b# e# r#  # o# f#  # s# a# m# p# l# e# s#  # r# e# q# u# i# r# e# d#  # t# o#  # b# e#  # a# t#  # a#  # l# e# a# f#  # n# o# d# e# .#  # T# h# e#  # d# e# f# a# u# l# t#  # v# a# l# u# e#  # f# o# r#  # t# h# i# s#  # p# a# r# a# m# e# t# e# r#  # i# s#  # 1# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# a# t#  # e# v# e# r# y#  # l# e# a# f#  # m# u# s# t#  # h# a# v# e#  # a# t#  # l# e# a# s# t#  # 1#  # s# a# m# p# l# e#  # t# h# a# t#  # i# t#  # c# l# a# s# s# i# f# i# e# s# .# 
# 
# ## ##  # F# .#  # X# G# B# O# O# S# T# :#  # 
# B# o# o# s# t# i# n# g#  # i# s#  # u# s# e# d#  # t# o#  # c# r# e# a# t# e#  # a#  # c# o# l# l# e# c# t# i# o# n#  # o# f#  # p# r# e# d# i# c# t# o# r# s# .#  # I# n#  # t# h# i# s#  # t# e# c# h# n# i# q# u# e# ,#  # l# e# a# r# n# e# r# s#  # a# r# e#  # l# e# a# r# n# e# d#  # s# e# q# u# e# n# t# i# a# l# l# y#  # w# i# t# h#  # e# a# r# l# y#  # l# e# a# r# n# e# r# s#  # f# i# t# t# i# n# g#  # s# i# m# p# l# e#  # m# o# d# e# l# s#  # t# o#  # t# h# e#  # d# a# t# a#  # a# n# d#  # t# h# e# n#  # a# n# a# l# y# s# i# n# g#  # d# a# t# a#  # f# o# r#  # e# r# r# o# r# s# .#  # C# o# n# s# e# c# u# t# i# v# e#  # t# r# e# e# s#  # (# r# a# n# d# o# m#  # s# a# m# p# l# e# )#  # a# r# e#  # f# i# t#  # a# n# d#  # a# t#  # e# v# e# r# y#  # s# t# e# p# ,#  # t# h# e#  # g# o# a# l#  # i# s#  # t# o#  # i# m# p# r# o# v# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # f# r# o# m#  # t# h# e#  # p# r# i# o# r#  # t# r# e# e# .#  # W# h# e# n#  # a# n#  # i# n# p# u# t#  # i# s#  # m# i# s# c# l# a# s# s# i# f# i# e# d#  # b# y#  # a#  # h# y# p# o# t# h# e# s# i# s# ,#  # i# t# s#  # w# e# i# g# h# t#  # i# s#  # i# n# c# r# e# a# s# e# d#  # s# o#  # t# h# a# t#  # n# e# x# t#  # h# y# p# o# t# h# e# s# i# s#  # i# s#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # c# l# a# s# s# i# f# y#  # i# t#  # c# o# r# r# e# c# t# l# y# .#  # T# h# i# s#  # p# r# o# c# e# s# s#  # c# o# n# v# e# r# t# s#  # w# e# a# k#  # l# e# a# r# n# e# r# s#  # i# n# t# o#  # b# e# t# t# e# r#  # p# e# r# f# o# r# m# i# n# g#  # m# o# d# e# l# .# 
# 
# T# h# e#  # X# G# B# o# o# s# t#  # l# i# b# r# a# r# y#  # i# m# p# l# e# m# e# n# t# s#  # t# h# e#  # g# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # d# e# c# i# s# i# o# n#  # t# r# e# e#  # a# l# g# o# r# i# t# h# m# .# 
# 
# G# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # i# s#  # a# n#  # a# p# p# r# o# a# c# h#  # w# h# e# r# e#  # n# e# w#  # m# o# d# e# l# s#  # a# r# e#  # c# r# e# a# t# e# d#  # t# h# a# t#  # p# r# e# d# i# c# t#  # t# h# e#  # r# e# s# i# d# u# a# l# s#  # o# r#  # e# r# r# o# r# s#  # o# f#  # p# r# i# o# r#  # m# o# d# e# l# s#  # a# n# d#  # t# h# e# n#  # a# d# d# e# d#  # t# o# g# e# t# h# e# r#  # t# o#  # m# a# k# e#  # t# h# e#  # f# i# n# a# l#  # p# r# e# d# i# c# t# i# o# n# .#  # I# t#  # i# s#  # c# a# l# l# e# d#  # g# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # b# e# c# a# u# s# e#  # i# t#  # u# s# e# s#  # a#  # g# r# a# d# i# e# n# t#  # d# e# s# c# e# n# t#  # a# l# g# o# r# i# t# h# m#  # t# o#  # m# i# n# i# m# i# z# e#  # t# h# e#  # l# o# s# s#  # w# h# e# n#  # a# d# d# i# n# g#  # n# e# w#  # m# o# d# e# l# s# .# 
# 
# T# h# i# s#  # a# p# p# r# o# a# c# h#  # s# u# p# p# o# r# t# s#  # b# o# t# h#  # r# e# g# r# e# s# s# i# o# n#  # a# n# d#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# l# i# n# g#  # p# r# o# b# l# e# m# s# .# 
# 
# *# *# X# G# B# o# o# s# t#  # H# y# p# e# r# p# a# r# a# m# e# t# e# r# s# :# -# *# *# 
# 
# *# m# a# x# _# d# e# p# t# h# *# :# T# h# e#  # m# a# x# i# m# u# m#  # d# e# p# t# h#  # o# f#  # a#  # t# r# e# e# 
# m# i# n# _# c# h# i# l# d# _# w# e# i# g# h# t# :# D# e# f# i# n# e# s#  # t# h# e#  # m# i# n# i# m# u# m#  # s# u# m#  # o# f#  # w# e# i# g# h# t# s#  # o# f#  # a# l# l#  # o# b# s# e# r# v# a# t# i# o# n# s#  # r# e# q# u# i# r# e# d#  # i# n#  # a#  # c# h# i# l# d# .# 
# 
# *# g# a# m# m# a# *# :# A#  # n# o# d# e#  # i# s#  # s# p# l# i# t#  # o# n# l# y#  # w# h# e# n#  # t# h# e#  # r# e# s# u# l# t# i# n# g#  # s# p# l# i# t#  # g# i# v# e# s#  # a#  # p# o# s# i# t# i# v# e#  # r# e# d# u# c# t# i# o# n#  # i# n#  # t# h# e#  # l# o# s# s#  # f# u# n# c# t# i# o# n# .#  # G# a# m# m# a#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # m# i# n# i# m# u# m#  # l# o# s# s#  # r# e# d# u# c# t# i# o# n#  # r# e# q# u# i# r# e# d#  # t# o#  # m# a# k# e#  # a#  # s# p# l# i# t# .# 
# 
# *# s# u# b# s# a# m# p# l# e# *# :#  #  #  # D# e# n# o# t# e# s#  # t# h# e#  # f# r# a# c# t# i# o# n#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s#  # t# o#  # b# e#  # r# a# n# d# o# m# l# y#  # c# h# o# s# e# n#  # s# a# m# p# l# e# s#  # f# o# r#  # e# a# c# h#  # t# r# e# e# .# 
# 
# *# c# o# l# s# a# m# p# l# e# _# b# y# t# r# e# e# *# :#  #  # D# e# n# o# t# e# s#  # t# h# e#  # f# r# a# c# t# i# o# n#  # o# f#  # c# o# l# u# m# n# s#  # t# o#  # b# e#  # r# a# n# d# o# m# l# y#  # c# h# o# s# e# n#  #  # s# a# m# p# l# e# s#  # f# o# r#  # e# a# c# h#  # t# r# e# e# .# 
# 
# *# r# e# g# _# a# l# p# h# a# *# :#  #  #  #  #  # R# e# g# u# l# a# r# i# z# a# t# i# o# n#  # p# a# r# a# m# e# t# e# r# 
# 
# *# r# e# g# _# l# a# m# d# a# *# :#  #  # R# e# g# u# l# a# r# i# z# a# t# i# o# n#  # p# a# r# a# m# e# t# e# r# 
# 
# *# l# e# a# r# n# i# n# g#  # r# a# t# e# *# :#  #  # P# a# r# a# m# e# t# e# r#  # i# n#  # G# r# a# d# i# e# n# t#  # D# e# s# c# e# n# t# 
# 
# ## ##  # G# .#  # C# A# T# B# O# O# S# T# :# 
# I# t#  # y# i# e# l# d# s#  # s# t# a# t# e# -# o# f# -# t# h# e# -# a# r# t#  # r# e# s# u# l# t# s#  # w# i# t# h# o# u# t#  # e# x# t# e# n# s# i# v# e#  # d# a# t# a#  # t# r# a# i# n# i# n# g#  # t# y# p# i# c# a# l# l# y#  # r# e# q# u# i# r# e# d#  # b# y#  # o# t# h# e# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# e# t# h# o# d# s# ,#  # a# n# d#  # p# r# o# v# i# d# e# s#  # p# o# w# e# r# f# u# l#  # o# u# t# -# o# f# -# t# h# e# -# b# o# x#  # s# u# p# p# o# r# t#  # f# o# r#  # t# h# e#  # m# o# r# e#  # d# e# s# c# r# i# p# t# i# v# e#  # d# a# t# a#  # f# o# r# m# a# t# s#  # t# h# a# t#  # a# c# c# o# m# p# a# n# y#  # m# a# n# y#  # b# u# s# i# n# e# s# s#  # p# r# o# b# l# e# m# s# .# 
# 
# “# C# a# t# B# o# o# s# t# ”#  # n# a# m# e#  # c# o# m# e# s#  # f# r# o# m#  # t# w# o#  # w# o# r# d# s#  # “# C# a# t# e# g# o# r# y# ”#  # a# n# d#  # “# B# o# o# s# t# i# n# g# ”# .# 
# 
# I# t#  # c# a# n#  # w# o# r# k#  # w# i# t# h#  # m# u# l# t# i# p# l# e#  # C# a# t# e# g# o# r# i# e# s#  # o# f#  # d# a# t# a# ,#  # s# u# c# h#  # a# s#  # a# u# d# i# o# ,#  # t# e# x# t# ,#  # i# m# a# g# e#  # i# n# c# l# u# d# i# n# g#  # h# i# s# t# o# r# i# c# a# l#  # d# a# t# a# .# 
# 
# “# B# o# o# s# t# ”#  # c# o# m# e# s#  # f# r# o# m#  # g# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # a# s#  # t# h# i# s#  # l# i# b# r# a# r# y#  # i# s#  # b# a# s# e# d#  # o# n#  # g# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # l# i# b# r# a# r# y# .#  # G# r# a# d# i# e# n# t#  # b# o# o# s# t# i# n# g#  # i# s#  # a#  # p# o# w# e# r# f# u# l#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # t# h# a# t#  # i# s#  # w# i# d# e# l# y#  # a# p# p# l# i# e# d#  # t# o#  # m# u# l# t# i# p# l# e#  # t# y# p# e# s#  # o# f#  # b# u# s# i# n# e# s# s#  # c# h# a# l# l# e# n# g# e# s#  # l# i# k# e#  # f# r# a# u# d#  # d# e# t# e# c# t# i# o# n# ,#  # r# e# c# o# m# m# e# n# d# a# t# i# o# n#  # i# t# e# m# s# ,#  # f# o# r# e# c# a# s# t# i# n# g#  # a# n# d#  # i# t#  # p# e# r# f# o# r# m# s#  # w# e# l# l#  # a# l# s# o# .#  # I# t#  # c# a# n#  # a# l# s# o#  # r# e# t# u# r# n#  # v# e# r# y#  # g# o# o# d#  # r# e# s# u# l# t#  # w# i# t# h#  # r# e# l# a# t# i# v# e# l# y#  # l# e# s# s#  # d# a# t# a# ,#  # u# n# l# i# k# e#  # D# L#  # m# o# d# e# l# s#  # t# h# a# t#  # n# e# e# d#  # t# o#  # l# e# a# r# n#  # f# r# o# m#  # a#  # m# a# s# s# i# v# e#  # a# m# o# u# n# t#  # o# f#  # d# a# t# a# .# 
# 
# *# *# A# d# v# a# n# t# a# g# e# s#  # o# f#  # C# a# t# B# o# o# s# t#  # L# i# b# r# a# r# y# *# *# 
# 
# *# P# e# r# f# o# r# m# a# n# c# e# *# :#  # C# a# t# B# o# o# s# t#  # p# r# o# v# i# d# e# s#  # s# t# a# t# e#  # o# f#  # t# h# e#  # a# r# t#  # r# e# s# u# l# t# s#  # a# n# d#  # i# t#  # i# s#  # c# o# m# p# e# t# i# t# i# v# e#  # w# i# t# h#  # a# n# y#  # l# e# a# d# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # o# n#  # t# h# e#  # p# e# r# f# o# r# m# a# n# c# e#  # f# r# o# n# t# .# 
# 
# *# H# a# n# d# l# i# n# g#  # C# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # a# u# t# o# m# a# t# i# c# a# l# l# y# *# :#  # W# e#  # c# a# n#  # u# s# e#  # C# a# t# B# o# o# s# t#  # w# i# t# h# o# u# t#  # a# n# y#  # e# x# p# l# i# c# i# t#  # p# r# e# -# p# r# o# c# e# s# s# i# n# g#  # t# o#  # c# o# n# v# e# r# t#  # c# a# t# e# g# o# r# i# e# s#  # i# n# t# o#  # n# u# m# b# e# r# s# .#  # C# a# t# B# o# o# s# t#  # c# o# n# v# e# r# t# s#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# l# u# e# s#  # i# n# t# o#  # n# u# m# b# e# r# s#  # u# s# i# n# g#  # v# a# r# i# o# u# s#  # s# t# a# t# i# s# t# i# c# s#  # o# n#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # a# n# d#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # c# a# t# e# g# o# r# i# c# a# l#  # a# n# d#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s# .#  # Y# o# u#  # c# a# n#  # r# e# a# d#  # m# o# r# e#  # a# b# o# u# t#  # i# t#  # h# e# r# e# .# 
# 
# *# R# o# b# u# s# t# *# :#  # I# t#  # r# e# d# u# c# e# s#  # t# h# e#  # n# e# e# d#  # f# o# r#  # e# x# t# e# n# s# i# v# e#  # h# y# p# e# r# -# p# a# r# a# m# e# t# e# r#  # t# u# n# i# n# g#  # a# n# d#  # l# o# w# e# r#  # t# h# e#  # c# h# a# n# c# e# s#  # o# f#  # o# v# e# r# f# i# t# t# i# n# g#  # a# l# s# o#  # w# h# i# c# h#  # l# e# a# d# s#  # t# o#  # m# o# r# e#  # g# e# n# e# r# a# l# i# z# e# d#  # m# o# d# e# l# s# .#  # A# l# t# h# o# u# g# h# ,#  # C# a# t# B# o# o# s# t#  # h# a# s#  # m# u# l# t# i# p# l# e#  # p# a# r# a# m# e# t# e# r# s#  # t# o#  # t# u# n# e#  # a# n# d#  # i# t#  # c# o# n# t# a# i# n# s#  # p# a# r# a# m# e# t# e# r# s#  # l# i# k# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # t# r# e# e# s# ,#  # l# e# a# r# n# i# n# g#  # r# a# t# e# ,#  # r# e# g# u# l# a# r# i# z# a# t# i# o# n# ,#  # t# r# e# e#  # d# e# p# t# h# ,#  # f# o# l# d#  # s# i# z# e# ,#  # b# a# g# g# i# n# g#  # t# e# m# p# e# r# a# t# u# r# e#  # a# n# d#  # o# t# h# e# r# s# .#  # Y# o# u#  # c# a# n#  # r# e# a# d#  # a# b# o# u# t#  # a# l# l#  # t# h# e# s# e#  # p# a# r# a# m# e# t# e# r# s#  # h# e# r# e# .# 
# 
# *# E# a# s# y# -# t# o# -# u# s# e# *# :#  # Y# o# u#  # c# a# n#  # u# s# e#  # C# a# t# B# o# o# s# t#  # f# r# o# m#  # t# h# e#  # c# o# m# m# a# n# d#  # l# i# n# e# ,#  # u# s# i# n# g#  # a# n#  # u# s# e# r# -# f# r# i# e# n# d# l# y#  # A# P# I#  # f# o# r#  # b# o# t# h#  # P# y# t# h# o# n#  # a# n# d#  # R# .# 
# 
# 
# ##  # V#  # T# U# N# I# N# G#  # H# Y# P# E# R# P# A# R# A# M# E# T# E# R# S# 
# 
# 
# ## ##  # A# .#  # G# r# i# d#  # S# e# a# r# c# h# :# -#  # 
#  # G# r# i# d#  # S# e# a# r# c# h#  # i# s#  # p# a# r# t# i# c# u# l# a# r# l# y#  # u# s# e# d#  # f# o# r#  # t# u# n# i# n# g#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s# .#  # N# o# w#  # b# e# f# o# r# e#  # g# o# i# n# g#  # i# n# t# o#  # d# e# e# p#  # l# e# t# s#  # k# n# o# w#  # w# h# a# t#  # i# s#  # a#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# .# 
# 
# A#  # m# o# d# e# l#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r#  # i# s#  # a#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c#  # o# f#  # a#  # m# o# d# e# l#  # t# h# a# t#  # i# s#  # e# x# t# e# r# n# a# l#  # t# o#  # t# h# e#  # m# o# d# e# l#  # a# n# d#  # w# h# o# s# e#  # v# a# l# u# e#  # c# a# n# n# o# t#  # b# e#  # e# s# t# i# m# a# t# e# d#  # f# r# o# m#  # d# a# t# a# .#  # T# h# e#  # v# a# l# u# e#  # o# f#  # t# h# e#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r#  # h# a# s#  # t# o#  # b# e#  # s# e# t#  # b# e# f# o# r# e#  # t# h# e#  # l# e# a# r# n# i# n# g#  # p# r# o# c# e# s# s#  # b# e# g# i# n# s# .#  # F# o# r#  # e# x# a# m# p# l# e#  # k#  # i# n#  # k# -# N# e# a# r# e# s# t#  # N# e# i# g# h# b# o# u# r# s# ,#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # h# i# d# d# e# n#  # l# a# y# e# r# s#  # i# n#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k# s# .# 
# 
# I# n#  # c# o# n# t# r# a# s# t# ,#  # a#  # p# a# r# a# m# e# t# e# r#  # i# s#  # a# n#  # i# n# t# e# r# n# a# l#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c#  # o# f#  # t# h# e#  # m# o# d# e# l#  # a# n# d#  # i# t# s#  # v# a# l# u# e#  # c# a# n#  # b# e#  # e# s# t# i# m# a# t# e# d#  # f# r# o# m#  # d# a# t# a# .#  # E# x# a# m# p# l# e# ,#  # b# e# t# a#  # c# o# e# f# f# i# c# i# e# n# t# s#  # o# f#  # l# i# n# e# a# r# /# l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # o# r#  # s# u# p# p# o# r# t#  # v# e# c# t# o# r# s#  # i# n#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e# s# .# 
# 
# G# r# i# d# -# s# e# a# r# c# h#  # i# s#  # u# s# e# d#  # t# o#  # f# i# n# d#  # t# h# e#  # o# p# t# i# m# a# l#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # o# f#  # a#  # m# o# d# e# l#  # w# h# i# c# h#  # r# e# s# u# l# t# s#  # i# n#  # t# h# e#  # m# o# s# t#  # ‘# a# c# c# u# r# a# t# e# ’#  # p# r# e# d# i# c# t# i# o# n# s# .# 
# 
# T# r# y# i# n# g#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t#  # v# a# l# u# e# s#  # o# f#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # a# n# d#  # c# h# e# c# k# i# n# g#  # t# h# e#  # m# e# t# r# i# c# s#  # i# s#  # a#  # l# o# n# g#  # p# r# o# c# e# s# s# .#  # G# r# i# d#  # S# e# a# r# c# h#  # d# o# e# s#  # t# h# e#  # w# o# r# k#  # f# o# r#  # u# s#  # b# y#  # i# t# e# r# a# t# i# n# g#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t#  # v# a# l# u# e# s#  # t# h# a# t#  # w# e#  # s# p# e# c# i# f# i# c# a# l# l# y#  # g# i# v# e#  # a# n# d#  # r# e# s# u# l# t# s#  # t# h# e#  # o# p# t# i# m# a# l#  # o# n# e#  # f# r# o# m#  # t# h# e#  # g# i# v# e# n# .# 
# 
# *# e# s# t# i# m# a# t# o# r# *# :#  # e# s# t# i# m# a# t# o# r#  # o# b# j# e# c# t#  # y# o# u#  # c# r# e# a# t# e# d# 
# 
# *# p# a# r# a# m# s# _# g# r# i# d# *# :#  # t# h# e#  # d# i# c# t# i# o# n# a# r# y#  # o# b# j# e# c# t#  # t# h# a# t#  # h# o# l# d# s#  # t# h# e#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # y# o# u#  # w# a# n# t#  # t# o#  # t# r# y# 
# 
# *# s# c# o# r# i# n# g# *# :#  # e# v# a# l# u# a# t# i# o# n#  # m# e# t# r# i# c#  # t# h# a# t#  # y# o# u#  # w# a# n# t#  # t# o#  # u# s# e# ,#  # y# o# u#  # c# a# n#  # s# i# m# p# l# y#  # p# a# s# s#  # a#  # v# a# l# i# d#  # s# t# r# i# n# g# /#  # o# b# j# e# c# t#  # o# f#  # e# v# a# l# u# a# t# i# o# n#  # m# e# t# r# i# c# 
# 
# *# c# v# *# :#  # n# u# m# b# e# r#  # o# f#  # c# r# o# s# s# -# v# a# l# i# d# a# t# i# o# n#  # y# o# u#  # h# a# v# e#  # t# o#  # t# r# y#  # f# o# r#  # e# a# c# h#  # s# e# l# e# c# t# e# d#  # s# e# t#  # o# f#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s# 
# 
# *# v# e# r# b# o# s# e# *# :#  # y# o# u#  # c# a# n#  # s# e# t#  # i# t#  # t# o#  # 1#  # t# o#  # g# e# t#  # t# h# e#  # d# e# t# a# i# l# e# d#  # p# r# i# n# t#  # o# u# t#  # w# h# i# l# e#  # y# o# u#  # f# i# t#  # t# h# e#  # d# a# t# a#  # t# o#  # G# r# i# d# S# e# a# r# c# h# C# V# 
# 
# *# n# _# j# o# b# s# *# :#  # n# u# m# b# e# r#  # o# f#  # p# r# o# c# e# s# s# e# s#  # y# o# u#  # w# i# s# h#  # t# o#  # r# u# n#  # i# n#  # p# a# r# a# l# l# e# l#  # f# o# r#  # t# h# i# s#  # t# a# s# k#  # i# f#  # i# t#  # -# 1#  # i# t#  # w# i# l# l#  # u# s# e#  # a# l# l#  # a# v# a# i# l# a# b# l# e#  # p# r# o# c# e# s# s# o# r# s# .# 
# 
# ## ##  # B# .#  # R# a# n# d# o# m#  # S# e# a# r# c# h# :# 
# R# a# n# d# o# m#  # s# e# a# r# c# h#  # i# s#  # a#  # t# e# c# h# n# i# q# u# e#  # w# h# e# r# e#  # r# a# n# d# o# m#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # t# h# e#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # a# r# e#  # u# s# e# d#  # t# o#  # f# i# n# d#  # t# h# e#  # b# e# s# t#  # s# o# l# u# t# i# o# n#  # f# o# r#  # t# h# e#  # b# u# i# l# t#  # m# o# d# e# l# .#  # I# t#  # t# r# i# e# s#  # r# a# n# d# o# m#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # a#  # r# a# n# g# e#  # o# f#  # v# a# l# u# e# s# .#  # T# o#  # o# p# t# i# m# i# s# e#  # w# i# t# h#  # r# a# n# d# o# m#  # s# e# a# r# c# h# ,#  # t# h# e#  # f# u# n# c# t# i# o# n#  # i# s#  # e# v# a# l# u# a# t# e# d#  # a# t#  # s# o# m# e#  # n# u# m# b# e# r#  # o# f#  # r# a# n# d# o# m#  # c# o# n# f# i# g# u# r# a# t# i# o# n# s#  # i# n#  # t# h# e#  # p# a# r# a# m# e# t# e# r#  # s# p# a# c# e# .# 
# 
# T# h# e#  # c# h# a# n# c# e# s#  # o# f#  # f# i# n# d# i# n# g#  # t# h# e#  # o# p# t# i# m# a# l#  # p# a# r# a# m# e# t# e# r#  # a# r# e#  # c# o# m# p# a# r# a# t# i# v# e# l# y#  # h# i# g# h# e# r#  # i# n#  # r# a# n# d# o# m#  # s# e# a# r# c# h#  # b# e# c# a# u# s# e#  # o# f#  # t# h# e#  # r# a# n# d# o# m#  # s# e# a# r# c# h#  # p# a# t# t# e# r# n#  # w# h# e# r# e#  # t# h# e#  # m# o# d# e# l#  # m# i# g# h# t#  # e# n# d#  # u# p#  # b# e# i# n# g#  # t# r# a# i# n# e# d#  # o# n#  # t# h# e#  # o# p# t# i# m# i# s# e# d#  # p# a# r# a# m# e# t# e# r# s#  # w# i# t# h# o# u# t#  # a# n# y#  # a# l# i# a# s# i# n# g# .#  # R# a# n# d# o# m#  # s# e# a# r# c# h#  # w# o# r# k# s#  # b# e# s# t#  # f# o# r#  # l# o# w# e# r#  # d# i# m# e# n# s# i# o# n# a# l#  # d# a# t# a#  # s# i# n# c# e#  # t# h# e#  # t# i# m# e#  # t# a# k# e# n#  # t# o#  # f# i# n# d#  # t# h# e#  # r# i# g# h# t#  # s# e# t#  # i# s#  # l# e# s# s#  # w# i# t# h#  # l# e# s# s#  # n# u# m# b# e# r#  # o# f#  # i# t# e# r# a# t# i# o# n# s# .#  # R# a# n# d# o# m#  # s# e# a# r# c# h#  # i# s#  # t# h# e#  # b# e# s# t#  # p# a# r# a# m# e# t# e# r#  # s# e# a# r# c# h#  # t# e# c# h# n# i# q# u# e#  # w# h# e# n#  # t# h# e# r# e#  # a# r# e#  # l# e# s# s#  # n# u# m# b# e# r#  # o# f#  # d# i# m# e# n# s# i# o# n# s# .#  # I# n#  # t# h# e#  # p# a# p# e# r#  # R# a# n# d# o# m#  # S# e# a# r# c# h#  # f# o# r#  # H# y# p# e# r# -# P# a# r# a# m# e# t# e# r#  # O# p# t# i# m# i# z# a# t# i# o# n#  # b# y#  # B# e# r# g# s# t# r# a#  # a# n# d#  # B# e# n# g# i# o# ,#  # t# h# e#  # a# u# t# h# o# r# s#  # s# h# o# w#  # e# m# p# i# r# i# c# a# l# l# y#  # a# n# d#  # t# h# e# o# r# e# t# i# c# a# l# l# y#  # t# h# a# t#  # r# a# n# d# o# m#  # s# e# a# r# c# h#  # i# s#  # m# o# r# e#  # e# f# f# i# c# i# e# n# t#  # f# o# r#  # p# a# r# a# m# e# t# e# r#  # o# p# t# i# m# i# z# a# t# i# o# n#  # t# h# a# n#  # g# r# i# d#  # s# e# a# r# c# h# .# 
# 
# ## ##  # C# .#  # B# a# y# e# s# i# a# n#  # O# p# t# i# m# i# z# a# t# i# o# n# 
# B# a# y# e# s# i# a# n#  # a# p# p# r# o# a# c# h# e# s# ,#  # i# n#  # c# o# n# t# r# a# s# t#  # t# o#  # r# a# n# d# o# m#  # o# r#  # g# r# i# d#  # s# e# a# r# c# h# ,#  # k# e# e# p#  # t# r# a# c# k#  # o# f#  # p# a# s# t#  # e# v# a# l# u# a# t# i# o# n#  # r# e# s# u# l# t# s#  # w# h# i# c# h#  # t# h# e# y#  # u# s# e#  # t# o#  # f# o# r# m#  # a#  # p# r# o# b# a# b# i# l# i# s# t# i# c#  # m# o# d# e# l#  # m# a# p# p# i# n# g#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# o#  # a#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # a#  # s# c# o# r# e#  # o# n#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# .# 
# 
# I# n#  # t# h# e#  # l# i# t# e# r# a# t# u# r# e# ,#  # t# h# i# s#  # m# o# d# e# l#  # i# s#  # c# a# l# l# e# d#  # a#  # “# s# u# r# r# o# g# a# t# e# ”#  # f# o# r#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n#  # a# n# d#  # i# s#  # r# e# p# r# e# s# e# n# t# e# d#  # a# s#  # p# (# y#  # |#  # x# )# .#  # T# h# e#  # s# u# r# r# o# g# a# t# e#  # i# s#  # m# u# c# h#  # e# a# s# i# e# r#  # t# o#  # o# p# t# i# m# i# z# e#  # t# h# a# n#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n#  # a# n# d#  # B# a# y# e# s# i# a# n#  # m# e# t# h# o# d# s#  # w# o# r# k#  # b# y#  # f# i# n# d# i# n# g#  # t# h# e#  # n# e# x# t#  # s# e# t#  # o# f#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# o#  # e# v# a# l# u# a# t# e#  # o# n#  # t# h# e#  # a# c# t# u# a# l#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n#  # b# y#  # s# e# l# e# c# t# i# n# g#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# h# a# t#  # p# e# r# f# o# r# m#  # b# e# s# t#  # o# n#  # t# h# e#  # s# u# r# r# o# g# a# t# e#  # f# u# n# c# t# i# o# n# .#  # I# n#  # o# t# h# e# r#  # w# o# r# d# s# :# 
# 
# 1# .# B# u# i# l# d#  # a#  # s# u# r# r# o# g# a# t# e#  # p# r# o# b# a# b# i# l# i# t# y#  # m# o# d# e# l#  # o# f#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# 
# 
# 2# .# F# i# n# d#  # t# h# e#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# h# a# t#  # p# e# r# f# o# r# m#  # b# e# s# t#  # o# n#  # t# h# e#  # s# u# r# r# o# g# a# t# e# 
# 
# 3# .# A# p# p# l# y#  # t# h# e# s# e#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# o#  # t# h# e#  # t# r# u# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# 
# 
# 4# .# U# p# d# a# t# e#  # t# h# e#  # s# u# r# r# o# g# a# t# e#  # m# o# d# e# l#  # i# n# c# o# r# p# o# r# a# t# i# n# g#  # t# h# e#  # n# e# w#  # r# e# s# u# l# t# s# 
# 
# 5# .# R# e# p# e# a# t#  # s# t# e# p# s#  # 2# –# 4#  # u# n# t# i# l#  # m# a# x#  # i# t# e# r# a# t# i# o# n# s#  # o# r#  # t# i# m# e#  # i# s#  # r# e# a# c# h# e# d# 
# 
# T# h# e#  # a# i# m#  # o# f#  # B# a# y# e# s# i# a# n#  # r# e# a# s# o# n# i# n# g#  # i# s#  # t# o#  # b# e# c# o# m# e#  # “# l# e# s# s#  # w# r# o# n# g# ”#  # w# i# t# h#  # m# o# r# e#  # d# a# t# a#  # w# h# i# c# h#  # t# h# e# s# e#  # a# p# p# r# o# a# c# h# e# s#  # d# o#  # b# y#  # c# o# n# t# i# n# u# a# l# l# y#  # u# p# d# a# t# i# n# g#  # t# h# e#  # s# u# r# r# o# g# a# t# e#  # p# r# o# b# a# b# i# l# i# t# y#  # m# o# d# e# l#  # a# f# t# e# r#  # e# a# c# h#  # e# v# a# l# u# a# t# i# o# n#  # o# f#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# .# 
# 
# A# t#  # a#  # h# i# g# h# -# l# e# v# e# l# ,#  # B# a# y# e# s# i# a# n#  # o# p# t# i# m# i# z# a# t# i# o# n#  # m# e# t# h# o# d# s#  # a# r# e#  # e# f# f# i# c# i# e# n# t#  # b# e# c# a# u# s# e#  # t# h# e# y#  # c# h# o# o# s# e#  # t# h# e#  # n# e# x# t#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # i# n#  # a# n#  # i# n# f# o# r# m# e# d#  # m# a# n# n# e# r# .#  # T# h# e#  # b# a# s# i# c#  # i# d# e# a#  # i# s# :#  # s# p# e# n# d#  # a#  # l# i# t# t# l# e#  # m# o# r# e#  # t# i# m# e#  # s# e# l# e# c# t# i# n# g#  # t# h# e#  # n# e# x# t#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # i# n#  # o# r# d# e# r#  # t# o#  # m# a# k# e#  # f# e# w# e# r#  # c# a# l# l# s#  # t# o#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# .#  # I# n#  # p# r# a# c# t# i# c# e# ,#  # t# h# e#  # t# i# m# e#  # s# p# e# n# t#  # s# e# l# e# c# t# i# n# g#  # t# h# e#  # n# e# x# t#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # i# s#  # i# n# c# o# n# s# e# q# u# e# n# t# i# a# l#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e#  # t# i# m# e#  # s# p# e# n# t#  # i# n#  # t# h# e#  # o# b# j# e# c# t# i# v# e#  # f# u# n# c# t# i# o# n# .#  # B# y#  # e# v# a# l# u# a# t# i# n# g#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r# s#  # t# h# a# t#  # a# p# p# e# a# r#  # m# o# r# e#  # p# r# o# m# i# s# i# n# g#  # f# r# o# m#  # p# a# s# t#  # r# e# s# u# l# t# s# ,#  # B# a# y# e# s# i# a# n#  # m# e# t# h# o# d# s#  # c# a# n#  # f# i# n# d#  # b# e# t# t# e# r#  # m# o# d# e# l#  # s# e# t# t# i# n# g# s#  # t# h# a# n#  # r# a# n# d# o# m#  # s# e# a# r# c# h#  # i# n#  # f# e# w# e# r#  # i# t# e# r# a# t# i# o# n# s# .# 
# 
# ##  # V# I#  # C# U# R# S# E#  # O# F#  # D# I# M# E# N# S# I# O# N# A# L# I# T# Y# 
# 
# ## ##  # P# r# i# n# c# i# p# a# l#  # C# o# m# p# o# n# e# n# t#  # A# n# a# l# y# s# i# s# 
# 
# W# h# e# n#  # w# e#  # h# a# v# e#  # t# o# o#  # m# a# n# y#  # f# e# a# t# u# r# e# s#  # t# o#  # t# r# a# i# n#  # i# n#  # t# h# e#  # m# o# d# e# l#  # t# h# e# n#  # t# h# e# r# e#  # m# i# g# h# t#  # b# e#  # a#  # c# h# a# n# c# e#  # o# f#  # o# v# e# r#  # f# i# t# t# i# n# g# ,#  # s# o#  # t# w# o#  # o# p# t# i# o# n# s# 
# 
# *# *# F# e# a# t# u# r# e#  # E# l# i# m# i# n# a# t# i# o# n# *# *# :#  # W# e#  # s# h# a# l# l#  # d# r# o# p#  # f# e# w#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# r# a# i# n#  # t# h# e#  # m# o# d# e# l#  # w# i# t# h#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # c# o# n# t# r# i# b# u# t# e#  # m# o# s# t#  # t# o# w# a# r# d# s#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .#  # T# h# i# s#  # c# a# n#  # b# e#  # d# o# n# e#  # b# y#  # R# F# E# (# R# e# c# u# r# s# i# v# e#  # F# e# a# t# u# r# e#  # E# l# i# m# i# n# a# t# i# o# n# )#  # o# r#  # R# F# E# C# V# (# R# F# E#  # w# i# t# h#  # C# r# o# s# s#  # V# a# l# i# d# a# t# i# o# n# )# .# T# h# e# y#  # c# a# n#  # g# i# v# e#  # h# o# w#  # m# u# c# h#  # e# a# c# h#  # f# e# a# t# u# r# e#  # i# s#  # i# m# p# o# r# t# a# n# t#  # ,#  # l# i# k# e#  # a#  # l# i# s# t# ,#  # s# o#  # w# e#  # c# a# n#  # s# e# l# e# c# t#  # t# h# e#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s# .#  # B# u# t#  # t# h# e#  # o# n# l# y#  # p# r# o# b# l# e# m#  # i# s#  # w# e#  # l# o# s# e#  # t# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # w# h# a# t# e# v# e# r#  # t# h# e#  # d# r# o# p# p# e# d#  # f# e# a# t# u# r# e# s#  # w# e# r# e#  # c# o# n# t# r# i# b# u# t# i# n# g#  # t# o#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .#  #  # S# o# 
# 
# *# *# F# e# a# t# u# r# e#  # E# x# t# r# a# c# t# i# o# n# *# *# :#  #  # P# C# A#  # i# s#  # a#  # f# e# a# t# u# r# e#  # e# x# t# r# a# c# t# i# o# n#  # m# e# t# h# o# d# .#  # I# n#  # f# e# a# t# u# r# e#  # e# x# t# r# a# c# t# i# o# n# ,#  # w# e#  # c# r# e# a# t# e#  # “# n# e# w# ”#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# ,#  # w# h# e# r# e#  # e# a# c# h#  # “# n# e# w# ”#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e#  # i# s#  # a#  # c# o# m# b# i# n# a# t# i# o# n#  # o# f#  # e# a# c# h#  # o# f#  # t# h# e#  # a# l# l#  # “# o# l# d# ”#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# .#  # H# o# w# e# v# e# r# ,#  # w# e#  # c# r# e# a# t# e#  # t# h# e# s# e#  # n# e# w#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # i# n#  # a#  # s# p# e# c# i# f# i# c#  # w# a# y#  # a# n# d#  # o# r# d# e# r#  # t# h# e# s# e#  # n# e# w#  # v# a# r# i# a# b# l# e# s#  # b# y#  # h# o# w#  # w# e# l# l#  # t# h# e# y#  # p# r# e# d# i# c# t#  # o# u# r#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# .# 
# 
# W# e#  # k# e# e# p#  # a# s#  # m# a# n# y#  # o# f#  # t# h# e#  # n# e# w#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# s#  # w# e#  # w# a# n# t# ,#  # b# u# t#  # w# e#  # d# r# o# p#  # t# h# e#  # “# l# e# a# s# t#  # i# m# p# o# r# t# a# n# t#  # o# n# e# s# .# ”#  # B# e# c# a# u# s# e#  # w# e#  # o# r# d# e# r# e# d#  # t# h# e#  # n# e# w#  # v# a# r# i# a# b# l# e# s#  # b# y#  # h# o# w#  # w# e# l# l#  # t# h# e# y#  # p# r# e# d# i# c# t#  # o# u# r#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# ,#  # w# e#  # k# n# o# w#  # w# h# i# c# h#  # v# a# r# i# a# b# l# e#  # i# s#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # a# n# d#  # l# e# a# s# t#  # i# m# p# o# r# t# a# n# t# .#  # B# e# c# a# u# s# e#  # t# h# e# s# e#  # n# e# w#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # o# u# r#  # o# l# d#  # o# n# e# s# ,#  # w# e# ’# r# e#  # s# t# i# l# l#  # k# e# e# p# i# n# g#  # t# h# e#  # m# o# s# t#  # v# a# l# u# a# b# l# e#  # p# a# r# t# s#  # o# f#  # o# u# r#  # o# l# d#  # v# a# r# i# a# b# l# e# s# ,#  # e# v# e# n#  # w# h# e# n#  # w# e#  # d# r# o# p#  # o# n# e#  # o# r#  # m# o# r# e#  # o# f#  # t# h# e# s# e#  # “# n# e# w# ”#  # v# a# r# i# a# b# l# e# s# 
# 
# *# *# P# r# o# s# :# *# *# 
# W# h# e# n#  # w# e#  # w# a# n# t#  # t# o#  # r# e# d# u# c# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # f# e# a# t# u# r# e# s#  # b# u# t#  # d# o# n# ’# t#  # k# n# o# w#  # w# h# a# t#  # t# o#  # d# r# o# p# ,#  # P# C# A#  # c# a# n#  # h# e# l# p#  # u# s# 
# N# e# w#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # i# n# d# e# p# e# n# d# e# n# t#  # o# f# f#  # e# a# c# h#  # o# t# h# e# r# 
# 
# *# *# C# o# n# s# :# *# *# 
# N# e# w#  # f# e# a# t# u# r# e# s#  # a# r# e#  # l# e# s# s#  # i# n# t# e# r# p# r# e# t# a# b# l# e# 
# 
# ##  # V# I# I#  #  #  # E# V# A# L# U# A# T# I# O# N#  # M# E# T# R# I# C# S# 
# 
# ## ##  # A# .#  # R# O# C# 
# M# a# n# y#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l# s#  # w# e# r# e#  # p# e# r# f# o# r# m# e# d#  # o# n#  # t# h# i# s#  # d# a# t# a# s# e# t#  # t# h# a# t#  # i# n# c# l# u# d# e# s#  # L# o# g# i# s# t# i# c#  # a# n# d#  # D# e# c# i# s# i# o# n#  # T# r# e# e#  # a# l# g# o# r# i# t# h# m# s# .#  # T# h# e#  # m# e# t# r# i# c# s#  # w# h# i# c# h#  # w# e# r# e#  # u# s# e# d#  # t# o#  # d# e# t# e# r# m# i# n# e#  # t# h# e#  # e# f# f# i# c# i# e# n# c# y#  # i# n# c# l# u# d# e# s#  # s# e# n# s# i# t# i# v# i# t# y#  # o# r#  # R# e# c# a# l# l# ,#  # s# p# e# c# i# f# i# c# i# t# y#  # a# n# d#  # a# c# c# u# r# a# c# y#  # a# n# d#  # a# l# s# o#  # u# s# i# n# g#  # R# e# c# e# i# v# e# r#  # o# p# e# r# a# t# i# n# g#  # c# h# a# r# e# c# t# e# r# i# s# t# i# c# s#  # c# u# r# v# e# .#  # T# h# e#  # a# r# e# a#  # u# n# d# e# r#  # c# u# r# v# e#  # v# a# l# u# e#  # r# e# v# e# a# l# s#  # t# h# a# t#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # p# e# r# f# o# r# m# e# d#  # b# e# t# t# e# r#  # t# h# a# n#  # D# e# c# i# s# i# o# n#  # T# r# e# e# .#  # 
# 
# 
# ## ##  # B# .#  # C# o# n# f# u# s# i# o# n#  # M# a# t# r# i# x# 
# P# e# r# f# o# r# m# a# n# c# e#  # m# e# a# s# u# r# e# m# e# n# t#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # w# h# e# r# e#  # o# u# t# p# u# t#  # c# a# n#  # b# e#  # t# w# o#  # o# r#  # m# o# r# e#  # c# l# a# s# s# e# s# .#  # I# t#  # i# s#  # a#  # t# a# b# l# e#  # w# i# t# h#  # 4#  # d# i# f# f# e# r# e# n# t#  # c# o# m# b# i# n# a# t# i# o# n# s#  # o# f#  # p# r# e# d# i# c# t# e# d#  # a# n# d#  # a# c# t# u# a# l#  # v# a# l# u# e# s# .# 
# 
# 
# I# t#  # i# s#  # e# x# t# r# e# m# e# l# y#  # u# s# e# f# u# l#  # f# o# r#  # m# e# a# s# u# r# i# n# g#  # R# e# c# a# l# l# ,#  # P# r# e# c# i# s# i# o# n# ,#  # S# p# e# c# i# f# i# c# i# t# y# ,#  # A# c# c# u# r# a# c# y#  # a# n# d#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t# l# y#  # A# U# C# -# R# O# C#  # C# u# r# v# e# .# 
# 
# ## ##  # C# .#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # R# e# p# o# r# t# 
# 
# A#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # r# e# p# o# r# t#  # i# s#  # u# s# e# d#  # t# o#  # m# e# a# s# u# r# e#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # p# r# e# d# i# c# t# i# o# n# s#  # f# r# o# m#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# l# g# o# r# i# t# h# m# .#  # H# o# w#  # m# a# n# y#  # p# r# e# d# i# c# t# i# o# n# s#  # a# r# e#  # T# r# u# e#  # a# n# d#  # h# o# w#  # m# a# n# y#  # a# r# e#  # F# a# l# s# e# .#  # M# o# r# e#  # s# p# e# c# i# f# i# c# a# l# l# y# ,#  # T# r# u# e#  # P# o# s# i# t# i# v# e# s# ,#  # F# a# l# s# e#  # P# o# s# i# t# i# v# e# s# ,#  # T# r# u# e#  # n# e# g# a# t# i# v# e# s#  # a# n# d#  # F# a# l# s# e#  # N# e# g# a# t# i# v# e# s#  # a# r# e#  # u# s# e# d#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # m# e# t# r# i# c# s#  # o# f#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # r# e# p# o# r# t# 
# 
# T# h# e#  # r# e# p# o# r# t#  # s# h# o# w# s#  # t# h# e#  # m# a# i# n#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# e# t# r# i# c# s#  # p# r# e# c# i# s# i# o# n# ,#  # r# e# c# a# l# l#  # a# n# d#  # f# 1# -# s# c# o# r# e#  # o# n#  # a#  # p# e# r# -# c# l# a# s# s#  # b# a# s# i# s# .#  # T# h# e#  # m# e# t# r# i# c# s#  # a# r# e#  # c# a# l# c# u# l# a# t# e# d#  # b# y#  # u# s# i# n# g#  # t# r# u# e#  # a# n# d#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e# s# ,#  # t# r# u# e#  # a# n# d#  # f# a# l# s# e#  # n# e# g# a# t# i# v# e# s# .#  # P# o# s# i# t# i# v# e#  # a# n# d#  # n# e# g# a# t# i# v# e#  # i# n#  # t# h# i# s#  # c# a# s# e#  # a# r# e#  # g# e# n# e# r# i# c#  # n# a# m# e# s#  # f# o# r#  # t# h# e#  # p# r# e# d# i# c# t# e# d#  # c# l# a# s# s# e# s# .#  # T# h# e# r# e#  # a# r# e#  # f# o# u# r#  # w# a# y# s#  # t# o#  # c# h# e# c# k#  # i# f#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n# s#  # a# r# e#  # r# i# g# h# t#  # o# r#  # w# r# o# n# g# :# 
# 
# T# N#  # /#  # T# r# u# e#  # N# e# g# a# t# i# v# e# :#  # w# h# e# n#  # a#  # c# a# s# e#  # w# a# s#  # n# e# g# a# t# i# v# e#  # a# n# d#  # p# r# e# d# i# c# t# e# d#  # n# e# g# a# t# i# v# e# 
# 
# T# P#  # /#  # T# r# u# e#  # P# o# s# i# t# i# v# e# :#  # w# h# e# n#  # a#  # c# a# s# e#  # w# a# s#  # p# o# s# i# t# i# v# e#  # a# n# d#  # p# r# e# d# i# c# t# e# d#  # p# o# s# i# t# i# v# e# 
# 
# F# N#  # /#  # F# a# l# s# e#  # N# e# g# a# t# i# v# e# :#  # w# h# e# n#  # a#  # c# a# s# e#  # w# a# s#  # p# o# s# i# t# i# v# e#  # b# u# t#  # p# r# e# d# i# c# t# e# d#  # n# e# g# a# t# i# v# e# 
# 
# F# P#  # /#  # F# a# l# s# e#  # P# o# s# i# t# i# v# e# :#  # w# h# e# n#  # a#  # c# a# s# e#  # w# a# s#  # n# e# g# a# t# i# v# e#  # b# u# t#  # p# r# e# d# i# c# t# e# d#  # p# o# s# i# t# i# v# e# 
# 
# ## ##  # D# .#  # P# r# e# c# i# s# i# o# n# 
# A# n#  # a# b# i# l# i# t# y#  # o# f#  # a#  # c# l# a# s# s# i# f# i# e# r#  # n# o# t#  # t# o#  # l# a# b# e# l#  # p# o# s# i# t# i# v# e#  # t# o#  # t# h# e#  # n# e# g# a# t# i# v# e# s# 
# W# h# e# n#  # y# o# u#  # s# a# y#  # a#  # m# a# l# e#  # i# s#  # p# r# e# g# n# a# n# t# ,#  # w# h# i# c# h#  # i# s#  # n# o# t#  # p# o# s# s# i# b# l# e#  # y# e# t# ,#  # t# h# e# n#  # t# h# i# s#  # w# o# u# l# d#  # b# e#  # d# e# t# e# c# t# e# d#  # u# n# d# e# r#  # t# h# i# s#  # p# r# e# c# i# s# i# o# n#  # s# c# o# r# e# .# 
# (# N# u# m# b# e# r#  # o# f#  # t# r# u# e#  # p# o# s# i# t# i# v# e#  # c# a# s# e# s# )#  # /#  # (# N# u# m# b# e# r#  # o# f#  # a# l# l#  # t# h# e#  # p# o# s# i# t# i# v# e#  # c# a# s# e# s# )# 
# *# a# l# l#  # t# h# e#  # p# o# s# i# t# i# v# e#  # c# l# a# s# s# e# s#  # =#  # t# r# u# e#  # p# o# s# i# t# i# v# e#  # +#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e# 
# 
# ## ##  # E# .#  # R# e# c# a# l# l# 
# 
# A# n#  # a# b# i# l# i# t# y#  # o# f#  # a#  # c# l# a# s# s# i# f# i# e# r#  # t# o#  # f# i# n# d#  # a# l# l#  # p# o# s# i# t# i# v# e#  # i# n# s# t# a# n# c# e# s# .#  # S# o# ,#  # o# n# l# y#  # c# o# r# r# e# c# t# e# d#  # m# e# a# s# u# r# e# d#  # i# n# s# t# a# n# c# e# s# ,#  # w# h# i# c# h#  # a# r# e#  # t# r# u# e# -# p# o# s# i# t# i# v# e#  # a# n# d#  # f# a# l# s# e# -# n# e# g# a# t# i# v# e# s# ,#  # a# r# e#  # c# o# n# c# e# r# n# e# d# .# 
# (# N# u# m# b# e# r#  # o# f#  # t# r# u# e#  # p# o# s# i# t# i# v# e# s# )#  # /#  # (# ##  # o# f#  # t# r# u# e#  # p# o# s# i# t# i# v# e# s#  # +#  # ##  # o# f#  # f# a# l# s# e#  # n# e# g# a# t# i# v# e# s# )# 
# *# ##  # s# i# g# n# i# f# i# e# s#  # ‘# n# u# m# b# e# r# ’# 
# B# y#  # f# a# r# ,#  # w# e#  # c# a# n#  # t# e# l# l#  # b# o# t# h#  # P# r# e# c# i# s# i# o# n#  # a# n# d#  # R# e# c# a# l# l#  # f# o# c# u# s#  # o# n#  # t# r# u# e# -# p# o# s# i# t# i# v# e#  # c# a# s# e# s#  # i# n#  # d# i# f# f# e# r# e# n# t#  # p# e# r# s# p# e# c# t# i# v# e# s# .# 
# 
# ## ##  # F# .#  # F# 1# -# s# c# o# r# e# 
# 
# T# h# i# s#  # i# s#  # a#  # w# e# i# g# h# t# e# d#  # h# a# r# m# o# n# i# c#  # m# e# a# n#  # v# a# l# u# e#  # u# s# i# n# g#  # b# o# t# h#  # P# r# e# c# i# s# i# o# n#  # a# n# d#  # R# e# c# a# l# l# .#  # T# h# i# s#  # m# e# a# s# u# r# e#  # i# s#  # p# r# e# t# t# y#  # u# s# e# f# u# l#  # w# h# e# n#  # t# h# e#  # d# a# t# a# s# e# t#  # h# a# s#  # a# n#  # i# m# b# a# l# a# n# c# e# d#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # d# i# f# f# e# r# e# n# t#  # l# a# b# e# l# s# .# 
# {# (# P# r# e# c# i# s# i# o# n#  # *#  # R# e# c# a# l# l# )#  # *#  # 2# }#  # /#  # (# P# r# e# c# i# s# i# o# n#  # +#  # R# e# c# a# l# l# )# 
# 
# 
# 
# 
# 
# ##  # V# I# I# I#  # C# O# N# C# L# U# S# I# O# N# 
# P# r# i# m# a# r# i# l# y#  # i# n#  # t# h# i# s#  # w# o# r# k#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # i# s#  # p# e# r# f# o# r# m# e# d#  # u# s# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# e# c# h# n# i# q# u# e# s# .#  # V# a# r# i# o# u# s#  # t# e# c# h# n# i# q# u# e# s#  # d# e# p# l# o# y# e# d#  # w# e# r# e#  # c# o# m# p# a# r# e# d#  # a# n# d#  # c# o# n# t# r# a# s# t# e# d#  # i# n#  # t# e# r# m# s#  # o# f#  # e# v# a# l# u# a# t# i# o# n#  # m# e# t# r# i# c# s# .#  # M# o# s# t#  # o# f#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# a# s# k# s#  # w# i# l# l#  # s# u# i# t#  # t# o#  # b# e#  # p# r# o# c# e# s# s# e# d#  # i# n#  # t# h# e#  # p# i# p# l# i# n# e#  # d# i# s# c# u# s# s# e# d#  # i# n#  # a# b# o# v# e#  # s# e# c# t# i# o# n# s# .#  # I# n#  # f# u# t# u# r# e#  # t# h# i# s#  # w# o# r# k#  # c# a# n#  # e# x# t# e# n# d#  # t# o#  # e# x# p# l# o# r# e#  # t# h# e#  #  # p# o# t# e# n# t# i# a# l#  # o# f#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k# s#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# a# s# k# s# .#  # 
# 
# ##  # I# X#  # R# E# F# E# R# E# N# C# E# S# 
# 
# 1# .#  #  #  # [# E# D# A#  # +#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # +#  # P# C# A#  # b# y#  # *# P# r# a# s# h# a# n# t#  # B# a# n# e# r# j# e# e# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# p# r# a# s# h# a# n# t# 1# 1# 1# /# e# d# a# -# l# o# g# i# s# t# i# c# -# r# e# g# r# e# s# s# i# o# n# -# p# c# a# )# 
# 
# 1# .#  #  #  # [# I# n# c# o# m# e#  # P# r# e# d# i# c# t# i# o# n#  # (# 8# 4# .# 3# 6# 9# %#  # A# c# c# u# r# a# c# y# )#  # b# y#  # *# I# P# B# y# r# n# e# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# i# p# b# y# r# n# e# /# i# n# c# o# m# e# -# p# r# e# d# i# c# t# i# o# n# -# 8# 4# -# 3# 6# 9# -# a# c# c# u# r# a# c# y# )# 
# 2# .#  #  #  # [# M# u# l# t# i# p# l# e#  # M# L#  # T# e# c# h# n# i# q# u# e# s#  # a# n# d#  # A# n# a# l# y# s# i# s#  # o# f#  # D# a# t# a# s# e# t#  # b# y#  # *# M# a# t# t#  # G# r# e# e# n# *#  # ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# b# a# n# a# n# u# h# b# e# a# t# d# o# w# n# /# m# u# l# t# i# p# l# e# -# m# l# -# t# e# c# h# n# i# q# u# e# s# -# a# n# d# -# a# n# a# l# y# s# i# s# -# o# f# -# d# a# t# a# s# e# t# )# 
# 
# 2# .#  #  #  # [# C# a# t# b# o# o# s# t#  # a# n# d#  # o# t# h# e# r#  # c# l# a# s# s# .# a# l# g# o# s#  # w# i# t# h#  # 8# 8# %#  # a# c# c# u# r# a# c# y#  # b# y#  # *# K# a# n# a# v#  # A# n# a# n# d# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# k# a# n# a# v# 0# 1# 8# 3# /# c# a# t# b# o# o# s# t# -# a# n# d# -# o# t# h# e# r# -# c# l# a# s# s# -# a# l# g# o# s# -# w# i# t# h# -# 8# 8# -# a# c# c# u# r# a# c# y# )# 
# 
# 2# .#  #  #  # [# E# D# A#  # a# n# d#  # I# n# c# o# m# e#  # p# r# e# d# i# c# t# i# o# n# s#  # (# 8# 6# .# 7# 5#  # %#  # a# c# c# u# r# a# c# y# )#  # b# y#  # *# S# u# m# i# t#  # M# i# s# h# r# a# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# s# u# m# i# t# m# 0# 0# 4# /# e# d# a# -# a# n# d# -# i# n# c# o# m# e# -# p# r# e# d# i# c# t# i# o# n# s# -# 8# 6# -# 7# 5# -# a# c# c# u# r# a# c# y# )# 
# 
# 1# .#  #  #  # [# I# n# c# o# m# e#  # p# r# e# d# i# c# t# i# o# n#  # u# s# i# n# g#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # a# n# d#  # X# G# B# o# o# s# t#  # b# y#  # *# N# i# t# i# n# e# s# h# w# a# r# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# g# r# a# y# p# h# a# n# t# o# m# /# i# n# c# o# m# e# -# p# r# e# d# i# c# t# i# o# n# -# u# s# i# n# g# -# r# a# n# d# o# m# -# f# o# r# e# s# t# -# a# n# d# -# x# g# b# o# o# s# t# )# 
# 


# N# o# w#  # l# e# t# s#  # d# i# v# e#  # i# n# t# o#  # t# h# e#  # c# o# d# e#  # a# n# d#  # s# e# e#  # h# o# w#  # t# o#  # s# o# l# v# e#  # t# h# e#  # d# a# t# a# s# e# t# .

# ## ##  #  # I# m# p# o# r# t# i# n# g#  # n# e# c# e# s# s# a# r# y#  # L# i# b# r# a# r# i# e# s# 


# C# a# t# b# o# o# s# t#  # a# l# g# o# r# i# t# h# m#  # m# i# g# h# t#  # n# e# e# d#  # i# n# s# t# a# l# l# a# t# i# o# n# ,#  # t# h# e#  # b# e# l# o# w#  # c# o# d# e#  # i# s#  # i# n#  # t# h# e#  # c# o# m# m# e# n# t#  # f# o# r# m# .#  # R# u# n#  # i# t#  # i# f#  # i# n# s# t# a# l# l# a# t# i# o# n#  # i# s#  # r# e# q# u# i# r# e# d#  

# In[None]

#pip install catboost

# In[None]

#Importing Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_selection import RFECV
from sklearn.metrics import roc_curve, roc_auc_score,accuracy_score,f1_score,log_loss,confusion_matrix,classification_report,precision_score,recall_score


# In[None]

#Reading Dataset
dataset = pd.read_csv('../input/adult-census-income/adult.csv')
dataset.head()

# W# e#  # h# a# v# e#  # t# w# o#  # v# a# r# i# a# b# l# e# s#  # r# e# g# a# r# d# i# n# g#  # E# d# u# c# a# t# i# o# n# ,#  # "# e# d# u# c# a# t# i# o# n# "#  # a# n# d#  # "# e# d# u# c# a# t# i# o# n# .# n# u# m# "# .# "# e# d# u# c# a# t# i# o# n# .# n# u# m# "#  # i# s#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# e# r# s# i# o# n#  # o# f#  # "# e# d# u# c# a# t# i# o# n# "#  # s# o#  # w# e#  # c# a# n#  # d# r# o# p#  # t# h# e#  # "# e# d# u# c# a# t# i# o# n# "#  # v# a# r# i# a# b# l# e

# In[None]

#Dropping education since we have its categorical coloumn education.num
dataset.drop(columns=['education'],inplace=True)

# In[None]

#data types of columns
dataset.dtypes

# In[None]

#List of columns present in Dataset
dataset.columns

# In[None]

#Shape of Dataset
dataset.shape

# A# l# l#  # t# h# e# s# e#  # c# o# l# u# m# n# s#  # n# a# m# e# s#  # c# o# n# s# i# t# s#  # o# f#  # "# .# "# ,#  # w# h# i# c# h#  # c# a# u# s# e#  # p# r# o# b# l# e# m#  # w# h# i# l# e#  # c# a# l# l# i# n# g#  # t# h# e#  # c# o# l# u# m# n# s# ,#  # s# o#  # r# e# p# l# a# c# i# n# g#  # a# l# l#  # t# h# e#  # "# .# "#  # w# i# t# h#  # "# _# "#  # i# n#  # t# h# e#  # c# o# l# u# m# n#  # n# a# m# e# s

# In[None]

#Renaming few columns
dataset.rename(columns = {'education.num':'education_num', 'marital.status':'marital_status', 'capital.gain':'capital_gain',
                          'capital.loss':'capital_loss','hours.per.week':'hours_per_week','native.country':'native_country'}, inplace = True) 

# In[None]

#Checking the change
dataset.columns

# "# ?# "#  # r# e# p# r# e# s# e# n# t# s#  # n# u# l# l#  # v# a# l# u# e# s#  # ,#  # l# e# t# s#  # r# e# p# l# a# c# e#  # t# h# e# m#  # w# i# t# h#  # n# p# .# n# a# n

# In[None]

#Replacing "?" with NAN
dataset['workclass'].replace('?', np.nan, inplace= True)
dataset['occupation'].replace('?', np.nan, inplace= True)
dataset['native_country'].replace('?', np.nan, inplace= True)

# In[None]

#A detailed description of the datset
dataset.describe(include='all')

# ## ##  # H# a# n# d# l# i# n# g#  # t# h# e#  # M# i# s# s# i# n# g#  # v# a# l# u# e# s# 
# 
# E# v# e# r# y#  # d# a# t# s# e# t#  # h# a# v# e#  # s# o# m# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # l# e# t# s#  # f# i# n# d#  # o# u# t#  # i# n#  # w# h# i# c# h#  # c# l# o# u# m# n# s#  # t# h# e# y#  # a# r# e# ?

# In[None]

#Number of null values in the dataset column wise
dataset.isnull().sum()

# In[None]

#Grouping Workclass
dataset.groupby(['workclass']).size().plot(kind="bar",fontsize=14)
plt.xlabel('Work Class Categories')
plt.ylabel('Count of People')
plt.title('Barplot of Workclass Variable')

# A# l# l#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # "# w# o# r# k# c# l# a# s# s# "#  # c# a# n#  # b# e#  # r# e# p# l# a# c# e# d#  # b# y#  # "# p# r# i# v# a# t# e# "

# In[None]

#Grouping Occupation
dataset.groupby(['occupation']).size().plot(kind="bar",fontsize=14)
plt.xlabel('Occupation Categories')
plt.ylabel('Count of People')
plt.title('Barplot of Occupation Variable')

# "# o# c# c# u# p# a# t# i# o# n# "#  # n# u# l# l#  # v# a# l# u# e# s#  # c# a# n# t#  # b# e#  # r# e# p# l# a# c# e# d#  # b# y#  # m# o# d# e#  # ,#  # i# t# s#  # m# o# r# e#  # o# r#  # l# i# k# e#  # e# q# u# a# l# l# y#  # d# i# s# t# r# i# b# u# t# e# d# .#  # S# o#  # d# r# o# p#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # t# h# i# s#  # c# o# l# u# m# n

# In[None]

#Grouping Native Country
dataset.groupby(['native_country']).size().plot(kind="bar",fontsize=10)
plt.xlabel('Native Country Categories')
plt.ylabel('Count of People')
plt.title('Barplot of Native Country Variable')

# I# t# s#  # c# l# e# a# r#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # o# f#  # "# n# a# t# i# v# e# _# c# o# u# n# t# r# y# "#  # c# o# u# l# d#  # b# e#  # e# a# s# i# l# y#  # r# e# p# l# a# c# e# d#  # b# y#  # m# o# d# e# .

# In[None]

#Droping null values in occupation column
dataset.dropna(subset=['occupation'],inplace=True)
dataset.isnull().sum()

# B# y#  # d# r# o# p# p# i# n# g#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # "# o# c# c# u# p# a# t# i# o# n# "#  # w# e#  # l# o# s# e#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # "# w# o# r# k# c# l# a# s# s# "#  # a# l# s# o# .

# In[None]

#Imputing null values with Mode

dataset['native_country'].fillna(dataset['native_country'].mode()[0], inplace=True)

# In[None]

#Checking for null values
dataset.isnull().sum()

# In[None]

#Confirming the Categorical Features
categorical_feature_mask = dataset.dtypes==object
categorical_feature_mask


# ## ##  # L# a# b# e# l#  # E# n# c# o# d# i# n# g# 
# 
# A# l# l#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # c# o# l# u# m# n# s#  # a# n# d#  # t# h# e#  # c# o# l# u# m# n# s#  # w# i# t# h#  # t# e# x# t#  # d# a# t# a#  # a# r# e#  # b# e# i# n# g#  # L# a# b# e# l#  # E# n# c# o# d# e# d# e# d#  # i# n#  # t# h# i# s#  # s# t# e# p# .

# In[None]

##Label encoding the all the categorical features


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
cat_list=['income','workclass','marital_status','occupation','relationship','race','sex','native_country']
dataset[cat_list]=dataset[cat_list].apply(lambda x:le.fit_transform(x))

# In[None]

#Number of categories in dataset
dataset.nunique()

# ## ##  # C# o# r# r# e# l# a# t# i# o# n# 
# 
# T# o#  # f# i# n# d#  # o# u# t#  # w# h# e# t# h# e# r#  # t# h# e# r# e#  # i# s#  # a# n# y#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # v# a# r# i# a# b# l# e# s# ,#  # i# n#  # o# t# h# e# r#  # t# e# r# m# s#  # m# u# l# t# i# c# o# l# l# i# n# e# a# r# i# a# t# y# .# 
# 


# In[None]

#Finding Correlation between variables
corr = dataset.corr()
mask = np.zeros(corr.shape, dtype=bool)
mask[np.triu_indices(len(mask))] = True
plt.subplots(figsize=(10,7))
sns.heatmap(corr, xticklabels=corr.columns, yticklabels=corr.columns,annot=True,cmap='RdYlGn',mask = mask)

# In[None]

#Dropping "sex" variable since it is highly correlated with "relationship" variable 
dataset.drop(columns=['sex'],inplace=True)

# In[None]

#Slicing dataset into Independent(X) and Target(y) varibles
y = dataset.pop('income')
X = dataset


# In[None]

#Scaling the dependent variables
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)

# In[None]

#Dividing dataset into test and train
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10917451.npy", { "accuracy_score": score })

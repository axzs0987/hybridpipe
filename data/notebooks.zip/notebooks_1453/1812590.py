import pandas as pd
# ##  # O# u# t# l# i# e# r# s# :#  # A# s# s# i# g# n# m# e# n# t#  # 6# 
#  #  #  #  # D# w# e# e# p# a#  # H# o# n# n# a# v# a# l# l# i#  # 0# 1# F# B# 1# 6# E# C# S# 1# 3# 8# 
#  #  #  #  # I# s# h# i# t# a#  # B# h# a# n# d# a# r# i#  # 0# 1# F# B# 1# 6# E# C# S# 1# 4# 3# 
#  #  #  #  # K# a# v# y# a#  # V# a# r# m# a#  # 0# 1# F# B# 1# 6# E# C# S# 1# 6# 2

# ## ## ##  # Q# u# e# s# t# i# o# n# 
# U# s# e#  # t# h# e#  # g# i# v# e# n#  # d# a# t# a# s# e# t#  # w# h# i# c# h#  # d# e# s# c# r# i# b# e# s# ​# r# e# c# o# r# d# s#  # o# f#  # a# b# s# e# n# t# e# e# i# s# m#  # a# t#  # w# o# r# k#  # f# r# o# m#  # J# u# l# y#  # 2# 0# 0# 7#  # t# o#  # J# u# l# y#  # 2# 0# 1# 0#  # a# t#  # a#  # c# o# u# r# i# e# r#  # c# o# m# p# a# n# y#  # i# n#  # B# r# a# z# i# l# .#  # S# p# l# i# t#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # T# r# a# i# n# i# n# g#  # a# n# d#  # T# e# s# t# i# n# g#  # d# a# t# a# .#  # U# s# e#  # a# n# y#  # 2#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # o# r#  # c# l# u# s# t# e# r# i# n# g#  # t# e# c# h# n# i# q# u# e# s#  # t# o#  # p# r# e# d# i# c# t#  # '# A# b# s# e# n# t# e# e# i# s# m#  # t# i# m# e#  # i# n#  # h# o# u# r# s# '# .#  # J# u# s# t# i# f# y#  # a# n# y#  # p# a# r# a# m# e# t# e# r#  # (# s# u# c# h#  # a# s#  # k#  # (# f# o# r#  # k# -# N# N#  # o# r#  # k# -# m# e# a# n# s# )# ,#  # e# t# c# .# )#  # i# f#  # p# r# e# -# d# e# t# e# r# m# i# n# e# d# .#  # C# o# m# p# a# r# e#  # t# h# e#  # t# e# c# h# n# i# q# u# e# s#  # u# s# e# d#  # a# n# d#  # s# t# a# t# e#  # w# h# i# c# h#  # o# f#  # t# h# e#  # t# w# o#  # i# s#  # b# e# t# t# e# r#  # f# o# r#  # t# h# i# s#  # d# a# t# a# .#  # C# l# e# a# r# l# y#  # i# n# t# e# r# p# r# e# t#  # t# h# e#  # r# e# s# u# l# t# s#  # a# n# d#  # s# u# p# p# o# r# t#  # y# o# u# r#  # i# n# t# e# r# p# r# e# t# a# t# i# o# n# s#  # w# i# t# h#  # c# o# m# p# u# t# a# t# i# o# n# s#  # o# f#  # s# u# i# t# a# b# l# e#  # p# e# r# f# o# r# m# a# n# c# e#  # m# e# a# s# u# r# e# s# .

# In[None]

from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt # plotting
import numpy as np # linear algebra
import os # accessing directory structure
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
nRowsRead = 1000 # specify 'None' if want to read whole file
df1 = pd.read_csv('../input/Absenteeism_at_work.csv', delimiter=',', nrows = None)
df1.dataframeName = 'Absenteeism_at_work.csv'
nRow, nCol = df1.shape
print(f'There are {nRow} rows and {nCol} columns')
df1.head()

# ##  # T# e# c# h# n# i# q# u# e# s#  # U# s# e# d# 
# 
# >#  # T# w# o#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# e# c# h# n# i# q# u# e# s#  # h# a# v# e#  # b# e# e# n#  # u# s# e# d#  # t# o#  # a# p# p# r# o# a# c# h#  # t# h# i# s#  # q# u# e# s# t# i# o# n# 
# 1# .#  #  # D# e# c# i# s# i# o# n#  # T# r# e# e# s# 
# 1# .#  #  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# 
# ## ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # v# s#  # C# l# u# s# t# e# r# i# n# g# 
# 
# C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # i# s#  # a#  # s# u# p# e# r# v# i# s# e# d#  # l# e# a# r# n# i# n# g#  # t# e# c# h# n# i# q# u# e#  # i# n#  # w# h# i# c# h#  # w# e#  # k# n# o# w#  # t# h# e#  # c# l# a# s# s# e# s#  # b# e# f# o# r# e#  # p# r# o# c# e# s# s# i# n# g# ,#  # a# n# d#  # w# e#  # a# t# t# e# m# p# t#  # t# o#  # t# r# a# i# n#  # t# h# e#  # m# o# d# e# l#  # b# a# s# e# d#  # o# n#  # t# h# e#  # t# r# a# i# n# i# n# g#  # d# a# t# a#  # s# e# t#  # a# n# d#  # u# s# e#  # t# h# a# t#  # t# o#  # p# r# e# d# i# c# t#  # f# u# t# u# r# e#  # o# b# s# e# r# v# a# t# i# o# n# s# .# 
# C# l# u# s# t# e# r# i# n# g#  # i# s#  # a# n#  # u# n# s# u# p# e# r# v# i# s# e# d#  # t# e# c# h# n# i# q# u# e#  # i# n#  # w# h# i# c# h#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # c# l# a# s# s# e# s#  # i# s#  # n# o# t#  # k# n# o# w# n#  # p# r# i# o# r#  # t# o#  # p# r# o# c# e# s# s# i# n# g# .#  # I# t#  # i# s#  # m# a# i# n# l# y#  # a#  # w# a# y#  # t# o#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a#  # a# n# d#  # i# n# f# e# r#  # s# o# m# e#  # i# n# f# o# r# m# a# t# i# o# n#  # f# r# o# m#  # i# t# .# 
# 
# I# n#  # o# u# r#  # d# a# t# a# s# e# t#  # o# f#  # '# A# b# s# e# n# t# e# e# i# s# m#  # A# t#  # W# o# r# k# '# ,#  # t# h# e# r# e#  # a# r# e#  # v# a# r# i# o# u# s#  # f# e# a# t# u# r# e# s#  # a# l# o# n# g#  # w# i# t# h#  # t# h# e#  # r# e# a# l#  # v# a# l# u# e#  # o# f#  # n# o#  # o# f#  # h# o# u# r# s#  # a# b# s# e# n# t# .#  # I# n#  # s# u# c# h#  # a#  # c# a# s# e#  # w# h# e# r# e#  # t# h# e#  # t# a# r# g# e# t#  # i# s#  # k# n# o# w# n#  # a# n# d#  # w# e#  # w# a# n# t#  # t# o#  # t# r# a# i# n#  # a#  # m# o# d# e# l#  # t# o#  # p# r# e# d# i# c# t#  # b# a# s# e# d#  # o# n#  # t# h# e#  # g# i# v# e# n#  # s# e# t#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s#  # a# n# d#  # v# a# l# u# e# s# ,#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# e# c# h# n# i# q# u# e#  # w# o# u# l# d#  # b# e#  # t# h# e#  # p# r# e# f# e# r# r# e# d#  # a# p# p# r# o# a# c# h# .# 
# 
# I# n#  # t# h# e#  # c# a# s# e#  # o# f#  # c# l# u# s# t# e# r# i# n# g# ,#  # w# e#  # m# a# y#  # y# e# i# l# d#  # c# l# u# s# t# e# r# s#  # w# h# i# c# h#  # m# a# y#  # b# e#  # a# l# g# o# r# i# t# h# m# i# c# a# l# l# y#  # s# i# m# i# l# a# r#  # b# u# t#  # n# o# t#  # i# n#  # t# e# r# m# s#  # o# f#  # t# h# e#  # '# '# A# b# s# e# n# t# e# e# i# s# m#  # t# i# m# e#  # i# n#  # h# o# u# r# s# '# .

# ## ## ##  # S# e# p# a# r# a# t# i# o# n#  # o# f#  # T# r# a# i# n# i# n# g#  # a# n# d#  # T# e# s# t# i# n# g#  # D# a# t# a# 
#  #  #  #  # T# h# e#  # r# a# t# i# o#  # o# f#  # t# r# a# i# n#  # t# o#  # t# e# s# t#  # c# h# o# s# e# n#  # i# s#  # 4# :# 1

# In[None]

X= df1.iloc[:,0:14]
y=df1['Absenteeism time in hours']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1812590.npy", { "accuracy_score": score })

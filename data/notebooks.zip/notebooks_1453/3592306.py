import pandas as pd
# In[49]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt
import xgboost as xgb

# Import statements required for Plotly 
import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
import plotly.tools as tls

import missingno as msno
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[50]

data=pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')
df=data.copy()

# In[51]

msno.matrix(df)

# In[52]

df.head()

# *# *# C# h# e# c# k# i# n# g#  # C# o# u# n# t#  # h# o# w#  # m# a# n# y#  # e# m# p# l# o# y# e# e#  # o# f#  # A# t# t# r# i# t# e# *# *

# In[53]

sns.countplot(df['Attrition'])
plt.show()

# >#  # l# o# t#  # s# h# o# w# s#  # t# h# a# t#  # a# r# o# u# n# d#  # 2# 5# 0#  # p# e# o# p# l# e#  # h# a# v# e#  # l# e# f# t#  # t# h# e#  # o# r# g# a# n# i# z# a# t# i# o# n#  # w# h# i# l# e#  # t# h# e#  # o# r# g# a# n# i# z# a# t# i# o# n#  # h# a# s#  # b# e# e# n#  # a# b# l# e#  # t# o#  # r# e# t# a# i# n#  # a# r# o# u# n# d#  # 1# 2# 0# 0#  # p# e# o# p# l# e# .

# *# *# D# i# s# t# r# i# b# u# t# i# n# g#  # D# a# t# a#  # w# i# t# h#  # R# e# s# p# e# c# t#  # t# o#  # I# m# p# o# r# t# a# n# t#  # F# a# c# t# o# r# s# *# *

# In[54]

fig,ax = plt.subplots(2,2, figsize=(15,10))               # 'ax' has references to all the four axes
plt.suptitle("Distribution with Respect to Important Factors", fontsize=20)
sns.distplot(df['Age'], ax = ax[0,0])  # Plot on 1st axes
ax[0][0].set_title('Distribution of Age',fontsize=14)
sns.distplot(df['TotalWorkingYears'], ax = ax[0,1])  # Plot on IInd axes
ax[0][1].set_title('Distribution of Total Working Years',fontsize=14)
sns.distplot(df['YearsAtCompany'], ax = ax[1,0])  # Plot on IIIrd axes
ax[1][0].set_title('Employee Years at company',fontsize=14)
sns.distplot(df['YearsInCurrentRole'], ax = ax[1,1])  # Plot on IV the axes
ax[1][1].set_title('Employee Years in Current Role',fontsize=14)
plt.show()  

# In[55]

sns.barplot(x='Attrition', y='MonthlyIncome', hue= 'Gender',data=df)
plt.show()

# >#  # p# e# o# p# l# e#  # w# i# t# h#  # l# e# s# s#  # m# o# n# t# h# l# y# i# n# c# o# m# e#  # (# a# r# o# u# n# d#  # 3# 0# 0# 0#  # u# n# i# t# s# )#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# e#  # o# r# g# a# n# i# z# a# t# i# o# n#  # t# h# a# n#  # t# h# o# s# e#  # w# i# t# h#  # b# e# t# t# e# r#  # i# n# c# o# m# e#  # (# a# r# o# u# n# d#  # 5# 0# 0# 0#  # u# n# i# t# s# )# .

# *# *# G# e# n# d# e# r#  # I# n# c# o# m# e#  # G# a# p# *# *

# In[56]

sns.boxplot(df['Gender'], df['MonthlyIncome'])
plt.title('MonthlyIncome vs Gender Box Plot', fontsize=20)      
plt.xlabel('MonthlyIncome', fontsize=16)
plt.ylabel('Gender', fontsize=16)
plt.show()

# In[57]

age=pd.DataFrame(data.groupby("Age")[["MonthlyIncome","Education","JobLevel","JobInvolvement","PerformanceRating","JobSatisfaction","EnvironmentSatisfaction","RelationshipSatisfaction","WorkLifeBalance","DailyRate","MonthlyRate"]].mean())
age["Count"]=data.Age.value_counts(dropna=False)
age.reset_index(level=0, inplace=True)
age.head()

# In[58]

plt.figure(figsize=(14,5))
ax=sns.barplot(x=age.Age,y=age.Count, data=df)
plt.xticks(rotation=90)
plt.xlabel("Age")
plt.ylabel("Counts")
plt.title("Age Counts")
plt.show()

# In[59]

plt.figure(figsize=(14,5))
ax=sns.barplot(x=age.Age,y=age.MonthlyIncome)
#palette = sns.cubehelix_palette(len(age.index))
plt.xticks(rotation=90)
plt.xlabel("Age")
plt.ylabel("Monthly Income")
plt.title("Monthly Income According to Age")
plt.show()

# In[None]



# *# *# P# l# o# t# t# i# n# g#  # R# o# l# e#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # t# h# e# i# r#  # I# n# c# o# m# e# s# *# *

# In[60]

income=pd.DataFrame(data.groupby("JobRole").MonthlyIncome.mean().sort_values(ascending=False))

# In[61]

plt.figure(figsize=(14,5))
ax=sns.barplot(x=income.index,y=income.MonthlyIncome)
plt.xticks(rotation=90)
plt.xlabel("Job Roles")
plt.ylabel("Monthly Income")
plt.title("Job Roles with Monthly Income")
plt.show()


# In[62]

plt.figure(figsize=(15,6))
plt.style.use('seaborn-colorblind')
plt.grid(True, alpha=0.5)
sns.kdeplot(df.loc[df['Attrition'] == 'No', 'Age'], label = 'Active Employee')
sns.kdeplot(df.loc[df['Attrition'] == 'Yes', 'Age'], label = 'Ex-Employees')
plt.xlim(left=18, right=60)
plt.xlabel('Age (years)')
plt.ylabel('Density')
plt.title('Age Distribution in Percent by Attrition Status');

# In[63]

sns.factorplot(data=df,kind='count',x='Attrition',col='Department')

# In[64]

plt.figure(figsize=(15,6))
ax=sns.countplot(x='JobRole',hue='Attrition', data=df)
ax.set_xticklabels(ax.get_xticklabels(), rotation=15, ha="right" )
plt.show()

# In[65]

plt.figure(figsize=(15,6))
ax=sns.countplot(x='YearsAtCompany',hue='Attrition', data=df)
ax.set_xticklabels(ax.get_xticklabels(), rotation=25, ha="right" )
plt.show()

# In[66]

plt.figure(figsize=(15,6))
ax=sns.countplot(x='PercentSalaryHike',hue='Attrition', data=df)
ax.set_xticklabels(ax.get_xticklabels(), rotation=25, ha="right" )
plt.show()

# In[67]

sns.factorplot(data=df,y='Age',x='Attrition',size=5,aspect=1,kind='box')

# In[68]

pd.crosstab(columns=[df.Attrition],index=[df.JobSatisfaction],margins=True,normalize='index')

# In[69]

pd.crosstab(columns=[df.Attrition],index=[df.EnvironmentSatisfaction],margins=True,normalize='index')

# In[70]

pd.crosstab(columns=[df.Attrition],index=[df.JobInvolvement],margins=True,normalize='index') 

# In[71]

pd.crosstab(columns=[df.Attrition],index=[df.WorkLifeBalance],margins=True,normalize='index')

# In[72]

pd.crosstab(columns=[df.Attrition],index=[df.RelationshipSatisfaction],margins=True,normalize='index')

# In[73]

df1=df.copy()

# In[74]

dect_gender={'Male':0,'Female':1}
df1['Gender']=df1['Gender'].map(dect_gender)

# In[75]

dect_attrition={'Yes':0,'No':1}
df1['Attrition']=df1['Attrition'].map(dect_attrition)

# In[76]

df1.drop(['BusinessTravel','DailyRate','EmployeeCount','EmployeeNumber','HourlyRate','MonthlyRate'
         ,'NumCompaniesWorked','Over18','StandardHours', 'StockOptionLevel','TrainingTimesLastYear',
       'Department','EducationField','OverTime','JobRole','MaritalStatus'],axis=1,inplace=True)

# In[77]

X = df1.drop('Attrition',axis = 1)
Y = df1['Attrition']

# In[78]

from sklearn.model_selection import train_test_split

# In[79]

from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/3592306.npy", { "accuracy_score": score })

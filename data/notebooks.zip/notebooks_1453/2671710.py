import pandas as pd
# ##  # A# u# s# t# r# a# l# i# a#  # R# a# i# n#  # P# r# e# d# i# c# t# i# o# n

# In[None]

# import libraries

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
import os


# In[None]

# load data
df = pd.read_csv('../input/weatherAUS.csv')
df.head()

# In[None]

# let's check data info
df.info()

# In[None]

# we can also plot a heatmap to visualize missing values
sns.heatmap(df.isnull(),yticklabels=False,cbar=False,cmap='viridis')

# In[None]

# we will drop some columns which has 30-40% of the values missing such as 'Evaporation'
# we drop date column as well since its of no use in this kernel
# we will drop few wind attributes as well
df.drop(['Date','Evaporation','Sunshine','Cloud9am','Cloud3pm',
         'WindGustDir','WindDir9am','WindDir3pm'],axis=1,inplace=True)
df.head()

# In[None]

# let's drop some of the rows of missing values
df.dropna(subset=['Pressure3pm','Humidity3pm','Pressure9am','RainToday'],axis=0,inplace=True)

# In[None]

# replace rest of the nulls with respective means
fill_feat = ['Temp9am','Humidity9am','MinTemp','MaxTemp','WindSpeed3pm','WindSpeed9am','WindGustSpeed']
for i in fill_feat:
    df[i].fillna(np.mean(df[i]),inplace=True)


# In[None]

df.info()

# In[None]

# count target class
sns.countplot(x='RainTomorrow',data=df)

# In[None]

# study relation between rain today and tomorrow
sns.countplot(x='RainTomorrow',data=df,hue='RainToday')

# In[None]

# now time to encode categorical variables to numerics
# we use Label encoder for 'Location', and pandas' get_dummies for 'RainToday' and 'RainTomorrow'
from sklearn.preprocessing import LabelEncoder

# In[None]

le = LabelEncoder()
df['Location'] = le.fit_transform(df['Location'])
df['RainToday'] = pd.get_dummies(df['RainToday'],drop_first=True)
df['RainTomorrow'] = pd.get_dummies(df['RainTomorrow'],drop_first=True)

# In[None]

# lets see if data is ready for training
df.head()

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

X = df.drop('RainTomorrow',axis=1)
y = df['RainTomorrow']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2671710.npy", { "accuracy_score": score })

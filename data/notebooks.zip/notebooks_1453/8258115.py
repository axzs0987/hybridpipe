import pandas as pd
# ##  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # x#  # G# B# M#  # x#  # X# G# B# o# o# s# t# 
# 
# O# s#  # t# r# ê# s#  # m# é# t# o# d# o# s#  # u# s# a# m#  # `# á# r# v# o# r# e#  # d# e#  # d# e# c# i# s# ã# o# `#  # c# o# m# o#  # b# a# s# e#  # e#  # s# ã# o#  # c# h# a# m# a# d# o# s#  # d# e#  # `# m# é# t# o# d# o# s#  # e# n# s# e# m# b# l# e# `# ,#  # q# u# e#  # s# e#  # c# a# r# a# c# t# e# r# i# z# a# m#  # c# o# m# o#  # m# é# t# o# d# o# s#  # q# u# e#  # p# r# o# c# u# r# a# m#  # u# s# a# r#  # m# o# d# e# l# o# s#  # m# a# i# s#  # s# i# m# p# l# e# s# /# f# r# a# c# o# s#  # d# e#  # f# o# r# m# a#  # c# o# n# j# u# n# t# a#  # p# a# r# a#  # m# e# l# h# o# r# a# r#  # o#  # d# e# s# e# m# p# e# n# h# o# .# 
# 
# ## ##  # R# a# n# d# o# m#  # F# o# r# e# s# t# 
# P# a# r# a#  # o# b# t# e# r#  # m# e# l# h# o# r#  # a# c# u# r# á# r# i# c# a# ,#  # o#  # a# l# g# o# r# i# t# i# m# o#  # d# e#  # R# F#  # v# a# i#  # c# r# i# a# r#  # d# i# v# e# r# s# a# s#  # `# á# r# v# o# r# e# s#  # d# e#  # d# e# c# i# s# ã# o# `#  # (# p# a# r# â# m# e# t# r# o#  # `# n# _# e# s# t# i# m# a# t# o# r# s# `# )#  # e#  # c# h# e# g# a# r#  # a# o#  # r# e# s# u# l# t# a# d# o#  # f# i# n# a# l#  # c# o# m#  # b# a# s# e#  # n# o#  # r# e# s# u# l# t# a# d# o#  # d# e#  # c# a# d# a#  # á# r# v# o# r# e#  # c# r# i# a# d# a# .#  # A#  # i# d# é# i# a#  # b# á# s# i# c# a#  # é#  # s# e# p# a# r# a# r#  # o#  # c# o# n# j# u# n# t# o#  # d# e#  # d# a# d# o# s#  # d# i# v# e# r# s# a# s#  # v# e# z# e# s#  # e#  # p# a# r# a#  # c# a# d# a#  # s# u# b# -# c# o# n# j# u# n# t# o#  # t# r# e# i# n# a# r#  # u# m#  # n# o# v# o#  # r# e# g# r# e# s# s# o# r# /# c# l# a# s# s# i# f# i# c# a# d# o# r# .#  #  # O# s#  # d# i# f# e# r# e# n# t# e# s#  # r# e# g# r# e# s# s# o# r# e# s# /# c# l# a# s# s# i# f# i# c# a# d# o# r# e# s#  # i# r# ã# o#  # p# r# o# d# u# z# i# r#  # r# e# s# u# l# t# a# d# o# s#  # d# i# f# e# r# e# n# t# e# s# ,#  # e#  # o#  # r# e# s# u# l# t# a# d# o#  # f# i# n# a# l#  # s# e# r# á#  # d# e# t# e# r# m# i# n# a# d# o#  # c# o# m#  # b# a# s# e#  # n# e# s# s# a# s#  # r# e# g# r# e# s# s# õ# e# s# /# c# l# a# s# s# i# f# i# c# a# ç# õ# e# s# .# 
# 
# ## ##  # G# r# a# d# i# e# n# t#  # B# o# o# s# t# i# n# g# 
# G# B# M#  # é#  # u# m#  # m# é# t# o# d# o#  # d# e#  # `# b# o# o# s# t# i# n# g# `# ,#  # c# o# n# s# t# r# u# í# d# o#  # e# m#  # c# i# m# a#  # d# e#  # r# e# g# r# e# s# s# o# r# e# s# /# c# l# a# s# s# i# f# i# c# a# d# o# r# e# s#  # f# r# a# c# o# s# .#  # A#  # i# d# é# i# a#  # é#  # a# d# i# c# i# o# n# a# r#  # u# m#  # r# e# g# r# e# s# s# o# r# /# c# l# a# s# s# i# f# i# c# a# d# o# r#  # d# e#  # c# a# d# a#  # v# e# z# ,#  # e# n# t# ã# o#  # o#  # p# r# ó# x# i# m# o#  # r# e# g# r# e# s# s# o# r# /# c# l# a# s# s# i# f# i# c# a# d# o# r#  # é#  # t# r# e# i# n# a# d# o#  # p# a# r# a#  # m# e# l# h# o# r# a# r#  # o#  # r# e# s# u# l# t# a# d# o#  # a# t# i# n# g# i# d# o#  # a# t# é#  # o#  # m# o# m# e# n# t# o#  # (# '# s# o# m# a#  # d# e#  # r# e# s# u# l# t# a# d# o# s# '# )# .#  # A# o#  # c# o# n# t# r# á# r# i# o#  # d# o#  # R# F# ,#  # q# u# e#  # t# r# e# i# n# a#  # c# a# d# a#  # r# e# g# r# e# s# s# o# r# /# c# l# a# s# s# i# f# i# c# a# d# o# r#  # d# e#  # f# o# r# m# a#  # i# n# d# e# p# e# n# d# e# n# t# e# ,#  # n# o#  # G# B# M#  # e# l# e# s#  # s# ã# o#  # t# r# e# i# n# a# d# o# s#  # e# m#  # c# o# n# j# u# n# t# o# ,#  # u# m#  # l# i# g# a# d# o#  # a# o#  # o# u# t# r# o# .# 
# 
# ## ##  # X# G# B# o# o# s# t# 
# X# G# B#  # é#  # u# m# a#  # i# m# p# l# e# m# e# n# t# a# ç# ã# o#  # e# s# p# e# c# í# f# i# c# a#  # d# o#  # G# B# M# ,#  # d# i# t# a#  # m# e# l# h# o# r#  # e#  # m# a# i# s#  # r# á# p# i# d# a#  # q# u# e#  # a#  # i# m# p# l# e# m# e# n# t# a# ç# ã# o#  # p# a# d# r# ã# o#  # d# o#  # s# c# i# k# i# t# -# l# e# a# r# n# .#  # T# a# n# t# o#  # o#  # G# B# M#  # q# u# a# n# t# o#  # o#  # X# G# B#  # p# r# e# c# i# s# a# m#  # d# e#  # m# a# i# o# r#  # t# r# a# b# a# l# h# o#  # d# e#  # i# n# t# e# r# p# r# e# t# a# ç# ã# o#  # d# o# s#  # d# a# d# o# s#  # e#  # `# t# u# n# n# i# n# g# `#  # d# o#  # m# o# d# e# l# o# .

# In[None]

# Importando as bibliotecas
import numpy as np
import pandas as pd

# Verificando os arquivos
import os
#print(os.listdir("../input"))

# In[None]

# Carregando os dados
df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

df.head().T

# In[None]

# Verificando os tipos e os valores nulos
df.info()

# In[None]

# Transformar texto em número
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].astype('category').cat.codes

# In[None]

# Dividindo o DataFrame
from sklearn.model_selection import train_test_split

# Treino e teste
y_varible = df["Churn"]
x_varible = df.drop(["Churn"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/8258115.npy", { "accuracy_score": score })

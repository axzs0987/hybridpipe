import pandas as pd
# In[None]

# import dependencies
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import seaborn as sns

sns.set(style="darkgrid")

# In[None]

# load data 
df = pd.read_csv("../input/HR_comma_sep.csv");

# get the column names to list
col_names = df.columns.tolist()

print("Column names:")
print(col_names)

print("\nSample data:")
df.head()

# In[None]

# we have 14999 rows and 10 columns
df.shape

# ## ##  # 1#  # F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g# 
# 
# 


# In[None]

# change the names of sales to department
df = df.rename(columns = {'sales':'department'})

df.head()

# In[None]

# check is the data contains 'null values'
df.isnull().any()

# In[None]

# check what athe departments are 
df['department'].unique()

# In[None]

#numpy.where(condition[, x, y])
#Return elements, either from x or y, depending on condition.

# turn support category in technical category
df['department'] = np.where(df['department'] == 'support', 'technical', df['department'])

# turn IT in technical category
df['department'] = np.where(df['department'] == 'IT' , 'technical', df['department'])

df['department'].unique()

# ## ##  # 2#  # D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n# 
# 
# L# e# t# s#  # f# i# n# d#  # o# u# t#  # h# o# w#  # m# a# n# y#  # p# e# o# p# l# e#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y# .# 
# 


# In[None]

df['left'].value_counts()

# In[None]

3571/11428

# In[None]

# check the numbers across people that left and people that didnt left

# pandas groupby function allows you to group by certain features
df.groupby('left').mean()

# O# b# s# e# r# v# a# t# i# o# n# s# ;# 
# 
# -#  # T# h# e#  # a# v# e# r# a# g# e#  # s# a# t# i# s# f# a# c# t# i# o# n#  # l# e# v# e# l#  # o# f#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # s# t# a# y# e# d#  # w# i# t# h#  # t# h# e#  # c# o# m# p# a# n# y#  # i# s#  # h# i# g# h# e# r#  # t# h# a# n#  # t# h# a# t#  # o# f#  # t# h# e#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # l# e# f# t# .# 
# -#  # T# h# e#  # a# v# e# r# a# g# e#  # m# o# n# t# h# l# y#  # w# o# r# k#  # h# o# u# r# s#  # o# f#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y#  # i# s#  # m# o# r# e#  # t# h# a# n#  # t# h# a# t#  # o# f#  # t# h# e#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # s# t# a# y# e# d# .# 
# -#  # T# h# e#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # h# a# d#  # w# o# r# k# p# l# a# c# e#  # a# c# c# i# d# e# n# t# s#  # a# r# e#  # l# e# s# s#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# a# n#  # t# h# a# t#  # o# f#  # t# h# e#  # e# m# p# l# o# y# e# e#  # w# h# o#  # d# i# d#  # n# o# t#  # h# a# v# e#  # w# o# r# k# p# l# a# c# e#  # a# c# c# i# d# e# n# t# s# .# 
# -#  # T# h# e#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # w# e# r# e#  # p# r# o# m# o# t# e# d#  # i# n#  # t# h# e#  # l# a# s# t#  # f# i# v# e#  # y# e# a# r# s#  # a# r# e#  # l# e# s# s#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# a# n#  # t# h# o# s# e#  # w# h# o#  # d# i# d#  # n# o# t#  # g# e# t#  # a#  # p# r# o# m# o# t# i# o# n#  # i# n#  # t# h# e#  # l# a# s# t#  # f# i# v# e#  # y# e# a# r# s# .# 
# 
# N# o# w#  # w# e#  # a# l# s# o#  # w# a# n# t#  # t# o#  # g# e# t#  # a#  # s# o# r# t#  # o# f#  # a# v# e# r# a# g# e#  # f# o# r#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# ;#  # *# *# d# e# p# a# r# t# m# e# n# t# ,#  # s# a# l# a# r# y#  # a# n# d#  # n# u# m# b# e# r# _# o# f# _# p# r# o# j# e# c# t# s# *# *

# In[None]

df.groupby('department').mean()

# In[None]

df.groupby('salary').mean()

# ## ##  # 3#  # V# i# s# u# a# l# i# s# a# t# i# o# n#  # 
# 
# G# e# t#  # b# e# t# t# e# r#  # i# n# s# i# g# h# t#  # i# n# t# o#  # t# h# e#  # d# a# t# a# ,#  # a#  # c# l# e# a# r# e# r#  # p# i# c# t# u# r# e# .#  # R# e# c# o# g# n# i# s# e#  # t# h# e#  # s# i# g# n# i# f# i# c# a# n# t#  # f# e# a# t# u# r# e# s# .# 


# In[None]

# Compute a simple cross-tabulation of two (or more) factors

pd.crosstab(df.department, df.left).plot(kind='bar')
plt.title('Turnover Frequency per Department')
plt.xlabel('Department')
plt.ylabel('0; stayed | 1; left')

# In[None]

table = pd.crosstab(df.salary, df.left)
table.div(table.sum(1).astype(float), axis=0).plot(kind='bar', stacked=True)
plt.title('Turnover Frequency and Salary')
plt.xlabel('Salary')
plt.ylabel('0; stayed | 1; left')

# I# n#  # o# r# d# e# r#  # t# o#  # u# s# e#  # a# l# l#  # t# h# e#  # d# a# t# a#  # f# o# r#  # m# o# d# e# l# l# i# n# g# ,#  # w# e#  # n# e# e# d#  # t# o#  # c# o# n# v# e# r# t#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # t# o#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e# s# .# 
# 
# *# *# D# u# m# m# y#  # v# a# r# i# a# b# l# e# s# *# *# 
# 
# D# u# m# m# y#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # u# s# e# d#  # w# h# e# n#  # y# o# u#  # w# a# n# t#  # t# o#  # w# o# r# k#  # w# i# t# h#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # t# h# a# t#  # h# a# v# e#  # n# o#  # q# u# a# n# t# i# f# i# a# b# l# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # w# i# t# h#  # e# a# c# h#  # o# t# h# e# r# .#  # 
# W# e#  # a# s# s# i# g# n#  # 0#  # t# o#  # e# a# c# h#  # c# a# t# e# g# o# r# y#  # t# h# a# t#  # i# s#  # n# o# t#  # i# t#  # a# n# d#  # 1#  # t# o#  # e# a# c# h#  # c# a# t# e# g# o# r# y#  # t# h# a# t#  # i# t#  # i# s# .#  # W# e#  # s# o# r# t#  # o# f#  # c# o# n# v# e# r# t#  # i# t#  # t# o#  # b# i# n# a# r# y# .# 
# 
# T# h# i# s#  # i# s#  # t# h# e#  # p# r# o# c# e# s# s# :# 
# 
# 1# -#  # c# o# n# v# e# r# t#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # t# o#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e# s# 
# 
# 2# -#  # d# e# l# e# t# e#  # t# h# e#  # o# l# d#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# 
# 


# In[None]

# convert to dummies
cat_vars=['department','salary']

for var in cat_vars:
    cat_list='var'+'_'+ var
    cat_list = pd.get_dummies(df[var], prefix=var) # convert to dummy variables
    df1 = df.join(cat_list)
    df = df1

# In[None]

# remove the old categorical variables
df.drop(df.columns[[8,9]], axis=1, inplace=True)
df.columns.values

# In[None]

# the outcome variable is left (y) all the other variables are predictors

df_vars = df.columns.values.tolist()
y=['left']
X=[i for i in df_vars if i not in y]

# ## ##  # 4#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n# 
# 
# -#  # W# e#  # o# n# l# y#  # w# a# n# t#  # t# o#  # p# i# c# k#  # t# h# e#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # a# r# e#  # t# r# u# l# y#  # r# e# l# e# v# a# n# t#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # y#  # (#  # w# h# e# t# h# e# r#  # s# o# m# e# o# n# e#  # l# e# f# t#  # o# r#  # n# o# t#  # )# 
# -#  # H# o# w#  # d# o#  # w# e#  # s# e# l# e# c# t#  # t# h# e#  # r# i# g# h# t#  # f# e# a# t# u# r# e# s#  # /#  # p# r# e# d# i# c# t# o# r# s# ?# 
# 
# W# e#  # c# a# n#  # u# s# e#  # s# k# .# l# e# a# r# n# '# s#  # `# `# `# s# k# l# e# a# r# n# .# f# e# a# t# u# r# e# _# s# e# l# e# c# t# i# o# n# .# R# F# E#  # `# `# `# 
# 
# G# i# v# e# n#  # a# n#  # e# x# t# e# r# n# a# l#  # e# s# t# i# m# a# t# o# r#  # t# h# a# t#  # a# s# s# i# g# n# s#  # w# e# i# g# h# t# s#  # t# o#  # f# e# a# t# u# r# e# s#  # (# e# .# g# .# ,#  # t# h# e#  # c# o# e# f# f# i# c# i# e# n# t# s#  # o# f#  # a#  # l# i# n# e# a# r#  # m# o# d# e# l# )# ,#  # t# h# e#  # g# o# a# l#  # o# f#  # r# e# c# u# r# s# i# v# e#  # f# e# a# t# u# r# e#  # e# l# i# m# i# n# a# t# i# o# n#  # (# R# F# E# )#  # i# s#  # t# o#  # *# *# s# e# l# e# c# t#  # f# e# a# t# u# r# e# s#  # b# y#  # r# e# c# u# r# s# i# v# e# l# y#  # c# o# n# s# i# d# e# r# i# n# g#  # s# m# a# l# l# e# r#  # a# n# d#  # s# m# a# l# l# e# r#  # s# e# t# s#  # o# f#  # f# e# a# t# u# r# e# s# *# *# .#  # F# i# r# s# t# ,#  # t# h# e#  # e# s# t# i# m# a# t# o# r#  # i# s#  # t# r# a# i# n# e# d#  # o# n#  # t# h# e#  # i# n# i# t# i# a# l#  # s# e# t#  # o# f#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # e# a# c# h#  # f# e# a# t# u# r# e#  # i# s#  # o# b# t# a# i# n# e# d#  # e# i# t# h# e# r#  # t# h# r# o# u# g# h#  # a#  # `# `# `# c# o# e# f# _# `# `# `#  # a# t# t# r# i# b# u# t# e#  # o# r#  # t# h# r# o# u# g# h#  # a#  # `# `# `# f# e# a# t# u# r# e# _# i# m# p# o# r# t# a# n# c# e# s# _# `# `# `#  # a# t# t# r# i# b# u# t# e# .#  # T# h# e# n# ,#  # t# h# e#  # l# e# a# s# t#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # a# r# e#  # p# r# u# n# e# d#  # f# r# o# m#  # c# u# r# r# e# n# t#  # s# e# t#  # o# f#  # f# e# a# t# u# r# e# s# .#  # T# h# a# t#  # p# r# o# c# e# d# u# r# e#  # i# s#  # r# e# c# u# r# s# i# v# e# l# y#  # r# e# p# e# a# t# e# d#  # o# n#  # t# h# e#  # p# r# u# n# e# d#  # s# e# t#  # u# n# t# i# l#  # t# h# e#  # d# e# s# i# r# e# d#  # n# u# m# b# e# r#  # o# f#  # f# e# a# t# u# r# e# s#  # t# o#  # s# e# l# e# c# t#  # i# s#  # e# v# e# n# t# u# a# l# l# y#  # r# e# a# c# h# e# d# .# 
# 
# 
# T# o#  # d# o# :# 
# c# h# e# c# k#  # o# t# h# e# r#  # m# e# t# h# o# d# s#  # f# o# r#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n

# In[None]

from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

model = LogisticRegression()

rfe = RFE(model, 10)
rfe = rfe.fit(df[X], df[y])
print(rfe.support_)
print('the selected features are ranked with 1')
print(rfe.ranking_)

# In[None]

# so these are the columns that we should select
cols = ['satisfaction_level', 'last_evaluation', 'time_spend_company', 'Work_accident', 'promotion_last_5years', 
        'department_hr', 'department_management', 'salary_high', 'salary_low'] 
# the predictors
X = df[cols]

# the outcome 
Y = df['left']

# In[None]

# create a train and a test set
from sklearn.cross_validation import train_test_split

# all lowercase for random forest
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1640848.npy", { "accuracy_score": score })

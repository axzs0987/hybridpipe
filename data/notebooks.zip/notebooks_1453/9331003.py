import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from sklearn.preprocessing import LabelEncoder

# In[None]

df=pd.read_csv('/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

df.info()

# In[None]

pd.DataFrame({'count':df.isnull().sum(),'percentage':df.isnull().sum()/len(df)*100})

# In[None]

df['Churn'].value_counts()

# In[None]

sns.countplot(x='Churn',data=df)

# In[None]

df.drop(['customerID'],axis=1,inplace=True)

# In[None]

df['gender'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='gender',data=df)

# In[None]

df['SeniorCitizen'].unique()

# In[None]

df['SeniorCitizen'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='SeniorCitizen',data=df)

# In[None]

df['Partner'].unique()

# In[None]

df['Partner'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='Partner',data=df)

# In[None]

df['Dependents'].unique()

# In[None]

df['Dependents'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='Dependents',data=df)

# In[None]

df['tenure'].describe()

# In[None]

sns.boxplot(y='tenure',x='Churn',data=df)

# In[None]

sns.boxplot(y='tenure',x='Churn',hue='SeniorCitizen',data=df)

# In[None]

sns.boxplot(y='tenure',x='Churn',hue='Partner',data=df)

# In[None]

sns.boxplot(y='tenure',x='Churn',hue='Dependents',data=df)

# In[None]

df['PhoneService'].unique()

# In[None]

df['PhoneService'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='PhoneService',data=df)

# In[None]

df['MultipleLines'].unique()

# In[None]

df['MultipleLines'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='MultipleLines',data=df)

# In[None]

df['InternetService'].unique()

# In[None]

df['InternetService'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='InternetService',data=df)

# In[None]

df['OnlineSecurity'].unique()

# In[None]

df['OnlineSecurity'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='OnlineSecurity',data=df)

# In[None]

df['OnlineBackup'].unique()

# In[None]

df['OnlineBackup'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='OnlineBackup',data=df)

# In[None]

df['DeviceProtection'].unique()

# In[None]

df['DeviceProtection'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='DeviceProtection',data=df)

# In[None]

df['TechSupport'].unique()

# In[None]

df['TechSupport'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='TechSupport',data=df)

# In[None]

df['StreamingTV'].unique()

# In[None]

df['StreamingTV'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='StreamingTV',data=df)

# In[None]

df['Contract'].unique()

# In[None]

df['Contract'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='Contract',data=df)

# In[None]

df['PaperlessBilling'].unique()

# In[None]

df['PaperlessBilling'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='PaperlessBilling',data=df)

# In[None]

df['PaymentMethod'].unique()

# In[None]

df['PaymentMethod'].value_counts()

# In[None]

sns.countplot(x='Churn',hue='PaymentMethod',data=df)

# In[None]

df['MonthlyCharges'].describe()

# In[None]

sns.boxplot(y='MonthlyCharges',x='Churn',data=df)

# In[None]

target_0 = df.loc[df['Churn'] == 'No']
target_1 = df.loc[df['Churn'] == 'Yes']
sns.distplot(target_0['MonthlyCharges'],hist=False, rug=True)
sns.distplot(target_1['MonthlyCharges'],hist=False, rug=True)
plt.show()

# In[None]

df['TotalCharges']=pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].describe()

# In[None]

sns.boxplot(y='TotalCharges',x='Churn',data=df)

# In[None]

target_0 = df.loc[df['Churn'] == 'No']
target_1 = df.loc[df['Churn'] == 'Yes']
sns.distplot(target_0['TotalCharges'],hist=False, rug=True)
sns.distplot(target_1['TotalCharges'],hist=False, rug=True)
plt.show()

# In[None]

df.drop(['PhoneService','InternetService'],axis=1,inplace=True)

# In[None]

df['MonthlyCharges']=(df['MonthlyCharges']-df['MonthlyCharges'].min())/(df['MonthlyCharges'].max()-df['MonthlyCharges'].min())

df['TotalCharges']=(df['TotalCharges']-df['TotalCharges'].min())/(df['TotalCharges'].max()-df['TotalCharges'].min())

df['tenure']=(df['tenure']-df['tenure'].min())/(df['tenure'].max()-df['tenure'].min())


# In[None]

gle = LabelEncoder()
gender_labels = gle.fit_transform(df['gender'])
gender_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['gender'] = gender_labels

# In[None]

gender_mappings

# In[None]

Partner_labels = gle.fit_transform(df['Partner'])
Partner_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['Partner'] = Partner_labels

# In[None]

Partner_mappings

# In[None]

Dependents_labels = gle.fit_transform(df['Dependents'])
Dependents_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['Dependents'] = Dependents_labels

# In[None]

Dependents_mappings

# In[None]

MultipleLines_labels = gle.fit_transform(df['MultipleLines'])
MultipleLines_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['MultipleLines'] = MultipleLines_labels

# In[None]

MultipleLines_mappings

# In[None]

OnlineSecurity_labels = gle.fit_transform(df['OnlineSecurity'])
OnlineSecurity_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['OnlineSecurity'] = OnlineSecurity_labels

# In[None]

OnlineSecurity_mappings

# In[None]

OnlineBackup_labels = gle.fit_transform(df['OnlineBackup'])
OnlineBackup_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['OnlineBackup'] = OnlineBackup_labels

# In[None]

OnlineBackup_mappings

# In[None]

DeviceProtection_labels = gle.fit_transform(df['DeviceProtection'])
DeviceProtection_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['DeviceProtection'] = DeviceProtection_labels


# In[None]

DeviceProtection_mappings

# In[None]

TechSupport_labels = gle.fit_transform(df['TechSupport'])
TechSupport_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['TechSupport'] = TechSupport_labels

# In[None]

TechSupport_mappings

# In[None]

StreamingTV_labels = gle.fit_transform(df['StreamingTV'])
StreamingTV_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['StreamingTV'] = StreamingTV_labels


# In[None]

StreamingTV_mappings

# In[None]

StreamingMovies_labels = gle.fit_transform(df['StreamingMovies'])
StreamingMovies_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['StreamingMovies'] = StreamingMovies_labels

# In[None]

StreamingMovies_mappings

# In[None]

Contract_labels = gle.fit_transform(df['Contract'])
Contract_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['Contract'] = Contract_labels

# In[None]

Contract_mappings

# In[None]

PaperlessBilling_labels = gle.fit_transform(df['PaperlessBilling'])
PaperlessBilling_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['PaperlessBilling'] = PaperlessBilling_labels

# In[None]

PaperlessBilling_mappings

# In[None]

PaymentMethod_labels = gle.fit_transform(df['PaymentMethod'])
PaymentMethod_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['PaymentMethod'] = PaymentMethod_labels

# In[None]

PaymentMethod_mappings

# In[None]

Churn_labels = gle.fit_transform(df['Churn'])
Churn_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['Churn'] = Churn_labels

# In[None]

Churn_mappings 

# In[None]

SeniorCitizen_labels = gle.fit_transform(df['SeniorCitizen'])
SeniorCitizen_mappings = {index: label for index, label in 
                  enumerate(gle.classes_)}
df['SeniorCitizen'] = SeniorCitizen_labels

# In[None]

SeniorCitizen_mappings

# In[None]

df.describe().T

# In[None]

df1=df.copy()

# In[None]

corr_matrix=df1.corr()
corr_matrix['Churn'].sort_values(ascending=False)

# In[None]

sns.heatmap(corr_matrix, cmap="YlGnBu")

# In[None]

corr_matrix['tenure'].sort_values(ascending=False)

# In[None]

sns.jointplot(x='tenure',y='TotalCharges',data=df,kind="scatter")

# In[None]

sns.jointplot(x='tenure',y='Contract',data=df,kind="scatter")

# In[None]

corr_matrix['TotalCharges'].sort_values(ascending=False)

# In[None]

sns.jointplot(x='TotalCharges',y='MonthlyCharges',data=df,kind="scatter")

# In[None]

df1.drop(['TotalCharges'],axis=1,inplace=True)

# In[None]

sns.heatmap(df1.corr(), cmap="YlGnBu")

# In[None]

x=df1.drop(['Churn'],axis=1)
y=df1['Churn']

# In[None]

from sklearn.neighbors import KNeighborsClassifier

# Import DecisionTreeClassifier from sklearn.tree
from sklearn.tree import DecisionTreeClassifier

# Import RandomForestClassifier
from sklearn.ensemble import RandomForestClassifier

# Import LogisticRegression
from sklearn.linear_model import LogisticRegression

from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import roc_auc_score
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.neural_network import MLPClassifier


# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9331003.npy", { "accuracy_score": score })

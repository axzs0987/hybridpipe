import pandas as pd
# F# o# r# g# e# t#  # a# p# p# l# e# s# .#  # I# n# s# t# e# a# d# ,#  # i# t# '# s#  # a#  # g# l# a# s# s#  # o# f#  # r# e# d#  # w# i# n# e#  # a#  # d# a# y#  # t# h# a# t#  # m# a# y#  # k# e# e# p#  # t# h# e#  # d# o# c# t# o# r#  # a# w# a# y# .#  # S# t# u# d# i# e# s#  # s# h# o# w#  # r# e# d#  # w# i# n# e#  # m# a# y#  # p# r# o# t# e# c# t#  # t# h# e#  # h# e# a# r# t#  # a# n# d#  # c# o# n# t# r# o# l#  # c# h# o# l# e# s# t# e# r# o# l#  # l# e# v# e# l# s# ,#  # a# m# o# n# g#  # o# t# h# e# r#  # b# e# n# e# f# i# t# s# .#  # A# n# d#  # t# h# e# s# e#  # p# r# o# t# e# c# t# i# v# e#  # q# u# a# l# i# t# i# e# s#  # h# a# v# e#  # b# e# e# n#  # m# o# s# t# l# y#  # a# t# t# r# i# b# u# t# e# d#  # t# o#  # t# w# o#  # c# o# m# p# o# n# e# n# t# s#  # i# n#  # r# e# d#  # w# i# n# e# :#  # t# h# e#  # a# l# c# o# h# o# l#  # a# n# d#  # t# h# e#  # g# r# a# p# e# ’# s#  # a# n# t# i# o# x# i# d# a# n# t# s# .# 
# 
# *# *# T# o#  # D# r# i# n# k# ,#  # o# r#  # N# o# t#  # t# o#  # D# r# i# n# k# ?#  # —#  # T# h# e#  # A# n# s# w# e# r# /# D# e# b# a# t# e# *# *# 
# N# o# t#  # a#  # f# a# n#  # o# f#  # r# e# d# ?#  # W# h# i# l# e#  # i# t#  # l# a# c# k# s#  # t# h# e#  # r# e# s# e# r# v# a# t# o# l#  # p# r# e# s# e# n# t#  # i# n#  # r# e# d#  # w# i# n# e# ,#  # w# h# i# t# e#  # w# i# n# e# ,#  # m# i# g# h# t#  # b# e#  # j# u# s# t#  # a# s#  # p# r# o# t# e# c# t# i# v# e#  # o# f#  # t# h# e#  # h# e# a# r# t#  # a# n# d# —#  # e# v# e# n#  # t# h# e#  # l# u# n# g# s#  #  # —#  # a# s#  # l# o# n# g#  # a# s#  # i# t# ’# s#  # r# i# c# h#  # i# n#  # o# t# h# e# r#  # a# n# t# i# o# x# i# d# a# n# t# s#  # l# i# k# e#  # t# y# r# o# s# o# l#  # a# n# d#  # h# y# d# r# o# x# y# t# y# r# o# s# o# l#  # .# 
# 
# B# u# t# ,#  # a# l# a# s# ,#  # a# l# l#  # w# i# n# e# s#  # a# r# e#  # n# o# t#  # c# r# e# a# t# e# d#  # e# q# u# a# l# .#  # D# a# r# k#  # r# e# d#  # w# i# n# e# s#  # m# a# d# e#  # f# r# o# m#  # a#  # g# r# a# p# e#  # w# i# t# h#  # t# h# i# c# k#  # s# k# i# n# ,#  # l# i# k# e#  # M# a# l# b# e# c# ,#  # a# r# e#  # f# u# l# l#  # o# f#  # r# e# s# v# e# r# a# t# r# o# l# .#  # O# t# h# e# r#  # a# n# t# i# o# x# i# d# a# n# t#  # w# i# n# n# e# r# s#  # i# n# c# l# u# d# e#  # C# a# b# e# r# n# e# t#  # S# a# u# v# i# g# n# o# n# ,#  # P# i# n# o# r#  # N# o# i# r# ,#  # a# n# d#  # C# h# a# r# d# o# n# n# a# y#  # .#  # D# o# n# ’# t#  # d# r# i# n# k#  # (# o# r#  # s# i# m# p# l# y#  # c# a# n# ’# t#  # s# t# a# n# d# )#  # e# i# t# h# e# r# ?#  # C# o# n# s# i# d# e# r#  # p# u# r# p# l# e#  # g# r# a# p# e#  # j# u# i# c# e#  # o# r#  # a#  # r# e# s# v# e# r# a# t# r# o# l#  # s# u# p# p# l# e# m# e# n# t#  # t# o#  # r# e# a# p#  # s# i# m# i# l# a# r#  # b# e# n# e# f# i# t# s# .# 
# 
# O# n# e#  # t# h# i# n# g#  # t# o#  # k# e# e# p#  # i# n#  # m# i# n# d# :#  # o# n# e#  # s# e# r# v# i# n# g#  # o# f#  # w# i# n# e#  # i# s#  # o# n# l# y#  # f# i# v# e#  # o# u# n# c# e# s# .#  # D# r# i# n# k# i# n# g#  # t# h# e#  # w# h# o# l# e#  # b# o# t# t# l# e#  # d# o# e# s# n# ’# t#  # d# o# u# b# l# e#  # (# o# r#  # q# u# a# d# r# u# p# l# e# )#  # t# h# e#  # b# e# n# e# f# i# t# s# ,#  # a# n# d#  # d# r# i# n# k# i# n# g#  # t# o# o#  # m# u# c# h#  # c# a# n#  # l# e# a# d#  # t# o#  # c# a# n# c# e# r# s#  # a# n# d#  # o# t# h# e# r#  # d# i# s# e# a# s# e# s# .#  # L# i# k# e#  # a# n# y#  # i# n# d# u# l# g# e# n# c# e# ,#  # m# o# d# e# r# a# t# i# o# n#  # i# s#  # k# e# y# :#  # t# h# e#  # U# S# D# A#  # r# e# c# o# m# m# e# n# d# s#  # n# o#  # m# o# r# e#  # t# h# a# n#  # f# i# v# e#  # o# u# n# c# e# s#  # f# o# r#  # w# o# m# e# n#  # a# n# d#  # t# e# n#  # o# u# n# c# e# s#  # f# o# r#  # m# e# n#  # p# e# r#  # d# a# y# .#  # W# i# t# h#  # t# h# e# s# e#  # l# i# m# i# t# a# t# i# o# n# s#  # i# n#  # m# i# n# d# ,#  # g# o#  # g# r# a# b#  # t# h# a# t#  # g# l# a# s# s# .#  # 
# 
# !# [# i# m# a# g# e# .# p# n# g# ]# (# a# t# t# a# c# h# m# e# n# t# :# i# m# a# g# e# .# p# n# g# )# 


# In[267]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

import os
#print(os.listdir("../input"))

# In[184]

wine = pd.read_csv('../input/winequality-red.csv')

# In[268]

wine.head(3)

# In[186]

wine.info()

# In[187]

wine[wine.isnull()].count()

# *# *# T# h# e#  # d# a# t# a#  # i# s#  # c# l# e# a# n# .# *# *

# *# *# A# c# i# d# i# t# y# *# *# 
# 
# T# h# e#  # a# c# i# d# s#  # i# n#  # w# i# n# e#  # a# r# e#  # a# n#  # i# m# p# o# r# t# a# n# t#  # c# o# m# p# o# n# e# n# t#  # i# n#  # b# o# t# h#  # w# i# n# e# m# a# k# i# n# g#  # a# n# d#  # t# h# e#  # f# i# n# i# s# h# e# d#  # p# r# o# d# u# c# t#  # o# f#  # w# i# n# e# .#  # T# h# e# y#  # a# r# e#  # p# r# e# s# e# n# t#  # i# n#  # b# o# t# h#  # g# r# a# p# e# s#  # a# n# d#  # w# i# n# e# ,#  # h# a# v# i# n# g#  # d# i# r# e# c# t#  # i# n# f# l# u# e# n# c# e# s#  # o# n#  # t# h# e#  # c# o# l# o# r# ,#  # b# a# l# a# n# c# e#  # a# n# d#  # t# a# s# t# e#  # o# f#  # t# h# e#  # w# i# n# e#  # a# s#  # w# e# l# l#  # a# s#  # t# h# e#  # g# r# o# w# t# h#  # a# n# d#  # v# i# t# a# l# i# t# y#  # o# f#  # y# e# a# s# t#  # d# u# r# i# n# g#  # f# e# r# m# e# n# t# a# t# i# o# n#  # a# n# d#  # p# r# o# t# e# c# t# i# n# g#  # t# h# e#  # w# i# n# e#  # f# r# o# m#  # b# a# c# t# e# r# i# a# .#  # 
# 
# T# h# r# e# e#  # p# r# i# m# a# r# y#  # a# c# i# d# s#  # a# r# e#  # f# o# u# n# d#  # i# n#  # w# i# n# e#  # g# r# a# p# e# s# :# *# *#  # t# a# r# t# a# r# i# c# ,#  # m# a# l# i# c#  # a# n# d#  # c# i# t# r# i# c#  # a# c# i# d# s# .# *# *#  # D# u# r# i# n# g#  # t# h# e#  # c# o# u# r# s# e#  # o# f#  # w# i# n# e# m# a# k# i# n# g#  # a# n# d#  # i# n#  # t# h# e#  # f# i# n# i# s# h# e# d#  # w# i# n# e# s# ,#  # a# c# e# t# i# c# ,#  # b# u# t# y# r# i# c# ,#  # l# a# c# t# i# c#  # a# n# d#  # s# u# c# c# i# n# i# c#  # a# c# i# d# s#  # c# a# n#  # p# l# a# y#  # s# i# g# n# i# f# i# c# a# n# t#  # r# o# l# e# s# .#  # M# o# s# t#  # o# f#  # t# h# e#  # a# c# i# d# s#  # i# n# v# o# l# v# e# d#  # w# i# t# h#  # w# i# n# e#  # a# r# e#  # f# i# x# e# d#  # a# c# i# d# s#  # w# i# t# h#  # t# h# e#  # n# o# t# a# b# l# e#  # e# x# c# e# p# t# i# o# n#  # o# f#  # a# c# e# t# i# c#  # a# c# i# d# ,#  # m# o# s# t# l# y#  # f# o# u# n# d#  # i# n#  # v# i# n# e# g# a# r# ,#  # w# h# i# c# h#  # i# s#  # v# o# l# a# t# i# l# e#  # a# n# d#  # c# a# n#  # c# o# n# t# r# i# b# u# t# e#  # t# o#  # t# h# e#  # w# i# n# e#  # f# a# u# l# t#  # k# n# o# w# n#  # a# s#  # v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y# .#  # S# o# m# e# t# i# m# e# s# ,#  # a# d# d# i# t# i# o# n# a# l#  # a# c# i# d# s# ,#  # s# u# c# h#  # a# s#  # a# s# c# o# r# b# i# c# ,#  # s# o# r# b# i# c#  # a# n# d#  # s# u# l# f# u# r# o# u# s#  # a# c# i# d# s# ,#  # a# r# e#  # u# s# e# d#  # i# n#  # w# i# n# e# m# a# k# i# n# g# .

# *# *# C# o# m# p# a# r# i# s# o# n#  # o# f#  # A# c# i# d# i# t# y#  # w# i# t# h#  # Q# u# a# l# i# t# y# *# *

# In[188]

plt.figure(figsize=(10,8))
sns.boxplot(wine['quality'],wine['fixed acidity'])

# T# h# e#  # m# e# a# s# u# r# e#  # o# f#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # a# c# i# d# i# t# y#  # i# n#  # w# i# n# e#  # i# s#  # k# n# o# w# n#  # a# s#  # t# h# e#  # “# t# i# t# r# a# t# a# b# l# e#  # a# c# i# d# i# t# y# ”#  # o# r#  # “# t# o# t# a# l#  # a# c# i# d# i# t# y# ”# ,#  # w# h# i# c# h#  # r# e# f# e# r# s#  # t# o#  # t# h# e#  # t# e# s# t#  # t# h# a# t#  # y# i# e# l# d# s#  # t# h# e#  # t# o# t# a# l#  # o# f#  # a# l# l#  # a# c# i# d# s#  # p# r# e# s# e# n# t# ,#  # *# *# w# h# i# l# e#  # s# t# r# e# n# g# t# h#  # o# f#  # a# c# i# d# i# t# y#  # i# s#  # m# e# a# s# u# r# e# d#  # a# c# c# o# r# d# i# n# g#  # t# o#  # p# H# ,#  # w# i# t# h#  # m# o# s# t#  # w# i# n# e# s#  # h# a# v# i# n# g#  # a#  # p# H#  # b# e# t# w# e# e# n#  # 2# .# 9#  # a# n# d#  # 3# .# 9# *# *# .#  # *# *# G# e# n# e# r# a# l# l# y# ,#  # t# h# e#  # l# o# w# e# r#  # t# h# e#  # p# H# ,#  # t# h# e#  # h# i# g# h# e# r#  # t# h# e#  # a# c# i# d# i# t# y#  # i# n#  # t# h# e#  # w# i# n# e# .# *# *# T# h# i# s#  # c# a# n#  # b# e#  # s# e# e# n#  # i# n#  # t# h# e#  # g# r# a# p# h#  # b# e# l# o# w# .

# In[189]

plt.figure(figsize=(10,8))
plt.scatter(wine['fixed acidity'],wine['pH'])
plt.xlabel('Acidity').set_size(20)
plt.ylabel('pH').set_size(20)

#  # H# o# w# e# v# e# r# ,#  # t# h# e# r# e#  # i# s#  # n# o#  # d# i# r# e# c# t#  # c# o# n# n# e# c# t# i# o# n#  # b# e# t# w# e# e# n#  # t# o# t# a# l#  # a# c# i# d# i# t# y#  # a# n# d#  # p# H#  # (# i# t#  # i# s#  # p# o# s# s# i# b# l# e#  # t# o#  # f# i# n# d#  # w# i# n# e# s#  # w# i# t# h#  # a#  # h# i# g# h#  # p# H#  # f# o# r#  # w# i# n# e#  # a# n# d#  # h# i# g# h#  # a# c# i# d# i# t# y# )# .# [# 1# ]#  # I# n#  # w# i# n# e#  # t# a# s# t# i# n# g# ,#  # *# *# t# h# e#  # t# e# r# m#  # “# a# c# i# d# i# t# y# ”#  # r# e# f# e# r# s#  # t# o#  # t# h# e#  # f# r# e# s# h# ,#  # t# a# r# t#  # a# n# d#  # s# o# u# r#  # a# t# t# r# i# b# u# t# e# s#  # o# f#  # t# h# e#  # w# i# n# e#  # w# h# i# c# h#  # a# r# e#  # e# v# a# l# u# a# t# e# d#  # i# n#  # r# e# l# a# t# i# o# n#  # t# o#  # h# o# w#  # w# e# l# l#  # t# h# e#  # a# c# i# d# i# t# y#  # b# a# l# a# n# c# e# s#  # o# u# t#  # t# h# e#  # s# w# e# e# t# n# e# s# s#  # a# n# d#  # b# i# t# t# e# r#  # c# o# m# p# o# n# e# n# t# s#  # o# f#  # t# h# e#  # w# i# n# e#  # s# u# c# h#  # a# s#  # t# a# n# n# i# n# s# .# *# *#  

# *# *# A# c# i# d# i# t# y#  # i# n#  # w# i# n# e#  # i# s#  # i# m# p# o# r# t# a# n# t# .# *# *# 
# 
# *# *# A# s#  # m# u# c# h#  # a# s#  # m# o# d# e# r# n#  # h# e# a# l# t# h#  # h# a# s#  # d# e# m# o# n# i# z# e# d#  # a# c# i# d# i# c#  # f# o# o# d# s# ,#  # a# c# i# d# i# t# y#  # i# s#  # a# n#  # e# s# s# e# n# t# i# a# l#  # t# r# a# i# t#  # i# n#  # w# i# n# e#  # t# h# a# t# ’# s#  # n# e# c# e# s# s# a# r# y#  # f# o# r#  # q# u# a# l# i# t# y# .# *# *#  # G# r# e# a# t#  # w# i# n# e# s#  # a# r# e#  # i# n#  # b# a# l# a# n# c# e#  # w# i# t# h#  # t# h# e# i# r#  # 4#  # f# u# n# d# a# m# e# n# t# a# l#  # t# r# a# i# t# s#  # (# A# c# i# d# i# t# y# ,#  # t# a# n# n# i# n# ,#  # a# l# c# o# h# o# l#  # a# n# d#  # s# w# e# e# t# n# e# s# s# )#  # a# n# d#  # a# s#  # w# i# n# e# s#  # a# g# e# ,#  # t# h# e#  # a# c# i# d# i# t# y#  # a# c# t# s#  # a# s#  # a#  # b# u# f# f# e# r#  # t# o#  # p# r# e# s# e# r# v# e#  # t# h# e#  # w# i# n# e#  # l# o# n# g# e# r# .#  # F# o# r#  # e# x# a# m# p# l# e# ,#  # S# a# u# t# e# r# n# e# s# ,#  # a#  # w# i# n# e#  # w# i# t# h#  # b# o# t# h#  # h# i# g# h#  # a# c# i# d# i# t# y#  # a# n# d#  # s# w# e# e# t# n# e# s# s# ,#  # i# s#  # k# n# o# w# n#  # t# o#  # a# g# e#  # s# e# v# e# r# a# l#  # d# e# c# a# d# e# s# .# 
# 
# L# e# t#  # u# s#  # s# e# e#  # i# f#  # p# H# /# A# c# i# d# i# t# y#  # i# s#  # r# e# l# a# t# e# d#  # t# o#  # t# h# e#  # o# v# e# r# a# l#  # q# u# a# l# i# t# y#  # r# a# t# i# n# g# .

# In[190]

plt.figure(figsize=(10,8))
sns.pointplot(wine['quality'],wine['pH'], color='grey')
plt.xlabel('Quality').set_size(20)
plt.ylabel('pH').set_size(20)

# *# *# W# e#  # c# a# n#  # i# n# f# e# r#  # t# h# a# t#  # h# i# g# h# e# r#  # q# u# a# l# i# t# y#  # w# i# n# e# s#  # h# a# v# e#  # a#  # c# o# m# p# a# r# a# t# i# v# e# l# y#  # l# o# w#  # p# H# /# h# i# g# h#  # A# c# i# d# i# t# y# *# *

# *# *# C# i# t# r# i# c#  # A# c# i# d# *# *# 
# 
# W# h# i# l# e#  # v# e# r# y#  # c# o# m# m# o# n#  # i# n#  # c# i# t# r# u# s#  # f# r# u# i# t# s# ,#  # s# u# c# h#  # a# s#  # l# i# m# e# s# ,#  # c# i# t# r# i# c#  # a# c# i# d#  # i# s#  # f# o# u# n# d#  # o# n# l# y#  # i# n#  # v# e# r# y#  # m# i# n# u# t# e#  # q# u# a# n# t# i# t# i# e# s#  # i# n#  # w# i# n# e#  # g# r# a# p# e# s# .#  # I# t#  # o# f# t# e# n#  # h# a# s#  # a#  # c# o# n# c# e# n# t# r# a# t# i# o# n#  # a# b# o# u# t#  # 1# /# 2# 0#  # t# h# a# t#  # o# f#  # t# a# r# t# a# r# i# c#  # a# c# i# d# .#  # T# h# e#  # c# i# t# r# i# c#  # a# c# i# d#  # m# o# s# t#  # c# o# m# m# o# n# l# y#  # f# o# u# n# d#  # i# n#  # w# i# n# e#  # i# s#  # c# o# m# m# e# r# c# i# a# l# l# y#  # p# r# o# d# u# c# e# d#  # a# c# i# d#  # s# u# p# p# l# e# m# e# n# t# s#  # d# e# r# i# v# e# d#  # f# r# o# m#  # f# e# r# m# e# n# t# i# n# g#  # s# u# c# r# o# s# e#  # s# o# l# u# t# i# o# n# s# .#  # 
# 
# T# h# e# s# e#  # i# n# e# x# p# e# n# s# i# v# e#  # s# u# p# p# l# e# m# e# n# t# s#  # c# a# n#  # b# e#  # u# s# e# d#  # b# y#  # w# i# n# e# m# a# k# e# r# s#  # i# n#  # a# c# i# d# i# f# i# c# a# t# i# o# n#  # t# o#  # b# o# o# s# t#  # t# h# e#  # w# i# n# e# '# s#  # t# o# t# a# l#  # a# c# i# d# i# t# y# .#  # I# t#  # i# s#  # u# s# e# d#  # l# e# s# s#  # f# r# e# q# u# e# n# t# l# y#  # t# h# a# n#  # t# a# r# t# a# r# i# c#  # a# n# d#  # m# a# l# i# c#  # d# u# e#  # t# o#  # t# h# e#  # a# g# g# r# e# s# s# i# v# e#  # c# i# t# r# i# c#  # f# l# a# v# o# r# s#  # i# t#  # c# a# n#  # a# d# d#  # t# o#  # t# h# e#  # w# i# n# e# .#  # W# h# e# n#  # c# i# t# r# i# c#  # a# c# i# d#  # i# s#  # a# d# d# e# d# ,#  # i# t#  # i# s#  # a# l# w# a# y# s#  # d# o# n# e#  # a# f# t# e# r#  # p# r# i# m# a# r# y#  # a# l# c# o# h# o# l#  # f# e# r# m# e# n# t# a# t# i# o# n#  # h# a# s#  # b# e# e# n#  # c# o# m# p# l# e# t# e# d#  # d# u# e#  # t# o#  # t# h# e#  # t# e# n# d# e# n# c# y#  # o# f#  # y# e# a# s# t#  # t# o#  # c# o# n# v# e# r# t#  # c# i# t# r# i# c#  # i# n# t# o#  # a# c# e# t# i# c#  # a# c# i# d# .#  # 
# 
# *# *# I# n#  # t# h# e#  # E# u# r# o# p# e# a# n#  # U# n# i# o# n# ,#  # u# s# e#  # o# f#  # c# i# t# r# i# c#  # a# c# i# d#  # f# o# r#  # a# c# i# d# i# f# i# c# a# t# i# o# n#  # i# s#  # p# r# o# h# i# b# i# t# e# d# ,#  # b# u# t#  # l# i# m# i# t# e# d#  # u# s# e#  # o# f#  # c# i# t# r# i# c#  # a# c# i# d#  # i# s#  # p# e# r# m# i# t# t# e# d#  # f# o# r#  # r# e# m# o# v# i# n# g#  # e# x# c# e# s# s#  # i# r# o# n#  # a# n# d#  # c# o# p# p# e# r#  # f# r# o# m#  # t# h# e#  # w# i# n# e#  # i# f#  # p# o# t# a# s# s# i# u# m#  # f# e# r# r# o# c# y# a# n# i# d# e#  # i# s#  # n# o# t#  # a# v# a# i# l# a# b# l# e# .# *# *

# In[191]

plt.figure(figsize=(10,8))
sns.countplot(wine['citric acid'] > 0)
plt.xlabel('Citric Acid Content').set_size(20)
plt.ylabel('Count').set_size(20)

# *# *# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h# ,#  # w# e#  # c# a# n#  # i# n# f# e# r#  # t# h# a# t#  # a# p# p# r# o# x# i# m# a# t# e# l# y#  # 1# 8# 0# -# 2# 0# 0#  # w# i# n# e# s#  # a# r# e#  # E# u# r# o# p# e# a# n# .# *# *

# *# *#  # S# u# l# f# u# r#  # D# i# o# x# i# d# e#  # *# *# 
# 
# S# u# l# f# u# r#  # d# i# o# x# i# d# e#  # p# l# a# y# s#  # t# w# o#  # i# m# p# o# r# t# a# n# t#  # r# o# l# e# s# .#  # F# i# r# s# t# l# y# ,#  # i# t#  # i# s#  # a# n#  # a# n# t# i# -# m# i# c# r# o# b# i# a# l#  # a# g# e# n# t# ,#  # a# n# d#  # a# s#  # s# u# c# h#  # i# s#  # u# s# e# d#  # t# o#  # h# e# l# p#  # c# u# r# t# a# i# l#  # t# h# e#  # g# r# o# w# t# h#  # o# f#  # u# n# d# e# s# i# r# a# b# l# e#  # f# a# u# l# t#  # p# r# o# d# u# c# i# n# g#  # y# e# a# s# t# s#  # a# n# d#  # b# a# c# t# e# r# i# a# .#  # S# e# c# o# n# d# l# y# ,#  # i# t#  # a# c# t# s#  # a# s#  # a# n#  # a# n# t# i# o# x# i# d# a# n# t# ,#  # s# a# f# e# g# u# a# r# d# i# n# g#  # t# h# e#  # w# i# n# e# '# s#  # f# r# u# i# t#  # i# n# t# e# g# r# i# t# y#  # a# n# d#  # p# r# o# t# e# c# t# i# n# g#  # i# t#  # a# g# a# i# n# s# t#  # b# r# o# w# n# i# n# g# .# 
# 
# D# e# s# p# i# t# e#  # i# t# s#  # c# h# e# m# i# c# a# l#  # s# i# m# p# l# i# c# i# t# y# ,#  # S# O# 2#  # c# a# n#  # t# a# k# e#  # o# n#  # a#  # f# e# w#  # d# i# f# f# e# r# e# n# t#  # f# o# r# m# s#  # i# n#  # a#  # w# i# n# e# .#  # O# n# e#  # f# o# r# m#  # i# s#  # c# a# l# l# e# d#  # '# m# o# l# e# c# u# l# a# r#  # S# O# 2# '# .#  # W# h# e# n#  # i# n#  # t# h# i# s#  # f# o# r# m# ,#  # i# t#  # i# s#  # a# r# o# u# n# d#  # 5# 0# 0#  # t# i# m# e# s#  # m# o# r# e#  # e# f# f# e# c# t# i# v# e#  # i# n#  # k# i# l# l# i# n# g#  # w# i# n# e#  # m# i# c# r# o# b# e# s#  # t# h# a# n#  # w# h# e# n#  # i# n#  # a# n# y#  # o# f#  # t# h# e#  # o# t# h# e# r#  # f# o# r# m# s#  # t# h# a# t#  # i# t#  # c# a# n#  # t# a# k# e#  # (# S# n# e# y# d#  # e# t#  # a# l# .#  # 1# 9# 9# 2# )# .#  # L# u# c# k# i# l# y#  # f# o# r#  # u# s# ,#  # t# h# e#  # d# e# s# i# r# a# b# l# e#  # y# e# a# s# t# s#  # t# h# a# t#  # u# n# d# e# r# t# a# k# e#  # w# i# n# e#  # f# e# r# m# e# n# t# a# t# i# o# n#  # a# r# e#  # m# o# r# e#  # r# e# s# i# s# t# a# n# t#  # t# o#  # S# O# 2#  # t# h# a# n#  # m# o# s# t#  # o# f#  # t# h# e#  # s# p# o# i# l# a# g# e#  # y# e# a# s# t# s# .#  # *# *# S# o#  # h# a# v# i# n# g#  # s# o# m# e#  # S# O# 2#  # a# r# o# u# n# d#  # h# e# l# p# s#  # g# i# v# e#  # t# h# e#  # d# e# s# i# r# a# b# l# e#  # b# u# g# s#  # a#  # l# e# g# -# u# p#  # i# n#  # t# h# e# i# r#  # c# o# m# p# e# t# i# t# i# v# e#  # d# o# g#  # e# a# t#  # d# o# g#  # w# o# r# l# d#  # i# n#  # w# h# i# c# h#  # t# h# e# y#  # c# o# -# e# x# i# s# t# .# *# *# 
#  # 
# M# a# n# y#  # w# o# u# l# d#  # b# e#  # a# w# a# r# e#  # t# h# a# t#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e#  # c# a# n#  # c# a# u# s# e#  # s# e# v# e# r# e#  # a# l# l# e# r# g# i# c#  # r# e# a# c# t# i# o# n# s#  # i# n#  # s# o# m# e#  # p# e# o# p# l# e# .#  # S# o#  # w# h# y#  # d# o#  # w# i# n# e# m# a# k# e# r# s#  # u# s# e#  # i# t# ?#  # P# u# t#  # s# i# m# p# l# y# ,# *# *#  # i# t#  # i# s#  # v# e# r# y#  # d# i# f# f# i# c# u# l# t#  # t# o#  # m# a# k# e#  # w# i# n# e# s#  # t# h# a# t#  # h# a# v# e#  # a# n#  # a# g# i# n# g#  # p# o# t# e# n# t# i# a# l#  # b# e# y# o# n# d#  # a#  # f# e# w#  # m# o# n# t# h# s#  # i# f#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e#  # i# s#  # n# o# t#  # u# s# e# d#  # d# u# r# i# n# g#  # w# i# n# e# m# a# k# i# n# g# .#  # A#  # b# i# g#  # s# t# a# t# e# m# e# n# t#  # b# u# t#  # t# r# u# e# .# *# *

# In[192]

plt.figure(figsize=(10,8))
sns.barplot(wine['quality'],wine['total sulfur dioxide'])
plt.xlabel('Quality').set_size(20)
plt.ylabel('Total Sulfur Dioxide').set_size(20)

# *# *# R# e# s# i# d# u# a# l#  # S# u# g# a# r# *# *# 
# 
# R# e# s# i# d# u# a# l#  # S# u# g# a# r# ,#  # o# r#  # R# S#  # f# o# r#  # s# h# o# r# t# ,#  # r# e# f# e# r# s#  # t# o#  # a# n# y#  # n# a# t# u# r# a# l#  # g# r# a# p# e#  # s# u# g# a# r# s#  # t# h# a# t#  # a# r# e#  # l# e# f# t# o# v# e# r#  # a# f# t# e# r#  # f# e# r# m# e# n# t# a# t# i# o# n#  # c# e# a# s# e# s#  # (# w# h# e# t# h# e# r#  # o# n#  # p# u# r# p# o# s# e#  # o# r#  # n# o# t# )# .#  # T# h# e#  # j# u# i# c# e#  # o# f#  # w# i# n# e#  # g# r# a# p# e# s#  # s# t# a# r# t# s#  # o# u# t#  # i# n# t# e# n# s# e# l# y#  # s# w# e# e# t# ,#  # a# n# d#  # f# e# r# m# e# n# t# a# t# i# o# n#  # u# s# e# s#  # u# p#  # t# h# a# t#  # s# u# g# a# r#  # a# s#  # t# h# e#  # y# e# a# s# t# s#  # f# e# a# s# t#  # u# p# o# n#  # i# t# .#  # T# h# e#  # b# y# -# p# r# o# d# u# c# t# s#  # a# r# e#  # b# u# b# b# l# y#  # C# O# 2#  # g# a# s#  # a# n# d#  # o# u# r#  # a# d# o# r# a# b# l# e#  # a# m# i# g# o# ,#  # a# l# c# o# h# o# l# .# 
# 
# T# h# e# r# e#  # a# r# e#  # m# a# n# y#  # r# e# a# s# o# n# s#  # w# h# y#  # f# e# r# m# e# n# t# a# t# i# o# n#  # m# i# g# h# t#  # s# t# o# p# .#  # T# h# e#  # a# g# e# -# o# l# d#  # m# e# t# h# o# d#  # h# a# s#  # t# o#  # d# o#  # w# i# t# h#  # a# l# c# o# h# o# l#  # t# o# x# i# c# i# t# y# .#  # D# i# f# f# e# r# e# n# t#  # y# e# a# s# t#  # s# t# r# a# i# n# s#  # c# a# n#  # t# o# l# e# r# a# t# e#  # d# i# f# f# e# r# e# n# t#  # l# e# v# e# l# s#  # o# f#  # a# l# c# o# h# o# l# ,#  # s# o#  # a#  # w# e# a# k# e# r#  # s# t# r# a# i# n#  # m# i# g# h# t#  # d# i# e#  # b# e# f# o# r# e#  # e# a# t# i# n# g#  # a# l# l#  # t# h# e#  # s# u# g# a# r#  # i# n#  # t# h# e#  # f# e# r# m# e# n# t# i# n# g#  # w# i# n# e# .#  # I# n#  # t# h# e#  # c# a# s# e#  # o# f#  # a#  # d# e# s# s# e# r# t#  # w# i# n# e#  # l# i# k# e#  # S# a# u# t# e# r# n# e# s#  # o# r#  # i# c# e#  # w# i# n# e# ,#  # t# h# e#  # s# u# g# a# r# s#  # a# r# e#  # c# o# n# c# e# n# t# r# a# t# e# d#  # w# h# e# n#  # t# h# e#  # g# r# a# p# e# s#  # g# e# t#  # s# h# r# i# v# e# l# e# d# ,#  # s# o#  # t# h# e# r# e# '# s#  # a#  # l# o# t#  # o# f#  # s# u# g# a# r#  # t# o#  # f# e# r# m# e# n# t# .#  # W# h# e# n#  # a# l# c# o# h# o# l#  # r# e# a# c# h# e# s#  # t# h# e#  # l# e# v# e# l#  # o# f#  # a#  # n# o# r# m# a# l#  # d# r# y#  # w# i# n# e# ,#  # s# a# y#  # 1# 2#  # o# r#  # 1# 4# %# ,#  # t# h# e#  # y# e# a# s# t#  # m# i# g# h# t#  # d# i# e# ,#  # b# u# t#  # p# l# e# n# t# y#  # o# f#  # u# n# e# a# t# e# n#  # s# u# g# a# r#  # i# s#  # l# e# f# t# .#  # I# n#  # t# h# e#  # c# a# s# e#  # o# f#  # a#  # f# o# r# t# i# f# i# e# d#  # w# i# n# e# ,#  # h# a# r# d#  # b# o# o# z# e#  # i# s#  # a# d# d# e# d#  # t# o#  # g# e# t#  # a#  # s# i# m# i# l# a# r#  # j# o# b#  # d# o# n# e# .# 
# 
# *# *# I# n#  # a# d# d# i# t# i# o# n#  # t# o#  # i# t# s#  # o# b# v# i# o# u# s#  # s# w# e# e# t# e# n# i# n# g#  # p# o# w# e# r# ,#  # s# u# g# a# r#  # a# l# s# o#  # h# a# s#  # a#  # b# o# n# u# s#  # e# f# f# e# c# t# :#  # i# t#  # c# a# n#  # h# e# l# p#  # w# i# n# e# s#  # a# g# e#  # w# e# l# l# .# *# *#  # I# f#  # y# o# u#  # c# a# n#  # g# o#  # t# h# e#  # l# o# n# g#  # h# a# u# l# ,#  # s# a# y# ,#  # a#  # d# e# c# a# d# e#  # (# o# r#  # t# w# o# ,#  # o# r#  # t# h# r# e# e# )# ,#  # t# h# e#  # R# S#  # c# a# n#  # b# r# i# n# g#  # d# e# e# p#  # d# i# v# i# d# e# n# d# s# .#  # W# e# '# v# e#  # t# a# l# k# e# d#  # a#  # l# i# t# t# l# e#  # a# b# o# u# t#  # w# h# i# c# h#  # w# i# n# e# s#  # a# g# e#  # w# e# l# l# :# *# *#  # t# h# o# s# e#  # w# i# t# h#  # a#  # l# i# t# t# l# e#  # R# S#  # c# a# n#  # b# e#  # t# h# e#  # m# o# s# t#  # e# x# c# i# t# i# n# g#  # t# o#  # t# a# s# t# e#  # a# s#  # t# h# e# y#  # e# v# o# l# v# e#  # o# v# e# r#  # t# i# m# e# .#  # *# *# T# h# e#  # s# u# g# a# r#  # c# o# m# p# o# u# n# d# s#  # c# h# a# n# g# e#  # s# h# a# p# e# ,#  # a# n# d#  # w# e#  # p# e# r# c# e# i# v# e#  # t# h# e# m#  # l# e# s# s#  # d# i# r# e# c# t# l# y# ,#  # s# o#  # t# h# e#  # w# i# n# e# s#  # e# v# e# n#  # s# e# e# m#  # t# o#  # d# r# y#  # o# u# t#  # a#  # b# i# t# .# 
# 
# *# *# W# h# e# t# h# e# r#  # y# o# u# r#  # b# o# t# t# l# e#  # i# s#  # y# o# u# n# g#  # o# r#  # e# l# d# e# r# l# y# ,#  # y# o# u#  # s# h# o# u# l# d#  # t# h# i# n# k#  # o# f#  # R# S#  # a# s#  # h# a# v# i# n# g#  # a#  # b# a# l# a# n# c# i# n# g#  # r# e# l# a# t# i# o# n# s# h# i# p#  # w# i# t# h#  # a# c# i# d# i# t# y# .# *# *#  # T# h# e# y#  # a# r# e#  # o# n#  # o# p# p# o# s# i# t# e#  # s# i# d# e# s#  # o# f#  # t# h# e#  # s# e# e# s# a# w# ,#  # s# o#  # i# f#  # t# h# e#  # w# i# n# e#  # h# a# s#  # s# u# g# a# r#  # y# o# u#  # w# i# l# l#  # p# r# o# b# a# b# l# y#  # w# a# n# t#  # s# t# r# o# n# g#  # a# c# i# d# i# t# y# ,#  # t# o# o# —# o# t# h# e# r# w# i# s# e#  # t# h# e#  # w# i# n# e#  # w# i# l# l#  # f# e# e# l#  # c# l# o# y# i# n# g# .#  # 
# 
# *# *# T# h# i# s#  # f# a# c# t#  # c# a# n#  # b# e#  # p# r# o# v# e# n#  # b# e# l# o# w# .# *# *# 


# In[193]

plt.figure(figsize=(10,8))
sns.pointplot(wine['pH'].round(1),wine['residual sugar'], color='green')
plt.xlabel('pH').set_size(15)
plt.ylabel('Residual Sugar').set_size(15)

# *# *# F# r# o# m#  # t# h# e#  # g# r# a# p# h# ,#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # l# o# w#  # l# e# v# e# l# s#  # o# f#  # p# H# (# H# i# g# h#  # A# c# i# d# i# t# y# )#  # h# a# v# e#  # h# i# g# h#  # l# e# v# e# l# s#  # o# f#  # S# u# g# a# r# .# *# *

# *# *# C# h# l# o# r# i# d# e# *# *# 
# 
# I# n#  # e# v# e# r# y#  # v# i# n# e# y# a# r# d# ,#  # a#  # u# n# i# q# u# e#  # c# o# m# b# i# n# a# t# i# o# n#  # o# f#  # c# l# i# m# a# t# e# ,#  # t# o# p# o# g# r# a# p# h# y#  # a# n# d#  # s# o# i# l# ,#  # k# n# o# w# n#  # a# s#  # t# e# r# r# o# i# r# ,#  # s# h# a# p# e# s#  # t# h# e#  # c# h# a# r# a# c# t# e# r#  # o# f#  # t# h# e#  # v# i# n# e# s#  # a# n# d#  # t# h# e#  # g# r# a# p# e# s#  # t# h# e# y#  # y# i# e# l# d# .#  # T# y# p# i# c# i# t# y#  # a# n# d#  # q# u# a# l# i# t# y#  # o# f#  # t# h# e#  # w# i# n# e# s#  # a# r# e#  # d# e# t# e# r# m# i# n# e# d#  # b# y#  # t# h# e#  # t# e# r# r# o# i# r#  # t# h# a# t#  # h# o# u# s# e# s#  # t# h# e#  # v# i# n# e# y# a# r# d# .#  # S# u# c# h#  # t# y# p# i# c# i# t# y#  # i# s#  # d# u# e#  # t# o#  # t# h# e#  # c# o# m# p# l# e# x# i# t# y#  # o# f#  # i# t# s#  # c# o# m# p# o# s# i# t# i# o# n# .#  # 
# 
# A# m# o# n# g#  # t# h# e#  # m# a# i# n#  # f# a# c# t# o# r# s#  # i# n# t# e# r# f# e# r# i# n# g#  # w# i# t# h#  # t# h# e#  # t# y# p# i# c# i# t# y#  # o# f#  # w# i# n# e# s#  # a# r# e#  # g# r# a# p# e#  # v# a# r# i# e# t# y# ,#  # r# e# g# i# o# n#  # o# f#  # o# r# i# g# i# n# ,#  # v# i# n# t# a# g# e# ,#  # c# u# l# t# u# r# a# l#  # t# r# a# i# t# s#  # a# n# d#  # e# l# a# b# o# r# a# t# i# o# n#  # m# e# t# h# o# d# s# .#  # T# h# u# s# ,#  # b# y#  # c# o# m# b# i# n# i# n# g#  # t# h# e# s# e#  # d# i# s# t# i# n# c# t# i# v# e#  # f# a# c# t# o# r# s# ,#  # *# *# s# e# v# e# r# a# l#  # d# i# f# f# e# r# e# n# t#  # w# i# n# e# s#  # c# a# n#  # b# e#  # c# r# e# a# t# e# d# ,#  # e# a# c# h#  # o# n# e#  # o# f#  # t# h# e# m#  # w# i# t# h#  # i# t# s#  # o# w# n#  # u# n# i# q# u# e#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s# .# *# *# 
# 
# *# *# A# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e#  # f# i# n# d# i# n# g# s# ,#  # A# u# s# t# r# a# l# i# a#  # w# i# n# e# s#  # h# a# v# e#  # t# h# e#  # h# i# g# h# e# s# t#  # l# e# v# e# l# s#  # o# f#  # c# h# l# o# r# i# d# e# s# ,#  # f# o# l# l# o# w# e# d#  # b# y#  # A# r# g# e# n# t# i# n# e# a# n#  # w# i# n# e# s# ,#  # a#  # c# o# u# n# t# r# y#  # t# h# a# t#  # b# e# a# r# s#  # t# h# e#  # s# e# c# o# n# d#  # p# o# s# i# t# i# o# n#  # f# o# r#  # t# h# e#  # c# o# n# c# e# n# t# r# a# t# i# o# n#  # l# e# v# e# l# s#  # o# f#  # s# u# c# h#  # i# o# n# .#  # *# *# 
# 
# *# *# D# i# f# f# e# r# e# n# c# e# s#  # i# n#  # t# h# e#  # p# h# y# s# i# c# o# c# h# e# m# i# c# a# l#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # o# f#  # w# i# n# e# s#  # m# a# y#  # b# e#  # d# u# e#  # t# o#  # s# e# v# e# r# a# l#  # f# a# c# t# o# r# s# .#  # A# l# l#  # o# f#  # t# h# e# m#  # a# r# e#  # r# e# l# a# t# e# d#  # t# o#  # s# o# i# l#  # a# n# d#  # c# l# i# m# a# t# e#  # c# o# n# d# i# t# i# o# n# s# ,#  # a# s#  # w# e# l# l#  # a# s#  # t# o#  # o# e# n# o# l# o# g# i# c# a# l#  # p# r# a# c# t# i# c# e# s#  # u# s# e# d#  # d# u# r# i# n# g#  # m# a# t# u# r# a# t# i# o# n#  # o# f#  # t# h# e#  # g# r# a# p# e# s#  # a# n# d#  # v# i# n# i# f# i# c# a# t# i# o# n#  # p# r# o# c# e# s# s# .# *# *# 
# 
#  # T# h# e#  # a# m# o# u# n# t#  # o# f#  # c# h# l# o# r# i# d# e#  # i# n#  # w# i# n# e#  # i# s#  # i# n# f# l# u# e# n# c# e# d#  # b# y#  # b# o# t# h#  # t# h# e#  # t# e# r# r# o# i# r#  # a# n# d#  # t# y# p# e#  # o# f#  # g# r# a# p# e# ,#  # a# n# d#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # q# u# a# n# t# i# f# i# c# a# t# i# o# n#  # l# i# e# s#  # i# n#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # w# i# n# e#  # f# l# a# v# o# r#  # i# s#  # s# t# r# o# n# g# l# y#  # i# m# p# a# c# t# e# d#  # b# y#  # t# h# i# s#  # p# a# r# t# i# c# u# l# a# r#  # i# o# n# ,#  # w# h# i# c# h# ,#  # i# n#  # h# i# g# h#  # c# o# n# c# e# n# t# r# a# t# i# o# n# ,#  # g# i# v# e# s#  # t# h# e#  # w# i# n# e#  # a# n#  # u# n# d# e# s# i# r# a# b# l# e#  # s# a# l# t# y#  # t# a# s# t# e#  # a# n# d#  # s# i# g# n# i# f# i# c# a# n# t# l# y#  # d# e# c# r# e# a# s# e# s#  # i# t# s#  # m# a# r# k# e# t#  # a# p# p# e# a# l# .

# In[194]

plt.figure(figsize=(20,8))
sns.countplot(x=wine['chlorides'].round(2))
plt.xlabel('Chlorides').set_size(15)
plt.ylabel('Count').set_size(15)

# *# *# R# e# d#  # W# i# n# e#  # Q# u# a# l# i# t# y#  # P# r# e# d# i# c# t# i# o# n# *# *

# In[195]

from sklearn.model_selection import train_test_split
from sklearn import metrics

# F# e# a# t# u# r# e#  # S# c# a# l# i# n# g

# In[196]

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

# In[197]

scaler.fit(wine.drop(['quality'],axis=1))
scaled_feat = scaler.transform(wine.drop(['quality'],axis=1))
wine_scaled = pd.DataFrame(scaled_feat,columns=wine.columns[:-1])

# *# *# 1# .#  # P# r# e# d# i# c# t# i# o# n#  # w# i# t# h# o# u# t#  # a# r# b# i# t# r# a# r# y#  # c# u# t# -# o# f# f#  # f# o# r#  # Q# u# a# l# i# t# y# (# D# e# p# e# n# d# e# n# t#  # V# a# r# i# a# b# l# e# )# *# *

# *# *# 1# .# 1#  # U# s# i# n# g#  # T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# (# H# o# l# d#  # O# u# t#  # M# e# t# h# o# d# )# *# *

# *# *# 1# .# 1# .# 1#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# *# *

# In[198]

from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()

# In[199]

X = wine_scaled
y = wine['quality']

# In[200]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/985414.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
breast_cancer=pd.read_csv('../input/Breast_cancer_data.csv')
breast_cancer.tail()
x=breast_cancer.iloc[:,0:5]
y=breast_cancer.iloc[:,5:]
from sklearn.tree import DecisionTreeClassifier
dtc=DecisionTreeClassifier(max_features=3,criterion="entropy")
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test=train_test_split(x,y,test_size=0.20,random_state=1999)
#dtc.fit(x_train,y_train)
#ypr=dtc.predict(x_test)
from sklearn.metrics import confusion_matrix,accuracy_score
#print(accuracy_score(y_test,ypr))
#print(confusion_matrix(y_test,ypr))
#dtc.tree_.compute_feature_importances()
breast_cancer.tail()
reducted=breast_cancer.iloc[:,2:5]
del reducted["mean_area"]
from sklearn.svm import SVC
svm=SVC()
#svm.fit(x_train,y_train)
#ypr=svm.predict(x_test)
from sklearn.metrics import confusion_matrix,accuracy_score
#print(accuracy_score(y_test,ypr))
#print(confusion_matrix(y_test,ypr))
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(reducted, y, train_size=0.8, test_size=1-0.8, random_state=0)
svm=SVC()
#svm.fit(x_train,y_train)
#ypr=svm.predict(x_test)
from sklearn.metrics import confusion_matrix,accuracy_score
#print(accuracy_score(y_test,ypr))
#print(confusion_matrix(y_test,ypr))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_dimensionreductionwithdecisiontree.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_dimensionreductionwithdecisiontree/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

winequality = pd.read_csv("../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")

# ##  # *# D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# *

# L# e# t# s#  # h# a# v# e#  # a#  # l# o# o# k#  # a# t#  # t# o# p#  # 5#  # c# o# l# u# m# n# s#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t

# In[None]

winequality.head()

# N# o# w#  # l# e# t# s#  # s# e# e#  # i# f#  # t# h# e# r# e#  # i# s#  # a# n# y#  # m# i# s# s# i# n# g#  # d# a# t# a#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t# .#  # T# h# i# s#  # s# t# e# p#  # i# s#  # c# r# u# c# i# a# l#  # i# n#  # a# n# y#  # d# a# t# a#  # a# n# a# l# y# s# i# s# .#  # N# o# t#  # h# a# v# i# n# g#  # m# a# n# y#  # v# a# l# u# e# s#  # f# o# r#  # a# n# y#  # f# e# a# t# u# r# e#  # m# i# g# h# t#  # m# a# k# e#  # o# u# r#  # a# s# s# u# m# p# t# i# o# n# s#  # t# o# t# a# l# l# y#  # w# r# o# n# g# .#  # A# n# d#  # w# e#  # d# o#  # n# o# t#  # w# a# n# t#  # t# o#  # t# a# k# e#  # a# n# y#  # r# i# s# k#  # w# i# t# h#  # W# i# n# e# .#  # D# o#  # w# e# ?

# In[None]

winequality.info()

# W# e#  # c# a# n#  # s# e# e#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # e# x# e# c# u# t# i# o# n#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # n# o# -# n# u# l# l#  # v# a# l# u# e# s# .#  # W# e#  # c# a# n#  # s# a# f# e# l# y#  # s# t# a# r# t#  # n# o# w#  # w# i# t# h#  # c# h# e# c# k# i# n# g#  # v# a# r# i# o# u# s#  # r# e# l# a# t# i# o# n# s#  # a# m# o# n# g#  # d# i# f# f# e# r# e# n# t#  # f# e# a# t# u# r# e# s#  # u# s# i# n# g#  # d# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n#  # t# e# c# h# n# i# q# u# e# s

# In[None]

#SNS is very popular library in python, It is very easy to plot and infer relations between two parameters using this
import seaborn as sns 
import matplotlib.pyplot as plt

# A# s#  # s# e# e# n#  # a# b# o# v# e#  # e# v# e# r# y#  # d# a# t# a#  # i# s#  # i# n#  # n# u# m# e# r# i# c# a# l#  # f# o# r# m# ,#  # t# h# i# s#  # m# a# k# e# s#  # o# u# r#  # a# n# a# l# y# s# i# s#  # m# u# c# h#  # e# a# s# i# e# r#  # a# s#  # w# e#  # d# o#  # n# o# t#  # h# a# v# e#  # t# o#  # d# e# a# l#  # w# i# t# h#  # s# t# r# i# n# g# s# .#  # W# e#  # w# i# l# l#  # d# i# r# e# c# t# l# y#  # j# u# m# p#  # i# n# t# o#  # h# e# a# t# m# a# p

# In[None]

winequality.corr()

# In[None]

f,ax = plt.subplots(figsize=(8, 8))
sns.heatmap(winequality.corr(), annot=True, fmt= '.1f',ax=ax)
plt.show()

# G# r# e# a# t# e# r#  # t# h# e#  # n# u# m# b# e# r#  # i# n# s# i# d# e#  # t# h# e#  # b# o# x# ,#  # h# i# g# h# e# r#  # t# h# e#  # d# e# p# e# n# d# e# n# c# y#  # b# e# t# w# e# e# n#  # t# h# e#  # t# w# o# .# 
# 
# W# i# t# h#  # t# h# e#  # a# b# o# v# e#  # u# n# d# e# r# s# t# a# n# d# i# n# g# ,#  # l# e# t#  # u# s#  # s# e# e#  # h# o# w#  # i# s#  # q# u# a# l# i# t# y#  # r# e# l# a# t# e# d#  # t# o#  # o# t# e# h# r#  # f# a# c# t# o# r# s# 
# 
# W# h# i# l# e#  # a# l# c# o# h# o# l# ,#  # s# u# l# p# h# a# t# e# s#  # a# n# d#  # c# i# t# r# i# c#  # a# c# i# d# i# t# y#  # p# o# s# i# t# i# v# e# l# y#  # i# n# f# l# u# e# n# c# e#  # f# i# n# a# l#  # w# i# n# e#  # q# u# a# l# i# t# y# 
# V# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y#  # a# l# m# o# s# t#  # n# e# g# a# t# i# v# e# l# y#  # i# n# f# l# u# e# n# c# e# s#  # w# i# n# e#  # q# u# a# l# i# t# y# .# 
# 
# F# e# w#  # o# t# h# e# r#  # c# o# n# c# l# u# s# i# o# n# s#  # t# h# a# t#  # c# a# n#  # b# e#  # d# e# r# i# v# e# d#  # f# r# o# m#  # h# e# a# t#  # m# a# p# 
# 1# .#  # F# r# e# e#  # s# u# l# p# h# u# r#  # d# i# o# x# i# d# e#  # a# n# d#  # t# o# t# a# l#  # s# u# l# p# h# u# r#  # d# i# o# x# i# d# e#  # a# r# e#  # r# e# l# a# t# e# d#  # (# a# s#  # e# x# p# e# c# t# e# d# )# 
# 2# .#  # F# i# x# e# d#  # a# c# i# d# i# t# y# ,#  # c# i# t# r# u# s#  # a# c# i# d# i# t# y#  # a# n# d#  # r# e# s# i# d# u# a# l#  # s# u# g# a# r#  # i# n# f# l# u# e# n# c# e# s#  # p# H# 
# L# e# t#  # u# s#  # s# t# a# r# t#  # t# o#  # p# l# o# t#  # e# a# c# h#  # o# f#  # t# h# e# s# e#  # v# a# r# i# a# b# l# e# s#  # a# g# a# i# n# s# t#  

# In[None]

fig = plt.figure(figsize = (20,6))
sns.regplot(x= winequality['alcohol'], y = winequality['quality'])

# F# r# o# m#  # s# c# a# t# t# e# r# p# l# o# t#  # i# t#  # c# a# n#  # b# e#  # s# e# e# n#  # t# h# a# t#  # a# l# c# o# h# o# l#  # p# o# s# i# t# i# v# e# l# y#  # i# n# f# l# u# e# n# c# e# s#  # w# i# n# e#  # q# u# a# l# i# t# y# .#  # A# l# c# o# h# o# l#  # p# e# r# c# e# n# t# a# g# e#  # >#  # 1# 1# .# 5#  # g# e# n# e# r# a# l# l# y#  # g# i# v# e# s#  # u# s#  # g# o# o# d#  # r# e# v# i# e# w

# In[None]

fig = plt.figure(figsize = (10,6)) 
sns.barplot(y= winequality['fixed acidity'], x = winequality['quality'])

# T# h# e#  # b# a# r# -# g# r# a# p# h#  # d# e# p# i# c# t# s#  # w# h# a# t#  # w# e#  # o# b# s# e# r# v# e# d#  # f# r# o# m#  # h# e# a# t# m# a# p# .#  # T# h# e# r# e#  # i# s#  # n# o#  # m# u# c# h#  # d# e# p# e# n# d# e# n# c# y#  # b# e# t# w# e# e# n#  # w# i# n# e# _# q# u# a# l# i# t# y#  # a# n# d#  # f# i# x# e# d#  # a# c# i# d# i# t# y

# In[None]

fig = plt.figure(figsize = (20,6))
sns.barplot(x= winequality['quality'], y = winequality['sulphates'])

# In[None]

sns.countplot(winequality['quality'])

# I# t# s#  # c# l# e# a# r#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h#  # h# o# w#  # o# u# r#  # w# i# n# e#  # q# u# a# l# i# t# y#  # i# s#  # d# i# s# t# r# i# b# u# t# e# d#  # o# v# e# r#  # d# i# f# f# e# r# e# n# t#  # r# a# t# i# n# g# s

# ##  # *# P# r# e# p# a# r# i# n# g#  # d# a# t# a#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g# *

# H# e# r# e#  # w# e#  # c# a# t# e# g# o# r# i# s# e#  # w# i# n# e#  # q# u# a# l# i# t# y#  # i# n# t# o#  # 3#  # s# e# g# m# e# n# t# s# .#  # F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h#  # i# t#  # i# s#  # c# l# e# a# r#  # t# h# a# t#  # m# o# s# t#  # w# i# n# e# s#  # a# r# e#  # i# n#  # t# h# e#  # r# a# t# i# n# g#  # 5# -# 6# ,#  # s# o#  # w# e#  # c# o# n# s# i# d# e# r#  # t# h# i# s#  # a# s#  # a# v# e# r# a# g# e#  # r# a# t# i# n# g# .#  # A# n# y# t# h# i# n# g#  # b# e# l# o# w#  # 5#  # w# i# l# l#  # b# e#  # a#  # b# a# d#  # r# a# t# i# n# g#  # a# n# d#  # a# n# y#  # o# t# h# e# r#  # r# a# t# i# n# g#  # w# i# l# l#  # b# e#  # g# o# o# d# .

# In[None]

quality = winequality["quality"].values
category = []
for num in quality:
    if num<5:
        category.append("Bad")
    elif num == 5 or num == 6:
        category.append("Average")
    else:
        category.append("Good")


# W# i# t# h#  # t# h# e#  # a# b# o# v# e#  # a# s# s# u# m# p# t# i# o# n# ,#  # w# e#  # r# e# p# l# a# c# e#  # n# u# m# e# r# i# c# a# l#  # q# u# a# l# i# t# y#  # d# a# t# a#  # i# n#  # o# u# r#  # m# a# i# n#  # d# a# t# a# s# e# t#  # t# o#  # t# h# e#  # o# n# e#  # w# i# t# h#  # c# a# t# e# g# o# r# i# s# e# d#  # r# a# t# i# n# g

# In[None]

#Creating new dataset for prediction
category = pd.DataFrame(data=category, columns=["category"])
winedata = pd.concat([winequality,category],axis=1)
winedata.drop(columns="quality",axis=1,inplace=True)

# In[None]

winedata.head()

# In[None]

X= winedata.iloc[:,:-1].values
y= winedata.iloc[:,-1].values

# In[None]

from sklearn.preprocessing import LabelEncoder
labelencoder_y =LabelEncoder()
y= labelencoder_y.fit_transform(y)

# ##  #  # *# M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # M# o# d# e# l# s#  # u# s# i# n# g#  # s# c# i# k# i# t#  # l# i# b# r# a# r# y# *

# H# e# r# e#  # w# e#  # f# i# r# s# t#  # s# p# l# i# t#  # o# u# r#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g# .#  # T# r# a# i# n# i# n# g#  # d# a# t# a#  # w# i# l# l#  # c# o# n# t# a# i# n#  # 8# 0# %#  # w# h# i# l# e#  # t# e# s# t# i# n# g#  # d# a# t# a#  # w# i# l# l#  # b# e#  # 2# 0# %#  # o# f#  # m# a# i# n#  # d# a# t# a# s# e# t

# W# e#  # t# r# a# i# n#  # o# u# r#  # d# a# t# a#  # o# n#  # 
# 1# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# e# r# 
# 2# .#  # K# N# N# 
# 3# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# 4# .#  # D# e# c# i# s# i# o# n# T# r# e# e# 
# 5# .#  # N# a# i# v# e#  # B# a# y# e# s# 
# 
# A# t#  # t# h# e#  # e# n# d# ,#  # w# e#  # c# o# m# p# a# r# e#  # h# o# w#  # e# a# c# h#  # m# o# d# e# l#  # w# i# l# l#  # p# e# r# f# o# r# m#  # o# n#  # o# u# r#  # d# a# t# a#  # a# n# d#  # f# i# n# a# l# i# z# e#  # o# n#  # t# h# e#  # m# o# d# e# l#  # b# a# s# e# d#  # o# n#  # p# e# r# f# o# r# m# a# n# c# e

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,accuracy_score
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9729109.npy", { "accuracy_score": score })

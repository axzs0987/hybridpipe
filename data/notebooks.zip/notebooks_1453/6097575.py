import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# In[None]

dataset = pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

dataset.tail()

# In[None]

y=dataset.iloc[0:1599,11].values
y=np.where(y>=7,1,0)

# In[None]

x = dataset.iloc[0:1599, [1, 10]].values

# In[None]

print('Class labels:', np.unique(y))

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6097575.npy", { "accuracy_score": score })

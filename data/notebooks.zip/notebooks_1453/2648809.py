import pandas as pd
# *# *#  # O# n#  # t# h# i# s#  # K# e# r# n# e# l# ,#  # I#  # w# i# l# l#  # m# a# k# e#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# b# o# u# t#  # g# e# n# d# e# r#  # v# o# i# c# e#  # *# *# 
# 
# M# y#  # s# t# e# p# s#  # a# r# e# :# 
# *#  #  # F# i# r# s# t# l# y#  # I#  # w# i# l# l#  # i# m# p# o# r# t#  # l# i# b# r# a# r# i# e# s# 
# *#  #  # L# o# a# d# i# n# g#  # D# a# t# a# 
# *#  #  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# 
# *#  #  # O# n# e#  # H# o# t#  # E# n# c# o# d# i# n# g# 
# *#  #  # N# o# r# m# a# l# i# z# a# t# i# o# n# 
# *#  #  # T# r# a# i# n#  # -#  # T# e# s# t#  # S# p# l# i# t# 
# *#  #  # F# i# n# a# l# l# y# ,#  # P# r# e# d# i# c# t# i# o# n# s

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# L# o# a# d#  # t# h# e#  # D# a# t# a# *# *

# In[None]

data = pd.read_csv('../input/voice.csv')
data.head()

# In[None]

data.info()

# *# *# D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# *# *

# In[None]

seaborn.pairplot(data[['meanfreq', 'Q25', 'Q75', 'skew', 'centroid', 'label']],hue='label', size=3)

# *# *# I# f#  # y# o# u#  # w# e# l# l#  # l# o# o# k#  # a# t#  # t# h# e#  # l# a# b# e# l#  # c# o# l# u# m# n#  # y# o# u#  # c# a# n#  # s# e# e#  # t# h# a# t#  # a# l# l#  # g# e# n# d# e# r# s#  # a# r# e#  # s# e# q# u# e# n# t# i# a# l# .#  # F# i# r# s# t# l# y#  # w# e#  # h# a# v# e#  # t# o#  # m# a# k# e#  # s# h# u# f# f# l# e#  # o# n#  # t# h# i# s#  # d# a# t# a# .# *# *

# In[None]

data = data.sample(frac=1)

data.head()

# *# *# C# a# t# e# g# o# r# i# c# a# l#  # E# n# c# o# d# i# n# g# *# *

# In[None]

data['label'] = data['label'].map({'male':1,'female':0})

# In[None]

X = data.loc[:, data.columns != 'label']
y = data.loc[:,'label']

# *# *# N# o# r# m# a# l# i# z# a# t# i# o# n# *# *

# In[None]

X = (X - np.min(X))/(np.max(X)-np.min(X)).values

X.head()

# *# *# T# r# a# i# n#  # -#  # T# e# s# t#  # S# p# l# i# t# *# *

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2648809.npy", { "accuracy_score": score })

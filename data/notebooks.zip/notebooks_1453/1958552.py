import pandas as pd
#  # *# *# I# N# T# R# O# D# U# C# T# I# O# N# *# *# 
#  # 
#  # W# e# '# l# l#  # l# e# a# r# n# ,#  # p# r# a# c# t# i# s# e#  # a# n# d#  # c# o# m# p# a# r# e#  # 6#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l# s#  # i# n#  # t# h# i# s#  # p# r# o# j# e# c# t# .#  # S# o# ,#  # y# o# u# '# l# l#  # s# e# e#  # i# n#  # t# h# i# s#  # k# e# r# n# e# l# :# 
# 
# *#  # E# D# A#  # (# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# )# 
# *#  # W# h# a# t#  # i# s#  # C# o# n# f# u# s# i# o# n#  # M# a# t# r# i# x# ?# 
# *#  # T# e# s# t# -# T# r# a# i# n#  # D# a# t# a# s#  # S# p# l# i# t# 
# *#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # K# N# N#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # (# S# V# M# )#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # N# a# i# v# e#  # B# a# y# e# s#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # D# e# s# i# c# i# o# n#  # T# r# e# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# *#  # C# o# m# p# a# r# e#  # a# l# l#  # o# f#  # t# h# e# s# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # M# o# d# e# l# s# 
# *#  # C# o# n# c# l# u# s# i# o# n

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

#For confusion matrixes
from sklearn.metrics import confusion_matrix


# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

# Read our data from dataset.
data = pd.read_csv("../input/voice.csv")

# In[None]

#Let's looking at top 5 datas.
data.head()

# In[None]

#Let's looking at last 10 datas.
data.tail(10)

# In[None]

data.describe()

# In[None]

data.corr()

# In[None]

# Firstly, we must check our data. If we have NaN values, we should drop them.
data.info()
#As we can see easily, we have no NaN values.

# *# *# O# u# r#  # '# l# a# b# e# l# '#  # f# e# a# t# u# r# e#  # h# a# s#  # 2#  # v# a# l# u# a# b# l# e# :#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e# .#  # T# h# e# s# e#  # a# r# e#  # s# t# r# i# n# g#  # b# u# t#  # w# e#  # n# e# e# d#  # i# n# t# e# g# e# r# s#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .#  # T# h# e# r# e# f# o# r# e# ,#  # w# e#  # m# u# s# t#  # c# o# n# v# e# r# t#  # t# h# e# m#  # f# r# o# m#  # o# b# j# e# c# t#  # t# o#  # i# n# t# e# g# e# r# .# *# *

# In[None]

data.label = [1 if each == "female" else 0 for each in data.label]
#We assign 1 to female, 0 to male.

# *# *# L# e# t# '# s#  # c# h# e# c# k#  # i# t# !# *# *

# In[None]

data.info()

# *# *# C# o# n# f# u# s# i# o# n#  # M# a# t# r# i# x# *# *# 
# 
# B# e# f# o# r# e#  # s# t# a# r# t#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# s# ,#  # w# e#  # s# h# o# u# l# d#  # k# n# o# w#  # o# n# e#  # t# h# i# n# g# :#  # C# o# n# f# u# s# i# o# n#  # M# a# t# r# i# x# !# 
# F# o# r#  # e# x# a# m# p# l# e# ;#  # w# e#  # h# a# v# e#  # 1# 0# 0#  # d# a# t# a#  # p# o# i# n# t#  # (# d# o# g# s#  # a# n# d#  # c# a# t# s# )#  # a# n# d#  # w# e#  # m# a# k# e#  # a#  # p# r# e# d# i# c# t# i# o# n# .#  # O# u# r#  # p# r# e# d# i# c# t# i# o# n#  # s# c# o# r# e#  # i# s#  # 0# .# 8#  # s# o#  # w# e#  # p# r# e# d# i# c# t#  # w# e# l# l#  # %# 8# 0# .#  # C# o# n# f# u# s# i# o# n#  # m# a# t# r# i# x#  # g# i# v# e# s#  # u# s# ;#  # 
# *#  # H# o# w#  # m# a# n# y#  # t# r# u# e#  # v# a# l# u# e# s#  # w# e#  # p# r# e# d# i# c# t#  # t# r# u# e#  #  # (# T# P#  # =#  # T# r# u# e#  # P# o# s# i# t# i# v# e# )# 
# *#  # H# o# w#  # m# a# n# y#  # t# r# u# e#  # v# a# l# u# e# s#  # w# e#  # p# r# e# d# i# c# t#  # f# a# l# s# e#  #  # (# F# P#  # =#  # F# a# l# s# e#  # P# o# s# i# t# i# v# e# )# 
# *#  # H# o# w#  # m# a# n# y#  # f# a# l# s# e#  # v# a# l# u# e# s#  # w# e#  # p# r# e# d# i# c# t#  # f# a# l# s# e#  #  # (# T# N#  # =#  # T# r# u# e#  # N# e# g# a# t# i# v# e# )# 
# *#  # H# o# w#  # m# a# n# y#  # f# a# l# s# e#  # v# a# l# u# e# s#  # w# e#  # p# r# e# d# i# c# t#  # t# r# u# e#  # (# F# N#  # =#  # F# a# l# s# e#  # N# e# g# a# t# i# v# e# 


# *# *# A# s#  # y# o# u#  # c# a# n#  # s# e# e# ;#  # o# u# r#  # l# a# b# e# l#  # f# e# a# t# u# r# e# s#  # c# o# n# v# e# r# t# e# d#  # i# n# t# e# g# e# r# !# *# *

# In[None]

#We should have x and y values for test-train datas.
y = data.label.values
x_data = data.drop(["label"],axis=1)

# In[None]

#Normalization
x = (x_data - np.min(x_data)) / (np.max(x_data)).values

# *# *# A# f# t# e# r#  # a# s# s# i# g# n#  # x#  # a# n# d#  # y#  # v# a# l# u# e# ;#  # w# e#  # s# h# o# u# l# d#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # d# a# t# a# s#  # s# p# l# i# t# .# *# *

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1958552.npy", { "accuracy_score": score })

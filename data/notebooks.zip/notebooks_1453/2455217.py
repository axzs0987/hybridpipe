import pandas as pd
# C# r# e# a# t# e# d#  # b# y# :#  # S# a# n# g# w# o# o# k#  # C# h# e# o# n# 
# 
# D# a# t# e# :#  # D# e# c#  # 2# 3# ,#  # 2# 0# 1# 8# 
# 
# T# h# i# s#  # i# s#  # s# t# e# p# -# b# y# -# s# t# e# p#  # g# u# i# d# e#  # t# o#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # u# s# i# n# g#  # s# c# i# k# i# t# -# l# e# a# r# n# ,#  # w# h# i# c# h#  # I#  # c# r# e# a# t# e# d#  # f# o# r#  # r# e# f# e# r# e# n# c# e# .#  # I#  # a# d# d# e# d#  # s# o# m# e#  # u# s# e# f# u# l#  # n# o# t# e# s#  # a# l# o# n# g#  # t# h# e#  # w# a# y#  # t# o#  # c# l# a# r# i# f# y#  # t# h# i# n# g# s# .#  # I#  # a# m#  # e# x# c# i# t# e# d#  # t# o#  # m# o# v# e#  # o# n# t# o#  # m# o# r# e#  # a# d# v# a# n# c# e# d#  # c# o# n# c# e# p# t# s# ,#  # s# u# c# h#  # a# s#  # d# e# e# p#  # l# e# a# r# n# i# n# g# ,#  # u# s# i# n# g#  # f# r# a# m# e# w# o# r# k# s#  # l# i# k# e#  # K# e# r# a# s#  # a# n# d#  # T# e# n# s# o# r# f# l# o# w# .# 
# T# h# i# s#  # n# o# t# e# b# o# o# k# '# s#  # c# o# n# t# e# n# t#  # i# s#  # f# r# o# m#  # A# -# Z#  # D# a# t# a# s# c# i# e# n# c# e#  # c# o# u# r# s# e# ,#  # a# n# d#  # I#  # h# o# p# e#  # t# h# i# s#  # w# i# l# l#  # b# e#  # u# s# e# f# u# l#  # t# o#  # t# h# o# s# e#  # w# h# o#  # w# a# n# t#  # t# o#  # r# e# v# i# e# w#  # m# a# t# e# r# i# a# l# s#  # c# o# v# e# r# e# d# ,#  # o# r#  # a# n# y# o# n# e#  # w# h# o#  # w# a# n# t# s#  # t# o#  # l# e# a# r# n#  # t# h# e#  # b# a# s# i# c# s#  # o# f#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .# 
# 
# ##  # C# o# n# t# e# n# t# :# 
# 
# ## ## ##  # 1# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# ## ## ##  # 2# .#  # K# -# n# e# a# r# e# s# t#  # N# e# i# g# h# b# o# r# s#  # (# K# N# N# )# 
# ## ## ##  # 3# .#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # (# S# V# M# )# 
# ## ## ##  # 4# .#  # K# e# r# n# e# l#  # S# V# M# 
# ## ## ##  # 5# .#  # N# a# i# v# e#  # B# a# y# e# s#  # a# l# g# o# r# i# t# h# m# 
# ## ## ##  # 6# .#  # D# e# c# i# s# i# o# n#  # T# r# e# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# ## ## ##  # 7# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# ## ## ##  # 8# .#  # E# v# a# l# u# a# t# i# n# g#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l# s# 
# 
# _# _# _# _# _# _# _# _# _# _# 
# _# _# _# _# _# _# _# _# _

# ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # 
# U# s# e#  # t# h# e#  # s# a# m# e#  # l# i# b# r# a# r# y#  # t# h# a# t#  # w# a# s#  # u# s# e# d#  # i# n#  # R# e# g# r# e# s# s# i# o# n#  # n# o# t# e# b# o# o# k# .# 


# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

dataset1 = pd.read_csv('../input/Social_Network_Ads.csv')
x = dataset1.iloc[:, [2,3]].values
y = dataset1.iloc[:, 4].values

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2455217.npy", { "accuracy_score": score })

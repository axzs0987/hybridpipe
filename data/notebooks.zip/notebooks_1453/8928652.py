import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler 
import xgboost
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold, RandomizedSearchCV
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report 


# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

import warnings
warnings.filterwarnings('ignore')

# In[None]

# Take a look at the data
df = pd.read_csv("../input/falldata/falldeteciton.csv", sep=",")
print(df.head(10))

# In[None]

# Data dimensionality [rows, columns]
print(df.shape)

# In[None]

# Check data quality
df.info()

# F# r# o# m#  # a# b# o# v# e#  # r# e# s# u# l# t#  # w# e#  # c# a# n#  # s# e# e#  # t# h# e# r# e#  # i# s#  # n# o#  # n# u# l# l#  # v# a# l# u# e#  # i# n#  # a# n# y#  # o# f#  # t# h# e#  # c# o# l# u# m# n# s# .

# In[None]

# Describe the dataframe columns
# We will discard activity column as that is a nominal attribute
df.iloc[:,1:7].describe()

# In[None]

d = df["ACTIVITY"].value_counts().sort_index()
print(d)

# In[None]

# Pie chart, where the slices will be ordered and plotted counter-clockwise:
dict = {0:'Standing', 1:'Walking', 2:'Sitting', 3:'Falling', 4:'Cramps', 5:'Running'}
resp = list(dict.keys())
labels = list(dict.values())
sizes = [d[0], d[1], d[2], d[3], d[4], d[5]]
explode = (0, 0, 0, 0.1, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=labels, explode = explode, autopct='%1.1f%%', startangle = 90, counterclock=False, shadow=False)
ax1.axis('equal')
plt.show()

# In[None]

# Visualize with Bar chart
#plt.bar(labels, d)
#plt.show()
sns.set(style="darkgrid")
ax = sns.countplot(y='ACTIVITY', data=df)
ax.set_yticklabels(labels);

# In[None]

# Histograms
df.iloc[:,1:7].hist(bins=10,figsize=(15, 15))
plt.show()

# In[None]

# Density
df.iloc[:,1:7].plot(kind='density', subplots=True, layout=(3,3), sharex=False, figsize=(15, 15))
plt.show()

# In[None]

# Create pivot_table
colum_names = ['TIME','SL','EEG','BP','HR','CIRCLUATION']
df_pivot_table = df.pivot_table(colum_names,
               ['ACTIVITY'], aggfunc='median')
print(df_pivot_table)

# In[None]

# Correlation matrix
tmp = df.drop('ACTIVITY', axis=1)
correlations = tmp.corr()
print(correlations)
# Plot figsize
fig, ax = plt.subplots(figsize=(15, 11))
# Generate Color Map
colormap = sns.diverging_palette(220, 10, as_cmap=True)
# Generate Heat Map, allow annotations and place floats in map
sns.heatmap(correlations, cmap=colormap, annot=True, fmt=".2f")
ax.set_xticklabels(
    colum_names,
    rotation=45,
    horizontalalignment='right'
);
ax.set_yticklabels(colum_names);

# In[None]

#temp = df.iloc[:,[1,2,5,6]]
#temp.describe()
# Correlation matrix
temp = df.drop(['ACTIVITY', 'EEG', 'BP'], axis=1)
correlations = temp.corr()
print(correlations)
# Plot figsize
fig, ax = plt.subplots(figsize=(8, 6))
# Generate Color Map
colormap = sns.diverging_palette(220, 10, as_cmap=True)
# Generate Heat Map, allow annotations and place floats in map
sns.heatmap(correlations, cmap=colormap, annot=True, fmt=".2f")
ax.set_xticklabels(
    ['TIME','SL','HR','CIRCLUATION'],
    rotation=45,
    horizontalalignment='right'
);
ax.set_yticklabels(['TIME','SL','HR','CIRCLUATION']);

# In[None]

sns.set(style='ticks')
sns.pairplot(tmp)

# In[None]

# Use boxplot to do the outlier analysis for the dataset feature variables
# Boxplot for 'TIME'
sns.boxplot(y=df['TIME'], x=df['ACTIVITY'])

# In[None]

# Use boxplot to do the outlier analysis for the dataset feature variables
# Boxplot for 'SL'
ax = sns.boxplot(y=df['SL'], x=df['ACTIVITY'])

# In[None]

# Use boxplot to do the outlier analysis for the dataset feature variables
# Boxplot for 'EEG'
ax = sns.boxplot(y=df['EEG'], x=df['ACTIVITY'])

# In[None]

# Use boxplot to do the outlier analysis for the dataset feature variables
# Boxplot for 'HR'
ax = sns.boxplot(y=df['HR'], x=df['ACTIVITY'])

# In[None]

# Use boxplot tdfo do the outlier analysis for the dataset feature variables
# Boxplot for 'BP'
ax = sns.boxplot(y=df['BP'], x=df['ACTIVITY'])

# In[None]

# Use boxplot to do the outlier analysis for the dataset feature variables
# Boxplot for 'CIRCLUATION'
ax = sns.boxplot(y=df['CIRCLUATION'], x=df['ACTIVITY'])

# In[None]

# Remove outliers from dataset df

Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3 - Q1
df_out = df[~((df < (Q1 - 1.5 * IQR)) |(df > (Q3 + 1.5 * IQR))).any(axis=1)]
df_out.shape

# In[None]

# Create a new column called Decision. This column will contain the values of 0 = 'No Fall', 1 = 'Fall' using following rule: 
# Activity Value : 3 --> Fall, else --> No Fall

decision = []
for i in df_out['ACTIVITY']:
    if i == 3:
        decision.append('1')
    else: 
        decision.append('0')
df_out['DECISION'] = decision
print(df_out.head(10))

# In[None]

df_out['DECISION'].value_counts().sort_index()

# In[None]

# Split the dataset into x and y : x -> Feature variables, y -> Class variable
X = df_out.iloc[:,1:7]
y = df_out['DECISION']
print(X.shape)
print(y.shape)

# In[None]

print(X.head(10))

# In[None]

print(y.head(10))

# In[None]

# Split dataset into train and test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8928652.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

train_data = pd.read_csv("../input/falldeteciton.csv")

# In[None]

X_train=train_data.iloc[:,[1,2,3,4,5,6]].values
y_train=train_data.iloc[:,0].values

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train_main, X_train_eval, y_train_main, y_train_eval = train_test_split(X_train, y_train, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train_main, y_train_main)
y_pred = model.predict(X_train_eval)
score = accuracy_score(y_train_eval, y_pred)
import numpy as np
np.save("prenotebook_res/3220194.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# ## ##  # P# r# e# p# a# r# a# n# d# o#  # o# s#  # d# a# d# o# s

# In[None]

# Carregando os dados
df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

df.head()

# In[None]

# Tamanho do dataframe e tipos dos dados
df.info()

# In[None]

# Limpando os valores em branco, trocando espaço em branco por -1, e convertendo a coluna
df['TotalCharges'] = df['TotalCharges'].str.strip().replace('', '-1').astype(float)

# In[None]

# Convertendo as colunas object para colunas categóricas
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].astype('category').cat.codes

# ## ##  # R# o# d# a# n# d# o#  # o#  # M# o# d# e# l# o

# In[None]

# Separando o dataframe
from sklearn.model_selection import train_test_split

y_varible = df["Churn"]
x_varible = df.drop(["Churn"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/4150868.npy", { "accuracy_score": score })

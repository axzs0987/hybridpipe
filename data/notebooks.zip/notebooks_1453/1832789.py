import pandas as pd
# *# *# T# e# a# m#  # N# a# m# e#  #  # :#  # S# i# g# n# i# f# i# c# a# n# t# l# y#  # D# i# f# f# e# r# e# n# t# *# *# 
# 
# M# a# a# n# v# i#  # N# u# n# n# a#  # -# -# >#  # 0# 1# F# B# 1# 6# E# C# S# 1# 8# 7# 
# 
# N# i# h# a# r# i# k# a#  # G#  # -# -# >#  # 0# 1# F# B# 1# 6# E# C# S# 2# 2# 9# 
# 
# O# m# k# a# r#  # M# e# t# r# i#  # -# -# >#  # 0# 1# F# B# 1# 6# E# C# S# 2# 3# 9# 


# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# R# e# q# u# i# r# e# d#  # A# P# I# s# *# *

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier 
from sklearn.metrics import classification_report, confusion_matrix  
from sklearn.cluster import KMeans
from scipy.cluster.vq import whiten

# *# *# K# N# N#  # C# l# a# s# s# i# f# i# c# a# a# t# i# o# n# *# *

# In[None]

data = pd.read_csv("../input/Absenteeism_at_work.csv")
#1st column to 13th column
X =  data.iloc[:,range(0,13)]
#14st column --> Labels
Y =  data.iloc[:,14]

#normalising the data
normal_X = preprocessing.normalize(X)

# In[None]

#Splitting of data set
from sklearn.model_selection import train_test_split
Train_X, Test_X, Train_y, Test_y = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(Train_X, Train_y)
y_pred = model.predict(Test_X)
score = accuracy_score(Test_y, y_pred)
import numpy as np
np.save("prenotebook_res/1832789.npy", { "accuracy_score": score })

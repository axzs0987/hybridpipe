import pandas as pd
import numpy as np
import matplotlib.pyplot as plt;
import seaborn as sns
train = pd.read_csv('../input/titanic-train/train.csv')
train.tail()
#sns.heatmap(train.isnull(),yticklabels=False,cbar=False,cmap='viridis')
train.isnull().sum().sort_values(ascending=False)
#sns.set_style('whitegrid')
#sns.countplot(x='Survived',data=train,palette='RdBu_r')
#sns.set_style('whitegrid')
#sns.countplot(x='Survived',hue='Sex',data=train,palette='RdBu_r')
#sns.set_style('whitegrid')
#sns.countplot(x='Survived',hue='Pclass',data=train,palette='rainbow')
#plt.figure(figsize=(12, 7))
#sns.boxplot(x='Pclass',y='Age',data=train,palette='winter')
def impute_age(cols):
    Age = cols[0]
    Pclass = cols[1]
    
    if pd.isnull(Age):
        if Pclass == 1:
            return 37
        elif Pclass == 2:
            return 29
        else:
            return 24
    else:
        return Age
train['Age'] = train[['Age','Pclass']].apply(impute_age,axis=1)
train['Embarked'] = train['Embarked'].fillna('S')
#sns.heatmap(train.isnull(),yticklabels=False,cbar=False,cmap='viridis')
train.drop('Cabin',axis=1,inplace=True)
train.head()
train.dropna(inplace=True)
train.info()
sex = pd.get_dummies(train['Sex'],drop_first=True)
embark = pd.get_dummies(train['Embarked'],drop_first=True)
train.drop(['Sex','Embarked','Name','Ticket'],axis=1,inplace=True)
train = pd.concat([train,sex,embark],axis=1)
train.head()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(train.drop(['Survived'], axis=1), train['Survived'], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression()
#logmodel.fit(X_train,y_train)
#predictions = logmodel.predict(X_test)
X_test.head()
#predictions
from sklearn.metrics import classification_report,confusion_matrix
#print(confusion_matrix(y_test,predictions))
#print(classification_report(y_test,predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alamjane61_titanic-logistic-regression.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/alamjane61_titanic-logistic-regression/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/alamjane61_titanic-logistic-regression/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alamjane61_titanic-logistic-regression/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alamjane61_titanic-logistic-regression/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alamjane61_titanic-logistic-regression/testY.csv",encoding="gbk")


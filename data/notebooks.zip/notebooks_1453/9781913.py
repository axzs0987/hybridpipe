import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# ##  # O# b# t# a# i# n#  # t# h# e#  # d# a# t# a#  # 
# G# a# t# h# e# r#  # d# a# t# a#  # a# n# d#  # u# n# d# e# r# s# t# a# n# d#  # i# t

# ## ## ##  # L# o# a# d#  # a# n# d#  # i# n# v# e# s# t# i# g# a# t# i# n# g#  # t# h# e#  # d# a# t# a# 
# 
# l# o# a# d#  # d# a# t# a#  # a# s#  # d# a# t# a# f# r# a# m#  # f# r# o# m#  # p# a# n# d# a# s#  # a# n# d#  # s# e# e#  # w# h# a# t#  # t# h# e#  # d# a# t# a#  # l# o# o# k#  # l# i# k# e

# In[None]

import pandas as pd 

df = pd.read_csv('../input/fertility-data-set/fertility.csv')
df.head()

# In[None]

# get some information about data 
df.info()

# ##  # S# c# r# u# b#  # t# h# e#  # d# a# t# a# 
# T# h# i# s#  # p# r# o# c# e# s# s#  # i# s#  # f# o# r#  # c# l# e# a# n# i# n# g#  # a# n# d#  # f# i# l# t# e# r# i# n# g#  # o# u# r#  # d# a# t# a# .#  # 
# 
# T# h# i# s#  # p# r# o# c# e# s# s#  # i# s#  # s# o#  # i# m# p# o# r# t# a# n# t#  # a# n# d#  # c# r# i# t# i# c# a# l# ,#  # r# e# f# e# r# r# i# n# g#  # t# o#  # *# *# “# g# a# r# b# a# g# e#  # i# n# ,#  # g# a# r# b# a# g# e#  # o# u# t# ”# *# *#  # p# h# i# l# o# s# o# p# h# y# ,#  # i# f#  # t# h# e#  # d# a# t# a#  # i# s#  # u# n# f# i# l# t# e# r# e# d#  # a# n# d#  # i# r# r# e# l# e# v# a# n# t# ,#  # t# h# e#  # r# e# s# u# l# t# s#  # o# f#  # t# h# e#  # a# n# a# l# y# s# i# s#  # w# i# l# l#  # n# o# t#  # m# e# a# n#  # a# n# y# t# h# i# n# g# ,#  # T# h# i# n# k#  # o# f#  # t# h# i# s#  # p# r# o# c# e# s# s#  # a# s#  # o# r# g# a# n# i# z# i# n# g#  # a# n# d#  # t# i# d# y# i# n# g#  # u# p#  # t# h# e#  # d# a# t# a

# ## ## ##  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # 
# 
# w# e#  # w# i# l# l#  # b# e#  # a# b# l# e#  # t# o#  # d# e# a# l#  # w# i# t# h#  # n# u# m# b# e# r# s#  # b# e# t# t# e# r#  # t# h# a# n#  # s# t# r# i# n# g# s#  # s# o#  # w# e#  # w# i# l# l#  # c# o# n# v# e# r# t#  # a# l# l#  # d# i# s# c# r# e# t# e#  # s# t# r# i# n# g#  # v# a# l# u# e# s#  # t# o#  # i# n# t# e# g# e# r#  # v# a# l# u# e# s#  # t# o#  # e# a# s# y#  # o# u# r#  # s# t# a# t# i# s# t# i# c# a# l#  # c# a# l# c# u# l# a# t# i# o# n# s# 
# 
# |#  # C# o# l# u# m# n#  #  #  #  #  #  #  #  # |#  # 0#  #  #  #  #  #  #  #  #  #  #  #  #  # |#  # 1#  #  #  #  #  # |#  #  # 2#  #  # |#  #  # 3#  #  # |#  #  # 4#  #  # |# 
# |#  # :# -# -# -# -# -# -# -# -# -# -# -# -# -#  # |# :# -# -# -# -# -# -# -# -# -# -# -# -# -# :# |# :# -# -# -# -# -# -# -# -# -# -# -# -# -# :# |#  #  #  # :# -# -# -# -# -# -# -# -# -# -# -# -# -# :# |#  # :# -# -# -# -# -# -# -# -# -# -# -# -# -# :#  #  # |#  #  # :# -# -# -# -# -# -# -# -# -# -# -# -# -# :#  #  # |# 
# |#  # S# e# a# s# o# n#  #  #  #  #  # |#  # *# *# n# u# l# l# *# *#  # |#  #  #  #  #  # w# i# n# t# e# r#  # |#  #  #  # s# p# r# i# n# g#  # |#  #  # s# u# m# m# e# r#  #  # |#  #  # f# a# l# l#  #  # |# 
# |#  # C# h# i# l# d# i# s# h#  # d# i# s# e# a# s# e# s#  #  #  #  #  #  # |#  # n# o#  #  #  #  #  #  # |#  #  #  # y# e# s#  # |#  #  #  # *# *# n# u# l# l# *# *#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |# 
# |#  # A# c# c# i# d# e# n# t#  # o# r#  # s# e# r# i# o# u# s#  # t# r# a# u# m# a#  # |#  # n# o#  #  #  #  #  #  # |#  #  #  # y# e# s#  # |#  #  #  # *# *# n# u# l# l# *# *#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |# 
# |#  # S# u# r# g# i# c# a# l#  # i# n# t# e# r# v# e# n# t# i# o# n#  # |#  # n# o#  #  #  #  #  #  # |#  #  #  # y# e# s#  # |#  #  #  # *# *# n# u# l# l# *# *#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |# 
# |#  # H# i# g# h#  # f# e# v# e# r# s#  # i# n#  # t# h# e#  # l# a# s# t#  # y# e# a# r#  # |#  # n# o#  #  #  #  #  #  # |#  #  #  # l# e# s# s#  # t# h# a# n#  # 3#  # m# o# n# t# h# s#  # a# g# o#  # |#  #  #  # m# o# r# e#  # t# h# a# n#  # 3#  # m# o# n# t# h# s#  # a# g# o#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |# 
# |#  # F# r# e# q# u# e# n# c# y#  # o# f#  # a# l# c# o# h# o# l#  # c# o# n# s# u# m# p# t# i# o# n#  # |#  # h# a# r# d# l# y#  # e# v# e# r#  # o# r#  # n# e# v# e# r#  #  #  #  #  #  # |#  #  #  # o# n# c# e#  # a#  # w# e# e# k#  # |#  #  #  # s# e# v# e# r# a# l#  # t# i# m# e# s#  # a#  # w# e# e# k#  # |#  # e# v# e# r# y#  # d# a# y#  # |#  #  # s# e# v# e# r# a# l#  # t# i# m# e# s#  # a#  # d# a# y#  # |# 
# |#  # S# m# o# k# i# n# g#  # h# a# b# i# t#  # |#  # n# e# v# e# r#  # |#  #  # o# c# c# a# s# i# o# n# a# l#  # |#  #  #  # d# a# i# l# y#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |# 
# |#  # D# i# a# g# n# o# s# i# s#  # |#  # A# l# t# e# r# e# d#  # |#  #  # N# o# r# m# a# l#  # |#  #  #  #  # *# *# n# u# l# l# *# *#  # |#  #  # *# *# n# u# l# l# *# *#  #  # |#  #  # *# *# n# u# l# l# *# *#  #  # |

# In[None]

# data transformation and replacement from string to integer
fertility = df

fertility['Season'].replace({"winter":1, "spring":2, "summer":3, "fall":4 }, inplace= True)
fertility['Childish diseases'].replace({"yes":1, "no":0}, inplace= True)
fertility['Accident or serious trauma'].replace({"yes":1, "no":0}, inplace= True)
fertility['Surgical intervention'].replace({"yes":1,"no":0}, inplace= True)
fertility['High fevers in the last year'].replace({"more than 3 months ago":2,"less than 3 months ago":1,"no":0}, inplace= True)
fertility['Frequency of alcohol consumption'].replace({"once a week":1,"hardly ever or never":0,"several times a week":2 , "every day":3 , "several times a day" : 4}, inplace= True)
fertility['Smoking habit'].replace({"daily":2, "occasional":1,"never":0}, inplace= True)
fertility['Diagnosis'].replace({"Normal":1,"Altered":0}, inplace= True)

fertility.head()

# In[None]

fertility.describe()
# to make some statistical calculations for the data to understand it more 

# w# e#  # c# a# n#  # s# e# e#  # h# e# r# e#  # t# h# a#  # t# h# e#  #  # `# N# u# m# b# e# r#  # o# f#  # h# o# u# r# s#  # s# p# e# n# t#  # s# i# t# t# i# n# g#  # p# e# r#  # d# a# y# `#  # h# a# v# e#  # s# o# m# e#  # o# u# t# l# i# r# e#  # f# r# o# m#  # t# h# e#  # h# u# g# e#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # a# n# d#  # t# h# e#  # m# a# x# i# m# u# m#  # v# a# l# u# e#  # (# 3# 4# 2# )# ,#  # s# o#  # t# o#  # m# a# k# e#  # s# u# r# e#  # w# e#  # c# a# n#  # d# o#  # s# o# m# e#  # h# i# s# t# o# g# r# a# m

# In[None]

fertility["Number of hours spent sitting per day"].hist(bins=100)
fertility["Number of hours spent sitting per day"].value_counts()
# from the histogram and the value counts functions we can find that we have an outlire with 342, so we can delete this row

# In[None]

fertility.loc[fertility['Number of hours spent sitting per day'] == 342]
# and then delete this row

# In[None]

fertility.drop([50],axis=0, inplace =True)

# ## ## ##  # T# e# s# t#  # t# o#  # f# i# n# d#  # a# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s

# In[None]

fertility.isnull().sum()
# there is no any missing values in our data set and now we are ready to go and explore our data 

# ##  # 3# )#  # E# x# p# l# o# r# e# 
# 
# f# i# n# d#  # s# i# g# n# i# f# i# c# a# n# t#  # p# a# t# t# e# r# n# s#  # a# n# d#  # t# r# e# n# d# s#  # u# s# i# n# g#  # s# t# a# t# i# s# t# i# c# a# l#  # m# e# t# h# o# d# s#  # a# n# d#  # v# i# s# u# l# i# z# a# t# i# o# n# 
# 
# ## ## ##  # C# o# r# r# e# l# a# t# i# o# n

# In[None]

# to visualize the correlatin between the data 
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np 

corr = fertility.corr()
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True
f, ax = plt.subplots(figsize = (10,7))
sns.heatmap(corr,annot=True ,linewidths=.5,mask = mask,square=True)

# In[None]

fertility.hist(bins = 30 , figsize=(15,10))
plt.show()

# u# s# i# n# g#  # t# h# i# s#  # h# i# s# t# o# g# r# a# m#  # w# e#  # c# a# n#  # t# e# l# l#  # t# h# a# t#  # t# h# e#  # d# i# a# g# n# o# s# i# s#  # h# a# v# e#  # s# o# e# m#  # r# e# l# a# t# i# o# n# s# h# i# p#  # w# i# t# h#  # t# h# e#  # c# h# i# l# d# i# s# h#  # d# i# s# e# a# s# e# s

# ##  # M# o# d# e# l# l# i# n# g# 
# 
# c# o# n# s# t# r# u# c# t#  # m# o# d# e# l# s#  # t# o#  # p# r# e# d# i# c# t#  # a# n# d#  # f# o# r# e# c# a# s# t#  

# In[None]

# split our data to features and output 

X = fertility.drop("Diagnosis" , axis = 1 )
y = fertility["Diagnosis"]

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression

# split the data to train and test model
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9781913.npy", { "accuracy_score": score })

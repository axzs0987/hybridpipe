import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn import preprocessing
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

# Read the file
df = pd.read_csv('../input/weatherAUS.csv', index_col='Date', parse_dates=True)
# Check dataset content
print(df.head(5))
# Check total null values for all columns
print(df.isnull().sum())
# Handling null or missing values and unneccesary column(s)
df.dropna(axis=0, subset=['Rainfall'], inplace=True)
df.drop(['Location','Evaporation','Sunshine', 'Cloud9am','Cloud3pm','WindGustDir',
        'WindGustSpeed','WindDir9am','WindDir3pm','WindSpeed9am','WindSpeed3pm', 'RISK_MM'], axis=1, inplace=True)
df.fillna(method='ffill', inplace=True)
# Handling Yes/No values
df.RainTomorrow.replace({'No':'It will not Rain Tomorrow', 'Yes':'It will Rain Tomorrow'}, inplace=True)
df.RainToday.replace({'No':0, 'Yes':1}, inplace=True)
# Check if any more null or missing values left
print(df.isnull().any())
# Check our dataset info
print(df.info())
# Define MinMaxScaler
scaler = preprocessing.MinMaxScaler()
# Declare array of columns need to be scaled
columns = ['MinTemp', 'MaxTemp', 'Rainfall', 'Humidity9am', 'Humidity3pm', 'Pressure9am', 
           'Pressure3pm', 'Temp9am', 'Temp3pm', 'RainToday']
# Scale values for chosen columns
df[columns] = scaler.fit_transform(df[columns])
# Check dataset content after scaling
print(df.head(5))

# In[None]

from sklearn.neighbors import KNeighborsClassifier # K Neighbors Classifier Algo.
from sklearn.ensemble import RandomForestClassifier # Random Forest Classifier Algo.
from sklearn.linear_model import LogisticRegression # Logistic Regression Classifier Algo.
from sklearn.tree import DecisionTreeClassifier # Decision Tree Classifier Algo.
from sklearn.naive_bayes import MultinomialNB # Naive Bayes Classifer Algo.
from sklearn.svm import SVC # Support Vector Classifier Algo.

from sklearn.metrics import confusion_matrix, accuracy_score, classification_report # To get models info.
from sklearn.model_selection import train_test_split # To split data

# In[None]

X = df[columns]
y= df['RainTomorrow']

# In[None]

# Splitting  up data, seting 80% for train and 20% for test.
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3807622.npy", { "accuracy_score": score })

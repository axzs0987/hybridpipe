import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
from matplotlib import pyplot as plt
import seaborn as sns
#sns.set()
data = pd.read_csv("../input/diabetes/diabetes.csv")
data.head()
data.info()
data.isnull().sum()
data.columns
data.shape
data.describe()
#sns.pairplot(data)
data.corr()
#plt.figure(figsize=(20,20))
#sns.heatmap(data.corr(), annot=True, cmap="RdYlGn")
#sns.distplot(data["Age"])
data["Glucose"] = data["Glucose"].replace(0,data["Glucose"].mean())
data["BloodPressure"] = data["BloodPressure"].replace(0,data["BloodPressure"].mean())
data["SkinThickness"] = data["SkinThickness"].replace(0,data["SkinThickness"].mean())
data["Insulin"] = data["Insulin"].replace(0,data["Insulin"].mean())
data["BMI"] = data["BMI"].replace(0,data["BMI"].mean())
data["Pregnancies"] = data["Pregnancies"].replace(0,data["Pregnancies"].mean())
data.describe()
X = data.drop(columns="Outcome") 
y = data["Outcome"]
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
X_train.shape
X_test.shape
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)
from sklearn.ensemble import RandomForestClassifier
random_forest = RandomForestClassifier(n_estimators=100)
#random_forest.fit(X_train, y_train)
#y_prediction = random_forest.predict(X_test)
from sklearn.metrics import classification_report, confusion_matrix
#print(classification_report(y_test, y_prediction))
#cm = confusion_matrix(y_test, y_prediction)
#cm
#sns.heatmap(cm, annot=True, cmap="mako")



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/adeyoyintemidayo_diabetes-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/adeyoyintemidayo_diabetes-prediction/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/adeyoyintemidayo_diabetes-prediction/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/adeyoyintemidayo_diabetes-prediction/testY.csv",encoding="gbk")


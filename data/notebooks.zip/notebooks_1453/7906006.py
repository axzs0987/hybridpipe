import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,LabelEncoder

from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import ExtraTreesClassifier,RandomForestClassifier
from sklearn.svm import SVC,LinearSVC

from sklearn.metrics import accuracy_score,r2_score,classification_report

# In[None]

df = pd.read_csv("/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")
df.head()

# In[None]

plt.figure(figsize=(15,10))
sns.heatmap(df.corr(), cmap="YlGnBu")

# In[None]

# plt.figure(figsize=(15,18))
sns.barplot(df['quality'],df['citric acid'],palette="Blues_d")

# In[None]

sns.barplot(df['quality'],df['fixed acidity'])

# In[None]

plt.figure(figsize=(15,10))
df['quality'].value_counts().plot.pie()

# In[None]

sns.countplot(df['quality'])

# In[None]

sns.barplot(df['quality'],df['residual sugar'])

# In[None]

sns.barplot(df['quality'],df['sulphates'])

# In[None]

sns.barplot(df['quality'],df['alcohol'])

# In[None]

bins = (2, 6.5, 8)
group_names = ['bad', 'good']
df['quality'] = pd.cut(df['quality'], bins = bins, labels = group_names)
label_quality = LabelEncoder()
df['quality'] = label_quality.fit_transform(df['quality'])

# In[None]

X = df.drop('quality',axis=1)
y = df['quality']
X = StandardScaler().fit_transform(X)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7906006.npy", { "accuracy_score": score })

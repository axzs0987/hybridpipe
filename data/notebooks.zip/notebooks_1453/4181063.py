import pandas as pd
# In[10]

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split 
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix 

# In[2]

pulsar_data = pd.read_csv("../input/pulsar_stars.csv")
pulsar_data.head()

# In[3]

#Preparing the data set
data_all = list(pulsar_data.shape)[0]
data_categories = list(pulsar_data['target_class'].value_counts())

print("The dataset has {} diagnosis, {} not star and {} star.".format(data_all, 
                                                                                 data_categories[0], 
                                                                                 data_categories[1]))

# In[4]

X = pulsar_data.iloc[:, 1:-1].values
y = pulsar_data.iloc[:, 8].values

# In[6]

#Creating training and Test Data
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4181063.npy", { "accuracy_score": score })

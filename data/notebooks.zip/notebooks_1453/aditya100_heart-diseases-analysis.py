import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('../input/heart.csv')
df.head()
df.shape
df.dropna()
df.shape
df.describe()
#plt.figure(figsize=(25, 10))
#p = sns.heatmap(df.corr(), annot=True)
#_ = plt.title('Correlation')
#p = sns.countplot(x='sex', data=df)
#p = sns.countplot(x='cp', data=df)
from sklearn.model_selection import train_test_split
Y = df['target']
X = df.drop(columns=['target'], axis=1)
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression 
from sklearn.metrics import accuracy_score 
clf = LogisticRegression(random_state=0, multi_class='multinomial', solver='lbfgs', max_iter=1000)
#_ = clf.fit(X_train, Y_train)
#predictions = clf.predict(X_test) 
#predictions
#accuracy = accuracy_score(Y_test, predictions) 
#accuracy
from sklearn.svm import SVC
clf_svm = SVC(gamma='auto', kernel='poly') 
#_ = clf_svm.fit(X_train, Y_train)
#predictions_svm = clf_svm.predict(X_test)
#predictions_svm
#accuracy_svm = accuracy_score(Y_test,predictions_svm)
#accuracy_svm




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aditya100_heart-diseases-analysis.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aditya100_heart-diseases-analysis/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aditya100_heart-diseases-analysis/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aditya100_heart-diseases-analysis/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aditya100_heart-diseases-analysis/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aditya100_heart-diseases-analysis/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aditya100_heart-diseases-analysis/testX.csv",encoding="gbk")

if type(Y_train).__name__ == "ndarray":
    np.save("hi_res_data/aditya100_heart-diseases-analysis/trainY.npy", Y_train)
if type(Y_train).__name__ == "Series":
    Y_train.to_csv("hi_res_data/aditya100_heart-diseases-analysis/trainY.csv",encoding="gbk")
if type(Y_train).__name__ == "DataFrame":
    Y_train.to_csv("hi_res_data/aditya100_heart-diseases-analysis/trainY.csv",encoding="gbk")

if type(Y_test).__name__ == "ndarray":
    np.save("hi_res_data/aditya100_heart-diseases-analysis/testY.npy", Y_test)
if type(Y_test).__name__ == "Series":
    Y_test.to_csv("hi_res_data/aditya100_heart-diseases-analysis/testY.csv",encoding="gbk")
if type(Y_test).__name__ == "DataFrame":
    Y_test.to_csv("hi_res_data/aditya100_heart-diseases-analysis/testY.csv",encoding="gbk")


import pandas as pd
# In[147]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))



from sklearn.model_selection import train_test_split,GridSearchCV,KFold,LeaveOneOut
from sklearn.metrics import precision_score,recall_score,f1_score,classification_report,accuracy_score,confusion_matrix
from sklearn.tree import DecisionTreeClassifier





# Any results you write to the current directory are saved as output.

# In[110]

dat=pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# In[111]

dat.head(2)

# In[112]

dat.info()

# In[113]

dat.nunique()

# In[114]

dat['Department'].unique()

# In[115]

dat.groupby(by=["Department",'Attrition']).size().plot(kind='bar')
plt.show()

# In[116]

dat.groupby(by=['BusinessTravel','Attrition']).size().plot(kind='bar')
plt.show()

# In[117]

dat.groupby(by=['EducationField','Attrition']).size().plot(kind='bar')
plt.show()

# In[118]


dat.groupby(by=['EnvironmentSatisfaction','Attrition']).size().plot(kind='bar')
plt.show()

# In[119]

dat.groupby(by=['Gender','Attrition']).size().plot(kind='bar')
plt.show()


# In[120]

dat.groupby(by=['JobInvolvement','Attrition']).size().plot(kind='bar')
plt.show()






# In[121]

dat.groupby(by=['JobLevel','Attrition']).size().plot(kind='bar')
plt.show()


# In[122]

dat.groupby(by=['JobRole','Attrition']).size().plot(kind='bar')
plt.show()
                        

# In[123]

dat.groupby(by=['JobSatisfaction','Attrition']).size().plot(kind='bar')
plt.show()




# In[124]

dat.groupby(by=['MaritalStatus','Attrition']).size().plot(kind='bar')
plt.show()

# In[125]

print("Average monthly income for males is {}".format(dat[dat['Gender']=='Male']['MonthlyIncome'].mean()))
print("Average monthly income for males is {}".format(dat[dat['Gender']=='Female']['MonthlyIncome'].mean()))

sns.violinplot(x = 'Gender',y = 'MonthlyIncome',data=dat, hue='Attrition',split=True,palette='Set2')
plt.show()

# In[126]

sns.distplot(dat.Age,kde=False)
plt.show()

# In[127]

dat.dtypes

# In[128]

dat['BusinessTravel'] = dat['BusinessTravel'].astype('category')
dat['Department'] = dat['Department'].astype('category')
dat['EducationField'] = dat['EducationField'].astype('category')
dat['EnvironmentSatisfaction'] = dat['EnvironmentSatisfaction'].astype('category')
dat['Gender'] = dat['Gender'].astype('category')
dat['JobInvolvement'] = dat['JobInvolvement'].astype('category')
dat['JobLevel'] = dat['JobLevel'].astype('category')
dat['JobRole'] = dat['JobRole'].astype('category')
dat['JobSatisfaction'] = dat['JobSatisfaction'].astype('category')
dat['MaritalStatus'] = dat['MaritalStatus'].astype('category')
dat['NumCompaniesWorked'] = dat['NumCompaniesWorked'].astype('category')
dat['OverTime'] = dat['OverTime'].astype('category')
dat['RelationshipSatisfaction'] = dat['RelationshipSatisfaction'].astype('category')
dat['StockOptionLevel'] = dat['StockOptionLevel'].astype('category')
dat['WorkLifeBalance'] = dat['WorkLifeBalance'].astype('category')

# In[129]

#This will return the percentage of Attrition datasets
dat.Attrition.value_counts(normalize=True)*100
#this shows it is an imbalanced dataset


# S# p# l# i# i# t# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t# 


# In[130]

x=dat.drop(columns=['Attrition'])

# In[131]

y=dat['Attrition']

# In[132]

x=pd.get_dummies(x)

# In[133]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3504043.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

import numpy as np
import matplotlib.pyplot as pd
import pandas as pd
import os

# In[None]

dataset = pd.read_csv('../input/epldata_final.csv')

# In[None]

X = dataset.iloc[:, 0:10].values
Y = dataset.iloc[:, 16].values

from sklearn.preprocessing import LabelEncoder
lb = LabelEncoder()
X[:, 0] = lb.fit_transform(X[:, 0]) 
lb1 = LabelEncoder()
X[:, 1] = lb1.fit_transform(X[:, 1])
lb2 = LabelEncoder()
X[:, 3] = lb2.fit_transform(X[:, 3])
lb3 = LabelEncoder()
X[:, 8] = lb3.fit_transform(X[:, 8])



# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1595145.npy", { "accuracy_score": score })

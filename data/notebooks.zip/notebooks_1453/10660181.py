import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# i# t# s#  # v# e# r# y#  # i# m# p# o# r# t# a# n# t#  # t# o#  # k# n# o# w#  # t# h# e#  # t# y# p# e#  # o# f#  # D# a# t# a#  # t# o#  # d# e# c# i# d# e#  # w# h# i# c# h#  # M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# t# h# i# m#  # y# o# u#  # h# a# v# e#  # t# o#  # u# s# e# .# T# h# e# r# e#  # a# r# e#  # t# h# r# e# e#  # t# y# p# e# s#  # o# f#  # D# a# t# a# :# 
# *#  # C# a# t# e# g# o# r# i# c# a# l#  # D# a# t# a# 
# *#  # N# u# m# e# r# i# c# a# l#  # D# a# t# a# 
# *#  # O# r# d# i# n# a# l#  # D# a# t# a# 
# 
# I# n#  # t# h# i# s#  # t# u# t# o# r# i# a# l# ,#  # I#  # w# i# l# l#  # p# r# e# s# e# n# t#  # d# i# f# f# e# r# e# n# t#  # t# y# p# e# s#  # o# f#  # M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # c# l# a# s# s# i# f# i# e# r# 
# 1# .#  # D# a# t# a#  # P# r# e# p# r# a# t# i# o# n# 
# 1# .#  # R# a# n# d# o# m# F# o# r# e# s# t# C# l# a# s# s# i# f# i# e# r# 
# 1# .#  # D# e# c# i# s# i# o# n# T# r# e# e# C# l# a# s# s# i# f# i# e# r# 
# 1# .#  # X# G# B# C# l# a# s# s# i# f# i# e# r# 
# 1# .#  # K# N# e# i# g# h# b# o# r# s# C# l# a# s# s# i# f# i# e# r# 
# 
# I#  # w# i# l# l#  # a# p# p# l# y#  # f# e# a# t# u# r# e# _# i# m# p# o# r# t# a# n# c# e# s# _#  # o# n#  # d# i# f# f# e# r# e# n# t#  # M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # c# l# a# s# s# i# f# i# e# r#  # m# o# d# e# l# s# 


# In[None]

import matplotlib.pyplot as plt
df=pd.read_csv('/kaggle/input/loan-predication/train_u6lujuX_CVtuZ9i (1).csv')
df.head(10)

# In[None]

df.shape

# In[None]

df.isnull().sum()

# In[None]

df1=df.dropna()
df1.shape

# In[None]



df2 = df1.replace(to_replace = ['Yes','No'],value = ['1','0'])
df2.head()

# In[None]

df2 = df1.replace(to_replace = ['Y','N'],value = ['1','0'])
df2.head()

# In[None]

X = df2[['ApplicantIncome','CoapplicantIncome','LoanAmount','Loan_Amount_Term']]
y=df2.Loan_Status



# In[None]

y=df2.Loan_Status
y.head()

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10660181.npy", { "accuracy_score": score })

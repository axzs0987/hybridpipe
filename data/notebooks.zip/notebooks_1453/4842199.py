import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn as sns

dataset = pd.read_csv('../input/winequality-red.csv')

# In[None]

dataset.head(10)





# *# *# h# e# a# d#  # i# s#  # u# s# e# d#  # t# o#  # c# h# e# c# k#  # w# h# a# t#  # i# s#  # t# h# e#  # s# t# r# u# c# t# u# r# e#  # o# f#  # o# u# r#  # d# a# t# a# s# e# t# *# *

# In[None]

dataset.describe()

# *# *# d# e# s# c# r# i# b# e# (# )#  # i# s#  # u# s# e# d#  # t# o#  # c# h# e# c# k#  # s# t# a# s# t# i# c# s#  # o# f#  # d# a# t# a# *# *

# In[None]

dataset.isnull().sum()

# *# *# o# u# r#  # d# a# t# a# s# e# t#  # d# o# e# s# n# '# t#  # c# o# n# t# a# i# n#  # a# n# y#  # n# u# l# l#  # v# a# l# u# e# s# *# *

# In[None]

dataset.columns

# In[None]

import seaborn as sns

sns.catplot(data = dataset,x='quality',y='fixed acidity',kind = 'bar')


# *# *# '# '# '#  # d# u# e#  # t# o#  # f# i# x# e# d#  # a# c# i# d# i# t# y#  # w# i# n# e#  # q# u# a# l# i# t# y#  # i# s#  # n# o# t#  # s# o#  # a# f# f# e# c# t# e# d#  # '# '# '# *# *

# In[None]

sns.catplot(data = dataset,x = 'quality',y = 'volatile acidity', kind = 'bar')


# *# *# t# h# e# r# e#  # i# s#  # i# n# v# e# r# s# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y#  # a# n# d#  # w# i# n# e#  # q# u# a# l# i# t# y# 
# *# *

# In[None]

sns.catplot(data = dataset,x = 'quality',y = 'citric acid',kind = 'bar')

# *# *# i# f#  # w# e#  # i# n# c# r# e# a# s# e#  # t# h# e#  # q# u# a# n# t# i# t# y#  # o# f#  # c# i# t# r# i# c#  # a# c# i# d#  # i# t#  # g# i# v# e# s#  # b# e# t# t# e# r#  # w# i# n# e#  # q# u# a# l# i# t# y#  # 
# *# *

# In[None]

sns.catplot(data = dataset,x='quality',y='residual sugar',kind = 'bar')
sns.relplot(data = dataset,x = 'quality',y ='residual sugar',kind = 'line')

# *# *# r# e# i# d# u# a# l#  # s# u# g# a# r#  # d# o# e# s#  # n# o# t#  # a# f# f# e# c# t#  # w# i# n# e#  # q# u# a# l# i# t# y# 
# *# *

# In[None]

sns.catplot(data = dataset,x = 'quality',y = 'chlorides',kind = 'bar')


# *# *# '# '# '#  # l# e# s# s#  # a# m# m# o# u# t#  # o# f#  # c# h# l# o# r# i# d# e# s#  # g# i# v# e# s#  # b# e# t# t# e# r#  # w# i# n# e#  # q# u# l# i# t# y#  # b# u# t#  # n# o# t#  # s# o#  # a# f# f# e# c# t# e# d# '# '# '# 
# *# *

# In[None]

corr_mat = dataset.corr()
corr_mat.style.background_gradient(cmap='coolwarm')

# *# *# c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # i# s#  # u# s# e# d#  # t# o#  # c# h# e# c# k#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# w# o#  # a# t# t# r# i# b# u# t# e# s#  # ,#  # h# o# w#  # m# u# c# h#  # t# h# e# y#  # a# r# e#  # d# e# p# e# n# d# e# n# t#  # o# n#  # e# a# c# h#  # o# t# h# e# r# 
# n# e# a# r#  # t# o#  # +# 1#  # m# e# a# n# s#  # t# h# e# y#  # a# r# e#  # p# o# s# i# t# i# v# e# l# y#  # h# i# g# h# l# y#  # c# o# r# r# e# l# a# t# e# d#  # a# n# d#  # n# e# a# r#  # t# o#  # -# 1#  # m# e# n# a# s#  # t# h# e# r#  # a# r# e#  # n# e# g# a# t# i# v# e# l# y#  # h# i# g# h# l# y#  # c# o# r# e# l# a# t# e# d#  # a# n# d#  # n# e# a# r#  # t# o#  # 0#  # m# e# a# n# s#  # t# h# e# r# e#  # i# s#  # n# o#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # a# t# t# r# i# b# u# t# e# s# *# *

# In[None]

sns.catplot(data = dataset,x = 'quality',y='alcohol',kind = 'bar')


# *# *# '# '# '#  # i# f#  # w# e#  # i# n# c# r# e# a# s# e#  # t# h# e#  # q# u# a# n# t# i# t# y#  # o# f#  # a# l# c# o# h# o# l#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # w# i# n# e#  # i# s#  # a# l# s# o#  # i# n# c# r# e# s# e# '# '# '# 
# *# *

# In[None]

sns.catplot(data = dataset,x = 'quality',y = 'sulphates',kind = 'bar')


# 
# *# *# '# '# '# i# f#  # w# e#  # i# n# c# r# e# a# s# e#  # t# h# e#  # s# u# l# p# h# a# t# e# s#  # o# f#  # a# l# c# o# h# o# l#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # w# i# n# e#  # i# s#  # a# l# s# o#  # i# n# c# r# e# s# e# '# '# '# 
# *# *

# In[None]

sns.catplot(data=dataset,kind = 'box')


# *# *# u# s# e# d#  # t# o#  # c# h# e# c# k#  # o# u# t# l# i# e# r#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t#  # t# h# e#  # v# a# l# u# e#  # t# h# a# t#  # a# r# e#  # o# u# t#  # o# f#  # b# o# x#  # a# n# d#  # f# a# r#  # f# r# o#  # I# Q# R#  # c# o# n# s# i# d# e# r#  # a# s#  # o# u# t# l# i# e# r# *# *

# In[None]

label_range_value  = (2, 6.5, 10)
class_name = ['bad', 'good']
dataset['quality'] = pd.cut(dataset['quality'], bins = label_range_value, labels = class_name)

# *# *# '# '# '#  # f# o# r#  # c# h# a# n# g# e#  #  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  #  # '# '# '# 
# *# *

# In[None]

X = dataset.iloc[:,0:11].values
y = dataset.iloc[:,11:12].values

# In[None]

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4842199.npy", { "accuracy_score": score })

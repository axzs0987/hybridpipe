import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
#print(os.listdir("../input")).

# In[None]

# Importing the dataset.
data = pd.read_csv('../input/Social_Network_Ads.csv')
data.head()

# In[None]

X = data.iloc[:, [2, 3]].values
y = data.iloc[:, 4].values

# In[None]

# Splitting the dataset into the Training set and Test set..
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3038169.npy", { "accuracy_score": score })

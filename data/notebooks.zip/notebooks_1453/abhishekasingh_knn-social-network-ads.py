import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
#sns.set_style('whitegrid')
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
social_data =pd.read_csv('/kaggle/input/social-network-ads/Social_Network_Ads.csv')
social_data.info()
social_data.head()
social_data.describe()
social_data.isna().sum()
#plt.figure(figsize=(12,7))
#sns.heatmap(social_data.isnull(),yticklabels=False,cbar=False,cmap='viridis')
X = social_data.iloc[:,[2,3]].values
X.shape
y = social_data.iloc[:,4].values
y.shape
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
print("Training Set of X:", len(X_train))
print("Testing Set of X:", len(X_test))
print("Training Set of y:", len(y_train))
print("Testing Set of y:", len(y_test))
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.fit_transform(X_test)
from sklearn.neighbors import KNeighborsClassifier
classifier = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
#classifier.fit(X_train,y_train)
#y_predict = classifier.predict(X_test)
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
#print(classification_report(y_test,y_predict))
#print(accuracy_score(y_test,y_predict))
#print(confusion_matrix(y_test,y_predict))
error_rate = []
for i in range(1,25):
    classifier = KNeighborsClassifier(n_neighbors=i)
#    classifier.fit(X_train,y_train)
#    pred_i = classifier.predict(X_test)
#    error_rate.append(np.mean(pred_i != y_test))
#plt.figure(figsize=(12,8))
#plt.plot(range(1,25),error_rate,color='blue', linestyle='dashed', marker='o', markerfacecolor='red', markersize=10)
#plt.title('Error Rate vs. K Value')
#plt.xlabel('K')
#plt.ylabel('Error Rate')



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/abhishekasingh_knn-social-network-ads.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekasingh_knn-social-network-ads/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekasingh_knn-social-network-ads/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekasingh_knn-social-network-ads/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekasingh_knn-social-network-ads/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/abhishekasingh_knn-social-network-ads/testY.csv",encoding="gbk")


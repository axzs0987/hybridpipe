import pandas as pd
# In[None]

#the usual suspects
import pandas as pd 
import matplotlib.pyplot as plt
import numpy as np

plt.style.use('ggplot')

# In[None]

X = pd.read_csv('../input/KaggleV2-May-2016.csv')
X.isnull().values.any()


# I#  # c# r# e# a# t# e# d#  # a#  # l# a# b# e# l#  # v# e# c# t# o# r#  # w# i# t# h#  # t# h# e#  # n# o# -# s# h# o# w#  # o# u# t# c# o# m# e# .#  # A# f# t# e# r# w# a# r# d# s#  # j# u# s# t#  # s# o# m# e#  # d# a# t# a#  # w# r# a# n# g# l# i# n# g# .

# In[None]

y = X['No-show']
y = y.map({'No': 0, 'Yes': 1})

X = X.drop(labels = ['No-show', 'PatientId', 'AppointmentID'], axis = 1)
X['Neighbourhood'] = X['Neighbourhood'].astype('category').cat.codes
X['Gender'] = X['Gender'].map({'M': 0, 'F': 1})

# S# o# m# e#  # m# o# r# e#  # d# a# t# a#  # w# r# a# n# g# l# i# n# g# .#  # I#  # o# p# t# e# d#  # t# o#  # s# e# e#  # h# o# w#  # m# a# n# y#  # h# o# u# r# s#  # p# a# s# s# e# d#  # b# e# t# w# e# e# n#  # t# h# e#  # s# c# h# e# l# u# e# d#  # d# a# y#  # a# n# d#  # t# h# e#  # a# p# p# o# i# n# t# m# e# n# t# .#  # 
# D# a# t# a#  # i# s#  # n# o# t#  # t# h# a# t#  # g# o# o# d#  # i# n#  # t# h# i# s#  # r# e# g# a# r# d#  # a# s#  # o# n# l# y#  # t# h# e#  # d# a# y#  # a# n# d#  # n# o# t#  # t# h# e#  # t# i# m# e#  # i# s#  # r# e# p# o# r# t# e# d#  # i# n#  # s# o# m# e#  # c# a# s# e# s# .

# In[None]

X['ScheduledDay'] = pd.to_datetime(X['ScheduledDay'])
X['AppointmentDay'] = pd.to_datetime(X['AppointmentDay'])

TimeDelta = X['ScheduledDay'] - X['AppointmentDay']
TimeDelta = TimeDelta / np.timedelta64(1, 'h')
TimeDelta = np.absolute(TimeDelta)

X = X.drop(labels = ['ScheduledDay', 'AppointmentDay'], axis = 1)
X = X.assign(TimeDelta = TimeDelta.values)


# H# o# w#  # d# o# e# s#  # o# u# r#  # d# a# t# a#  # l# o# o# k#  # n# o# w# ?

# In[None]

X.head(5)

# C# r# e# a# t# e#  # t# e# s# t#  # a# n# d#  # t# r# a# i# n# .

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/434771.npy", { "accuracy_score": score })

import pandas as pd
# ##  # G# e# n# d# e# r#  # R# e# c# o# g# n# i# t# i# o# n#  # f# r# o# m#  # v# o# i# c# e#  # u# s# i# n# g#  # D# e# e# p#  # L# e# a# r# n# i# n# g#  # A# n# d#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k# s

# ##  # *# *# *# *#  # A# I# M# *# *# *# *# 
# 1# .#  # T# o#  # b# u# i# l# d#  # n# e# u# r# a# l#  # n# e# t# w# o# r# k# s#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e#  # g# e# n# d# e# r#  # o# f#  # t# h# e#  # v# o# i# c# e#  # a# n# d#  # m# a# x# i# m# i# s# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # o# f#  # t# h# e#  # m# o# d# e# l# 
# 2# .#  # T# o#  # c# o# m# p# a# r# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # o# f#  # D# e# e# p#  # l# e# a# r# n# i# n# g# -# N# e# u# r# a# l#  # N# e# t# w# o# r# k#  # m# o# d# e# l#  # w# i# t# h#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # c# l# a# s# s# i# f# i# e# r# s

# B# e# f# o# r# e#  # w# e#  # d# i# v# e#  # i# n#  # l# e# t#  # m# e#  # g# i# v# e#  # a#  # b# r# i# e# f#  # o# f#  # w# h# a# t#  # w# e#  # a# r# e#  # u# p# t# o# .#  # W# e#  # h# a# v# e#  # a#  # d# a# t# a# s# e# t#  # w# h# i# c# h#  # b# a# s# e# d#  # o# n#  # c# e# r# t# a# i# n#  # p# a# r# a# m# a# t# e# r# s#  # c# l# a# s# s# i# f# i# e# s#  # a#  # v# o# i# c# e#  # b# a# s# e# d#  # o# n#  # g# e# n# d# e# r# .#  # H# o# w#  # d# o#  # h# u# m# a# n# s#  # d# o#  # i# t# ?# 
# 
#  #  #  #  # S# o# u# n# d#  # w# a# v# e# s#  # t# r# a# v# e# l#  # i# n# t# o#  # t# h# e#  # e# a# r#  # c# a# n# a# l#  # u# n# t# i# l#  # t# h# e# y#  # r# e# a# c# h#  # t# h# e#  # e# a# r# d# r# u# m# .#  # T# h# e#  # e# a# r# d# r# u# m#  # p# a# s# s# e# s#  # t# h# e#  # v# i# b# r# a# t# i# o# n# s#  # t# h# r# o# u# g# h#  # t# h# e#  # m# i# d# d# l# e#  # e# a# r#  # b# o# n# e# s#  # o# r#  # o# s# s# i# c# l# e# s#  # i# n# t# o#  # t# h# e#  # i# n# n# e# r#  # e# a# r# .#  # T# h# e#  # i# n# n# e# r#  # e# a# r#  # i# s#  # s# h# a# p# e# d#  # l# i# k# e#  # a#  # s# n# a# i# l#  # a# n# d#  # i# s#  # a# l# s# o#  # c# a# l# l# e# d#  # t# h# e#  # c# o# c# h# l# e# a# .#  # I# n# s# i# d# e#  # t# h# e#  # c# o# c# h# l# e# a# ,#  # t# h# e# r# e#  # a# r# e#  # t# h# o# u# s# a# n# d# s#  # o# f#  # t# i# n# y#  # h# a# i# r#  # c# e# l# l# s# .#  # H# a# i# r#  # c# e# l# l# s#  # c# h# a# n# g# e#  # t# h# e#  # v# i# b# r# a# t# i# o# n# s#  # i# n# t# o#  # e# l# e# c# t# r# i# c# a# l#  # s# i# g# n# a# l# s#  # t# h# a# t#  # a# r# e#  # s# e# n# t#  # t# o#  # t# h# e#  # b# r# a# i# n#  # t# h# r# o# u# g# h#  # t# h# e#  # h# e# a# r# i# n# g#  # n# e# r# v# e# .#  # T# h# e#  # b# r# a# i# n#  # t# e# l# l# s#  # y# o# u#  # t# h# a# t#  # y# o# u#  # a# r# e#  # h# e# a# r# i# n# g#  # a#  # s# o# u# n# d#  # a# n# d#  # w# h# a# t#  # t# h# a# t#  # s# o# u# n# d#  # i# s# .# 
# 
# W# h# a# t#  # h# a# p# p# e# n# s#  # i# n#  # t# h# e#  # b# r# a# i# n#  # i# s#  # n# e# u# r# o# n# s#  # p# e# r# f# o# r# m#  # c# e# r# t# a# i# n#  # o# p# e# r# a# t# i# o# n# s#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e#  # s# o# u# n# d# ,#  # t# h# i# s#  # i# s#  # e# x# a# c# t# l# y#  # w# h# a# t#  # w# e#  # w# i# l# l#  # b# e#  # t# r# y# i# n# g#  # t# o#  # s# i# m# u# l# a# t# e# .#  

# In[None]

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# ##  # S# t# e# p#  # 1# 
# I# m# p# o# r# t#  # t# h# e#  # l# i# b# r# a# r# i# e# s# 
# 1# .#  # m# a# t# p# l# o# t# l# i# b#  # :# :#  # T# o#  # p# l# o# t#  # g# r# a# p# h# s#  # 
# 2# .#  # n# u# m# p# y#  # :# :#  # T# o#  # p# e# r# f# o# r# m#  # o# p# e# r# a# t# i# o# n# s#  # a# n# d#  # m# a# n# i# p# u# l# a# t# e#  # a# r# r# a# y# s#  # 
# 3# .#  # p# a# n# d# a# s#  # :# :#  # T# o#  # r# e# a# d#  # a# n# d#  # m# a# n# a# g# e#  # t# h# e#  # d# a# t# a#  # f# r# o# m#  # t# h# e#  # f# i# l# e# 
# 4# .#  # I# m# p# o# r# t#  # M# L#  # b# a# s# i# c#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l# s#  # :# :#  # f# r# o# m#  # s# k# l# e# a# r# n#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# 5# .#  # I# m# p# o# r# t#  # N# e# u# r# a# l#  # n# e# t# w# o# r# k#  # b# u# i# l# d# i# n# g#  # l# i# b# r# a# r# i# e# s#  # :# :#  # f# r# o# m#  # k# e# r# a# s

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pylab as pl

from sklearn import model_selection
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import sklearn.metrics as metrics
from mpl_toolkits.mplot3d import Axes3D

#Ignore  the warnings
import warnings
warnings.filterwarnings('always')
warnings.filterwarnings('ignore')

#plotting missing data
import missingno as msno

#classification models
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB

#Neural network building libraries
import keras
from keras.layers import Dense
from keras.models import Sequential
from keras.callbacks import History 
from keras.utils import plot_model
from keras.optimizers import SGD

# ##  # S# t# e# p#  # 2# 
# L# o# a# d# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # a# n# d#  # p# e# r# f# o# r# m# i# n# g#  # E# D# A#  # (# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# )#  # o# v# e# r#  # t# h# e#  # d# a# t# a# s# e# t# .#  # 
# T# o#  # a# n# a# l# y# s# e#  # a# n# d#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # i# t# s#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# a# r# g# e# t#  # c# l# a# s# s# e# s

# In[None]

voice=pd.read_csv("../input/voicegender/voice.csv")
voice.head(5)

# In[None]

print("\n",voice.info())

# In[None]

voice.describe()

# In[None]

#visualizing no missing value.
msno.matrix(voice)

# *# *# S# h# o# w# s#  # n# o#  # n# u# l# l#  # v# a# l# u# e# s#  # s# o#  # c# l# e# a# n# i# n# g#  # n# o# t#  # r# e# q# u# i# r# e# d# *# *

# In[None]

#creating a copy
data=voice.copy()

# In[None]

# Distribution of target varibles
# colors = ['pink','Lightblue']
df = data[data.columns[-1]]
# plt.pie(df.value_counts(),colors=colors,labels=['female','male'])
# plt.axis('equal')
# print (data['label'].value_counts())

# In[None]

#Radviz circle 
#Good to compare every feature
# pd.plotting.radviz(data,"label")

# In[None]

# Pairplotting
# sns.pairplot(data[['meanfreq', 'Q25', 'Q75',
#                 'skew', 'centroid', 'label']], 
#                  hue='label', size=2)

# In[None]

data.drop('label' ,axis=1).hist(bins=30, figsize=(12,12))
# pl.suptitle("Histogram for each numeric input variable")
# plt.show()

# In[None]

#corelation matrix.
# cor_mat= data[:].corr()
# mask = np.array(cor_mat)
# mask[np.tril_indices_from(mask)] = False
# fig=plt.gcf()
# fig.set_size_inches(15,15)
# sns.heatmap(data=cor_mat,square=True,annot=True,cbar=True,cmap='Spectral')

# I# n#  # t# h# i# s#  # s# e# c# t# i# o# n#  # t# h# e#  # c# o# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # f# e# a# t# u# r# e# s#  # i# s#  # a# n# a# l# y# z# e# d# .#  # '# H# e# a# t#  # m# a# p# '#  # i# s#  # p# l# o# t# t# e# d#  # w# h# i# c# h#  # c# l# e# a# r# l# y#  # v# i# s# u# l# i# z# e# s#  # t# h# e#  # c# o# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # f# e# a# t# u# r# e# s

# ##  # S# t# e# p#  # 3# 
# 
# N# o# w#  # s# i# n# c# e#  # w# e#  # h# a# v# e#  # t# h# e#  # f# e# a# t# u# r# e#  # s# e# t#  # a# n# d#  # t# h# e#  # s# e# t#  # o# f#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# ,#  # W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e#  # '# l# a# b# e# l# '#  # h# a# s#  # s# t# r# i# n# g# s#  # a# n# d#  # i# n#  # m# a# t# h# s#  # w# e#  # n# e# e# d#  # v# a# l# u# e# s#  # s# o#  #  # w# e#  # w# i# l# l#  # c# o# n# v# e# r# t#  # i# t#  # t# o#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # M# a# l# e# =# 1#  # a# n# d#  # F# e# m# a# l# e# =# 0

# In[None]

# Convert string label to float : male = 1, female = 0
dict = {'label':{'male':1,'female':0}}      # label = column name
data.replace(dict,inplace = True)           # replace = str to numerical
x = data.loc[:, data.columns != 'label']
y = data.loc[:,'label']

# ##  # S# t# e# p#  # 4# 
# W# e#  # n# e# e# d#  # t# o#  # s# e# p# a# r# a# t# e#  # t# h# e#  # d# e# p# e# n# d# e# n# t#  # a# n# d#  # i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# .#  # H# e# r# e#  # t# h# e#  # f# i# r# s# t#  # 2# 0#  # s# e# t#  # c# o# l# u# m# n# s#  # c# o# n# s# i# s# t# s#  # o# f#  # t# h# e#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# h# e#  # l# a# s# t#  # c# o# l# o# u# m# n#  # i# s#  # t# h# e#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# ,#  # w# h# i# c# h#  # t# a# k# e# s#  # t# w# o#  # i# n# t# e# g# e# r#  # v# a# l# u# e# s#  # i# .# e#  # 1#  # (# M# a# l# e# )#  # a# n# d#  # 0#  # (# F# e# m# a# l# e# )# 
# 
# X#  # a# s#  # f# e# a# t# u# r# e#  # c# o# l# u# m# n# s#  # a# n# d#  # Y#  # a# s#  # d# e# p# e# n# d# e# n# t#  # c# o# l# u# m# n

# In[None]

array = data.values
X = array[:,0:20]
Y = array[:,20]

# ##  # S# t# e# p#  # 5# 
# 
# D# i# v# i# d# e#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # s# e# t#  # a# n# d#  # t# e# s# t#  # s# e# t# ,#  # O# n# e#  # s# e# t#  # t# o#  # t# r# a# i# n#  # t# h# e#  # n# e# u# r# a# l#  # N# e# t# w# o# r# k#  # a# n# d#  # t# h# e#  # o# t# h# e# r#  # s# e# t#  # t# o#  # t# e# s# t#  # t# h# e#  # n# e# u# r# a# l#  # n# e# t# w# o# r# k# .#  

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10060587.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle as pkl
from sklearn.preprocessing import StandardScaler,MinMaxScaler

# In[None]

df = pd.read_csv("/kaggle/input/predicting-a-pulsar-star/pulsar_stars.csv")
df.columns = [x.strip().lower() for x in df.columns.values]
df.head()

# In[None]

df.columns.values

# In[None]

def preprocess(df):
    df['mean of the integrated profile'] = df['mean of the integrated profile'].apply(lambda x : 25 if x<=25 else x)
    df['standard deviation of the integrated profile'] = df['standard deviation of the integrated profile'].apply(lambda x : 75 if x>=75 else x)
    df['excess kurtosis of the integrated profile'] = df['excess kurtosis of the integrated profile'].apply(lambda x : 2 if x>=2 else x)
    df['mean of the dm-snr curve'] = df['mean of the dm-snr curve'].apply(lambda x : 12 if x>=12 else x)
    df['standard deviation of the dm-snr curve'] = df['standard deviation of the dm-snr curve'].apply(lambda x : 70 if x>=70 else x)
    df['excess kurtosis of the dm-snr curve'] = df['excess kurtosis of the dm-snr curve'].apply(lambda x : 25 if x>=25 else x)
    df['skewness of the dm-snr curve'] = df['skewness of the dm-snr curve'].apply(lambda x : 450 if x>=450 else x)
    return df

def scaling(df,scaler=None):
    if scaler==None:
        sc = StandardScaler()
        sc.fit(df)
        df = sc.transform(df)
        pkl.dump(sc,open("pulsar_scaler.pkl",'wb'))
    else:
        df = scaler.transform(df)
    return df

# In[None]

corr = df.corr()
corr

# In[None]

y = df['target_class']
X = df.drop(columns=['target_class'])

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6891154.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import preprocessing


# plotly library
import plotly.graph_objs as go
from plotly import tools
from plotly.offline import init_notebook_mode, iplot

# In[None]

data=pd.read_csv('../input/indian-liver-patient-records/indian_liver_patient.csv')
data.head()

# In[None]

data.info()

# S# o#  # f# r# o# m#  # a# b# o# v# e#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # w# e#  # h# a# v# e#  # o# n# l# y#  # o# n# e#  # c# o# l# u# m# n#  # t# h# a# t#  # i# s#  # c# a# t# e# g# o# r# i# c# a# l# .#  # S# o#  # w# e#  # w# i# l# l#  # c# o# n# v# e# r# t#  # i# n# t# o#  # n# u# m# e# r# i# c# a# l#  # i# n#  # n# e# x# t#  # o# n# e# .

# In[None]

male=pd.get_dummies(data['Gender'],drop_first=True)
male.head()

# S# o#  # u# s# i# n# g#  # p# d# .# g# e# t# _# d# u# m# m# i# e# s# (# )#  # w# e#  # c# r# e# a# t# e#  # a#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e#  # f# o# r#  # m# a# l# e#  # a# n# d#  # i# t#  # g# o# t#  # c# o# n# v# e# r# t# e# d#  # i# n# t# o#  # n# u# m# e# r# i# c# a# l# .# 
# N# o# w#  # w# e#  # w# i# l# l#  # c# o# n# c# a# t#  # t# h# i# s#  # i# n#  # t# h# e#  # o# r# i# g# i# n# a# l#  # d# a# t# a# f# r# a# m# e#  # a# n# d#  # d# r# o# p#  # t# h# e#  # g# e# n# d# e# r#  # v# a# r# i# a# b# l# e# .

# In[None]

data=pd.concat([data,male],axis=1)
data.drop('Gender',axis=1,inplace=True)
data.head()

# N# o# w#  # w# e# '# l# l#  # c# h# e# c# k#  # f# o# r#  # n# u# l# l#  # v# a# l# u# e# .# I# n#  # t# h# e#  # n# e# x# t#  # s# t# e# p

# In[None]

data.isnull().sum()

# S# o#  # f# r# o# m#  # h# e# r# e#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # 4#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # A# L# b# u# m# i# n# _# a# n# d# _# G# l# o# b# u# l# i# n# _# R# a# t# i# o#  # c# o# l# u# m# n#  # a# n# d#  # i# t# '# s#  # o# f#  # f# l# o# a# t#  # t# y# p# e#  # s# o#  # w# e#  # c# a# n#  # r# e# p# l# a# c# e#  # i# t#  # f# r# o# m#  # t# h# e#  # m# e# a# n#  # o# f#  # t# h# a# t#  # c# o# l# u# m# n# .#  

# In[None]

data['Albumin_and_Globulin_Ratio']=data['Albumin_and_Globulin_Ratio'].fillna(data['Albumin_and_Globulin_Ratio'].mean())
data.isnull().sum()

# N# o# w#  # w# e# '# l# l#  # c# h# e# c# k#  # f# o# r#  # t# h# e#  # o# u# t# l# i# e# r# .

# In[None]

data.plot(kind='box',figsize=(25,10),subplots=True,layout=(3,4))

# In[None]

data.columns

# In[None]

sns.countplot(data['Male'],hue=data['Dataset'])

# In[None]

sns.barplot(data=data, x='Male', y='Total_Bilirubin', hue='Dataset')

# In[None]

sns.barplot(data=data, x='Male', y='Direct_Bilirubin', hue='Dataset')

# In[None]

plt.figure(figsize=(11,6))
sns.heatmap(data.corr(),annot=True,linewidths=1.5)

# W# e#  # c# a# n#  # s# e# e#  # f# r# o# m#  # a# b# o# v# e#  # t# h# e#  # A# l# b# u# m# i# n#  # a# n# d#  # T# o# t# a# l# _# P# r# o# t# e# i# n# s# ,#  # A# l# b# u# m# i# n#  # a# n# d#  # A# l# b# u# m# i# n# _# a# n# d# _# G# l# o# b# u# l# i# n# _# R# a# t# i# o#  # a# r# e#  # h# i# g# h# l# y#  # c# o# r# r# e# l# a# t# e# d#  # s# o#  # w# e# '# l# l#  # d# r# o# p#  # t# h# o# s# e#  # c# o# l# u# m# n# s#  # w# h# i# c# h#  # a# r# e#  # l# e# s# s#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h# t#  # t# h# e#  # d# a# t# a# s# e# t#  # t# o#  # a# v# o# i# d#  # m# u# l# t# i# c# o# l# l# i# n# e# a# r# i# t# y# .

# In[None]

plt.figure(figsize=(11,6))
sns.scatterplot(data=data,x='Albumin',y='Total_Protiens',hue='Dataset')

# In[None]

plt.figure(figsize=(11,6))
sns.scatterplot(data=data,x='Albumin',y='Albumin_and_Globulin_Ratio',hue='Dataset')

# In[None]

data['all_albumin']=data['Albumin']+data['Albumin_and_Globulin_Ratio']
data['all_albumin'].corr(data['Dataset'])

# In[None]

data.columns

# In[None]

plt.figure(figsize=(11,6))
sns.scatterplot(data=data,x='Direct_Bilirubin',y='Total_Bilirubin',hue='Dataset')

# In[None]

data['total_bilrubin']=data['Direct_Bilirubin']-data['Total_Bilirubin']
data['total_bilrubin'].corr(data['Dataset'])

# In[None]

data.columns

# In[None]

drop_all=['Albumin','Albumin_and_Globulin_Ratio','Direct_Bilirubin','Total_Bilirubin']
data.drop(drop_all,axis=1,inplace=True)
data.columns

# In[None]

plt.figure(figsize=(11,6))
sns.lineplot(data=data,x='Alamine_Aminotransferase',y= 'Aspartate_Aminotransferase',hue='Dataset',palette="Paired")

# S# o#  # f# r# o# m#  # a# b# o# v# e#  # w# e#  # c# a# n#  # d# r# o# p#  # o# u# t# l# i# e# r# s#  # i# .# e#  # a# f# t# e# r#  # 1# 2# 5# 0# .

# In[None]

data=data.drop(data[(data['Alamine_Aminotransferase']>1250) & (data['Aspartate_Aminotransferase']<3500)].index)

# In[None]

data.isnull().sum()

# In[None]

plt.figure(figsize=(11,6))
sns.heatmap(data.corr(),annot=True)

# S# o#  # a# b# o# v# e#  # w# e#  # c# a# n#  # s# e# e#  # t# h# e# r# e#  # i# s#  # a#  # s# k# e# w# n# e# s# s#  # i# n#  # t# h# e#  # d# a# t# a#  # .# S# o#  # i# n#  # t# h# e#  # n# e# x# t#  # s# t# e# p#  # w# e#  # c# a# n#  # u# s# e#  # l# o# g#  # t# r# a# n# f# o# r# m# a# t# i# o# n#  # t# o#  # r# e# d# u# c# e#  # t# h# e#  # s# k# e# w# n# e# s# s# .# 
# H# e# r# e#  # w# e#  # a# r# e#  # c# h# o# o# s# i# n# g#  # t# h# e#  # l# o# g#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n#  # b# e# c# a# u# s# e#  # i# t#  # g# i# v# e# s#  # m# o# r# e#  # b# e# t# t# e# r#  # r# e# s# u# l# t#  # t# h# a# n#  # s# q# u# a# r# e#  # a# n# d#  # c# u# b# e# .

# In[None]

X=data.drop('Dataset',axis=1)
y=data['Dataset']

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7194425.npy", { "accuracy_score": score })

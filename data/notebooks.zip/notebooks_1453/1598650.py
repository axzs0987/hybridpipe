import pandas as pd
# In[None]

import numpy as np 
import pandas as pd 
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn import metrics
import matplotlib.pyplot as plt
import math 
from patsy import dmatrices 

data = pd.read_csv("../input/HR_comma_sep.csv")
data.head()

# In[None]

data.corr()['left']

# In[None]

tmp=pd.crosstab(data.time_spend_company,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)


# In[None]

tmp=pd.crosstab(data.number_project,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)

# In[None]

#把average monthly hours变成离散的bin, 以便分析monthly hours跟left的关系
data['avg_hours_level'] = pd.qcut( data['average_montly_hours'], 15 , labels=range(15))
tmp=pd.crosstab(data.avg_hours_level,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)

# In[None]

#把average monthly hours变成离散的bin, 以便分析monthly hours跟left的关系
data['satisfaction_level_discrete'] = pd.qcut( data['satisfaction_level'], 15 , labels=range(15))
tmp=pd.crosstab(data.avg_hours_level,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)

# In[None]

data['last_evaluation_level'] = pd.qcut( data['last_evaluation'], 15 , labels=range(15))
tmp=pd.crosstab(data.last_evaluation_level,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)

# In[None]

tmp=pd.crosstab(data.time_spend_company,data.left)
tmp.div(tmp.sum(1),axis=0).plot(kind='bar',stacked=True)

# In[None]

Y, X = dmatrices('left~C(satisfaction_level_discrete)+C(number_project)+C(avg_hours_level)+C(time_spend_company)+C(last_evaluation_level)+Work_accident+promotion_last_5years+C(salary)+C(sales)', data, return_type='dataframe')
Y=np.ravel(Y)
X=np.asmatrix(X)
from sklearn.model_selection import train_test_split
xtrain, xvali, ytrain, yvali = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xvali)
score = accuracy_score(yvali, y_pred)
import numpy as np
np.save("prenotebook_res/1598650.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

import pandas as pd

# In[None]

dataset = pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

dataset.head()

# In[None]

dataset.shape

# In[None]

dataset.info()

# In[None]

dataset.describe()
#In the below you can see there are outliers present in the dataset. Let's say for total sulfur dioxide, 75% percent of data is below 62 and max is 289

# In[None]

dataset.isnull().sum()

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt
dataset.hist(bins = 50, figsize = (16,10))
#checking the distribution
#dataset.plot(kind = 'box',subplots = True,layout = (4,3),figsize = (16,10))

# In[None]

#There is a outlier present checking with the boxplot
sns.boxplot(dataset['total sulfur dioxide'])

# In[None]

from scipy import stats

# In[None]

z = np.abs(stats.zscore(dataset))
filtered_entries = (z < 3).all(axis=1)
new_df = dataset[filtered_entries]

# In[None]

new_df.shape
#1599

# In[None]

(1599-1322)/1599
#17% percent of the dataset are outliers so it wont be a good idea to elimate the outliers

# In[None]

correlation = dataset.corr()
correlation['quality']

# In[None]

plt.figure(figsize = (15,8))
sns.heatmap(correlation,annot = True)

# In[None]

dataset.quality.value_counts()

# In[None]

bins = (2, 6.5, 8)
group_names = ['bad', 'good']
dataset['quality'] = pd.cut(dataset['quality'], bins = bins, labels = group_names)

# In[None]

sns.countplot(dataset.quality)

# In[None]

X= dataset.iloc[:,:-1]
y= dataset.iloc[:,-1]


# In[None]

from sklearn.preprocessing import LabelEncoder
label_quality = LabelEncoder()
y =label_quality.fit_transform(y)



# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10551253.npy", { "accuracy_score": score })

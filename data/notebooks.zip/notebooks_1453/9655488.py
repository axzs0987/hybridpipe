import pandas as pd
# 
# <# f# o# n# t#  # c# o# l# o# r# =# '# b# l# a# c# k# '# ># 
# ##  # C# o# n# t# e# n# t# :# 
# *#  #  # [# I# n# t# r# o# d# u# c# t# i# o# n# ]# (# ## 1# )# 
#  #  #  #  # 
# *#  #  # [# D# a# t# a#  # S# e# t# ]# (# ## 2# )# 
# 
#  #  #  #  # *#  # [# L# o# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# ]# (# ## 2# )# 
#  #  #  #  # *#  # [# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# ]# (# ## 3# )# 
#  #  #  #  # *#  # [# M# i# s# s# i# n# g#  # V# a# l# u# e# s#  # T# r# e# a# t# m# e# n# t# ]# (# ## 4# )# 
#  #  #  #  # *#  # [# V# i# s# u# a# l# i# z# a# t# i# o# n# ]# (# ## 5# )# 
#  #  #  #  # 
#  #  #  #  # 
# *#  #  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## 6# )# 
# 
#  #  #  #  # *#  # [# P# r# e# p# r# o# c# e# s# s# i# n# g# :#  # L# a# b# e# l#  # e# n# c# o# d# e# r#  # a# n# d#  # N# o# r# m# a# l# i# z# a# t# i# o# n# ]# (# ## 7# )# 
#  #  #  #  # *#  # [# T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# ]# (# ## 8# )# 
#  #  #  #  # *#  # [# P# a# r# a# m# e# t# e# r#  # I# n# i# t# i# a# l# i# z# e#  # a# n# d#  # S# i# g# m# o# i# d#  # F# u# n# c# t# i# o# n# ]# (# ## 9# )# 
#  #  #  #  # *#  # [# F# o# r# w# a# r# d#  # a# n# d#  # B# a# c# k# w# a# r# d#  # P# r# o# p# o# g# a# r# i# o# n#  # C# o# m# b# i# n# e# d# ]# (# ## 1# 0# )# 
#  #  #  #  # *#  # [# G# r# a# d# i# e# n# t#  # D# e# c# e# n# t#  # f# o# r#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## 1# 1# )# 
#  #  #  #  # *#  # [# P# r# e# d# i# c# t# i# o# n# ]# (# ## 1# 2# )# 
#  #  #  #  # *#  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # M# a# t# h# ]# (# ## 1# 3# )# 
#  #  #  #  # *#  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # S# k# l# e# a# r# n# ]# (# ## 1# 4# )

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 1# '# ># <# /# a# ># 
# ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# D# e# t# e# r# m# i# n# i# n# g#  # a#  # p# e# r# s# o# n# ’# s#  # g# e# n# d# e# r#  # a# s#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e# ,#  # b# a# s# e# d#  # u# p# o# n#  # a#  # s# a# m# p# l# e#  # o# f#  # t# h# e# i# r#  # v# o# i# c# e#  # s# e# e# m# s#  # t# o#  # i# n# i# t# i# a# l# l# y#  # b# e#  # a# n#  # e# a# s# y#  # t# a# s# k# .#  # O# f# t# e# n# ,#  # t# h# e#  # h# u# m# a# n#  # e# a# r#  # c# a# n#  # e# a# s# i# l# y#  # d# e# t# e# c# t#  # t# h# e#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # a#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e#  # v# o# i# c# e#  # w# i# t# h# i# n#  # t# h# e#  # f# i# r# s# t#  # f# e# w#  # s# p# o# k# e# n#  # w# o# r# d# s# .#  # H# o# w# e# v# e# r# ,#  # d# e# s# i# g# n# i# n# g#  # a#  # c# o# m# p# u# t# e# r#  # p# r# o# g# r# a# m#  # t# o#  # d# o#  # t# h# i# s#  # t# u# r# n# s#  # o# u# t#  # t# o#  # b# e#  # a#  # b# i# t#  # t# r# i# c# k# i# e# r# .# 
# 
# T# h# e#  # m# o# d# e# l#  # i# s#  # c# o# n# s# t# r# u# c# t# e# d#  # u# s# i# n# g#  # 3# ,# 1# 6# 8#  # r# e# c# o# r# d# e# d#  # s# a# m# p# l# e# s#  # o# f#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # v# o# i# c# e# s# ,#  # s# p# e# e# c# h# ,#  # a# n# d#  # u# t# t# e# r# a# n# c# e# s# .#  # T# h# e#  # s# a# m# p# l# e# s#  # a# r# e#  # p# r# o# c# e# s# s# e# d#  # u# s# i# n# g#  # a# c# o# u# s# t# i# c#  # a# n# a# l# y# s# i# s#  # a# n# d#  # t# h# e# n#  # a# p# p# l# i# e# d#  # t# o#  # a# n#  # a# r# t# i# f# i# c# i# a# l#  # i# n# t# e# l# l# i# g# e# n# c# e# /# m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # t# o#  # l# e# a# r# n#  # g# e# n# d# e# r# -# s# p# e# c# i# f# i# c#  # t# r# a# i# t# s# .# 
# 
# -# -# -# 
# 
# ## ## ## ##  # A#  # s# h# o# r# t#  # d# e# s# c# r# i# p# t# i# o# n#  # a# s#  # o# n#  # '# D# a# t# a# '#  # t# a# b#  # o# n#  # k# a# g# g# l# e#  # i# s#  # :# 
# 
# m# e# a# n# f# r# e# q# :#  # m# e# a# n#  # f# r# e# q# u# e# n# c# y#  # (# i# n#  # k# H# z# )# 
# 
# s# d# :#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # f# r# e# q# u# e# n# c# y# 
# 
# m# e# d# i# a# n# :#  # m# e# d# i# a# n#  # f# r# e# q# u# e# n# c# y#  # (# i# n#  # k# H# z# )# 
# 
# Q# 2# 5# :#  # f# i# r# s# t#  # q# u# a# n# t# i# l# e#  # (# i# n#  # k# H# z# )# 
# 
# Q# 7# 5# :#  # t# h# i# r# d#  # q# u# a# n# t# i# l# e#  # (# i# n#  # k# H# z# )# 
# 
# I# Q# R# :#  # i# n# t# e# r# q# u# a# n# t# i# l# e#  # r# a# n# g# e#  # (# i# n#  # k# H# z# )# 
# 
# s# k# e# w# :#  # s# k# e# w# n# e# s# s#  # (# s# e# e#  # n# o# t# e#  # i# n#  # s# p# e# c# p# r# o# p#  # d# e# s# c# r# i# p# t# i# o# n# )# 
# 
# k# u# r# t# :#  # k# u# r# t# o# s# i# s#  # (# s# e# e#  # n# o# t# e#  # i# n#  # s# p# e# c# p# r# o# p#  # d# e# s# c# r# i# p# t# i# o# n# )# 
# 
# s# p# .# e# n# t# :#  # s# p# e# c# t# r# a# l#  # e# n# t# r# o# p# y# 
# 
# s# f# m# :#  # s# p# e# c# t# r# a# l#  # f# l# a# t# n# e# s# s# 
# 
# m# o# d# e# :#  # m# o# d# e#  # f# r# e# q# u# e# n# c# y# 
# 
# c# e# n# t# r# o# i# d# :#  # f# r# e# q# u# e# n# c# y#  # c# e# n# t# r# o# i# d#  # (# s# e# e#  # s# p# e# c# p# r# o# p# )# 
# 
# p# e# a# k# f# :#  # p# e# a# k#  # f# r# e# q# u# e# n# c# y#  # (# f# r# e# q# u# e# n# c# y#  # w# i# t# h#  # h# i# g# h# e# s# t#  # e# n# e# r# g# y# )# 
# 
# m# e# a# n# f# u# n# :#  # a# v# e# r# a# g# e#  # o# f#  # f# u# n# d# a# m# e# n# t# a# l#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# i# n# f# u# n# :#  # m# i# n# i# m# u# m#  # f# u# n# d# a# m# e# n# t# a# l#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# a# x# f# u# n# :#  # m# a# x# i# m# u# m#  # f# u# n# d# a# m# e# n# t# a# l#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# e# a# n# d# o# m# :#  # a# v# e# r# a# g# e#  # o# f#  # d# o# m# i# n# a# n# t#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# i# n# d# o# m# :#  # m# i# n# i# m# u# m#  # o# f#  # d# o# m# i# n# a# n# t#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# a# x# d# o# m# :#  # m# a# x# i# m# u# m#  # o# f#  # d# o# m# i# n# a# n# t#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# d# f# r# a# n# g# e# :#  # r# a# n# g# e#  # o# f#  # d# o# m# i# n# a# n# t#  # f# r# e# q# u# e# n# c# y#  # m# e# a# s# u# r# e# d#  # a# c# r# o# s# s#  # a# c# o# u# s# t# i# c#  # s# i# g# n# a# l# 
# 
# m# o# d# i# n# d# x# :#  # m# o# d# u# l# a# t# i# o# n#  # i# n# d# e# x# .#  # C# a# l# c# u# l# a# t# e# d#  # a# s#  # t# h# e#  # a# c# c# u# m# u# l# a# t# e# d#  # a# b# s# o# l# u# t# e#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # a# d# j# a# c# e# n# t#  # m# e# a# s# u# r# e# m# e# n# t# s#  # o# f#  # f# u# n# d# a# m# e# n# t# a# l#  # f# r# e# q# u# e# n# c# i# e# s#  # d# i# v# i# d# e# d#  # b# y#  # t# h# e#  # f# r# e# q# u# e# n# c# y#  # r# a# n# g# e# 
# 
# l# a# b# e# l# :#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e# 
# 
# N# o# t# e#  # t# h# a# t#  # w# e#  # h# a# v# e#  # 3# 1# 6# 8#  # v# o# i# c# e#  # s# a# m# p# l# e# s#  # a# n# d#  # f# o# r#  # e# a# c# h#  # o# f#  # s# a# m# p# l# e#  # 2# 0#  # d# i# f# f# e# r# e# n# t#  # a# c# o# u# s# t# i# c#  # p# r# o# p# e# r# t# i# e# s#  # a# r# e#  # r# e# c# o# r# d# e# d# .#  # F# i# n# a# l# l# y#  # t# h# e#  # '# l# a# b# e# l# '#  # c# o# l# u# m# n#  # i# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # w# h# i# c# h#  # w# e#  # h# a# v# e#  # t# o#  # p# r# e# d# i# c# t#  # w# h# i# c# h#  # i# s#  # t# h# e#  # g# e# n# d# e# r#  # o# f#  # t# h# e#  # p# e# r# s# o# n# *# *# *# *# 


# -# -# -# 
# 
# <# h# 2# ># <# c# e# n# t# e# r# ># I# m# p# o# r# t# i# n# g#  # V# a# r# i# o# u# s#  # M# o# d# u# l# e# s# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# -# -# -

# In[None]


import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import missingno as msno
import warnings
warnings.filterwarnings("ignore")

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))


# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 2# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># L# o# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# 
# -# -# -

# In[None]

data_voice = pd.read_csv("/kaggle/input/voicegender/voice.csv")

data = data_voice.copy()

data.tail()

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 3# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# -# -# -

# In[None]

data.describe().T

# In[None]

data.corr()

# In[None]

data.info()

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 4# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># M# i# s# s# i# n# g#  # V# a# l# u# e# s#  # T# r# e# a# t# m# e# n# t# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# -# -# -

# In[None]

data.isnull().sum()

# <# h# 2# ># <# c# e# n# t# e# r# ># M# i# s# s# i# n# g#  # d# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n# <# /# c# e# n# t# e# r# ># <# /# h# 2# >

# In[None]

msno.matrix(data)
plt.show()

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 5# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># V# i# s# u# a# l# i# z# a# t# i# o# n# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# -# -# -

# In[None]

plt.subplots(4,5,figsize=(15,15))
for i in range(1,21):
    plt.subplot(4,5,i)
    plt.title(data.columns[i-1])
    sns.kdeplot(data.loc[data['label'] == "female", data.columns[i-1]], color= 'red', label='Female')
    sns.kdeplot(data.loc[data['label'] == "male", data.columns[i-1]], color= 'blue', label='Male')

# -# -# -# 
# *#  # M# o# s# t#  # s# i# g# n# i# f# i# c# a# n# t#  # f# e# a# t# u# r# e# s#  # a# r# e#  # Q# 2# 5# ,#  # I# Q# R#  # a# n# d#  # m# e# a# n# f# u# n# .#  # W# e#  # w# i# l# l#  # b# u# i# l# d#  # m# o# d# e# l# s#  # b# y#  # u# s# i# n# g#  # t# h# e#  # 2# 0#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# h# e#  # 3#  # d# i# s# t# i# n# c# t#  # f# e# a# t# u# r# e# s# 
# *#  # W# e#  # w# i# l# l#  # p# l# o# t#  # f# e# m# a# l# e#  # a# n# d#  # m# a# l# e#  # c# l# a# s# s# e# s#  # a# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e# i# r#  # m# e# a# n# f# u# n# (# X# )# ,#  # I# Q# R# (# Y# )# ,#  # a# n# d#  # Q# 2# 5# (# Z# )# .# 
# -# -# -

# In[None]

# import data again to avoid confusion

import plotly.graph_objs as go
from plotly.offline import init_notebook_mode, iplot
data_voice = pd.read_csv("/kaggle/input/voicegender/voice.csv")
data = data_voice.copy()

male = data[data.label == "male"]

female = data[data.label == "female"]

# trace1
trace1 = go.Scatter3d(
    x=male.meanfun,
    y=male.IQR,
    z=male.Q25,
    mode='markers',
    name = "MALE",
    marker=dict(
        color='rgb(54, 170, 127)',
        size=12,
        line=dict(
            color='rgb(204, 204, 204)',
            width=0.1
        )
    )
)

trace2 = go.Scatter3d(
    x=female.meanfun,
    y=female.IQR,
    z=female.Q25,
    mode='markers',
    name = "FEMALE",
    marker=dict(
        color='rgb(217, 100, 100)',
        size=12,
        line=dict(
            color='rgb(255, 255, 255)',
            width=0.1
        )
    )
)

data1 = [trace1, trace2]
layout = go.Layout(
    title = ' 3D VOICE DATA ',
    margin=dict(
        l=0,
        r=0,
        b=0,
        t=0
    )
)
fig = go.Figure(data=data1, layout=layout)

iplot(fig)

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 6# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# l# g# o# r# i# t# h# m#  # u# s# e# d#  # t# o#  # a# s# s# i# g# n#  # o# b# s# e# r# v# a# t# i# o# n# s#  # t# o#  # a#  # d# i# s# c# r# e# t# e#  # s# e# t#  # o# f#  # c# l# a# s# s# e# s# .#  # U# n# l# i# k# e#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n#  # w# h# i# c# h#  # o# u# t# p# u# t# s#  # c# o# n# t# i# n# u# o# u# s#  # n# u# m# b# e# r#  # v# a# l# u# e# s# ,#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # t# r# a# n# s# f# o# r# m# s#  # i# t# s#  # o# u# t# p# u# t#  # u# s# i# n# g#  # t# h# e#  # l# o# g# i# s# t# i# c#  # s# i# g# m# o# i# d#  # f# u# n# c# t# i# o# n#  # t# o#  # r# e# t# u# r# n#  # a#  # p# r# o# b# a# b# i# l# i# t# y#  # v# a# l# u# e#  # w# h# i# c# h#  # c# a# n#  # t# h# e# n#  # b# e#  # m# a# p# p# e# d#  # t# o#  # t# w# o#  # o# r#  # m# o# r# e#  # d# i# s# c# r# e# t# e#  # c# l# a# s# s# e# s# .# 
# 
# -# -# -

# -# -# -# 
# 
# <# h# 2# ># <# c# e# n# t# e# r# ># C# o# m# p# u# t# a# t# i# o# n#  # G# r# a# p# h#  # o# f#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# m# a# c# h# i# n# e# t# h# i# n# k# .# n# e# t# /# i# m# a# g# e# s# /# t# e# n# s# o# r# f# l# o# w# -# o# n# -# i# o# s# /# L# o# g# i# s# t# i# c# R# e# g# r# e# s# s# i# o# n# @# 2# x# .# p# n# g# )# 
# 
# *#  #  #  #  #  #  # P# a# r# a# m# e# t# e# r# s#  # a# r# e#  # w# e# i# g# h# t#  # a# n# d#  # b# i# a# s# .# 
# *#  #  #  #  #  #  # W# e# i# g# h# t# s# :#  # c# o# e# f# f# i# c# i# e# n# t# s#  # o# f#  # e# a# c# h#  # a# c# c# o# u# s# t# i# c#  # p# r# o# p# e# r# t# i# e# s# 
# *#  #  #  #  #  #  # B# i# a# s# :#  # i# n# t# e# r# c# e# p# t# 
# *#  #  #  #  #  #  # z#  # =#  # (# w# .# t# )# x#  # +#  # b#  #  # =# >#  # z#  # e# q# u# a# l# s#  # t# o#  # (# t# r# a# n# s# p# o# s# e#  # o# f#  # w# e# i# g# h# t# s#  # t# i# m# e# s#  # i# n# p# u# t#  # x# )#  # +#  # b# i# a# s#  # 
# *#  #  #  #  #  #  # I# n#  # a# n#  # o# t# h# e# r#  # s# a# y# i# n# g#  # =# >#  # z#  # =#  # b#  # +#  # x# 1# *# w# 1#  # +#  # x# 2# *# w# 2#  # +#  # .# .# .#  # +#  # x# 1# 8# *# w# 1# 8#  # +#  # x# 1# 9# *# w# 1# 9# 
# 
# 
# -# -# -

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 7# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># P# r# e# p# r# o# c# e# s# s# i# n# g# :#  # l# a# b# e# l#  # e# n# c# o# d# e# r#  # a# n# d#  # n# o# r# m# a# l# i# z# a# t# i# o# n# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# N# o# r# m# a# l# i# z# a# t# i# o# n#  # i# s#  # a#  # s# y# s# t# e# m# a# t# i# c#  # a# p# p# r# o# a# c# h#  # o# f#  # d# e# c# o# m# p# o# s# i# n# g#  # t# a# b# l# e# s#  # t# o#  # e# l# i# m# i# n# a# t# e#  # d# a# t# a#  # r# e# d# u# n# d# a# n# c# y# (# r# e# p# e# t# i# t# i# o# n# )#  # a# n# d#  # u# n# d# e# s# i# r# a# b# l# e#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # l# i# k# e#  # I# n# s# e# r# t# i# o# n# ,#  # U# p# d# a# t# e#  # a# n# d#  # D# e# l# e# t# i# o# n#  # A# n# o# m# a# l# i# e# s# .#  # I# t#  # i# s#  # a#  # m# u# l# t# i# -# s# t# e# p#  # p# r# o# c# e# s# s#  # t# h# a# t#  # p# u# t# s#  # d# a# t# a#  # i# n# t# o#  # t# a# b# u# l# a# r#  # f# o# r# m# ,#  # r# e# m# o# v# i# n# g#  # d# u# p# l# i# c# a# t# e# d#  # d# a# t# a#  # f# r# o# m#  # t# h# e#  # 
# r# e# l# a# t# i# o# n#  # t# a# b# l# e# s# .# 
# 
# -# -# -

# In[None]

#Normalization

data.label = [1 if each == "male" else 0 for each in data_voice.label]
y = data.label.values
x_data = data.drop(["label"],axis=1)
x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data)).values

# -# -# -# 
# 
# <# a#  # i# d#  # =#  # '# 8# '# ># <# /# a# ># 
# <# h# 2# ># <# c# e# n# t# e# r# ># T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# <# /# c# e# n# t# e# r# ># <# /# h# 2# ># 
# 
# 
# <# c# e# n# t# e# r# ># 8# 0# %#  # o# f#  # t# h# e#  # d# a# t# a#  # w# i# l# l#  # b# e#  # u# s# e# d#  # f# o# r#  # t# h# e#  # t# r# a# i# n# i# n# g# ,#  # r# e# s# t#  # o# f#  # t# h# e#  # d# a# t# a#  # w# i# l# l#  # b# e#  # u# s# e# d#  # f# o# r#  # t# h# e#  # t# e# s# t# <# /# c# e# n# t# e# r# ># 
# 
# -# -# -

# In[None]


from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9655488.npy", { "accuracy_score": score })

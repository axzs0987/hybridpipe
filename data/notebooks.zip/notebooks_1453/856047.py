import pandas as pd
# ##  # A#  # P# r# e# d# i# c# t# i# v# e#  # A# n# a# l# y# s# i# s#  # o# f#  # L# o# a# n#  # D# a# t# a#  

# In[2]

# importing packages

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB
from sklearn.metrics import roc_curve
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

# importing the Dataset

a=pd.read_csv("../input/Loan payments data.csv")

# In[3]

# Information of the Dataset

a.info()

# In[4]

# First 5 rows of the Dataset

a.head()

# In[5]

# Cleaning and transforming the data for futher data analysis

list_edu=[]
for i in a['education']:
    list_edu.append(i)
l=LabelEncoder()
l.fit(list_edu)
l1=l.transform(list_edu)

list_gen=[]
for i in a['Gender']:
    list_gen.append(i)
l.fit(list_gen)
l2=l.transform(list_gen)

list_loan_stat=[]
for i in a['loan_status']:
    list_loan_stat.append(i)
l.fit(list_loan_stat)
l3=l.transform(list_loan_stat)

new_a=pd.DataFrame({'loan_status':l3,'Principal':a['Principal'],'terms':a['terms'],'age':a['age'],'education':l1,'Gender':l2,'loan_status':a['loan_status'],'past_due_days':a['past_due_days']})
new_a['past_due_days']=new_a['past_due_days'].fillna(0)
new_a

# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# 
# ## ## ##  # I# n#  # t# h# e#  # a# b# o# v# e#  # t# a# b# l# e# ,#  # t# h# e#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n#  # f# r# o# m#  # s# t# r# i# n# g#  # t# o#  # i# n# t# e# g# e# r#  # a# r# e#  # a# s#  # f# o# l# l# o# w# s#  # -#  # 
# ## ## ##  # F# o# r#  # G# e# n# d# e# r# 
# ## ## ## ## ## ##  # 0#  # -# -# -#  # F# e# m# a# l# e#  # 
# ## ## ## ## ## ##  # 1#  # -# -# -#  # M# a# l# e# 
# ## ## ##  # F# o# r#  # e# d# u# c# a# t# i# o# n# 
# ## ## ## ## ## ##  # 0#  # -# -# -#  # B# a# c# h# e# l# o# r#  # 
# ## ## ## ## ## ##  # 1#  # -# -# -#  # H# i# g# h#  # S# c# h# o# o# l#  # o# r#  # b# e# l# o# w#  # 
# ## ## ## ## ## ##  # 2#  # -# -# -#  # M# a# s# t# e# r#  # o# r#  # A# b# o# v# e# 
# ## ## ## ## ## ##  # 3#  # -# -# -#  # c# o# l# l# e# g# e# 
# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -

# In[6]

# Data Visualization

plt.figure(figsize=(12,8))
sns.countplot( x = "loan_status",hue = "education", data=a)
plt.show()

# In[7]

plt.figure(figsize=(12,8))
sns.countplot( x = "loan_status",hue = "Gender", data=a)
plt.show()

# In[8]

plt.figure(figsize=(12,8))
sns.countplot( x = "age",hue = "loan_status", data=a)
plt.show()

# ##  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g

# ## ## ##  # K# -# N# e# a# r# e# s# t#  # N# e# i# g# h# b# o# r# s#  # C# l# a# s# s# i# f# i# e# r

# In[9]

x=new_a.drop('loan_status',axis=1).values
y=new_a['loan_status']
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/856047.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
import seaborn as sns
from matplotlib import pyplot as plt
import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv('../input/weatherAUS.csv')

# In[None]

data.head()

# In[None]

len(data)

# In[None]

data.shape

# *# *# E# x# p# l# o# r# i# n# g#  # D# a# t# a# *# *

# In[None]

data.RainToday.value_counts()

# In[None]

data.RainTomorrow.value_counts()

# *# *# D# a# t# a#  # C# l# e# a# n# i# n# g# *# *

# In[None]

# Filling missing values

# In[None]

data.isnull().sum()

# In[None]

(data.isnull().sum() / len(data)).sort_values(ascending=False)

# In[None]

data.columns

# In[None]

# Removing columns with too much null values
data = data.drop(['Sunshine', 'Evaporation', 'Cloud3pm', 'Cloud9am'], axis=1)

# In[None]

# For the plots
data_no_nan = data.dropna()

# In[None]

# Pressure9am
data.Pressure9am.describe()

# In[None]

plt.figure(figsize=(10,6))
sns.distplot(data_no_nan.Pressure9am)

# In[None]

# Fill with mean, nearly same as median
data.Pressure9am = data.Pressure9am.fillna(data.Pressure9am.mean())

# In[None]

# Pressure3pm
data.Pressure3pm.describe()

# In[None]

plt.figure(figsize=(10,6))
sns.distplot(data_no_nan.Pressure3pm)

# In[None]

# Fill with mean, nearly same as median
data.Pressure3pm = data.Pressure3pm.fillna(data.Pressure3pm.mean())

# In[None]

# WindDir9am
data.WindDir9am.value_counts()

# In[None]

plt.figure(figsize=(10,6))
sns.countplot(data_no_nan.WindDir9am)

# In[None]

# Fill with max value
data.WindDir9am = data.WindDir9am.fillna(data.WindDir9am.value_counts().reset_index().iloc[0]['index'])

# In[None]

# WindGustDir
data.WindGustDir.value_counts()

# In[None]

plt.figure(figsize=(10,6))
sns.countplot(data_no_nan.WindGustDir)

# In[None]

# Fill with max value
data.WindGustDir = data.WindGustDir.fillna(data.WindGustDir.value_counts().reset_index().iloc[0]['index'])

# In[None]

# WindGustSpeed
data.WindGustSpeed.describe()

# In[None]

plt.figure(figsize=(10,6))
sns.distplot(data_no_nan.WindGustSpeed)

# In[None]

# Fill with mean, nearly same as median
data.WindGustSpeed = data.WindGustSpeed.fillna(data.WindGustSpeed.mean())

# In[None]

# WindDir3pm
data.WindDir3pm.value_counts()

# In[None]

plt.figure(figsize=(10,6))
sns.countplot(data_no_nan.WindDir3pm)

# In[None]

# Fill with max value
data.WindDir3pm = data.WindDir3pm.fillna(data.WindDir3pm.value_counts().reset_index().iloc[0]['index'])

# In[None]

# Humidity3pm
data.Humidity3pm.describe()

# In[None]

plt.figure(figsize=(10,6))
sns.distplot(data_no_nan.Humidity3pm)

# In[None]

# Fill with mean, nearly same as median
data.Humidity3pm = data.Humidity3pm.fillna(data.Humidity3pm.mean())

# In[None]

# Temp3pm
data.Temp3pm.describe()

# In[None]

plt.figure(figsize=(10,6))
sns.distplot(data_no_nan.Temp3pm)

# In[None]

# Fill with mean, nearly same as median
data.Temp3pm = data.Temp3pm.fillna(data.Temp3pm.mean())

# In[None]

# WindSpeed3pm
data.WindSpeed3pm.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.countplot(data_no_nan.WindSpeed3pm)
g.set_xticklabels(g.get_xticklabels(), rotation=90)

# In[None]

# Fill with mean, nearly same as median
data.WindSpeed3pm = data.WindSpeed3pm.fillna(data.WindSpeed3pm.mean())

# In[None]

# Humidity9am
data.Humidity9am.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.distplot(data_no_nan.Humidity9am)

# In[None]

# Fill with mean, nearly same as median
data.Humidity9am = data.Humidity9am.fillna(data.Humidity9am.mean())

# In[None]

# Rainfall
data.Rainfall.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.distplot(data_no_nan.Rainfall)

# In[None]

# Fill with median
data.Rainfall = data.Rainfall.fillna(data.Rainfall.median())

# In[None]

# WindSpeed9am
data.WindSpeed9am.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.countplot(data_no_nan.WindSpeed9am)
g.set_xticklabels(g.get_xticklabels(), rotation=90)

# In[None]

# Fill with mean, nearly same as median
data.WindSpeed9am = data.WindSpeed9am.fillna(data.WindSpeed9am.mean())

# In[None]

# Temp9am
data.Temp9am.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.distplot(data_no_nan.Temp9am)

# In[None]

# Fill with mean, nearly same as median
data.Temp9am = data.Temp9am.fillna(data.Temp9am.mean())

# In[None]

# MinTemp
data.MinTemp.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.distplot(data_no_nan.MinTemp)

# In[None]

# Fill with mean, nearly same as median
data.MinTemp = data.MinTemp.fillna(data.MinTemp.mean())

# In[None]

# MaxTemp
data.MaxTemp.describe()

# In[None]

plt.figure(figsize=(10,6))
g = sns.distplot(data_no_nan.MaxTemp)

# In[None]

# Fill with mean, nearly same as median
data.MaxTemp = data.MaxTemp.fillna(data.MaxTemp.mean())

# In[None]

# MaxTemp
data.RainToday.value_counts()

# In[None]

plt.figure(figsize=(10,6))
sns.countplot(data_no_nan.RainToday)

# In[None]

# Fill with max value
data.RainToday = data.RainToday.fillna(data.RainToday.value_counts().reset_index().iloc[0]['index'])

# In[None]

(data.isnull().sum() / len(data)).sort_values(ascending=False)

# In[None]

# Converting categorical values to numerical values

# In[None]

# Removing Location and Date, not useful to predict the rain 
data = data.drop(['Date', 'Location'], axis=1)

# In[None]

from sklearn import preprocessing

# In[None]

le = preprocessing.LabelEncoder()
le.fit(data.WindGustDir)
data.WindGustDir = le.transform(data.WindGustDir)

# In[None]

le = preprocessing.LabelEncoder()
le.fit(data.WindDir9am)
data.WindDir9am = le.transform(data.WindDir9am)

# In[None]

le = preprocessing.LabelEncoder()
le.fit(data.WindDir3pm)
data.WindDir3pm = le.transform(data.WindDir3pm)

# In[None]

data.RainToday = data.RainToday.map({'No':0, 'Yes':1})
data.RainTomorrow = data.RainTomorrow.map({'No':0, 'Yes':1})

# In[None]

data.head()

# *# *# D# a# t# a#  # P# r# e# d# i# c# t# i# o# n# s# *# *

# In[None]

plt.figure(figsize=(10,8))
sns.heatmap(data.corr())

# In[None]

data.corr()['RainTomorrow'].sort_values(ascending=False)

# In[None]

# RISK_MM is an estimation of the amount of rain in the next day, we don't want to use this feature

data = data.drop('RISK_MM', axis=1)

# In[None]

X = data.drop('RainTomorrow', axis=1)
y = data['RainTomorrow']

# In[None]

from sklearn.model_selection import train_test_split

#split dataset into train and test data
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4274393.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import numpy as np 
import pandas as pd 
import warnings
warnings.filterwarnings('ignore')


# In[None]

import pandas as pd
liver_patient = pd.read_csv("../input/indian-liver-patient-records/indian_liver_patient.csv")
liver_patient.head()

# In[None]

y = liver_patient['Dataset']
import seaborn as sns
liver_patient.isnull().sum()

# *# *# U# s# i# n# g#  # I# n# t# e# r# p# o# l# a# t# e#  # m# e# t# h# o# d#  # t# o#  # r# e# m# o# v# e#  # n# u# l# l#  # v# a# l# u# e# s

# In[None]

liver = liver_patient.interpolate()
liver.isnull().sum()

# *# *# C# a# t# e# g# o# r# i# c# a# l#  # V# a# l# u# e# s#  # a# r# e#  # c# o# n# v# e# r# t# e# d#  # t# o#  # i# n# t#  # t# y# p# e#  # b# e# l# o# w

# In[None]

liver['Gender'] = liver['Gender'].apply(lambda x: 1 if x =='Male' else 0)

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt
sns.countplot(liver['Dataset'])
ld,nld = liver['Dataset'].value_counts()
print('Number of people Diagnoised with Liver Disease:',ld)
print('Number of people with no Liver Disease:', nld)

# In[None]

Gender_comparision = liver[['Gender','Dataset']]
x = liver['Gender'][liver['Dataset']==1]
sns.countplot(x)
male,female = x.value_counts()
print("Number of Male's diagonised with Liver disease:",male)
print("Number of Female's diagonised with Liver Disease:",female)

# In[None]

liver[['Age','Gender','Dataset']].groupby(['Dataset','Gender'],as_index = False).mean().sort_values(by = 'Dataset',ascending = False)

# *# *# C# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # h# e# l# p# s#  # u# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # v# a# r# i# a# b# l# e# s# .# 
# *# *# F# r# o# m#  # t# h# e#  # h# e# a# t# m# a# p#  # w# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # D# a# t# a# s# e# t#  # c# o# l# u# m# n#  # h# a# s#  # s# o# m# e#  # c# o# r# r# e# a# l# a# t# i# o# n#  # w# i# t# h#  # A# l# b# u# m# i# n# _# a# n# d# _# G# l# o# b# u# l# i# n#  # R# a# t# i# o#  # a# n# d#  # A# l# b# u# m# i# n# .

# In[None]

correl = liver.drop(['Age'],axis = 1)
cor = correl.corr()
sns.heatmap(cor,annot = True, fmt = '.2f')

# *# *# W# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # 5# 5# %#  # o# f#  # M# a# l# e# s#  # a# r# e#  # p# r# o# n# e#  # t# o#  # L# i# v# e# r#  # D# i# s# e# a# s# e#  # i# f#  # A# l# b# u# m# i# n#  # a# n# d#  # G# l# o# b# u# l# i# n#  # r# a# t# i# o# n#  # a# r# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 0# .# 9# ,# 
# a# n# d#  # 5# 7# %#  # o# f#  # F# e# m# a# l# e# s#  # a# r# e#  # p# r# o# n# e#  # t# o#  # L# i# v# e# r#  # D# i# s# e# a# s# e#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # t# h# e#  # r# a# t# i# o# .

# In[None]

x = liver['Gender'][liver['Dataset']==1][liver['Albumin_and_Globulin_Ratio']>=0.9]
sns.countplot(x)
male,female = x.value_counts()
print('Number of Males diagonised with liver disease having Albumin and Globulin ratio > 0.9:',male)
print('Number of Females diagonised with liver disease having Albumin and Globulin ratio > 0.9:',female)

# In[None]

liver[['Albumin','Albumin_and_Globulin_Ratio', 'Dataset']].groupby('Dataset',as_index= False).mean()

# *# *# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # d# r# o# p#  # D# a# t# a# s# e# t#  # a# s#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # m# a# k# e#  # t# h# i# s#  # a# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .

# In[None]

liver_dis = liver.drop(['Dataset'],axis = 1)


# In[None]

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error,accuracy_score
from sklearn.metrics import confusion_matrix, classification_report

# In[None]

logistic_model = LogisticRegression()
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(liver_dis, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/6614126.npy", { "accuracy_score": score })

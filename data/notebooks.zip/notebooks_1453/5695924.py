import pandas as pd
# In[None]

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from pandas.plotting import scatter_matrix
print('Import Complete')
#wine_data = pd.read_csv('/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, roc_curve

# In[None]

#wine_data  = pd.read_csv('D:\\Hemant\\Machine_Learning_Self_Study\\datasets\\red-wine-quality-cortez-et-al-2009\\winequality-red.csv')
wine_data = pd.read_csv('/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

wine_data.head()

# In[None]

wine_data.info() # to check number of missing values

# In[None]

wine_data.columns.to_list()

# In[None]

wine_data.plot.bar(x = 'fixed acidity', y = 'quality')

# In[None]

attributes = wine_data.columns.to_list()

# In[None]

scatter_matrix(wine_data[attributes], figsize=(30,30))

# In[None]

wine_data['quality'].value_counts()

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

attr = wine_data.columns.to_list()[:-1]

# In[None]

X = np.array(wine_data.iloc[:,:-1])
y = np.array(wine_data.iloc[:,-1])

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5695924.npy", { "accuracy_score": score })

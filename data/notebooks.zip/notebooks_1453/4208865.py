import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

#Import the Labraries for visualision 
import matplotlib.pyplot as plt
import seaborn as sns
# Any results you write to the current directory are saved as output.

# In[None]

#Import the Dataset
df = pd.read_csv("../input/pulsar_stars.csv")  

# In[None]

#lets check our dataset
df.info()

# In[None]

#At first we Renaming columns
df = df.rename(columns={' Mean of the integrated profile':"mean_profile",
       ' Standard deviation of the integrated profile':"std_profile",
       ' Excess kurtosis of the integrated profile':"kurtosis_profile",
       ' Skewness of the integrated profile':"skewness_profile", 
        ' Mean of the DM-SNR curve':"mean_dmsnr_curve",
       ' Standard deviation of the DM-SNR curve':"std_dmsnr_curve",
       ' Excess kurtosis of the DM-SNR curve':"kurtosis_dmsnr_curve",
       ' Skewness of the DM-SNR curve':"skewness_dmsnr_curve",
       })

# In[None]

#Now we see the statistical inference of the dataset
# df.describe()

# In[None]

#Now check the if any missing value in our dataset
# df.isnull().sum()

# In[None]

#Now we see out target varibale
# sns.countplot(x ='target_class', data = df)
# plt.show()

# In[None]

#Now lets see the correlation by plotting heatmap
# corr = df.corr()
# colormap = sns.diverging_palette(220, 10, as_cmap = True)
# plt.figure(figsize = (8,6))
# sns.heatmap(corr,
#             xticklabels=corr.columns.values,
#             yticklabels=corr.columns.values,
#             annot=True,fmt='.2f',linewidths=0.30,
#             cmap = colormap, linecolor='white')
# plt.title('Correlation of df Features', y = 1.05, size=10)

# In[None]

#Lets look the correlation score
# print (corr['target_class'].sort_values(ascending=False), '\n')

# In[None]

#Lets see the pair plot between all variables
# sns.pairplot(df,hue = 'target_class')
# plt.title("pair plot for variables")
# plt.show()

# In[None]

#Lets create ML model for our dataset
x = df.iloc[:, 0 : 8].values
y = df.iloc[:, - 1].values

# In[None]

#Spliting the dataset to the traning and test set
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4208865.npy", { "accuracy_score": score })

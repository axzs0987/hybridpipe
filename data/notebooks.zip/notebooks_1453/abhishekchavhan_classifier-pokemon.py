import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier,GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
from sklearn.metrics import roc_curve,roc_auc_score
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay
from sklearn.model_selection import cross_val_score,RandomizedSearchCV,GridSearchCV 
data = pd.read_csv('/kaggle/input/pokemon/pokemon.csv')
data.head()
data.isna().sum()
#fig,axes = plt.subplots(figsize=(10,10))
#axes.bar(data['name'][:10],data['attack'][:10],color='salmon');
#plt.title('Pokemon attack');
#plt.xlabel('Pokemon');
#plt.ylabel('Attack');
#data.plot(kind='scatter',x='name',y='sp_attack');
for label,content in data.items():
    if pd.api.types.is_numeric_dtype(content):
        if pd.isnull(content).sum():
            print(label)
for label,content in data.items():
    if pd.api.types.is_numeric_dtype(content):
        if pd.isnull(content).sum():
            data[label] = content.fillna(content.median())
            
data.dtypes
for label,content in data.items():
    if pd.api.types.is_float_dtype(content):
        data[label] = data[label].astype('int')
data.dtypes
for label,content in data.items():
    if not pd.api.types.is_numeric_dtype(content):
        data[label] = data[label].astype('category')
data.dtypes
for label,content in data.items():
    if pd.api.types.is_categorical_dtype(content):
        data[label] = pd.Categorical(content).codes + 1
X = data.drop('is_legendary',axis=1)
y = data['is_legendary']
model_a = RandomForestClassifier()
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
#model_a.fit(X_train,y_train)
#model_a.score(X_test,y_test)
model_b = GradientBoostingClassifier()
#model_b.fit(X_train,y_train)
#model_b.score(X_test,y_test)
model_c = LogisticRegression()
#model_c.fit(X_train,y_train)
#model_c.score(X_test,y_test)
#y_preds = model_a.predict_proba(X_test)
#cvm = cross_val_score(model_a,X,y,cv=10)
#np.mean(cvm)
#y_preds = model_a.predict(X_test)
#precision = precision_score(y_test,y_preds)
#recall = recall_score(y_test,y_preds)
#accuracy = accuracy_score(y_test,y_preds)
#accuracy,recall,precision
Pokemon = pd.DataFrame()
#y_preds = model_a.predict(X)
Pokemon['Default values'] = y
#Pokemon['Predictions'] = y_preds
Pokemon
#fig,axes = plt.subplots()
#axes.stackplot(Pokemon['Default values'],Pokemon['Predictions'],color=['red','blue']);



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/abhishekchavhan_classifier-pokemon.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekchavhan_classifier-pokemon/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekchavhan_classifier-pokemon/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/abhishekchavhan_classifier-pokemon/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/abhishekchavhan_classifier-pokemon/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/abhishekchavhan_classifier-pokemon/testY.csv",encoding="gbk")


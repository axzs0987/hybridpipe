import pandas as pd
# ##  # T# e# l# c# o#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n# 
# !# [# a# l# t#  # t# e# x# t# ]# (# h# t# t# p# s# :# /# /# m# i# r# o# .# m# e# d# i# u# m# .# c# o# m# /# m# a# x# /# 1# 1# 0# 4# /# 0# *# 6# h# X# w# L# K# d# 6# 7# L# _# _# l# T# s# g# .# p# n# g# )

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

#importing the dataset

df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')
df.head()

# T# h# e#  # d# a# t# a# s# e# t#  # d# e# s# c# r# i# b# e# s#  # T# e# l# c# o#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n#  # d# a# t# a# .#  #  # T# h# e#  # d# a# t# a# s# e# t#  # c# o# n# t# a# i# n# s#  # 2# 1#  # C# o# l# u# m# n# s#  # a# n# d#  # 7# 0# 4# 3#  # R# o# w# s#  # w# h# i# c# h#  # h# a# s#  # b# o# t# h#  # n# u# m# e# r# i# c#  # a# n# d#  # n# o# n# -# n# u# m# e# r# i# c#  # d# a# t# a# .

# In[None]

df.columns

# In[None]

df.shape

# In[None]

df.info()

# In[None]

df.describe()

# In[None]

# checking if any null data exists
df.isnull().sum()

# In[None]

df = df.drop(columns = ['customerID'])
df.head()

# In[None]

#plotting the graph

import matplotlib.pyplot as plt
import seaborn as sns

sns.countplot(x = "Churn", data = df)
df.loc[:, 'Churn'].value_counts()

# In[None]

sns.countplot(x = "SeniorCitizen", data = df)
df.loc[:, 'SeniorCitizen'].value_counts()

# In[None]

sns.countplot(x = "InternetService", data = df)
df.loc[:, 'InternetService'].value_counts()

# In[None]

sns.countplot(x = "PhoneService", data = df)
df.loc[:, 'PhoneService'].value_counts()

# In[None]

plt.figure()
Corr=df[df.columns].corr()
sns.heatmap(Corr,annot=True)

# In[None]

df['TotalCharges'].value_counts().sort_index().plot.hist()

# In[None]

df['MonthlyCharges'].value_counts().sort_index().plot.hist()

# In[None]

df['tenure'].value_counts().sort_index().plot.hist()

# In[None]

df['PaymentMethod'].value_counts().plot.pie()
plt.gca().set_aspect('equal')

# In[None]

sns.kdeplot(df['tenure'], df['MonthlyCharges'])

# In[None]

# converting the non-numeric data into numeric data.
from sklearn.preprocessing import LabelEncoder
encoded = df.apply(lambda x: LabelEncoder().fit_transform(x) if x.dtype == 'object' else x)
encoded.head()

# In[None]

plt.figure(figsize =(20,20))
Corr=encoded[encoded.columns].corr()
sns.heatmap(Corr,annot=True)

# In[None]

sns.violinplot(x='gender', y='InternetService', data=encoded)

# In[None]

sns.violinplot(x='PaperlessBilling', y='PaymentMethod', data=encoded)

# In[None]

sns.violinplot(encoded['StreamingTV'],encoded['StreamingMovies'])

# In[None]

sns.violinplot(encoded['Partner'],encoded['Dependents'])

# In[None]

sns.violinplot(encoded['MultipleLines'])

# In[None]

X = encoded.iloc[:, 0:19]
y = encoded.Churn

# ##  # T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# i# n# g# 
# W# e#  # w# i# l# l#  #  # s# p# l# i# t#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # a#  # t# r# a# i# n# i# n# g#  # a# n# d#  # a#  # t# e# s# t#  # p# a# r# t# .#  # T# h# e#  # m# o# d# e# l# s#  # w# i# l# l#  # b# e#  # t# r# a# i# n# e# d#  # o# n#  # t# h# e#  # t# r# a# i# n# i# n# g#  # d# a# t# a#  # s# e# t#  # a# n# d#  # t# e# s# t# e# d#  # o# n#  # t# h# e#  # t# e# s# t#  # d# a# t# a#  # s# e# t# .

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1454254.npy", { "accuracy_score": score })

import pandas as pd
# ##  # C# h# u# r# n#  # i# n#  # T# e# l# e# c# o# m# '# s#  # d# a# t# a# s# e# t#  

# ## ##  # I# n# d# e# x#  

# *#  # [# L# i# b# r# a# r# i# e# s# ]# (# ## L# i# b# r# a# r# i# e# s# )#  # 
# *#  # [# L# o# a# d# i# n# g#  # D# a# t# a# ]# (# ## L# o# a# d# i# n# g# -# D# a# t# a# )# 
# *#  # [# D# a# t# a#  # D# e# s# c# r# i# p# t# i# o# n# ]# (# ## D# a# t# a# -# D# e# s# c# r# i# p# t# i# o# n# )# 
# *#  # [# C# h# e# c# k# i# n# g#  # n# u# l# l#  # v# a# l# u# e# s#  # a# n# d#  # v# a# l# u# e# _# c# o# u# n# t# s# ]# (# ## C# h# e# c# k# i# n# g# -# n# u# l# l# -# v# a# l# u# e# s# -# a# n# d# -# v# a# l# u# e# _# c# o# u# n# t# s# )# 
# *#  # [# D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# ]# (# ## D# a# t# a# -# V# i# s# u# a# l# i# z# a# t# i# o# n# )# 
# 	# *#  # [# C# h# u# r# n#  # P# l# o# t# ]# (# ## C# h# u# r# n# -# P# l# o# t# )# 
#  #  #  #  # *#  # [# A# r# e# a#  # c# o# d# e#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t# ]# (# ## A# r# e# a# -# c# o# d# e# -# a# n# d# -# C# h# u# r# n# -# p# l# o# t# )# 
#  #  #  #  # *#  # [# S# t# a# t# e#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t# ]# (# ## S# t# a# t# e# -# a# n# d# -# C# h# u# r# n# -# p# l# o# t# )# 
#  #  #  #  # *#  # [# I# n# t# e# r# n# a# t# i# o# n# a# l#  # p# l# a# n#  # a# n# d#  # C# h# u# r# n# ]# (# ## I# n# t# e# r# n# a# t# i# o# n# a# l# -# p# l# a# n# -# a# n# d# -# C# h# u# r# n# )# 
#  #  #  #  # *#  # [# V# o# i# c# e#  # m# a# i# l#  # p# l# a# n#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t# ]# (# ## V# o# i# c# e# -# m# a# i# l# -# p# l# a# n# -# a# n# d# -# C# h# u# r# n# -# p# l# o# t# )# 
#  #  #  #  # *#  # [# C# u# s# t# o# m# e# r#  # s# e# r# v# i# c# e#  # c# a# l# l# s#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t# ]# (# ## C# u# s# t# o# m# e# r# -# s# e# r# v# i# c# e# -# c# a# l# l# s# -# a# n# d# -# C# h# u# r# n# -# p# l# o# t# )# 
# *#  # [# L# a# b# e# l#  # e# n# c# o# d# i# n# g# ]# (# ## L# a# b# e# l# -# e# n# c# o# d# i# n# g# )# 
# *#  # [# M# o# d# e# l#  # B# u# i# l# d# i# n# g# ]# (# ## M# o# d# e# l# -# B# u# i# l# d# i# n# g# )# 
# *#  # [# F# e# a# t# u# r# e#  # i# m# p# o# r# t# a# n# c# e#  # u# s# i# n# g#  # R# a# n# d# o# m#  # F# o# r# e# s# t# ]# (# ## F# e# a# t# u# r# e# -# i# m# p# o# r# t# a# n# c# e# -# u# s# i# n# g# -# R# a# n# d# o# m# -# F# o# r# e# s# t# )# 
# *#  # [# T# r# a# i# n#  # t# e# s# t#  # s# p# l# i# t# ]# (# ## T# r# a# i# n# -# t# e# s# t# -# s# p# l# i# t# )# 
# *#  # [# R# a# n# d# o# m#  # f# o# r# e# s# t# ]# (# ## R# a# n# d# o# m# -# f# o# r# e# s# t# )# 
# *#  # [# D# e# c# i# s# i# o# n#  # t# r# e# e# ]# (# ## D# e# c# i# s# i# o# n# -# t# r# e# e# )# 
# *#  # [# O# n# e# -# H# o# t#  # E# n# c# o# d# i# n# g# ]# (# ## O# n# e# -# H# o# t# -# E# n# c# o# d# i# n# g# )# 
# *#  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## L# o# g# i# s# t# i# c# -# R# e# g# r# e# s# s# i# o# n# )# 
# *#  # [# S# a# v# i# n# g#  # t# o#  # p# k# l#  # f# i# l# e# ]# (# ## S# a# v# i# n# g# -# t# o# -# p# k# l# -# f# i# l# e# )# 
# *#  # [# L# o# a# d#  # P# k# l#  # f# i# l# e# s# ]# (# ## L# o# a# d# -# P# k# l# -# f# i# l# e# s# )# 
# *#  # [# A# l# l#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # A# l# g# o# r# i# t# h# m# ]# (# ## A# l# l# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# -# A# l# g# o# r# i# t# h# m# )# 
#  #  #  #  # *#  # L# o# g# i# s# t# i# c# R# e# g# r# e# s# s# i# o# n# 
#  #  #  #  # *#  # X# G# B# C# l# a# s# s# i# f# i# e# r# 
#  #  #  #  # *#  # M# u# l# t# i# n# o# m# i# a# l# N# B# 
#  #  #  #  # *#  # A# d# a# B# o# o# s# t# C# l# a# s# s# i# f# i# e# r# 
#  #  #  #  # *#  # K# N# e# i# g# h# b# o# r# s# C# l# a# s# s# i# f# i# e# r# 
#  #  #  #  # *#  # G# r# a# d# i# e# n# t# B# o# o# s# t# i# n# g# C# l# a# s# s# i# f# i# e# r# 
#  #  #  #  # *#  # E# x# t# r# a# T# r# e# e# s# C# l# a# s# s# i# f# i# e# r# 
#  #  #  #  # *#  # D# e# c# i# s# i# o# n# T# r# e# e# C# l# a# s# s# i# f# i# e# r#  

# ## ## ##  # L# i# b# r# a# r# i# e# s

# In[None]

import numpy as np 
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import xgboost as xgb
from sklearn.neighbors import KNeighborsClassifier,RadiusNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC,SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier,ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.externals import joblib
from sklearn.metrics import accuracy_score,roc_auc_score

# ## ## ##  # L# o# a# d# i# n# g#  # D# a# t# a

# In[None]

data=pd.read_csv("../input/bigml_59c28831336c6604c800002a.csv")

# ## ## ##  # D# a# t# a#  # D# e# s# c# r# i# p# t# i# o# n

# In[None]

print(data.shape)
print(data.columns)
data.head()

# In[None]

data.describe()

# In[None]

data.dtypes

# ## ## ##  # C# h# e# c# k# i# n# g#  # n# u# l# l#  # v# a# l# u# e# s#  # a# n# d#  # v# a# l# u# e# _# c# o# u# n# t# s

# In[None]

data.isnull().sum()

# In[None]

data.drop(["phone number"],axis=1,inplace=True)

# In[None]

data["account length"].value_counts().head(20)

# In[None]

for i in data.columns:
    if data[i].dtype == "object":
        print(data[i].value_counts())

# ## ##  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# ## ## ##  # C# h# u# r# n#  # P# l# o# t

# In[None]

ax=sns.countplot(x="churn",data=data)
for p in ax.patches:
        ax.annotate('{:.1f}%'.format( (p.get_height()/data.shape[0])*100 ), (p.get_x()+0.3, p.get_height()))

# ## ## ##  # A# r# e# a#  # c# o# d# e#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t

# In[None]

# data.groupby(["area code","churn"]).size()

# In[None]

ac=data.groupby(["area code", "churn"]).size().unstack().plot(kind='bar', stacked=False,figsize=(6,5))
for i in ac.patches:
    ac.text(i.get_x()+0.05, i.get_height()+20,str(i.get_height()))

# ## ## ##  #  # S# t# a# t# e#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t

# In[None]

# data["state"].value_counts()

# In[None]

st=data.groupby(["state", "churn"]).size().unstack().plot(kind='bar',stacked=True,figsize=(15,5))
# for i in st.patches:
#     st.text(i.get_x(), i.get_height(),str(i.get_height()))

# In[None]

# cols=['state','area code',
#  'international plan',
#  'voice mail plan',
#  'number vmail messages','customer service calls',]

# In[None]

# plt.plot([1,6])
# for i in range(len(cols)):
#     plt.subplot(i+1,1,1)
#     a=data.groupby([cols[i], "churn"]).size().unstack().plot(kind='bar', stacked=False,figsize=(6,5))
#     for i in a.patches:
#         a.text(i.get_x(), i.get_height(),str(i.get_height()))
#     plt.show()

# ## ## ##  # I# n# t# e# r# n# a# t# i# o# n# a# l#  # p# l# a# n#  # a# n# d#  # C# h# u# r# n

# In[None]

ip=data.groupby(["international plan", "churn"]).size().unstack().plot(kind='bar', stacked=False,figsize=(6,5))
for i in ip.patches:
    ip.text(i.get_x()+0.05, i.get_height()+20,str(i.get_height()))

# ## ## ##  # V# o# i# c# e#  # m# a# i# l#  # p# l# a# n#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t

# In[None]

vp=data.groupby(["voice mail plan", "churn"]).size().unstack().plot(kind='bar', stacked=True,figsize=(6,5))
# for i in vp.patches:
#     vp.text(i.get_x()+0.05, i.get_height()+20,str(i.get_height()))

# ## ## ##  # C# u# s# t# o# m# e# r#  # s# e# r# v# i# c# e#  # c# a# l# l# s#  # a# n# d#  # C# h# u# r# n#  # p# l# o# t

# In[None]

cs=data.groupby(["customer service calls", "churn"]).size().unstack().plot(kind='bar', stacked=False,figsize=(12,6))
for i in cs.patches:
    cs.text(i.get_x()+0.05, i.get_height()+20,int(i.get_height()))

# In[None]

cate = [key for key in dict(data.dtypes) if dict(data.dtypes)[key] in ['bool', 'object']]

# ## ## ##  # L# a# b# e# l#  # e# n# c# o# d# i# n# g#  

# In[None]

le = preprocessing.LabelEncoder()
for i in cate:
    le.fit(data[i])
    data[i] = le.transform(data[i])

# In[None]

data.head()

# ## ##  # M# o# d# e# l#  # B# u# i# l# d# i# n# g

# ## ## ##  # F# e# a# t# u# r# e#  # i# m# p# o# r# t# a# n# c# e#  # u# s# i# n# g#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  

# In[None]

y=data["churn"]
x=data.drop(["churn"],axis=1)
x.columns

# In[None]

clf = RandomForestClassifier()
clf.fit(x, y)

# >#  # <# f# o# n# t#  # s# i# z# e# =# 4# ,#  # c# o# l# o# r# =# b# l# u# e# ># A# c# c# u# r# a# c# y# <# /# f# o# n# t# >

# In[None]

clf.score(x,y)

# In[None]

clf.feature_importances_

# >#  # <# f# o# n# t#  # s# i# z# e# =# 4# ,#  # c# o# l# o# r# =# b# l# u# e# ># F# e# a# t# u# r# e#  # I# m# p# o# r# t# a# n# c# e#  # p# l# o# t# <# /# f# o# n# t# >

# In[None]

importances = clf.feature_importances_
indices = np.argsort(importances)
features=x.columns
fig, ax = plt.subplots(figsize=(9,9))
plt.title("Feature Impoprtance")
plt.ylabel("Features")
plt.barh(range(len(indices)), importances[indices] )
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.show()

# ## ## ##  # T# r# a# i# n#  # t# e# s# t#  # s# p# l# i# t#  

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2592774.npy", { "accuracy_score": score })

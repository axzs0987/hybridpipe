import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt
sns.set_style ('whitegrid')

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

#load data
data = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

#check the head of the data
data.head()

# In[None]

data.info()

# *# *# D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # (# E# D# A# )# *# *

# In[None]

#Drop customerID - not needed
data = data.drop(columns = 'customerID')
data.head()

# In[None]

#Convert TotalCharges to a numeric datatype
data['TotalCharges'] = pd.to_numeric(data['TotalCharges'], errors = 'coerce')
type(data['TotalCharges'][0])

# In[None]

#Check for missing values in each column
missing_values_count = data.isnull().sum()
missing_values_count

# In[None]

#TotalCharges is the only column with missing values
#fill missing values with the mean TotalCharges
data['TotalCharges'] = data['TotalCharges'].fillna(data['TotalCharges'].mean())

# In[None]

#Let's check the missing values again to confirm that TotalCharges has no missing values
missing_values_count_2 = data.isnull().sum()
missing_values_count_2

# In[None]

#Convert SeniorCitizen from integer to string
data['SeniorCitizen'] = data['SeniorCitizen'].apply(lambda x: 'Yes' if x==1 else 'No')
data.head()

# In[None]

#Let's check the outcome variable Churn
sns.countplot(x='Churn', data = data)

# In[None]

sns.pairplot(data = data, hue = 'Churn')

# I# n# s# i# g# h# t# s#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h# 
# ## -#  # T# h# e#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # l# o# n# g# e# r#  # t# e# n# u# r# e# s#  # g# e# n# e# r# a# l#  # t# e# n# d#  # t# o#  # s# t# a# y

# In[None]

sns.heatmap(data.corr(),cmap = 'viridis', annot=True)

# I# n# s# i# g# h# t# s#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h# 
# ## -#  # T# o# t# a# l# C# h# a# r# g# e# s#  # i# s#  # s# t# r# o# n# g# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # t# e# n# u# r# e# ,#  # w# h# i# c# h#  # m# a# k# e# s#  # s# e# n# s# e#  # b# e# c# a# u# s# e#  # y# o# u#  # p# a# y#  # m# o# r# e#  # w# i# t# h#  # t# i# m# e# 
# ## -#  # I# t#  # w# o# u# l# d#  # b# e#  # g# o# o# d#  # t# o#  # d# r# o# p#  # T# o# t# a# l# C# h# a# r# g# e# s#  # d# u# r# i# n# g#  # m# o# d# e# l# i# n# g#  # s# i# n# c# e#  # i# t#  # i# s#  # s# t# r# o# n# g# l# y#  # d# e# p# e# n# d# e# n# t#  # o# n#  # t# e# n# u# r# e#  # a# n# d#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s

# In[None]

plt.subplots(figsize=(12,4))
plt.subplot(1,3,1)
sns.boxplot(x='MonthlyCharges', y='Churn', data=data)
plt.subplot(1,3,2)
sns.boxplot(x='TotalCharges', y='Churn', data=data)
plt.subplot(1,3,3)
sns.boxplot(x='tenure', y='Churn', data=data)
plt.tight_layout()

# ## I# n# s# i# g# h# t# s# 
# ## -#  # C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # h# a# v# e#  # a#  # h# i# g# h# e# r#  # c# h# u# r# n#  # r# a# t# e# 
# ## -#  # C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # l# o# n# g# e# r#  # t# e# n# u# r# e#  # h# a# v# e#  # l# o# w# e# r#  # c# h# u# r# n#  # r# a# t# e

# In[None]

sns.countplot(x='Dependents', data=data, hue='Churn')

# In[None]

sns.countplot(x='Contract', data=data, hue='Churn')
#insight - month-to-month contract customers have a higher churn rate

# In[None]

sns.countplot(x='Partner', data=data, hue='Churn')

# In[None]

sns.countplot(x='InternetService', data=data, hue='Churn')
#Insight - customers with fiber optic service tend to have a higher churn rate

# In[None]

sns.countplot(x='TechSupport', data=data, hue='Churn')
#Insght - Customers without tech support tend to have a higher churn rate

# In[None]

sns.countplot(x='PaperlessBilling', data=data, hue='Churn')

# In[None]

data.sample(5)

# *# *# F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g# *# *# 
# *# *# -#  # S# c# a# l# i# n# g#  # o# f#  # n# u# m# e# r# i# c#  # v# a# r# i# a# b# l# e# s# *# *# 
# *# *# -#  # G# e# t# t# i# n# g#  # d# u# m# m# i# e# s#  # f# o# r#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# *# *

# In[None]

columns = list(data.columns)

# In[None]

numeric_cols = ['tenure', 'TotalCharges', 'MonthlyCharges']
non_numeric_cols = list(set(columns) - set(numeric_cols))
non_numeric_cols

# In[None]

non_numeric_data = pd.get_dummies(data[non_numeric_cols], drop_first=True)
non_numeric_data.sample(5)

# In[None]

from sklearn.preprocessing import scale
numeric_data = pd.DataFrame(scale(data[numeric_cols]), index=data.index, columns=numeric_cols)
numeric_data.head()

# In[None]

prepared_data = pd.concat([numeric_data, non_numeric_data], axis=1)
prepared_data.head()

# *# *# M# o# d# e# l# i# n# g# *# *

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(prepared_data.drop(['TotalCharges', 'Churn_Yes'], axis=1), prepared_data['Churn_Yes'], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1528779.npy", { "accuracy_score": score })

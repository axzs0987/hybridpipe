import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

customers = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

customers.head(10)

# In[None]

customers.any().isnull()
#no null values
customers.info()
#total charges is an object


# In[None]

#customers['TotalCharges'] = pd.to_numeric(customers['TotalCharges'], errors='raise')   
#converting total charges to float, found non integer elements ' '
nonintegers = customers[customers['TotalCharges'] == ' '] 
to_drop = nonintegers.index.tolist()
to_drop

# In[None]

customers = customers.drop(to_drop, axis='index')
customers['TotalCharges'] = pd.to_numeric(customers['TotalCharges'], errors='raise') 

# In[None]

customers.any().isnull()
#no NaN's in TotalCharges
#i want to convert all the yes/no's to 1's and 0's in churn
customers['Churn'] = customers['Churn'].map(dict({'Yes':1,'No':0}))


# In[None]

import plotly as py
import plotly.graph_objs as go
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
init_notebook_mode(connected=True)


# L# e# t# '# s#  # c# h# e# c# k#  # t# h# e#  # d# e# m# o# g# r# a# p# h# i# c# s#  # o# f#  # t# h# e#  # p# e# o# p# l# e#  # w# h# o#  # d# i# s# c# o# n# t# i# n# u# e# d#  # t# h# e# i# r#  # s# e# r# v# i# c# e# .

# In[None]

demographics = ['gender', 'Partner', 'SeniorCitizen', 'Dependents']


for i in demographics:
    trace1 = go.Bar(
        x=customers.groupby(i)['Churn'].sum().reset_index()[i],
        y=customers.groupby(i)['Churn'].sum().reset_index()['Churn'],
        name= i
    )

    data = [trace1]
    layout = go.Layout(
        title= i,
        yaxis=dict(
        title='Churn'
        ),
        barmode='group',
        autosize=True,
    width=600,
    height=600,
    margin=go.Margin(
        l=70,
        r=70,
        b=100,
        t=100,
        pad=8
    )
    )
    fig = go.Figure(data=data, layout=layout)
    py.offline.iplot(fig)


# 1# 8# 6# 9#  # p# e# o# p# l# e#  # c# a# n# c# e# l# l# e# d#  # t# h# e# i# r#  # s# e# r# v# i# c# e# .#  # 
# 
# *#  # R# e# g# a# r# d# i# n# g#  # t# h# e#  # g# e# n# d# e# r#  # o# f#  # t# h# e#  # p# r# e# s# u# m# e# d#  # a# c# c# o# u# n# t#  # h# o# l# d# e# r# ,#  # i# t#  # l# o# o# k# s#  # l# i# k# e#  # t# h# i# s#  # d# a# t# a# s# e# t#  # h# a# s#  # a# n#  # e# v# e# n#  # a# m# o# u# n# t#  # o# f#  # c# h# u# r# n# e# r# s#  # b# e# t# w# e# e# n#  # m# e# n#  # a# n# d#  # w# o# m# e# n# .#  # 
# *#  # A# l# m# o# s# t#  # 2# x#  # t# h# e#  # r# a# t# e#  # o# f#  # c# h# u# r# n#  # a# m# o# n# g# s# t#  # p# e# o# p# l# e#  # w# i# t# h# o# u# t#  # a#  # p# a# r# t# n# e# r# .# 
# *#  # A#  # l# a# r# g# e#  # m# a# r# j# o# r# i# t# y#  # w# e# r# e#  # n# o# t#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s#  # (# 7# 4# %# )# ,#  # a# n# d#  # h# a# d#  # n# o#  # d# e# p# e# n# d# e# n# t# s#  # (# 8# 2# %# )# .# 
# 
# A# l# s# o# ,#  # c# h# e# c# k# i# n# g#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s#  # (# 1# 1# 4# 2# )#  # s# h# o# w# s#  # t# h# a# t#  # n# e# a# r# l# y#  # 4# 2# %#  # o# f#  # t# h# e# m#  # d# i# s# c# o# n# t# i# n# u# e#  # t# h# e# i# r#  # s# e# r# v# i# c# e# .#  # C# o# m# p# a# r# e#  # t# h# a# t#  # t# o#  # 2# 0# %#  # o# f#  # e# v# e# r# y# o# n# e#  # e# l# s# e# ,#  # a# n# d#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # s# e# n# i# o# r# s#  # a# r# e#  # a# l# m# o# s# t#  # 2# x#  # a# s#  # l# i# k# e# l# y#  # t# o#  # s# t# o# p#  # u# s# i# n# g#  # t# h# e#  # s# e# r# v# i# c# e# .#  # 
# 


# In[None]

seniors = customers.loc[customers['SeniorCitizen'] == 1]

nonseniors = customers.loc[customers['SeniorCitizen'] == 0]


# In[None]

hist_data = [seniors.groupby('tenure')['Churn'].sum(),nonseniors.groupby('tenure')['Churn'].sum()]
group_labels = ['Seniors', 'Non-Seniors']

import plotly.figure_factory as ff
fig = ff.create_distplot(hist_data, group_labels,bin_size=[1,1], curve_type='normal', show_rug=False)
py.offline.iplot(fig)

# W# e#  # c# a# n#  # s# e# e#  # h# o# w#  # d# i# f# f# e# r# e# n# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # a# r# e# .#  # S# e# n# i# o# r# s#  # a# r# e#  # m# o# s# t# l# y#  # l# e# a# v# i# n# g#  # w# i# t# h# i# n#  # 4#  # m# o# n# t# h# s# .#  # T# h# e# r# e#  # i# s#  # a# n#  # o# p# p# o# r# t# u# n# i# t# y#  # t# h# e# r# e#  # t# o#  # f# i# g# u# r# e#  # o# u# t#  # w# h# y#  # s# u# c# h#  # s# h# o# r# t#  # t# e# n# u# r# e# s# ,#  # b# u# t#  # I# '# m#  # a# l# s# o#  # a# w# a# r# e#  # t# h# a# t#  # t# h# e# r# e#  # m# a# y#  # b# e#  # o# t# h# e# r#  # a# g# e#  # g# r# o# u# p# s#  # t# h# a# t#  # h# a# v# e#  # h# i# g# h# e# r#  # e# a# r# l# y#  # c# h# u# r# n# .

# In[None]

customers['InternetService'].value_counts()

# In[None]

customers.groupby('InternetService')['Churn'].sum()
#Nearly half of the customers who took fiber optic left

# In[None]

seniors.groupby('InternetService')['Churn'].sum()

# In[None]

mask = ['DSL','Fiber optic']
internet = customers[customers['InternetService'].isin(mask)]

# In[None]

categories = ['InternetService', 'OnlineSecurity', 'OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies','Contract',
             'PaperlessBilling','PaymentMethod']
internet.info()

# In[None]

dumm = pd.get_dummies(internet,columns=categories,drop_first=True)

# In[None]

corr = dumm.corr(method='spearman')
corr

# In[None]

mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr,cmap=cmap, mask=mask,vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})

# In[None]

y = dumm.iloc[:,10].values
dumm = dumm.drop(['customerID','Churn'],axis=1)


# In[None]

X = dumm

# In[None]

y



# In[None]

mask = ['gender','Partner','Dependents','PhoneService','MultipleLines']
X = pd.get_dummies(dumm,columns=mask,drop_first=True)


# In[None]

X.head()

# In[None]

#Splitting the dataset into the Training set and Test set
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1576440.npy", { "accuracy_score": score })

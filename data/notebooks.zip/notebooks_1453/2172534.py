import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

['WA_Fn-UseC_-Telco-Customer-Churn.csv']

# In[None]

cust=pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

cust.head()

# In[None]

cust.dtypes

# In[None]

cust.info

# In[None]

cust.describe

# In[None]

cust.shape

# In[None]

#totalcharges kolonunun numaric değere dönüştürülmesi
cust.TotalCharges = pd.to_numeric(cust.TotalCharges, errors='coerce')
cust.isnull().sum()

# In[None]

#Eksik değerlerin kaldırılması
cust.dropna(inplace = True)
#CustomerID kolonunun silinmesi
df2 = cust.iloc[:,1:]
#Değerlerin numaric yapılması
df2['Churn'].replace(to_replace='Yes', value=1, inplace=True)
df2['Churn'].replace(to_replace='No',  value=0, inplace=True)

#Kategorik değişkenlerin dönüştürülmesi
df_dummies = pd.get_dummies(df2)
df_dummies.head()

# In[None]

#Veri ön işleme sonrası kontroller

# In[None]

df_dummies.dtypes

# In[None]

df_dummies.shape

# In[None]

#Histogram Gösterimi
import matplotlib.pyplot as plt
num_bins = 10
df_dummies.hist(bins=num_bins, figsize=(20,15))

# In[None]

#Korelasyon Gösterim 1
import matplotlib.pyplot as plt
plt.matshow(df_dummies.corr())

# In[None]

#Korelasyon gösterim 2
import seaborn as sns
corr = df_dummies.corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values)

# In[None]

#curn değerinin diğer değerlerle olan korelasyonu
plt.figure(figsize=(15,8))
df_dummies.corr()['Churn'].sort_values(ascending = False).plot(kind='bar')

#churn değerini artı yönde en çok etkileyen kolon Contract_Month-to-month kolonudur

#bunun anlamı artı yönde olan değer arttıkça churn olma ihtimalinin artmasıdır.
#yinede bu 0.4 korelasyonu yeterli bir korelasyon değeri değildir

#churn değerini eksi yönde en çok etkileyen kolon tenure kolonudur.

#bunun anlamı eksi yönde olan değer azaltıkça churn olma ihtimalinin artmasıdır.
#Yinede bu -0.3 korelasyon değeri yeterli bir korelasyon değildir.

# In[None]

#Churn ile diğer kolonlar arasındaki korelasyon !düzmetin
df_dummies.corr()['Churn'].sort_values(ascending = False)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn import preprocessing

#Eğitim  ve test verisini parcaliyoruz --> 80% / 20%
X = df_dummies.ix[:, df_dummies.columns != 'Churn']
Y = df_dummies['Churn']

from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2172534.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

churn_data = pd.read_csv("../input/watson.csv")
churn_data.head()

# In[None]

churn_data.shape

# In[None]

churn_data.info()

# In[None]

churn_data.describe()

# In[None]

#dropping customerID 
churn_data = churn_data.drop('customerID',axis=1)


# In[None]

churn_data.isna().sum()

# In[None]

churn_data['TotalCharges'] = pd.to_numeric(churn_data['TotalCharges'],errors='coerce')
churn_data['TotalCharges'].fillna(churn_data['TotalCharges'].median(),inplace=True)

# In[None]

churn_data.info()

# In[None]

churn_objdata = churn_data.select_dtypes(include='object')


# In[None]

churn_numdata = churn_data.select_dtypes(include=['int','float'])

# In[None]

churn_objdata.head()

# In[None]

from sklearn.preprocessing import LabelEncoder ,MinMaxScaler
churn_objdata=churn_objdata.apply(LabelEncoder().fit_transform)

# In[None]

churn_objdata.shape

# In[None]

churn_objdata['InternetService'].value_counts()

# In[None]

churn_numdata.head()

# In[None]

lis_num = ['tenure','MonthlyCharges','TotalCharges']
minmax=MinMaxScaler()
for i in lis_num:
    churn_numdata[i+'_norm'] = minmax.fit_transform(np.array(churn_numdata[i]).reshape(-1,1))
    

# In[None]

churn_numdata.drop(['tenure','MonthlyCharges','TotalCharges'],axis=1,inplace=True)
churn_numdata.head()

# In[None]

final_data = pd.concat([churn_numdata,churn_objdata],axis=1)

# In[None]

final_data.head()

# In[None]

final_data.corr()['Churn']

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve,auc,accuracy_score,precision_score,recall_score

# In[None]

X =final_data.drop('Churn',axis=1)
Y=final_data['Churn']

# In[None]

from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/4859427.npy", { "accuracy_score": score })

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LogisticRegression 
from sklearn.metrics import classification_report 
import matplotlib.pyplot as plt 
ad_path="../input/advertising/advertising.csv"
ad_data=pd.read_csv(ad_path)
ad_data.head()
ad_data.describe()
y=ad_data["Clicked on Ad"]
X= ad_data[["Daily Time Spent on Site","Age","Area Income","Daily Internet Usage","Male"]]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
lgmodel=LogisticRegression()
#lgmodel.fit(X_train,y_train)
#predictions =lgmodel.predict(X_test)
#print(classification_report(y_test,predictions))
#final_predictions = lgmodel.predict(X)
#predic = pd.DataFrame({'Predict_Click on Ad': final_predictions})
#output=pd.concat([X,predic], axis=1)
#output.head()
#output.to_csv('Ad_predictions.csv', index=False)
print("Your output was successfully saved!")



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/achouak_logistic-regression-advertising-example.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/achouak_logistic-regression-advertising-example/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/achouak_logistic-regression-advertising-example/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/achouak_logistic-regression-advertising-example/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/achouak_logistic-regression-advertising-example/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/achouak_logistic-regression-advertising-example/testY.csv",encoding="gbk")


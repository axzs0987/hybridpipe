import pandas as pd
# ##  # P# r# i# m# e# i# r# o#  # t# r# a# b# a# l# h# o#  # d# e#  # A# p# r# e# n# d# i# z# a# d# o#  # d# e#  # M# á# q# u# i# n# a

# ## ##  # B# a# s# e#  # d# e#  # d# a# d# o# s# 
# 
# A#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # p# o# d# e#  # s# e# r#  # e# n# c# o# n# t# r# a# d# a#  # e# m#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# j# s# p# h# y# g# /# w# e# a# t# h# e# r# -# d# a# t# a# s# e# t# -# r# a# t# t# l# e# -# p# a# c# k# a# g# e# 
# 
# E# l# a#  # c# o# n# t# ê# m#  # i# n# f# o# r# m# a# ç# õ# e# s#  # s# o# b# r# e#  # o# b# s# e# r# v# a# ç# õ# e# s#  # d# i# á# r# i# a# s#  # d# o#  # t# e# m# p# o#  # e# m#  # v# á# r# i# a# s#  # e# s# t# a# ç# õ# e# s#  # m# e# t# e# o# r# o# l# ó# g# i# c# a# s#  # d# a#  # A# u# s# t# r# á# l# i# a#  # p# a# r# a#  # p# r# e# v# e# r#  # s# e#  # v# a# i#  # o# u#  # n# ã# o#  # c# h# o# v# e# r#  # a# m# a# n# h# ã#  # a# t# r# a# v# é# s#  # d# o#  # t# r# e# i# n# a# m# e# n# t# o#  # d# e#  # u# m#  # m# o# d# e# l# o#  # d# e#  # c# l# a# s# s# i# f# i# c# a# ç# ã# o#  # b# i# n# á# r# i# a#  # n# o#  # a# l# v# o#  # "# R# a# i# n# T# o# m# o# r# r# o# w# "#  # (# S# i# m#  # o# u#  # N# ã# o# )# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os

# Any results you write to the current directory are saved as output.

# ## ##  # A# p# r# e# s# e# n# t# a# ç# ã# o#  # d# o# s#  # d# a# d# o# s

# In[None]

# Import das bibliotecas necessárias para rodar o programa
import numpy as np
import matplotlib.pyplot as plt
import sklearn.metrics
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
import graphviz
from sklearn import tree
from sklearn.tree import export_graphviz
from sklearn.metrics import roc_auc_score,roc_curve

# In[None]

# Lendo os dados do Dataset
dados = pd.read_csv('weatherAUS.csv')
print(dados.shape)

# In[None]

# Visualizando as primeiras 5 instâncias do Dataset
dados.head()

# In[None]

# Analisando mais detalhadamente cada coluna do Dataset
dados.describe()

# In[None]

# Verificando o tipo dos dados presentes na tabela
dados.dtypes

# ## ##  # P# r# é# -# p# r# o# c# e# s# s# a# m# e# n# t# o

# In[None]

# Descobrindo se há dados faltantes, caso seja True pode-se afirmar que existem dados faltantes na respectiva coluna
dados.isnull().any()

# In[None]

# Colocando as colunas com dados faltantes em uma lista para serem tratadas futuramente. Nessa lista são colocadas
# apenas as colunas com dados numéricos
colunas_dados_faltantes = ['MinTemp', 'MaxTemp', 'Rainfall', 'Evaporation', 'Sunshine', \
                           'WindGustSpeed', 'WindSpeed9am', 'WindSpeed3pm', \
                           'Humidity9am', 'Humidity3pm', 'Pressure9am', 'Pressure3pm', 'Cloud9am', \
                           'Cloud3pm', 'Temp9am', 'Temp3pm']

# Substituindo valores numéricos com a média dos valores não nulos presentes na coluna
for coluna in colunas_dados_faltantes:
    dados[coluna] = dados[coluna].fillna(dados[coluna].mean())
    
# Colocando as colunas com dados faltantes em uma lista. Nessa lista são colocadas as colunas com dados categóricos
colunas_dados_categoricos = ['WindGustDir', 'WindDir3pm', 'WindDir9am']

# Substituindo valores categóricos pela moda dos valores não nulos presentes na coluna
for coluna in colunas_dados_categoricos:
    dados[coluna] = dados[coluna].fillna(dados[coluna].mode()[0])

# Verificando se ainda existem dados faltantes no Dataset
dados.isnull().any()

# In[None]

# Substituindo os valores de objeto dos atributos 'RainToday' pra 0 e 1 (antes eram "Yes" e "No")
# e substituindo valores faltantes por 0
dados['RainToday'] = dados['RainToday'].replace({'No': 0, 'Yes': 1}).fillna(0)

# In[None]

# Substituindo No e Yes por 0 e 1 para o atributo alvo
dados['RainTomorrow'] = dados['RainTomorrow'].replace({'No': 0, 'Yes': 1})

# In[None]

# Verificando quantas cidades existem no Dataset
len(set(dados['Location']))

# In[None]

# Escolhemos LabelEncoder porque há 49 localizações diferentes e, portanto, 
# seriam necessários mais 49 atributos utilizando One-HotEncoder

from sklearn import preprocessing

colunas_dados_categoricos.append('Location')

for coluna in colunas_dados_categoricos:
    le = preprocessing.LabelEncoder()
    le.fit(dados[coluna])
    dados[coluna] = le.transform(dados[coluna])

# In[None]

# Visualizando as primeiras 5 instâncias do Dataset, para analisar as mudanças feitas
dados.head()

# In[None]

# Novamente analisando mais detalhadamente cada coluna do Dataset, agora sem os dados faltantes
dados.describe()

# In[None]

# Analisando a correlação dos dados do Dataset
# Para isso, plotamos a matriz de correlação entre os valores numéricos

rain_data_num = dados[['MinTemp','MaxTemp','Rainfall','WindSpeed9am','WindSpeed3pm',
                           'Humidity9am','Humidity3pm','Pressure9am','Pressure3pm',
                           'Temp9am','Temp3pm','RainToday','RainTomorrow', 'RISK_MM']]
plt.figure(figsize=(12,8))
sns.heatmap(rain_data_num.corr(),annot=True,cmap='bone',linewidths=0.25)

# P# e# r# c# e# b# e# -# s# e#  # q# u# e#  # a#  # c# o# l# u# n# a#  # `# T# e# m# p# 9# a# m# `#  # s# e#  # c# o# r# r# e# l# a# c# i# o# n# a#  # c# o# m#  # a# l# g# u# m# a# s#  # o# u# t# r# a# s# .# 
# 
# A# s# s# i# m# ,#  # é#  # i# n# t# e# r# e# s# s# a# n# t# e#  # d# e# s# c# o# n# s# i# d# e# r# á# -# l# a# .

# In[None]

# Desconsiderando a coluna Temp9am
dados = dados.drop(columns=['Temp9am', 'MaxTemp', 'MinTemp'])

# In[None]

# Desconsiderando a coluna: RISK_MM
# Note: You should exclude the variable Risk-MM when training a binary classification model. 
# Not excluding it will leak the answers to your model and reduce its predictability.
dados = dados.drop(columns=['RISK_MM'])

# In[None]

rain_data_num = dados[['Rainfall','WindSpeed9am','WindSpeed3pm',
                           'Humidity9am','Humidity3pm','Pressure9am','Pressure3pm',
                           'Temp3pm','RainToday','RainTomorrow']]
plt.figure(figsize=(12,8))
sns.heatmap(rain_data_num.corr(),annot=True,cmap='bone',linewidths=0.25)

# ## ##  # G# r# á# f# i# c# o# s

# In[None]

#Plotando gráficos relacionandos à coluna Humidity3pm com RainTomorrow para analisar como os dados da humidade 
# do ar as 3pm se relacionam com a probabilidade de chover amanhã.

sns.catplot(x='RainTomorrow', y='Humidity3pm', hue='RainTomorrow',
            kind="violin", split=False, data=dados);

# A# s# s# i# m# ,#  # p# o# d# e# -# s# e#  # p# e# r# c# e# b# e# r#  # q# u# e# ,#  # q# u# a# n# d# o#  # a#  # h# u# m# i# d# a# d# e#  # t# e# m#  # v# a# l# o# r# e# s#  # e# n# t# r# e#  # 6# 0#  # e#  # 8# 0# ,#  # h# á#  # u# m# a#  # m# a# i# o# r#  # c# h# a# n# c# e#  # d# e#  # c# h# o# v# e# r#  # a# m# a# n# h# ã# ,#  # 
# r# e# p# r# e# s# e# n# t# a# d# a#  # p# e# l# o#  # g# r# á# f# i# c# o#  # l# a# r# a# n# j# a# .#  # J# á#  # a#  # p# a# r# t# e#  # m# a# i# s#  # s# i# g# n# i# f# i# c# a# t# i# v# a#  # d# o# s#  # d# a# d# o# s#  # q# u# e#  # m# o# r# t# r# a# m#  # q# u# e#  # n# ã# o#  # v# a# i#  # c# h# o# v# e# r#  # 
# a# m# a# n# h# ã#  # s# e#  # e# n# c# o# n# t# r# a#  # e# n# t# r# e#  # 4# 0#  # e#  # 6# 0# .

# ## ##  # C# l# a# s# s# i# f# i# c# a# ç# ã# o

# In[None]

from statistics import stdev
# Divisão dos dados para treinamento e teste
Y = dados.pop('RainTomorrow').values
X = dados.drop(columns=['Date']).values

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4102169.npy", { "accuracy_score": score })

import pandas as pd
# >#  # *#  # D# a# t# a#  # P# r# e# p# a# r# a# t# i# o# n# 
# >#  # *#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# >#  # *#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # S# c# k# i# t#  # L# e# a# r# n# 
# >#  # *#  # 2#  # L# a# y# e# r#  # A# N# N# 
# >#  # *#  # 3#  # L# a# y# e# r#  # A# N# N#  # w# i# t# h#  # K# e# r# a# s

# ## ##  # D# a# t# a#  # P# r# e# p# a# r# a# t# i# o# n

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

import os
#print(os.listdir("../input"))

# In[None]

data = pd.read_csv("../input/voice.csv")

# In[None]

data.label = [1 if each == "male" else 0 for each in data.label]
data.label.values

# In[None]

data.head()

# In[None]

data.info()

# In[None]

data.describe()

# In[None]

y = data.label.values
x = data.drop(['label'],axis=1)
x = (x-np.min(x))/(np.max(x)-np.min(x)).values # Normalize

print("y: ", y.shape)
print("x: ", x.shape)

# ## ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2188645.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
from sklearn import preprocessing

# Any results you write to the current directory are saved as output.

# In[None]

df = pd.read_csv("/kaggle/input/sloan-digital-sky-survey/Skyserver_SQL2_27_2018 6_51_39 PM.csv")

# In[None]

df.head(10)

# In[None]

df.columns

# In[None]

labels = df['class']
df.drop('class' , inplace = True , axis = 1 )
print(labels.unique())

# In[None]

listt = df.columns
dict = []
for i in listt :
    dict.append(( len(df[i].unique()) / df.shape[0] , i ))

# In[None]

dict = sorted(dict)
for i , j in   dict:
    print( i , j )

# In[None]

# drop first 2 columns 
df.drop(['objid' , 'rerun'] , inplace = True , axis = 1 )

# In[None]

dict2 = []
for i in df.columns :
    dict2.append( ( df[i].isnull().sum() , i ) )
dict2 = sorted(dict2 , reverse = False)
for i , j in dict2 :
    print( i , j )

# In[None]

df.describe()

# In[None]

from sklearn.preprocessing import StandardScaler

ss = StandardScaler()
df = ss.fit_transform(df)


# In[None]

df1 = pd.DataFrame(df)

# In[None]

le = preprocessing.LabelEncoder()
labels = le.fit_transform(labels)
print(labels)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df1, labels, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7903034.npy", { "accuracy_score": score })

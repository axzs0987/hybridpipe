import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# *# *# A# n# a# l# y# s# e#  # t# h# e#  # D# a# t# a# *# *#  

# In[None]

data=pd.read_csv('../input/sloan-digital-sky-survey/Skyserver_SQL2_27_2018 6_51_39 PM.csv')
data.head(5)

# In[None]

data.columns

# In[None]

#♠move the target data to the end of the dataframe 
def ToTheEnd(df,column):
    Target_data=df[column]
    df=df.drop([column],axis=1)
    df[column]=Target_data
    return df

data=ToTheEnd(data,'class')


# c# h# e# c# k#  # f# o# r#  # n# u# l# l#  # v# a# l# u# e# s

# In[None]

data.info()

# g# r# e# a# t# !# !#  # n# o#  # n# u# l# l#  # v# a# l# u# e# s#  

# In[None]

data['class'].head(10)
ax = sns.countplot(x='class',data=data)

# d# e# a# l#  # w# i# t# h#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  

# In[None]

data['class']=data['class'].map({'STAR':0,'GALAXY':1,'QSO':2}).astype(int)

# In[None]

ax = plt.subplots(figsize=(10,8))
sns.heatmap(data.corr(), vmax=.8 ,annot=True,square=True,fmt=".2f")

# S# o# m# e# t# h# i# n# g#  # n# o# t#  # r# i# g# h# t#  # 
# y# e# s#  # !#  # w# e#  # s# h# o# u# l# d#  # r# e# m# o# v# e#  # t# h# e#  # u# n# n# e# c# e# s# s# a# r# y#  # f# e# a# t# u# r# e# s#  

# In[None]

data=data.drop(['objid','rerun','specobjid','fiberid'],axis=1)
#recall the heatmap
ax = plt.subplots(figsize=(10,8))
sns.heatmap(data.corr(), vmax=.8 , annot=True,square=True,fmt=".2f")

# L# o# o# k#  # C# o# o# l# !# !

# In[None]

data.describe()

# m# o# v# e#  # t# o#  # f# e# a# t# u# r# e# s#  # d# i# s# t# r# i# b# u# t# i# o# n

# In[None]

def feature_dist(df0,df1,df2,label0,label1,label2,features):
    plt.figure()
    fig,ax=plt.subplots(13,1,figsize=(8,45))
    i=0
    for ft in features:
        i+=1
        plt.subplot(13,1,i)
        # plt.figure()
        sns.distplot(df0[ft], hist=False,label=label0)
        sns.distplot(df1[ft], hist=False,label=label1)
        sns.distplot(df2[ft], hist=False,label=label2)
        plt.xlabel(ft, fontsize=11)
        #locs, labels = plt.xticks()
        plt.tick_params(axis='x', labelsize=9)
        plt.tick_params(axis='y', labelsize=9)
    plt.show()
t0 = data.loc[data['class'] == 0]
t1 = data.loc[data['class'] == 1]
t2 = data.loc[data['class'] == 2]
features = data.columns.values[:13]
feature_dist(t0,t1,t2, 'STAR', 'GALAXY','QSO', features)

# c# h# e# c# k#  # t# h# e#  # r# e# d# s# h# i# f# t#  # f# e# a# t# u# r# e#  # "# n# o# t# i# c# e#  # t# h# e#  # g# r# a# p# h# "#  

# In[None]

#data['redshift'].describe()
data[['redshift','class']].groupby(['class'],as_index=False).mean().sort_values(by='class',ascending=False)


# n# o# w#  # e# v# e# r# y# t# h# i# n# g#  # l# o# o# k#  # c# l# e# a# r#  # r# i# g# h# t#  # ?

# *# *# P# r# e# p# a# r# e#  # d# a# t# a# *# *

# In[None]

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# In[None]

X=data.drop(['class'],axis=1)
y=data['class']

# In[None]

X=StandardScaler().fit_transform(X)

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9214030.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder , StandardScaler
from sklearn.model_selection import train_test_split ,cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix , accuracy_score

# In[None]

data = pd.read_csv("../input/adult-income-dataset/adult.csv")
data.head(10)

# In[None]

data.info()

# In[None]

data.describe()

# In[None]

data.isnull().sum()

# In[None]

sns.heatmap(data.isnull() , yticklabels=False)

# In[None]

data.isin(['?']).sum(axis=0)

# In[None]

data['native-country'] = data['native-country'].replace('?',np.nan)
data['workclass'] = data['workclass'].replace('?',np.nan)
data['occupation'] = data['occupation'].replace('?',np.nan)

# In[None]

data.isin(['?']).sum(axis=0)

# In[None]

data.isnull().sum()

# In[None]

data.dropna(how='any',inplace=True)

# In[None]

plt.figure(figsize = (16,9))
sns.countplot(data["workclass"])

# In[None]

plt.figure(figsize = (16,9))
sns.countplot(data["occupation"])

# In[None]

data["native-country"].value_counts()

# In[None]

data.columns

# In[None]

data.drop(['educational-num','age', 'hours-per-week', 'fnlwgt', 'capital-gain','capital-loss', 'native-country'], axis=1, inplace=True)

# In[None]

data.head(10)

# In[None]

data['income'] = data['income'].map({'<=50K': 0, '>50K': 1}).astype(int)

# In[None]

l = LabelEncoder()
data["gender"] = l.fit_transform(data["gender"])
data["race"] = l.fit_transform(data["race"])
data["race"] = l.fit_transform(data["race"])
data["marital-status"] = l.fit_transform(data["marital-status"])
data["workclass"] = l.fit_transform(data["workclass"])
data["education"] = l.fit_transform(data["education"])
data["occupation"] = l.fit_transform(data["occupation"])
data["relationship"] = l.fit_transform(data["relationship"])



# In[None]

data.head(10)

# In[None]

sns.distplot(data["workclass"] )

# In[None]

sns.distplot(data["occupation"])

# In[None]

plt.figure(figsize  = (16,9))
sns.heatmap(data.corr(), annot = True)

# In[None]

plt.figure(figsize = (16,9))
sns.pairplot(data)

# In[None]

x = data.iloc[:,:-1].values
y = data.iloc[:,-1].values

# In[None]

from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/11566222.npy", { "accuracy_score": score })

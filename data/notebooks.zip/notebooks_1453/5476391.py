import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import recall_score, confusion_matrix, precision_score, f1_score, accuracy_score, classification_report

# In[None]

df = pd.read_csv('/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# ## ## ##  # O# v# e# r# v# i# e# w

# In[None]

df.head()

# In[None]

print('Rows: {}, Columns: {}'.format(df.shape[0], df.shape[1]))
features = df.columns.to_list()
features.remove('Churn')
print('Features:\n', features, sep='')

# L# e# t# '# s#  # d# r# o# p#  # t# h# e#  # c# u# s# t# o# m# e# r#  # i# d# s#  # a# s#  # t# h# e# y#  # d# o#  # n# o# t#  # h# a# v# e#  # a# n# y# t# h# i# n# g#  # t# o#  # d# o#  # w# i# t# h#  # c# h# u# r# n# i# n# g# .

# In[None]

df.drop(["customerID"], axis = 1,inplace = True)

# C# h# e# c# k# i# n# g#  # i# f#  # t# h# e# r# e#  # a# r# e#  # a# n# y#  # n# u# l# l#  # v# a# l# u# e# s# .

# In[None]

df.isnull().sum()

# S# e# e# m# s#  # l# i# k# e#  # t# h# e# r# e#  # a# r# e#  # n# o#  # N# a# N# s# .# 
# 
# B# u# t#  # t# o#  # b# e#  # 1# 0# 0# %#  # s# u# r# e# ,#  # l# e# t# '# s#  # s# e# e#  # i# f#  # t# h# e# r# e#  # i# s#  # s# o# m# e# t# h# i# n# g#  # e# l# s# e#  # i# n#  # p# l# a# c# e#  # o# f#  # a#  # v# a# l# u# e# .

# In[None]

def check_values():
    for i in range(df.columns.size):
        print(df.columns[i] + ':')
        for j in range(df[df.columns[i]].size):
            if df[df.columns[i]][j] == ' ' :
                print('Found space')
            elif df[df.columns[i]][j] == '-' :
                print('Found hyphen')
            elif df[df.columns[i]][j] == 'NA' :
                print('Found NA')
        print('Done!')

# In[None]

check_values()

# W# e#  # h# a# v# e#  # f# o# u# n# d#  # '# S# p# a# c# e# s# '#  # i# n#  # T# o# t# a# l# C# h# a# r# g# e# s#  # c# o# l# u# m# n#  # w# h# i# c# h#  # c# a# n# '# t#  # b# e#  # u# s# e# d#  # f# o# r#  # t# r# a# i# n# i# n# g# .# 
# 
# L# e# t# '# s#  # f# i# x#  # t# h# i# s# .

# In[None]

# replacing spaces with null values
df['TotalCharges'] = df['TotalCharges'].replace(' ', np.nan)

# In[None]

check_values()

# In[None]

df.isnull().sum()

# In[None]

df = df[df["TotalCharges"].notnull()]

# In[None]

df.isnull().sum()

# F# i# x# i# n# g#  # t# h# e#  # i# n# d# e# x# .

# In[None]

df.reset_index(drop = True, inplace = True)

# L# e# t# '# s#  # c# h# e# c# k#  # i# f#  # t# h# e#  # d# a# t# a#  # t# y# p# e# s#  # a# r# e#  # d# e# f# i# n# e# d#  # p# r# o# p# e# r# l# y# .

# In[None]

df.dtypes

# T# o# t# a# l# C# h# a# r# g# e# s#  # i# s#  # o# f#  # o# b# j# e# c# t#  # d# a# t# a#  # t# y# p# e# ,#  # w# e#  # n# e# e# d#  # t# o#  # c# o# n# v# e# r# t#  # i# t#  # i# n# t# o#  # f# l# o# a# t# .

# In[None]

df.TotalCharges = df.TotalCharges.astype(float)

# In[None]

df.dtypes

# L# e# t# '# s#  # s# e# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # u# n# i# q# u# e#  # v# a# l# u# e# s#  # i# n#  # o# u# r#  # d# a# t# a# .

# In[None]

df.nunique()

# In[None]

for i in range(df.columns.size) :
    if df[df.columns[i]].nunique() <= 4:
        print(df[df.columns[i]].unique())

# M# a# p# p# i# n# g#  # y# e# s#  # t# o#  # 1# ,#  # n# o#  # t# o#  # 0#  # a# n# d#  # n# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # t# o#  # -# 1# .

# In[None]

col_map = ['Partner', 
          'Dependents', 
          'PhoneService', 
          'MultipleLines',
          'OnlineSecurity',
          'OnlineBackup',
          'DeviceProtection',
          'TechSupport',
          'StreamingTV',
          'StreamingMovies',
          'PaperlessBilling', 
          'Churn']
for col in col_map:
    df[col] = [1 if val == "Yes" else 0 if val == "No" else -1 for val in df[col]]

# In[None]

for i in range(df.columns.size) :
    if df[df.columns[i]].nunique() <= 4:
        print(df[df.columns[i]].unique())

# M# a# p# p# i# n# g#  # m# a# l# e#  # t# o#  # 1#  # a# n# d#  # f# e# m# a# l# e#  # t# o#  # 0#  # i# n#  # G# e# n# d# e# r#  # c# o# l# u# m# n# .

# In[None]

df['gender'] = [1 if gen == 'Male' else 0 for gen in df['gender']]

# In[None]

df.head()

# ## ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # a# n# d#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# L# e# t# '# s#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

plt.figure(figsize = [15, 6])
plt.pie(df['Churn'].value_counts(), 
        labels = ['No', 'Yes'], 
        startangle = 90, 
        autopct='%1.1f%%', 
        wedgeprops = {'width' : 0.2},
        counterclock = True);
plt.title('Customer churn')
plt.legend()
plt.axis('equal');

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # *# *# 2# 6# .# 6# %# *# *#  # o# f#  # t# h# e#  # t# o# t# a# l#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # c# h# u# r# n# e# d#  # o# u# t# .

# In[None]

plt.figure(figsize = [15, 6])
plt.suptitle('Gender distribution')

plt.subplot(1, 2, 1)
plt.pie(df[df['Churn'] == 1]['gender'].value_counts(), 
        labels = ['Female', 'Male'], 
        startangle = 90, 
        autopct='%1.1f%%', 
        wedgeprops = {'width' : 0.2},
        counterclock = True);
plt.legend()
plt.text(-0.13,-0.03, 'Churn',fontsize = 14)
plt.axis('equal')

plt.subplot(1, 2, 2)
plt.pie(df[df['Churn'] == 0]['gender'].value_counts(), 
        labels = ['Male', 'Female'], 
        startangle = 90, 
        autopct='%1.1f%%', 
        wedgeprops = {'width' : 0.2},
        counterclock = True);
plt.legend()
plt.text(-0.22,-0.03, 'Not Churn',fontsize = 14)
plt.axis('equal');

# W# e#  # d# o#  # n# o# t#  # o# b# s# e# r# v# e#  # a# n# y#  # d# r# a# s# t# i# c#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # c# h# u# r# n#  # a# n# d#  # n# o# t#  # c# h# u# r# n#  # c# u# s# t# o# m# e# r# s#  # b# a# s# e# d#  # o# n#  # t# h# e# i# r#  # _# g# e# n# d# e# r# _# .

# A# n# a# l# y# s# i# z# i# n# g#  # t# h# e#  # p# r# o# b# a# b# i# l# i# t# y#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # o# f#  # c# h# u# r# n#  # a# n# d#  # n# o# t#  # c# h# u# r# n#  # c# u# s# t# o# m# e# r# s#  # a# g# a# i# n# s# t#  # v# a# r# i# o# u# s#  # f# e# a# t# u# r# e# s#  # u# s# i# n# g#  # K# e# r# n# e# l#  # D# e# n# s# i# t# y#  # E# s# t# i# m# a# t# e# (# K# D# E# )#  # p# l# o# t# .

# In[None]

bluish = sns.color_palette()[0]
orangish = sns.color_palette()[1]

# In[None]

plt.figure(figsize = [15, 8])
ten_dist = sns.kdeplot(df['tenure'][df["Churn"] == 0], color = bluish, shade = True)
ten_dist = sns.kdeplot(df['tenure'][df["Churn"] == 1], color = orangish, shade= True)
ten_dist.legend(['Not Churn', 'Churn'])
ten_dist.set_xlabel('Tenure')
ten_dist.set_ylabel('Frequency')
plt.xticks(np.arange(0, 80, 5))
plt.title('Distribution of tenure for churn and not churn customers');

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # c# h# u# r# n# i# n# g#  # o# u# t#  # i# s#  # m# a# x# i# m# u# m#  # f# o# r#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # a#  # *# *# s# h# o# r# t#  # t# e# n# u# r# e# *# *#  # (# b# e# t# w# e# e# n#  # 0#  # t# o#  # a# p# p# r# o# x# .#  # 1# 5# )# .

# In[None]

plt.figure(figsize = [15, 8])
ten_dist = sns.kdeplot(df['MonthlyCharges'][df["Churn"] == 0], color = bluish, shade = True)
ten_dist = sns.kdeplot(df['MonthlyCharges'][df["Churn"] == 1], color = orangish, shade= True)
ten_dist.legend(['Not Churn', 'Churn'])
ten_dist.set_xlabel('Monthly charges')
ten_dist.set_ylabel('Frequency')
plt.title('Distribution of monthly charges for churn and not churn customers');

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # m# o# s# t#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d#  # o# u# t#  # h# a# v# e#  # *# *# h# i# g# h#  # m# o# n# t# h# l# y#  # c# h# a# r# a# g# e# s# *# *#  # w# h# e# n#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e#  # o# n# e# s#  # w# h# o#  # h# a# v# e#  # n# o# t#  # c# h# u# r# n# e# d#  # o# u# t# .

# In[None]

plt.figure(figsize = [15, 8])
ten_dist = sns.kdeplot(df['TotalCharges'][df["Churn"] == 0], color = bluish, shade = True)
ten_dist = sns.kdeplot(df['TotalCharges'][df["Churn"] == 1], color = orangish, shade= True)
ten_dist.legend(['Not Churn', 'Churn'])
ten_dist.set_xlabel('Total charges')
ten_dist.set_ylabel('Frequency')
plt.title('Distribution of total charges for churn and not churn customers');

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d#  # o# u# t#  # i# s#  # h# i# g# h#  # b# e# t# w# e# e# n#  # 0#  # t# o#  # a# p# p# r# o# x# .#  # 1# 0# 0# 0# .

# In[None]

plt.figure(figsize = [10,6])
sns.countplot(data = df, x = 'Contract', hue = 'Churn')
plt.legend(['Not Churn', 'Churn'])
plt.title('Contracts against churn and not churn customers', fontsize = 14);

# 
# W# e#  # l# e# a# r# n#  # t# h# a# t#  # m# o# s# t#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d#  # o# u# t#  # w# e# r# e#  # p# a# r# t#  # o# f#  # t# h# e#  # m# o# n# t# h# -# t# o# -# m# o# n# t# h#  # c# o# n# t# r# a# c# t# .# 
# 
# W# e#  # a# l# s# o#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e#  # p# a# r# t# i# c# i# p# a# t# i# o# n#  # i# n#  # o# n# e#  # a# n# d#  # t# w# o#  # y# e# a# r#  # c# o# n# t# r# a# c# t#  # i# s#  # v# e# r# y#  # l# e# s# s#  # f# o# r#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d#  # o# u# t#  # w# h# e# r# e# a# s#  # t# h# e#  # p# a# r# t# i# c# i# p# a# t# i# o# n#  # i# s#  # s# i# g# n# i# f# i# c# a# n# t#  # f# o# r#  # t# h# o# s# e#  # w# h# o#  # h# a# v# e#  # n# o# t# .

# In[None]

plt.figure(figsize = [10,6])
sns.countplot(data = df, x = 'InternetService', hue = 'Churn')
plt.legend(['Not Churn', 'Churn'])
plt.title('Internet service against churn and not churn customers', fontsize = 14);

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # o# p# t# e# d#  # f# o# r#  # F# i# b# e# r#  # o# p# t# i# c#  # w# e# r# e#  # l# i# k# e# l# y#  # t# o#  # c# h# u# r# n#  # o# u# t# .# 
# 
# W# e#  # a# l# s# o#  # s# e# e#  # t# h# a# t#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # o# p# t# e# d#  # f# o# r#  # D# S# L#  # w# e# r# e#  # l# e# s# s#  # l# i# k# e# l# y#  # t# o#  # c# h# u# r# n#  # o# u# t# .

# ## ## ##  # D# a# t# a#  # P# r# e# -# p# r# o# c# e# s# s# i# n# g

# C# o# n# v# e# r# t# i# n# g#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # t# o#  # i# n# d# i# c# a# t# o# r#  # v# a# r# i# a# b# l# e# s# .

# In[None]

df = pd.get_dummies(data = df)
df.head()

# L# e# t# '# s#  # b# u# i# l# d#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # t# o#  # a# n# a# l# y# s# e#  # t# h# e#  # r# e# l# a# t# i# o# n# .

# In[None]

corr = df.corr()
fig = plt.figure(figsize = (8, 8))
ax = fig.add_subplot(111)
p = ax.matshow(corr, vmin = -1, vmax = 1)
fig.colorbar(p)
ticks = np.arange(0, 27, 1) 
ax.set_xticks(ticks)
ax.set_yticks(ticks)
ax.set_xticklabels(df.columns.to_list(), rotation = 90)
ax.set_yticklabels(df.columns.to_list());

# In[None]

df.corr()['Churn'].sort_values()

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # C# o# n# t# r# a# c# t# _# M# o# n# t# h# -# t# o# -# m# o# n# t# h# ,#  # I# n# t# e# r# n# e# t# S# e# r# v# i# c# e# _# F# i# b# e# r#  # o# p# t# i# c# ,#  # P# a# y# m# e# n# t# M# e# t# h# o# d# _# E# l# e# c# t# r# o# n# i# c#  # c# h# e# c# k#  # a# r# e#  # h# i# g# h# l# y#  # p# o# s# i# t# i# v# e# l# y#  # c# o# r# r# e# l# a# t# e# d#  # a# n# d#  # T# e# n# u# r# e# ,#  # C# o# n# t# r# a# c# t# _# T# w# o#  # y# e# a# r#  # a# r# e#  # n# e# g# a# t# i# v# e# l# y#  # h# i# g# h# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # C# h# u# r# n# .

# In[None]

df.describe()

# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # o# u# r#  # f# e# a# u# t# r# e# s#  # a# r# e#  # o# n#  # d# i# f# f# e# r# e# n# t#  # s# c# a# l# e# s#  # a# n# d#  # t# h# i# s#  # c# a# n#  # s# l# o# w#  # t# h# e#  # p# r# o# c# e# s# s#  # o# f#  # c# o# n# v# e# r# g# e# n# c# e#  # o# f#  # o# u# r#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# .#  # 
# 
# T# o#  # f# i# x#  # t# h# i# s#  # l# e# t# '# s#  # n# o# r# m# a# l# i# z# e#  # o# u# r#  # d# a# t# a# s# e# t# .

# ## ## ## ##  # M# e# a# n#  # n# o# r# m# a# l# i# z# a# t# i# o# n

# In[None]

X = df.drop(["Churn"], axis = 1)
X = (X - np.mean(X, axis = 0)) / np.std(X, axis = 0)
X.describe()

# In[None]

y = df['Churn'].values

# ## ## ## ##  # S# p# l# i# t# t# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # s# e# t

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5476391.npy", { "accuracy_score": score })

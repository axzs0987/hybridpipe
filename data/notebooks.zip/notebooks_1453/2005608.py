import pandas as pd
# ##  # T# a# b# l# e#  # o# f#  # C# o# n# t# e# n# t# s# 
# 
# *#  # [# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# ]# (# ## e# x# p# l# o# r# a# t# o# r# y# )# :# 
#  #  #  #  # -#  # [# D# a# t# a#  # C# l# e# a# n# s# i# n# g#  # a# n# d#  # I# n# i# t# i# a# l#  # A# n# a# l# y# s# i# s# ]# (# ## c# l# e# a# s# i# n# g# )# 
#  #  #  #  # 
# *#  # [# P# r# e# d# i# c# t# i# o# n# ]# (# ## p# r# e# d# i# c# t# i# o# n# )# 
#  #  #  #  # -#  # [# F# e# a# t# u# r# e#  # I# m# p# o# r# t# a# n# c# e# ]# (# ## p# r# e# d# i# c# t# i# o# n# )# 
#  #  #  #  # -#  # [# C# o# r# r# e# l# a# t# i# o# n#  # M# a# t# r# i# x# ]# (# ## p# r# e# d# i# c# t# i# o# n# )# 
#  #  #  #  # -#  # [# M# o# d# e# l#  # c# h# o# o# s# i# n# g# ]# (# ## p# r# e# d# i# c# t# i# o# n# )# 
#  #  #  #  # -#  # [# D# e# v# O# P# S# ]# (# ## p# r# e# d# i# c# t# i# o# n# )# 
#  #  #  #  # 
# *#  # C# o# n# c# l# u# s# i# o# n

# <# a#  # n# a# m# e# =# "# e# x# p# l# o# r# a# t# o# r# y# "# ># <# /# a# >#  # 
# ##  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# <# a#  # n# a# m# e# =# "# c# l# e# a# s# i# n# g# "# ># <# /# a# ># 
# ## ##  # D# a# t# a#  # C# l# e# a# n# s# i# n# g#  # a# n# d#  # I# n# i# t# i# a# l#  # A# n# a# l# y# s# i# s

# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Suppress warnings 
import warnings
warnings.filterwarnings('ignore')
warnings.simplefilter(action='ignore', category=FutureWarning)

plt.style.use('ggplot')
sns.set_style()

# In[None]

data = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv', sep=',')

# In[None]

data.head()

# W# e#  # l# o# o# k#  # f# o# r#  # f# i# r# s# t#  # i# n# f# o# r# m# a# t# i# o# n# s#  # a# b# o# u# t#  # o# u# r#  # d# a# t# a# ,#  # t# h# e#  # s# i# z# e#  # o# f#  # o# u# r#  # d# a# t# a# s# e# t# ,#  # f# e# a# t# u# r# e# s# ,#  # a# n# d#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # d# i# f# f# e# r# e# n# t# s#  # l# a# b# e# l# s#  # i# n#  # e# a# c# h#  # f# e# a# t# u# r# e# .

# In[None]

print('Rows     :', data.shape[0])
print('Columns  :', data.shape[1])
print('\nFeatures :', data.columns.tolist())
print('\nUnique values :\n', data.nunique())

# F# i# r# s# t#  # w# e# '# r# e#  # l# o# o# k# i# n# g#  # f# o# r#  # p# o# s# s# i# b# l# e#  # i# s# s# u# e# s#  # w# h# e# n#  # w# e#  # l# o# a# d#  # t# h# e#  # d# a# t# a#  # s# e# t#  # a# s#  # t# y# p# e#  # c# o# n# v# e# r# t# i# o# n#  # a# n# d#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .#  # O# u# r#  # f# i# r# s# t#  # t# a# s# k#  # h# e# r# e#  # i# s#  # m# o# t# i# v# a# t# e# d#  # b# y#  # d# a# t# a#  # c# l# e# a# n# s# i# n# g#  # a# n# d#  # t# y# p# e#  # c# o# n# v# e# r# t# i# o# n# s#  # t# o#  # b# e#  # u# s# e# d#  # i# n#  # f# u# t# u# r# e#  # t# r# a# i# n# n# i# g#  # s# e# t# .

# In[None]

# Function to calculate missing values by column# Funct 
def missing_values_table(df):
        # Total missing values
        mis_val = df.isnull().sum()
        
        # Percentage of missing values
        mis_val_percent = 100 * df.isnull().sum() / len(df)
        
        # Make a table with the results
        mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)
        
        # Rename the columns
        mis_val_table_ren_columns = mis_val_table.rename(
        columns = {0 : 'Valores em falta', 1 : '% of Total Values'})
        
        # Sort the table by percentage of missing descending
        mis_val_table_ren_columns = mis_val_table_ren_columns[
            mis_val_table_ren_columns.iloc[:,1] != 0].sort_values(
        '% of Total Values', ascending=False).round(1)
        
        # Print some summary information
        print ("Your selected dataframe has " + str(df.shape[1]) + " columns.\n"      
            "There are " + str(mis_val_table_ren_columns.shape[0]) +
              " columns that have missing values.")
        
        # Return the dataframe with missing information
        return mis_val_table_ren_columns
    
# Valores que estão faltando nos dados
missing_values = missing_values_table(data)

# I# n#  # c# e# l# l#  # a# b# o# v# e#  # w# e#  # l# o# o# k# i# n# g#  # f# o# r#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # o# r#  # n# u# n# -# n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s# ,#  # N# a# N# .#  # W# e#  # c# a# n# '# t#  # i# n# d# e# n# t# i# f# y#  # n# o# n# e#  # u# n# t# i# l#  # w# e#  # l# o# o# k#  # c# a# r# e# f# u# l# l# y

# In[None]

data.info()

# T# h# e# r# e#  # a# r# e#  # s# o# m# e#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # c# o# n# t# a# i# n# s#  # `# P# y# t# h# o# n#  # o# b# j# e# c# t# `# ,#  # a# n# d#  # w# e#  # h# a# v# e#  # t# o#  # c# o# n# v# e# r# t#  # t# h# i# s#  # c# o# l# u# m# n# s#  # t# o#  # a#  # v# a# l# i# d#  # t# y# p# e#  # f# o# r# m# a# t# .#  # O# n# e#  # f# e# a# t# u# r# e#  # t# h# a# t#  # c# o# n# t# a# i# n# s#  # a# n#  # i# m# p# o# r# t# a# n# t#  # i# n# f# o# r# m# a# t# i# o# n#  # i# s#  # `# T# o# t# a# l# C# h# a# r# g# e# s# `#  # w# h# i# c# h#  # c# o# n# t# a# i# n# s#  # c# h# a# r# g# e# s#  # v# a# l# u# e# s#  # a# n# d#  # w# e#  # n# e# e# d#  # t# o#  # c# o# n# v# e# r# t#  # t# o#  # n# u# m# e# r# i# c#  # t# y# p# e# .#  

# In[None]

#Data Manipulation

#Replacing spaces with null values in total charges column
data['TotalCharges'] = data["TotalCharges"].replace(" ", np.nan)

#Dropping null values from total charges column which contain .15% missing data 
data = data[data["TotalCharges"].notnull()]
data = data.reset_index()[data.columns]

#convert to float type
data["TotalCharges"] = data["TotalCharges"].astype(float)

# W# i# t# h#  # a#  # l# i# t# t# l# e#  # c# l# e# a# n# i# s# i# n# g#  # w# e#  # d# r# o# p# p# e# d#  # s# o# m# e#  # v# a# l# u# e# s#  # f# r# o# m#  # d# a# t# a# s# e# t# .#  # T# h# e# s# e#  # d# r# o# p# p# e# d#  # d# a# t# a#  # c# o# n# t# a# i# n# s#  # `# w# h# i# t# e#  # s# p# a# c# e# s# `#  # a# n# d#  # w# e#  # h# a# v# e#  # t# o#  # c# h# a# n# g# e#  # t# o#  # N# a# N#  # v# a# l# u# e# s# .#  # A# f# t# e# r#  # w# e#  # d# r# o# p# p# e# d#  # t# h# i# s#  # c# u# s# t# o# m# e# r# s#  # f# r# o# m#  # o# u# r#  # d# a# t# a# s# e# t# .

# In[None]

data.info()

# A# g# a# i# n# ,#  # t# h# e# r# e#  # a# r# e#  # s# o# m# e#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # c# o# n# t# a# i# n# s#  # a# m# b# i# g# u# o# u# s#  # i# n# f# o# r# m# a# t# i# o# n# s# ,#  # f# o# r#  # e# x# a# m# p# l# e# ,#  # `# O# n# l# i# n# e# S# e# c# u# r# i# t# y# `#  # c# o# n# t# a# i# n# s#  # 3#  # d# i# f# f# e# r# e# n# t# s#  # l# a# b# e# l# s# ,#  # b# u# t#  # t# h# e#  # c# o# r# r# e# c# t#  # l# a# b# e# l# s#  # a# r# e#  # *# Y# E# S# *#  # o# r#  # *# N# O# *# .

# In[None]

f, axes = plt.subplots(2, 3, sharey=False, sharex=False, figsize=(10,4))

data['OnlineSecurity'].value_counts(ascending=True).plot.barh(title='OnlineSecurity', ax=axes[0,0])
data['OnlineBackup'].value_counts(ascending=True).plot.barh(title='OnlineBackup', ax=axes[0,1])
data['DeviceProtection'].value_counts(ascending=True).plot.barh(title='DeviceProtection', ax=axes[0,2])
data['TechSupport'].value_counts(ascending=True).plot.barh(title='TechSupport', ax=axes[1,0])
data['StreamingTV'].value_counts(ascending=True).plot.barh(title='StreamingTV', ax=axes[1,1])
data['StreamingMovies'].value_counts(ascending=True).plot.barh(title='StreamingMovies', ax=axes[1,2])
plt.tight_layout()

# W# e#  # h# a# v# e#  # t# o#  # r# e# p# l# a# c# e#  # *# *# N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# *# *#  # t# o#  # *# *# N# o# *# *#  # a# n# d#  # t# h# e#  # a# b# o# v# e#  # f# e# a# t# u# r# e# s#  # `# O# n# l# i# n# e# S# e# c# u# r# i# t# y# `# ,#  # `# O# n# l# i# n# e# B# a# c# k# u# p# `# ,#  # `# D# e# v# i# c# e# P# r# o# t# e# c# t# i# o# n# `# ,#  # `# T# e# c# h# S# u# p# p# o# r# t# `# ,#  # `# S# t# r# e# a# m# i# n# g# T# V# `# ,#  # `# S# t# r# e# a# m# i# n# g# M# o# v# i# e# s# `# .

# In[None]

replace_cols = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport','StreamingTV', 'StreamingMovies', 'MultipleLines']

for i in replace_cols :
    data[i]  = data[i].replace({'No internet service' : 'No'})
    data[i]  = data[i].replace({'No phone service' : 'No'})

# In[None]

f, axes = plt.subplots(2, 3, sharey=False, sharex=False, figsize=(10,4))

data['OnlineSecurity'].value_counts(ascending=True).plot.barh(title='OnlineSecurity', ax=axes[0,0])
data['OnlineBackup'].value_counts(ascending=True).plot.barh(title='OnlineBackup', ax=axes[0,1])
data['DeviceProtection'].value_counts(ascending=True).plot.barh(title='DeviceProtection', ax=axes[0,2])
data['TechSupport'].value_counts(ascending=True).plot.barh(title='TechSupport', ax=axes[1,0])
data['StreamingTV'].value_counts(ascending=True).plot.barh(title='StreamingTV', ax=axes[1,1])
data['StreamingMovies'].value_counts(ascending=True).plot.barh(title='StreamingMovies', ax=axes[1,2])
plt.tight_layout()

# T# h# e#  # m# o# s# t#  # o# f#  # c# u# s# t# o# m# e# r# s#  # d# o# e# s# n# '# t#  # h# a# v# e#  # a# d# d# i# t# i# o# n# a# l#  # p# r# o# d# u# c# t# s# ,#  # c# h# o# o# s# i# n# g#  # s# i# m# p# l# e#  # p# l# a# n# s#  # t# h# a# t#  # d# o# e# s# n# '# t#  # c# o# n# t# a# i# n# s#  # s# p# e# c# i# a# l#  # p# r# o# d# u# c# t# s# .

# W# e#  # w# i# l# l#  # r# e# p# l# a# c# e#  # t# h# e#  # l# a# b# e# l# s#  # i# n#  # `# S# e# n# i# o# r# C# i# t# i# z# e# n# `#  # c# h# a# n# g# i# n# g#  # *# *# 1#  # t# o#  # Y# e# s# *# *#  # a# n# d#  # *# *# 0#  # t# o#  # N# o# *# *# .#  # T# h# i# s#  # g# i# v# e# s#  # u# s#  # a#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d#  # a# b# o# u# t#  # n# e# x# t#  # d# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s# .

# In[None]

#replace values
data["SeniorCitizen"] = data["SeniorCitizen"].replace({1:"Yes",0:"No"})

# W# e#  # c# a# n#  # l# o# o# k#  # f# o# r#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # c# o# n# t# r# a# c# t# s#  # t# h# a# t#  # a# r# e#  # d# i# s# t# r# i# b# u# t# e# d#  # b# y#  # c# u# s# t# o# m# e# r# s# ,#  # t# r# y# i# n# g#  # t# o#  # s# u# m# m# a# r# i# z# e#  # h# o# w#  # t# h# e# m#  # c# h# o# s# e#  # t# h# e#  # s# e# r# v# i# c# e# s# :

# In[None]

f, axes = plt.subplots(3, 2, sharey=False, sharex=False, figsize=(12,12))

data['Contract'].value_counts(ascending=True, normalize=True).plot.barh(title='Contracts', ax=axes[0,0])
data['SeniorCitizen'].value_counts(ascending=True, normalize=True).plot.barh(title='SeniorCitizen', ax=axes[0,1])
sns.countplot(x='gender', hue='Contract', data=data, orient='v', ax=axes[1,0])
sns.countplot(x='Contract', hue='SeniorCitizen', data=data, orient='v', ax=axes[1,1])

data.groupby('gender')['SeniorCitizen'].value_counts(ascending=True, normalize=True).plot.barh(title='SeniorCitizen by gender', ax=axes[2,0])
data.groupby('Contract')['gender'].value_counts(ascending=True, normalize=False).unstack().plot.bar(title='Contracts by gender', ax=axes[2,1])
plt.tight_layout()

# In[None]

data['Contract'].value_counts(ascending=True, normalize=True)

# I# n#  # t# h# e#  # c# h# a# r# t#  # a# b# o# v# e#  # w# e#  # w# e# r# e#  # l# o# o# k# i# n# g#  # f# o# r#  # h# o# w#  # d# i# s# t# r# i# b# u# t# e# d#  # o# u# r#  # c# o# n# t# r# a# c# t# s#  # a# r# e#  # d# i# v# i# d# e# d#  # b# y#  # g# e# n# d# e# r# ,#  # b# y#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# ,#  # a# n# d#  # b# y#  # k# i# n# d#  # o# f#  # c# o# n# t# r# a# c# t# s# .#  # T# h# e#  # m# o# s# t#  # o# f#  # c# o# n# t# r# a# c# t# s#  # a# r# e#  # s# p# e# c# i# f# i# e# d#  # a# s#  # *# *# M# o# n# t# h# -# t# o# -# m# o# n# t# h# *# *#  # a# b# o# u# t#  # 5# 5# %#  # o# f#  # c# o# n# t# r# a# c# t# s# .#  # A# b# o# u# t#  # t# h# e#  # `# S# e# n# i# o# r# C# i# t# i# z# e# n# `#  # w# e#  # h# a# v# e#  # j# u# s# t#  # 1# 5# %#  # o# f#  # s# e# n# i# o# r# s#  # c# i# t# i# z# e# n# .#  # W# h# e# n#  # w# e#  # l# o# o# k#  # f# o# r#  # S# e# n# i# o# r# C# i# t# i# z# e# n#  # b# y#  # g# e# n# d# e# r#  # w# e#  # h# a# v# e#  # a# b# o# u# t#  # t# h# e#  # s# a# m# e#  # p# e# r# c# e# n# t# a# g# e#  # o# f#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # w# h# o#  # c# o# n# t# r# a# c# t# s#  # s# e# r# v# i# c# e# s# .# 
# 
# N# o# w#  # w# e#  # h# a# v# e#  # t# o#  # l# o# o# k#  # a# b# o# u# t#  # h# o# w#  # t# h# e#  # `# t# e# n# u# r# e# `#  # f# e# a# t# u# r# e#  # a# r# e#  # c# a# t# e# g# o# r# i# z# e# d# .#  # I# f#  # w# e#  # h# a# v# e#  # t# h# e#  # e# n# t# i# r# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # h# o# w#  # c# u# s# t# o# m# e# r# s#  # b# u# y#  # p# r# o# d# u# c# t# s#  # w# e#  # c# a# n#  # a# n# a# l# y# s# e#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # t# o#  # c# a# l# c# u# l# a# t# e#  # c# h# u# r# n# .# 
# 
# T# h# e#  # f# e# a# t# u# r# e#  # `# t# e# n# u# r# e# `#  # s# p# e# c# i# f# i# e# s#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # m# o# n# t# h# s#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# t# a# y# e# d#  # w# i# t# h#  # t# h# e#  # c# o# m# p# a# n# y# ,#  # w# e#  # c# a# n#  # c# a# t# e# g# o# r# i# z# e#  # t# h# i# s#  # i# n#  # y# e# a# r# s# .

# In[None]

#Tenure to categorical column
def tenure_lab(data):    
    if data['tenure'] <= 12 :
        return "Tenure_0-12"
    elif (data['tenure'] > 12) & (data['tenure'] <= 24 ):
        return "Tenure_12-24"
    elif (data['tenure'] > 24) & (data['tenure'] <= 48) :
        return "Tenure_24-48"
    elif (data['tenure'] > 48) & (data['tenure'] <= 60) :
        return "Tenure_48-60"
    elif data['tenure'] > 60 :
        return "Tenure_60-gt"
data["tenure_group"] = data.apply(lambda data:tenure_lab(data), axis = 1)

# W# e#  # h# a# v# e#  # t# o#  # p# l# o# t#  # a# n#  # h# i# s# t# o# g# r# a# m#  # f# o# r#  # t# h# e#  # `# t# e# n# u# r# e# `#  # v# a# r# i# a# b# l# e# ,#  # w# h# i# c# h#  # r# e# p# r# e# s# e# n# t#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # m# o# n# t# h# s#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# t# a# y# e# d#  # w# i# t# h#  # t# h# e#  # c# o# m# p# a# n# y# .#  # B# e# s# i# d# e# ,#  # w# e#  # l# o# o# k#  # f# o# r#  # t# h# e#  # s# a# m# e#  # b# e# h# a# v# i# o# u# r#  # b# u# t#  # n# o# w#  # l# o# o# k# i# n# g#  # f# o# r#  # y# e# a# r# s# .

# In[None]

f, (ax1, ax2) = plt.subplots(1, 2, sharey=False, sharex=False, figsize=(10,4))

data['tenure'].hist(density=False, ax=ax1)
data['tenure_group'].value_counts(ascending=False, sort=True, normalize=True).sort_index().plot.bar(ax=ax2)

ax1.set_xlabel(r'Tenure')
ax1.set_ylabel(r'# months with the company')
plt.tight_layout()

# In[None]

order_tenure = list(data['tenure_group'].value_counts(ascending=False, sort=True, normalize=True).sort_index().index)

# A# b# o# u# t#  # 3# 1# %#  # o# f#  # c# u# s# t# o# m# e# r# s#  # s# t# a# y#  # w# i# t# h#  # t# h# e#  # c# o# m# p# a# n# y#  # a# b# o# u# t#  # o# n# e#  # y# e# a# r# ,#  # t# h# i# s#  # p# e# r# i# o# d#  # i# s#  # t# h# e#  # m# o# s# t#  # c# o# m# m# o# n# .#  # O# n# l# y#  # 2# 0# %#  # a# r# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # o# r#  # e# q# u# a# l#  # t# o#  # f# o# u# r#  # y# e# a# r# s# ,#  # i# n#  # o# t# h# e# r#  # w# o# r# d# s# ,#  # o# n# l# y#  # 2# 0# %#  # c# o# n# t# i# n# u# e# s#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # b# e# f# o# r# e#  # f# o# u# r#  # y# e# a# r# s#  # o# f#  # c# o# n# t# r# a# c# t# .

# O# n# c# e#  # w# e#  # k# n# o# w#  # o# u# r#  # c# u# s# t# o# m# e# r# ,#  # w# e#  # h# a# v# e#  # t# o#  # i# d# e# n# t# i# f# y#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # a# r# e#  # c# h# u# r# n#  # o# r#  # n# o# n# -# c# h# u# r# n

# In[None]

data[data['Churn']=='Yes']['TotalCharges'].hist();
data[data['Churn']=='No']['TotalCharges'].hist();

# In[None]

f, axes = plt.subplots(3, 2, sharey=False, sharex=False, figsize=(16,16))

sns.countplot(x='tenure_group', hue='Churn', data=data, order=order_tenure, orient='v', ax=axes[0,0])
sns.countplot(x='Churn', hue='gender', data=data, orient='v', ax=axes[0,1])
sns.countplot(x='Churn', hue='SeniorCitizen', data=data, orient='v', ax=axes[1,0])
sns.distplot(data[data['Churn']=='Yes']['MonthlyCharges'], kde=False, hist=True, norm_hist=False, ax=axes[1,1], label='Churn')
sns.distplot(data[data['Churn']=='No']['MonthlyCharges'], kde=False, hist=True, norm_hist=False, ax=axes[1,1], label='Non-Churn')

sns.distplot(data[data['Churn']=='Yes']['TotalCharges'], kde=False, hist=True, norm_hist=False, ax=axes[2,0], label='Churn')
sns.distplot(data[data['Churn']=='No']['TotalCharges'], kde=False, hist=True, norm_hist=False, ax=axes[2,0], label='Non-Churn')

pivot = pd.pivot_table(data, values=['MonthlyCharges', 'TotalCharges'], index=['tenure_group', 'Churn'])

pivot.unstack()['TotalCharges'].plot.bar(ax=axes[2,1], title='Average Total Charges by Tenure groups')


axes[0,0].set_title('Churn customers by Tenure groups')
axes[0,1].set_title('Churn customers by gender')
axes[1,0].set_title('Churn customers by SeniorCitizen')
axes[1,1].set_title('Distribution of MonthlyCharges by Churn')
axes[2,0].set_title('Distribution of TotalCharges by Churn')

axes[1,1].legend()
axes[2,0].legend()
axes[2,1].legend()
plt.tight_layout()

# W# h# e# n#  # w# e#  # p# l# o# t# t# e# d#  # `# c# h# u# r# n# `#  # v# a# r# i# a# b# l# e#  # w# i# t# h#  # t# h# e#  # f# e# a# t# u# r# e# s#  # w# e#  # c# h# o# s# e# ,#  # w# e#  # o# b# s# e# r# v# e# d#  # h# o# w#  # c# u# s# t# o# m# e# r# s#  # a# r# e#  # c# a# t# e# g# o# r# i# z# e# d# ,#  # f# o# r#  # e# x# a# m# p# l# e# ,#  # t# h# e# r# e#  # a# r# e# n# '# t#  # d# i# f# e# r# e# n# c# e# s#  # b# e# t# w# e# e# n#  # g# e# n# d# e# r# .#  # O# t# h# e# r#  # c# o# n# c# l# u# s# i# o# n#  # i# s#  # h# o# w#  # m# u# c# h#  # o# l# d# e# r#  # a#  # c# u# s# t# o# m# e# r#  # i# s#  # l# e# s# s#  # c# h# u# r# n#  # t# h# e# y#  # a# r# e# .# 
# 
# T# o#  # f# i# n# i# s# h# ,#  # w# e#  # c# a# n#  # v# i# s# u# a# l# i# z# e#  # h# o# w#  # o# u# r# s#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # c# o# r# r# e# l# a# t# e# d# .#  # T# o#  # d# o#  # t# h# a# t#  # w# e#  # c# a# n#  # c# a# l# c# u# l# a# t# e#  # t# h# e#  # *# *# *# P# e# a# r# s# o# n#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t# *# *# *# .

# *# *# *# P# e# a# r# s# o# n#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t# *# *# *# 
# 
# I# n#  # s# t# a# t# i# s# t# i# c# s# ,#  # t# h# e#  # P# e# a# r# s# o# n#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t#  # i# s#  # a#  # m# e# a# s# u# r# e#  # o# f#  # t# h# e#  # l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# w# o#  # v# a# r# i# a# b# l# e# s#  # X#  # a# n# d#  # Y# .#  # O# w# i# n# g#  # t# o#  # t# h# e#  # C# a# u# c# h# y# –# S# c# h# w# a# r# z#  # i# n# e# q# u# a# l# i# t# y#  # i# t#  # h# a# s#  # a#  # v# a# l# u# e#  # b# e# t# w# e# e# n#  # +# 1#  # a# n# d#  # −# 1# ,#  # w# h# e# r# e#  # 1#  # i# s#  # t# o# t# a# l#  # p# o# s# i# t# i# v# e#  # l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n# ,#  # 0#  # i# s#  # n# o#  # l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n# ,#  # a# n# d#  # −# 1#  # i# s#  # t# o# t# a# l#  # n# e# g# a# t# i# v# e#  # l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n# .#  # P# e# a# r# s# o# n# '# s#  # c# o# e# f# f# i# c# i# e# n# t#  # i# s#  # t# h# e#  # c# o# v# a# r# i# a# n# c# e#  # o# f#  # t# h# e#  # t# w# o#  # v# a# r# i# a# b# l# e# s#  # d# i# v# i# d# e# d#  # b# y#  # t# h# e#  # p# r# o# d# u# c# t#  # o# f#  # t# h# e# i# r#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n# s# .#  # 
# 
# P# e# a# r# s# o# n# '# s#  # c# o# e# f# f# i# c# i# e# n# t#  # w# h# e# n#  # a# p# p# l# i# e# d#  # t# o#  # a#  # s# a# m# p# l# e#  # i# s#  # c# o# m# m# o# n# l# y#  # r# e# p# r# e# s# e# n# t# e# d#  # b# y#  # t# h# e#  # l# e# t# t# e# r#  # $# r# $#  # a# n# d#  # c# a# n#  # a# s# s# u# m# e#  # v# a# l# u# e# s#  # b# e# t# w# e# e# n#  # -# 1#  # a# n# d#  # 1# .# 
# 
# *#  # $# {# \# d# i# s# p# l# a# y# s# t# y# l# e#  # r#  # =# 1# }# $#  # M# e# a# n# s#  # a#  # p# o# s# i# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# w# o#  # v# a# r# i# a# b# l# e# s# ,#  # i# n#  # o# t# h# e# r#  # w# o# r# d# s#  # i# f#  # o# n# e#  # v# a# r# y#  # t# h# e#  # s# e# c# o# n# d#  # o# n# e#  # v# a# r# i# e# s#  # t# o# o# .# 
# *#  # $# {# \# d# i# s# p# l# a# y# s# t# y# l# e#  # r#  # =# -# 1# }# $#  # M# e# a# n# s#  # a#  # n# e# g# a# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# w# o#  # v# a# r# i# a# b# l# e# s# ,#  # i# n#  # o# t# h# e# r#  # w# o# r# d# s#  # i# f#  # o# n# e#  # v# a# r# y#  # t# h# e#  # s# e# c# o# n# d#  # o# n# e#  # v# a# r# i# e# s#  # i# n#  # t# h# e#  # o# p# p# o# s# i# t# e#  # w# a# y# .# 
# *#  # $# {# \# d# i# s# p# l# a# y# s# t# y# l# e#  # r#  # =# 0# }# $#  # R# e# p# r# e# s# e# n# t# s#  # a#  # z# e# r# o#  # c# o# r# r# e# l# a# t# i# o# n# ,#  # o# n# e#  # v# a# r# i# a# b# l# e#  # d# o# e# s# n# '# t#  # d# e# p# e# n# d#  # o# f#  # s# e# c# o# n# d#  # o# n# e#  # l# i# n# e# a# r# l# y# .# 
# 
# $# $# r# _# {# X# Y# }#  # =#  # \# f# r# a# c# {# \# s# u# m# _# {# i# =# 1# }# ^# n# (# X# _# i#  # -#  # \# o# v# e# r# l# i# n# e# {# X# }# )# (# Y# _# i#  # -#  # \# o# v# e# r# l# i# n# e# {# Y# }# )# }# {# \# s# q# r# t# {# \# s# u# m# _# {# i# =# 1# }# ^# n# (# X# _# i#  # -#  # \# o# v# e# r# l# i# n# e# {# X# }# )# ^# 2# }# \# s# q# r# t# {# \# s# u# m# _# {# i# =# 1# }# ^# n# (# Y# _# i#  # -#  # \# o# v# e# r# l# i# n# e# {# Y# }# )# ^# 2# }# }# $# $

# *#  # N# e# x# t#  # w# e#  # w# i# l# l#  # d# o#  # e# n# c# o# d# i# n# g#  # w# i# t# h#  # i# n#  # o# u# r#  # v# a# r# i# a# b# l# e# s#  # t# o#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# l# u# e# s# ,#  # t# h# i# s#  # w# i# l# l#  # p# e# r# m# i# t# e#  # u# s#  # t# o#  # c# r# e# a# t# e#  # s# o# m# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # t# o#  # a# n# a# l# y# s# e#  # h# o# w#  # o# u# r# s#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # r# e# l# a# t# i# o# n# e# d# .

# In[None]

from sklearn.preprocessing import LabelEncoder

dataobject=data.select_dtypes(['object'])

def uni(columnname):
    print(columnname,"--" ,data[columnname].unique())

for i in range(1,len(dataobject.columns)):
    uni(dataobject.columns[i])
    
def labelencode(columnname):
    data[columnname] = LabelEncoder().fit_transform(data[columnname])
    
for i in range(1,len(dataobject.columns)):
    labelencode(dataobject.columns[i])
        
for i in range(1,len(dataobject.columns)):
     uni(dataobject.columns[i])

# In[None]

df = data.copy()
drop_list = ['customerID', 'gender', 'Dependents', 'PhoneService', 'DeviceProtection', 'TechSupport',
             'StreamingTV', 'StreamingMovies', 'PaperlessBilling', 'PaymentMethod']

df['Contract_0'] = ((df['Contract']==0).values).astype(int)
df['Contract_1'] = ((df['Contract']==1).values).astype(int)
df['Contract_2'] = ((df['Contract']==2).values).astype(int)

df['tenure_0'] = ((df['tenure_group']==0).values).astype(int)
df['tenure_1'] = ((df['tenure_group']==1).values).astype(int)
df['tenure_2'] = ((df['tenure_group']==2).values).astype(int)
df['tenure_3'] = ((df['tenure_group']==3).values).astype(int)
df['tenure_4'] = ((df['tenure_group']==4).values).astype(int)

df = df.drop(drop_list, axis=1)
df = df.drop(['Contract', 'tenure', 'tenure_group'], axis=1)

# In[None]

f, (ax1,ax2) = plt.subplots(1, 2, sharey=False, sharex=False, figsize=(16,6))

corr = df.corr(method='pearson')

sns.heatmap(data.corr(method='pearson'), cmap=plt.cm.inferno_r, ax=ax1)
sns.heatmap(corr, cmap=plt.cm.inferno_r, ax=ax2)
plt.tight_layout()

# A# b# o# v# e#  # w# e#  # p# l# o# t# t# e# d#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # w# i# t# h#  # o# u# r#  # f# e# a# t# u# r# e# s# ,#  # s# o# m# e#  # o# f#  # t# h# e# s# e#  # f# e# a# t# u# r# e# s#  # d# o# e# s# n# '# t#  # c# o# n# t# r# i# b# u# t# e#  # t# o#  # u# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # r# o# o# t# -# c# a# u# s# e#  # o# f#  # c# h# u# r# n# ,#  # s# o#  # w# e#  # d# r# o# p# p# e# d#  # s# o# m# e#  # a# n# d#  # k# e# e# p# e# d#  # t# h# e#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # w# e#  # t# h# i# n# k#  # i# t# '# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # u# s# .# 
# 
# T# o#  # e# x# e# m# p# l# i# f# y# ,#  # w# e#  # l# o# o# k#  # f# o# r#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t#  # b# e# t# w# e# e# n#  # `# t# e# n# u# r# e# `#  # a# n# d#  # `# T# o# t# a# l# C# h# a# r# g# e# s# `# ,#  # i# t#  # c# a# n#  # b# e#  # a#  # l# i# t# t# l# e#  # o# b# v# i# o# u# s#  # b# e# c# a# u# s# e#  # t# h# e#  # t# i# m# e#  # a#  # c# u# s# t# o# m# e# r#  # c# o# n# t# r# a# c# t# e# d#  # a#  # s# e# r# v# i# c# e#  # i# s#  # h# i# g# h# l# y#  # r# e# l# a# t# e# d#  # w# i# t# h#  # t# h# e#  # c# h# a# r# g# e# s#  # t# h# a# t#  # h# e#  # w# i# l# l#  # p# a# y# .#  # T# h# e#  # c# o# e# f# f# i# c# i# e# n# t#  # i# s#  # `# c# o# r# r# [# '# t# e# n# u# r# e# '# ]# [# '# T# o# t# a# l# C# h# a# r# g# e# s# '# ]# =#  # 0# .# 8# 3# `# ,#  # s# h# o# w# i# n# g#  # h# i# g# h#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# i# s#  # t# w# o#  # f# e# a# t# u# r# e# s# .

# <# a#  # n# a# m# e# =# "# p# r# e# d# i# c# t# i# o# n# "# ># <# /# a# ># 
# ##  # P# r# e# d# i# c# t# i# o# n

# *# *# 1# )# *# *#  # B# e# f# o# r# e#  # w# e#  # t# r# a# i# n#  # o# u# r#  # m# o# d# e# l# ,#  # w# e#  # p# r# e# -# p# r# o# c# e# s# s# e# d#  # o# u# r#  # d# a# t# a# .#  # W# e#  # d# o# n# e#  # s# o# m# e#  # c# l# e# a# s# i# n# g# ,#  # s# o# m# e#  # l# a# b# e# l# s#  # c# o# r# r# e# c# t# i# o# n# s# ,#  # a# n# d#  # a# f# t# e# r#  # a# l# l#  # t# h# a# t# ,#  # w# e#  # c# a# t# e# g# o# r# i# z# e# d#  # n# u# m# e# r# i# c# a# l# l# y#  # o# u# r#  # d# a# t# a# .#  # I# n#  # s# o# m# e#  # f# e# a# t# u# r# e# s#  # w# e#  # h# a# d#  # a# m# b# i# g# u# o# u# s#  # i# n# f# o# r# m# a# t# i# o# n# s# ,#  # f# o# r#  # e# x# a# m# p# l# e# ,#  # i# n#  # `# O# n# l# i# n# e# S# e# c# u# r# i# t# y# `#  #  # w# e#  # h# a# d#  # t# h# r# e# e#  # d# i# f# f# e# r# e# n# t# s#  # l# a# b# e# l# s# ,#  # *# *# *# Y# E# S# ,#  # N# O#  # a# n# d#  # N# O# _# I# N# T# E# R# N# E# T# _# S# E# R# V# I# C# E# ,# *# *# *#  # b# u# t#  # t# h# e#  # c# o# r# r# e# c# t#  # l# a# b# e# l# s#  # a# r# e#  # *# *# Y# E# S#  # o# r#  # N# O# *# *# .#  # S# o# ,#  # w# e#  # c# o# r# r# e# c# t#  # t# h# e# s# e#  # k# i# n# d#  # o# f#  # i# n# f# o# r# m# a# t# i# o# n# s#  # i# n#  # o# t# h# e# r#  # f# e# a# t# u# r# e# s# .#  # A# f# t# e# r#  # t# h# a# t#  # w# e#  # c# a# t# e# g# o# r# i# z# e# d#  # t# h# e#  # l# a# b# e# l# s#  # *# *# N# O#  # o# r#  # Y# E# S# *# *#  # t# o#  # *# *# 0#  # o# r#  # 1# *# *# .#  # W# e#  # d# o# n# e#  # t# h# i# s#  # k# i# n# d#  # o# f#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # a# l# l#  # o# v# e# r#  # t# h# e#  # d# a# t# a# s# e# t# .

# *# *# 2# )# *# *#  # O# n# e#  # o# f#  # t# h# e#  # m# e# t# h# o# d# s#  # t# o#  # i# d# e# n# t# i# f# y#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t# s#  # f# e# a# t# u# r# e# s#  # i# s#  # t# r# y#  # t# o#  # f# i# t#  # o# u# r#  # d# a# t# a#  # i# n#  # a#  # L# i# n# e# a# r#  # R# e# g# r# e# s# s# i# o# n# .#  # I# n#  # t# h# i# s#  # c# a# s# e#  # I# '# l# l#  # u# s# e#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # p# e# n# a# l# t# i# e# s#  # t# o#  # f# i# n# d#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # t# h# a# t#  # a# r# e#  # m# o# r# e#  # i# m# p# o# r# t# a# n# t#  # t# o#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .#  # B# e# s# i# d# e# s#  # t# h# a# t# ,#  # I# '# l# l#  # t# r# y#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # A# l# g# o# r# i# t# h# m# ,#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # a# n# d#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # t# o#  # d# o#  # t# h# e#  # s# a# m# e#  # t# h# i# n# g# ,#  # b# u# t#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t# s#  # a# p# p# r# o# a# c# h# s# .

# In[None]

from sklearn.model_selection import train_test_split
data_to_train = data.drop(['customerID'], axis=1).copy()

y_varible = data_to_train.copy()["Churn"]
x_varible = data_to_train.copy().drop(["Churn"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/2005608.npy", { "accuracy_score": score })

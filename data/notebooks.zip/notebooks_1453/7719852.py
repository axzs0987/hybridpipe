import pandas as pd
# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # a#  # t# y# p# e#  # o# f#  # S# u# p# p# o# r# t#  # v# e# c# t# o# r#  # m# a# c# h# i# n# e#  # t# h# a# t#  # s# u# p# p# o# r# t# s#  # l# i# n# e# a# r#  # a# n# d#  # n# o# n# -# l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .# 
# 
# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # c# a# n#  # a# l# s# o#  # b# e#  # u# s# e# d#  # a# s#  # a#  # r# e# g# r# e# s# s# i# o# n#  # m# e# t# h# o# d# ,#  # m# a# i# n# t# a# i# n# i# n# g#  # a# l# l#  # t# h# e#  # m# a# i# n#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # c# h# a# r# a# c# t# e# r# i# z# e#  # t# h# e#  # a# l# g# o# r# i# t# h# m#  # (# m# a# x# i# m# a# l#  # m# a# r# g# i# n# )# .#  # T# h# e#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # R# e# g# r# e# s# s# i# o# n#  # (# S# V# R# )#  # u# s# e# s#  # t# h# e#  # s# a# m# e#  # p# r# i# n# c# i# p# l# e# s#  # a# s#  # t# h# e#  # S# V# M#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ,#  # w# i# t# h#  # o# n# l# y#  # a#  # f# e# w#  # m# i# n# o# r#  # d# i# f# f# e# r# e# n# c# e# s# .#  # F# i# r# s# t#  # o# f#  # a# l# l# ,#  # b# e# c# a# u# s# e#  # o# u# t# p# u# t#  # i# s#  # a#  # r# e# a# l#  # n# u# m# b# e# r#  # i# t#  # b# e# c# o# m# e# s#  # v# e# r# y#  # d# i# f# f# i# c# u# l# t#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# t#  # h# a# n# d# ,#  # w# h# i# c# h#  # h# a# s#  # i# n# f# i# n# i# t# e#  # p# o# s# s# i# b# i# l# i# t# i# e# s# .#  # I# n#  # t# h# e#  # c# a# s# e#  # o# f#  # r# e# g# r# e# s# s# i# o# n# ,#  # a#  # m# a# r# g# i# n#  # o# f#  # t# o# l# e# r# a# n# c# e#  # (# e# p# s# i# l# o# n# )#  # i# s#  # s# e# t#  # i# n#  # a# p# p# r# o# x# i# m# a# t# i# o# n#  # t# o#  # t# h# e#  # S# V# M#  # w# h# i# c# h#  # w# o# u# l# d#  # h# a# v# e#  # a# l# r# e# a# d# y#  # r# e# q# u# e# s# t# e# d#  # f# r# o# m#  # t# h# e#  # p# r# o# b# l# e# m# .#  # B# u# t#  # b# e# s# i# d# e# s#  # t# h# i# s#  # f# a# c# t# ,#  # t# h# e# r# e#  # i# s#  # a# l# s# o#  # a#  # m# o# r# e#  # c# o# m# p# l# i# c# a# t# e# d#  # r# e# a# s# o# n# ,#  # t# h# e#  # a# l# g# o# r# i# t# h# m#  # i# s#  # m# o# r# e#  # c# o# m# p# l# i# c# a# t# e# d#  # t# h# e# r# e# f# o# r# e#  # t# o#  # b# e#  # t# a# k# e# n#  # i# n#  # c# o# n# s# i# d# e# r# a# t# i# o# n# .#  # H# o# w# e# v# e# r# ,#  # t# h# e#  # m# a# i# n#  # i# d# e# a#  # i# s#  # a# l# w# a# y# s#  # t# h# e#  # s# a# m# e# :#  # t# o#  # m# i# n# i# m# i# z# e#  # e# r# r# o# r# ,#  # i# n# d# i# v# i# d# u# a# l# i# z# i# n# g#  # t# h# e#  # h# y# p# e# r# p# l# a# n# e#  # w# h# i# c# h#  # m# a# x# i# m# i# z# e# s#  # t# h# e#  # m# a# r# g# i# n# ,#  # k# e# e# p# i# n# g#  # i# n#  # m# i# n# d#  # t# h# a# t#  # p# a# r# t#  # o# f#  # t# h# e#  # e# r# r# o# r#  # i# s#  # t# o# l# e# r# a# t# e# d# .#  

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from matplotlib.colors import ListedColormap

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

# Importing the Dataset

dataset = pd.read_csv("../input/social-network-ads/Social_Network_Ads.csv")

X = dataset.iloc[:, [2, 3]].values
y = dataset.iloc[:, 4].values

# In[None]

# Splitting Dataset into Training and Test set

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7719852.npy", { "accuracy_score": score })

import pandas as pd
# *# *# <# f# o# n# t#  # s# i# z# e# =# "# 5# "# ># R# e# d#  # W# i# n# e#  # A# n# a# l# y# s# i# s# <# /# f# o# n# t# ># *# *# <# b# r# ># <# b# r# ># 
# W# e# l# c# o# m# e#  # t# o#  # t# h# e#  # j# o# u# r# n# e# y#  # o# f#  # a# n# a# l# y# s# i# s#  # o# f#  # W# i# n# e#  # Q# u# a# l# i# t# y# .# <# b# r# ># 
# *# L# e# t# s#  # g# e# t#  # s# t# a# r# t# e# d# *

# *# *# P# l# e# a# s# e#  # U# P# V# O# T# E#  # i# f#  # i# t#  # h# e# l# p# s#  # y# o# u# .# *# *

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # (# a# l# l#  # t# o# g# e# t# h# e# r# )# <# /# f# o# n# t# >

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.metrics import confusion_matrix,accuracy_score

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># R# e# a# d# i# n# g#  # D# a# t# a# <# /# f# o# n# t# >

# In[None]

data=pd.read_csv('../input/winequality-red.csv')
# Reading Data 

# In[None]

data.head()
# Top 5 rows

# In[None]

data.info()
# Information about data types and null values

# In[None]

data.describe()
# Statistical Analysis

# In[None]

data.isnull().any()
# data[data.isnull()].count()

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># C# o# r# r# e# l# a# t# i# o# n# <# /# f# o# n# t# >

# In[None]

corr=data.corr()

sns.set(font_scale=1.10)
plt.figure(figsize=(10, 10))

sns.heatmap(corr, vmax=.8, linewidths=0.01,
            square=True,annot=True,cmap='magma',linecolor="black")
plt.title('Correlation between features');

# <# f# o# n# t#  # s# i# z# e# =# "# 5# "# ># O# u# t# p# u# t#  # V# a# r# i# a# b# l# e# <# /# f# o# n# t# >

# In[None]

data['quality'].value_counts()

# *# *# <# f# o# n# t#  # s# i# z# e# =# "# 5# "# ># D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n# s# <# /# f# o# n# t# ># *# *

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># C# o# u# n# t#  # P# l# o# t# <# /# f# o# n# t# >

# In[None]

sns.countplot(x='quality',data=data)
plt.title('Quality Variable Analysis')
plt.xlabel('Quality').set_size(20)
plt.ylabel('Frequency').set_size(20)
plt.show()

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># P# a# i# r#  # P# l# o# t# <# /# f# o# n# t# >

# In[None]

sns.pairplot(data,plot_kws={'alpha':0.3})
# data.hist(bins=50,figsize=(15,15))

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># B# o# x# p# l# o# t# <# /# f# o# n# t# >

# In[None]

plt.figure(figsize=(10,8))
sns.boxplot(data['quality'],data['fixed acidity'])

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># P# o# i# n# t#  # P# l# o# t# <# /# f# o# n# t# >

# In[None]

plt.figure(figsize=(10,8))
sns.pointplot(data['quality'],data['pH'],color='grey')
plt.xlabel('Quality').set_size(20)
plt.ylabel('pH').set_size(20)

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># R# e# g# r# e# s# s# i# o# n#  # P# l# o# t# <# /# f# o# n# t# >

# In[None]

sns.regplot('alcohol','density',data=data)

# In[None]

sns.regplot('pH','alcohol',data=data)

# In[None]

sns.regplot('fixed acidity','citric acid',data=data)

# In[None]

sns.regplot('pH','fixed acidity',data=data)

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># D# i# v# i# d# i# n# g#  # o# u# t# p# u# t#  # v# a# r# i# a# b# l# e#  # i# n# t# o#  # g# r# o# u# p# s#  # s# o#  # t# h# a# t#  # i# t#  # c# a# n#  # b# e#  # e# a# s# i# l# y#  # *# *# C# l# a# s# s# i# f# i# e# d# *# *# <# /# f# o# n# t# >

# In[None]

bins=[0,4,7,10]
labels=['bad','acceptable','good']
data['group']=pd.cut(data.quality,bins,3,labels=labels)

# In[None]

data.head()

# In[None]

data['group'].value_counts()

# In[None]

sns.set(palette='colorblind')
sns.countplot(x='group',data=data)
plt.title('Group frequencies')
plt.xlabel('Quality group')
plt.ylabel('Frequency')
plt.show()

# *# *# <# f# o# n# t#  # s# i# z# e# =# "# 5# "# ># P# r# e# d# i# c# t# i# o# n# <# /# f# o# n# t# ># *# *

# In[None]

X = data.iloc[:,:-2].values
y = data.iloc[:,-1].values

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># L# a# b# e# l# E# n# c# o# d# e# r# <# /# f# o# n# t# >

# In[None]

y_le = LabelEncoder()
y = y_le.fit_transform(y)

# <# f# o# n# t#  # s# i# z# e# =# "# 4# "# ># S# p# l# i# t# t# i# n# g#  # D# a# t# a# s# e# t# <# /# f# o# n# t# >

# In[None]

pca = PCA(n_components=8)
x_new = pca.fit_transform(X)

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x_new, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4087068.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# ## ##  # R# e# a# d# i# n# g#  # D# a# t# a# s# e# t

# In[None]


sky=pd.read_csv('../input/Skyserver_SQL2_27_2018 6_51_39 PM.csv')
sky.head()

# ## ##  # C# h# e# c# k# i# n# g#  # f# o# r#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s

# In[None]

pd.isnull(sky).sum()

# T# h# e# r# e#  # a# r# e#  # n# o#  # n# u# l# l#  # v# a# l# u# e# s#  # s# o#  # d# o# e# s#  # n# o# t#  # n# e# e# d#  # m# i# s# s# i# n# g#  # v# a# l# u# e#  # i# m# p# u# t# a# t# i# o# n# .

# ## ##  # D# r# o# p# p# i# n# g#  # c# o# l# u# m# n# s#  # n# o# t#  # r# e# l# e# v# a# n# t#  # f# o# r#  # t# r# a# i# n# i# n# g#  # t# h# e#  # m# o# d# e# l#  # l# i# k# e#  # I# D# s# 


# In[None]

sky=sky.drop(['objid','rerun','specobjid','fiberid'], axis=1)

# ## ##  # F# i# n# d# i# n# g#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # c# o# l# u# m# n# s#  # t# o#  # f# e# t# c# h#  # t# h# e#  # b# e# s# t#  # s# u# i# t# a# b# l# e#  # f# e# a# t# u# r# e# s#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .# 
# ## ## ##  # P# l# o# t# t# i# n# g#  # t# h# e#  # h# e# a# t# m# a# p# .

# In[None]

import seaborn as sns
corr=sky.corr() 
sns.heatmap(corr)

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # h# e# a# t# m# a# p#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # c# o# l# u# m# n# s#  # u# ,#  # g# ,#  # r# ,#  # i# ,#  # z#  # a# n# d#  # r# e# d# s# h# i# f# t#  # a# r# e#  # h# i# g# h# l# y#  # c# o# r# r# e# l# a# t# e# d# .#  # S# o# ,#  # w# e# '# l# l#  # u# s# e#  # t# h# e# s# e#  # c# o# l# u# m# n# s#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .

# In[None]

sky=sky[['u','g','r','i','z','redshift','class']]

# ## ##  # F# i# n# d# i# n# g#  # n# u# m# b# e# r#  # o# f#  # u# n# i# q# u# e#  # c# l# a# s# s# e# s#  # i# n#  # '# c# l# a# s# s# '#  # c# o# l# u# m# n#  # a# n# d#  # w# i# l# l#  # c# h# e# c# k#  # i# f#  # t# h# e#  # c# l# a# s# s# e# s#  # a# r# e#  # b# i# a# s# e# d#  # o# r#  # n# o# t# .

# In[None]

sky['class'].unique()

# In[None]

# Here we can see that Galaxies and Stars are more as compared to Quasars and so dataset is biased towards Galaxy and Star
sns.countplot(x='class',data=sky, palette='plasma_r')

# ## ##  # S# p# l# i# t# t# i# n# g#  # d# a# t# a#  # i# n# t# o#  # t# e# s# t# (# 3# 0# %#  # o# f#  # d# a# t# a# )#  # a# n# d#  # t# r# a# i# n# (# 7# 0# %#  # o# f#  # d# a# t# a# )

# In[None]

from sklearn.model_selection import train_test_split
y_varible = sky["class"]
x_varible = sky.drop(["class"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/2303244.npy", { "accuracy_score": score })

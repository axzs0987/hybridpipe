import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
import matplotlib.pyplot as plt
import seaborn as sns
data = pd.read_csv("../input/heart.csv")
data.head()
data.describe()
data.info()
#sns.pairplot(data, hue='target')
#plt.figure(figsize = (10,7))
#sns.heatmap(data.corr(), annot=True)
data.columns
X = data[['age', 'sex', 'cp', 'trestbps', 'restecg', 'thalach',       'exang', 'oldpeak', 'slope', 'ca', 'thal']]
y = data['target']
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression()
#logmodel.fit(X_train, y_train)
#predictions = logmodel.predict(X_test)
from sklearn.metrics import classification_report, confusion_matrix
#print(classification_report(y_test, predictions))
#print(confusion_matrix(y_test, predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alishanathani_heart-disease.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/alishanathani_heart-disease/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/alishanathani_heart-disease/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/alishanathani_heart-disease/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/alishanathani_heart-disease/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/alishanathani_heart-disease/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/alishanathani_heart-disease/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alishanathani_heart-disease/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alishanathani_heart-disease/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alishanathani_heart-disease/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alishanathani_heart-disease/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alishanathani_heart-disease/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alishanathani_heart-disease/testY.csv",encoding="gbk")


import pandas as pd
# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># I# m# p# o# r# t#  # n# e# c# e# s# s# a# r# y#  # m# o# d# u# l# e# s# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# ># 
# *#  # B# a# s# i# c#  # m# o# d# u# l# e# s# 
# *#  # M# o# d# u# l# e# s#  # f# o# r#  # p# l# o# t# t# i# n# g# 
# *#  # 7#  # t# y# p# e# s#  # o# f#  # c# l# a# s# s# i# f# i# e# r# s#  

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression,SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># R# e# a# d#  # d# a# t# a# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# >

# In[None]

data=pd.read_csv('../input/voice.csv')
data.head(5)

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># C# h# e# c# k# i# n# g#  # d# a# t# a#  # f# o# r#  # d# i# s# c# r# e# p# a# n# c# i# e# s# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# ># 
# *#  # N# o#  # d# i# s# c# r# e# p# a# n# c# i# e# s#  # f# o# u# n# d

# In[None]

data.describe()

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># C# h# e# c# k# i# n# g#  # f# o# r#  # s# k# e# w# d# n# e# s# s#  # o# f#  # d# a# t# a# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# ># 
# *#  # D# a# t# a#  # i# s#  # n# o# t#  # s# k# e# w# e# d# 
# *#  # T# h# e# r# e#  # a# r# e#  # i# d# e# n# t# i# c# a# l#  # n# o# .#  # o# f#  # e# n# t# r# i# e# s#  # f# o# r#  # b# o# t# h#  # l# a# b# e# l# s

# In[None]

sns.set()
fig=plt.gcf()
fig.set_size_inches(10,10)
sns.countplot(data['label'])
plt.show()

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># E# n# c# o# d# i# n# g#  # d# a# t# a# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# ># 
# *#  # M# a# l# e#  # -# >#  # 1# 
# *#  # F# e# m# a# l# e#  # -# >#  # 0

# In[None]

data=data.replace('male',1)
data=data.replace('female',0)
data.label.sample(5)

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># C# o# -# r# e# l# a# t# i# o# n#  # o# f#  # a# l# l#  # f# e# a# t# u# r# e# s# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# >

# In[None]

corr = data.corr()
fig=plt.gcf()
fig.set_size_inches(18,10)
ax = sns.heatmap(
    corr, 
    vmin=-1, vmax=1, center=0,
    cmap=sns.diverging_palette(20, 220, n=200),
    square=True
)
ax.set_xticklabels(
    ax.get_xticklabels(),
    rotation=90,
    horizontalalignment='right'
);

# <# c# e# n# t# e# r# ># <# f# o# n# t#  # s# i# z# e# =# 4# ># <# b# ># T# r# a# i# n# -# T# e# s# t#  # s# p# l# i# t# <# /# b# ># <# /# f# o# n# t# ># <# /# c# e# n# t# e# r# ># 
# *#  # 7# 5# %#  # -# >#  # t# r# a# i# n#  # d# a# t# a# 
# *#  # 2# 5# %#  # -# >#  # t# e# s# t#  # d# a# t# a

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(data.drop('label', axis=1), data['label'], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4866494.npy", { "accuracy_score": score })

import pandas as pd
# P# r# o# b# l# e# m#  # S# t# a# t# e# m# e# n# t# :#  # U# n# c# o# v# e# r#  # t# h# e#  # f# a# c# t# o# r# s#  # t# h# a# t#  # l# e# a# d#  # t# o#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n#  # a# n# d#  # e# x# p# l# o# r# e#  # i# m# p# o# r# t# a# n# t#  # q# u# e# s# t# i# o# n# s#  # s# u# c# h#  # a# s#  # ‘# s# h# o# w#  # m# e#  # a#  # b# r# e# a# k# d# o# w# n#  # o# f#  # d# i# s# t# a# n# c# e#  # f# r# o# m#  # h# o# m# e#  # b# y#  # j# o# b#  # r# o# l# e#  # a# n# d#  # a# t# t# r# i# t# i# o# n# ’#  # o# r#  # ‘# c# o# m# p# a# r# e#  # a# v# e# r# a# g# e#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e#  # b# y#  # e# d# u# c# a# t# i# o# n#  # a# n# d#  # a# t# t# r# i# t# i# o# n# ’# .#  # T# h# i# s#  # i# s#  # a#  # f# i# c# t# i# o# n# a# l#  # d# a# t# a#  # s# e# t#  # c# r# e# a# t# e# d#  # b# y#  # I# B# M#  # d# a# t# a#  # s# c# i# e# n# t# i# s# t# s# .# 
# 
# E# d# u# c# a# t# i# o# n#  # 1#  # '# B# e# l# o# w#  # C# o# l# l# e# g# e# '#  # 2#  # '# C# o# l# l# e# g# e# '#  # 3#  # '# B# a# c# h# e# l# o# r# '#  # 4#  # '# M# a# s# t# e# r# '#  # 5#  # '# D# o# c# t# o# r# '# 
# 
# E# n# v# i# r# o# n# m# e# n# t# S# a# t# i# s# f# a# c# t# i# o# n#  # 1#  # '# L# o# w# '#  # 2#  # '# M# e# d# i# u# m# '#  # 3#  # '# H# i# g# h# '#  # 4#  # '# V# e# r# y#  # H# i# g# h# '# 
# 
# J# o# b# I# n# v# o# l# v# e# m# e# n# t# 
# 1#  # '# L# o# w# '#  # 2#  # '# M# e# d# i# u# m# '#  # 3#  # '# H# i# g# h# '#  # 4#  # '# V# e# r# y#  # H# i# g# h# '# 
# 
# J# o# b# S# a# t# i# s# f# a# c# t# i# o# n#  # 1#  # '# L# o# w# '#  # 2#  # '# M# e# d# i# u# m# '#  # 3#  # '# H# i# g# h# '#  # 4#  # '# V# e# r# y#  # H# i# g# h# '# 
# 
# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# 
# 1#  # '# L# o# w# '#  # 2#  # '# G# o# o# d# '#  # 3#  # '# E# x# c# e# l# l# e# n# t# '#  # 4#  # '# O# u# t# s# t# a# n# d# i# n# g# '# 
# 
# R# e# l# a# t# i# o# n# s# h# i# p# S# a# t# i# s# f# a# c# t# i# o# n# 
# 1#  # '# L# o# w# '#  # 2#  # '# M# e# d# i# u# m# '#  # 3#  # '# H# i# g# h# '#  # 4#  # '# V# e# r# y#  # H# i# g# h# '# 
# 
# W# o# r# k# L# i# f# e# B# a# l# a# n# c# e#  # 1#  # '# B# a# d# '#  # 2#  # '# G# o# o# d# '#  # 3#  # '# B# e# t# t# e# r# '#  # 4#  # '# B# e# s# t# '

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# In[None]

df=pd.read_csv('../input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv')

# In[None]

df.head()

# In[None]

df.shape

# In[None]

df.tail(10)

# In[None]

df.isnull().sum()

# In[None]

df.info()

# In[None]

df.describe()

# In[None]

df.fillna(0,inplace=True)

# In[None]

df.isnull().sum()

# In[None]

df.drop(['EmployeeCount','EmployeeNumber','StandardHours'],inplace=True,axis=1)

# In[None]

df.head()

# In[None]

df.corr()

# In[None]

plt.figure(figsize=[20,8])
sns.heatmap(df.corr(),cmap='BuGn',annot=True)
plt.show()

# In[None]

df['Attrition'].value_counts()


# In[None]

print('Yes Attrition percentage is:',(len(df[df['Attrition']=='Yes'])/len(df))*100)
print('Yes Attrition percentage is:',(len(df[df['Attrition']=='No'])/len(df))*100)

# ## ## ## ##  # L# e# t# s#  # d# o#  # s# o# m# e#  # E# D# A

# In[None]

df.columns

# In[None]

sns.countplot(df['Attrition'])
plt.show()

# In[None]

sns.countplot(df['BusinessTravel'])
plt.show()

# *#  # I# t#  # s# h# o# w# s#  # t# h# a# t#  # t# h# e#  # n# u# m# b# e# r#  # y# e# s#  # p# e# r# c# e# n# t# a# g# e#  # i# s#  # m# o# r# e#  # t# h# a# n#  # n# o# .# 
# *#  # i# t#  # a# l# s# o#  # s# h# o# w# s#  # t# h# a# t#  # t# h# e#  # e# m# p# l# o# y# e# s#  # b# u# s# i# n# e# s# s#  # t# r# a# v# e# l#  # i# s#  # r# a# r# e# l# y# .

# In[None]

sns.countplot(df['Department'])
plt.show()

# In[None]

sns.distplot(df['DistanceFromHome'])
plt.show()

# In[None]

df['DistanceFromHome'].mean()

# In[None]

sns.countplot(df['Education'])
plt.show()

# *#  # f# r# o# m#  # a# b# o# v# e#  # w# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # t# h# e#  # e# m# p# l# o# y# e# s#  # i# n#  # R# e# s# e# a# r# c# h#  # a# n# d#  # D# e# v# e# l# o# p# e# m# e# n# t#  # d# e# p# a# r# t# m# e# n# t#  # a# r# e#  # m# o# r# e#  # t# h# a# n#  # o# t# h# e# r# s# .# 
# *#  # A# s#  # w# e#  # c# a# n#  # s# e# e#  # t# h# e#  # d# i# s# t# a# n# c# e#  # f# r# r# o# m#  # h# o# m# e#  # v# a# r# i# e# s#  # f# r# o# m#  # 2#  # t# o#  # a# l# m# o# s# t#  # 2# 8# .# 
# *#  # t# h# e#  # e# d# u# c# a# t# i# o# n#  # v# a# r# i# e# s#  # f# r# o# m#  # 1#  # t# o#  # 5#  # w# h# e# r# e#  # a# s#  # m# o# s# t#  # o# f#  # t# h# e#  # e# m# p# l# o# y# e# s#  # a# r# e#  # i# n#  # 3#  # l# e# v# e# l# .

# In[None]

plt.figure(figsize=[15,6])
sns.countplot(df['EducationField'])
plt.show()

# In[None]

sns.countplot(df['Gender'])
plt.show()

# In[None]

sns.countplot(df['JobLevel'])
plt.show()

# In[None]

plt.figure(figsize=[19,5])
sns.countplot(df['JobRole'])
plt.show()

# *#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # M# a# l# e#  # e# m# p# l# o# y# e# s#  # i# s#  # m# o# r# e#  # t# h# a# n#  # F# e# m# a# l# e# .# 
# *#  # t# h# e#  # j# o# b#  # l# e# v# e# l#  # 1#  # i# s#  # h# a# s#  # h# i# g# h# e# r#  # p# e# r# c# e# n# t# a# g# e#  # t# h# a# n# .# 
# *#  # t# h# e#  # N# u# m# b# e# r#  # o# f#  # e# m# p# l# o# y# e# s#  # i# n#  # S# a# l# e# s#  # E# x# e# c# u# t# i# v# e#  # j# o# b#  # r# o# l# e#  # i# s#  # m# o# r# e#  # t# h# a# n#  # o# t# h# e# r#  # j# o# b#  # r# o# l# e# .

# In[None]

sns.countplot(df['MaritalStatus'])
plt.show()

# In[None]

df.groupby(['Attrition'])['MonthlyIncome'].mean()

# In[None]

sns.countplot(df['NumCompaniesWorked'])
plt.show()

# In[None]

sns.countplot(data=df,x='Gender',hue='Attrition')
plt.show

# In[None]

sns.countplot(df['StockOptionLevel'])
plt.show()

# In[None]

sns.countplot(data=df,x='Attrition',hue='StockOptionLevel')
plt.show()

# In[None]

sns.distplot(df['TotalWorkingYears'])
plt.show()

# In[None]

sns.countplot(data=df,x='Attrition',hue='JobRole')
plt.show()

# In[None]

sns.countplot(data=df,x='Attrition',hue='JobLevel')
plt.show()

# In[None]

df.info()

# In[None]

from sklearn.preprocessing import LabelEncoder
labelEncoder_X = LabelEncoder()
df['BusinessTravel'] = labelEncoder_X.fit_transform(df['BusinessTravel'])
df['Department'] = labelEncoder_X.fit_transform(df['Department'])
df['EducationField'] = labelEncoder_X.fit_transform(df['EducationField'])
df['Gender'] = labelEncoder_X.fit_transform(df['Gender'])
df['JobRole'] = labelEncoder_X.fit_transform(df['JobRole'])
df['MaritalStatus'] = labelEncoder_X.fit_transform(df['MaritalStatus'])
df['Over18'] = labelEncoder_X.fit_transform(df['Over18'])
df['OverTime']=labelEncoder_X.fit_transform(df['OverTime'])

# In[None]

labelencoder_y=LabelEncoder()
df['Attrition']=labelencoder_y.fit_transform(df['Attrition'])

# In[None]

df.head()

# In[None]

y=df['Attrition']
X=df.drop('Attrition',axis=1)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7676025.npy", { "accuracy_score": score })

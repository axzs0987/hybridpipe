import pandas as pd
# ##  # P# r# e# d# i# c# t# i# o# n#  # J# o# b#  # T# e# r# m# i# n# a# t# i# o# n

# ## ##  # I# m# p# o# r# t# i# n# g#  # N# e# c# e# s# a# r# y#  # C# o# d# e

# In[None]

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

import os
#print(os.listdir("../input"))

# ## ##  # R# e# a# d# i# n# g#  # i# n#  # t# h# e#  # D# a# t# a# s# e# t

# In[None]

df = pd.read_csv('../input/MFG10YearTerminationData.csv')

# ## ##  # P# r# e# l# i# m# i# n# a# r# y#  # C# l# e# a# n# i# n# g#  # o# f#  # t# h# e#  # D# a# t# a# s# e# t

# In[None]

df.head(20)

# In[None]

df.tail(20)

# In[None]

df.info()

# ## ##  # O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# -#  # N# o#  # n# u# l# l#  # v# a# l# u# e# s# 
# -#  # D# a# t# a# s# e# t#  # i# s#  # a#  # m# i# x#  # o# f#  # i# n# t# e# g# e# r# s#  # a# n# d#  # s# t# r# i# n# g# s# 
# -#  # S# o# m# e#  # c# o# l# u# m# n# s#  # a# r# e#  # r# e# p# e# t# i# t# i# v# e# ,#  # a# n# d#  # c# a# n#  # b# e#  # r# e# m# o# v# e# d#  # w# i# t# h# o# u# t#  # f# u# r# t# h# e# r#  # a# n# a# l# y# s# i# s# 
#  #  #  #  # -#  # a# g# e#  # c# a# n#  # b# e#  # d# e# t# e# r# m# i# n# e# d#  # f# r# o# m#  # b# i# r# t# h# d# a# t# e# _# k# e# y#  # a# n# d#  # r# e# c# o# r# d# d# a# t# e# _# k# e# y# ,#  # o# n# e#  # s# e# t#  # c# a# n#  # b# e#  # d# i# s# c# a# r# d# e# d# 
#  #  #  #  # -#  # l# e# n# g# t# h# _# o# f# _# s# e# r# v# i# c# e#  # c# a# n#  # b# e#  # d# e# t# e# r# m# i# n# e# d#  # f# r# o# m#  # o# r# i# g# h# i# r# e# d# a# t# e# _# k# e# y#  # a# n# d#  # r# e# c# o# r# d# d# a# t# e# _# k# e# y# ,#  # o# n# e#  # s# e# t#  # c# a# n#  # b# e#  # d# i# s# c# a# r# d# e# d# 
#  #  #  #  # -#  # d# e# p# a# t# m# e# n# t# _# n# a# m# e#  # a# n# d#  # j# o# b# _# t# i# t# l# e#  # a# r# e#  # a# l# s# o#  # p# r# e# t# t# y#  # s# i# m# i# l# a# r# ,#  # s# o#  # o# n# e#  # c# o# l# u# m# n#  # c# a# n#  # b# e#  # d# i# s# c# a# r# d# e# d# 
#  #  #  #  # -#  # c# i# t# y# _# n# a# m# e#  # a# l# s# o#  # h# a# s#  # l# i# t# t# l# e#  # r# e# l# e# v# a# n# c# e# 
# -#  # S# o# m# e#  # c# o# l# u# m# n# s#  # g# i# v# e#  # a# w# a# y#  # i# n# f# o# r# m# a# t# i# o# n#  # t# h# a# t#  # o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l#  # i# s#  # t# r# y# i# n# g#  # t# o#  # p# r# e# d# o# c# t# ,#  # s# o#  # t# h# e# s# e#  # c# o# l# u# m# s#  # m# u# s# t#  # b# e#  # r# e# m# o# v# e# d# 
#  #  #  #  # -#  # t# e# r# m# r# e# a# s# o# n# _# d# e# s# c#  # g# i# v# e# s#  # a# w# a# y#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # t# h# o# s# e#  # e# m# p# l# o# y# e# e# s#  # w# e# r# e#  # t# e# r# m# i# n# a# t# e# d# 
#  #  #  #  # -#  # t# e# r# m# t# y# p# e# _# d# e# s# c#  # a# l# s# o#  # g# i# v# e# s#  # a# w# a# y#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # t# h# o# s# e#  # e# m# p# l# o# y# e# e# s#  # w# e# r# e#  # t# e# r# m# i# n# a# t# e# d# 
# -#  # V# a# r# i# o# u# s#  # e# n# t# r# i# e# s#  # i# n#  # t# h# e#  # c# o# l# u# m# n# s#  # a# r# e#  # i# n#  # t# h# e#  # f# o# r# m#  # o# f#  # s# t# r# i# n# g# s# ,#  # w# e#  # m# u# s# t#  # c# h# a# n# g# e#  # t# h# e# m#  # t# o#  # i# n# t# e# g# r# a# l#  # v# a# l# u# e# s# 
# 
# B# a# s# e# d#  # o# n#  # t# h# e# s# e#  # o# b# s# e# r# v# a# t# i# o# n# s# ,#  # w# e#  # c# a# n#  # s# t# a# r# t#  # r# e# m# o# v# i# n# g#  # a# n# d#  # r# e# f# o# r# m# a# t# t# i# n# g#  # d# a# t# a

# ## ## ##  # D# r# o# p# p# i# n# g#  # C# o# l# u# m# n# s

# In[None]

df = df.drop(columns = ['birthdate_key', 'recorddate_key', 'orighiredate_key', 'terminationdate_key', 'termreason_desc', 'termtype_desc', 'department_name', 'gender_full'])

# ## ## ##  # R# e# f# o# r# m# a# t# i# n# g#  # s# t# r# i# n# g# s#  # i# n# t# o#  # i# n# t# e# g# r# a# l#  # d# a# t# a

# In[None]

df['job_title'].value_counts()

# In[None]

'''
Job_title is the most tedious column, as it has many distinct entries, we will generalize like jobs into categories, and
then turn them into numerical values
'''

board = ['VP Stores', 'Director, Recruitment', 'VP Human Resources', 'VP Finance',
         'Director, Accounts Receivable', 'Director, Accounting',
         'Director, Employee Records', 'Director, Accounts Payable',
         'Director, HR Technology', 'Director, Investments',
         'Director, Labor Relations', 'Director, Audit', 'Director, Training',
         'Director, Compensation']

executive = ['Exec Assistant, Finance', 'Exec Assistant, Legal Counsel',
             'CHief Information Officer', 'CEO', 'Exec Assistant, Human Resources',
             'Exec Assistant, VP Stores']

manager = ['Customer Service Manager', 'Processed Foods Manager', 'Meats Manager',
           'Bakery Manager', 'Produce Manager', 'Store Manager', 'Trainer', 'Dairy Manager']


employee = ['Meat Cutter', 'Dairy Person', 'Produce Clerk', 'Baker', 'Cashier',
            'Shelf Stocker', 'Recruiter', 'HRIS Analyst', 'Accounting Clerk',
            'Benefits Admin', 'Labor Relations Analyst', 'Accounts Receiveable Clerk',
            'Accounts Payable Clerk', 'Auditor', 'Compensation Analyst',
            'Investment Analyst', 'Systems Analyst', 'Corporate Lawyer', 'Legal Counsel']

def changeTitle(row):
    if row in board:
        return 'board'
    elif row in executive:
        return 'executive'
    elif row in manager:
        return 'manager'
    else:
        return 'employee'
    
df['job_title'] = df['job_title'].apply(changeTitle)

df.head()

# In[None]

df['job_title'] = df['job_title'].map({'board': 3, 'executive': 2, 'manager': 1, 'employee': 0})
df.head()

# In[None]

df['city_name'].value_counts()

# We will sort these cities by population, and then turn them into integral values 

# In[None]

city_pop_2011 = {'Vancouver':2313328,
                 'Victoria':344615,
                 'Nanaimo':146574,
                 'New Westminster':65976,
                 'Kelowna':179839,
                 'Burnaby':223218,
                 'Kamloops':85678,
                 'Prince George':71974,
                 'Cranbrook':19319,
                 'Surrey':468251,
                 'Richmond':190473,
                 'Terrace':11486,
                 'Chilliwack':77936,
                 'Trail':7681,
                 'Langley':25081,
                 'Vernon':38180,
                 'Squamish':17479,
                 'Quesnel':10007,
                 'Abbotsford':133497,
                 'North Vancouver':48196,
                 'Fort St John':18609,
                 'Williams Lake':10832,
                 'West Vancouver':42694,
                 'Port Coquitlam':55985,
                 'Aldergrove':12083,
                 'Fort Nelson':3561,
                 'Nelson':10230,
                 'New Westminister':65976,
                 'Grand Forks':3985,
                 'White Rock':19339,
                 'Haney':76052,
                 'Princeton':2724,
                 'Dawson Creek':11583,
                 'Bella Bella':1095,
                 'Ocean Falls':129,
                 'Pitt Meadows':17736,
                 'Cortes Island':1007,
                 'Valemount':1020,
                 'Dease Lake':58,
                 'Blue River':215}

# In[None]

#Make a copy of city names
df['Pop'] = df['city_name']

# Map from city name to population
df['Pop'] = df.Pop.map(city_pop_2011)

# Make a new column for population category
df['Pop_category'] = df.Pop

# Categorise according to population size
# >= 100,000 is City
# 10,000 to 99,999 is Rural
# < 10,000 is Remote
# Guidance from Australian Institute of Health and Welfare
# http://www.aihw.gov.au/rural-health-rrma-classification/
city_ix = (df['Pop'] >= 100000)
rural_ix = ((df['Pop'] < 100000) & (df['Pop'] >= 10000))
remote_ix = (df['Pop'] < 10000)
df.loc[city_ix, 'Pop_category'] = 'City'
df.loc[rural_ix, 'Pop_category'] = 'Rural'
df.loc[remote_ix, 'Pop_category'] = 'Remote'

df['Pop_category'] = df['Pop_category'].map({'City' : 0, 'Rural' : 1, 'Remote' : 2})

# Check the replacement went to plan
df.Pop_category.value_counts()

# In[None]

df['gender_short'] = df['gender_short'].map({'M': 1, 'F': 0})

# In[None]

df['STATUS'] = df['STATUS'].map({'ACTIVE': 1, 'TERMINATED': 0})
df.head()

# In[None]

df['BUSINESS_UNIT'].value_counts()

# In[None]

df['BUSINESS_UNIT'] = df['BUSINESS_UNIT'].map({'STORES': 0, 'HEADOFFICE' :1})

# ## ##  # I# n# t# e# r# p# r# e# t# i# n# g#  # t# h# e#  # D# a# t# a

# In[None]

out_of_co = df[df.STATUS == 0]
in_co = df[df.STATUS == 1]

# In[None]

df.head()

# In[None]

a = sns.jointplot(out_of_co.age, out_of_co.length_of_service, color='r')

# In[None]

a = sns.FacetGrid(out_of_co, col='Pop_category', row='job_title', palette='Set1_r', 
                  hue='gender_short', margin_titles=True)
b = (a.map(plt.scatter, 'age', 'length_of_service').add_legend())

# In[None]

c = sns.FacetGrid(in_co, col='Pop_category', row='job_title', palette='Set1_r', 
                  hue='gender_short', margin_titles=True)
d = (c.map(plt.scatter, 'age', 'length_of_service').add_legend())

# ## ##  # O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# -#  # N# o# b# o# d# y#  # w# a# s#  # t# e# r# m# i# n# a# t# e# d#  # i# f#  # t# h# e# y#  # w# e# r# e#  # a# t#  # t# h# e#  # e# x# e# c# u# t# i# v# e#  # l# e# v# e# l# ,#  # o# r#  # h# i# g# h# e# r# .# 
# -#  # N# o#  # m# a# j# o# r#  # d# i# s# c# r# e# p# a# n# c# y#  # b# e# t# w# e# e# n#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # t# e# r# m# i# n# a# t# i# o# n# 
# -#  # E# x# e# c# u# t# i# v# e# s#  # a# n# d#  # b# o# a# r# d#  # m# e# m# b# e# r# s#  # l# i# v# e#  # i# n#  # t# h# e#  # c# i# t# i# e# s

# ## ##  # P# r# e# p# a# r# i# n# g#  # T# h# e#  # M# o# d# e# l

# In[None]

# Deleting columns that are not relevant to predictions
short_df = df.drop(columns = ['EmployeeID', 'store_name','job_title','BUSINESS_UNIT', 'city_name'])

# In[None]

y = short_df['STATUS']
X = short_df.drop('STATUS', axis=1)

# In[None]

y.head()

# In[None]



# In[None]

X.head()

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5087762.npy", { "accuracy_score": score })

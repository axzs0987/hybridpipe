import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

#  # ##  # D# a# t# a# 
# *#  # F# i# r# s# t#  # l# e# t# '# s#  # m# a# k# e#  # o# u# r#  # d# a# t# a#  # r# e# a# d# y# .

# In[None]

df = pd.read_csv("/kaggle/input/logistic-regression/Social_Network_Ads.csv")

df.drop(["User ID","Gender"],axis=1,inplace=True)

y = df.Purchased.values
x_data = df.drop(["Purchased"],axis=1)

x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data)).values

#  # ##  # T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t# 
# *#  # L# e# t# '# s#  # d# e# c# l# a# r# e#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # f# o# r#  # b# o# t# h#  # o# f#  # x#  # a# n# d#  # y#  # w# i# t# h#  # h# e# l# p#  # o# f#  # t# h# e#  # S# k# l# e# a# r# n#  # l# i# b# r# a# r# y# .

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8781413.npy", { "accuracy_score": score })

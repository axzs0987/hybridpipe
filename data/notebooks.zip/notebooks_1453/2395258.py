import pandas as pd
# ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# I#  # a# m#  # g# o# n# n# a#  # w# o# r# k#  # o# n#  # a# n#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a#  # i# n#  # t# h# i# s#  # h# o# m# e# w# o# r# k#  # w# h# i# c# h#  # I#  # d# o# n# '# t#  # r# e# c# o# g# n# i# z# e#  # y# e# t# .#  # I#  # w# i# l# l#  # t# r# y#  # a# p# p# l# y#  # L# o# g# i# c# a# l#  # R# e# g# r# e# s# s# i# o# n#  # t# o#  # r# e# c# o# g# n# i# z# e#  # m# y#  # y# _# t# e# s# t#  # f# r# o# m#  # m# y#  # x# _# t# e# s# t# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

df = pd.read_csv("../input/voice.csv")

# In[None]

df.head()

# In[None]

df.info()

# In[None]

df.label = [1 if each == "male" else 0 for each in df.label]


# In[None]

df.label.head()

# In[None]

x_data = df.drop(["label"],axis = 1)
y = df.label.values

# In[None]

#Normalization
x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data))

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2395258.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt #graph
import seaborn as sns 

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

df = pd.read_csv('../input/bigml_59c28831336c6604c800002a.csv')
df.head()

# In[None]

df.dtypes

# In[None]

df["voice mail plan"].value_counts()
df["international plan"].value_counts()

# In[None]

cleanup_nums = {"voice mail plan":     {"no": 0, "yes": 1},
                "international plan": {"no": 0, "yes": 1 }
               }

obj_df = df.copy()
obj_df.replace(cleanup_nums, inplace=True)
obj_df.head()

# In[None]

obj_df = df.copy()

# In[None]

obj_df.replace(cleanup_nums, inplace=True)
obj_df.head()

# In[None]

print(obj_df.groupby('churn')['phone number'].count())

# In[None]

######################################################
############################
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

drp = obj_df[['state','area code','phone number','international plan','voice mail plan','churn']]
X= obj_df.drop(drp,1)
y= obj_df.churn
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1700217.npy", { "accuracy_score": score })

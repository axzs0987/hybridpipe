import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[None]

df = pd.read_csv('../input/voice.csv')

# In[None]

df.head()

# In[None]

df.dtypes

# In[None]

df.shape

# In[None]

#For normally distributed data, the skewness should be about 0. 
#A skewness value > 0 means that there is more weight in the left tail of the distribution. 

df.skew()

# In[None]

#Finding Correlation among the features
df.corr()

# In[None]

df.isnull().sum()
#This shows that our data has no missing values in it. That is good!

# In[None]

print("Total number ber of people involve in the test: {}".format(df.shape[0]))
print("Number of Male: {}".format(df[df.label == 'male'].shape[0]))
print("Number of Female: {}".format(df[df.label == 'female'].shape[0]))

#It proves the data contain same number of male and female labels

# In[None]

#Visualising individual features of our data
df.hist(figsize=(16,16))
plt.show()

# In[None]

#Finding the relationship between independent and dependent variable(Label)
sns.pointplot(x='label',y='meanfreq',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='sd',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='median',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='Q25',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='Q75',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='IQR',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='skew',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='kurt',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='sp.ent',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='sfm',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='mode',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='centroid',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='meanfun',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='minfun',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='maxfun',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='meandom',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='mindom',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='maxdom',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='dfrange',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

sns.pointplot(x='label',y='modindx',data=df,color='red',alpha=0.8,label = 'a')

# In[None]

X = df.iloc[:,:-1]
X.head()
#Now X contains all the features except labels

# In[None]

#Saving labels in variable y
y = df.iloc[:,-1]
y.head()

# In[None]

#Now we are encoding the labels in the form of ones and zeros
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
y = encoder.fit_transform(y)

# In[None]

print(y)
#It shows that our labels are encoded as ones and zeros
#One = Male
#Zero = Female

# In[None]

#Splitting our data into train and test sets
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/432334.npy", { "accuracy_score": score })

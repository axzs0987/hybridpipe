import pandas as pd
# ##  # A# d# u# l# t#  # D# a# t# a#  # I# n# c# o# m# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # N# o# t# e# b# o# o# k

# T# h# e#  # G# o# a# l#  # i# s#  # t# o#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # h# a# s#  # a# n#  # i# n# c# o# m# e#  # o# f#  # m# o# r# e#  # t# h# a# n#  # 5# 0# K#  # a#  # y# e# a# r#  # o# r#  # n# o# t# .#  # T# h# i# s#  # i# s#  # b# a# s# i# c# a# l# l# y#  # a#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # w# h# e# r# e#  # a#  # p# e# r# s# o# n#  # i# s#  # c# l# a# s# s# i# f# i# e# d#  # i# n# t# o#  # t# h# e#  # ># 5# 0# K#  # g# r# o# u# p#  # o# r#  # <# =# 5# 0# K#  # g# r# o# u# p# .#  # I#  # h# a# v# e#  # u# s# e# d#  # R# a# n# d# o# m#  # F# o# r# e# s# t# s#  # a# n# d#  # D# e# c# i# s# i# o# n#  # T# r# e# e#  # t# o#  # t# a# c# k# l# e#  # t# h# i# s#  # p# r# o# b# l# e# m# .#  # 
# T# h# e#  # d# a# t# a# s# e# t#  # i# s#  # t# a# k# e# n#  # f# r# o# m#  # t# h# e#  # U# C# I#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # R# e# p# o# s# i# t# o# r# y# .#  # T# h# e#  # l# i# n# k#  # t# o#  # t# h# e#  # s# a# m# e#  # i# s#  # t# h# e#  # f# o# l# l# o# w# i# n# g# :#  # h# t# t# p# s# :# /# /# a# r# c# h# i# v# e# .# i# c# s# .# u# c# i# .# e# d# u# /# m# l# /# d# a# t# a# s# e# t# s# /# c# e# n# s# u# s# +# i# n# c# o# m# e# 
# ## ## ##  # T# h# i# s#  # N# o# t# e# b# o# o# k#  # c# o# v# e# r# s#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # a# s# p# e# c# t# s# :# 
#  #  #  # ## ## ## ##  # 1# .#  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # V# i# s# u# a# l# i# z# a# t# i# o# n# 
#  #  #  # ## ## ## ##  # 2# .#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # T# a# s# k# 
#  #  #  # ## ## ## ##  # 3# .#  # H# y# p# e# r# p# a# r# a# m# e# t# e# r#  # T# u# n# i# n# g# 
#  #  #  # ## ## ## ##  # 4# .#  # B# u# i# l# d# i# n# g#  # t# h# e#  # F# i# n# a# l#  # M# o# d# e# l# 
#  #  #  # ## ## ## ##  # A# p# p# e# n# d# i# x#  # -#  # A# d# d# i# t# i# o# n# a# l#  # I# n# f# o# r# m# a# t# i# o# n#  # a# n# d#  # g# r# a# p# h# s#  # a# b# o# u# t#  # h# y# p# e# r# p# a# r# a# m# e# t# e# r#  # t# u# n# i# n# g#  # o# f#  # R# a# n# d# o# m#  # F# o# r# e# s# t# s

# ## ## ##  # 1# .#  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# In[None]

import numpy as np
import pandas as pd

df = pd.read_csv("../input/adult.csv")
df.head()

# In[None]

df.dtypes

# C# h# e# c# k# i# n# g#  # f# o# r#  # n# u# l# l#  # a# n# d# /# o# r#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s

# In[None]

df.isnull().sum()

# In[None]

df.columns.isna()

# In[None]

df.isin(['?']).sum()

# In[None]

df = df.replace('?', np.NaN)
df.head()

# In[None]

df = df.dropna()
df.head()

# M# a# p# p# i# n# g#  # t# h# e#  # i# n# c# o# m# e#  # l# a# b# e# l# s#  # n# u# m# e# r# i# c# a# l# l# y

# In[None]

df['income'] = df['income'].map({'<=50K':0, '>50K':1})
df.income.head()

# In[None]

numerical_df = df.select_dtypes(exclude=['object'])
numerical_df.columns

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

plt.hist(df['age'], edgecolor='black')
plt.title('Age Histogram')
plt.axvline(np.mean(df['age']), color='yellow', label='average age')
plt.legend()

# In[None]

age50k = df[df['income']==1].age
agel50k = df[df['income']==0].age

fig, axs = plt.subplots(2, 1)

axs[0].hist(age50k, edgecolor='black')
axs[0].set_title('Distribution of Age for Income > 50K')

axs[1].hist(agel50k, edgecolor='black')
axs[1].set_title('Distribution of Age for Income <= 50K')
plt.tight_layout()

# ## ## ## ##  # I# n# f# e# r# e# n# c# e# s# :# 
# 
# F# o# r#  # I# n# c# o# m# e#  # >#  # 5# 0# K# ,#  # A# g# e#  # i# s#  # a# l# m# o# s# t#  # n# o# r# m# a# l# l# y#  # d# i# s# t# r# i# b# u# t# e# d# 
# 
# F# o# r#  # I# n# c# o# m# e#  # <# =# 5# 0# K# ,#  # A# g# e#  # i# s#  # p# o# s# i# t# i# v# e# l# y#  # s# k# e# w# e# d# .#  # M# o# r# e#  # p# e# o# p# l# e#  # i# n#  # t# h# e#  # 2# 0# s#  # a# n# d#  # 3# 0# s#  # h# a# v# e#  # i# n# c# o# m# e#  # <# =#  # 5# 0# K# .

# In[None]

df['marital.status'].unique()

# In[None]

ax = sns.countplot(df['marital.status'], hue=df['income'])
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")
plt.tight_layout()

# ## ## ## ##  # C# o# n# v# e# r# t# i# n# g#  # m# a# r# i# t# a# l# .# s# t# a# t# u# s#  # t# o#  # 2#  # c# a# t# e# g# o# r# i# e# s# 
# 
# I# t#  # s# e# e# m# s#  # b# e# t# t# e# r#  # t# o#  # r# e# d# u# c# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # c# a# t# e# g# o# r# i# e# s#  # f# o# r#  # m# a# r# i# t# a# l#  # s# t# a# t# u# s#  # t# o#  # b# e# t# t# e# r#  # v# i# s# u# a# l# i# z# e#  # t# h# e#  # e# f# f# e# c# t#  # o# f#  # m# a# r# i# t# a# l#  # s# t# a# t# u# s#  # o# n#  # i# n# c# o# m# e# .#  # 
# W# e#  # n# e# e# d#  # t# o#  # c# o# n# v# e# r# t#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # i# n# t# o#  # 2#  # d# i# s# t# i# n# c# t#  # c# a# t# e# g# o# r# i# e# s#  # n# a# m# e# l# y# ,#  # "# m# a# r# r# i# e# d# "#  # a# n# d#  # "# s# i# n# g# l# e# "

# In[None]

df['marital.status'] = df['marital.status'].replace(['Widowed', 'Divorced', 'Separated', 'Never-married'], 'single')

df['marital.status'] = df['marital.status'].replace(['Married-spouse-absent', 'Married-civ-spouse', 'Married-AF-spouse'], 'married')

# In[None]

categorical_df = df.select_dtypes(include=['object'])
categorical_df.columns

# In[None]

sns.countplot(df['marital.status'], hue=df['income'])

# ## ## ## ##  # I# n# f# e# r# e# n# c# e# :# 
# 
# M# a# r# r# i# e# d#  # p# e# o# p# l# e#  # a# r# e#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # e# a# r# n#  # m# o# r# e#  # t# h# a# n#  # 5# 0# K#  # a# s#  # i# n# c# o# m# e

# ## ## ## ##  # E# n# c# o# d# i# n# g#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # n# u# m# e# r# i# c# a# l# l# y#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  

# In[None]

from sklearn.preprocessing import LabelEncoder
enc = LabelEncoder()

# In[None]

ax = sns.countplot(df['income'], hue=df['race'])
ax.set_title('')

# In[None]

categorical_df = categorical_df.apply(enc.fit_transform)
categorical_df.head()

# In[None]

df = df.drop(categorical_df.columns, axis=1)
df = pd.concat([df, categorical_df], axis=1)
df.head()

# In[None]

sns.factorplot(data=df, x='education', y='hours.per.week', hue='income', kind='point')

# In[None]

sns.FacetGrid(data=df, hue='income', size=6).map(plt.scatter, 'age', 'hours.per.week').add_legend()

# ## ## ## ##  # I# n# f# e# r# e# n# c# e# s# :#  # 
#  #  #  #  # 1# .#  # M# a# x# i# m# u# m#  # p# e# o# p# l# e#  # b# e# t# w# e# e# n#  # t# h# e#  # a# g# e#  # o# f#  # 2# 5#  # t# o#  # 8# 0#  # e# a# r# n#  # m# o# r# e#  # t# h# a# n#  # 5# 0# K#  # a# s#  # i# n# c# o# m# e# 
#  #  #  #  # 2# .#  # M# o# s# t#  # p# e# o# p# l# e#  # w# h# i# c# h#  # w# o# r# k#  # a# t# l# e# a# s# t#  # 3# 6#  # t# o#  # 7# 0#  # h# o# u# r# s#  # a#  # w# e# e# k#  # e# a# r# n#  # m# o# r# e#  # t# h# a# n#  # 5# 0# K# 
#  #  #  #  # 3# .#  # M# o# s# t#  # p# e# o# p# l# e#  # u# n# d# e# r#  # t# h# e#  # a# g# e#  # o# f#  # 2# 0#  # e# a# r# n#  # l# e# s# s#  # t# h# a# n#  # a# s#  # m# 5# 0# K#  # i# n# c# o# m# e

# In[None]

plt.figure(figsize=(15,12))
cor_map = df.corr()
sns.heatmap(cor_map, annot=True, fmt='.3f', cmap='YlGnBu')

# ## ## ##  # 2# .#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # T# a# s# k

# In[None]

from sklearn.model_selection import train_test_split

X = df.drop('income', axis=1)
y = df['income']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2797150.npy", { "accuracy_score": score })

import pandas as pd
# ## ##  # A# b# o# u# t# 
# _# _# _# _# _# _# _# _# _# 
# 
# T# h# i# s#  # n# o# t# e# b# o# o# k#  # c# o# n# t# a# i# n# s#  # a#  # v# e# r# y#  # f# a# s# t#  # f# u# n# d# a# m# e# n# t# a# l#  # k# -# n# e# a# r# e# s# t#  # n# e# i# g# h# b# o# u# r#  # e# x# a# m# p# l# e#  # i# n#  # P# y# t# h# o# n# .# 
# 	# 
# T# h# i# s#  # w# o# r# k#  # i# s#  # p# a# r# t#  # o# f#  # a#  # s# e# r# i# e# s#  # c# a# l# l# e# d#  # [# M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # i# n#  # m# i# n# u# t# e# s#  # -#  # v# e# r# y#  # f# a# s# t#  # f# u# n# d# a# m# e# n# t# a# l#  # e# x# a# m# p# l# e# s#  # i# n#  # P# y# t# h# o# n# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# j# a# m# i# e# m# o# r# a# l# e# s# /# m# a# c# h# i# n# e# -# l# e# a# r# n# i# n# g# -# i# n# -# m# i# n# u# t# e# s# -# v# e# r# y# -# f# a# s# t# -# e# x# a# m# p# l# e# s# )# .#  # 
# 	# 
# T# h# e#  # a# p# p# r# o# a# c# h#  # i# s#  # d# e# s# i# g# n# e# d#  # t# o#  # h# e# l# p#  # g# r# a# s# p#  # t# h# e#  # a# p# p# l# i# e# d#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # l# i# f# e# c# y# c# l# e#  # i# n#  # m# i# n# u# t# e# s# .#  # I# t#  # i# s#  # n# o# t#  # a# n#  # a# l# t# e# r# n# a# t# i# v# e#  # t# o#  # a# c# t# u# a# l# l# y#  # t# a# k# i# n# g#  # t# h# e#  # t# i# m# e#  # t# o#  # l# e# a# r# n# .#  # W# h# a# t#  # i# t#  # a# i# m# s#  # t# o#  # d# o#  # i# s#  # h# e# l# p#  # s# o# m# e# o# n# e#  # g# e# t#  # s# t# a# r# t# e# d#  # f# a# s# t#  # a# n# d#  # g# a# i# n#  # i# n# t# u# i# t# i# v# e#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # o# f#  # t# h# e#  # t# y# p# i# c# a# l#  # s# t# e# p# s#  # e# a# r# l# y#  # o# n# .

# ## ##  # S# t# e# p#  # 0# :#  # U# n# d# e# r# s# t# a# n# d#  # t# h# e#  # p# r# o# b# l# e# m# 
# W# h# a# t#  # w# e# '# r# e#  # t# r# y# i# n# g#  # t# o#  # d# o#  # h# e# r# e#  # i# s#  # t# o#  # c# l# a# s# s# i# f# y#  # a# c# t# i# v# i# t# i# e# s#  # o# f#  # e# l# d# e# r# l# y#  # p# a# t# i# e# n# t# s# .

# ## ##  # S# t# e# p#  # 1# :#  # S# e# t# -# u# p#  # a# n# d#  # u# n# d# e# r# s# t# a# n# d#  # d# a# t# a# 
# T# h# i# s#  # s# t# e# p#  # h# e# l# p# s#  # u# n# c# o# v# e# r#  # i# s# s# u# e# s#  # t# h# a# t#  # w# e#  # w# i# l# l#  # w# a# n# t#  # t# o#  # a# d# d# r# e# s# s#  # i# n#  # t# h# e#  # n# e# x# t#  # s# t# e# p#  # a# n# d#  # t# a# k# e#  # i# n# t# o#  # a# c# c# o# u# n# t#  # w# h# e# n#  # b# u# i# l# d# i# n# g#  # a# n# d#  # e# v# a# l# u# a# t# i# n# g#  # o# u# r#  # m# o# d# e# l# .#  # W# e#  # a# l# s# o#  # w# a# n# t#  # t# o#  # f# i# n# d#  # i# n# t# e# r# e# s# t# i# n# g#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # o# r#  # p# a# t# t# e# r# n# s#  # t# h# a# t#  # w# e#  # c# a# n#  # p# o# s# s# i# b# l# y#  # l# e# v# e# r# a# g# e#  # i# n#  # s# o# l# v# i# n# g#  # t# h# e#  # p# r# o# b# l# e# m#  # w# e#  # s# p# e# c# i# f# i# e# d# .

# In[None]

# Set-up libraries
import os
import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report

# In[None]

# Check data input source
for dirname, _, filenames in os.walk('../input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# In[None]

# Read-in data
df = pd.read_csv('../input/falldata/falldeteciton.csv')

# In[None]

# Look at some details
df.info()

# In[None]

# Look at some records
df.head()

# In[None]

# Check for missing values
df.isna().sum()

# In[None]

# Look at breakdown of label
sns.countplot(df['ACTIVITY'])
df['ACTIVITY'].value_counts()

# In[None]

# Explore data visually with multiple scatter plots
sns.pairplot(df, hue='ACTIVITY')

# In[None]

# Summarise
df.describe()

# ## ##  # S# t# e# p#  # 2# :#  # P# r# e# p# r# o# c# e# s# s#  # d# a# t# a# 
# T# h# i# s#  # s# t# e# p#  # t# y# p# i# c# a# l# l# y#  # t# a# k# e# s#  # t# h# e#  # m# o# s# t#  # t# i# m# e#  # i# n#  # t# h# e#  # c# y# c# l# e#  # b# u# t#  # f# o# r#  # o# u# r#  # p# u# r# p# o# s# e# s# ,#  # m# o# s# t#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# s#  # c# h# o# s# e# n#  # i# n#  # t# h# i# s#  # s# e# r# i# e# s#  # a# r# e#  # c# l# e# a# n# .#  # 
# 	# 
# R# e# a# l# -# w# o# r# l# d#  # d# a# t# a# s# e# t# s#  # a# r# e#  # n# o# i# s# y#  # a# n# d#  # i# n# c# o# m# p# l# e# t# e# .#  # T# h# e#  # c# h# o# i# c# e# s#  # w# e#  # m# a# k# e#  # i# n#  # t# h# i# s#  # s# t# e# p#  # t# o#  # a# d# d# r# e# s# s#  # d# a# t# a#  # i# s# s# u# e# s#  # c# a# n#  # i# m# p# a# c# t#  # d# o# w# n# s# t# r# e# a# m#  # s# t# e# p# s#  # a# n# d#  # t# h# e#  # r# e# s# u# l# t#  # i# t# s# e# l# f# .#  # F# o# r#  # e# x# a# m# p# l# e# ,#  # i# t#  # c# a# n#  # b# e#  # t# r# i# c# k# y#  # t# o#  # a# d# d# r# e# s# s#  # m# i# s# s# i# n# g#  # d# a# t# a#  # w# h# e# n#  # w# e#  # d# o# n# '# t#  # k# n# o# w#  # w# h# y#  # i# t# '# s#  # m# i# s# s# i# n# g# .#  # I# s#  # i# t#  # m# i# s# s# i# n# g#  # c# o# m# p# l# e# t# e# l# y#  # a# t#  # r# a# n# d# o# m#  # o# r#  # n# o# t# ?#  # I# t#  # c# a# n#  # a# l# s# o#  # b# e#  # t# r# i# c# k# y#  # t# o#  # a# d# d# r# e# s# s#  # o# u# t# l# i# e# r# s#  # i# f#  # w# e#  # d# o#  # n# o# t#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # d# o# m# a# i# n#  # a# n# d#  # p# r# o# b# l# e# m#  # c# o# n# t# e# x# t#  # e# n# o# u# g# h# .

# In[None]

# Split dataset into 80% train and 20% validation
X = df.drop('ACTIVITY', axis=1)
y = df['ACTIVITY']
from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_val)
score = accuracy_score(y_val, y_pred)
import numpy as np
np.save("prenotebook_res/8603261.npy", { "accuracy_score": score })

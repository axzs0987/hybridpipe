import pandas as pd
# In[None]

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
simplefilter(action='ignore', category=DeprecationWarning)

# load data
data = pd.read_csv('../input/predicting-a-pulsar-star/pulsar_stars.csv')
data.head()

# In[None]

# concise way to display stats in the data including nulls and skewness
def data_stats(df):
    lines = df.shape[0]
    d_types = df.dtypes
    counts = df.apply(lambda x: x.count())
    unique = df.apply(lambda x: x.unique().shape[0])
    nulls = df.isnull().sum()
    missing_ratio = (df.isnull().sum()/lines)*100
    skewness = df.skew()
    col_names = ['dtypes', 'counts', 'unique', 'nulls', 'missing_ratio', 'skewness']
    temp = pd.concat([d_types, counts, unique, nulls, missing_ratio, skewness], axis=1)
    temp.columns = col_names
    return temp


stats = data_stats(data)
stats

# T# h# e#  # C# o# l# u# m# n#  # n# a# m# e# s#  # a# r# e#  # a#  # b# i# t#  # u# n# w# i# e# l# d# l# y#  # s# o#  # f# i# r# s# t#  # w# e#  # w# i# l# l#  # d# e# a# l#  # w# i# t# h#  # t# h# e# m

# In[None]

col_names = ['mean_IP', 'std_IP', 'kurt_IP', 'skew_IP', 'mean_DMSNR', 'std_DMSNR', 'kurt_DMSNR', 'skew_DMSNR', 'target_class']
data.columns = col_names

# In[None]

data.describe()

# D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n

# In[None]

fig = plt.figure(figsize=(8,6))
sns.countplot(data['target_class'])

# t# h# i# s#  # i# s#  # s# e# v# e# a# r# l# y#  # u# n# b# a# l# a# n# c# e# d#  # w# e#  # w# i# l# l#  # h# a# v# e#  # t# o#  # m# a# k# e#  # s# u# r# e#  # w# e#  # k# e# e# p#  # t# h# i# s#  # i# n#  # m# i# n# d#  # w# h# e# n#  # m# o# d# e# l# i# n# g# .

# In[None]

# pairplot
sns.pairplot(data, 
             vars=['mean_IP', 'std_IP', 'kurt_IP', 'skew_IP', 'mean_DMSNR', 'std_DMSNR', 'kurt_DMSNR', 'skew_DMSNR'],
             hue='target_class')

# In[None]

# heatmap
fig = plt.figure(figsize=(12, 10))
sns.heatmap(data.corr(), annot=True)

# In[None]

# plot distributions
def plot_dists(df, col_1, col_2='target_class'):
    fig, axis = plt.subplots(1, 2, figsize=(16, 5))
    
    sns.distplot(df[col_1], ax=axis[0])
    axis[0].set_title('distribution of {}. Skewness = {:.4f}'.format(col_1 ,df[col_1].skew()))
    
    sns.violinplot(x=col_2, y=col_1, data=data, ax=axis[1], inner='quartile')
    axis[1].set_title('violin of {}, split by target'.format(col_1))
    plt.show()
    
for col in data.columns[:-1]:
    plot_dists(data, col)

# L# e# t# s#  # c# r# e# a# t# e#  # a#  # b# a# s# e# l# i# n# e#  # m# o# d# e# l#  # s# c# o# r# e#  # f# o# r#  # c# o# m# p# a# r# i# s# o# n#  # p# u# r# p# o# s# e# s

# In[None]

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.base import clone
from sklearn.model_selection import KFold, cross_val_score, train_test_split

# In[None]

# score function
def cv_score(model, features, label, folds):
    cv=KFold(n_splits=folds, shuffle=True)
    cv_estimate = cross_val_score(model, features, label, cv=cv, scoring='roc_auc', n_jobs=4)
    mean = np.mean(cv_estimate)
    std = np.std(cv_estimate)
    return mean, std

# In[None]

# set up dataframe for estimator evaluation
indx_estimators = ['LogisticRegression', 'SVC', 'AdaBoostClassifier', 'GradientBoostingClassifier', 'RandomForestClassifier', 'MPLClassifier']
column_names = ['roc_auc_mean', 'roc_auc_std']
results = pd.DataFrame(columns=column_names, index=indx_estimators)

# In[None]

# initialize models with balanced class_weight as the target is unbalanced
# log_mod = LogisticRegression(class_weight='balanced')
# svc_mod = SVC(probability=True, class_weight='balanced')
# ada_mod = AdaBoostClassifier()
# gbc_mod = GradientBoostingClassifier()
# rfc_mod = RandomForestClassifier(class_weight='balanced')
# mlp_mod = MLPClassifier()

# In[None]

# We need to transform and scale the skewed data. because there is over 1000 samples we can use the quantile transformer.
from sklearn.preprocessing import QuantileTransformer
X = data[['mean_IP', 'std_IP', 'kurt_IP', 'skew_IP', 'mean_DMSNR', 'std_DMSNR', 'kurt_DMSNR', 'skew_DMSNR']].values
y = data['target_class'].values

X = QuantileTransformer(output_distribution='normal').fit_transform(X)

# print('Features shape: {}'.format(X.shape))
# print('Label shape   : {}'.format(y.shape))

# In[None]

# models = [log_mod, svc_mod, ada_mod, gbc_mod, rfc_mod, mlp_mod]
# for name, mod in zip(indx_estimators, models):
#     mean, std = cv_score(mod, X, y, 10)
#     results.loc[name,'roc_auc_mean'] = mean
#     results.loc[name, 'roc_auc_std'] = std
    
# results

# F# e# a# t# u# r# e#  # I# m# p# o# r# t# a# n# c# e# s

# In[None]

# rf = RandomForestClassifier()
# rf.fit(data[data.columns[:-1]].values, data['target_class'].values)

# feature_import = pd.Series(rf.feature_importances_, index=data.columns[:-1]).sort_values(ascending=False)
# feature_import

# fig = plt.figure(figsize=(18, 8))
# sns.barplot(x=feature_import, y=feature_import.index)
# plt.title('Feature importances')
# plt.xlabel('Score')
# plt.show()

# In[None]

from sklearn.model_selection import GridSearchCV, learning_curve
from sklearn import metrics

# In[None]

# model comparison dataframe on test data
# index_cols = ['LogisticRegression', 'SVC', 'AdaBoostClassifier', 'GradientBoosting', 'RandomForestClassifier', 'MPLClassifier']
# colnames =['roc_auc', 'accuracy', 'precision', 'recall']
# results_final = pd.DataFrame(columns=colnames, index=index_cols)

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7752056.npy", { "accuracy_score": score })

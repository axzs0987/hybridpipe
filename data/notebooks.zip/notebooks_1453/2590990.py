import pandas as pd
# <# a#  # i# d#  # =#  # '# B# a# s# i# c# s# '# ># 1# .# B# a# s# i# c# s# <# /# a# ># <# b# r# >

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# <# a#  # i# d#  # =#  # '# ## L# o# a# d# D# a# t# a# '# ># 1# .#  # a# .#  # L# o# a# d#  # D# a# t# a# <# /# a# ># <# b# r# >

# In[None]

#read the data

# In[None]

input_data = pd.read_csv('../input/bank.csv')

# In[None]

print(input_data.shape)

# In[None]

import matplotlib.pyplot as plt

# In[None]

input_data['deposit_y_n'] = input_data['deposit'].map({'yes':1, 'no':0})

# In[None]

#we define the input and output variables
output_var = 'deposit_y_n'

# In[None]

#lets use only the numeric cols for input vars
input_vars = [col for col in input_data.columns if input_data[col].dtype != 'object']

# In[None]

#the list of input vars also has our output var; lets remove it
input_vars.remove(output_var)

# In[None]

#before we build any models, we need to have a test set to check the goodness of our models

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(input_data[input_vars], input_data[output_var], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_val)
score = accuracy_score(y_val, y_pred)
import numpy as np
np.save("prenotebook_res/2590990.npy", { "accuracy_score": score })

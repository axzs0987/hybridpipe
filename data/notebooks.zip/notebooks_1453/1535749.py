import pandas as pd
# A# n# a# l# y# s# i# s#  # o# f#  # [# T# e# l# c# o# '# s# ]# (# h# t# t# p# :# /# /# t# e# l# c# o# .# c# o# m# .# b# r# /# )#  # c# u# s# t# o# m# e# r#  # d# a# t# a# b# a# s# e# ,#  # w# i# t# h#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # t# h# e#  # a# t# t# r# i# b# u# t# e# s#  # o# f#  # i# t# s#  # c# u# s# t# o# m# e# r# s# .# 
# 
# T# h# e#  # i# n# t# e# n# t# i# o# n#  # i# s#  # t# o#  # p# r# e# d# i# c# t#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # g# r# e# a# t# e# r#  # p# o# t# e# n# t# i# a# l#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .# 
# 
# P# l# e# a# s# e# ,#  # i# f#  # y# o# u#  # l# i# k# e#  # t# h# a# t#  # K# e# r# n# e# l# ,#  # l# e# t#  # m# e#  # k# n# o# w# ,#  # l# e# a# v# i# n# g#  # y# o# u# r#  # u# p# v# o# t# e# ,#  # i#  # w# o# u# l# d#  # a# p# p# r# e# c# i# a# t# e#  # t# h# a# t#  # s# o#  # m# u# c# h#  # !# 


# In[None]

# importanto as bibliotecas

# Manipulação dos dados
import pandas as pd  

# Para uso de matrizes e arrays
import numpy as np  

# Visualização 
import matplotlib.pyplot as plt
import seaborn as sns

# Estatística
import statsmodels as sm

df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

df.head()

# In[None]

df.info()

# ## ##  # C# l# e# a# n#  # a# n# d#  # T# r# a# n# s# f# o# r# m#  # D# a# t# a# !# 
# 
# T# h# e#  # d# a# t# a# s# e# t#  # h# a# s#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .# 
# 
# W# e#  # h# a# v# e#  # m# o# r# e#  # t# h# a# n#  # 7# 0# 0# 0#  # r# o# w# s#  # a# n# d#  # 2# 1#  # a# t# t# r# i# b# u# t# e# s#  # (# c# o# l# u# m# n# s# )# 
# 
# S# o# m# e#  # d# a# t# a#  # t# h# a# t#  # s# h# o# u# l# d#  # b# e#  # c# a# t# e# g# o# r# i# c# a# l#  # a# r# e#  # s# a# v# e# d#  # a# s#  # n# u# m# b# e# r# .#  # L# e# t# '# s#  # f# i# x#  # t# h# i# s# .

# *# *# *# S# e# n# i# o# r# C# i# t# z# e# n# *# *# *

# In[None]

# SeniorCitizen

df['SeniorCitizen'] = df.SeniorCitizen.astype('object')

# In[None]

df.info()

# D# o# n# e#  # !#  # N# o# w#  # t# h# e#  # S# e# n# i# o# r# C# i# t# i# z# e# n#  # c# o# l# u# m# n# ,#  # w# h# i# c# h#  # i# n# d# i# c# a# t# e# s#  # w# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # i# s#  # e# l# d# e# r# l# y#  # o# r#  # n# o# t# ,#  # t# h# r# o# u# g# h#  # a#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e#  # (# 0#  # a# n# d#  # 1# )# ,#  # i# s#  # p# r# o# p# e# r# l# y#  # s# a# v# e# d#  # a# s#  # a#  # q# u# a# l# i# t# a# t# i# v# e#  # v# a# r# i# a# b# l# e# .# 
# 
# W# e#  # n# e# e# d#  # t# o#  # c# h# a# n# g# e#  # t# h# e#  # c# o# l# u# m# n#  # *# *# *#  # T# o# t# a# l# C# h# a# r# g# e# s#  # *# *# *#  # t# o#  # n# u# m# e# r# i# c# a# l#  # a# s#  # i# t#  # r# e# f# e# r# s#  # t# o#  # t# h# e#  # t# o# t# a# l#  # a# m# o# u# n# t#  # o# f#  # r# e# v# e# n# u# e#  # g# e# n# e# r# a# t# e# d#  # b# y#  # t# h# e#  # c# l# i# e# n# t# .#  # I# '# l# l#  # d# o#  # t# h# i# s#  # u# s# i# n# g#  # t# h# e#  # _# t# o# _# n# u# m# e# r# i# c#  # (# )#  # _#  # f# u# n# c# t# i# o# n#  # o# f#  # p# a# n# d# a# s# .# 
# 
# T# h# e#  # _# e# r# r# o# r# s#  # =#  # '# c# o# e# r# c# e# '# _#  # p# a# r# a# m# e# t# e# r#  # t# u# r# n# s#  # t# h# e#  # r# e# c# o# r# d# s#  # i# n# t# o#  # w# h# i# c# h#  # t# h# e#  # c# o# n# v# e# r# s# i# o# n#  # c# o# u# l# d#  # n# o# t#  # b# e#  # c# o# n# v# e# r# t# e# d#  # t# o#  # v# a# l# u# e# s#  # ​# ​# o# f#  # t# y# p# e#  # N# a# N# .

# In[None]

df.TotalCharges = pd.to_numeric(df.TotalCharges, errors = 'coerce')

df.TotalCharges.describe()

# In[None]

df.info()

# T# h# e#  # c# o# n# v# e# r# s# i# o# n#  # g# e# n# e# r# a# t# e# d#  # 1# 1#  # n# u# l# l#  # v# a# l# u# e# s# ,#  # w# e#  # w# i# l# l#  # f# i# l# l#  # t# h# e# m#  # w# i# t# h#  # t# h# e#  # r# e# s# u# l# t#  # o# f#  # m# u# l# t# i# p# l# y# i# n# g#  # t# h# e#  # t# e# n# u# r# e#  # a# n# d#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s#  # c# o# l# u# m# n# s# .#  # S# i# n# c# e#  # t# h# e#  # f# i# r# s# t#  # r# e# p# r# e# s# e# n# t# s#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # m# o# n# t# h# s#  # t# h# a# t#  # t# h# e#  # c# u# s# t# o# m# e# r#  # w# a# s#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# ,#  # a# n# d#  # t# h# e#  # s# e# c# o# n# d#  # i# n# d# i# c# a# t# e# s#  # t# h# e#  # a# m# o# u# n# t#  # p# a# i# d#  # p# e# r#  # m# o# n# t# h# .

# In[None]

df.TotalCharges.isnull().sum()

# In[None]

df.TotalCharges.fillna(value = df.tenure *  df.MonthlyCharges, inplace = True)

# In[None]

df.TotalCharges.isnull().sum()

# P# r# o# b# l# e# m#  # s# o# l# v# e# d#  # !# 
# 
# N# o# w#  # t# h# a# t#  # a# l# l#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # o# k# ,#  # w# e#  # c# a# n#  # s# t# a# r# t#  # e# x# p# l# o# r# i# n# g#  # t# h# e#  # d# a# t# a# .#  # L# e# t# '# s#  # t# r# y#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # w# h# i# c# h#  # c# u# s# t# o# m# e# r# s#  # s# p# e# n# d#  # m# o# r# e# ,#  # w# h# i# c# h#  # o# n# e# s#  # u# s# u# a# l# l# y#  # s# t# a# y#  # l# o# n# g# e# r#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # a# m# o# n# g#  # o# t# h# e# r#  # i# n# f# o# r# m# a# t# i# o# n#  # t# h# a# t#  # m# a# y#  # b# e#  # i# n# t# e# r# e# s# t# i# n# g#  # a# n# d#  # l# e# a# d#  # u# s#  # t# o#  # s# o# m# e#  # i# n# s# i# n# g# h# t# s# .# 
# 
# L# e# t# '# s#  # s# t# a# r# t#  # b# y#  # o# b# s# e# r# v# i# n# g#  # a#  # s# t# a# t# i# s# t# i# c# a# l#  # s# u# m# m# a# r# y#  # o# f#  # t# h# e#  # n# u# m# e# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# ,#  # w# h# i# c# h#  # a# r# e# :# 
# 
# *#  # t# e# n# u# r# e# :#  # P# e# r# i# o# d#  # i# n#  # m# o# n# t# h# s#  # t# h# a# t#  # c# u# s# t# o# m# e# r# s#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# 
# *#  # M# o# n# t# h# l# y# C# h# a# r# g# e# :#  # V# a# l# u# e#  # o# f#  # t# h# e#  # m# o# n# t# h# l# y#  # p# a# y# m# e# n# t#  # p# a# i# d#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r# 
# *#  # T# o# t# a# l# C# h# a# r# g# e# s# :#  # T# o# t# a# l#  # a# m# o# u# n# t#  # p# a# i# d#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r# 
# 
# ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # A# n# a# l# y# s# i# s

# In[None]

df.describe().round()

# *#  # H# a# l# f#  # o# f#  # t# h# e#  # c# l# i# e# n# t# s#  # r# e# m# a# i# n#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # f# o# r#  # m# o# r# e#  # t# h# a# n#  # 2# 9#  # m# o# n# t# h# s#  # (# j# u# s# t#  # o# v# e# r#  # t# w# o#  # y# e# a# r# s# )# ;# 
# *#  # T# h# e#  # a# v# e# r# a# g# e#  # a# m# o# u# n# t#  # p# e# r#  # m# o# n# t# h#  # $#  # 3# 0# ;# 
# *#  # T# h# e#  # a# v# e# r# a# g# e#  # t# o# t# a# l#  # r# e# v# e# n# u# e#  # g# e# n# e# r# a# t# e# d#  # p# e# r#  # c# u# s# t# o# m# e# r#  # i# s#  # 2# 2# 8# 0# .# 
# 
# 
# *# *# *#  # L# e# t# '# s#  # l# o# o# k#  # a# t#  # h# o# w#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # b# e# t# w# e# e# n#  # t# h# e# s# e#  # v# a# r# i# a# b# l# e# s#  # o# c# c# u# r# .# *# *# *

# In[None]

numerics = df[['tenure','MonthlyCharges', 'TotalCharges', 'Churn']]

plt.figure(figsize = (8,8))

sns.regplot(x = 'tenure', y = 'TotalCharges', data = numerics)

plt.title('Relationship between loyalty months and total revenue')

# In[None]

plt.figure(figsize = (8,8))
plt.title('Relationship between monthly fee and total revenue')
ax = sns.regplot(x = 'MonthlyCharges', y = 'TotalCharges', data = numerics)

# In[None]

plt.figure(figsize = (15,10))
sns.pairplot(numerics)

# In[None]

plt.figure(figsize = (15,10))

sns.boxplot(x = 'tenure', y = 'TotalCharges', data = df)

plt.title('Box Plot of Total Payments X Months of Loyalty')

# In[None]

plt.figure(figsize = (15,10))
sns.countplot(df['tenure'])

# A# b# o# v# e#  # w# e#  # h# a# v# e#  # j# u# s# t#  # e# x# p# l# o# r# e# d#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p# s#  # b# e# t# w# e# e# n#  # t# h# e#  # t# i# m# e#  # o# f#  # h# o# m# e#  # a# n# d#  # t# h# e#  # t# o# t# a# l#  # v# a# l# u# e#  # o# f#  # e# x# p# e# n# s# e# s# .#  # T# h# e# y#  # a# r# e#  # l# i# n# e# a# r#  # a# s#  # y# o# u#  # w# o# u# l# d#  # e# x# p# e# c# t# .#  # T# h# a# t#  # i# s# ,#  # t# h# e#  # l# o# n# g# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # s# t# a# y# s#  # w# i# t# h#  # u# s# ,#  # t# h# e#  # g# r# e# a# t# e# r#  # y# o# u# r#  # t# o# t# a# l#  # s# p# e# n# d# .# 
# 
# W# e#  # a# l# s# o#  # o# b# s# e# r# v# e# d#  # t# h# e#  # l# i# n# e# a# r#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # t# h# e#  # m# o# n# t# h# l# y#  # v# a# l# u# e#  # a# n# d#  # t# o# t# a# l#  # r# e# v# e# n# u# e# .#  # C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # v# a# l# u# e# ,#  # r# e# p# r# e# s# e# n# t#  # h# i# g# h# e# r#  # r# e# v# e# n# u# e# .# 
# 
# W# e#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # n# o#  # r# e# l# a# t# i# o# n#  # t# o#  # t# h# e#  # m# o# n# t# h# s#  # o# f#  # t# h# e#  # h# o# u# s# e# ,#  # a# n# d#  # t# h# e#  # i# n# c# r# e# a# s# e#  # o# f#  # t# h# e#  # m# o# n# t# h# l# y#  # p# a# y# m# e# n# t# s# .#  # T# o#  # m# y#  # c# r# e# d# i# t# ,#  # m# a# n# y#  # c# l# i# e# n# t# s#  # r# e# m# a# i# n#  # f# o# r#  # a#  # l# o# n# g#  # t# i# m# e#  # w# i# t# h# o# u# t#  # h# i# r# i# n# g#  # n# e# w#  # s# e# r# v# i# c# e# s# ;#  # i# n#  # c# o# n# t# r# a# s# t# ,#  # s# o# m# e#  # a# l# r# e# a# d# y#  # c# o# m# e#  # w# i# t# h#  # m# o# r# e#  # e# x# p# e# n# s# i# v# e#  # p# l# a# n# s# .# 
# 
# A# n# d#  # t# h# r# o# u# g# h#  # b# o# x# b# l# o# t#  # w# e#  # h# a# v# e#  # s# e# e# n#  # t# h# a# t# ,#  # i# n#  # g# e# n# e# r# a# l# ,#  # t# h# e#  # D# a# t# a# s# e# t#  # d# o# e# s#  # n# o# t#  # h# a# v# e#  # o# u# t# l# i# e# r# s# .# 
# 
# 
# *# *# *# N# o# w#  # l# e# t# '# s#  # e# x# p# l# o# r# e#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# .#  # F# r# o# m#  # h# e# r# e# ,#  # w# e# '# l# l#  # t# a# k# e#  # i# n# t# o#  # a# c# c# o# u# n# t#  # t# h# e#  # v# a# r# i# a# b# l# e#  # '# C# h# u# r# n# '#  # i# n#  # a# l# l#  # o# u# r#  # v# i# e# w# s# .#  # T# h# i# s#  # v# a# r# i# a# b# l# e#  # i# n# d# i# c# a# t# e# s#  # w# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y#  # o# r#  # n# o# t# .#  # O# u# r#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .# *# *# *

# In[None]


df.describe(include = 'object')

# Q# u# i# c# k# l# y# ,#  # i# n#  # t# h# i# s#  # p# i# c# t# u# r# e#  # w# e#  # c# a# n#  # a# l# r# e# a# d# y#  # o# b# s# e# r# v# e# :# 
# 
# *#  # M# o# s# t#  # c# u# s# t# o# m# e# r# s#  # a# r# e#  # n# o# t#  # S# e# n# i# o# r# ;# 
# *#  # T# h# e#  # m# o# s# t#  # p# o# p# u# l# a# r#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # i# s#  # f# i# b# e# r#  # o# p# t# i# c# s# ;# 
# *#  # M# o# s# t#  # c# u# s# t# o# m# e# r# s#  # p# r# e# f# e# r#  # n# o# t#  # t# o#  # r# e# c# e# i# v# e#  # p# r# i# n# t# e# d#  # a# c# c# o# u# n# t# s# ;# 
# *#  # T# h# e#  # m# o# s# t#  # p# o# p# u# l# a# r#  # f# o# r# m#  # o# f#  # p# a# y# m# e# n# t#  # i# s#  # t# h# e#  # e# l# e# c# t# r# o# n# i# c#  # p# a# y# m# e# n# t# 
# 
# 


# *# *# *# S# e# n# i# o# r# C# i# t# i# z# e# n# *# *# *

# D# o# e# s#  # t# h# e#  # a# g# e#  # g# r# o# u# p#  # i# n# f# l# u# e# n# c# e#  # t# h# e#  # e# s# c# a# p# e#  # o# f#  # c# u# s# t# o# m# e# r# s# ?

# In[None]

pd.crosstab(df.Churn, df.SeniorCitizen,
            margins = True)

# In[None]

# Should make a function for that..
print('The percentage of elderly people who left the company:{}%'.format(476/1142*100))
print('The non-elderly population is:{}%'.format(1393/5901*100)) 

# In[None]

plt.figure(figsize = (8,8))
sns.set(style = 'whitegrid')

sns.countplot(df.SeniorCitizen, hue = df.Churn )

# P# r# o# p# o# r# t# i# o# n# a# l# l# y#  # s# p# e# a# k# i# n# g# ,#  # t# h# e#  # v# o# l# u# m# e#  # o# f#  # o# l# d# e# r#  # p# e# o# p# l# e#  # l# e# a# v# i# n# g#  # t# h# e#  # c# o# m# p# a# n# y#  # i# s#  # m# u# c# h#  # h# i# g# h# e# r#  # t# h# a# n#  # t# h# e#  # v# o# l# u# m# e#  # o# f#  # n# o# n# -# e# l# d# e# r# l# y# .# 
# 
# D# o# e# s#  # t# h# i# s#  # i# n# d# i# c# a# t# e#  # a#  # d# e# p# e# n# d# e# n# c# y#  # r# e# l# a# t# i# o# n# s# h# i# p# ?#  # I# s#  # i# t#  # w# o# r# t# h#  # c# o# n# s# i# d# e# r# i# n# g#  # t# o#  # i# n# v# e# s# t# i# g# a# t# e#  # t# h# i# s#  # r# e# l# a# t# i# o# n# s# h# i# p#  # m# o# r# e#  # c# l# o# s# e# l# y# ?#  # O# r#  # w# a# s#  # i# t#  # m# e# r# e#  # c# h# a# n# c# e# ?#  # A#  # c# h# i# -# s# q# u# a# r# e#  # t# e# s# t#  # c# a# n#  # h# e# l# p#  # u# s#  # f# i# n# d#  # o# u# t#  # i# f#  # t# h# i# s#  # a# s# s# i# g# n# m# e# n# t#  # i# s#  # s# t# a# t# i# s# t# i# c# a# l# l# y#  # s# i# g# n# i# f# i# c# a# n# t# .# 
# 
# J# u# s# t#  # f# o# r#  # c# u# r# i# o# s# i# t# y# ,#  # w# h# a# t#  # i# s#  # t# h# e#  # m# o# n# t# h# l# y#  # a# v# e# r# a# g# e#  # b# e# t# w# e# e# n#  # y# o# u# n# g#  # a# n# d#  # o# l# d# ?

# In[None]

mens_media_idoso = df[df['SeniorCitizen'] == 1]
mens_media_idoso = mens_media_idoso.MonthlyCharges.mean()
mens_media_idoso

n_idoso_media_mes = df[df['SeniorCitizen'] == 0]
n_idoso_media_mes = n_idoso_media_mes.MonthlyCharges.mean()

print('The average monthly expenditure for the elderly is :{}'.format(mens_media_idoso))
print('The average monthly expenditure for non-elderly persons is :{}'.format(n_idoso_media_mes))

# In[None]

# Checking

media_mes_idade = df.groupby('SeniorCitizen').mean() 
media_mes_idade.round()

# In[None]

plt.figure(figsize = (10,8))

sns.set(style = 'whitegrid')
sns.boxplot(x = df.SeniorCitizen, y = df.TotalCharges, hue = df.Churn)

plt.title('Total Revenue by Seniors and Non-Seniors')

# In[None]

df.SeniorCitizen.value_counts(normalize = True)

# B# a# s# e# d#  # o# n#  # t# h# e#  # a# b# o# v# e#  # c# o# m# p# a# r# i# s# o# n# s# :# 
# 
# *#  # A# l# t# h# o# u# g# h#  # t# h# e# y#  # r# e# p# r# e# s# e# n# t#  # o# n# l# y#  # 1# 6# %#  # o# f#  # c# l# i# e# n# t# s# ,#  # t# h# e#  # e# l# d# e# r# l# y#  # s# p# e# n# d#  # m# o# r# e#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# :#  # I# t#  # h# a# s#  # a#  # m# o# n# t# h# l# y#  # a# v# e# r# a# g# e#  # h# i# g# h# e# r# ,#  # l# e# a# v# e#  # m# o# r# e#  # r# e# v# e# n# u# e#  # a# n# d#  # h# a# s#  # a#  # h# i# g# h# e# r#  # f# i# d# e# l# i# t# y#  # a# v# e# r# a# g# e# .#  # H# o# w# e# v# e# r# ,#  # a# s#  # w# e#  # h# a# v# e#  # s# e# e# n# ,#  # i# t#  # h# a# s#  # a#  # m# u# c# h#  # h# i# g# h# e# r#  # r# a# t# e#  # o# f#  # e# v# a# s# i# o# n#  # t# h# a# n#  # t# h# e#  # y# o# u# n# g#  # p# u# b# l# i# c# .#  # T# h# e#  # g# r# a# p# h# i# c#  # m# a# k# e# s#  # t# h# i# s#  # e# v# e# n#  # c# l# e# a# r# e# r# .# 
# 
# T# h# e# s# e#  # n# u# m# b# e# r# s#  # m# a# k# e#  # s# e# n# s# e# .#  # O# l# d# e# r#  # p# e# o# p# l# e#  # s# p# e# n# d#  # m# o# r# e#  # t# i# m# e#  # a# t#  # h# o# m# e# ,#  # b# e# c# a# u# s# e#  # t# h# e# y#  # a# r# e#  # r# e# t# i# r# e# d#  # o# r#  # t# a# k# i# n# g#  # l# i# g# h# t# e# r#  # l# i# v# e# s# ,#  # s# o#  # t# h# e# y#  # c# o# n# s# u# m# e#  # m# o# r# e#  # t# e# l# e# v# i# s# i# o# n# ,#  # w# h# i# c# h#  # l# e# a# d# s#  # t# h# e# m#  # t# o#  # s# i# g# n#  # m# o# r# e#  # c# o# m# p# l# e# t# e#  # a# n# d#  # c# o# n# s# e# q# u# e# n# t# l# y#  # m# o# r# e#  # e# x# p# e# n# s# i# v# e#  # p# a# c# k# a# g# e# s# .# 
# 
# B# a# s# e# d#  # o# n#  # t# h# e# s# e#  # d# a# t# a# ,#  # I#  # w# o# u# l# d#  # r# e# c# o# m# m# e# n# d#  # a#  # d# e# e# p# e# r#  # a# n# a# l# y# s# i# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # r# e# a# s# o# n#  # f# o# r#  # t# h# i# s#  # e# v# a# s# i# o# n#  # r# a# t# e#  # a# n# d#  # p# r# o# p# o# s# e#  # a# c# t# i# o# n# s#  # t# o#  # i# n# c# r# e# a# s# e#  # r# e# t# e# n# t# i# o# n#  # o# f#  # t# h# i# s#  # p# u# b# l# i# c#  # a# n# d#  # t# o#  # a# t# t# r# a# c# t#  # t# h# e# m# .# 
# 
# T# h# i# s#  # a# n# a# l# y# s# i# s#  # h# a# s#  # a# l# r# e# a# d# y#  # s# h# o# w# n#  # u# s#  # s# o# m# e#  # v# e# r# y#  # r# e# l# e# v# a# n# t#  # i# n# s# i# g# h# t# s#  # a# n# d#  # t# h# i# s#  # c# o# n# s# i# d# e# r# i# n# g#  # o# n# l# y#  # t# h# e#  # v# a# r# i# a# b# l# e#  # r# e# l# a# t# i# v# e#  # t# o#  # a# g# e#  # .# .# .# .# 
# 
# 
# ## ## ##  # L# e# t# s#  # i# n# v# e# s# t# i# g# a# t# e#  # t# h# e#  # g# e# n# d# e# r#  # v# a# r# i# a# b# l# e

# In[None]

plt.figure(figsize = (8,8))
sns.set(style = 'whitegrid')
sns.countplot(df.gender, hue = df.Churn)

# In[None]

receita_gender = df.groupby(by = 'gender')['TotalCharges', 'MonthlyCharges'].mean().round()
receita_gender

# In[None]

df.groupby(by = 'gender')['tenure'].mean().round()

# *# *# *# T# h# e# r# e#  # i# s#  # n# o#  # b# e# h# a# v# i# o# r#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # w# o# m# e# n#  # a# n# d#  # m# e# n# .# *# *# *# 
# 
# ## ## ##  # L# e# t# s#  # i# n# v# e# s# t# i# g# a# t# e#  # t# h# e#  # P# a# r# t# n# e# r#  # v# a# r# i# a# b# l# e# ,#  # t# h# a# t#  # i# n# d# i# c# a# t# e# s#  # i# f#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # a# n# y#  # r# e# l# a# t# i# o# n# s# h# i# p#  # p# a# r# t# n# e# r# .

# In[None]

plt.figure(figsize = (8,8))
sns.set(style = 'whitegrid')
sns.countplot(df.Partner, hue = df.Churn)

# In[None]

df.groupby('Partner')['TotalCharges', 'MonthlyCharges', 'tenure'].mean().plot(kind = 'bar', stacked = True, 
                                                                             figsize = (8,8))

# T# h# e# r# e# s#  # i# s#  # g# r# e# a# t#  # d# i# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # p# e# o# p# l# e#  # w# i# t# h#  # p# a# r# t# n# e# r# s#  # e#  # w# i# t# h# o# u# t#  # i# t# .#  # P# e# o# p# l# e#  # w# i# t# h#  # p# a# r# t# n# e# r# (# m# a# r# r# i# e# d#  # o# n# e# s# )#  # s# p# e# n# t#  # m# u# c# h#  # m# o# r# e#  # m# o# n# e# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # a# n# d#  # s# t# a# y#  # m# u# c# h#  # m# o# r# e#  # t# i# m# e# .#  # T# h# a# t#  # m# a# y#  # b# e#  # c# a# u# s# e#  # t# h# e# y#  # h# a# s#  # c# h# i# l# d# r# e# n#  # a# n# d#  # h# a# s#  # m# o# r# e#  # c# o# m# p# l# e# t# e#  # p# a# c# k# s# .# 
# 
# L# e# t# '# s#  # c# o# n# f# i# r# m#  # t# h# a# t#  # p# o# s# s# i# b# i# l# i# t# y# !

# In[None]

pd.crosstab(df.Partner, df.Dependents).plot(kind = 'bar', stacked = True, figsize = (8,8))

# T# h# a# t# '# s#  # r# i# g# h# t# ,#  # p# e# o# p# l# e#  # w# h# o#  # h# a# s#  # p# a# r# t# n# e# r# s# ,#  # h# a# s#  # m# o# r# e#  # d# e# p# e# n# d# e# n# t# s# (# c# h# i# l# d# r# e# n# )#  # t# h# a# n#  # t# h# e#  # s# i# n# g# l# e#  # o# n# e# s# .

# In[None]

plt.figure(figsize = (15,10))
sns.countplot(df['tenure'], hue = df.Partner)

# T# h# a#  # a# b# o# v# e#  # c# h# a# r# t# ,#  # c# o# n# f# i# r# m#  # t# h# a# t#  # p# e# o# p# l# e#  # w# h# o#  # h# a# s#  # p# a# r# t# n# e# r#  # s# t# a# y#  # m# o# r# e#  # t# i# m# e#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# .#  # 
# 
# S# o# ,#  # t# h# a# t# '# s#  # t# h# e#  # i# n# s# g# h# t# s#  # o# f#  # t# h# i# s#  # a# n# a# l# y# s# i# s# :#  # 
# 
# *#  # P# e# o# p# l# e#  # w# i# t# h#  # p# a# r# t# n# e# r#  # a# r# e#  # v# e# r# y#  # l# u# c# r# a# t# i# v# e#  # t# o#  # t# h# e#  # c# o# m# p# a# n# y# ,#  # c# a# u# s# e#  # t# h# e# y#  # s# t# a# y#  # m# o# r# e#  # t# i# m# e#  # a# n# d#  # s# p# e# n# t#  # m# o# r# e#  # m# o# n# e# y# .#  # 
# 
# 
# *# *# *# O# K# ,#  # i#  # t# h# i# n# k#  # t# h# a# t#  # w# e#  # g# o# t#  # s# o# m# e#  # g# o# o# d#  # i# n# s# i# g# h# t# s#  # e# x# p# l# o# r# i# n# g#  # t# h# e#  # d# e# m# o# g# r# a# p# h# i# c# s#  # a# t# r# i# b# u# t# e# s#  # o# f#  # o# u# r#  # c# l# i# e# n# t# s# .#  # L# e# t# s#  # t# a# k# e#  # a#  # l# o# o# k#  # o# n#  # o# u# r#  # p# r# o# d# u# c# t# s#  # !#  # W# h# i# c# h#  # o# n# e#  # i# s#  # t# h# e#  # m# o# s# t#  # l# u# c# r# a# t# i# v# e#  # ?#  # I# s#  # t# h# a# t#  # t# h# e#  # s# a# m# e#  # w# i# t# h#  # t# h# e#  # h# i# g# u# e# r#  # f# i# d# e# l# i# t# y#  # ?# *# *# *

# In[None]

df.InternetService.value_counts(normalize = True)

# 2# 1# %#  # o# f#  # c# l# i# e# n# t# s#  # d# o# n# '# t#  # u# s# e#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# s# .#  # W# o# u# l# d#  # b# e#  # a#  # n# i# c# e#  # i# d# e# a#  # e# x# p# l# o# r# e#  # s# o# m# e#  # w# a# y# s#  # t# o#  # m# a# k# i# n# g#  # t# h# e# y#  # u# s# e#  # o# u# r#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# s# .#  # M# a# y# b# e#  # u# s# i# n# g#  # s# o# m# e#  # c# l# u# s# t# e# r# i# n# g#  # a# l# g# o# r# i# t# h# m#  # t# o#  # d# i# s# c# o# v# e# r#  # e# s# p# e# c# i# f# i# c#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # t# o#  # u# s# e#  # t# o#  # o# u# r#  # f# a# v# o# r# .# .# .# .# 
# 
# F# r# o# m#  # h# e# r# e#  # a#  # t# h# i# n# k#  # t# h# a# t#  # i# s#  # t# i# m# e#  # t# o#  # s# l# i# c# e#  # o# u# r#  # d# a# t# a# s# e# t# ,#  # l# e# t# s#  # f# o# c# u# s#  # o# n#  # c# l# i# e# n# t# s#  # t# h# a# t#  # u# s# e#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# s# ,#  # b# u# t#  # b# e# f# o# r# e#  # t# h# a# t# ,#  # l# e# t# s#  # t# a# k# e#  # a#  # c# l# o# s# e# r#  # l# o# o# k# :#  

# In[None]

pd.crosstab(df.InternetService, df.PhoneService, margins = True)

# C# l# i# e# n# t# s#  # t# h# a# t#  # d# o# n# t#  # u# s# e#  # p# h# o# n# e#  # s# e# r# v# i# c# e# s# ,#  # u# s# e#  # t# h# e#  # D# S# L#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# .#  # W# i# c# h#  # m# e# a# n# s#  # t# h# a# t#  # F# i# b# e# r#  # O# p# t# i# c#  # i# s#  # a# v# a# l# i# a# b# l# e#  # o# n# l# y#  # f# o# r#  # t# h# o# s# e#  # w# h# o#  # h# a# s#  # p# h# o# n# e#  # s# e# r# v# i# c# e# s# .# 
# 
# F# o# r#  # t# h# o# s# e#  # W# h# o#  # u# s# e#  # p# h# o# n# e#  # s# e# r# v# i# c# e# ,#  # D# S# L#  # s# t# i# l# l#  # a# n#  # o# p# t# i# o# n# .# 
# 
# W# e#  # a# r# e#  # s# t# a# r# t# i# n# g#  # t# o#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # c# o# m# p# a# n# y# '# s#  # p# r# o# d# u# c# t#  # s# t# r# a# t# e# g# y# .# .# .

# In[None]

plt.figure(figsize = (15,5))
sns.countplot(df.InternetService, hue = df.Churn)

# T# h# e# r# e#  # i# s#  # a#  # h# u# g# e#  # c# h# u# r# n#  # t# e# n# d# e# n# c# y#  # i# n#  # F# i# b# e# r#  # O# p# t# i# c#  # S# e# r# v# i# c# e# s# .#  # T# h# a# t#  # m# i# g# h# t# y#  # s# h# o# w#  # a#  # g# r# e# a# t#  # i# n# s# a# t# i# s# f# c# a# t# i# o# n#  # w# i# t# h#  # t# h# i# s#  # s# e# r# v# i# c# e# .#  # 
# 


# In[None]

df.groupby('InternetService')['TotalCharges'].mean()

#  # *# *# *# L# e# t# s#  # s# t# a# r#  # t# h# e#  # m# o# d# e# l# i# n# g#  # p# h# a# s# e# *# *# *# 
# 
# F# i# r# s# t#  # o# f#  # a# l# l# ,#  #  # i# '# l# l#  # t# r# a# n# s# f# o# r# m#  # t# h# e#  # c# o# l# u# m# n# s#  # s# o#  # t# h# e#  # m# o# d# e# l#  # w# i# l# l#  # b# e#  # a# b# l# e#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # o# u# r#  # d# a# t# a#  # !#  #  

# In[None]

df.head()

# *# *# *# G# e# n# d# e# r# *# *# *

# A# s#  # w# e#  # s# e# e#  # a# b# o# v# e# ,#  # t# h# e#  # g# e# n# d# e# r#  # d# o# e# s#  # n# o# t#  # h# a# v# e#  # a# n# y#  # g# r# e# a# t#  # d# i# f# f# e# r# e# n# c# e# .#  # S# o#  # i#  # t# h# i# n# k#  # t# h# a# t#  # t# h# i# s#  # v# a# r# i# a# b# l# e#  # i# s#  # n# o# t#  # i# m# p# o# r# t# a# n# t#  # f# o# r#  # t# h# e#  # m# o# d# e# l# .#  # L# e# t# '# s#  # d# r# o# p#  # i# t# !

# In[None]

df.drop(['customerID', 'gender'], axis = 1, inplace = True)

# In[None]

df_model = df

df_model.head()

# In[None]

df_model.columns

# In[None]

## Here i forked some code from another Kernel

columns_to_convert = ['Partner', 'Dependents','PhoneService','OnlineSecurity' ,
                      'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies','PaperlessBilling',
                      'Churn']
                      
                      
    
    
for item in columns_to_convert:
    df_model[item].replace(to_replace=['Yes', 'No'], value= [1,0], inplace = True)
df_model.head()

# In[None]

# adjusting the column Multiple Lines

df_model.MultipleLines = df_model.MultipleLines.replace(to_replace= 'No phone service', value = 'No')
df_model.MultipleLines = df_model.MultipleLines.replace(to_replace= ['Yes', 'No'], value = [1,0])
df_model.MultipleLines.value_counts()

# In[None]

pd.get_dummies(df_model, columns = ['InternetService', 'Contract', 'PaymentMethod'], drop_first = True)

# In[None]

df_model.OnlineSecurity = df_model.OnlineSecurity.replace(to_replace= 'No internet service', value = 0)
df_model.OnlineBackup = df_model.OnlineBackup.replace(to_replace= 'No internet service', value = 0)
df_model.DeviceProtection = df_model.DeviceProtection.replace(to_replace= 'No internet service', value = 0)
df_model.TechSupport = df_model.TechSupport.replace(to_replace= 'No internet service', value = 0)
df_model.StreamingTV = df_model.StreamingTV.replace(to_replace= 'No internet service', value = 0)
df_model.StreamingMovies = df_model.StreamingMovies.replace(to_replace= 'No internet service', value = 0)


# In[None]

df_model.head(10)

# In[None]

df_model2 = pd.get_dummies(df_model, columns = ['InternetService', 'Contract', 'PaymentMethod'], drop_first = True)
df_model2.head(20)

# In[None]

from sklearn.model_selection import train_test_split

X = df_model2.drop('Churn',axis=1)
y = df_model2['Churn']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1535749.npy", { "accuracy_score": score })

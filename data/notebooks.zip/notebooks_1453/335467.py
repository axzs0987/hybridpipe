import pandas as pd
# *# *# A# d# u# l# t#  # S# a# l# a# r# y#  # I# n# c# o# m# e# .# *# *# 
#  # I# n#  # t# h# i# s#  # k# e# r# n# e# l#  # w# e#  # s# h# a# l# l#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a#  # a# n# d#  # m# a# k# e#  # p# r# e# d# i# c# t# i# o# n# s#  # i# f#  # a# n#  # a# d# u# l# t#  # e# a# r# n# s#  # m# o# r# e#  # t# h# a# n#  # 5# 0# K#  # p# e# r#  # y# e# a# r# .# 
# I# '# v# e#  # u# s# e# d#  # t# a# b# l# e# a# u#  # t# o#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a#  # u# s# i# n# g#  # d# a# t# a#  # v# i# z# .# 
# H# o# p# e#  # y# o# u#  # h# a# v# e#  # f# u# n# .

# In[None]

#Libraries Required
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns


# In[None]

data= pd.read_csv("../input/adult.csv")
df= pd.DataFrame(data)

# In[None]

data.head()


# W# e#  # d# o#  # h# a# v# e#  # s# o# m# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # h# e# r# e#  # c# o# d# e# d#  # w# i# t# h#  # *# *# '# ?# '# *# *

# In[None]

data.info()

# W# e# '# l# l#  # t# a# k# e#  # c# a# r# e#  # o# f#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # a#  # l# i# t# t# l# e#  # l# a# t# e# r# .

# In[None]

#Converting Categorical variables into Quantitative variables
print(set(data['occupation']))
data['occupation'] = data['occupation'].map({'?': 0, 'Farming-fishing': 1, 'Tech-support': 2, 
                                                       'Adm-clerical': 3, 'Handlers-cleaners': 4, 'Prof-specialty': 5,
                                                       'Machine-op-inspct': 6, 'Exec-managerial': 7, 
                                                       'Priv-house-serv': 8, 'Craft-repair': 9, 'Sales': 10, 
                                                       'Transport-moving': 11, 'Armed-Forces': 12, 'Other-service': 13, 
                                                       'Protective-serv': 14}).astype(int)



    

# In[None]

data['income'] = data['income'].map({'<=50K': 0, '>50K': 1}).astype(int)

# In[None]

data['sex'] = data['sex'].map({'Male': 0, 'Female': 1}).astype(int)

# In[None]

data['race'] = data['race'].map({'Black': 0, 'Asian-Pac-Islander': 1, 'Other': 2, 'White': 3, 
                                             'Amer-Indian-Eskimo': 4}).astype(int)

# In[None]

data['marital.status'] = data['marital.status'].map({'Married-spouse-absent': 0, 'Widowed': 1, 
                                                             'Married-civ-spouse': 2, 'Separated': 3, 'Divorced': 4, 
                                                             'Never-married': 5, 'Married-AF-spouse': 6}).astype(int)



# A# l# l#  # t# h# e#  # n# e# c# e# s# s# a# r# y#  # v# a# r# i# a# b# l# e# s#  # h# a# v# e#  # b# e# e# n#  # c# o# n# v# e# r# t# e# d# .#  # N# o# w#  # l# e# t# s#  # s# e# e#  # w# h# a# t#  # w# e#  # c# a# n#  # d# o#  # w# i# t# h#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .

# In[None]

df.occupation.replace(0, np.nan, inplace=True)

# In[None]

print(df.shape)
df=df.dropna()
print(df.shape)

# I# n#  # t# h# e#  # a# b# o# v# e#  # c# o# d# e#  # I#  # j# u# s# t#  # d# r# o# p# p# e# d#  # a# b# o# u# t#  # 1# 8# 0# 0#  # n# u# l# l#  # e# n# t# r# i# e# s#  # f# o# r#  # t# h# e#  # o# c# c# u# p# a# t# i# o# n#  # c# o# l# u# m# n# .

# In[None]

df.head(10)

# W# e# '# r# e#  # g# o# o# d#  # t# o#  # g# o# .

# L# e# t# s#  # n# o# w#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a#  # w# i# t# h#  # f# e# w#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s# .

# In[None]

hmap = df.corr()
plt.subplots(figsize=(12, 9))
sns.heatmap(hmap, vmax=.8,annot=True,cmap="BrBG", square=True);

# !# [# ]# (# h# t# t# p# s# :# /# /# i# m# a# g# e# .# i# b# b# .# c# o# /# i# o# Z# v# j# v# /# S# c# r# e# e# n# _# S# h# o# t# _# 2# 0# 1# 7# _# 0# 8# _# 1# 1# _# a# t# _# 1# 0# _# 3# 4# _# 4# 0# _# P# M# .# p# n# g# )# 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# i# m# a# g# e# .# i# b# b# .# c# o# /# e# o# k# q# H# F# /# S# c# r# e# e# n# _# S# h# o# t# _# 2# 0# 1# 7# _# 0# 8# _# 1# 1# _# a# t# _# 9# _# 0# 1# _# 5# 6# _# P# M# .# p# n# g# )# 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# p# r# e# v# i# e# w# .# i# b# b# .# c# o# /# j# t# g# 8# 4# v# /# S# c# r# e# e# n# _# S# h# o# t# _# 2# 0# 1# 7# _# 0# 8# _# 1# 1# _# a# t# _# 8# _# 5# 9# _# 2# 3# _# P# M# .# p# n# g# )# 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# i# m# a# g# e# .# i# b# b# .# c# o# /# d# A# A# C# W# a# /# S# c# r# e# e# n# _# S# h# o# t# _# 2# 0# 1# 7# _# 0# 8# _# 1# 1# _# a# t# _# 9# _# 0# 2# _# 1# 3# _# P# M# .# p# n# g# )# 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# i# m# a# g# e# .# i# b# b# .# c# o# /# e# b# U# v# j# v# /# S# c# r# e# e# n# _# S# h# o# t# _# 2# 0# 1# 7# _# 0# 8# _# 1# 1# _# a# t# _# 9# _# 0# 3# _# 3# 5# _# P# M# .# p# n# g# )

# *# *# I# n# f# e# r# e# n# c# e# s# :# *# *# 
# *#  # M# a# r# r# i# e# d#  # c# i# t# i# z# e# n# s#  # w# i# t# h#  # s# p# o# u# s# e#  # h# a# v# e#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # e# a# r# n# i# n# g#  # m# o# r# e#  # t# h# a# n#  # t# h# o# s# e#  # w# h# o# '# r# e#  # u# n# m# a# r# r# i# e# d# /# d# i# v# o# r# c# e# d# /# w# i# d# o# w# e# d# /# s# e# p# a# r# a# t# e# d# .# 
# *#  # M# a# l# e# s#  # o# n#  # a# n#  # a# v# e# r# a# g# e#  # m# a# k# e#  # e# a# r# n#  # m# o# r# e#  # t# h# a# n#  # f# e# m# a# l# e# s# .# 
# *#  # H# i# g# h# e# r#  # E# d# u# c# a# t# i# o# n#  # c# a# n#  # l# e# a# d#  # t# o#  # h# i# g# h# e# r#  # i# n# c# o# m# e#  # i# n#  # m# o# s# t#  # c# a# s# e# s# .# 
# *#  # A# s# i# a# n# -# P# a# c# i# f# i# c# -# I# s# l# a# n# d# e# r# s#  # a# n# d#  # w# h# i# t# e#  # a# r# e#  # t# w# o#  # r# a# c# e# s#  # t# h# a# t#  # h# a# v# e#  # t# h# e#  # h# i# g# h# e# s# t#  # a# v# e# r# a# g# e#  # i# n# c# o# m# e# .

# *# *# S# e# t# t# i# n# g#  # u# p#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l# .# *# *#  # L# e# t# s#  # s# t# a# r# t#  # w# i# t# h#  # *# *# D# e# c# i# s# s# i# o# n#  # T# r# e# e# s# .# *# *

# In[None]

#SETTING UP DECISSION TREES
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn import metrics


X=df[['education.num','age','hours.per.week']].values
y= df[['income']].values

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/335467.npy", { "accuracy_score": score })

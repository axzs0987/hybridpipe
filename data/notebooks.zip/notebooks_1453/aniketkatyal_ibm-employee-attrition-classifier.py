import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
df=pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')
df.head()
df.isnull().sum()
df.dtypes
correlation_df = df.corr()
employee_count_var = df["EmployeeCount"].var() 
standard_hours_var = df["StandardHours"].var() 
new_df = df.drop(["EmployeeCount","StandardHours"],axis = 1)
new_df.head()
correlation_new_df = new_df.corr()
correlation_new_df
#sns.set()
#f, ax = plt.subplots(figsize=(10, 8))
corr = new_df.corr()
#sns.heatmap(corr, mask=np.zeros_like(corr), cmap=sns.diverging_palette(220, 10, as_cmap=True),            square=True, ax=ax)
#plt.show()
df_numerical = new_df[['Age','DailyRate','DistanceFromHome','Education',                       'EnvironmentSatisfaction', 'HourlyRate',                                            'JobInvolvement', 'JobLevel','MonthlyRate',                       'JobSatisfaction',                       'RelationshipSatisfaction',                        'StockOptionLevel',                        'TrainingTimesLastYear','WorkLifeBalance']].copy()
df_numerical.head()
df_numerical = abs(df_numerical - df_numerical.mean())/df_numerical.std()  
df_numerical.head()
df_categorical = new_df[['Attrition', 'BusinessTravel','Department',                       'EducationField','Gender','JobRole',                       'MaritalStatus',                       'Over18', 'OverTime']].copy()
df_categorical.head()
df_categorical["Over18"].value_counts()
df_categorical = df_categorical.drop(["Over18"],axis = 1)
lbl = LabelEncoder()
lbl.fit(['Yes','No'])
df_categorical["Attrition"] = lbl.transform(df_categorical["Attrition"])
df_categorical.head()
df_categorical = pd.get_dummies(df_categorical)
df_categorical.head()
final_df = pd.concat([df_numerical,df_categorical], axis= 1)
final_df.head()
X = final_df.drop(['Attrition'],axis= 1)
y = final_df["Attrition"]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
lr = LogisticRegression(solver = 'liblinear',random_state = 0) 
#lr.fit(X_train,y_train)
#y_pred_lr = lr.predict(X_test)
#accuracy_score_lr = accuracy_score(y_pred_lr,y_test)
#accuracy_score_lr 
dtree = DecisionTreeClassifier(criterion='entropy',max_depth = 4,random_state = 0)
#dtree.fit(X_train,y_train)
#y_pred_dtree = dtree.predict(X_test)
#accuracy_score_dtree = accuracy_score(y_pred_dtree,y_test)
#accuracy_score_dtree
rf = RandomForestClassifier(criterion = 'gini',random_state = 0)
#rf.fit(X_train,y_train)
#y_pred_rf = rf.predict(X_test)
#accuracy_score_rf = accuracy_score(y_pred_rf,y_test)
#accuracy_score_rf
sv = svm.SVC(kernel= 'linear',gamma =2)
#sv.fit(X_train,y_train)
#y_pred_svm = sv.predict(X_test)
#accuracy_score_svm = accuracy_score(y_pred_svm,y_test)
#accuracy_score_svm
knn = KNeighborsClassifier(n_neighbors = 5)
#knn.fit(X_train,y_train)
#y_pred_knn = knn.predict(X_test)
#accuracy_score_knn = accuracy_score(y_pred_knn,y_test)
#accuracy_score_knn
#scores = [accuracy_score_lr,accuracy_score_dtree,accuracy_score_rf,accuracy_score_svm,accuracy_score_knn]
#scores = [i*100 for i in scores]
algorithm  = ['Logistic Regression','Decision Tree','Random Forest','SVM', 'K-Means']
index = np.arange(len(algorithm))
#plt.bar(index, scores)
#plt.xlabel('Algorithm', fontsize=10)
#plt.ylabel('Accuracy Score', fontsize=5)
#plt.xticks(index, algorithm, fontsize=10, rotation=30)
#plt.title('Accuracy scores for each classification algorithm')
#plt.ylim(80,100)
#plt.show()    
#feat_importances = pd.Series(rf.feature_importances_, index=X.columns)
#feat_importances = feat_importances.nlargest(20)
#feat_importances.plot(kind='barh')
#plt.show()



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aniketkatyal_ibm-employee-attrition-classifier.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aniketkatyal_ibm-employee-attrition-classifier/testY.csv",encoding="gbk")


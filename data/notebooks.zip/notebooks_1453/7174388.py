import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

# In[None]

df = pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# In[None]

df.head()

# In[None]

df.shape

# In[None]

df.columns

# In[None]

df.info()

# In[None]

df.describe()

# In[None]

df.isnull().sum()

# In[None]

df['quality'].unique()

# In[None]

df.quality.value_counts().sort_index()

# In[None]

sns.countplot(x='quality', data = df)

# In[None]

reviews = []
for i in df['quality']:
    if i >= 1 and i <= 4:
        reviews.append('1')
    elif i >= 5 and i <= 6:
        reviews.append('2')
    elif i >= 7 and i <= 8:
        reviews.append('3')
df['Reviews'] = reviews

# In[None]

df.Reviews.value_counts()
# poor = 1
# average = 2
# good = 3

# In[None]

corrmat = df.corr()
plt.figure(figsize=(20,10))
sns.heatmap(corrmat, annot=True, cmap='coolwarm')

# In[None]

corrmat['quality'].sort_values(ascending = False)

# In[None]

sns.boxplot('quality', 'alcohol', data = df)

# In[None]

sns.boxplot('Reviews', 'sulphates', data = df)

# In[None]

sns.boxplot('Reviews', 'citric acid', data = df)

# In[None]

sns.boxplot('Reviews', 'fixed acidity', data = df)

# In[None]

sns.boxplot('Reviews', 'residual sugar', data = df)

# In[None]

X = df.iloc[:,0:11]
y = df['Reviews']

# In[None]

X.head(10)

# In[None]

y.head(10)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7174388.npy", { "accuracy_score": score })

import pandas as pd
# ##  # F# i# g# u# r# i# n# g#  # O# u# t#  # W# h# i# c# h#  # C# u# s# t# o# m# e# r# s#  # M# a# y#  # L# e# a# v# e#  # -#  # C# h# u# r# n#  # A# n# a# l# y# s# i# s# 
# 
# ## ## ##  # A#  # N# o# t# e# b# o# o# k#  # B# y#  # A# n# e# e# s# h#  # C# h# o# p# r# a

# ## ##  # D# a# t# a# s# e# t#  # C# o# n# t# e# x# t#  # 
# 
# E# a# c# h#  # r# o# w#  # r# e# p# r# e# s# e# n# t# s#  # a#  # c# u# s# t# o# m# e# r# ,#  # e# a# c# h#  # c# o# l# u# m# n#  # c# o# n# t# a# i# n# s#  # c# u# s# t# o# m# e# r# ’# s#  # a# t# t# r# i# b# u# t# e# s#  # d# e# s# c# r# i# b# e# d#  # o# n#  # t# h# e#  # c# o# l# u# m# n#  # M# e# t# a# d# a# t# a# .# 
# 
# T# h# e#  # d# a# t# a#  # s# e# t#  # i# n# c# l# u# d# e# s#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t# :# 
# 
# *#  # C# u# s# t# o# m# e# r# s#  # w# h# o#  # l# e# f# t#  # w# i# t# h# i# n#  # t# h# e#  # l# a# s# t#  # m# o# n# t# h#  # –#  # t# h# e#  # c# o# l# u# m# n#  # i# s#  # c# a# l# l# e# d#  # C# h# u# r# n# 
# *#  # S# e# r# v# i# c# e# s#  # t# h# a# t#  # e# a# c# h#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# i# g# n# e# d#  # u# p#  # f# o# r#  # –#  # p# h# o# n# e# ,#  # m# u# l# t# i# p# l# e#  # l# i# n# e# s# ,#  # i# n# t# e# r# n# e# t# ,#  # o# n# l# i# n# e#  # s# e# c# u# r# i# t# y# ,#  # o# n# l# i# n# e#  # b# a# c# k# u# p# ,#  # d# e# v# i# c# e#  # p# r# o# t# e# c# t# i# o# n# ,#  # t# e# c# h#  # s# u# p# p# o# r# t# ,#  # a# n# d#  # s# t# r# e# a# m# i# n# g#  # T# V#  # a# n# d#  # m# o# v# i# e# s# 
# *#  # C# u# s# t# o# m# e# r#  # a# c# c# o# u# n# t#  # i# n# f# o# r# m# a# t# i# o# n#  # –#  # h# o# w#  # l# o# n# g#  # t# h# e# y# ’# v# e#  # b# e# e# n#  # a#  # c# u# s# t# o# m# e# r# ,#  # c# o# n# t# r# a# c# t# ,#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d# ,#  # p# a# p# e# r# l# e# s# s#  # b# i# l# l# i# n# g# ,#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s# ,#  # a# n# d#  # t# o# t# a# l#  # c# h# a# r# g# e# s# 
# *#  # D# e# m# o# g# r# a# p# h# i# c#  # i# n# f# o#  # a# b# o# u# t#  # c# u# s# t# o# m# e# r# s#  # –#  # g# e# n# d# e# r# ,#  # a# g# e#  # r# a# n# g# e# ,#  # a# n# d#  # i# f#  # t# h# e# y#  # h# a# v# e#  # p# a# r# t# n# e# r# s#  # a# n# d#  # d# e# p# e# n# d# e# n# t# s

# ## ##  # F# e# a# t# u# r# e# s# /# C# o# l# u# m# n# /# A# t# t# r# i# b# u# t# e# s#  # E# x# p# l# a# n# a# t# i# o# n# 
# 
# *#  # *# *# c# u# s# t# o# m# e# r# I# D#  # *# *# -#  # C# u# s# t# o# m# e# r#  # I# D# 
# *#  # *# *# g# e# n# d# e# r# *# *#  # -#  # W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # i# s#  # a#  # m# a# l# e#  # o# r#  # a#  # f# e# m# a# l# e# 
# *#  # *# *# S# e# n# i# o# r# C# i# t# i# z# e# n# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # i# s#  # a#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n#  # o# r#  # n# o# t#  # (# 1# ,#  # 0# )# 
# *#  # *# *# P# a# r# t# n# e# r# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # a#  # p# a# r# t# n# e# r#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# )# 
# *#  # *# *# D# e# p# e# n# d# e# n# t# s# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # d# e# p# e# n# d# e# n# t# s#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# )# 
# *#  # *# *# t# e# n# u# r# e# *# *#  # -# N# u# m# b# e# r#  # o# f#  # m# o# n# t# h# s#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# t# a# y# e# d#  # w# i# t# h#  # t# h# e#  # c# o# m# p# a# n# y# 
# *#  # *# *# P# h# o# n# e# S# e# r# v# i# c# e# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # a#  # p# h# o# n# e#  # s# e# r# v# i# c# e#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# )# 
# *#  # *# *# M# u# l# t# i# p# l# e# L# i# n# e# s# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # m# u# l# t# i# p# l# e#  # l# i# n# e# s#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # p# h# o# n# e#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# I# n# t# e# r# n# e# t# S# e# r# v# i# c# e# *# *#  # -# C# u# s# t# o# m# e# r# ’# s#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r#  # (# D# S# L# ,#  # F# i# b# e# r#  # o# p# t# i# c# ,#  # N# o# )# 
# *#  # *# *# O# n# l# i# n# e# S# e# c# u# r# i# t# y# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # o# n# l# i# n# e#  # s# e# c# u# r# i# t# y#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# O# n# l# i# n# e# B# a# c# k# u# p# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # o# n# l# i# n# e#  # b# a# c# k# u# p#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# D# e# v# i# c# e# P# r# o# t# e# c# t# i# o# n# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # d# e# v# i# c# e#  # p# r# o# t# e# c# t# i# o# n#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# T# e# c# h# S# u# p# p# o# r# t# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # t# e# c# h#  # s# u# p# p# o# r# t#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# S# t# r# e# a# m# i# n# g# T# V# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# t# r# e# a# m# i# n# g#  # T# V#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# S# t# r# e# a# m# i# n# g# M# o# v# i# e# s# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# t# r# e# a# m# i# n# g#  # m# o# v# i# e# s#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# ,#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# )# 
# *#  # *# *# C# o# n# t# r# a# c# t# *# *#  # -# T# h# e#  # c# o# n# t# r# a# c# t#  # t# e# r# m#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r#  # (# M# o# n# t# h# -# t# o# -# m# o# n# t# h# ,#  # O# n# e#  # y# e# a# r# ,#  # T# w# o#  # y# e# a# r# )# 
# *#  # *# *# P# a# p# e# r# l# e# s# s# B# i# l# l# i# n# g# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # p# a# p# e# r# l# e# s# s#  # b# i# l# l# i# n# g#  # o# r#  # n# o# t#  # (# Y# e# s# ,#  # N# o# )# 
# *#  # *# *# P# a# y# m# e# n# t# M# e# t# h# o# d# *# *#  # -# T# h# e#  # c# u# s# t# o# m# e# r# ’# s#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d#  # (# E# l# e# c# t# r# o# n# i# c#  # c# h# e# c# k# ,#  # M# a# i# l# e# d#  # c# h# e# c# k# ,#  # B# a# n# k#  # t# r# a# n# s# f# e# r#  # (# a# u# t# o# m# a# t# i# c# )# ,#  # C# r# e# d# i# t#  # c# a# r# d#  # (# a# u# t# o# m# a# t# i# c# )# )# 
# *#  # *# *# M# o# n# t# h# l# y# C# h# a# r# g# e# s# *# *#  # -# T# h# e#  # a# m# o# u# n# t#  # c# h# a# r# g# e# d#  # t# o#  # t# h# e#  # c# u# s# t# o# m# e# r#  # m# o# n# t# h# l# y# 
# *#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # -# T# h# e#  # t# o# t# a# l#  # a# m# o# u# n# t#  # c# h# a# r# g# e# d#  # t# o#  # t# h# e#  # c# u# s# t# o# m# e# r# 
# *#  # *# *# C# h# u# r# n# *# *#  # -# W# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n# e# d#  # o# r#  # n# o# t#  # (# Y# e# s#  # o# r#  # N# o# )

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as  sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ## ##  # R# e# a# d# i# n# g#  # i# n#  # t# h# e#  # D# a# t# a# s# e# t

# In[None]

org=pd.read_csv("/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv")
org.head()

# ## ##  # D# a# t# a#  # C# l# e# a# n# i# n# g#  # P# r# o# c# e# s# s# 
# 
# -#  # F# i# r# s# t# ,#  # w# e#  # w# i# l# l#  # m# a# k# e#  # a#  # c# o# p# y#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t#  # a# n# d#  # w# o# r# k#  # o# n#  # t# h# a# t# ,#  # s# o#  # w# e#  # m# a# k# e#  # s# u# r# e#  # t# h# a# t#  # w# e#  # h# a# v# e#  # t# h# e#  # o# r# i# g# i# n# a# l#  # d# a# t# a#  # s# e# t#  # t# o#  # f# a# l# l# b# a# c# k#  # t# o#  # i# n# c# a# s# e#  # o# f#  # a# n# y#  # m# i# s# t# a# k# e# s# 
# -#  # F# r# o# m#  # t# h# e#  # f# i# r# s# t#  # g# l# i# m# p# s# e#  # a# t#  # t# h# e#  # d# a# t# a# ,#  # t# h# e#  # I# D#  # c# o# l# u# m# n#  # s# e# e# m# s#  # r# e# d# u# n# d# a# n# t#  # a# s#  # w# e#  # a# l# r# e# a# d# y#  # h# a# v# e#  # i# n# d# e# x#  # t# o#  # p# r# o# v# i# d# e#  # u# s#  # u# n# i# q# u# e#  # i# d# e# n# t# i# f# i# e# r# s#  # f# o# r#  # e# a# c# h#  # c# u# s# t# o# m# e# r#  # a# n# d#  # i# t#  # g# i# v# e# s#  # n# o#  # a# d# d# i# t# i# o# n# a# l#  # i# n# f# o#  # 
# -#  # F# o# r#  # S# t# a# n# d# a# r# d# i# z# a# t# i# o# n#  # p# u# r# p# o# s# e# s#  # y# o# u#  # c# a# n#  # d# i# v# i# d# e#  # e# v# e# r# y#  # c# l# e# a# n# i# n# g#  # o# p# e# r# a# t# i# o# n#  # i# n# t# o#  # *# *# D# e# f# i# n# e# *# *#  # ,#  # *# *# C# o# d# e# *# *#  # a# n# d#  # *# *# T# e# s# t# *# *#  # S# e# c# t# i# o# n# s# 
# 
# L# e# t#  # m# e#  # s# h# o# w#  # y# o# u#  # a# n#  # e# x# a# m# p# l# e# *# *# *# *#  

# ## ## ##  # C# l# e# a# n# i# n# g#  # O# p# e# r# a# t# i# o# n#  # 1# 
# 
# ## ## ##  # D# e# f# i# n# e# 
# -#  # R# e# m# o# v# i# n# g#  # t# h# e#  # C# u# s# t# o# m# e# r# I# D#  # c# o# l# u# m# n#  # s# i# n# c# e#  # i# t#  # i# s#  # r# e# d# u# n# d# a# n# t# 
# 
# ## ## ##  # C# o# d# e

# In[None]

#making a copy of the original dataset
df=org.copy()

#Dropping the customerID column 
df.drop('customerID', axis=1, inplace= True)

# ## ## ##  # T# e# s# t# 
# 
# -#  # A# l# w# a# y# s#  # m# a# k# e#  # s# u# r# e#  # t# o#  # t# e# s# t#  # y# o# u# r#  # o# p# e# r# a# t# i# o# n# s#  # h# a# v# e#  # w# o# r# k# e# d#  # a# f# t# e# r#  # e# v# e# r# y#  # s# t# e# p#  # o# f#  # c# l# e# a# n# i# n# g#  # 
# -#  # y# o# u#  # c# a# n#  # m# a# k# e#  # u# s# e#  # o# f#  # *# *# a# s# s# e# r# t# *# *#  # s# t# a# t# e# m# e# n# t# s#  # f# o# r#  # t# e# s# t# i# n# g# 
# -#  # i# f#  # y# o# u# r#  # *# *# a# s# s# e# r# t# *# *#  # s# t# a# t# e# m# e# n# t# s#  # a# r# e#  # f# a# l# s# e# ,#  # t# h# e# y#  # w# i# l# l#  # t# h# r# o# w#  # a# n#  # e# r# r# o# r# 
# -#  # i# f#  # i# t# '# s#  # t# r# u# e# ,#  # r# e# s# t#  # o# f#  # t# h# e#  # c# o# d# e#  # p# r# e# s# e# n# t#  # i# n#  # t# h# e#  # c# e# l# l#  # w# i# l# l#  # b# e#  # e# x# e# c# u# t# e# d#  # w# i# t# h# o# u# t#  # a#  # p# r# o# b# l# e# m# 


# In[None]

assert 'customerID' not in df.columns

# -#  # S# e# e# ,#  # N# o#  # e# r# r# o# r#  # i# s#  # t# h# r# o# w# n# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # c# u# s# t# o# m# e# r# I# D#  # i# s#  # n# o#  # l# o# n# g# e# r#  # p# r# e# s# e# n# t#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t#  # a# n# d#  # w# e#  # h# a# v# e#  # s# u# c# c# e# s# f# u# l# l# y#  # c# o# m# p# l# e# t# e# d#  # o# u# r#  # f# i# r# s# t#  # c# l# e# a# n# i# n# g#  # o# p# e# r# a# t# i# o# n# 
# -#  # L# e# t# '# s#  # c# o# n# t# i# n# u# e#  # t# o# y# i# n# g#  # w# i# t# h#  # t# h# e#  # d# a# t# a#  # t# o#  # s# e# e#  # w# h# a# t#  # o# t# h# e# r#  # c# l# e# a# n# i# n# g#  # o# p# e# r# a# t# i# o# n# s#  # w# e#  # n# e# e# d#  # t# o#  # p# e# r# f# o# r# m#  # o# n#  # o# u# r#  # d# a# t# a

# -#  # *# *# d# e# s# c# r# i# b# e# (# )# *# *#  # a# n# d#  # *# *# i# n# f# o# (# )# *# *#  # a# r# e#  # s# o# m# e#  # o# f#  # t# h# e#  # m# o# s# t#  # b# a# s# i# c#  # a# n# d#  # u# s# e# f# u# l#  # m# e# t# h# o# d# s#  # o# f#  # a# s# s# e# s# s# i# n# g#  # o# u# r#  # d# a# t# a#  # a# n# d#  # f# i# n# d#  # f# a# u# l# t# s#  # i# n#  # t# h# e# m#  # s# u# c# h#  # a# s#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # i# n# c# o# r# r# e# c# t#  # d# a# t# a# t# y# p# e# s# ,#  # o# u# t# l# i# e# r# s#  # ,#  # e# t# c# .

# In[None]

df.info()

#  # -#  # T# h# e# r# e#  # s# e# e# m# s#  # t# o#  # b# e#  # n# o#  # m# i# s# s# i# n# g#  # d# a# t# a#  # a# s#  # o# f#  # n# o# w# ,#  # l# e# t# '# s#  # c# o# n# t# i# n# u# e

# In[None]

df.describe()

# -#  # T# h# e# r# e#  # a# r# e#  # s# u# p# p# o# s# e# d#  # t# o#  # b# e#  # 4#  # n# u# m# e# r# i# c#  # c# o# l# u# m# n# s#  # a# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e#  # d# a# t# a#  # c# o# n# t# e# x# t#  # g# i# v# e# n#  # t# o#  # u# s# 
# -#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # s# e# e# m# s#  # t# o#  # b# e#  # m# i# s# s# i# n# g# ,#  # l# e# t# s#  # t# r# y#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # w# h# y

# ## ## ##  # C# l# e# a# n# i# n# g#  # O# p# e# r# a# t# i# o# n#  # 2# 
# 
# ## ## ##  # D# e# f# i# n# e# 
# 
# -#  # C# o# n# v# e# r# t# i# n# g#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # C# o# l# u# m# n#  # i# n# t# o#  # n# u# m# e# r# i# c#  # 
# 
# ## ## ##  # C# o# d# e

# In[None]

#Converting all possible values in the TotalCharges Column into numeric and converting rest of them into missing values
df['TotalCharges']=df['TotalCharges'].apply(pd.to_numeric, errors='coerce')

#Checking if there are any null values now
df.isnull().sum().sum()

# In[None]

df[df.isnull().any(axis=1)]

# -#  # t# h# e# r# e#  # s# e# e# m#  # t# o#  # b# e#  # 1# 1#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # n# o# w# ,#  # w# e#  # w# i# l# l#  # t# a# k# e#  # c# a# r# e#  # o# f#  # t# h# e# m#  # i# n#  # t# h# e#  # n# e# x# t#  # c# l# e# a# n# i# n# g#  # o# p# e# r# a# t# i# o# n# 
# -#  # a# l# l#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # h# a# v# e#  # t# e# n# u# r# e# =# 0# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# i# s#  # i# s#  # t# h# e#  # c# u# s# t# o# m# e# r# '# s#  # f# i# r# s# t#  # m# o# n# t# h# .#  # I# n#  # t# h# i# s#  # c# a# s# e# ,#  # w# e#  # c# a# n#  # s# u# b# s# t# i# t# u# t# e#  # T# o# t# a# l# C# h# a# r# g# e# s#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  # M# o# n# t# h# l# y# C# h# a# r# g# e#  # v# a# l# u# e# s#  # i# t# s# e# l# f# 
# 
# ## ## ##  # T# e# s# t

# In[None]

assert df['TotalCharges'].dtype=='float64'

# -#  # C# o# l# u# m# n#  # h# a# s#  # b# e# e# n#  # s# u# c# c# e# s# f# u# l# l# y#  # c# o# n# v# e# r# t# e# d#  # i# n# t# o#  # a#  # n# u# m# e# r# i# c# a# l#  # c# o# l# u# m# n# 
# 
# 
# 


# -#  # A# s#  # w# e#  # c# a# n#  # s# e# e# ,#  # t# h# e# r# e#  # i# s#  # a# n#  # a# v# e# r# a# g# e#  # o# f#  # a# b# o# u# t#  # *# *# 3# %# *# *#  #  # a# n# d#  # a#  # m# e# d# i# a# n#  # o# f#  # *# *# 1# .# 9# 9# 5# %# *# *#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # t# h# e#  # p# r# e# d# i# c# t# e# d#  # a# n# d#  # a# c# t# u# a# l#  # v# a# l# u# e# s# 
# -#  # T# h# u# s# ,#  # t# h# e# s# e#  # p# r# e# d# i# c# t# e# d#  # v# a# l# u# e# s#  # s# e# e# m#  # l# i# k# e#  # a#  # v# e# r# y#  # s# e# n# s# i# b# l# e#  # a# m# o# u# n# t#  # t# o#  # i# m# p# u# t# e#  # o# u# r#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  

# ## ## ##  # C# l# e# a# n# i# n# g#  # O# p# e# r# a# t# i# o# n#  # 3# 
# 
# ## ## ##  # D# e# f# i# n# e# 
# 
# -#  # I# m# p# u# t# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s# 
# 
# ## ## ##  # C# o# d# e

# In[None]

df.loc[(pd.isnull(df.TotalCharges)), 'TotalCharges'] = df.MonthlyCharges

# ## ## ##  # T# e# s# t

# In[None]

assert len(df.loc[(pd.isnull(df.TotalCharges))])==0

#  # -#  # w# e#  # h# a# v# e#  # s# u# c# c# e# s# s# f# u# l# l# y#  # i# m# p# u# t# e# d#  # t# h# e#  # v# a# l# u# e# s# 
#  # 
#  # -#  # n# o# w#  # l# e# t# s#  # m# a# k# e#  # s# u# r# e#  # a# l# l#  # c# a# t# e# g# o# r# i# c# a# l#  # c# o# l# u# m# n# s#  # o# n# l# y#  # h# a# v# e#  # t# h# e#  # v# a# l# u# e# s#  # a# m# o# n# g#  # t# h# e#  # g# i# v# e# n#  # r# a# n# g# e

# In[None]

#extracting all categorical columns
categorical_columns=df.select_dtypes(include='object').columns.tolist()
print(categorical_columns)

# In[None]

#Made a list of number of unique values allowed in each column according to the details provided to us
x=[2,2,2,2,3,3,3,3,3,3,3,3,3,2,4,2]
y=[]

#Number of unique elements present in each column
for i in categorical_columns:
    y.append(len(df[i].unique()))

#Comparing Values
for i,j in zip(x,y):
    print(i,j)

# -#  # A# l# l#  # C# o# l# u# m# n# s#  # S# e# e# m#  # t# o#  # h# a# v# e#  # v# a# l# u# e# s#  # p# r# e# s# e# n# t#  # i# n#  # t# h# e#  # g# i# v# e# n#  # r# a# n# g# e# 
# -#  # L# o# o# k# s#  # l# i# k# e#  # n# o#  # m# o# r# e#  # c# l# e# a# n# i# n# g#  # n# e# e# d# s#  # t# o#  # b# e#  # d# o# n# e# ,#  # l# e# t# s#  # m# o# v# e#  # o# n# t# o#  # e# x# p# l# o# r# a# t# i# o# n

# ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# In[None]

# Summarize our dataset 
print ("Rows     : " ,df.shape[0])
print ("Columns  : " ,df.shape[1])
print ("\nFeatures : \n" ,df.columns.tolist())
print ("\nMissing values :  ", df.isnull().sum().values.sum())
print ("\nUnique values :  \n",df.nunique())

# ## ## ##  # 1# -# D#  # E# x# p# l# o# r# a# t# i# o# n# 
# -#  # L# e# t# s#  # g# e# t#  # t# h# e#  # C# l# a# s# s#  # L# a# b# e# l# (# C# u# s# t# o# m# e# r#  # C# h# u# r# n# )#  # B# r# e# a# k# d# o# w# n#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t#  # g# i# v# e# n#  # t# o#  # u# s

# In[None]

df['Churn'].value_counts()/df.shape[0]

# In[None]

labels = df['Churn'].value_counts(sort = True).index
sizes = df['Churn'].value_counts(sort = True)

colors = ["green","red"]
explode = (0.05,0)  # explode 1st slice
 
plt.figure(figsize=(7,7))
# Plot
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=90,)

plt.title('Customer Churn Breakdown')
plt.show()

# S# i# d# e#  # N# o# t# e#  # :#  # T# r# y#  # t# o#  # a# v# o# i# d#  # p# i# e#  # c# h# a# r# t# s#  # i# f#  # p# o# s# s# i# b# l# e# .#  # I# t# ’# s#  # a#  # c# o# m# m# o# n#  # v# i# s# u# a# l# i# z# a# t# i# o# n#  # j# o# k# e#  # t# h# a# t#  # P# i# e#  # C# h# a# r# t# s#  # a# r# e#  # t# h# e#  # w# o# r# s# t# .#  # 
# 
# -#  # O# n# l# y#  # u# s# e#  # t# h# e# m#  # w# h# e# n#  # t# h# e# r# e#  # a# r# e#  # 2# -# 4#  # d# i# f# f# e# r# e# n# t#  # u# n# i# q# u# e#  # v# a# l# u# e# s# .#  # M# o# r# e#  # t# h# e#  # v# a# r# i# a# b# l# e# s# ,#  # t# h# e#  # h# a# r# d# e# r#  # i# t#  # w# i# l# l#  # b# e#  # f# o# r#  # u# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # w# h# a# t#  # t# h# e#  # p# i# e#  # c# h# a# r# t#  # i# s#  # t# r# y# i# n# g#  # t# o#  # c# o# n# v# e# y# 
# -#  # P# i# e#  # c# h# a# r# t# s#  # c# a# n#  # b# e#  # u# s# e# d#  # t# o#  # m# a# n# i# p# u# l# a# t# e#  # o# r#  # h# i# d# e#  # f# a# c# t# s#  # a# s#  # w# e# l# l# .#  # F# o# r#  # e# g# ,#  # W# e#  # g# e# t#  # t# o#  # k# n# o# w#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# h# e#  # t# h# e#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n# i# n# g#  # t# h# o# r# u# g# h#  # t# h# e#  # p# i# e#  # c# h# a# r# t#  # b# u# t#  # w# e#  # d# o# n# '# t#  # g# e# t#  # t# o#  # k# n# o# w#  # h# o# w#  # b# e# l# i# e# v# a# b# l# e#  # t# h# i# s#  # i# s#  # s# i# n# c# e#  # w# e#  # a# r# e#  # u# n# a# b# l# e#  # t# o#  # f# i# g# u# r# e#  # o# u# t#  # t# h# e#  # s# a# m# p# l# e#  # s# i# z# e#  # t# a# k# e# n#  # f# o# r#  # t# h# i# s#  # c# h# a# r# t# 
# -#  # T# h# i# s#  # w# o# u# l# d# n# t#  # b# e#  # t# h# e#  # c# a# s# e#  # i# n#  # b# a# r#  # p# l# o# t# s#  # s# i# n# c# e#  # w# e#  # w# o# u# l# d#  # h# a# v# e#  # t# h# e#  # v# a# l# u# e#  # c# o# u# n# t# s#  # o# n#  # t# h# e#  # x# -# a# x# i# s

# In[None]

fig, axes = plt.subplots(1, 3, figsize=(20, 5))
sns.distplot( df["tenure"] , color="skyblue", ax=axes[0])
sns.distplot(df['MonthlyCharges'],color='orange',ax=axes[1])
sns.distplot(df['TotalCharges'],color='green',ax=axes[2])
fig.suptitle('Histogram of Numerical Columns')

# ## ## ## ##  # O# b# e# r# v# a# t# i# o# n# s#  # 
# 
# *#  # T# h# e# r# e#  # s# e# e# m# s#  # t# o#  # b# e#  # a#  # s# o# m# e# w# h# a# t#  # u# n# i# f# o# r# m#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# e# n# u# r# e#  # o# f#  # c# u# s# t# o# m# e# r# s#  # e# x# c# e# p# t#  # f# o# r#  # t# w# o#  # p# e# a# k# s#  # a# t#  # t# h# e#  # e# x# t# r# e# m# e# s#  # w# h# i# c# h#  # s# u# g# g# e# s# t#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # a# t# l# e# a# s# t#  # 2#  # c# u# s# t# o# m# e# r#  # s# e# g# m# e# n# t# s# :#  # 
#  # 1# .#  # L# o# y# a# l# i# s# t# s# :#  # W# h# i# c# h#  # h# a# v# e#  # r# e# m# a# i# n# e# d#  # w# i# t# h#  # t# h# e#  # g# i# v# e# n#  # t# e# l# c# o#  # f# o# r#  # ># 7# 0#  # m# o# n# t# h# s#  # 
#  # 2# .#  # N# e# w# c# o# m# e# r# s# :#  # W# h# i# c# h#  # h# a# v# e#  # s# t# a# r# t# e# d#  # u# s# i# n# g#  # t# h# e#  # g# i# v# e# n#  # t# e# l# c# o# '# s#  # s# e# r# v# i# c# e# s# 
# 
# 
# *#  # U# n# a# b# l# e#  # t# o#  # m# a# k# e#  # a# n# y#  # c# l# e# a# r#  # o# b# s# e# r# v# a# t# i# o# n# s#  # f# r# o# m#  # t# h# e#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s#  # H# i# s# t# o# g# r# a# m#  # b# u# t#  # t# h# e# r# e#  # s# e# e# m# s#  # t# o#  # b# e#  # a#  # b# a# s# e#  # p# l# a# n#  # o# f#  # $# 2# 0#  # b# e# i# n# g#  # o# f# f# e# r# e# d#  # b# y#  # t# h# e#  # t# e# l# c# o#  # w# h# i# c# h#  # m# a# n# y#  # c# u# s# t# o# m# e# r# s#  # s# e# e# m#  # t# o#  # b# e#  # u# s# i# n# g#  # 
# 
# *#  #  # T# h# e#  # T# o# t# a# l# C# h# a# r# g# e# s#  # d# i# t# r# i# b# u# t# i# o# n#  # s# o# r# t#  # o# f#  # m# i# m# i# c# s#  # t# h# e#  # l# o# n# g# -# t# a# i# l#  # d# i# s# t# r# i# b# u# t# i# o# n#  # w# h# e# r# e#  # a# s#  # t# h# e#  # T# o# t# a# l# C# h# a# r# g# e#  # i# n# c# r# e# a# s# e# s# ,#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r#  # g# o# e# s#  # o# n#  # f# u# r# t# h# e# r#  # d# e# c# r# e# a# s# i# n# g#  

# In[None]

fig, axes = plt.subplots(3, 2, figsize=(20, 20))
fig1=sns.countplot( df["gender"] ,ax=axes[0,0])
fig2=sns.countplot( df["SeniorCitizen"] , ax=axes[0,1])
fig3=sns.countplot( df["Contract"] , ax=axes[2,0])
fig4=sns.countplot( df["PaymentMethod"] , ax=axes[2,1])
fig5=sns.countplot( df["Partner"] , ax=axes[1,0])
fig6=sns.countplot( df["Dependents"] , ax=axes[1,1])

figures=[fig1,fig2,fig3,fig4,fig5,fig6]

for graph in figures:
    graph.set_xticklabels(graph.get_xticklabels(),rotation=90)
    
    for p in graph.patches:
        height = p.get_height()
        graph.text(p.get_x()+p.get_width()/2., height,height ,ha="center")


fig.suptitle('')

# ## ## ## ##  # O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# -#  # I#  # o# n# l# y#  # p# l# o# t# t# e# d#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # w# h# i# c# h#  # s# e# e# m#  # i# m# p# o# r# t# a# n# t#  # t# o#  # m# e#  # a# t#  # t# h# e#  # m# o# m# e# n# t# 
# -#  # G# e# n# d# e# r#  # a# n# d#  # P# a# r# t# n# e# r#  # f# e# a# t# u# r# e# s#  # s# e# e# m#  # t# o#  # b# e#  # e# v# e# n# l# y#  # d# i# s# t# r# i# b# u# t# e# d#  # a# m# o# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # w# i# t# h#  # e# a# c# h#  # u# n# i# q# u# e#  # v# a# l# u# e#  # b# e# i# n# g#  # e# q# u# a# l# l# y#  # r# e# p# r# e# s# e# n# t# e# d#  # 
# -#  # T# h# e# r# e#  # a# r# e#  # l# e# s# s#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # d# e# p# e# n# d# e# n# t# s#  # a# s#  # w# e# l# l#  # a# s#  # l# e# s# s#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # a# r# e#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s# 
# -#  # A#  # h# u# g# e#  # m# a# j# o# r# i# t# y#  # o# f#  # c# u# s# t# o# m# e# r# s#  # a# r# e#  # t# i# e# d#  # t# o#  # t# h# e#  # t# e# l# c# o#  # s# e# r# v# i# c# e# s#  # o# n#  # a#  # m# o# n# t# h#  # t# o#  # m# o# n# t# h#  # b# a# s# i# s# ,#  # w# h# i# c# h#  # g# i# v# e# s#  # t# h# e# m#  # a# l# o# t#  # o# f#  # f# l# e# x# i# b# i# l# i# t# y#  # t# o#  # m# o# v# e#  # a# r# o# u# n# d#  # t# o#  # t# r# y#  # o# u# t#  # o# t# h# e# r#  # c# o# m# p# e# t# i# t# o# r# s# 
# -#  # A# l# o# t#  # o# f#  # c# u# s# t# o# m# e# r# s#  # a# l# s# o#  # p# r# e# f# e# r#  # e# l# e# c# t# o# n# i# c#  # c# h# e# c# k#  # w# h# e# n#  # i# t#  # c# o# m# e# s#  # t# o#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d# .#  # M# a# y# b# e#  # d# u# e#  # t# o#  # t# h# e#  # e# a# s# e#  # o# f#  # t# h# e#  # p# r# o# c# e# s# s# ,#  # n# o#  # o# t# h# e# r#  # i# n# f# e# r# e# n# c# e#  # c# a# n#  # b# e#  # m# a# d# e#  # f# r# o# m#  # t# h# i# s#  # s# o# l# e# l# y

# ## ## ##  # 2# -# D#  # P# l# o# t# s

# ## ## ## ##  # A# )#  # N# u# m# e# r# i# c# a# l#  # C# o# l# u# m# n# s#  # v# s#  # C# h# u# r# n

# In[None]

fig, axes = plt.subplots(1, 2, figsize=(12, 7))
g = sns.violinplot(x="Churn", y = "MonthlyCharges",data = df, palette = "Pastel1",ax=axes[0])
g = sns.violinplot(x="Churn", y = "tenure",data = df, palette = "Pastel1",ax=axes[1])


# ## ## ## ##  # O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# -#  # M# a# n# y#  # p# e# o# p# l# e#  # w# h# o#  # h# a# v# e#  # c# h# o# s# e# n#  # t# h# e#  # b# a# s# e#  # p# l# a# n#  # o# f#  # $# 2# 0#  # s# e# e# m#  # t# o#  # b# e#  # s# t# i# c# k# i# n# g#  # t# o#  # t# h# e#  # t# e# l# c# o# '# s#  # s# e# r# v# i# c# e# s#  # w# h# e# r# e# s#  # a# s#  # t# h# e#  # M# o# n# t# h# l# y#  # C# h# a# r# g# e# s#  # g# o#  # o# n#  # i# n# c# r# e# a# s# i# n# g#  # a#  # h# u# g# e#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r# s#  # s# e# e# m#  # t# o#  # h# a# v# e#  # l# e# f# t#  # t# h# e#  # s# e# r# v# i# c# e# s#  # a# s#  # s# e# e# n#  # i# n#  # t# h# e#  # r# a# n# g# e# s#  # 6# 0# -# 1# 2# 0# 
# 
# -#  # T# h# e# r# e#  # i# s#  # n# o#  # p# a# t# t# e# r# n#  # o# b# s# e# r# v# a# b# l# e#  # a# m# o# n# g#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # s# t# a# y# e# d#  # w# h# e# n#  # i# t#  # c# o# m# e# s#  # t# o#  # t# e# n# u# r# e#  # b# u# t#  # n# e# w# -# c# o# m# e# r#  # C# u# s# t# o# m# e# r# s#  # s# e# e# m#  # t# o#  # t# a# k# e#  # u# p#  # p# o# r# t# i# o# n#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d# 


# ## ## ## ##  # B# )#  # C# a# t# e# g# o# r# i# c# a# l#  # C# o# l# u# m# n# s#  # v# s#  # C# h# u# r# n

# In[None]

fig, axes = plt.subplots(3, 2, figsize=(20, 20))
fig1=sns.countplot( x=df["Churn"],hue=df["gender"] ,ax=axes[0,0])
fig2=sns.countplot( x=df["Churn"],hue=df["SeniorCitizen"] , ax=axes[0,1])
fig3=sns.countplot( x=df["Churn"],hue=df["Contract"] , ax=axes[2,0])
fig4=sns.countplot( x=df["Churn"],hue=df["PaymentMethod"] , ax=axes[2,1])
fig5=sns.countplot( x=df["Churn"],hue=df["Partner"] , ax=axes[1,0])
fig6=sns.countplot( x=df["Churn"],hue=df["Dependents"] , ax=axes[1,1])

figures=[fig1,fig2,fig3,fig4,fig5,fig6]

for graph in figures:
    graph.set_xticklabels(graph.get_xticklabels(),rotation=90)
    
    for p in graph.patches:
        height = p.get_height()
        graph.text(p.get_x()+p.get_width()/2., height,round((height/7043)*100,2) ,ha="center")


fig.suptitle('')

# ## ## ## ##  # O# b# s# e# r# v# a# t# i# o# n# s# 
# -#  # T# h# e#  # g# e# n# d# e# r#  # d# o# e# s# n# '# t#  # s# e# e# m#  # t# o#  # p# l# a# y#  # a#  # r# o# l# e#  # i# n#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n#  # a# s#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # r# e# m# a# i# n# s#  # t# h# e#  # s# a# m# e#  # i# n#  # b# o# t# h#  # c# a# s# e# s# 
# -#  # W# e#  # s# e# e#  # a#  # s# h# i# f# t#  # i# n#  # d# i# s# t# r# i# b# u# t# i# o# n#  # i# n#  # t# h# e#  # p# a# r# t# n# e# r# s#  # c# a# t# e# g# o# r# y#  # a# m# o# n# g#  # C# u# t# o# m# e# r# s#  # w# h# o#  # l# e# f# t#  # a# n# d#  # w# h# o#  # s# t# a# y# e# d# .# 
# 1# .#  # A# m# o# n# g#  # C# u# s# t# o# m# e# r# s#  # w# h# o#  # s# t# a# y# e# d#  # ,# T# h# e# r# e#  # a# r# e#  # s# l# i# g# h# l# t# y#  # m# o# r# e#  # C# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # p# a# r# t# n# e# r# s#  # (# 3# 8# .# 8# %# )#  # t# h# a# n#  # t# h# o# s# e#  # w# h# o#  # d# o# n# '# t#  # (# 3# 4# .# 6# 6# %# )# 
# 2# .#  # W# h# e# n#  # i# t#  # c# o# m# e# s#  # t# o#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # l# e# f# t# ,#  # C# u# s# t# o# m# e# r# s#  # w# h# o#  # d# o# n# '# t#  # h# a# v# e#  # p# a# r# t# n# e# r# s#  # (# 1# 7# .# 0# 4# %# )#  # a# r# e#  # a# l# m# o# s# t#  # t# w# i# c# e#  # a# s#  # m# u# c# h#  # a# s#  # t# h# o# s# e#  # w# h# o#  # d# o#  # (# 9# .# 5# %# )# 
# -#  # W# e#  # a# l# r# e# a# d# y#  # k# n# o# w#  # t# h# a# t#  # m# a# j# o# r# i# t# y#  # o# f#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # a#  # m# o# n# t# h# -# t# o# -# m# o# n# t# h#  # c# o# n# t# r# a# c# t#  # b# u# t#  # a# s#  # w# e#  # c# a# n#  # s# e# e# ,# t# h# e# r# e#  # i# s#  # a#  # h# u# g# e#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # t# h# e#  # r# a# t# i# o# s#  # o# f#  # C# h# u# r# n# e# d#  # C# u# s# t# o# m# e# r# s#  # w# h# e# r# e#  # M# o# n# t# h# -# t# o# -# M# o# n# t# h#  # C# o# n# t# r# a# c# t#  # C# u# s# t# o# m# e# r# s#  # t# a# k# e#  # u# p#  # a#  # h# u# g# e#  # c# h# u# n# k# 
# -#  # T# h# e# r# e#  # i# s#  # a#  # s# i# m# i# l# a# r#  # c# a# s# e#  # w# h# e# n#  # i# t#  # c# o# m# e# s#  # t# o#  # P# a# y# m# e# n# t# M# e# t# h# o# d# s# ,#  # w# h# e# r# e#  # E# l# e# c# t# r# o# n# i# c#  # C# h# e# c# k#  # r# e# p# l# a# c# e# s#  # M# o# n# t# h# -# t# o# -# M# o# n# t# h#  # C# o# n# t# r# a# c# t# s# 
# -#  # U# s# i# n# g#  # t# h# e# s# e#  # b# a# r# p# l# o# t# s#  # a# n# d#  # a# n# n# o# t# a# t# i# o# n# s# ,#  # w# e#  # a# r# e#  # a# b# l# e#  # t# o#  # s# e# e#  # t# h# e#  # a# b# s# o# l# u# t# e#  # p# e# r# c# e# n# t# a# g# e#  # e# a# c# h#  # b# a# r#  # r# e# p# r# e# s# e# n# t# s#  # i# n#  # t# h# e#  # w# h# o# l# e#  # d# a# t# a# s# e# t# ,#  # b# u# t#  # w# h# e# n#  # i# t#  # c# o# m# e# s#  # k# n# o# w# i# n# g#  # t# h# e#  # r# e# l# a# t# i# v# e#  # p# e# r# c# e# n# t# a# g# e# s#  # o# r#  # p# r# o# b# a# b# i# l# i# t# i# e# s#  # e# a# c# h#  # v# a# r# i# a# b# l# e#  # h# a# s#  # w# h# e# n#  # r# e# l# a# t# e# d#  # t# o#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n# i# n# g# ,#  # w# e#  # w# i# l# l#  # h# a# v# e#  # t# o#  # u# s# e#  # a#  # b# e# t# t# e# r#  # a# l# t# e# r# n# a# t# i# v# e#  # i# .# e#  # i# n#  # t# h# i# s#  # c# a# s# e# ,#  # a#  # c# r# o# s# s# -# t# a# b# u# l# a# t# i# o# n# 
# -#  # C# r# o# s# s# -# t# a# b#  # w# i# l# l#  # i# n#  # a#  # s# e# n# s# e# ,#  # h# e# l# p#  # u# s#  # i# n#  # c# a# l# c# u# l# a# t# i# n# g#  # p# r# o# b# a# b# i# l# i# t# i# e# s#  # s# u# c# h#  # a# s#  # *# *# P# (# C# h# u# r# n#  # =#  # '# Y# e# s# '# |# C# o# n# t# r# a# c# t# =# '# M# o# n# t# h# -# t# o# -# M# o# n# t# h# '# )# *# *#  # w# h# i# c# h#  # p# l# a# y#  # a#  # k# e# y#  # r# o# l# e#  # i# n#  # N# a# i# v# e#  # B# a# y# e# s#  # C# l# a# s# s# i# f# i# e# r#  # a# s#  # w# e# l# l#  # a# s#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # i# m# p# a# c# t#  # a#  # v# a# r# i# a# b# l# e#  # h# a# s#  # o# n#  # t# h# e#  # o# u# t# c# o# m# e

# In[None]

#First Create a dataset which only has categorical columns for the cross-tab

#Method 1: Dropping All Numerical Columns or adding All Categorical Columns MANUALLY
df_cat=df.drop(['MonthlyCharges', 'TotalCharges', 'tenure'], axis=1)
print(df_cat.shape)

#Method 2: Create a Method to automatically parse through all columns and recognise categorical columns
cat_cols = df.nunique()[df.nunique() < 6].keys().tolist()
cat_cols = [x for x in cat_cols]
df_cat=df[cat_cols]
print(df_cat.shape)


# In[None]

summary = pd.concat([pd.crosstab(df_cat[x], df_cat.Churn) for x in df_cat.columns[:-1]], keys=df_cat.columns[:-1])
summary['Churn_Percentage'] = summary['Yes'] / (summary['No'] + summary['Yes'])

# In[None]

#Lets check cases where more than 1/3rd of the customers have left
summary[summary['Churn_Percentage']>0.33]

# ## ## ##  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g# 
# 
# -#  # I# n#  # t# h# e#  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # P# h# a# s# e# ,#  # w# e#  # m# a# n# i# p# u# l# a# t# e#  # a# n# d#  # t# r# a# n# s# f# o# r# m#  # o# u# r#  # d# a# t# a#  # i# n# t# o#  # a#  # f# o# r# m# a# t#  # w# h# i# c# h#  # c# a# n#  # b# e#  # u# s# e# d#  # b# y#  # o# u# r#  # m# o# d# e# l#  # t# o#  # t# r# a# i# n#  # o# n# .#  # T# h# i# s#  # i# n# v# o# l# v# e# s#  # v# a# r# i# o# u# s#  # f# o# r# m# s#  # o# f#  # e# n# c# o# d# i# n# g#  # a# n# d#  # s# c# a# l# i# n# g#  # o# f#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # 
# 
# -#  # I# n#  # t# h# e#  # F# e# a# t# u# e#  # E# n# g# i# n# e# e# r# i# n# g#  # s# e# c# t# i# o# n#  # w# e#  # w# i# l# l#  # t# r# y#  # t# o#  # b# u# i# l# d#  # n# e# w#  # f# e# a# t# u# r# e# s#  # o# r#  # m# o# d# i# f# y#  # e# x# i# s# i# t# i# n# g#  # f# e# a# t# u# r# e# s#  # w# h# i# c# h#  # i# n#  # t# u# r# n#  # w# i# l# l#  # h# e# l# p#  # o# u# r#  # m# o# d# e# l#  # t# o#  # p# e# r# f# o# r# m#  # b# e# t# t# e# r# 
# 
# -#  # G# e# n# e# r# a# l# l# y#  # t# o#  # d# o#  # t# h# i# s# ,#  # y# o# u#  # r# e# q# u# i# r# e#  # d# o# m# a# i# n#  # k# n# o# w# l# e# d# g# e#  # a# s#  # w# e# l# l#  # a# s#  # u# n# d# e# r# t# a# n# d# i# n# g#  # o# f#  # c# o# m# m# o# n#  # F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g#  # t# e# c# h# n# i# q# u# e# s#  # u# s# e# d#  # 


# ## ## ## ##  # A# )#  # N# e# w#  # F# e# a# t# u# r# e# s# 
# 
# -#  # w# e#  # c# o# u# l# d#  # m# u# l# t# i# p# l# y#  # t# h# e#  # *# *# t# e# n# u# r# e# *# *#  # c# o# l# u# m# n#  # v# a# l# u# e# s#  # w# i# t# h#  # t# h# e#  # *# *# M# o# n# t# h# l# y# C# h# a# r# g# e# s# *# *#  # ,#  # l# e# t# s#  # c# o# m# p# a# r# e#  # t# h# e#  # p# r# e# d# i# c# t# e# d#  # v# a# l# u# e# s#  # (# t# e# n# u# r# e#  # *#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s# )#  # w# i# t# h#  # a# c# t# u# a# l#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .#  # I# f#  # t# h# e#  # v# a# l# u# e# s#  # d# i# f# f# e# r#  # m# u# c# h# ,#  # i# t#  # m# e# a# n# s#  # t# h# e#  # C# u# s# t# o# m# e# r#  # h# a# d#  # h# i# s#  # p# l# a# n#  # c# h# a# n# g# e# d#  # a# t#  # s# o# m# e#  # p# o# i# n# t# .#  # 
# 
# 1# .#  # I# f#  # *# *# t# e# n# u# r# e#  # *#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s# *# *#  # =# =#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # -# >#  # C# o# n# s# i# s# t# e# n# t#  # C# u# s# t# o# m# e# r# :#  # H# e# /# S# h# e#  # i# s#  # p# r# o# b# a# b# l# y#  # s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e#  # s# e# r# v# i# c# e#  # b# e# i# n# g#  # p# r# o# v# i# d# e# d#  # s# o#  # f# a# r# 
# 2# .#  # I# f#  # *# *# t# e# n# u# r# e#  # *#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s# *# *#  # <#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # -# >#  # P# r# o# f# i# t# a# b# l# e#  # C# u# s# t# o# m# e# r# :#  # A#  # c# u# s# t# o# m# e# r#  # w# o# u# l# d#  # o# n# l# y#  # i# n# c# r# e# a# s# e#  # h# i# s# /# h# e# r#  # p# l# a# n#  # i# f#  # h# e#  # r# e# q# u# i# r# e# s#  # m# o# r# e#  # s# e# r# v# i# c# e# s#  # a# n# d# /# o# r#  # h# i# s# /# h# e# r#  # i# n# c# o# m# e#  # l# e# v# e# l#  # h# a# s#  # i# n# c# r# e# a# s# e# d# 
# 3# .#  # I# f#  # *# *# t# e# n# u# r# e#  # *#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s# *# *#  # >#  # *# *# T# o# t# a# l# C# h# a# r# g# e# s# *# *#  # -# >#  # D# e# c# l# i# n# i# n# g#  # C# u# s# t# o# m# e# r# :#  # T# h# e#  # C# u# s# t# o# m# e# r# '# s#  # i# n# c# o# m# e#  # l# e# v# e# l#  # a# s#  # p# r# o# b# a# b# l# y#  # d# e# c# r# e# a# s# e# d#  # o# r#  # h# e# /# s# h# e#  # i# s#  # d# i# s# s# a# t# i# f# i# e# d#  # w# i# t# h#  # c# e# r# t# a# i# n#  # s# e# r# v# i# c# e# s#  # o# f#  # t# h# e#  # T# e# l# c# o#  # a# n# d#  # i# s#  # t# r# y# i# n# g#  # o# u# t#  # t# h# e#  # c# o# m# p# e# t# i# t# o# r# '# s#  # s# e# r# v# i# c# e# s# 
# 
# -#  # T# h# e# s# e#  # a# r# e#  # j# u# s# t#  # m# e# r# e#  # a# s# s# u# m# p# t# i# o# n# s#  # I#  # h# a# v# e#  # m# a# d# e#  # t# o#  # j# u# s# t# i# f# y#  # t# h# e#  # r# e# a# s# o# n#  # b# e# h# i# n# d#  # t# h# e#  # c# h# a# n# g# e# s# .#  # I#  # c# o# u# l# d#  # v# e# r# y#  # e# a# s# i# l# y#  # b# e#  # w# r# o# n# g# ,#  # b# u# t#  # l# e# t# '# s#  # c# h# e# c# k#  # o# u# t#  # i# f#  # w# e#  # c# a# n#  # f# i# n# d#  # a# n# y# t# h# i# n# g#  # n# e# w#  # a# b# o# u# t#  # o# u# r#  # d# a# t# a

# In[None]

#Creating a Predicted Values Column
df['PCharges']=df['MonthlyCharges']*df['tenure']
#Creating a Column to calculate Absolute Percentage Difference between predicted and actual values
df['PDifference']=(((df['PCharges']-df['TotalCharges'])/df['TotalCharges'])*100)



# In[None]

fig, axes = plt.subplots(1, 2, figsize=(10, 5))
sns.distplot( df[df['Churn']=="No"]["PDifference"] , color="green",ax=axes[0])
sns.distplot( df[df['Churn']=="Yes"]["PDifference"] , color="red",ax=axes[1])
df['PDifference'].describe()

# In[None]

df.drop(["PCharges"],axis=1,inplace=True)

# In[None]

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

target_col = ["Churn"]

#numerical columns
num_cols = [x for x in df.columns if x not in cat_cols + target_col]

#Binary columns with 2 values
bin_cols = df.nunique()[df.nunique() == 2].keys().tolist()

#Columns more than 2 values
multi_cols = [i for i in cat_cols if i not in bin_cols]

#Label encoding Binary columns
le = LabelEncoder()
for i in bin_cols :
    df[i] = le.fit_transform(df[i])
    
#Duplicating columns for multi value columns
df = pd.get_dummies(data = df, columns = multi_cols )
df.head()

# In[None]

#Scaling Numerical columns
std = StandardScaler()

# Scale data
scaled = std.fit_transform(df[num_cols])
scaled = pd.DataFrame(scaled,columns=num_cols)

#dropping original values merging scaled values for numerical columns
df_telcom_og = df.copy()
df = df.drop(columns = num_cols,axis = 1)
df = df.merge(scaled, left_index=True, right_index=True, how = "left")

#churn_df.info()
df.head()

# ## ##  # M# o# d# e# l# l# i# n# g#  

# In[None]

from sklearn.model_selection import train_test_split

# We remove the label values from our training data
X = df.drop(['Churn'], axis=1).values

# We assigned those label values to our Y dataset
y = df['Churn'].values

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8694335.npy", { "accuracy_score": score })

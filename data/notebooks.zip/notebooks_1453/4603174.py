import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import SGDClassifier

import os
#print(os.listdir("../input"))

# In[None]

data = pd.read_csv('../input/winequality-red.csv')

# In[None]

data.head()

# In[None]

data.describe()

# In[None]

sns.pairplot(data)

# In[None]

results = data[['quality']]
results.head()

# In[None]

data.drop(columns = ['quality'])

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(data, results, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4603174.npy", { "accuracy_score": score })

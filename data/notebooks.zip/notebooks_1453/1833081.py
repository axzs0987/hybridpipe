import pandas as pd
# T# e# a# m#  # N# a# m# e# :#  # 4# 0# 4# N# A#  # <# b# r# ># 
# A# n# i# s# h#  # M#  # R# a# o#  # 0# 1# F# B# 1# 6# E# C# S# 0# 6# 2#  # <# b# r# ># 
# M# a# l# a# i# k# a#  # V# i# j# a# y#  # 0# 1# F# B# 1# 6# E# C# S# 1# 8# 9#  # <# b# r# ># 
# M# a# n# a# s# a#  # J# a# g# a# d# e# e# s# h#  # 0# 1# F# B# 1# 6# E# C# S# 4# 7# 1

# In[None]

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor,DecisionTreeClassifier
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.metrics import mean_squared_error,classification_report,accuracy_score
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import numpy as np
import os

# In[None]

print(os.listdir('../input'))
data = pd.read_csv('../input/Absenteeism_at_work.csv', delimiter=',')
X_orig=data.drop('Absenteeism time in hours',axis=1)
y=data['Absenteeism time in hours']
scaler=MinMaxScaler()
X = scaler.fit_transform(X_orig)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1833081.npy", { "accuracy_score": score })

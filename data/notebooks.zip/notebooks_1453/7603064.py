import pandas as pd
# ##  # P# R# E# D# I# C# T# I# N# G#  # A#  # P# U# L# S# A# R#  # S# T# A# R# 
# 
# M# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# o# o# l# s#  # a# r# e#  # n# o# w#  # b# e# i# n# g#  # u# s# e# d#  # t# o#  # a# u# t# o# m# a# t# i# c# a# l# l# y#  # l# a# b# e# l#  # p# u# l# s# a# r#  # c# a# n# d# i# d# a# t# e# s#  # t# o#  # f# a# c# i# l# i# t# a# t# e#  # r# a# p# i# d#  # a# n# a# l# y# s# i# s# .#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # s# y# s# t# e# m# s#  # i# n#  # p# a# r# t# i# c# u# l# a# r#  # a# r# e#  # b# e# i# n# g#  # w# i# d# e# l# y#  # a# d# o# p# t# e# d# ,#  # w# h# i# c# h#  # t# r# e# a# t#  # t# h# e#  # c# a# n# d# i# d# a# t# e#  # d# a# t# a#  # s# e# t# s#  # a# s#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# s# .#  # H# e# r# e#  # t# h# e#  # l# e# g# i# t# i# m# a# t# e#  # p# u# l# s# a# r#  # e# x# a# m# p# l# e# s#  # a# r# e#  # a#  # m# i# n# o# r# i# t# y#  # p# o# s# i# t# i# v# e#  # c# l# a# s# s# ,#  # a# n# d#  # s# p# u# r# i# o# u# s#  # e# x# a# m# p# l# e# s#  # t# h# e#  # m# a# j# o# r# i# t# y#  # n# e# g# a# t# i# v# e#  # c# l# a# s# s# .# 
# 
# T# h# e#  # d# a# t# a#  # s# e# t#  # s# h# a# r# e# d#  # h# e# r# e#  # c# o# n# t# a# i# n# s#  # 1# 6# ,# 2# 5# 9#  # s# p# u# r# i# o# u# s#  # e# x# a# m# p# l# e# s#  # c# a# u# s# e# d#  # b# y#  # R# F# I# /# n# o# i# s# e# ,#  # a# n# d#  # 1# ,# 6# 3# 9#  # r# e# a# l#  # p# u# l# s# a# r#  # e# x# a# m# p# l# e# s# .#  # T# h# e# s# e#  # e# x# a# m# p# l# e# s#  # h# a# v# e#  # a# l# l#  # b# e# e# n#  # c# h# e# c# k# e# d#  # b# y#  # h# u# m# a# n#  # a# n# n# o# t# a# t# o# r# s# .# 
# 
# E# a# c# h#  # r# o# w#  # l# i# s# t# s#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # f# i# r# s# t# ,#  # a# n# d#  # t# h# e#  # c# l# a# s# s#  # l# a# b# e# l#  # i# s#  # t# h# e#  # f# i# n# a# l#  # e# n# t# r# y# .#  # T# h# e#  # c# l# a# s# s#  # l# a# b# e# l# s#  # u# s# e# d#  # a# r# e#  # 0#  # (# n# e# g# a# t# i# v# e# )#  # a# n# d#  # 1#  # (# p# o# s# i# t# i# v# e# )# .# 
# 
# M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s#  # u# s# e# d#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # t# a# r# g# e# t#  # i# n#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # d# a# t# a# s# e# t#  # a# r# e# 
# 
# 1# -# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# 
# 2# -# R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# e# r#  # 
# 
# 3# -# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# 
# 
# t# h# e#  # g# i# t# h# u# b#  # r# e# p# o#  # t# o#  # t# h# i# s#  # s# a# m# e#  # d# a# t# a# s# e# t#  # c# a# n#  # b# e#  # f# o# u# n# d#  # h# e# r# e#  # h# t# t# p# s# :# /# /# g# i# t# h# u# b# .# c# o# m# /# s# i# d# 2# 6# r# a# n# j# a# n# /# p# u# l# s# a# r# -# s# t# a# r# 
# 
# a# l# s# o#  # c# h# e# c# k#  # o# u# t#  # m# y#  # o# t# h# e# r#  # k# e# r# n# e# l# s#  # a# n# d#  # g# i# t# h# u# b#  # r# e# p# o# s#  # h# t# t# p# s# :# /# /# g# i# t# h# u# b# .# c# o# m# /# s# i# d# 2# 6# r# a# n# j# a# n

# In[None]

import pandas as pd

# In[None]

data=pd.read_csv('../input/predicting-a-pulsar-star/pulsar_stars.csv')

# ## ## ## ## ## ##  # S# O# M# E#  # B# A# S# I# C#  # I# N# F# O# R# M# A# T# I# O# N#  # A# B# O# U# T#  # T# H# E#  # D# A# T# A#  # S# E# T

# In[None]

data.head()

# In[None]

data.columns

# In[None]

data.isnull().sum()

# In[None]

data.info()

# In[None]

data.describe()

# ## ## ## ## ## ##  # T# A# R# G# E# T#  #  # C# L# A# S# S

# In[None]

data['target_class'].unique()

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

sns.countplot(data['target_class'])

# In[None]

data[data['target_class']==1].count()

# In[None]

data[data['target_class']==0].count()

# In[None]

data.head()

# ## ## ## ## ## ##  # A# t# t# r# i# b# u# t# e#  # I# n# f# o# r# m# a# t# i# o# n# :# 
# 
# E# a# c# h#  # c# a# n# d# i# d# a# t# e#  # i# s#  # d# e# s# c# r# i# b# e# d#  # b# y#  # 8#  # c# o# n# t# i# n# u# o# u# s#  # v# a# r# i# a# b# l# e# s# ,#  # a# n# d#  # a#  # s# i# n# g# l# e#  # c# l# a# s# s#  # v# a# r# i# a# b# l# e# .#  # 
# 
# T# h# e#  # f# i# r# s# t#  # f# o# u# r#  # a# r# e#  # s# i# m# p# l# e#  # s# t# a# t# i# s# t# i# c# s#  # o# b# t# a# i# n# e# d#  # f# r# o# m#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# u# l# s# e#  # p# r# o# f# i# l# e#  # (# f# o# l# d# e# d#  # p# r# o# f# i# l# e# )# .# 
# 
# T# h# i# s#  # i# s#  # a# n#  # a# r# r# a# y#  # o# f#  # c# o# n# t# i# n# u# o# u# s#  # v# a# r# i# a# b# l# e# s#  # t# h# a# t#  # d# e# s# c# r# i# b# e#  # a#  # l# o# n# g# i# t# u# d# e# -# r# e# s# o# l# v# e# d#  # v# e# r# s# i# o# n#  # o# f#  # t# h# e#  # s# i# g# n# a# l#  # t# h# a# t#  # h# a# s#  # b# e# e# n#  # a# v# e# r# a# g# e# d#  # i# n#  # b# o# t# h#  # t# i# m# e#  # a# n# d#  # f# r# e# q# u# e# n# c# y#  # .# 
# 
# T# h# e#  # r# e# m# a# i# n# i# n# g#  # f# o# u# r#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # s# i# m# i# l# a# r# l# y#  # o# b# t# a# i# n# e# d#  # f# r# o# m#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # .#  # T# h# e# s# e#  # a# r# e#  # s# u# m# m# a# r# i# s# e# d#  # b# e# l# o# w# :# 
# 
# M# e# a# n#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# .# 
# 
# S# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# .# 
# 
# E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# .# 
# 
# S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# .# 
# 
# M# e# a# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# .# 
# 
# S# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# .# 
# 
# E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# .# 
# 
# S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# .# 
# 
# C# l# a# s# s

# ## ## ## ## ## ##  # C# O# R# R# E# L# A# T# I# O# N#  # B# E# T# W# E# E# N#  # T# H# E#  # F# E# A# T# U# R# E# S

# In[None]

correlation=data.corr()
fig = plt.figure(figsize=(12, 10))

sns.heatmap(correlation, annot=True, center=1)

# In[None]

y=data['target_class']

# In[None]

X=data.drop(['target_class'],axis=1)

# In[None]

X.head()

# In[None]

X.describe()

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# ## ## ## ## ## ##  # L# O# G# I# S# T# I# C#  # R# E# G# R# E# S# S# I# O# N# :

# In[None]

model=LogisticRegression()

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7603064.npy", { "accuracy_score": score })

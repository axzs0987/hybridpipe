import pandas as pd
# In[29]

# Call libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings    
import os
from sklearn.cross_validation import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score  
from sklearn.tree import DecisionTreeClassifier
from pandas import read_csv

# In[30]

warnings.filterwarnings("ignore")    # Ignore warnings
IBMData=pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')

# In[31]

IBMData.head()

# In[32]

IBMData.shape

# In[33]

pd.isnull(IBMData).sum()

# In[34]

for i in range(IBMData.shape[1]):
    print (IBMData.columns.values[i],":",np.unique(IBMData[IBMData.columns.values[i]]),"\n")


# ## ## ## ##  # *# *# I# n# f# e# r# e# n# c# e# :#  # *# *# 
# E# m# p# l# o# y# e# e# C# o# u# n# t# ,#  # O# v# e# r# 1# 8#  # &#  # S# t# a# n# d# a# r# d# H# o# u# r# s#  # h# a# v# e#  # t# h# e#  # s# a# m# e#  # v# a# l# u# e# s#  # f# o# r#  # a# l# l#  # e# m# p# l# o# y# e# e# s# ,#  # w# h# i# c# h#  # m# e# a# n# s#  # t# h# e# y#  # a# r# e#  # n# o# t#  # r# e# l# e# v# a# n# t#  # f# a# c# t# o# r# s#  # t# o#  # b# e#  # c# o# n# s# i# d# e# r# e# d#  # f# o# r#  # t# h# e#  # a# n# a# l# y# s# i# s# .#  # S# o#  # w# i# l# l#  # d# r# o# p#  # t# h# e# s# e#  # 3#  # c# o# l# u# m# n# s# .

# In[35]

IBMData=IBMData.drop(['EmployeeCount','Over18','StandardHours','DailyRate'],axis=1)

# ## ## ##  # C# l# e# a# n# s# e#  # t# h# e#  # d# a# t# a

# In[36]

IBMData=IBMData.replace({'Attrition':{'No':0,'Yes':1}})
IBMData=IBMData.replace({'Gender':{'Male':0,'Female':1}})
IBMData=IBMData.replace({'BusinessTravel':{'Non-Travel':0,'Travel_Rarely':1,'Travel_Frequently':2}})
IBMData=IBMData.replace({'Department':{'Human Resources':0,'Research & Development':1,'Sales':2}})
IBMData=IBMData.replace({'EducationField':{'Human Resources':0,'Life Sciences':1,'Marketing':2,'Medical':3,'Technical Degree':4,'Other':5}})
IBMData=IBMData.replace({'JobRole':{'Human Resources':0,'Healthcare Representative':1,'Laboratory Technician':2,'Manager':3,'Manufacturing Director':4,'Research Director':5,'Research Scientist':6,'Sales Executive':7,'Sales Representative':8}})
IBMData=IBMData.replace({'MaritalStatus':{'Single':0,'Married':1,'Divorced':2}}) 
IBMData=IBMData.replace({'OverTime':{'No':0,'Yes':1}})
IBMData['MonthlyIncome']=IBMData['MonthlyIncome']-min(IBMData['MonthlyIncome'])/(max(IBMData['MonthlyIncome'])-min(IBMData['MonthlyIncome']))
IBMData['MonthlyRate']=IBMData['MonthlyRate']-min(IBMData['MonthlyRate'])/(max(IBMData['MonthlyRate'])-min(IBMData['MonthlyRate']))
IBMData.shape

# In[37]

IBMData.head()

# In[38]

row=8
col=3
fig,ax = plt.subplots(row,col, figsize=(15,20))  # 'ax' has references to all the four axes
x=0
y=0
for i in range(IBMData.shape[1]):
    if(i!=1):
        sns.distplot(IBMData[IBMData.columns.values[i]], ax = ax[x,y])  # Plot on 1st axes 
        sns.boxplot(IBMData['Attrition'],IBMData[IBMData.columns.values[i]], ax = ax[x+1,y])  # Plot on 1st axes 
    y=y+1
    if(x<row-2 and y==col):
        x=x+2
        y=0
    if(x==row-2 and y==col):
        break
plt.show()


# In[39]

row=8
col=3
fig,ax = plt.subplots(row,col, figsize=(15,20))  # 'ax' has references to all the four axes
x=0
y=0
for i in range(12,IBMData.shape[1]):
    if(i!=1):
        sns.distplot(IBMData[IBMData.columns.values[i]], ax = ax[x,y])  # Plot on 1st axes 
        sns.boxplot(IBMData['Attrition'],IBMData[IBMData.columns.values[i]], ax = ax[x+1,y])  # Plot on 1st axes 
    y=y+1
    if(x<row-2 and y==col):
        x=x+2
        y=0
    if(x==row-2 and y==col):
        break
plt.show()

# In[40]

row=6
col=3
fig,ax = plt.subplots(row,col, figsize=(15,25))  # 'ax' has references to all the four axes
x=0
y=0
for i in range(24,IBMData.shape[1]):
    if(i!=1):
        sns.distplot(IBMData[IBMData.columns.values[i]], ax = ax[x,y])  # Plot on 1st axes 
        sns.boxplot(IBMData['Attrition'],IBMData[IBMData.columns.values[i]], ax = ax[x+1,y])  # Plot on 1st axes 
    y=y+1
    if(x<row-2 and y==col):
        x=x+2
        y=0
    if(x==row-2 and y==col):
        break
plt.show()

# ## ## ##  # *# *# C# o# n# c# l# u# s# i# o# n#  # :# *# *# 
# 1# .#  # T# h# e#  # p# e# r# c# e# n# t# a# g# e#  # o# f#  # e# m# p# l# o# y# e# e# s#  # g# o# i# n# g#  # f# o# r#  # b# u# s# i# n# e# s# s#  # t# r# a# v# e# l#  # i# s#  # h# i# g# h#  # w# h# i# c# h#  # d# i# r# e# c# t# l# y#  # c# o# n# t# r# i# b# u# t# e# s#  # t# o#  # i# n# c# r# e# a# s# e# d#  # r# a# t# e#  # o# f#  # a# t# t# r# i# t# i# o# n# .# 
# 2# .#  # D# i# s# t# a# n# c# e#  # f# r# o# m#  # o# f# f# i# c# e#  # i# s#  # a# n# o# t# h# e# r#  # f# a# c# t# o# r#  # w# h# i# c# h#  # i# m# p# a# c# t# s#  # t# h# e#  # r# a# t# e#  # o# f#  # a# t# t# r# i# t# i# o# n# .#  # F# a# r# t# h# e# r#  # t# h# e#  # d# i# s# t# a# n# c# e#  # f# r# o# m#  # o# f# f# i# c# e#  # m# o# r# e#  # i# s#  # t# h# e#  # a# t# t# r# i# t# i# o# n# .# 
# 3# .#  # L# o# w# e# r#  # t# h# e#  # e# n# v# i# r# o# n# m# e# n# t#  # s# a# t# i# s# f# a# c# t# i# o# n# ,#  # j# o# b#  # l# e# v# e# l# ,#  # j# o# b#  # r# o# l# e#  # &#  # j# o# b#  # s# a# t# i# s# f# a# c# t# i# o# n#  # h# i# g# h# e# r#  # t# h# e#  # a# t# t# r# i# t# i# o# n# .# 
# 4# .#  # L# o# w# e# r#  # t# h# e#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e#  # h# i# g# h# e# r#  # t# h# e#  # a# t# t# r# i# t# i# o# n# .# 
# 5# .#  # O# v# e# r# t# i# m# e#  # c# o# n# t# r# i# b# u# t# e# s#  # t# o#  # h# i# g# h# e# r#  # a# t# t# r# i# t# i# o# n# .# 
# 7# .#  # L# e# s# s# e# r#  # t# h# e#  # T# o# t# a# l# w# o# r# k# i# n# g# y# e# a# r# s# ,# y# e# a# r# s#  # a# t#  # c# o# m# p# a# n# y# ,#  # y# e# a# r# s#  # i# n#  # c# u# r# r# e# n# t#  # r# o# l# e#  # &#  # y# e# a# r# s#  # w# i# t# h#  # c# u# r# r# e# n# t#  # m# a# n# a# g# e# r# ,#  # m# o# r# e#  # i# s#  # t# h# e#  # a# t# t# r# i# t# i# o# n# .# 
# 
# F# o# r#  # b# u# i# l# d# i# n# g#  # t# h# e#  # m# o# d# e# l#  # r# e# m# o# v# e#  # t# h# e#  # f# i# e# l# d# s#  # w# h# i# c# h#  # d# o# n# '# t#  # h# a# v# e#  # m# a# j# o# r#  # i# m# p# a# c# t#  # o# n#  # a# t# t# r# i# t# i# o# n# ,#  # b# a# s# e# d#  # o# n#  # t# h# e#  # a# b# o# v# e#  # v# i# s# u# a# l# i# z# a# t# i# o# n# .

# In[41]

newIBMData = IBMData.drop(['Age','Department','Education','EducationField','JobInvolvement','MaritalStatus','MonthlyRate','NumCompaniesWorked','PercentSalaryHike','PerformanceRating', 'RelationshipSatisfaction','StockOptionLevel','TrainingTimesLastYear','WorkLifeBalance'],axis=1)       

# In[42]

df_y=newIBMData.loc[:,"Attrition"]
df_x=newIBMData.drop(["Attrition"],axis=1)
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(df_x, df_y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/494288.npy", { "accuracy_score": score })

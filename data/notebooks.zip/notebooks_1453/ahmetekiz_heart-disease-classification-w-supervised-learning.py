import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df = pd.read_csv("/kaggle/input/heart-disease-uci/heart.csv")  
df.info()
df.head()
import seaborn as sns
import matplotlib.pyplot as plt
labels = ['M' if i == 1 else 'F' for i in df.sex.value_counts().index]
colors = ['gray','red']
explode = [0,0.1]
sizes = [df.sex.value_counts().values]
#plt.figure(figsize = (8,8))
#plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%')   
#plt.title('Sex Ratio of Patients',color = 'blue',fontsize = 15)
#plt.show()
#plt.figure(figsize=(15,10))
#sns.countplot(df.age)
#plt.title("Age Distribution",color = 'black',fontsize=20)
#plt.show()
heart_disease = ['Has Heart Disease' if i == 0 else 'No Heart Disease' for i in df.target]
df_1 =  pd.DataFrame({'target':heart_disease})
#plt.figure(figsize=(10,7))
#sns.countplot(x = df_1.target)
#plt.ylabel('Count')
#plt.xlabel('Has Heart Disease or No Heart Disease')
#plt.title('Heart Disease Count',color = 'blue',fontsize=15)
#plt.show()
y = df.target.values
x_data = df.drop(["target"],axis=1)
x = ( x_data - np.min(x_data) ) / ( np.max(x_data) - np.min(x_data) ).values
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
accuracies = {} 
def save_score(name,score):
    """
    Parameters
    ----------
    name : Algorithm name
    score : Algorithm test score    
    Returns
    -------
    None.
    """
    accuracies[name] = score*100
    
    return None
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
#lr.fit(x_train,y_train)
#print("Test Accuracy {}".format(lr.score(x_test,y_test)))
#save_score( "Logistic Regression Classification",lr.score(x_test,y_test) )
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 3) 
#knn.fit(x_train,y_train)
#prediction = knn.predict(x_test)
#print(" {} nn score: {} ".format(3,knn.score(x_test,y_test)))
#save_score( "K-Nearest Neighbour (KNN) Classification",knn.score(x_test,y_test) )
score_list = []
for each in range(1,50):
    
    knn2 = KNeighborsClassifier(n_neighbors = each)
    
#    knn2.fit(x_train,y_train)
    
#    score_list.append(knn2.score(x_test,y_test))
    
#plt.figure(figsize=(30,6))   
#plt.plot(range(1,50),score_list)
#plt.xlabel("k values")
#plt.ylabel("accuracy")
#plt.show()
from sklearn.svm import SVC
svm = SVC(random_state = 1)
#svm.fit(x_train,y_train)
#print("print accuracy of svm algo: ",svm.score(x_test,y_test))
#save_score( "Support Vector Machine (SVM) Classification",svm.score(x_test,y_test) )
from sklearn.naive_bayes import GaussianNB
nb = GaussianNB()
#nb.fit(x_train,y_train)
#print("Accuracy of Naive Bayes Algo: ",nb.score(x_test,y_test))
#save_score( "Naive Bayes Classification",nb.score(x_test,y_test) )
from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier()
#dt.fit(x_train,y_train)
#print("score: ", dt.score(x_test,y_test))
#save_score( "Decision Tree Classification",dt.score(x_test,y_test) )
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(n_estimators = 100,random_state = 1)  
#rf.fit(x_train,y_train)
#print("random forest algo result: ",rf.score(x_test,y_test))
#accuracies["Random Forest Classification"] = [rf.score(x_test,y_test)*100]
#save_score( "Random Forest Classification",rf.score(x_test,y_test) )
#plt.figure(figsize=(30,8))
#sns.barplot(x = list( accuracies.keys() ), y = list( accuracies.values() ) )
#plt.show()
#y_lr_pred = lr.predict(x_test)
#y_knn_pred = knn.predict(x_test)
#y_svm_pred = svm.predict(x_test)
#y_nb_pred = nb.predict(x_test)
#y_dt_pred = dt.predict(x_test)
#y_rf_pred = rf.predict(x_test)
y_true = y_test
from sklearn.metrics import confusion_matrix
#cm_lr = confusion_matrix(y_true,y_lr_pred)
#cm_knn = confusion_matrix(y_true,y_knn_pred)
#cm_svm = confusion_matrix(y_true,y_svm_pred)
#cm_nb = confusion_matrix(y_true,y_nb_pred)
#cm_dt = confusion_matrix(y_true,y_dt_pred)
#cm_rf = confusion_matrix(y_true,y_rf_pred)
#plt.figure(figsize=(24,12))
#plt.suptitle("Confusion Matrixes",fontsize=24)
#plt.subplots_adjust(wspace = 0.4, hspace= 0.4)
#plt.subplot(2,3,1)
#plt.title("Logistic Regression Confusion Matrix")
#sns.heatmap(cm_lr,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.subplot(2,3,2)
#plt.title("K Nearest Neighbors Confusion Matrix")
#sns.heatmap(cm_knn,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.subplot(2,3,3)
#plt.title("Support Vector Machine Confusion Matrix")
#sns.heatmap(cm_svm,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.subplot(2,3,4)
#plt.title("Naive Bayes Confusion Matrix")
#sns.heatmap(cm_nb,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.subplot(2,3,5)
#plt.title("Decision Tree Classifier Confusion Matrix")
#sns.heatmap(cm_dt,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.subplot(2,3,6)
#plt.title("Random Forest Confusion Matrix")
#sns.heatmap(cm_rf,annot=True,cmap="Blues",fmt="d",cbar=False, annot_kws={"size": 24})
#plt.show()




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ahmetekiz_heart-disease-classification-w-supervised-learning.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ahmetekiz_heart-disease-classification-w-supervised-learning/testY.csv",encoding="gbk")


import pandas as pd
# P# r# o# b# l# e# m#  # s# t# a# t# e# m# e# n# t# 
# =# =# 
# 
# I# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # f# o# r#  # B# a# n# k#  # a# n# d#  # L# e# n# d# e# r# s#  # t# o#  # e# n# s# u# r# e#  # t# h# a# t#  # t# h# e# y#  # d# o# n# ’# t#  # g# i# v# e#  # l# o# a# n# s#  # t# o#  # p# e# o# p# l# e#  # w# h# o#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # d# e# f# a# u# l# t# .#  # T# h# e#  # H# o# m# e#  # E# q# u# i# t# y#  # d# a# t# a#  # s# e# t#  # c# o# n# t# a# i# n# s#  # i# n# f# o# r# m# a# t# i# o# n#  # r# e# l# a# t# e# d#  # t# o#  # h# o# m# e#  # e# q# u# i# t# y#  # f# o# r#  # a# b# o# u# t#  # s# i# x#  # t# h# o# u# s# a# n# d#  # l# o# a# n# s#  # g# i# v# e# n#  # o# u# t#  # i# n#  # p# a# s# t# .#  # T# h# i# s#  # d# a# t# a#  # c# o# n# t# a# i# n# s#  # v# a# r# i# o# u# s#  # i# n# f# o# r# m# a# t# i# o# n#  # r# e# g# a# r# d# i# n# g#  # c# u# s# t# o# m# e# r# ’# s#  # s# i# t# u# a# t# i# o# n#  # a# t#  # t# h# e#  # t# i# m# e#  # o# f#  # l# o# a# n#  # a# n# d#  # a# l# s# o#  # c# o# n# t# a# i# n# s#  # a#  # c# o# l# u# m# n#  # '# B# A# D# '#  # w# h# i# c# h#  # i# n# d# i# c# a# t# e# s#  # w# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # l# a# t# e# r#  # o# n#  # d# e# f# a# u# l# t# e# d#  # o# n#  # t# h# e#  # l# o# a# n# .#  # W# e#  # c# a# n#  # u# s# e#  # t# h# i# s#  # d# a# t# a#  # s# e# t#  # a# l# o# n# g#  # w# i# t# h#  # t# h# e#  # v# a# r# i# a# b# l# e#  # ‘# B# A# D# ’#  # t# o#  # t# r# a# i# n#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l# s#  # w# h# i# c# h#  # w# o# u# l# d#  # h# e# l# p#  # u# s#  # p# r# e# d# i# c# t#  # t# h# e#  # l# i# k# e# l# i# h# o# o# d#  # o# f#  # s# o# m# e# o# n# e#  # d# e# f# a# u# l# t# i# n# g#  # t# h# e#  # l# o# a# n#  # i# n#  # f# u# t# u# r# e#  # b# a# s# e# d#  # o# n#  # t# h# e# i# r#  # c# u# r# r# e# n# t#  # s# i# t# u# a# t# i# o# n# .# 
# 
# T# h# i# s#  # n# o# t# e# b# o# o# k#  # p# r# o# v# i# d# e# s#  # a# n#  # a# n# a# l# y# s# i# s#  # o# f#  # t# h# e#  # H# o# m# e#  # E# q# u# i# t# y#  # d# a# t# a# s# e# t#  # a# n# d#  # p# r# o# p# o# s# e# s#  # t# h# e#  # b# e# s# t#  # m# o# d# e# l#  # t# o#  # u# s# e#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # p# e# o# p# l# e#  # w# h# o#  # m# a# y#  # d# e# f# a# u# l# t#  # b# y#  # a# n# a# l# y# s# i# n# g#  # t# h# e# i# r#  # c# u# r# r# e# n# t#  # s# i# t# u# a# t# i# o# n# .#  # T# h# i# s#  # p# r# o# b# l# e# m#  # c# a# n#  # b# e#  # c# a# t# e# g# o# r# i# z# e# d#  # a# s#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # a# s#  # t# h# e#  # m# o# d# e# l#  # w# i# l# l#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # w# o# u# l# d#  # d# e# f# a# u# l# t# .# 


# H# y# p# o# t# h# e# s# i# s#  # G# e# n# e# r# a# t# i# o# n# 
# =# =# 
# 
# S# o# m# e#  # o# f#  # t# h# e#  # f# a# c# t# o# r# s#  # w# h# i# c# h#  # c# a# n#  # a# f# f# e# c# t#  # t# h# e#  # B# A# D#  # (# t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # f# o# r#  # t# h# i# s#  # l# o# a# n#  # d# e# f# a# u# l# t# e# r#  # p# r# o# b# l# e# m# )#  # a# r# e# :# 
# *#  # M# o# r# t# g# a# g# e#  # d# u# e# :#  # A# p# p# l# i# c# a# n# t# s#  # w# i# t# h#  # l# e# s# s#  # a# m# o# u# n# t#  # l# e# f# t#  # o# n#  # m# o# r# t# g# a# g# e#  # s# h# o# u# l# d#  # h# a# v# e#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # n# o# t#  # d# e# f# a# u# l# t# i# n# g#  # o# n#  # f# u# t# u# r# e#  # l# o# a# n# s# 
# *#  # L# o# a# n#  # a# m# o# u# n# t# :#  # A# p# p# l# i# c# a# n# t# s#  # w# i# t# h#  # l# e# s# s#  # a# m# o# u# n# t#  # o# f#  # l# o# a# n#  # r# e# q# u# e# s# t# e# d#  # s# h# o# u# l# d#  # h# a# v# e#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # n# o# t#  # d# e# f# a# u# l# t# i# n# g#  # o# n#  # f# u# t# u# r# e#  # l# o# a# n# 
# *#  # V# a# l# u# e#  # o# f#  # c# u# r# r# e# n# t#  # p# r# o# p# e# r# t# y# :#  # I# f#  # t# h# e#  # v# a# l# u# e#  # o# f#  # t# h# e#  # c# u# r# r# e# n# t#  # p# r# o# p# e# r# t# y#  # i# s#  # l# e# s# s#  # t# h# e# n#  # t# h# e# r# e#  # s# h# o# u# l# d#  # b# e#  # l# e# s# s#  # c# h# a# n# c# e# s#  # o# f#  # b# e# i# n# g#  # a#  # d# e# f# a# u# l# t# e# r#  # o# n#  # f# u# t# u# r# e#  # l# o# a# n# s# 
# *#  # R# e# a# s# o# n# :#  # T# h# e#  # r# e# a# s# o# n#  # f# o# r#  # t# a# k# i# n# g#  # o# u# t#  # t# h# e#  # l# o# a# n#  # m# i# g# h# t#  # a# l# s# o#  # h# a# v# e#  # a# n#  # i# m# p# a# c# t#  # o# n#  # t# h# e#  # c# h# a# n# c# e#  # o# f#  # g# o# i# n# g#  # i# n#  # d# e# f# a# u# l# t# 
# *#  # N# u# m# b# e# r#  # o# f#  # d# e# l# i# n# q# u# e# n# t#  # l# o# a# n# s# :#  # I# f#  # a#  # p# e# r# s# o# n#  # h# a# s#  # a# l# r# e# a# d# y#  # b# e# e# n#  # d# e# l# i# n# q# u# e# n# t#  # i# n#  # p# a# s# t#  # f# o# r#  # a#  # n# u# m# b# e# r#  # o# f#  # t# i# m# e# s#  # t# h# e# n#  # t# h# e# r# e#  # w# o# u# l# d#  # b# e#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # d# e# f# a# u# l# t# 
# *#  # N# u# m# b# e# r#  # o# f#  # d# e# r# o# g# a# t# o# r# y#  # r# e# p# o# r# t# s# :#  # D# e# r# o# g# a# t# o# r# y#  # r# e# p# o# r# t# s#  # a# r# e#  # a# l# w# a# y# s#  # a#  # n# e# g# a# t# i# v# e#  # s# i# g# n#  # o# n#  # t# h# e#  # c# r# e# d# i# t#  # h# i# s# t# o# r# y#  # a# n# d#  # a# n# y#  # n# u# m# b# e# r#  # i# n#  # t# h# i# s#  # c# o# l# u# m# n#  # s# h# o# u# l# d#  # i# n# d# i# c# a# t# e#  # h# i# g# h#  # c# h# a# n# c# e#  # o# f#  # d# e# f# a# u# l# t# i# n# g#  # i# n#  # f# u# t# u# r# e# 
# *#  # C# r# e# d# i# t#  # l# i# n# e#  # a# g# e# :#  # T# h# i# s#  # i# n# d# i# c# a# t# e# s#  # t# h# e#  # a# g# e#  # o# f#  # o# l# d# e# s# t#  # c# r# e# d# i# t#  # a# p# p# r# o# v# e# d#  # a# n# d#  # t# h# e#  # o# l# d# e# r#  # t# h# i# s#  # i# s#  # t# h# e#  # l# e# s# s#  # l# i# k# e# l# y#  # i# t#  # w# i# l# l#  # b# e#  # f# o# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # t# o#  # d# e# f# a# u# l# t# 
# *#  # D# e# b# t#  # t# o#  # i# n# c# o# m# e#  # r# a# t# i# o# :#  # I# f#  # a#  # p# e# r# s# o# n#  # h# a# s#  # h# i# g# h#  # d# e# b# t#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # i# n# c# o# m# e#  # t# h# e# n#  # i# t#  # w# o# u# l# d#  # b# e#  # d# i# f# f# i# c# u# l# t#  # f# o# r#  # t# h# a# t#  # p# e# r# s# o# n#  # t# o#  # p# a# y#  # b# a# c# k#  # m# o# r# e#  # d# e# b# t#  # s# o#  # a#  # h# i# g# h#  # n# u# m# b# e# r#  # i# n#  # t# h# i# s#  # w# o# u# l# d#  # i# n# d# i# c# a# t# e#  # a#  # d# e# f# a# u# l# t# e# r

# U# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # d# a# t# a# 
# =# =

# In[None]

#import the packages

import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
print(os.listdir("../input")) #list the files in the input directory
df=pd.read_csv('../input/hmeq.csv') #import the dataset
columnNames = pd.Series(df.columns.values) # to check the columns/variables/features present in our data set

# In[None]

df.head(5) # to see the first 5 rows of dataset


# In[None]

df.shape #to look at the shape of the dataset

# I# t#  # s# h# o# w# s#  # t# h# a# t#  # t# h# e#  # d# a# t# a# s# e# t#  # h# a# s#  # 5# 9# 6# 0#  # r# o# w# s# (# o# b# s# e# r# v# a# t# i# o# n# s# )#  # a# n# d#  # 1# 3#  # c# o# l# u# m# n# s#  # (# v# a# r# i# a# b# l# e# s# /# f# e# a# t# u# r# e# s# )

# In[None]

#descriptive statistics
description= df.describe(include='all') # to get the basic summary of all the numeric columns and frequency distribution of all the categorical columns.
description

# In[None]

data_types=df.dtypes #to print data types for each variable
data_types

# M# i# s# s# i# n# g#  # V# a# l# u# e# s# 
# =# =

# In[None]

MissingData=df.isnull().sum().rename_axis('Variables').reset_index(name='Missing Values') # the isnull() returns 1 if the value is null
MissingData

# In[None]

#dropping rows that have missing data
df.dropna(axis=0, how='any', inplace=True)
df


# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # (# E# D# A# )# 
# =# =

# *# *# U# n# i# v# a# r# i# a# t# e#  # A# n# a# l# y# s# i# s# *# *# 
# 
# I# n#  # t# h# i# s#  # a# n# a# l# y# s# i# s#  # w# e#  # e# x# a# m# i# n# e#  # e# a# c# h#  # v# a# r# i# a# b# l# e#  # i# n# d# i# v# i# d# u# a# l# l# y# .#  # F# o# r#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # w# e#  # c# a# n#  # u# s# e#  # b# a# r#  # p# l# o# t# s#  # w# h# i# c# h#  # c# a# l# c# u# l# a# t# e# s#  # t# h# e#  # t# o# t# a# l#  # c# o# u# n# t#  # o# f#  # e# a# c# h#  # c# a# t# e# g# o# r# y#  # i# n#  # a#  # p# a# r# t# i# c# u# l# a# r#  # v# a# r# i# a# b# l# e# .#  # F# o# r#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # w# e#  # c# a# n#  # u# s# e#  # h# i# s# t# o# g# r# a# m# s#  # o# r#  # p# r# o# b# a# b# i# l# i# t# y#  # d# e# n# s# i# t# y#  # p# l# o# t# s#  # t# o#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# h# e#  # v# a# r# i# a# b# l# e# .

# In[None]

#Frequency distribution of target variable "BAD" and visualizing the target variable
df["BAD"].value_counts().plot.bar(title='BAD')

# I# t#  # s# h# o# w# s#  # t# h# a# t#  # 2# 0# %#  # a# r# e#  # d# e# f# a# u# l# t# e# r# s#  # a# n# d#  # 8# 0# %#  # a# r# e#  # n# o# n#  # d# e# f# u# l# t# e# r# s

# In[None]

#visualizing the categorical variable REASON
REASON_count= df["REASON"].value_counts().rename_axis('REASON').reset_index(name='Total Count')
df["REASON"].value_counts().plot.bar(title='REASON')


# In[None]

#visualizing the categorical variable JOB
JOB_count= df["JOB"].value_counts().rename_axis('JOB').reset_index(name='Total Count')
df["JOB"].value_counts().plot.bar(title='JOB')

# In[None]

# visualizing numeric variables using seaborn
f, axes = plt.subplots(3, 3, figsize=(25,25))
sns.distplot( df["LOAN"] , color="skyblue", ax=axes[0, 0])
sns.distplot( df["DEBTINC"] , color="olive", ax=axes[0, 1])
sns.distplot( df["MORTDUE"] , color="orange", ax=axes[0, 2])
sns.distplot( df["YOJ"] , color="yellow", ax=axes[1, 0])
sns.distplot( df["VALUE"] , color="pink", ax=axes[1, 1])
sns.distplot( df["DELINQ"] , color="red", ax=axes[1, 2])
sns.distplot( df["DEROG"] , color="green", ax=axes[2, 0])
sns.distplot( df["CLAGE"] , color="gold", ax=axes[2, 1])
sns.distplot( df["CLNO"] , color="teal", ax=axes[2, 2])

# *# *# B# i# v# a# r# i# a# t# e#  # A# n# a# l# y# s# i# s# *# *# 
# 
# I# n#  # t# h# i# s#  # a# n# a# l# y# s# i# s#  # w# e#  # e# x# p# l# o# r# e#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # o# f#  # e# a# c# h#  # v# a# r# i# a# b# l# e#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .#  # W# e#  # c# a# n#  # a# l# s# o#  # c# h# e# c# k#  # o# u# r#  # h# y# p# o# t# h# e# s# i# s#  # u# s# i# n# g#  # b# i# v# a# r# i# a# t# e#  # a# n# a# l# y# s# i# s# .

# *# *# C# a# t# e# g# o# r# i# c# a# l#  # a# n# d#  # T# a# r# g# e# t#  # V# a# r# i# a# b# l# e#  # R# e# l# a# t# i# o# n# s# h# i# p# *# *

# In[None]


JOB=pd.crosstab(df['JOB'],df['BAD'])
JOB.div(JOB.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True, title='JOB vs BAD', figsize=(4,4))


# In[None]

REASON=pd.crosstab(df['REASON'],df['BAD'])
REASON.div(REASON.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True, title='REASON vs BAD', figsize=(4,4))

# In[None]

# visualizing numeric variables using seaborn
f, axes = plt.subplots(3, 3, figsize=(25,25))
sns.distplot( df["LOAN"] , color="skyblue", ax=axes[0, 0])
sns.distplot( df["DEBTINC"] , color="olive", ax=axes[0, 1])
sns.distplot( df["MORTDUE"] , color="orange", ax=axes[0, 2])
sns.distplot( df["YOJ"] , color="yellow", ax=axes[1, 0])
sns.distplot( df["VALUE"] , color="pink", ax=axes[1, 1])
sns.distplot( df["DELINQ"] , color="red", ax=axes[1, 2])
sns.distplot( df["DEROG"] , color="green", ax=axes[2, 0])
sns.distplot( df["CLAGE"] , color="gold", ax=axes[2, 1])
sns.distplot( df["CLNO"] , color="teal", ax=axes[2, 2])

# *# *# N# u# m# e# r# i# c#  # a# n# d#  # T# a# r# g# e# t#  # V# a# r# i# a# b# l# e#  # R# e# l# a# t# i# o# n# s# h# i# p# *# *

# In[None]


dfWithBin = df.copy()
bins=[0,15000,25000,90000] 
group=['Low','Average','High'] 
dfWithBin['LOAN_bin']=pd.cut(df['LOAN'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['LOAN_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Realtionship between Amount of Loan requested and the target variable BAD')
plt.xlabel('LOAN')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,47000,92000,400000] 
group=['Low','Average','High'] 
dfWithBin['MORTDUE_bin']=pd.cut(dfWithBin['MORTDUE'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['MORTDUE_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Realtionship between the Amount due on existing mortgage and the target variable BAD')
plt.xlabel('MORTDUE')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,68000,120000,860000] 
group=['Low','Average','High'] 
dfWithBin['VALUE_bin']=pd.cut(dfWithBin['VALUE'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['VALUE_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Realtionship between the value of the current property and the target variable BAD')
plt.xlabel('VALUE')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,3,15] 
group=['Low','High'] 
dfWithBin['DELINQ_bin']=pd.cut(dfWithBin['DELINQ'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['DELINQ_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Relationship of Number of Delinquent credit lines with the target variable')
plt.xlabel('DELINQ')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,2,15] 
group=['Low','High'] 
dfWithBin['DEROG_bin']=pd.cut(dfWithBin['DEROG'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['DEROG_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Relationship of Number of major derogatory reports with the target variable')
plt.xlabel('DEROG')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,120,230,1170] 
group=['Low','Average','High'] 
dfWithBin['CLAGE_bin']=pd.cut(dfWithBin['CLAGE'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['CLAGE_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Relationship  of Age of oldest tradeline in months with the target variable')
plt.xlabel('CLAGE')
P= plt.ylabel('Percentage')

# In[None]

bins=[0,40,204] 
group=['Low','High'] 
dfWithBin['DEBTINC_bin']=pd.cut(dfWithBin['DEBTINC'],bins,labels=group)
LOAN_bin=pd.crosstab(dfWithBin['DEBTINC_bin'],dfWithBin['BAD'])
LOAN_bin.div(LOAN_bin.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True,title='Debt to Income ratio realtionship with target variable')
plt.xlabel('DEBTINC')
P= plt.ylabel('Percentage')

# T# h# e# s# e#  # s# t# a# c# k# e# d#  # b# a# r#  # p# l# o# t# s#  # s# h# o# w# :# 
# 
# *#  # T# h# e#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # d# e# f# a# u# l# t# e# r# s#  # o# r#  # n# o# n#  # d# e# f# a# u# l# t# e# r# s#  # i# n#  # e# a# c# h#  # c# a# t# e# g# o# r# y#  # o# f#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# 
# *#  # T# h# e#  # p# r# o# p# o# r# t# i# o# n#  # f# o# r#  # d# e# f# a# u# l# t# e# r# s#  # h# a# v# i# n# g#  # S# a# l# e# s#  # j# o# b#  # i# s#  # h# i# g# h# e# r# 
# *#  # T# h# e# r# e#  # i# s#  # n# o# t# h# i# n# g#  # s# i# g# n# i# f# i# c# a# n# t#  # t# h# a# t#  # w# e#  # c# a# n#  # i# n# f# e# r#  # f# r# o# m#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # d# e# f# a# u# l# t# e# r# s#  # h# a# v# i# n# g#  # a#  # d# i# f# f# e# r# e# n# t#  # r# e# a# s# o# n#  # f# o# r#  # t# a# k# i# n# g#  # o# u# t#  # l# o# a# n

# In[None]

#Create Correlation matrix
corr = df.corr()
#Plot figsize
fig, ax = plt.subplots(figsize=(10,8))
#Generate Color Map
colormap = sns.diverging_palette(220, 10, as_cmap=True)
#Generate Heat Map, allow annotations and place floats in map
sns.heatmap(corr, cmap=colormap, annot=True, fmt=".2f")
#Apply xticks
plt.xticks(range(len(corr.columns)), corr.columns);
#Apply yticks
plt.yticks(range(len(corr.columns)), corr.columns)
#show plot
plt.show()

# T# h# i# s#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # s# h# o# w# s#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # a# l# l#  # t# h# e#  # n# u# m# e# r# i# c#  # v# a# r# i# a# b# l# e# s# .# 
# 
# T# h# e#  # i# n# t# e# r# e# s# t# i# n# g#  # c# o# r# r# e# l# a# t# i# o# n#  # t# h# a# t#  # w# e#  # c# a# n#  # s# e# e#  # i# s#  # t# h# a# t#  # B# A# D#  # (# t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# )#  # i# s#  # p# o# s# i# t# i# v# e# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # D# E# L# I# N# Q# ,#  # D# E# R# O# G#  # a# n# d#  # D# E# B# T# I# N# C

# D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g# 
# =# =

# *# *# E# n# c# o# d# i# n# g# *# *# 
# 
# A# s#  # m# a# n# y#  # o# f#  # t# h# e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # m# o# d# e# l# s#  # t# a# k# e# s#  # o# n# l# y#  # t# h# e#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # a# s#  # i# n# p# u# t#  # s# o#  # w# e#  # h# a# v# e#  # t# o#  # c# o# n# v# e# r# t#  # c# a# t# e# g# o# r# i# c# a# l#  # c# o# l# u# m# n# s#  # t# o#  # n# u# m# e# r# i# c# 
# D# u# m# m# y#  # v# a# r# i# a# b# l# e#  # t# u# r# n# s#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # i# n# t# o#  # a#  # s# e# r# i# e# s#  # o# f#  # 0#  # a# n# d#  # 1# ,#  # m# a# k# i# n# g#  # t# h# e# m#  # m# u# c# h#  # e# a# s# i# e# r#  # t# o#  # c# o# m# p# a# r# e

# In[None]

#encoding
df=pd.get_dummies(df, columns=['REASON','JOB'])
df


#  # W# e#  # c# a# n#  # u# s# e#  # s# c# i# k# i# t# -# l# e# a# r# n#  # (# s# k# l# e# a# r# n# )#  # f# o# r#  # m# a# k# i# n# g#  # d# i# f# f# e# r# e# n# t#  # m# o# d# e# l# s# .#  # I# t#  # r# e# q# u# i# r# e# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # i# n#  # a#  # s# e# p# a# r# a# t# e#  # d# a# t# a# s# e# t#  

# In[None]

# Extract independent and target variables
X = df.drop(['BAD'], axis=1)
y = df['BAD']

# *# *# D# a# t# a#  # N# o# r# m# a# l# i# z# a# t# i# o# n# *# *# 
# 
# s# o# m# e#  # o# f#  # t# h# e#  # c# o# l# u# m# n# s#  # i# n#  # X#  # h# a# v# e#  # l# a# r# g# e#  # v# a# r# i# a# n# c# e#  # i# n#  # t# h# e#  # n# u# m# e# r# i# c#  # d# a# t# a#  # i# n#  # t# h# e# m#  # s# o#  # s# t# a# n# d# a# r# d#  # s# c# a# l# i# n# g#  # i# s#  # d# o# n# e#  # t# o#  # n# o# r# m# a# l# i# z# e#  # t# h# e# m

# In[None]

#Scaling
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X = pd.DataFrame(sc_X.fit_transform(X), columns=X.columns)

# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# =# =# 
# 
# L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # o# r#  # t# h# e#  # l# o# g# i# t#  # m# o# d# e# l#  # i# s#  # o# n# e#  # o# f#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # t# e# c# h# n# i# q# u# e# s#  # a# n# d#  # i# s#  # d# e# f# i# n# e# d#  # a# s#  # a#  # t# y# p# e#  # o# f#  # r# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l#  # w# h# e# r# e#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # i# s#  # b# i# n# a# r# y#  # f# o# r#  # e# x# a# m# p# l# e#  # h# a# v# i# n# g#  # o# n# l# y#  # t# w# o#  # v# a# l# u# e# s#  # s# u# c# h#  # a# s#  # d# e# f# a# u# l# t#  # /# n# o# t#  # d# e# f# a# u# l# t# ,#  # f# r# a# u# d#  # /# n# o# t#  # f# r# a# u# d#  # e# t# c# .# I# n#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n# ,#  # t# h# e#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # a#  # b# i# n# a# r# y#  # o# u# t# c# o# m# e#  # i# s#  # p# r# e# d# i# c# t# e# d# .# 
# F# o# r#  # b# u# i# l# d# i# n# g#  # t# h# e#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l#  # s# p# l# i# t#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t# .#  # A# l# s# o#  # u# s# e# d#  # K# F# o# l# d#  # c# r# o# s# s#  # v# a# l# i# d# a# t# i# o# n#  # t# o#  # r# a# n# d# o# m# l# y#  # s# p# l# i# t#  # t# h# e#  # e# n# t# i# r# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # k# -# f# o# l# d# s

# F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n#  # u# s# i# n# g#  # R# F# E#  # f# o# r#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # M# o# d# e# l# 
# =# =# 
# 
# F# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # i# s#  # a#  # p# r# o# c# e# s# s#  # o# f#  # s# e# l# e# c# t# i# n# g#  # t# h# e#  # f# e# a# t# u# r# e# s#  # i# n#  # t# h# e#  # d# a# t# a#  # t# h# a# t#  # c# o# n# t# r# i# b# u# t# e#  # t# h# e#  # m# o# s# t#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # t# a# r# g# e# t#  # a# t# t# r# i# b# u# t# e# .#  # T# h# e#  # R# e# c# u# r# s# i# v# e#  # F# e# a# t# u# r# e#  # E# l# i# m# i# n# a# t# i# o# n#  # (# R# F# E# )#  # m# e# t# h# o# d#  # i# s#  # a#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # a# p# p# r# o# a# c# h# .#  # I# t#  # w# o# r# k# s#  # b# y#  # r# e# c# u# r# s# i# v# e# l# y#  # r# e# m# o# v# i# n# g#  # a# t# t# r# i# b# u# t# e# s#  # a# n# d#  # b# u# i# l# d# i# n# g#  # a#  # m# o# d# e# l#  # o# n#  # r# e# m# a# i# n# i# n# g#  # a# t# t# r# i# b# u# t# e# s# .#  # S# o# m# e#  # o# f#  # i# t# s#  # b# e# n# e# f# i# t# s#  # a# r# e# :# 
# *#  # r# e# d# u# c# e# s#  # o# v# e# r# f# i# t# t# i# n# g# 
# *#  # I# m# p# r# o# v# e# s#  # a# c# c# u# r# a# c# y# 
# *#  # R# e# d# u# c# e# s#  # t# r# a# i# n# i# n# g#  # t# i# m# e# 
# 


# In[None]

#RFE with the logistic regression algorithm to select the top 4 features. 
#import classifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
model = LogisticRegression()
rfe = RFE(model, 4)
fit = rfe.fit(X, y)
no_of_features = fit.n_features_
support_features = fit.support_
ranking_features = fit.ranking_
print("Num Features: %d" % (no_of_features))
print("Selected Features: %s" % (support_features))
print("Feature Ranking: %s" % (ranking_features))
X_sub = X.iloc[:,support_features] #updated X with the top 4 features

# T# h# e#  # R# F# E#  # r# e# t# u# r# n# s#  # t# h# e#  # t# o# p#  # 4#  # f# e# a# t# u# r# e# s# /# i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# s# :#  # D# E# R# O# G# ,# D# E# L# I# N# Q# ,# C# L# A# G# E# ,# D# E# B# T# I# N# C# 
# 
# T# h# e# r# e# f# o# r# e# ,#  # X# =#  # D# E# R# O# G# ,# D# E# L# I# N# Q# ,# C# L# A# G# E# ,# D# E# B# T# I# N# C# 
#  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  # Y# =#  # B# A# D# 
# 
# I# n#  # r# a# n# d# o# m#  # f# o# r# e# s# t#  # m# o# d# e# l#  # a# n# d#  # d# e# c# i# s# i# o# n#  # t# r# e# e# s# ,#  # v# a# r# i# a# b# l# e# /# f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # i# s#  # d# o# n# e#  # a# u# t# o# m# a# t# i# c# a# l# l# y#  # b# y#  # s# p# l# i# t# t# i# n# g#  # t# h# e#  # t# o# p#  # n# o# d# e# s#  # b# a# s# e# d#  # o# n#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # o# f#  # t# h# e#  # d# a# t# a

# P# e# r# f# o# r# m# a# n# c# e# /# E# v# a# l# u# a# t# i# o# n#  # m# e# t# r# i# c# s#  # o# f#  # t# h# e#  # m# o# d# e# l# s# 
# =# =# 
# 
# *# *# C# o# n# f# u# s# i# o# n#  # M# a# t# r# i# x# *# *# 
# 
# A#  # c# o# n# f# u# s# i# o# n#  # m# a# t# r# i# x#  # i# s#  # a#  # s# u# m# m# a# r# y#  # o# f#  # p# r# e# d# i# c# t# i# o# n#  # r# e# s# u# l# t# s#  # o# n#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# .#  # A#  # c# o# n# f# u# s# i# o# n#  # m# a# t# r# i# x#  # f# o# r#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # s# h# o# w# s#  # t# h# e#  # f# o# u# r#  # d# i# f# f# e# r# e# n# t#  # o# u# t# c# o# m# e# s# :#  # t# r# u# e#  # p# o# s# i# t# i# v# e# ,#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e# ,#  # t# r# u# e#  # n# e# g# a# t# i# v# e# ,#  # a# n# d#  # f# a# l# s# e#  # n# e# g# a# t# i# v# e# .#  # T# h# e#  # a# c# t# u# a# l#  # v# a# l# u# e# s#  # f# o# r# m#  # t# h# e#  # c# o# l# u# m# n# s# ,#  # a# n# d#  # t# h# e#  # p# r# e# d# i# c# t# e# d#  # v# a# l# u# e# s#  # (# l# a# b# e# l# s# )#  # f# o# r# m#  # t# h# e#  # r# o# w# s# .# 
# 
# !# [# i# m# a# g# e# .# p# n# g# ]# (# a# t# t# a# c# h# m# e# n# t# :# i# m# a# g# e# .# p# n# g# )# 
# 
# *# *# A# c# c# u# r# a# c# y# *# *# 
# 
# •# 	# T# r# u# e#  # P# o# s# i# t# i# v# e#  # -#  # T# a# r# g# e# t# s#  # w# h# i# c# h#  # a# r# e#  # a# c# t# u# a# l# l# y#  # t# r# u# e# (# Y# )#  # a# n# d#  # w# e#  # a# l# s# o#  # p# r# e# d# i# c# t# e# d#  # t# h# e# m#  # t# r# u# e# (# Y# )# 
# •# 	# T# r# u# e#  # N# e# g# a# t# i# v# e#  # -#  # T# a# r# g# e# t# s#  # w# h# i# c# h#  # a# r# e#  # a# c# t# u# a# l# l# y#  # f# a# l# s# e# (# N# )#  # a# n# d#  # w# e#  # a# l# s# o#  # p# r# e# d# i# c# t# e# d#  # t# h# e# m#  # f# a# l# s# e# (# N# )# 
# •# 	# F# a# l# s# e#  # P# o# s# i# t# i# v# e#  # -#  # T# a# r# g# e# t# s#  # w# h# i# c# h#  # a# r# e#  # a# c# t# u# a# l# l# y#  # f# a# l# s# e# (# N# )#  # b# u# t#  # w# e#  # p# r# e# d# i# c# t# e# d#  # t# h# e# m#  # t# r# u# e# (# T# )# 
# •# 	# F# a# l# s# e#  # N# e# g# a# t# i# v# e#  # -#  # T# a# r# g# e# t# s#  # w# h# i# c# h#  # a# r# e#  # a# c# t# u# a# l# l# y#  # t# r# u# e# (# T# )#  # b# u# t#  # w# e#  # p# r# e# d# i# c# t# e# d#  # t# h# e# m#  # f# a# l# s# e# (# N# )# 
# W# e#  # c# a# n#  # c# a# l# c# u# l# a# t# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # o# f#  # t# h# e#  # m# o# d# e# l#  # u# s# i# n# g#  # t# h# e# s# e#  # v# a# l# u# e# s#  # o# f#  # c# o# n# f# u# s# i# o# n#  # m# a# t# r# i# x# .#  # T# h# e#  # a# c# c# u# r# a# c# y#  # i# s#  # g# i# v# e# n#  # b# y# :# 
# 
# A# c# c# u# r# a# c# y# =#  # T# P#  # +#  # T# N#  # /#  # (# T# P#  # +#  # T# N#  # +#  # F# P#  # +#  # F# N# )# 
# 
# *# *# P# r# e# c# i# s# i# o# n#  # *# *# 
# 
# P# r# e# c# i# s# i# o# n#  # i# s#  # a#  # m# e# a# s# u# r# e#  # o# f#  # c# o# r# r# e# c# t# n# e# s# s#  # a# c# h# i# e# v# e# d#  # i# n#  # t# r# u# e#  # p# r# e# d# i# c# t# i# o# n#  # i# .# e# .#  # i# t#  # c# a# l# c# u# l# a# t# e# s#  # o# u# t#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s#  # l# a# b# e# l# e# d#  # a# s#  # t# r# u# e# ,#  # h# o# w#  # m# a# n# y#  # o# f#  # t# h# e# m#  # a# r# e#  # a# c# t# u# a# l# l# y#  # t# r# u# e# .# P# r# e# c# i# s# i# o# n#  # i# s#  # a#  # g# o# o# d#  # m# e# a# s# u# r# e#  # t# o#  # d# e# t# e# r# m# i# n# e# ,#  # w# h# e# n#  # t# h# e#  # c# o# s# t# s#  # o# f#  # F# a# l# s# e#  # P# o# s# i# t# i# v# e#  # i# s#  # h# i# g# h# .# 
# 
# P# r# e# c# i# s# i# o# n#  # =#  # T# P#  # /#  # (# T# P#  # +#  # F# P# )# 
# 
# *# *# R# e# c# a# l# l# *# *# 
# 
# R# e# c# a# l# l#  # i# s#  # a#  # m# e# a# s# u# r# e#  # o# f#  # a# c# t# u# a# l#  # o# b# s# e# r# v# a# t# i# o# n# s#  # w# h# i# c# h#  # a# r# e#  # p# r# e# d# i# c# t# e# d#  # c# o# r# r# e# c# t# l# y#  # i# .# e# .#  # i# t#  # c# a# l# c# u# l# a# t# e# s#  # h# o# w#  # m# a# n# y#  # o# b# s# e# r# v# a# t# i# o# n# s#  # o# f#  # t# r# u# e#  # c# l# a# s# s#  # a# r# e#  # l# a# b# e# l# e# d#  # c# o# r# r# e# c# t# l# y# .#  # I# t#  # i# s#  # a# l# s# o#  # k# n# o# w# n#  # a# s#  # ‘# S# e# n# s# i# t# i# v# i# t# y# ’# .#  # P# r# e# c# i# s# i# o# n#  # i# s#  # a#  # g# o# o# d#  # m# e# a# s# u# r# e#  # t# o#  # d# e# t# e# r# m# i# n# e# ,#  # w# h# e# n#  # t# h# e#  # c# o# s# t# s#  # o# f#  # F# a# l# s# e#  # P# o# s# i# t# i# v# e#  # i# s#  # h# i# g# h# .# 
# 
# R# e# c# a# l# l#  # =#  # T# P#  # /#  # (# T# P#  # +#  # F# N# )# 
# 
# *# *# S# p# e# c# i# f# i# c# i# t# y# *# *# 
# 
# S# p# e# c# i# f# i# c# i# t# y#  # i# s#  # a#  # m# e# a# s# u# r# e#  # o# f#  # h# o# w#  # m# a# n# y#  # o# b# s# e# r# v# a# t# i# o# n# s#  # o# f#  # f# a# l# s# e#  # c# l# a# s# s#  # a# r# e#  # l# a# b# e# l# e# d#  # c# o# r# r# e# c# t# l# y# .# 
# 
# S# p# e# c# i# f# i# c# i# t# y#  # =#  # T# N#  # /#  # (# T# N#  # +#  # F# P# )# 
# 
# S# p# e# c# i# f# i# c# i# t# y#  # a# n# d#  # S# e# n# s# i# t# i# v# i# t# y#  # b# o# t# h#  # p# l# a# y# s#  # a# n#  # i# m# p# o# r# t# a# n# t#  # r# o# l# e#  # i# n#  # d# e# r# i# v# i# n# g#  # R# O# C#  # c# u# r# v# e# .# 
# 
# *# *# R# O# C#  # c# u# r# v# e# *# *# 
# 
# R# e# c# e# i# v# e# r#  # O# p# e# r# a# t# i# n# g#  # C# h# a# r# a# c# t# e# r# i# s# t# i# c# (# R# O# C# )#  # s# u# m# m# a# r# i# z# e# s#  # t# h# e#  # m# o# d# e# l# ’# s#  # p# e# r# f# o# r# m# a# n# c# e#  # b# y#  # c# a# l# c# u# l# a# t# i# n# g#  # t# h# e#  # t# r# a# d# e#  # o# f# f# s#  # b# e# t# w# e# e# n#  # t# r# u# e#  # p# o# s# i# t# i# v# e#  # r# a# t# e#  # (# s# e# n# s# i# t# i# v# i# t# y# )#  # a# n# d#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e#  # r# a# t# e# (# 1# -#  # s# p# e# c# i# f# i# c# i# t# y# )# .# 
# T# h# e#  # a# r# e# a#  # u# n# d# e# r#  # c# u# r# v# e#  # (# A# U# C# )#  # a# l# s# o#  # c# a# l# l# e# d#  # c# o# n# c# o# r# d# a# n# c# e#  # i# n# d# e# x#  # i# s#  # a#  # p# e# r# f# e# c# t#  # p# e# r# f# o# r# m# a# n# c# e#  # m# e# t# r# i# c#  # f# o# r#  # R# O# C#  # c# u# r# v# e# .#  # H# i# g# h# e# r#  # t# h# e#  # a# r# e# a#  # u# n# d# e# r#  # c# u# r# v# e# ,#  # b# e# t# t# e# r#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n#  # p# o# w# e# r#  # o# f#  # t# h# e#  # m# o# d# e# l# .# 


# In[None]

#splitting the data into test and train for logistic regression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_sub, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4485746.npy", { "accuracy_score": score })

import pandas as pd
# ##  # R# e# g# r# e# s# s# i# o# n#  # M# o# d# e# l# s

# ## ## ##  # I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s

# In[None]

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
#from sklearn.neural_network import MLPRegressor
from math import sqrt

# ## ## ##  # R# e# a# d# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

data = pd.read_csv('../input/winequality-red.csv')

# In[None]

data.head()

# In[None]

data.shape

# ## ## ##  # S# e# l# e# c# t# i# n# g#  # t# h# e#  # i# n# p# u# t#  # a# n# d#  # o# u# t# p# u# t#  # f# e# a# t# u# r# e# s#  # f# o# r#  # r# e# g# r# e# s# s# i# o# n#  # t# a# s# k# s

# In[None]

features = ['fixed acidity','volatile acidity','citric acid','residual sugar','chlorides',
            'free sulfur dioxide','total sulfur dioxide','density','pH','sulphates','alcohol']

# In[None]

target = ['quality']

# ## ## ## ##  # C# h# e# c# k# i# n# g#  # f# o# r#  # a# n# y#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t

# In[None]

data.isnull().any()

# In[None]

X = data[features]
y = data[target]

# ## ## ##  # P# e# r# f# o# r# m#  # t# r# a# i# n#  # t# e# s# t#  # s# p# l# i# t

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1517734.npy", { "accuracy_score": score })

import pandas as pd
# ##  # *# *# T# h# i# s#  # n# o# t# e# b# o# o# k#  # d# e# s# c# r# i# b# e# s#  # t# h# e#  # P# y# t# h# o# n#  # c# o# d# e#  # t# o#  # d# e# c# i# d# e#  # t# h# e#  # e# f# f# i# c# i# e# n# t#  # n# u# m# b# e# r#  # o# f#  # n# e# i# g# h# b# o# r# s#  # i# n#  # '# K# -# N# e# a# r# e# s# t#  # N# e# i# g# h# b# o# r# s# '#  # m# e# t# h# o# d#  # f# o# r#  # t# h# i# s#  # d# a# t# a# s# e# t# .# *# *

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# ##  # *# *# I# m# p# o# r# t# i# n# g#  # a# n# d#  # S# e# p# a# r# a# t# i# n# g#  # f# e# a# t# u# r# e# s#  # a# n# d#  # l# a# b# e# l# s# *# *

# In[None]

import pandas as pd
df = pd.read_csv('../input/voice.csv')

y=df.iloc[:,-1]
X=df.iloc[:, :-1]
X.head()

# ##  # *# *# C# o# n# v# e# r# t# i# n# g#  # s# t# r# i# n# g#  # v# a# l# u# e#  # t# o#  # i# n# t#  # t# y# p# e#  # f# o# r#  # l# a# b# e# l# s# *# *

# In[None]

from sklearn.preprocessing import LabelEncoder

gender_encoder = LabelEncoder()
#Male=1, Female=0
y = gender_encoder.fit_transform(y)
y

# ## *# *# D# a# t# a#  # S# t# a# n# d# a# r# d# i# z# a# t# i# o# n# *# *# 
# 
# S# t# a# n# d# a# r# d# i# z# a# t# i# o# n#  # r# e# f# e# r# s#  # t# o#  # s# h# i# f# t# i# n# g#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # e# a# c# h#  # a# t# t# r# i# b# u# t# e#  # t# o#  # h# a# v# e#  # a#  # m# e# a# n#  # o# f#  # z# e# r# o#  # a# n# d#  # a#  # s# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # o# n# e#  # (# u# n# i# t#  # v# a# r# i# a# n# c# e# )# .#  # I# t#  # i# s#  # u# s# e# f# u# l#  # t# o#  # s# t# a# n# d# a# r# d# i# z# e#  # a# t# t# r# i# b# u# t# e# s#  # f# o# r#  # a#  # m# o# d# e# l# .#  # S# t# a# n# d# a# r# d# i# z# a# t# i# o# n#  # o# f#  # d# a# t# a# s# e# t# s#  # i# s#  # a#  # c# o# m# m# o# n#  # r# e# q# u# i# r# e# m# e# n# t#  # f# o# r#  # m# a# n# y#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # e# s# t# i# m# a# t# o# r# s#  # i# m# p# l# e# m# e# n# t# e# d#  # i# n#  # s# c# i# k# i# t# -# l# e# a# r# n# ;#  # t# h# e# y#  # m# i# g# h# t#  # b# e# h# a# v# e#  # b# a# d# l# y#  # i# f#  # t# h# e#  # i# n# d# i# v# i# d# u# a# l#  # f# e# a# t# u# r# e# s#  # d# o#  # n# o# t#  # m# o# r# e#  # o# r#  # l# e# s# s#  # l# o# o# k#  # l# i# k# e#  # s# t# a# n# d# a# r# d#  # n# o# r# m# a# l# l# y#  # d# i# s# t# r# i# b# u# t# e# d#  # d# a# t# a# .

# In[None]

#Standardize features by removing the mean and scaling to unit variance
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)

# ##  # *# *# S# p# l# i# t# t# i# n# g#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # s# e# t#  # a# n# d#  # t# e# s# t# i# n# g#  # s# e# t#  # f# o# r#  # b# e# t# t# e# r#  # g# e# n# e# r# a# l# i# z# a# t# i# o# n# *# *

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/142262.npy", { "accuracy_score": score })

import pandas as pd
# *# *# H# R#  # E# M# P# L# O# Y# E# E#  # A# T# T# R# I# T# I# O# N#  # D# A# T# A# S# E# T# .# *# *# 
# 
# T# h# i# s#  # i# s#  # a#  # f# i# c# t# i# o# n# a# l#  # d# a# t# a#  # s# e# t#  # c# r# e# a# t# e# d#  # b# y#  # I# B# M#  # d# a# t# a#  # s# c# i# e# n# t# i# s# t# s# .#  # W# e#  # n# e# e# d#  # t# o#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # a# l# g# o# r# i# t# h# m# s#  # a# n# d#  # t# e# c# h# n# i# q# u# e# s#  # w# h# i# c# h#  # c# a# n#  # b# e#  # a# p# p# l# i# e# d#  # o# n#  # i# t# .#  # W# e# '#  # l# l#  # t# r# y#  # t# o#  # g# a# i# n#  # m# e# a# n# i# n# g# f# u# l#  # i# n# s# i# g# h# t# s#  # f# r# o# m#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # l# i# k# e#  # w# h# a# t#  # a# r# e#  # t# h# e#  # f# a# c# t# o# r# s#  # w# h# i# c# h#  # h# a# v# e#  # a# n#  # i# m# p# a# c# t#  # o# n#  # E# m# p# l# o# y# e# e#  # A# t# t# r# i# t# i# o# n# .

# In[None]

# Import Desired libraries.

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

# Any results you write to the current directory are saved as output.

# I# m# p# o# r# t# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# .#  # A# f# t# e# r#  # w# h# i# c# h#  # a# n#  # i# m# p# o# r# t# a# n# t#  # s# t# e# p#  # i# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # o# u# r#  # d# a# t# a# .

# In[None]

data=pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")
attrition=data
print(data.columns)
print(data.shape)

# S# o#  # t# h# e# r# e#  # a# r# e#  # 3# 5#  # c# o# l# u# m# n# s#  # a# n# d#  # 1# 4# 7# 0#  # r# o# w# s# .# 
# N# e# x# t#  # l# e# t# '# s#  # c# h# e# c# k#  # h# o# w#  # m# a# n# y#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # n# u# m# e# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# :

# In[None]

# Differentiate numerical features (minus the target) and categorical features
categorical_features = data.select_dtypes(include=['object']).columns
categorical_features

numerical_features = data.select_dtypes(exclude = ["object"]).columns
print(categorical_features.shape)
print(categorical_features)
print(numerical_features)

# S# o#  # t# h# e# r# e#  # a# r# e#  # 9#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # w# h# i# c# h#  # i# n# c# l# u# d# e# s#  # o# u# r#  # t# a# r# g# e# t#  #  # v# a# r# i# a# b# l# e#  # "# A# t# t# r# i# t# i# o# n# "# .# 
# T# h# e# s# e#  # w# i# l# l#  # n# e# e# d#  # t# o#  # b# e#  # e# n# c# o# d# e# d#  # u# s# i# n# g#  # o# n# e#  # o# f#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # w# a# y# s# :# 
# 1# .#  # D# u# m# m# y#  # E# n# c# o# d# i# n# g# 
# 2# .# O# n# e#  # H# o# t#  # E# n# c# o# d# e# r# 
# 3# .# L# a# b# e# l#  # E# n# c# o# d# e# r# 
# R# e# s# t#  # a# r# e#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s# .#  # B# e# f# o# r# e#  # g# o# i# n# g#  # a# n# y#  # f# u# r# t# h# u# r#  # l# e# t# '# s#  # c# h# e# c# k#  # f# o# r#  # a# n# y#  # N# U# L# L# S#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t# .

# In[None]

print(data.isnull().values.any())

# S# i# n# c# e#  # t# h# e# r# e#  # a# r# e#  # n# o#  # n# u# l# l# s#  # w# e#  # D# o#  # n# o# t#  # n# e# e# d#  # t# o#  # w# o# r# r# y#  # a# b# o# u# t#  # t# h# i# s#  # a# n# y# m# o# r# e# .#  # 
# T# o#  # g# e# t#  # a#  # b# e# t# t# e# r#  # g# r# a# s# p#  # o# f#  # o# u# r#  # d# a# t# s# e# t# .#  # I#  # w# i# l# l#  # e# x# e# c# u# t# e#  # t# h# e#  # n# e# x# t#  # l# i# n# e#  # o# f#  # m# y#  # c# o# d# e# .

# In[None]

data.describe() # this creates a kind of summary of the datset withh various statistical features.

# W# e#  # n# e# e# d#  # t# o#  # s# p# e# c# i# f# y#  # o# u# r#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # w# h# i# c# h#  # i# s#  # A# t# t# r# i# t# i# o# n#  # i# n#  # t# h# i# s#  # c# a# s# e# .#  # A# l# s# o#  # s# i# n# c# e#  # A# t# t# r# i# t# i# o# n#  # i# s#  # a#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e#  # w# e#  # w# i# l# l#  # m# a# p#  # i# t#  # t# o#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s# .

# *# *# D# A# T# A#  # V# I# S# U# A# L# I# Z# A# T# I# O# N# *# *#  #  # 
# D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n#  # i# s#  # o# n# e#  # o# f#  # t# h# e#  # c# o# r# e#  # s# t# e# p#  # b# e# f# o# r# e#  # b# u# i# l# d# i# n# g#  # a# n# y#  # m# o# d# e# l# .#  # P# y# t# h# o# n#  # o# f# f# e# r# s#  # n# u# m# e# r# o# u# s#  # l# i# b# r# a# r# i# e# s#  # f# o# r#  # t# h# i# s#  # p# u# r# p# o# s# e# .# I#  # h# a# v# e#  # u# s# e# d#  # S# e# a# b# o# r# n#  # l# i# b# r# a# r# y#  # f# o# r#  # t# h# i# s#  # p# o# r# p# o# s# e# .#  # F# i# r# s# t#  # a# n# d#  # f# o# r# e# m# o# s# t#  # I#  # w# a# n# t#  # t# o#  # s# e# e#  # h# o# w#  # m# y#  # T# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # i# s#  # d# i# s# t# r# i# b# u# t# e# d#  # a# c# r# o# s# s#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

sns.countplot("Attrition",data=data)
plt.show()

# *# *# C# O# U# N# T# P# L# O# T# *# *# :# -# T# h# e#  # a# b# o# v# e#  # p# l# o# t#  # s# h# o# w# s#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # o# u# r#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .# A# s#  # c# a# n#  # b# e#  # s# e# e# n#  # c# l# e# a# r# l# y# ,#  # t# h# e#  # g# r# a# p# h#  # r# e# p# r# e# s# e# n# t# s#  # i# m# b# a# l# a# n# c# e# d#  # d# a# t# a# s# e# t# .# 
# S# o#  # w# e# '#  # l# l#  # n# e# e# d#  # t# o#  # b# a# l# a# n# c# e#  # t# h# i# s#  # d# a# t# a# s# e# t# .# 
# I# m# b# a# l# a# n# c# e# d#  # c# l# a# s# s#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # a# r# e#  # a# n#  # i# s# s# u# e#  # w# h# e# n#  # a# n# a# m# o# l# y#  # d# e# t# e# c# t# i# o# n#  # l# i# k# e#  # f# r# a# u# d#  # c# a# s# e# s# ,#  # i# d# e# n# t# i# f# i# c# a# t# i# o# n#  # o# f#  # r# a# r# e#  # d# i# s# e# a# s# e# s# ,#  # o# r#  # c# a# s# e# s#  # s# i# m# i# l# i# a# r#  # t# o#  # t# h# e#  # a# b# o# v# e#  # a# r# e#  # p# r# e# s# e# n# t# .#  # I# n#  # s# u# c# h#  # s# c# e# n# a# r# i# o# s#  # w# e#  # a# r# e#  # m# o# r# e#  # i# n# t# e# r# e# s# t# e# d#  # i# n#  # t# h# e#  # m# i# n# o# r# i# t# y#  # c# l# a# s# s#  # a# n# d#  # t# h# e#  # f# a# c# t# o# r# s#  # t# h# a# t#  # c# o# n# t# i# b# u# t# e#  # t# o#  # t# h# e#  # o# c# c# u# r# r# e# n# c# e#  # o# f#  # t# h# e# m# .#  # 
# 
# V# a# r# i# o# u# s#  # t# e# c# h# n# i# q# u# e# s#  # a# r# e#  # a# v# a# i# l# a# b# l# e#  # f# o# r#  # h# a# n# d# l# i# n# g#  # i# m# b# a# l# a# n# c# e# d#  # D# a# t# a# s# e# t#  # l# i# k# e#  # U# n# d# e# r# s# a# m# p# l# i# n# g#  # t# h# e#  # M# a# j# o# r# i# t# y#  # c# l# a# s# s#  # a# n# d#  # O# v# e# r# s# a# m# p# l# i# n# g#  # t# h# e#  # M# i# n# o# r# i# t# y#  # c# l# a# s# s# .# 
# I# n#  # s# i# m# p# l# e#  # t# e# r# m# s# ,#  # i# t#  # i# s#  # d# e# c# r# e# a# s# i# n# g#  # i# n# s# t# a# n# c# e# s#  # o# f#  # m# a# j# o# r# i# t# y#  # c# l# a# s# s# e# s#  # o# r#  # i# n# c# r# e# a# s# i# n# g#  # i# n# s# t# a# n# c# e# s#  # o# f#  # m# i# n# o# r# i# t# y#  # c# l# a# s# s# e# s#  # t# o#  # r# e# s# u# l# t#  # i# n#  # a#  # b# a# l# a# n# c# e# d#  # d# a# t# a# s# e# t# .# 
# W# e#  # w# i# l# l#  # d# e# a# l#  # w# i# t# h#  # t# h# i# s#  # i# s# s# u# e#  # w# h# i# l# e#  # b# u# i# l# d# i# n# g#  # o# u# r#  # m# o# d# e# l# .# E# a# c# h#  # h# a# s#  # i# t# s#  # o# w# n#  # s# e# t#  # o# f#  # p# r# o# s#  # a# n# d#  # c# o# n# s# .

# T# o#  # s# e# e#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # w# i# t# h#  # o# u# r#  # t# a# r# g# e# t#  # V# a# r# i# a# b# l# e#  # w# h# i# c# h#  # i# s#  # A# t# t# r# i# t# i# o# n#  # w# e#  # w# i# l# l#  # c# o# n# v# e# r# t#  # i# t#  # i# n# t# o#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s# .# 
# I#  # w# i# l# l#  # b# e#  # u# s# i# n# g#  # R# e# p# l# a# c# e#  # f# u# n# c# t# i# o# n#  # f# o# r#  # t# h# i# s# .

# In[None]

corrmat = data.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat,annot=True,fmt= '.1f',vmax=.8, square=True)

# S# t# a# t# i# s# t# i# c# a# l#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # t# w# o#  # v# a# r# i# a# b# l# e# s#  # i# s#  # r# e# f# e# r# r# e# d#  # t# o#  # a# s#  # t# h# e# i# r#  # *# *#  # c# o# r# r# e# l# a# t# i# o# n# *# *# .#  # T# h# e#  # p# e# r# f# o# r# m# a# n# c# e#  # o# f#  # s# o# m# e#  # a# l# g# o# r# i# t# h# m# s#  # c# a# n#  # d# e# t# e# r# i# o# r# a# t# e#  # i# f#  # t# w# o#  # o# r#  # m# o# r# e#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # t# i# g# h# t# l# y#  # r# e# l# a# t# e# d# ,#  # c# a# l# l# e# d#  # m# u# l# t# i# c# o# l# l# i# n# e# a# r# i# t# y# .# T# h# i# s#  # i# s#  # o# f#  # s# p# e# c# i# a# l#  # i# m# p# o# r# t# a# n# c# e#  # i# n#  # R# e# g# r# e# s# s# i# o# n# .# 
# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # ,#  # w# e#  # f# i# n# d#  # m# o# s# t#  # o# f#  # t# h# e#  # f# e# a# t# u# r# e# s#  # a# r# e#  # u# n# c# o# r# r# e# l# a# t# e# d# .# B# u# t# ,#  # t# h# e# r# e#  # i# s#  # a#  # c# o# r# r# e# l# a# t# i# o# n#  # (# 0# .# 8# )#  # b# e# t# w# e# e# n#  # P# e# r# f# o# r# m# a# n# c# e#  # R# a# t# i# n# g#  # a# n# d#  # P# e# r# f# o# r# m# a# n# c# e#  # S# a# l# a# r# y#  # H# i# k# e# .#  # W# e#  # n# e# e# d#  # t# o#  # l# o# o# k#  # i# n# t# o#  # t# h# e#  # w# h# i# t# e#  # l# i# n# e# s#  # s# h# o# w# n#  # b# y#  # E# m# p# l# o# y# e# e# C# o# u# n# t#  # a# n# d#  # S# t# a# n# d# a# r# d#  # H# o# u# r# s# .# T# o# t# a# l# W# o# r# k# i# n# g# Y# e# a# r# s#  # w# i# t# h#  # J# o# b# L# e# v# e# l#  # a# l# s# o#  # h# a# s#  # h# i# g# h#  # c# o# r# r# e# l# a# t# i# o# n# (# 0# .# 8# )# .

# A# n#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e#  # i# n#  # o# u# r#  # d# a# t# s# e# t#  # i# s#  # G# e# n# d# e# r# .#  # I#  # '#  # l# l#  # v# e# r# i# f# y#  # t# h# i# s#  # w# i# t# h#  # h# e# l# p#  # o# f#  # p# l# o# t#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # w# h# o#  # i# s#  # m# o# r# e#  # l# i# k# e# l# y#  # f# o# r#  # J# o# b#  # A# t# t# r# i# t# i# o# n#  # i# f#  # w# e#  # o# n# l# y#  # c# o# n# s# i# d# e# r#  # G# e# n# d# e# r#  # a# s#  # t# h# e#  # f# a# c# t# o# r# .

# In[None]

x, y, hue = "Attrition", "prop", "Gender"
f, axes = plt.subplots(1,2)
sns.countplot(x=x, hue=hue, data=data, ax=axes[0])
prop_df = (data[x]
           .groupby(data[hue])
           .value_counts(normalize=True)
           .rename(y)
           .reset_index())
sns.barplot(x=x, y=y, hue=hue, data=prop_df, ax=axes[1])

# O# n# e#  # i# m# p# o# r# t# a# n# t#  # t# h# i# n# g#  # t# o#  # n# o# t# e#  # h# e# r# e#  # i# s#  # w# e#  # c# a# n# n# o# t#  # m# a# k# e#  # d# i# r# e# c# t#  # i# n# f# e# r# e# n# c# e# s#  # f# r# o# m#  # f# i# r# s# t#  # c# o# u# n# t# p# l# o# t# .#  # T# h# e#  # s# e# c# o# n# d#  # b# a# r# p# l# o# t#  # i# s#  # m# a# d# e#  # i# n#  # a# c# c# o# r# d# a# n# c# e#  # w# i# t# h#  # p# r# o# p# o# r# t# i# o# n# .# 
# O# n# e#  # c# a# n#  # c# l# e# a# r# l# y#  # i# n# f# e# r#  # f# r# o# m#  # t# h# e#  # p# l# o# t#  # a# b# o# v# e#  # t# h# a# t#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # m# a# l# e# s#  # a# r# e#  # l# i# k# e# l# y#  # f# o# r#  # A# t# t# r# i# t# i# o# n#  # a# s#  # c# o# m# p# a# r# e# d#  # t# o#  # f# e# m# a# l# e# s# .

# In[None]

x, y, hue = "Attrition", "prop", "Department"
f, axes = plt.subplots(1,2,figsize=(10,5))
sns.countplot(x=x, hue=hue, data=data, ax=axes[0])
prop_df = (data[x]
           .groupby(data[hue])
           .value_counts(normalize=True)
           .rename(y)
           .reset_index())
sns.barplot(x=x, y=y, hue=hue, data=prop_df, ax=axes[1])

# I#  # h# a# v# e#  # t# r# i# e# d#  # t# o#  # f# i# n# d#  # o# u# t#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n# *# *#  # D# e# p# a# r# t# m# e# n# t#  # a# n# d#  # A# t# t# r# i# t# i# o# n# *# *# .#  # I# t#  # c# a# n#  # b# e#  # i# n# f# e# r# e# d#  # t# h# a# t#  # e# m# p# l# o# y# e# e# s#  # f# r# o# m#  # S# a# l# e# s#  # D# e# p# a# r# t# m# e# n# t#  # h# a# v# e#  # h# i# g# h# e# r#  # p# o# s# s# i# b# i# l# i# t# y#  # o# f#  # A# t# t# r# i# t# i# o# n#  # w# h# e# r# e# a# s#  # R# e# s# e# a# r# c# h#  # a# n# d#  # D# e# v# e# l# o# p# m# e# n# t#  # h# a# v# e#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# n#  # t# h# e#  # N# o#  # A# t# t# r# i# t# i# o# n#  # s# i# d# e# .

# In[None]

sns.pairplot(data=data,x_vars=['MonthlyIncome'], y_vars=['Age'],height=5, hue='Attrition',palette="prism")

# T# h# e#  # a# b# o# v# e#  # p# l# o# t#  # s# h# o# w# s#  # t# h# o# s# e#  # w# i# t# h#  # l# e# s# s# e# r#  # a# g# e#  # a# n# d#  # L# o# w# e# r#  # i# n# c# o# m# e#  # g# r# o# u# p# s#  # u# p# t# o#  # 5# 0# 0# 0#  # h# a# v# e#  # h# i# g# h# e# r#  # p# o# s# s# i# b# i# l# i# t# y#  # o# f#  # A# t# t# r# i# t# i# o# n#  # a# s#  # g# r# e# e# n#  # d# o# t# s#  # a# r# e#  # m# o# r# e#  # c# o# n# c# e# n# t# r# a# t# e# d#  # i# n#  # t# h# a# t#  # r# e# g# i# o# n#  # m# o# r# e# .

# In[None]

sns.set()
cols=['Age','DailyRate','Education','JobLevel','DistanceFromHome','EnvironmentSatisfaction','Attrition']
sns.pairplot(data[cols],hue='Attrition',height=2.5,palette="hls")

# A# b# o# v# e#  # a# r# e#  # t# h# e#  # p# a# i# r# p# l# o# t# s#  # b# e# t# w# e# e# n#  # v# a# r# i# o# u# s#  # n# u# m# e# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# .# 
# 1# .#  # T# h# e#  # f# i# r# s# t#  # d# i# s# t# r# i# b# u# t# i# o# n#  # p# l# o# t#  # f# o# r#  # a# g# e#  # s# h# o# w# s#  # t# h# a# t#  # e# m# p# l# o# y# e# e# s#  # w# h# i# c# h#  # f# a# l# l#  # i# n#  # l# o# w# e# r#  # a# g# e#  # g# r# o# u# p#  # a# r# e#  # m# o# r# e#  # l# i# k# e# l# y#  # f# o# r#  # a# t# t# r# i# t# i# o# n# ,#  # H# o# w# e# v# e# r# ,#  # a# s#  # t# h# e#  # a# g# e#  # i# n# c# r# e# a# s# e# s#  # t# h# e#  # b# l# u# e#  # c# u# r# v# e#  # g# o# e# s#  # u# p# .# 
# 2# .#  # F# o# r#  # t# h# e#  # J# o# b#  # L# e# v# e# l# ,#  # t# h# e# r# e#  # i# s#  # a#  # s# h# a# r# p#  # p# e# a# k#  # a# t#  # l# o# w# e# r#  # j# o# b#  # l# e# v# e# l# s#  # b# e# t# w# e# e# n#  # 0# -# 2#  # w# h# i# c# h#  # s# h# o# w# s#  # A# t# r# r# i# t# i# o# n#  # i# s#  # m# o# r# e#  # l# i# k# e# l# y# .# 
# 3# .#  # T# h# e#  # p# l# o# t#  # b# e# t# w# e# e# n#  # D# i# s# t# a# n# c# e# f# r# o# m# H# o# m# e#  # a# n# d#  # A# g# e#  # s# h# o# w# s#  # t# h# a# t#  # a# g# a# i# n#  # e# m# p# l# o# y# e# e# s#  # w# i# t# h#  # l# e# s# s#  # a# g# e# s#  # a# a# n# d#  # l# i# v# i# n# g#  # a# t#  # a#  # d# i# s# t# a# n# c# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 1# 5#  # h# a# v# e#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # A# t# t# r# i# t# i# o# n# .# 
# 4# .#  # E# m# p# l# o# y# e# e# s#  # w# i# t# h#  # l# o# w# e# r#  # l# e# v# e# l#  # o# f#  # E# n# v# i# r# o# n# m# e# n# t# S# a# t# i# s# f# a# c# t# i# o# n#  # i# n# d# i# c# a# t# e# s#  # h# i# g# h# e# r#  # c# h# a# n# c# e# s#  # o# f#  # A# t# t# r# i# t# i# o# n#  # a# s#  # t# h# e#  # R# e# d#  # c# u# r# v# e#  # g# o# e# s#  # a# b# o# v# e#  # t# h# e#  # b# l# u# e#  # c# u# r# v# e#  # f# o# r#  # l# o# w# e# r#  # l# e# v# e# l# s#  # o# f#  # E# n# v# i# r# o# n# m# e# n# t# S# a# t# i# s# f# a# c# t# i# o# n# .

# T# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # c# o# u# n# t# s#  # o# f#  # d# i# f# f# e# r# e# n# t#  # v# a# l# u# e# s#  # i# n#  # e# a# c# h#  # f# e# a# t# u# r# e#  # I#  # h# a# v# e#  # u# s# e# d#  # v# a# l# u# e# _# c# o# u# n# t# s#  # m# e# t# h# o# d#  # o# f#  # P# a# n# d# a# s# .#  

# In[None]

#for c in data.columns:
    #print("---- %s ---" % c)
    #print(data[c].value_counts())

# S# i# n# c# e#  # a# t# t# r# i# t# i# o# n#  # i# s#  # a#  # c# a# t# e# g# o# r# i# c# a# l#  # V# a# r# i# a# b# l# e#  # ,#  # o# n# e#  # n# e# e# d# s#  # t# o#  # c# o# n# v# e# r# t#  # i# t#  # i# n# t# o#  # n# u# m# e# r# i# c# a# l#  # f# o# r# m# .#  # I#  # a# m#  # r# e# p# l# a# c# i# n# g#  # Y# e# s#  # w# i# t# h#  # 1#  # a# n# d#  # N# o#  # w# i# t# h#  # 0# .

# In[None]

data1=data
di={"Yes": 1, "No": 0}
data1["Attrition"].replace(di,inplace=True)


# S# i# n# c# e#  # a# t# t# r# i# t# i# o# n#  # v# a# l# u# e#  # t# o#  # b# e#  # c# l# a# s# s# i# f# i# e# d# ,#  # a# s# s# i# g# n# i# n# g#  # i# t#  # t# o#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e

# In[None]

attrition=data
data1.shape
target=data.iloc[:,1]
print(target.head(5))

# In[None]

print(target.dtypes)
target=pd.DataFrame(target)
print(target.dtypes)

# In[None]

print(data1.columns)

# S# i# n# c# e#  # A# t# t# r# i# t# i# o# n#  # i# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # w# e#  # d# o#  # n# o# t#  # n# e# e# d#  # i# t#  # i# n#  # o# u# r#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e# s# .# 
# A# p# a# r# t#  # f# r# o# m#  # t# h# e# s# e#  # f# r# o# m#  # v# a# l# u# e# _# c# o# u# n# t# s#  # o# f#  # e# a# c# h#  # v# a# r# i# a# b# l# e#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # '# O# v# e# r# 1# 8# '# ,#  # '# S# t# a# n# d# a# r# d# H# o# u# r# s# '# ,#  # '# E# m# p# l# o# y# e# e# C# o# u# n# t# '#  # a# r# e#  # a# l# l#  # s# a# m# e#  # v# a# l# u# e# s#  # a# n# d#  # c# a# n#  # b# e#  # d# r# o# p# p# e# d#  # w# i# t# h# o# u# t#  # l# o# s# s#  # o# f#  # i# n# f# o# r# m# a# t# i# o# n# .# 


# In[None]

data1.head(5)
data1.drop(["Attrition","Over18","StandardHours","EmployeeCount","EmployeeNumber"],axis=1,inplace=True)


# C# o# n# v# e# r# t# i# n# g#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # t# o#  # d# u# m# m# y#  # v# a# r# i# a# b# l# e# s# .#  # I#  # h# a# v# e#  # u# s# e# d#  # g# e# t# _# d# u# m# m# i# e# s#  # m# e# t# h# o# d#  # o# f#  # p# a# n# d# a# s#  # f# o# r#  # t# h# e#  # s# a# m# e# .

# In[None]

categorical=data1.select_dtypes(include=['object']).columns
data1.shape
print(data1.columns)
print(categorical)
Prediction=data1##copy paste

# In[None]

print(data1.columns)
dummie=pd.get_dummies(data=data1, columns=['OverTime','BusinessTravel', 'Department', 'EducationField', 'Gender', 'JobRole','MaritalStatus'])
dummie=pd.DataFrame(dummie)
new_data=pd.concat([data1, dummie], axis=1)
# print(new_data.columns)

# *# *# M# O# D# E# L#  # B# U# I# L# D# I# N# G#  # :# *# *# *# *# 
# 
# I#  # h# a# v# e#  # u# s# e# d#  # t# w# o#  # m# o# d# e# l# s#  # f# o# r#  # t# h# i# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # -# R# a# n# d# o# m#  # F# o# r# e# s# t# s#  # &#  # G# r# a# d# i# e# n# t#  # B# o# o# s# t# i# n# g#  # A# l# g# o# r# i# t# h# m# .# 
# 
# F# i# r# s# t#  # ,#  # I#  # h# a# v# e#  # a# p# p# l# i# e# d#  # b# o# t# h#  # t# h# e#  # a# l# g# o# r# i# t# h# m# s#  # o# n#  # t# h# e#  # i# m# b# a# l# a# n# c# e# d#  # d# a# t# a# s# e# t#  # a# n# d#  # t# h# e# n#  # o# n#  # t# h# e#  # B# a# l# a# n# c# e# d#  # D# a# t# a# s# e# t# .#  # 
# F# o# r#  # t# h# e#  # p# u# r# p# o# s# e#  # o# f#  # B# a# l# a# n# c# i# n# g#  # o# f#  # o# u# r#  # d# a# t# s# e# t# ,#  # I#  # h# a# v# e#  # u# s# e# d#  # S# M# O# T# E# (# S# y# n# t# h# e# t# i# c#  # M# I# n# o# r# i# t# y#  # O# v# e# r#  # S# a# m# p# l# i# n# g#  # T# e# c# h# n# i# q# u# e# )# .# 
# 
# *# *# R# A# N# D# O# M#  # F# O# R# E# S# T# S# :# *# *# -#  #  # T# h# i# s#  # i# s#  # a# n#  # e# n# s# e# m# b# l# e#  # m# e# t# h# o# d#  # u# s# e# d#  # f# o# r#  # b# u# i# l# d# i# n# g#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# s#  # f# o# r#  #  # b# o# t# h#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# n# d#  # r# e# g# r# e# s# s# i# o# n#  # p# r# o# b# l# e# m# s# .# 
# F# i# r# s# t#  # I#  # a# m#  # a# p# p# l# y# i# n# g#  # R# a# n# d# o# m#  # F# o# r# e# s# t# s#  # A# l# g# o# r# i# t# h# m#  # f# o# r#  # t# h# i# s#  # B# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # o# f#  # E# m# p# l# o# y# e# e#  # A# t# t# r# i# t# i# o# n# .# T# h# i# s#  # i# s#  # a#  # b# a# g# g# i# n# g#  # E# n# s# e# m# b# l# e#  # M# o# d# e# l# .# 
# B# a# g# g# i# n# g#  # i# s#  # a#  # s# i# m# p# l# e#  # e# n# s# e# m# b# l# i# n# g#  # t# e# c# h# n# i# q# u# e#  # i# n#  # w# h# i# c# h#  # w# e#  # b# u# i# l# d#  # m# a# n# y#  # i# n# d# e# p# e# n# d# e# n# t#  # p# r# e# d# i# c# t# o# r# s# /# m# o# d# e# l# s# /# l# e# a# r# n# e# r# s#  # a# n# d#  # c# o# m# b# i# n# e#  # t# h# e# m#  # u# s# i# n# g#  # s# o# m# e#  # m# o# d# e# l#  # a# v# e# r# a# g# i# n# g#  # t# e# c# h# n# i# q# u# e# s# .# 
# 
# *# *# G# R# A# D# I# E# N# T#  # B# O# O# S# T# I# N# G# :# -# *# *#  # A# n# o# t# h# e# r#  # w# a# y#  # o# f#  # e# n# s# e# m# b# l# i# n# g#  # t# o#  # b# u# i# l# d#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# s#  # i# s#  # t# h# r# o# u# g# h#  # B# o# o# s# t# i# n# g# .#  # B# o# o# s# t# i# n# g#  # i# s#  # a#  # t# e# c# h# n# i# q# u# e#  # i# n#  # w# h# i# c# h#  # l# e# a# r# n# e# r# s# /# p# r# e# d# i# c# t# o# r# s#  # a# r# e#  # c# o# m# b# i# n# e# d#  # s# e# q# u# e# n# t# i# a# l# l# y# ,#  # r# a# t# h# e# r#  # t# h# a# n#  # i# n# d# e# p# e# n# d# e# n# t# l# y# .#  # T# h# i# s#  # m# e# a# n# s#  # e# a# c# h#  # p# r# e# d# i# c# t# o# r#  # l# e# a# r# n# s#  # f# r# o# m#  # t# h# e#  # m# i# s# t# a# k# e# s#  # o# f#  # t# h# e# i# r#  # p# r# e# v# i# o# u# s#  # p# r# e# d# i# c# t# o# r# s# .#  

# In[None]

print(target.head(5))

# In[None]

new_data.drop(['OverTime','BusinessTravel', 'Department', 'EducationField', 'Gender', 'JobRole','MaritalStatus'],axis=1,inplace=True)
# Since we have already created dummy variables so we can drop the columns with categorical features.

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(new_data, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2287052.npy", { "accuracy_score": score })

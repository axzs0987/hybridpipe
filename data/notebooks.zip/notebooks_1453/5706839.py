import pandas as pd
# ##  # *# *#  # A# k# a# d# e# m# i# k#  # P# e# r# f# o# r# m# a# n# s#  # A# n# a# l# i# z# i# *# *# 
# K# o# n# u# s# u#  # e# ğ# i# t# i# m#  # o# l# a# n#  # b# u#  # v# e# r# i#  # s# e# t# i# ,#  # 4# 8# 0#  # ö# ğ# r# e# n# c# i#  # k# a# y# d# ı#  # v# e#  # 1# 6#  # ö# z# e# l# l# i# k# t# e# n#  # o# l# u# ş# m# a# k# t# a# d# ı# r# .#  # 
# 
# Ö# z# e# l# l# i# k# l# e# r#  # ü# ç#  # a# n# a#  # k# a# t# e# g# o# r# i# y# e#  # a# y# r# ı# l# ı# r# :# 
# 
# (# 1# )#  # C# i# n# s# i# y# e# t#  # v# e#  # u# y# r# u# k#  # g# i# b# i#  # d# e# m# o# g# r# a# f# i# k#  # ö# z# e# l# l# i# k# l# e# r# :# 
# 
# V# e# r# i#  # s# e# t# i#  # 3# 0# 5#  # e# r# k# e# k#  # v# e#  # 1# 7# 5#  # k# a# d# ı# n# d# a# n#  # o# l# u# ş# m# a# k# t# a# d# ı# r# .#  # 
# 
# (# 2# )#  # E# ğ# i# t# i# m#  # a# ş# a# m# a# s# ı# ,#  # s# e# v# i# y# e# s# i#  # v# e#  # b# ö# l# ü# m#  # g# i# b# i#  # a# k# a# d# e# m# i# k#  # g# e# ç# m# i# ş#  # ö# z# e# l# l# i# k# l# e# r# i# :# 
# 
# V# e# r# i#  # s# e# t# i#  # i# k# i#  # e# ğ# i# t# i# m#  # d# ö# n# e# m# i#  # b# o# y# u# n# c# a#  # t# o# p# l# a# n# m# ı# ş# t# ı# r# :#  # b# i# r# i# n# c# i#  # d# ö# n# e# m# d# e#  # 2# 4# 5#  # ö# ğ# r# e# n# c# i#  # k# a# y# d# ı#  # v# e#  # i# k# i# n# c# i#  # d# ö# n# e# m# d# e#  # 2# 3# 5#  # ö# ğ# r# e# n# c# i#  # k# a# y# d# ı#  # b# u# l# u# n# m# a# k# t# a# d# ı# r# .# 
# D# e# v# a# m# s# ı# z# l# ı# k#  # g# ü# n# l# e# r# i# n# e#  # g# ö# r# e#  # d# e#  # i# k# i#  # k# a# t# e# g# o# r# i# d# e#  # s# ı# n# ı# f# l# a# n# d# ı# r# ı# l# a# n#  # ö# ğ# r# e# n# c# i# l# e# r#  # g# i# b# i#  # o# k# u# l# a#  # d# e# v# a# m#  # e# t# m# e#  # ö# z# e# l# l# i# ğ# i# n# i#  # d# e#  # i# ç# e# r# m# e# k# t# e# d# i# r# .# 
# 
# (# 3# )#  # S# ı# n# ı# f# t# a#  # e# l#  # k# a# l# d# ı# r# m# a# k# ,#  # k# a# y# n# a# k# l# a# r# ı#  # a# ç# m# a# k# ,#  # e# b# e# v# e# y# n# l# e# r# i# n# e#  # v# e# r# i# l# e# n#  # a# n# k# e# t# l# e# r# i# n#  # c# e# v# a# p# l# a# n# m# a# s# ı#  # v# e#  # o# k# u# l#  # t# a# t# m# i# n# i#  # g# i# b# i#  # d# a# v# r# a# n# ı# ş# s# a# l#  # ö# z# e# l# l# i# k# l# e# r# 
# 
# İ# ç# e# r# i# s# i# n# d# e#  # h# e# r# h# a# n# g# i#  # b# o# ş#  # d# e# ğ# e# r# l# e# r#  # b# a# r# ı# n# d# ı# r# m# a# d# ı# ğ# ı# n# d# a# n# ,#  # g# ö# r# s# e# l# l# e# ş# t# i# r# m# e#  # v# e#  # m# o# d# e# l# l# e# m# e#  # i# ç# i# n#  # i# y# i#  # b# i# r#  # b# a# ş# l# a# n# g# ı# ç# .# 
# 
# 
# 
# 
# 


# 
#  #  # ##  # *# *# İ# ç# i# n# d# e# k# i# l# e# r# *# *# 
# <# a#  # i# d#  # =# "# t# o# c# "# ># <# /# a# ># 
# 
# 1# .#  # [# İ# l# g# i# l# i#  # K# ü# t# ü# p# h# a# n# e# l# e# r# i# n#  # Y# ü# k# l# e# n# m# e# s# i# ]# (# ## İ# l# g# i# l# i# -# K# ü# t# ü# p# h# a# n# e# l# e# r# i# n# -# Y# ü# k# l# e# n# m# e# s# i# )# 
# 
# 2# .#  # [# V# e# r# i# y# i#  # H# a# z# ı# r# l# a# m# a#  # &#  # T# a# n# ı# m# a# ]# (# ## V# e# r# i# y# i# -# H# a# z# ı# r# l# a# m# a# -# &# -# T# a# n# ı# m# a# )# 
# 
# 3# .#  # [# V# e# r# i#  # G# ö# r# s# e# l# l# e# ş# t# i# r# m# e# ]# (# ## V# e# r# i# -# G# ö# r# s# e# l# l# e# ş# t# i# r# m# e# )# 
#  #  # 
#  #  # 3# .# 1# .#  # [# S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # Ö# ğ# r# e# n# c# i#  # S# a# y# ı# s# ı# ]# (# ## S# ı# n# ı# f# l# a# r# a# -# G# ö# r# e# -# Ö# ğ# r# e# n# c# i# -# S# a# y# ı# s# ı# )# 
#  #  # 
#  #  # 3# .# 2# .#  # [# E# ğ# i# t# i# m#  # A# l# a# n#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # C# i# n# s# i# y# e# t#  # D# a# ğ# ı# l# ı# m# ı# ]# (# ## E# ğ# i# t# i# m# -# A# l# a# n# -# Ö# ğ# r# e# n# c# i# l# e# r# i# n# -# C# i# n# s# i# y# e# t# -# D# a# ğ# ı# l# ı# m# ı# )# 
#  #  # 
#  #  # 3# .# 3# .#  # [# S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # C# i# n# s# i# y# e# t#  # D# a# ğ# ı# l# ı# m# ı# ]# (# ## S# ı# n# ı# f# l# a# r# a# -# G# ö# r# e# -# C# i# n# s# i# y# e# t# -# D# a# ğ# ı# l# ı# m# ı# )# 
#  #  # 
#  #  # 3# .# 4# .#  # [# G# e# n# e# l#  # V# e# l# i#  # D# a# ğ# ı# l# ı# m# ı# ]# (# ## G# e# n# e# l# -# V# e# l# i# -# D# a# ğ# ı# l# ı# m# ı# )# 
#  #  # 
#  #  # 3# .# 5# .#  # [# S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # V# e# l# i#  # D# a# ğ# ı# l# ı# m# ı# ]# (# ## S# ı# n# ı# f# l# a# r# a# -# G# ö# r# e# -# V# e# l# i# -# D# a# ğ# ı# l# ı# m# ı# )# 
#  #  # 
#  #  # 3# .# 6# .#  # [# A# n# k# e# t# i#  # C# e# v# a# p# l# a# y# a# n#  # V# e# l# i# l# e# r# ]# (# ## A# n# k# e# t# i# -# C# e# v# a# p# l# a# y# a# n# -# V# e# l# i# l# e# r# )# 
#  #  # 
#  #  # 3# .# 7# .#  # [# E# b# e# v# e# y# n#  # o# k# u# l#  # m# e# m# n# u# n# i# y# e# t# i# ]# (# ## E# b# e# v# e# y# n# -# O# k# u# l# -# M# e# m# n# u# n# i# y# e# t# i# )# 
#  #  # 
#  #  # 3# .# 8# .#  # [# V# a# t# a# n# d# a# ş# ı#  # O# l# d# u# k# l# a# r# ı#  # Ü# l# k# e# y# e#  # G# ö# r# e#  # Ö# ğ# r# e# n# c# i#  # Y# ü# z# d# e# s# i# ]# (# ## V# a# t# a# n# d# a# ş# ı# -# O# l# d# u# k# l# a# r# ı# -# Ü# l# k# e# y# e# -# G# ö# r# e# -# Ö# ğ# r# e# n# c# i# -# Y# ü# z# d# e# s# i# )# 
#  #  # 
#  #  # 3# .# 9# .#  # [# İ# k# i#  # d# ö# n# e# m#  # b# o# y# u# n# c# a#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # t# o# p# l# a# m#  # e# l#  # k# a# l# d# ı# r# m# a#  # a# d# e# d# i# ]# (# ## İ# k# i# -# D# ö# n# e# m# -# B# o# y# u# n# c# a# -# Ö# ğ# r# e# n# c# i# l# e# r# i# n# -# T# o# p# l# a# m# -# E# l# -# K# a# l# d# ı# r# m# a# -# A# d# e# d# i# )# 
#  #  # 
#  #  # 3# .# 1# 0# .#  # [# K# a# d# ı# n# -#  # E# r# k# e# k#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # A# l# d# ı# ğ# ı#  # D# e# r# s# l# e# r# i# n#  # D# a# ğ# ı# l# ı# m# ı#  # v# e#  # K# a# d# ı# n# -# E# r# k# e# k#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # Ü# l# k# e# l# e# r# i# n# e#  # G# ö# r# e#  # D# a# ğ# ı# l# ı# m# l# a# r# ı# ]# (# ## K# a# d# ı# n# -# -# -# E# r# k# e# k# -# Ö# ğ# r# e# n# c# i# l# e# r# i# n# -# A# l# d# ı# ğ# ı# -# D# e# r# s# l# e# r# i# n# -# D# a# ğ# ı# l# ı# m# ı# -# v# e# -# K# a# d# ı# n# -# E# r# k# e# k# -# Ö# ğ# r# e# n# c# i# l# e# r# i# n# -# Ü# l# k# e# l# e# r# i# n# e# -# G# ö# r# e# -# D# a# ğ# ı# l# ı# m# l# a# r# ı# )# 
#  #  # 
#  #  # 3# .# 1# 1# .#  # [# S# ı# n# ı# f#  # S# e# v# i# y# e# s# i# n# e#  # G# ö# r# e#  # D# a# ğ# ı# l# ı# m# l# a# r# ]# (# ## S# ı# n# ı# f# -# S# e# v# i# y# e# s# i# n# e# -# G# ö# r# e# -# D# a# ğ# ı# l# ı# m# l# a# r# )# 
#  #  # 
#  #  # 3# .# 1# 2# .#  # [# S# ı# n# ı# f# a#  # G# ö# r# e#  # T# a# k# i# p#  # E# d# i# l# e# n#  # K# a# y# n# a# k# l# a# r# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # D# u# y# u# r# u#  # T# a# k# i# b# i# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # E# l#  # K# a# l# d# ı# r# m# a# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # T# a# r# t# ı# ş# m# a# l# a# r# a#  # K# a# t# ı# l# ı# m# ]# (# ## S# ı# n# ı# f# a# -# G# ö# r# e# -# T# a# k# i# p# -# E# d# i# l# e# n# -# K# a# y# n# a# k# l# a# r# -# -# -# S# ı# n# ı# f# a# -# G# ö# r# e# -# D# u# y# u# r# u# -# T# a# k# i# b# i# -# -# -# S# ı# n# ı# f# a# -# G# ö# r# e# -# E# l# -# K# a# l# d# ı# r# m# a# -# -# -# S# ı# n# ı# f# a# -# G# ö# r# e# -# T# a# r# t# ı# ş# m# a# l# a# r# a# -# K# a# t# ı# l# ı# m# )# 
#  #  # 
#  #  # 3# .# 1# 3# .#  # [# S# a# y# ı# s# a# l#  # Ö# z# e# l# l# i# k# l# e# r#  # A# r# a# s# ı# n# d# a# k# i#  # İ# l# i# ş# k# i# l# e# r# ]# (# ## S# a# y# ı# s# a# l# -# Ö# z# e# l# l# i# k# l# e# r# -# A# r# a# s# ı# n# d# a# k# i# -# İ# l# i# ş# k# i# l# e# r# )# 
#  # 
# 4# .#  # [# M# o# d# e# l#  # S# e# ç# i# m# i#  # &#  # U# y# g# u# l# a# n# m# a# s# ı# ]# (# ## M# o# d# e# l# -# S# e# ç# i# m# i# -# &# -# U# y# g# u# l# a# n# m# a# s# ı# )# 
#  #  # 
#  #  # 4# .# 1# .#  # [# İ# s# t# a# t# i# k# s# e# l#  # N# o# r# m# a# l# l# e# ş# t# i# r# m# e# ]# (# ## İ# s# t# a# t# i# k# s# e# l# -# N# o# r# m# a# l# l# e# ş# t# i# r# m# e# )# 
#  #  # 
#  #  # 4# .# 2# .#  # [# E# ğ# i# t# i# m#  # v# e#  # T# e# s# t#  # V# e# r# i# l# e# r# i# n# i# n#  # B# e# l# i# r# l# e# n# m# e# s# i# ]# (# ## E# ğ# i# t# i# m# -# v# e# -# T# e# s# t# -# V# e# r# i# l# e# r# i# n# i# n# -# B# e# l# i# r# l# e# n# m# e# s# i# )# 
#  #  # 
#  #  # 4# .# 3# .#  # [# M# o# d# e# l# i# n#  # U# y# g# u# l# a# n# m# a# s# ı# ]# (# ## M# o# d# e# l# i# n# -# U# y# g# u# l# a# n# m# a# s# ı# )# 
#  #  # 
#  #  # 4# .# 3# .# 1# .#  # [# S# u# p# p# o# r# t#  # V# e# k# t# o# r#  # M# a# c# h# i# n# e# (# S# V# M# )#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## S# u# p# p# o# r# t# -# V# e# k# t# o# r# -# M# a# c# h# i# n# e# (# S# V# M# )# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# )# 
#  #  # 
#  #  # 4# .# 3# .# 2# .#  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## L# o# g# i# s# t# i# c# -# R# e# g# r# e# s# s# i# o# n# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# )# 
#  #  # 
#  #  # 4# .# 3# .# 3# .#  # [# R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## R# a# n# d# o# m# -# F# o# r# e# s# t# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# )# 
#  #  # 
#  #  # 4# .# 3# .# 4# .#  # [# N# a# i# v# e#  # B# a# y# e# s#  #  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## N# a# i# v# e# -# B# a# y# e# s# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# )# 
#  #  # 
#  #  # 4# .# 3# .# 5# .#  # [# D# e# c# i# s# i# o# n#  # T# r# e# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## D# e# c# i# s# i# o# n# -# T# r# e# e# -# C# l# a# s# s# i# f# i# c# a# t# i# o# n# )# 


#  #  # ##  # *# *# 1# .#  # İ# l# g# i# l# i#  # K# ü# t# ü# p# h# a# n# e# l# e# r# i# n#  # Y# ü# k# l# e# n# m# e# s# i# *# *

# In[None]



import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.pyplot as plt


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))



#  #  # ##  # *# *# 2# .#  # V# e# r# i# y# i#  # H# a# z# ı# r# l# a# m# a#  # &#  # T# a# n# ı# m# a# *# *

# In[None]

df = pd.read_csv('/kaggle/input/xAPI-Edu-Data/xAPI-Edu-Data.csv')
df.head()

# In[None]


df.isnull().values.any()

# İ# l# k#  # o# l# a# r# a# k#  # v# e# r# m# i# z# d# e#  # b# o# ş#  # v# e# r# i#  # o# l# u# p#  # o# l# m# a# d# ı# ğ# ı# n# ı#  # k# o# n# t# r# o# l#  # e# d# i# l# d# i# .#  # Ş# a# y# e# t#  # v# e# r# i# m# i# z# d# e#  # e# k# s# i# k#  # v# e# r# i#  # o# l# d# u# ğ# u# n# u#  # t# e# s# p# i# t#  # e# t# m# i# ş#  # o# l# s# a# y# d# ı# k#  # i# l# k#  # o# l# a# r# a# k#  # h# a# n# g# i#  # s# e# b# e# p# l# e# r# d# e# n#  # k# a# y# n# a# k# l# a# d# ı# ğ# ı# n# ı#  # a# n# l# a# m# a# y# a#  # ç# a# l# ı# ş# ı# r# d# ı# k# .#  # V# e#  # e# k# s# i# k#  # v# e# r# i# l# e# r# i#  # t# e# m# i# z# l# e# y# i# p#  # y# e# r# i# n# e#  # b# a# ş# k# a#  # d# e# ğ# e# r# l# e# r#  # e# k# l# e# m# e# m# i# z#  # g# e# r# e# k# i# r# d# i# .#  

# In[None]


#sütun bilgilerine ulaşıldı
df.info()

#  #  # ##  # *# *# 3# .#  # V# e# r# i#  # G# ö# r# s# e# l# l# e# ş# t# i# r# m# e# *# *# 
#  #  # ##  # *# *# 3# .# 1# .#  # S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # Ö# ğ# r# e# n# c# i#  # S# a# y# ı# s# ı# *# *

# K# a# y# ı# t# l# ı#  # b# u# l# u# n# a# n#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  #  # h# a# n# g# i#  # e# ğ# i# t# i# m#  # g# r# u# b# u# n# a#  # d# a# h# i# l#  # o# l# u# p# ,#  # k# a# ç#  # k# i# ş# i#  # o# l# d# u# k# l# a# r# ı# n# ı#  # s# a# p# t# a# d# ı# k# .

# In[None]

df['StageID'].value_counts()

#  #  # ##  # *# *# 3# .# 2# .#  # E# ğ# i# t# i# m#  # A# l# a# n#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # C# i# n# s# i# y# e# t#  # D# a# ğ# ı# l# ı# m# ı# *# *# 
#  #  

# G# e# n# e# l#  # o# l# a# r# a# k#  # e# ğ# i# t# i# m#  # a# l# a# n#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # c# i# n# s# i# y# e# t#  # o# l# a# r# a# k#  # d# a# ğ# ı# l# ı# m# ı# n# ı#  # ö# ğ# r# e# n# m# e# k#  # i# ç# i# n#  # g# ö# r# s# e# l# l# e# ş# t# i# r# m# e#  # u# y# g# u# l# a# d# ı# k# .

# In[None]

fig= plt.subplots(figsize=(10,7))
sns.countplot(x='gender',data=df,palette="pastel" )
plt.show()

# ##  # *# *# 3# .# 3# .#  # S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # C# i# n# s# i# y# e# t#  # D# a# ğ# ı# l# ı# m# ı# *# *

# G# e# n# e# l#  # d# a# ğ# ı# l# ı# m# a#  # b# a# k# t# ı# k# t# a# n#  # s# o# n# r# a#  # b# u# l# u# n# d# u# k# l# a# r# ı#  # s# e# v# i# y# e# y# e#  # g# ö# r# e#  # d# a# ğ# ı# l# ı# m# ı#  # i# n# c# e# l# e# n# d# i# :# 
# 
# M# :# O# r# t# a# o# k# u# l# 
# L# :# İ# l# k# o# k# u# l# 
# H# :# L# i# s# e# 
# 
# İ# l# k#  # g# ö# z# e#  # ç# a# r# p# a# n# ı# n#  # i# l# k# o# k# u# l# a#  # g# i# d# e# n#  # k# a# d# ı# n#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # e# p# e# y# c# e#  # a# z#  # o# l# d# u# ğ# u# n# u#  # g# ö# r# m# ü# ş#  # o# l# d# u# k# .#  # L# i# s# e# y# e#  # g# i# d# e# n#  # k# a# d# ı# n#  # e# r# k# e# k#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # i# s# e#  # y# a# k# l# a# ş# ı# k#  # o# l# a# r# a# k#  # e# ş# i# t#  # b# i# r#  # d# a# ğ# ı# l# ı# m#  # g# ö# s# t# e# r# d# i# ğ# i# n# i#  # a# n# l# a# d# ı# k# .# 
# 
# 


# In[None]

fig= plt.subplots(figsize=(15,7))
sns.countplot(x='gender', hue='Class', data=df,hue_order = ['L', 'M', 'H'],palette="pastel" )
plt.show()

# ##  # *# *# 3# .# 4# .#  # G# e# n# e# l#  # V# e# l# i#  # D# a# ğ# ı# l# ı# m# ı# *# *

# Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # s# a# y# ı# s# ı# n# a#  # b# a# k# t# ı# k# t# a# n#  # s# o# n# r# a#  # b# u#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # g# e# n# e# l#  # o# l# a# r# a# k#  # a# n# n# e#  # v# e#  # b# a# b# a#  # v# e# l# i#  # d# a# ğ# ı# l# ı# m# ı# n# a#  # g# ö# z#  # a# t# t# ı# k# .

# In[None]

f=plt.figure(figsize=(10,7))
sns.countplot(x="Relation", data=df, palette="pastel");
plt.show()

# ##  # *# *# 3# .# 5# .#  # S# ı# n# ı# f# l# a# r# a#  # G# ö# r# e#  # V# e# l# i#  # D# a# ğ# ı# l# ı# m# ı# *# *

# O# k# u# l# a#  # d# e# v# a# m#  # e# t# m# e#  # s# e# v# i# y# e# s# i# n# e#  # g# ö# r# e#  # d# e#  # k# a# d# ı# n#  # ö# ğ# r# e# n# c# i#  # s# a# y# ı# s# ı#  # a# z#  # o# l# a# n#  # i# l# k# o# k# u# l#  # ö# ğ# r# e# n# c# i# l# e# r# i# n# i# n#  # a# n# n# e#  # v# e# l# i# l# e# r# i#  # d# e#  # k# e# z# a#  # a# y# n# ı#  # a# z# l# ı# k# t# a#  # d# e# v# a# m#  # e# d# e# r# k# e# n# ;#  # s# a# y# ı#  # o# l# a# r# a# k#  # y# a# k# l# a# ş# ı# k#  # e# ş# i# t#  # o# l# a# n#  # l# i# s# e#  # ö# ğ# r# e# n# c# i# l# e# r# i# n# i# n#  # a# n# n# e#  # v# e# l# i# s# i# n# i# n#  # d# a# h# a#  # f# a# z# l# a#  # o# l# d# u# ğ# u# n# u#  # g# ö# r# ü# l# d# ü# .# 


# In[None]


fig= plt.subplots(figsize=(15,7))
sns.countplot(x='Relation', hue='Class', data=df,hue_order = ['L', 'M', 'H'],palette="pastel" )
plt.show()

#  # ##  # *# *# 3# .# 6# .#  # A# n# k# e# t# i#  # C# e# v# a# p# l# a# y# a# n#  # V# e# l# i# l# e# r# *# *

# In[None]

from matplotlib.pyplot import pie
plt.figure(figsize = (7,7))
colors=["wheat","aquamarine"]
count = df.ParentAnsweringSurvey.groupby(df.ParentAnsweringSurvey).count()
Answer = count.keys()
pie(count,labels=Answer, colors=colors, autopct='%1.1f%%')

# ##  # *# *# 3# .# 7# .#  # E# b# e# v# e# y# n#  # o# k# u# l#  # m# e# m# n# u# n# i# y# e# t# i#  # *# *

# In[None]

from matplotlib.pyplot import pie
plt.figure(figsize = (7,7))
colors=["wheat","aquamarine"]
count = df.ParentschoolSatisfaction.groupby(df.ParentschoolSatisfaction).count()
Satisfaction = count.keys()
pie(count,labels=Satisfaction, colors=colors, autopct='%1.1f%%')

# Y# u# k# a# r# ı# d# a#  # g# ö# r# d# ü# ğ# ü# m# ü# z#  # i# k# i#  # g# ö# r# s# e# l# l# e# ş# t# i# r# m# e# d# e#  # v# e# l# i# l# e# r# e#  # y# a# p# ı# l# a# n#  # a# n# k# e# t# e#  # g# e# r# i#  # d# ö# n# ü# ş# ü#  # v# e#  # m# e# m# n# u# n# i# y# e# t#  # o# r# a# n# ı# n# a#  # b# a# k# t# ı# k# .#  # Y# a# k# l# a# ş# ı# k#  # %# 5# 6#  # l# ı# k#  # v# e# l# i#  # a# n# k# e# t# i#  # c# e# v# a# p# l# a# r# k# e# n# ;#  # b# u#  # %# 5# 6# '# l# ı# k#  # k# e# s# i# m# i# n#  # y# a# k# l# a# ş# ı# k#  # %# 6# 1# '# l# i# k#  # k# ı# s# m# ı# n# ı# n#  # a# n# c# a# k#  # v# e# r# i# l# e# n#  # e# ğ# i# t# i# m# d# e# n#  # m# e# m# n# u# n# i# y# e# t# i# n# i#  # g# ö# r# m# ü# ş#  # o# l# d# u# k# .

# ##  # *# *# 3# .# 8# .#  # V# a# t# a# n# d# a# ş# ı#  # O# l# d# u# k# l# a# r# ı#  # Ü# l# k# e# y# e#  # G# ö# r# e#  # Ö# ğ# r# e# n# c# i#  # Y# ü# z# d# e# s# i# *# *

# In[None]

from matplotlib.pyplot import pie
group_by_sum_of_nationalities = df.NationalITy.groupby(df.NationalITy).count()
group_by_sum_of_nationalities_header = group_by_sum_of_nationalities.keys()
plt.figure(figsize = (15,12))
colors=['#c2c2f0','#ffb3e6',"wheat","aquamarine",'#ff9999','#66b3ff','#99ff99','#ffcc99','#ff9999']
#print(group_by_sum_of_nationalities_header)
pie(group_by_sum_of_nationalities,labels=group_by_sum_of_nationalities_header, colors=colors, autopct='%1.1f%%')

# G# e# n# e# l#  # o# l# a# r# a# k#  # v# a# t# a# n# d# a# ş# ı#  # o# l# d# u# k# l# a# r# ı#  # ü# l# k# e# l# e# r# e#  # g# ö# r# e#  # ö# ğ# r# e# n# c# i# l# e# r# i#  # e# l# e#  # a# l# d# ı# ğ# ı# m# ı# z# d# a#  # e# n#  # a# z#  # ö# ğ# r# e# n# c# i# n# i# n#  # g# e# l# d# i# ğ# i#  # ü# l# k# e#  # V# e# n# e# z# u# e# l# a#  # o# l# d# u# ğ# u# n# u#  # g# ö# r# ü# r# k# e# n# ,#  # e# n#  # f# a# z# l# a#  # ö# ğ# r# e# n# c# i#  # y# o# l# l# a# y# a# n#  # ü# l# k# e# n# i# n#  # d# e#  # K# u# v# e# y# t#  # o# l# d# u# ğ# u# n# u#  # s# a# p# t# a# d# ı# k# .#  

# ##  # *# *#  #  # 3# .# 9# .#  # İ# k# i#  # d# ö# n# e# m#  # b# o# y# u# n# c# a#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # t# o# p# l# a# m#  # e# l#  # k# a# l# d# ı# r# m# a#  # a# d# e# d# i#  # *# *

# In[None]

pd.DataFrame(df['raisedhands'].loc[0:481]).astype(int).sum()

# ##  # *# *# 3# .# 1# 0# .# K# a# d# ı# n# -#  # E# r# k# e# k#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # A# l# d# ı# ğ# ı#  # D# e# r# s# l# e# r# i# n#  # D# a# ğ# ı# l# ı# m# ı#  # v# e#  # K# a# d# ı# n# -# E# r# k# e# k#  # Ö# ğ# r# e# n# c# i# l# e# r# i# n#  # Ü# l# k# e# l# e# r# i# n# e#  # G# ö# r# e#  # D# a# ğ# ı# l# ı# m# l# a# r# ı# *# *

# In[None]

fig, (axis1, axis2)  = plt.subplots(2, 1,figsize=(20,15))
sns.countplot(x='Topic', hue='gender', data=df, ax=axis1, palette="pastel")
sns.countplot(x='NationalITy', hue='gender', data=df, ax=axis2, palette="pastel")

# D# e# r# s# l# e# r# i#  # a# l# a# n#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # c# i# n# s# i# y# e# t# i# n# e#  # g# ö# r# e#  # d# a# ğ# ı# l# ı# m# l# a# r# ı# n# ı#  # i# n# c# e# l# e# d# i# ğ# i# m# i# z# d# e# :# 
# 
# B# i# l# i# ş# i# m#  # v# e#  # İ# s# p# a# n# y# o# l# c# a#  # d# e# r# s# l# e# r# i# n# e#  # e# r# k# e# k#  # ö# ğ# r# e# n# c# i# l# e# r#  # d# a# h# a#  # f# a# z# l# a#  # r# a# ğ# b# e# t#  # g# ö# s# t# e# r# i# r# k# e# n# ;#  # F# r# a# n# s# ı# z# c# a# ,#  # K# i# m# y# a#  # v# e#  # İ# n# g# i# l# i# z# c# e#  # d# e# r# s# l# e# r# i# n# d# e#  # y# a# k# l# a# ş# ı# k#  # o# l# a# r# a# k#  # k# a# d# ı# n#  # ö# ğ# r# e# n# c# i# l# e# r# i# n#  # e# ş# i# t# l# i# ğ# e#  # y# a# k# l# a# ş# t# ı# ğ# ı# n# ı#  # g# ö# r# d# ü# k# .

# ##  # *# *#  # 3# .# 1# 1# .#  # S# ı# n# ı# f#  # S# e# v# i# y# e# s# i# n# e#  # G# ö# r# e#  # D# a# ğ# ı# l# ı# m# l# a# r# *# *

# In[None]

f=plt.figure(figsize=(20,7))
sns.countplot(x='GradeID', hue='Class', data=df, order=['G-02', 'G-04', 'G-05', 'G-06', 'G-07', 'G-08', 'G-09', 'G-10', 'G-11', 'G-12'], hue_order = ['L', 'M', 'H'], palette="pastel")
plt.show()

#  #  # ##  # *# *#  # 3# .# 1# 2# .#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # T# a# k# i# p#  # E# d# i# l# e# n#  # K# a# y# n# a# k# l# a# r# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # D# u# y# u# r# u#  # T# a# k# i# b# i# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # E# l#  # K# a# l# d# ı# r# m# a# -#  # S# ı# n# ı# f# a#  # G# ö# r# e#  # T# a# r# t# ı# ş# m# a# l# a# r# a#  # K# a# t# ı# l# ı# m# *# *

# In[None]

fig, axarr  = plt.subplots(2,2,figsize=(20,10))
sns.barplot(x='Class', y='VisITedResources', data=df, order=['L','M','H'], ax=axarr[0,0],palette="pastel")
sns.barplot(x='Class', y='AnnouncementsView', data=df, order=['L','M','H'], ax=axarr[0,1],palette="pastel")
sns.barplot(x='Class', y='raisedhands', data=df, order=['L','M','H'], ax=axarr[1,0],palette="pastel")
sns.barplot(x='Class', y='Discussion', data=df, order=['L','M','H'], ax=axarr[1,1],palette="pastel")

# Z# i# y# a# r# e# t#  # E# d# i# l# e# n#  # K# a# y# n# a# k# l# a# r# ,#  # D# u# y# u# r# u# l# a# r#  # G# ö# r# ü# n# t# ü# l# e# m# e# ,#  # E# l#  # K# a# l# d# ı# r# m# a#  # v# e#  # D# e# r# s#  # i# l# e#  # İ# l# g# i# l# i#  # T# a# r# t# ı# ş# m# a#  # d# u# r# u# m# u# n# a#  # b# a# k# ı# l# d# ı# ğ# ı#  # z# a# m# a# n#  # 4#  # g# r# a# f# i# ğ# i# n#  # b# i# r# b# i# r# i#  # i# l# e#  # ö# r# t# ü# ş# t# ü# ğ# ü# n# ü#  # v# e#  # d# a# ğ# ı# l# ı# m# ı# n#  # n# e# r# e# d# e# y# s# e#  # e# ş# i# t#  # o# l# d# u# ğ# u# n# u#  # b# i# r#  # t# ı# k#  # i# l# k# o# k# u# l#  # ö# ğ# r# e# n# c# i# l# e# r# i# n# i# n#  # d# a# h# a#  # t# a# r# t# ı# ş# m# a# l# a# r# a#  # a# ç# ı# k#  # o# l# d# u# ğ# u#  # a# n# l# a# ş# ı# l# ı# y# o# r# .# 


# ##  # *# *#  # 3# .# 1# 3# .#  # S# a# y# ı# s# a# l#  # Ö# z# e# l# l# i# k# l# e# r#  # A# r# a# s# ı# n# d# a# k# i#  # İ# l# i# ş# k# i# l# e# r#  # *# *

# In[None]

fig, (axis1, axis2)  = plt.subplots(1, 2,figsize=(20,7))
sns.regplot(x='raisedhands', y='VisITedResources', data=df, ax=axis1)
sns.regplot(x='AnnouncementsView', y='Discussion', data=df, ax=axis2)

# ##  # *# *#  # 4# .#  # M# o# d# e# l#  # S# e# ç# i# m# i#  # &#  # U# y# g# u# l# a# n# m# a# s# ı# *# *# 
# 
# ##  # *# *#  # 4# .# 1# .#  # İ# s# t# a# t# i# k# s# e# l#  # N# o# r# m# a# l# l# e# ş# t# i# r# m# e# *# *

# B# u# r# a# d# a# k# i#  # a# m# a# c# ı# m#  # v# e# r# i# l# e# r# i# m# i#  # t# e# k#  # b# i# r#  # d# ü# z# e# n#  # i# ç# e# r# i# s# i# n# d# e#  # e# l# e#  # a# l# ı# p#  # ü# z# e# r# i# n# d# e#  # ç# a# l# ı# ş# m# a# l# a# r# ı# m# a#  # d# e# v# a# m#  # e# d# e# b# i# l# m# e# k# .#  # M# i# n# -# M# a# x#  # N# o# r# m# a# l# i# z# a# s# y# o# n# u#  # k# u# l# l# a# n# d# ı# ğ# ı# m#  # b# u#  # n# o# r# m# a# l# l# e# ş# t# i# r# m# e# d# e#  #  # v# e# r# i# l# e# r# i#  # d# o# ğ# r# u# s# a# l#  # o# l# a# r# a# k#  # n# o# r# m# a# l# i# z# e#  # e# d# i# p#  # m# i# n# i# m# u# m# ;#  # b# i# r# 
# v# e# r# i# n# i# n#  # a# l# a# b# i# l# e# c# e# ğ# i#  # e# n#  # d# ü# ş# ü# k#  # d# e# ğ# e# r#  # i# k# e# n# ,#  # m# a# k# s# i# m# u# m# ;#  # v# e# r# i# n# i# n#  # a# l# a# b# i# l# e# c# e# ğ# i#  # e# n#  # y# ü# k# s# e# k#  # d# e# ğ# e# r# i#  # i# f# a# d# e#  # e# t# m# e# s# i# n# i#  # s# a# ğ# l# a# m# a# k# .#  

# In[None]

df_selected = df.drop(['NationalITy','StageID','SectionID','PlaceofBirth', 'GradeID', "Topic", 'Semester', "Relation", 'ParentAnsweringSurvey', "ParentschoolSatisfaction", 'StudentAbsenceDays', "Class"], 
                        axis = 1)

# K# u# l# l# a# n# a# m# a# y# c# a# ğ# ı# m#  # v# e# r# i# l# e# r# i# m# i# n#  # s# ü# t# u# n# l# a# r# ı# n# ı#  # i# l# k#  # ç# ı# k# a# r# m# a# k#  # i# l# e#  # b# a# ş# l# a# d# ı# m#  # v# e#  # ç# ı# k# a# r# d# ı# k# t# a# n#  # s# o# n# r# a# s# ı# n# d# a#  # d# f# _# s# e# l# e# c# t# e# d#  # d# i# y# e# r# e# k#  # s# o# n#  # h# a# l# i# n# i#  # g# ö# r# d# ü# m# .

# In[None]

df_selected

# In[None]

df_selected_copy=df_selected

# In[None]

df_selected_copy.gender=[1 if i=="M" else 0 for i in df_selected_copy.gender]

# İ# s# t# e# m# e# d# i# ğ# i# m#  # s# ü# t# u# n# l# a# r# ı#  # ç# ı# k# a# r# d# ı# k# t# a# n#  # s# o# n# r# a#  # e# l# i# m# d# e#  # k# a# l# a# n#  # c# i# n# s# i# y# e# t#  # s# ü# t# u# n# u# n# u#  # e# r# k# e# k# l# e# r# e#  # 1#  # k# a# d# ı# n# l# a# r# a#  # 0#  # s# a# y# ı# s# ı# n# u#  # v# e# r# e# r# e# k#  # t# e# k# r# a# r# d# a# n#  # y# a# z# d# ı# r# d# ı# m# .

# In[None]

df_selected_copy

# N# o# r# m# a# l# l# e# ş# t# i# r# m# e#  # y# a# p# m# a# y# a# c# a# ğ# ı# m#  # v# e#  # y# a# p# a# c# a# ğ# ı# m#  # k# ı# s# ı# m# l# a# r# ı#  # x#  # v# e#  # y#  # o# l# a# r# a# k#  # a# y# ı# r# d# ı# m# .#  

# In[None]

y=df_selected_copy.gender.values
x_df=df_selected_copy.drop("gender",axis=1)

# In[None]

y

# In[None]

x=(x_df-np.min(x_df))/(np.max(x_df)-np.min(x_df))

# v# e# r# i# m# i# z# i#  # n# o# r# m# a# l# l# e# ş# t# i# r# d# i# k# /# i# s# t# a# t# i# k# s# e# l#  # n# o# r# m# a# l# l# e# ş# t# i# r# m# e# 


# In[None]

x

# V# e#  # b# u#  # ş# e# k# i# l# d# e#  # 0#  # v# e#  # 1#  # a# r# a# s# ı# n# d# a#  # n# o# r# m# a# l# l# e# ş# t# i# r# m# e# k#  # i# s# t# e# d# i# ğ# i# m#  # v# e# r# i# l# e# r# i#  # g# ö# r# m# ü# ş#  # o# l# d# u# k# .

# ##  # *# *#  # 4# .# 2# .#  # E# ğ# i# t# i# m#  # v# e#  # T# e# s# t#  # V# e# r# i# l# e# r# i# n# i# n#  # B# e# l# i# r# l# e# n# m# e# s# i# *# *

# N# o# r# m# a# l# l# e# ş# t# i# r# m# e#  # k# ı# s# m# ı# n# ı#  # d# a#  # b# i# t# i# r# d# i# ğ# i# m#  # v# e# r# i# l# e# r# i# m# i# n#  #  # %# 2# 0#  # l# i# k#  # k# ı# s# m# ı# n# ı#  # t# e# s# t#  # v# e# r# i# s# i#  # o# l# a# r# a# k#  # a# y# ı# r# d# ı# k# .

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5706839.npy", { "accuracy_score": score })

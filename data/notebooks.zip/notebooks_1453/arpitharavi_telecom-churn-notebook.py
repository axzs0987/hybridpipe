import numpy as np 
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt
from subprocess import check_output
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
print(check_output(["ls", "../input"]).decode("utf8"))
tele = pd.read_csv('../input/bigml_59c28831336c6604c800002a.csv')
print(tele.dtypes)
print(tele.info())
print(tele.groupby('churn')['phone number'].count())
drp = tele[['state','area code','phone number','international plan','voice mail plan','churn']]
X= tele.drop(drp,1)
y= tele.churn
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
logreg = LogisticRegression()
#logreg.fit(X_train, y_train)
#y_pred = logreg.predict(X_test)
#print('Logistic regression score =',round(metrics.accuracy_score(y_test, y_pred),2))
#scores = cross_val_score(logreg, X, y, cv=5, scoring='accuracy') 
#print('Logistic regression of each partition\n',scores)
#print('Mean score of all the scores after cross validation =',round(scores.mean(),2)) 
#conf = (metrics.confusion_matrix(y_test, y_pred))
#cmap = sns.cubehelix_palette(50, hue=0.05, rot=0, light=0.9, dark=0, as_cmap=True)
#sns.heatmap(conf,cmap = cmap,xticklabels=['0','1'],yticklabels=['0','1'],annot=True, fmt="d",)
#plt.xlabel('Predicted')
#plt.ylabel('Actual')
#FP = conf[1][0]
#FN = conf[0][1]
#TP = conf[0][0]
#TN = conf[1][1]
#print('False Positive ',FP)
#print('False Negative ',FN)
#print('True Positive ',TP)
#print('True Negative ',TN)
#TPR = TP/(TP+FN)
#print('\nTrue Positive Rate :',round(TPR,2))
#TNR = TN/(TN+FP) 
#print('\nTrue Negative Rate :',round(TNR,2))
#PPV = TP/(TP+FP)
#print('\nPositive Predictive Value :',round(PPV,2))
#NPV = TN/(TN+FN)
#print('\nNegative Predictive Value :',round(NPV,2))
#FPR = FP/(FP+TN)
#print('\nFalse Positive Rate :',round(FPR,2))
#FNR = FN/(TP+FN)
#print('\nFalse Negative Rate :',round(FNR,2))
#FDR = FP/(TP+FP)
#print('\nFalse Discovery Rate :',round(FDR,2))
#ACC = (TP+TN)/(TP+FP+FN+TN)
#print('\nOverall accuracy :',round(ACC,2))
rf_clf = RandomForestClassifier(n_estimators=120, criterion='entropy')
#rf_clf.fit(X_train, y_train)
#rf_pred_test = rf_clf.predict(X_test)
#print('Accuracy of Random forest :',round(metrics.accuracy_score(y_test, rf_pred_test),2))
#rf_scores = cross_val_score(rf_clf, X, y, cv=5, scoring='accuracy')
#print('Cross Validation scores using random forest \n',rf_scores)
#print('Mean of Cross Validation scores',round(rf_scores.mean(),2)) 
#rf_conf = (metrics.confusion_matrix(y_test, rf_pred_test))
#cmap = sns.cubehelix_palette(50, hue=0.05, rot=0, light=0.9, dark=0, as_cmap=True)
#sns.heatmap(rf_conf,cmap = cmap,xticklabels=['0','1'],yticklabels=['0','1'],annot=True, fmt="d",)
#plt.xlabel('Predicted')
#plt.ylabel('Actual')
#FP = rf_conf[1][0]
#FN = rf_conf[0][1]
#TP = rf_conf[0][0]
#TN = rf_conf[1][1]
#print('False Positive ',FP)
#print('False Negative ',FN)
#print('True Positive ',TP)
#print('True Negative ',TN)
#TPR = TP/(TP+FN)
#print('\nTrue Positive Rate :',round(TPR,2))
#TNR = TN/(TN+FP) 
#print('\nTrue Negative Rate :',round(TNR,2))
#PPV = TP/(TP+FP)
#print('\nPositive Predictive Value :',round(PPV,2))
#NPV = TN/(TN+FN)
#print('\nNegative Predictive Value :',round(NPV,2))
#FPR = FP/(FP+TN)
#print('\nFalse Positive Rate :',round(FPR,2))
#FNR = FN/(TP+FN)
#print('\nFalse Negative Rate :',round(FNR,2))
#FDR = FP/(TP+FP)
#print('\nFalse Discovery Rate :',round(FDR,2))
#ACC = (TP+TN)/(TP+FP+FN+TN)
#print('\nOverall accuracy :',round(ACC,2))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/arpitharavi_telecom-churn-notebook.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/arpitharavi_telecom-churn-notebook/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/arpitharavi_telecom-churn-notebook/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/arpitharavi_telecom-churn-notebook/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/arpitharavi_telecom-churn-notebook/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/arpitharavi_telecom-churn-notebook/testY.csv",encoding="gbk")


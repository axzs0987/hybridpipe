import pandas as pd
# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from pandas.tools.plotting import scatter_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold
import os
#print(os.listdir("../input"))
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()
import warnings
warnings.filterwarnings('ignore')

# In[None]

eye_data = pd.read_csv(r"../input/eye movement.csv")

# ## ##  # B# a# s# i# c#  # E# D# A

# In[None]

eye_data.info()

# In[None]

eye_data.describe()

# ## ## ## ##  # T# h# e#  # v# a# r# i# a# b# l# e#  # r# a# n# g# e# s#  # v# a# r# y#  # g# r# e# a# t# l# y# .#  # I# t#  # c# a# l# l# s#  # f# o# r#  # s# t# a# n# d# a# r# d# i# s# a# t# i# o# n# !

# In[None]

eye_data.head()

# In[None]

fig,ax = plt.subplots(nrows = 4, ncols=4, figsize=(16,10))
row = 0
col = 0
for i in range(len(eye_data.columns) -1):
    if col > 3:
        row += 1
        col = 0
    axes = ax[row,col]
    sns.boxplot(x = eye_data['Target'], y = eye_data[eye_data.columns[i]],ax = axes)
    col += 1
plt.tight_layout()
# plt.title("Individual Features by Class")
plt.show()

# In[None]

p = eye_data.hist(figsize = (20,20),bins=50)

# In[None]

color_wheel = {1: "#0392cf", 
               2: "#7bc043"}
colors = eye_data["Target"].map(lambda x: color_wheel.get(x + 1))
p = eye_data.Target.value_counts().plot(kind="bar")
plt.xlabel("Target")
plt.ylabel("Count of Target")

# In[None]

X = eye_data.drop(['Target'],axis=1)
y = eye_data.Target

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1556475.npy", { "accuracy_score": score })

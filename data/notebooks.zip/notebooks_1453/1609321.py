import pandas as pd
# ##  # E# m# p# l# o# y# e# e#  # A# t# t# r# i# t# i# o# n#  # D# a# t# a

# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # f# i# n# d#  # m# a# j# o# r#  # c# a# u# s# e# s#  # o# f#  # a# t# t# r# i# t# i# o# n#  # i# n#  # e# m# p# l# o# y# e# e# s# .#  # A# t# t# r# i# t# i# o# n#  # r# e# s# u# l# t# s#  # i# n#  # l# a# c# k#  # o# f#  # p# r# o# d# u# c# t# i# v# i# t# y#  # w# h# i# c# h#  # r# e# u# l# t# s#  # i# n#  # l# a# c# k#  # o# f#  # p# r# o# f# i# t#  # ,# w# h# i# c# h#  # u# l# t# i# m# a# t# e# l# y#  # l# e# a# d# s#  # t# o#  # u# n# e# m# p# l# o# y# m# e# n# t# .#  # I# t#  # s# e# e# m# s#  # s# i# m# p# l# e#  # t# o#  # p# o# i# n# t#  # o# u# t#  # f# e# w#  # f# a# c# t# o# r# s#  # b# e# h# i# n# d#  # a# t# t# r# i# t# i# o# n#  # s# u# c# h#  # a# s#  # l# o# w#  # w# a# g# e# s# ,#  # w# o# r# k# i# n# g#  # e# n# v# i# r# o# n# m# e# n# t# ,# r# e# l# a# t# i# o# n# s# h# i# p#  # w# i# t# h#  # b# o# s# s#  # e# t# c# ,#  # b# u# t#  # a# c# t# u# a# l# l# y#  # t# h# e# r# e#  # a# r# e#  # a#  # l# o# t#  # m# o# r# e#  # f# r# o# m#  # o# n# e# '# s#  # p# e# r# s# o# n# a# l#  # r# e# a# s# o# n#  # t# o#  # h# i# s#  # e# d# u# c# a# t# i# o# n# .#  # A# n# d#  # t# h# i# s#  # i# s#  # w# h# e# r# e#  # S# t# a# t# i# s# t# i# c# s#  # c# o# m# e#  # i# n# .#  # T# h# i# s#  # f# i# e# l# d#  # o# f#  # c# o# n# c# e# r# n#  # i# s#  # s# o#  # w# i# d# e#  # t# h# a# t# i# t#  # h# a# s#  # g# i# v# e# n#  # b# i# r# t# h#  # t# o#  # n# e# w#  # M# L#  # r# e# s# e# a# r# c# h#  # c# a# l# l# e# d#  # *# *# "# I# n# t# e# r# p# r# e# t# a# b# i# l# i# t# y# "# *# *# .

# In[None]

import os
#print(os.listdir("../input"))

# ## ##  # I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # D# a# t# a# s# e# t

# In[None]

import pandas as pd
import numpy as np

# In[None]

data = pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')
data.head()

# In[None]

data.columns

# ## ## ##  # F# e# w#  # o# f#  # t# h# e#  # p# r# e# d# i# c# t# o# r# s#  # a# r# e#  # u# s# e# l# e# s# s#  # c# a# r# r# y# i# n# g#  # s# a# m# e#  # v# a# l# u# e#  # f# o# r#  # a# l# l#  # t# h# e#  # o# b# s# e# r# v# a# t# i# o# n# s#  # ,# t# h# u# s#  # h# a# v# i# n# g#  # n# o#  # s# i# g# n# i# f# i# c# a# n# c# e#  # i# n#  # t# h# e#  # d# e# s# i# r# e# d#  # o# u# t# p# u# t#  # v# a# r# i# a# b# l# e# :# 
# ## ## ## ##  #  #  #  # '# E# m# p# l# o# y# e# e# C# o# u# n# t# '#  # ,#  # '# E# m# p# l# o# y# e# e# N# u# m# b# e# r# '#  # ,#  # '# O# v# e# r# 1# 8# '#  # ,#  # '# S# t# a# n# d# a# r# d# H# o# u# r# s

# In[None]

data = data.drop(['EmployeeCount','EmployeeNumber','Over18','StandardHours'],axis=1)
data.columns

# ## ## ##  # G# e# t# t# i# n# g#  # u# n# i# q# u# e#  # e# l# e# m# e# n# t# s#  # f# o# r#  # e# v# e# r# y#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e

# In[None]

data['MaritalStatus'].unique()

# ## ##  # R# e# p# l# a# c# i# n# g#  # o# u# r#  # A# t# t# r# i# t# i# o# n#  # o# u# t# p# u# t#  # b# y#  # i# n# t# e# g# e# r#  # c# o# n# s# t# a# n# t# s

# In[None]

data.loc[data['Attrition']=='No','Attrition'] = 0
data.loc[data['Attrition']=='Yes','Attrition'] = 1
data.head()

# ## ##  # C# a# t# e# g# o# r# i# s# i# n# g#  # o# n#  # t# h# e#  # b# a# s# i# s#  # o# f#  # t# r# a# v# e# l#  # f# o# r#  # b# u# s# i# n# e# s# s#  # p# u# r# p# o# s# e# s# ;#  # r# a# r# e# l# y# ,# f# r# e# q# u# e# n# t# l# y#  # o# r#  # n# o#  # t# r# a# v# e# l

# In[None]

data['Business_Travel_Rarely']=0
data['Business_Travel_Frequently']=0
data['Business_Non-Travel']=0

data.loc[data['BusinessTravel']=='Travel_Rarely','Business_Travel_Rarely'] = 1
data.loc[data['BusinessTravel']=='Travel_Frequently','Business_Travel_Frequently'] = 1
data.loc[data['BusinessTravel']=='Non-Travel','Business_Non-Travel'] = 1

# ## ##  # C# a# t# e# g# o# r# i# s# i# n# g#  # o# n#  # t# h# e#  # b# a# s# i# s#  # o# f#  # e# d# u# c# a# t# i# o# n#  # f# i# e# l# d

# In[None]

data['Life Sciences']=0
data['Medical']=0
data['Marketing']=0
data['Technical Degree']=0
data['Education Human Resources']=0
data['Education_Other']=0

data.loc[data['EducationField']=='Life Sciences','Life Sciences'] = 1
data.loc[data['EducationField']=='Medical','Medical'] = 1
data.loc[data['EducationField']=='Other','Education_Other'] = 1
data.loc[data['EducationField']=='Technical Degree','Technical Degree'] = 1
data.loc[data['EducationField']=='Human Resources','Education Human Resources'] = 1
data.loc[data['EducationField']=='Marketing','Marketing'] = 1

# ## ##  # C# a# t# e# g# o# r# i# s# i# n# g#  # o# n#  # t# h# e#  # b# a# s# i# s#  # o# f#  # w# o# r# k# i# n# g#  # d# e# p# a# r# t# m# e# n# t

# In[None]

data['Sales']=0
data['R&D']=0
data['Dept_Human Resources'] =0

data.loc[data['Department']=='Sales','Sales'] = 1
data.loc[data['Department']=='Research & Development','R&D'] = 1
data.loc[data['Department']=='Human Resources','Dept_Human Resources'] = 1

# ## ##  #  # S# e# t# t# i# n# g#  # p# r# e# d# i# c# t# o# r#  # g# e# n# d# e# r#  # w# h# e# r# e#  # m# a# l# e#  # i# s#  # i# n# d# i# c# a# t# e# d#  # a# s#  # 1#  # a# n# d#  # f# e# m# a# l# e#  # a# s#  # 0

# In[None]

data.loc[data['Gender']=='Male','Gender'] = 1
data.loc[data['Gender']=='Female','Gender'] = 0

# ## ##  # C# a# t# e# g# o# r# i# s# i# n# g#  # o# n#  # t# h# e#  # b# a# s# i# s#  # o# f#  # J# o# b#  # R# o# l# e

# In[None]

data['Research Scientist']=0
data['Laboratory Technician']=0
data['Sales Executive']=0
data['Manufacturing Director']=0
data['Healthcare Representative']=0
data['Sales Representative']=0
data['Research Director']=0
data['Manager'] = 0
data['Job_Human_Resources'] = 0

data.loc[data['JobRole']=='Research Scientist','Research Scientist'] = 1
data.loc[data['JobRole']=='Laboratory Technician','Laboratory Technician'] = 1
data.loc[data['JobRole']=='Sales Executive','Sales Executive'] = 1
data.loc[data['JobRole']=='Sales Representative','Sales Representative'] = 1
data.loc[data['JobRole']=='Manufacturing Director','Manufacturing Director'] = 1
data.loc[data['JobRole']=='Healthcare Representative','Healthcare Representative'] = 1
data.loc[data['JobRole']=='Research Director','Research Director'] = 1
data.loc[data['JobRole']=='Manager','Manager'] = 1
data.loc[data['JobRole']=='Human Resources','Job_Human_Resources'] = 1
data.head()

# ## ##  # C# a# t# e# g# o# r# i# s# i# n# g#  # o# n#  # t# h# e#  # b# a# s# i# s#  # o# f#  # M# a# r# i# t# a# l#  # S# a# t# u# s#  # o# f#  # E# m# p# l# o# y# e# e

# In[None]

data['Marital_single']=0
data['Marital_married']=0
data['Marital_divorced']=0

data.loc[data['MaritalStatus']=='Married','Marital_married'] = 1
data.loc[data['MaritalStatus']=='Single','Marital_single'] = 1
data.loc[data['MaritalStatus']=='Divorced','Marital_divorced'] = 1

# ## ##  # S# e# t# t# i# n# g#  # u# p#  # t# h# e#  # O# v# e# r#  # T# i# m# e#  # p# r# e# d# i# c# t# o# r

# In[None]

data.loc[data['OverTime']=='No','OverTime'] = 0
data.loc[data['OverTime']=='Yes','OverTime'] = 1
data.head()

# ## ##  # C# h# e# c# k# i# n# g#  # f# o# r#  # u# s# e# l# e# s# s#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # r# e# m# o# v# i# n# g#  # t# h# e# m

# In[None]

data.columns

# In[None]

data = data.drop(['BusinessTravel','EducationField',
                        'Department','JobRole','MaritalStatus'],axis=1)
data.head()

# ## ##  # C# o# n# v# e# r# t# i# n# g#  # d# a# t# a# t# y# p# e# s#  # o# f#  # s# o# m# e#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e# s

# In[None]

data.dtypes

# In[None]

data['Attrition'] = data['Attrition'].astype('int')
data['Gender'] = data['Gender'].astype('int')
data['OverTime'] = data['OverTime'].astype('int')

# ## ##  # F# i# n# d# i# n# g#  # c# o# o# r# e# l# a# t# i# o# n#  # a# m# o# n# g#  # v# a# r# i# o# u# s#  # p# r# e# d# i# c# t# o# r# s

# In[None]

data.corr()

# ## ##  # D# i# v# i# d# i# n# g#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # d# a# t# a# s# e# t

# In[None]

from sklearn.cross_validation import train_test_split
#from random import seed

#seed(20)
train_x = data.drop(['Attrition'],axis=1)
train_y = data['Attrition']

from sklearn.model_selection import train_test_split
X, test_x, Y, test_y = train_test_split(train_x, train_y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X, Y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/1609321.npy", { "accuracy_score": score })

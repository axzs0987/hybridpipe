import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("/kaggle/input/heart-disease-uci/heart.csv")
data.head()
data.describe()
data.isnull().sum()
y=data["target"]
X=data.drop("target",axis=1)
X.head()
y.head()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.preprocessing import MinMaxScaler
scaler=MinMaxScaler()
scaler.fit(X_train)
X_train_scaled=scaler.transform(X_train)
X_test_scaled=scaler.transform(X_test)
from sklearn.linear_model import LogisticRegression
model=LogisticRegression()
#model.fit(X_train_scaled,y_train)
#y_pred=model.predict(X_test_scaled)
from sklearn.metrics import confusion_matrix
#confusion_matrix(y_test,y_pred)
accuracy=(33+40)/(33+40+8+10)
accuracy
from sklearn.neighbors import KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=8)
#knn.fit(X_train_scaled,y_train)
#y_predict_knn=knn.predict(X_test_scaled)
#y_predict_knn
#confusion_matrix(y_predict_knn,y_test)
acc_knn=69/91
acc_knn
#knn.score(X_test_scaled,y_test)
accuracy_knn=[]
for k in range(1,15):
    knn=KNeighborsClassifier(n_neighbors=k)
#    knn.fit(X_train_scaled,y_train)
#    accuracy_knn.append([k,knn.score(X_test_scaled,y_test)])
#    print(k,knn.score(X_test_scaled,y_test))
    
#accuracy_knn
from sklearn.tree import DecisionTreeClassifier
model=DecisionTreeClassifier()
#model.fit(X_train_scaled,y_train)
#y_pred=model.predict(X_test_scaled)
#y_pred
#confusion_matrix(y_test,y_pred)
66/94
#model.score(X_test_scaled,y_test)
from sklearn.model_selection import GridSearchCV
parameters={"max_depth":[1,2,3,4,5,6,7,8,9,10]}
model=DecisionTreeClassifier()
#grid=GridSearchCV(model,parameters,cv=10)
#grid.fit(X_train_scaled,y_train)
#grid.best_params_
#grid.score(X_test_scaled,y_test)
from sklearn.ensemble import RandomForestClassifier
model_rf = RandomForestClassifier(n_estimators=100,max_depth=5,max_features=12,oob_score=True,verbose=1,random_state=50)
#model_rf.fit(X_train_scaled,y_train)
#y_pred_rf=model_rf.predict(X_test_scaled)
#confusion_matrix(y_test,y_pred)
acc=75/91
acc
#model_rf.score(X_test,y_test)
from sklearn.model_selection import GridSearchCV
hyperparameters = {'max_features':np.arange(1,12),'max_depth':np.arange(1,6)}
#model_tune=GridSearchCV(model_rf,hyperparameters,cv=10)
#model_tune.fit(X_train_scaled,y_train)
#model_tune.best_params_
#y_pred_test_cv=model_tune.predict(X_test_scaled)     
#confusion_matrix(y_test,y_pred_test_cv)
76/91  




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ankitbansal2101_heart-disease-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ankitbansal2101_heart-disease-prediction/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ankitbansal2101_heart-disease-prediction/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ankitbansal2101_heart-disease-prediction/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ankitbansal2101_heart-disease-prediction/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ankitbansal2101_heart-disease-prediction/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # *# *

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# *# *# I# m# p# o# r# t# i# n# g#  # D# a# t# a# s# e# t#  # *# *

# In[None]

dataset = pd.read_csv('../input/Social_Network_Ads.csv')

# *# *# G# e# t# t# i# n# g#  # t# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # r# e# l# a# t# e# d#  # t# o#  # D# a# t# a# s# e# t# *# *

# In[None]

dataset.info()

# In[None]

dataset.describe()

# In[None]

dataset.describe(include = ['O'])

# In[None]

dataset['Gender'] = dataset['Gender'].map({'Male':1,'Female':0})

# In[None]

x = dataset.iloc[:,1:4]
y = dataset.iloc[:,4:]

# *# *# N# o# r# m# a# l# i# s# i# n# g# .# .# .# *# *

# In[None]

def normalise(x):
    return ((x - np.min(x))/(np.max(x)-np.min(x)))

x.iloc[:,2:] = x.iloc[:,2:].apply(normalise)

# *# *# S# e# p# e# r# a# t# i# n# g#  # i# n#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # s# e# t# *# *

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4311454.npy", { "accuracy_score": score })

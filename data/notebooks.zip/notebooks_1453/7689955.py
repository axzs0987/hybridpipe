import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

data = pd.read_csv('../input/predicting-a-pulsar-star/pulsar_stars.csv')
data.shape

# In[None]

data.columns

# In[None]

data.isnull().sum()

# In[None]

## Viz

plt.figure(figsize=[8,6])
sns.heatmap(data.corr(), annot=True)

# In[None]

sns.pairplot(data, hue='target_class')

# In[None]

## Scaling

X = data.drop(['target_class'], axis=1)
y = data['target_class']

from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

X_scaled = MinMaxScaler(feature_range=(0,1))
X_train_scaled = X_scaled.fit_transform(X)

X_train_scaled

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7689955.npy", { "accuracy_score": score })

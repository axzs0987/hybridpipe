import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix



# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

# I am using this data set which i took from kaggle named as "Social_Network_ads.csv".
# i will use this data set to pridict who can buy a car if a company launces its new model they can directly contact the employees to advertise there new model
# i am using KNN algorithm of Supervised learning ,which is a classifier type of algorithms


# In[None]

#importing the data set 
data= pd.read_csv("../input/users-of-a-social-networks-who-bought-suv/Social_Network_Ads.csv")
data.head(10)

# In[None]

#now spliting our data  for input and output
#i will take the Age and Estimated Salary columns for the input
input_x=data.iloc[:,[2,3]].values
#now taking the purchased column as output. we can see that purchased columns contain data as binary data(0,1)
#where 0 represent "NO"-it means they donot have car, and 1 represent "YES" -it means they have car
output_x=data.iloc[:,4].values
#now spliting data into Traning Data and Testing Data
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(input_x, output_x, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/6434180.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df = pd.read_csv('/kaggle/input/mobile-price-classification/train.csv')
df.head()
df.isnull().sum()
x = df.drop(columns=['price_range'])
print(x)
y = df['price_range']
print(y)
import matplotlib.pyplot as plt
#plt.hist(df['fc'],rwidth=0.9,alpha=0.3,color='blue',bins=15,edgecolor='red') 
#plt.xlabel('price_range') 
#plt.ylabel('battery_power') 
#plt.title('Mobile Price Classification') 
#plt.show();
import seaborn as sns
#sns.factorplot('fc',data=df,kind='count')
df['talk_time'].hist(bins=70)
#sns.lmplot('pc','price_range',data=df)
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
nb = GaussianNB()
#nb.fit(x_train, y_train)
#y_pred = nb.predict(x_test)
#print(y_pred)
#print(accuracy_score(y_test, y_pred))
from sklearn import model_selection
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
rfc = RandomForestClassifier()
#rfc.fit(x_train,y_train)
#rfc_predict = rfc.predict(x_test)
#print("Accuracy:",accuracy_score(y_test, rfc_predict))
from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier()
#clf = clf.fit(x_train,y_train)
#y_pred = clf.predict(x_test)
#print("Accuracy:",accuracy_score(y_test, y_pred))
from sklearn.neighbors import KNeighborsClassifier  
classifier= KNeighborsClassifier(n_neighbors=5, metric='minkowski', p=2 )  
#classifier.fit(x_train, y_train)  
#y_pred= classifier.predict(x_test)  
from sklearn.metrics import confusion_matrix  
#cm= confusion_matrix(y_test, y_pred)  
#print(accuracy_score(y_test, y_pred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aavinashvijay_mobile-price-predictions-using-ml-algorithms.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aavinashvijay_mobile-price-predictions-using-ml-algorithms/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# ##  # *# *# L# O# A# D#  # T# H# E#  # D# A# T# A# S# E# T# *# *# 


# In[None]

dataset = pd.read_csv('/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# ##  # E# D# A#  # A# N# D#  # P# R# E# P# R# O# C# E# S# S# I# N# G# 


# In[None]

dataset.head()

# L# e# t# s#  # h# a# v# e#  # a#  # c# h# e# c# k#  # f# o# r#  # n# u# l# l#  # v# a# l# u# e# s# :

# In[None]

dataset.isnull().any()

# H# e# r# e#  # q# u# a# l# i# t# y#  # i# s#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt
for feature in dataset.columns:
    if feature == 'quality':
        break
    sns.boxplot('quality',feature, data = dataset)
    plt.figure()
    
        
    

# S# i# n# c# e#  # f# e# w#  # f# e# a# t# u# r# e# s#  # h# a# v# e#  # a#  # l# o# t#  # o# f#  # o# u# t# l# i# e# r# s#  # a#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # w# i# l# l#  # g# i# v# e#  # b# e# t# t# e# r#  # i# n# s# i# g# h# t# s#  # o# n#  # w# h# i# c# h#  # f# e# a# t# u# r# e# s#  # t# o#  # r# e# m# o# v# e#  # a# n# d#  # w# h# i# c# h#  # o# n# e# s#  # t# o#  # k# e# e# p# .

# In[None]

corr = dataset.corr()

fig, ax = plt.subplots(figsize=(10, 8))

sns.heatmap(corr, cmap='coolwarm', annot=True, fmt=".2f")




plt.show()

# p# H# ,# f# r# e# e#  # s# u# l# p# h# u# r#  # d# i# o# x# i# d# e# ,# c# h# l# o# r# i# d# e# s#  # a# n# d#  # r# e# s# i# d# u# a# l#  # s# u# g# a# r#  # a# r# e#  # n# o# t#  # o# f#  # m# u# c# h#  # u# s# e#  # a# s#  # t# h# e# y#  # h# a# v# e#  # v# e# r# y#  # l# e# s# s#  # i# m# p# a# c# t#  # o# n#  # t# a# r# g# e# t#  # q# u# a# l# i# t# y# .

# In[None]

dataset.drop(['pH','chlorides','free sulfur dioxide', 'residual sugar'], axis = 1, inplace = True)

# In[None]

dataset

# L# e# t# s#  # a# n# a# l# y# s# e#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .

# In[None]

sns.countplot(x = 'quality', data = dataset)

# In[None]

bins = (2, 6.5, 8)
labels = ['bad', 'good']
dataset['quality'] = pd.cut(x = dataset['quality'], bins = bins, labels = labels)

# In[None]

sns.countplot(x = 'quality', data = dataset)

# W# e#  # n# e# e# d#  # t# o#  # l# a# b# e# l#  # e# n# c# o# d# e#  # t# h# i# s#  # b# i# n# a# r# y#  # d# a# t# a# .

# In[None]

from sklearn.preprocessing import LabelEncoder
labelencoder = LabelEncoder()
dataset['quality'] = labelencoder.fit_transform(dataset['quality'])

# In[None]

X = dataset.drop('quality', axis = 1)
y = dataset['quality']

# T# r# a# i# n#  # -#  # T# e# s# t#  # S# p# l# i# t

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9425270.npy", { "accuracy_score": score })

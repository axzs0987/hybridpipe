import pandas as pd
# ##  # P# r# o# b# l# e# m#  # S# t# a# t# e# m# e# n# t# 
# 
# W# i# n# e#  # Q# u# a# l# i# t# y#  # P# r# e# d# i# c# t# i# o# n# -# 
# H# e# r# e# ,#  # w# e#  # w# i# l# l#  # a# p# p# l# y#  # a#  # m# e# t# h# o# d#  # o# f#  # a# s# s# e# s# s# i# n# g#  # w# i# n# e#  # q# u# a# l# i# t# y#  # u# s# i# n# g#  # a#  # d# e# c# i# s# i# o# n#  # t# r# e# e# ,#  # a# n# d#  # t# e# s# t#  # i# t#  # a# g# a# i# n# s# t#  # t# h# e#  # w# i# n# e# -# q# u# a# l# i# t# y#  # d# a# t# a# s# e# t#  # f# r# o# m#  # t# h# e#  # U# C#  # I# r# v# i# n# e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # R# e# p# o# s# i# t# o# r# y# .# 
# 


# T# h# e#  # w# i# n# e#  # d# a# t# a# s# e# t#  # i# s#  # a#  # c# l# a# s# s# i# c#  # a# n# d#  # v# e# r# y#  # e# a# s# y#  # m# u# l# t# i# -# c# l# a# s# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # d# a# t# a# s# e# t# .# 
# F# i# n# d#  # m# o# r# e#  # a# b# o# u# t#  # d# a# t# a#  # h# e# r# e#  # -#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# u# c# i# m# l# /# r# e# d# -# w# i# n# e# -# q# u# a# l# i# t# y# -# c# o# r# t# e# z# -# e# t# -# a# l# -# 2# 0# 0# 9

# In[None]

#Import all the necessary modules
import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
import scipy.stats
import os
#print(os.listdir("../input"))


# ##  #  # L# o# a# d#  # t# h# e#  # W# i# n# e#  # D# a# t# a#  # f# i# l# e#  # i# n# t# o#  # P# y# t# h# o# n#  # D# a# t# a# F# r# a# m# e# .#  # 


# L# e# t#  # u# s#  # a# s# s# u# m# e#  # t# h# e#  # d# a# t# a#  # f# r# a# m# e#  # i# s#  # n# a# m# e# d#  # w# i# n# e# _# d# f# 


# In[None]

wine_data = pd.read_csv('../input/winequality-red.csv')

# ##  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g

# In[None]

wine_data.info()

# In[None]

# checking whether column has any value other than numeric value
wine_data[~wine_data.applymap(np.isreal).all(1)]

# In[None]

# checking for nan
wine_data.isin([np.nan]).any()

# In[None]

# grouping data based on quality
# since the problem explains wine quality range from 0 to 6 as 'bad' & quality range from 7 to 10 as 'good'
wine_data.groupby(["quality"]).count()

# I# t#  # i# s#  # a# l# w# a# y# s#  # a#  # g# o# o# d#  # p# r# a# c# t# i# c# e#  # t# o#  # e# y# e# -# b# a# l# l#  # r# a# w#  # d# a# t# a#  # t# o#  # g# e# t#  # a#  # f# e# e# l#  # o# f#  # t# h# e#  # d# a# t# a#  # i# n#  # t# e# r# m# s#  # o# f#  # n# u# m# b# e# r#  # o# f#  # s# t# r# u# c# t# u# r# e#  # o# f#  # t# h# e#  # f# i# l# e# ,#  # n# u# m# b# e# r#  # o# f#  # a# t# t# r# i# b# u# t# e# s# ,#  # t# y# p# e# s#  # o# f#  # a# t# t# r# i# b# u# t# e# s#  # a# n# d#  # a#  # g# e# n# e# r# a# l#  # i# d# e# a#  # o# f#  # l# i# k# e# l# y#  # c# h# a# l# l# e# n# g# e# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

wine_data.head(10)

# In[None]

# since i am going to build a decission tree to predict the wine quality as good or bad 
# I am replacing the vaules
# less than 7 and above 0 with '0' 
# greater than 6 and less than 11 with '1'

wine_data['quality']=wine_data['quality'].replace(3,0)
wine_data['quality']=wine_data['quality'].replace(4,0)
wine_data['quality']=wine_data['quality'].replace(5,0)
wine_data['quality']=wine_data['quality'].replace(6,0)
wine_data['quality']=wine_data['quality'].replace(7,1)
wine_data['quality']=wine_data['quality'].replace(8,1)

# In[None]

# after replacing the quality col with '0' and '1' inferring the count of data based on good(1) and bad(0) quality
# as we can see we have more data for bad quality wine and less data for good quality wine
# so the model ability to predict bad quality wine will be better than to predict good quality wine
wine_data.groupby(["quality"]).count()

# In[None]

wine_data.columns

# In[None]

wine_data.dtypes

# In[None]

wine_data.shape

# In[None]

wine_data.describe().transpose()

# ##  # U# s# i# n# g#  # u# n# i# v# a# r# i# a# t# e#  # a# n# a# l# y# s# i# s#  # c# h# e# c# k#  # t# h# e#  # i# n# d# i# v# i# d# u# a# l#  # a# t# t# r# i# b# u# t# e# s#  # f# o# r#  # t# h# e# i# r#  # b# a# s# i# c#  # s# t# a# t# i# s# t# i# c#  # s# u# c# h#  # a# s#  # c# e# n# t# r# a# l#  # v# a# l# u# e# s# ,#  # s# p# r# e# a# d# ,#  # t# a# i# l# s#  

# In[None]

# positive values denotes more data is distributed around the tails [chlorides,residual sugar,sulphates]
# negative value denotes less data is distributed around the tails [citric acid]
wine_data.kurtosis(numeric_only=True)

# In[None]

print(scipy.stats.mstats.normaltest(wine_data['chlorides']))
print(scipy.stats.kurtosis(wine_data['chlorides']))
print(scipy.stats.kurtosistest(wine_data['chlorides']))

# In[None]

# positive skew denotes right tail is longer
# negative skew denotes left tail is longer
wine_data.skew(numeric_only=True)

# In[None]

print(scipy.stats.skew(wine_data['chlorides']))
print(scipy.stats.skewtest(wine_data['chlorides']))

# In[None]

sns.boxplot(x='chlorides',data=wine_data,orient='h')
# as you can see it is right skewed

# In[None]

sns.boxplot(x='residual sugar',data=wine_data,orient='h')
# as you can see it is right skewed

# In[None]

print(scipy.stats.mstats.normaltest(wine_data['citric acid']))
print(scipy.stats.kurtosis(wine_data['citric acid']))
print(scipy.stats.kurtosistest(wine_data['citric acid']))

# In[None]

print(scipy.stats.skew(wine_data['citric acid']))
print(scipy.stats.skewtest(wine_data['citric acid']))

# In[None]

sns.boxplot(x='citric acid',data=wine_data,orient='h')
# kurtosis gives a negative value which means less data is distributed around the data

# In[None]

sns.boxplot(x='fixed acidity',data=wine_data,orient='h')

# In[None]

sns.boxplot(x='pH',data=wine_data,orient='h')

# ##  # U# s# i# n# g#  # p# a# i# r# p# l# o# t# s#  # a# n# d#  # c# o# r# r# e# l# a# t# i# o# n#  # m# e# t# h# o# d#  # t# o#  # o# b# s# e# r# v# e#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # s# t# a# t# e#  # y# o# u# r#  # i# n# s# i# g# h# t# s# .

# In[None]

sns.pairplot(wine_data, hue="quality",diag_kind="kde")

# In[None]

# Attributes which look normally distributed (density, pH).
# Some of the attributes look like they may have an exponential distribution (residual sugar, chlorides ,etc).

# In[None]

# finding the correlation with each and every feature

# as you can see 'alcohol' is less highly correlated with the 'quality' of the wine when compared to other fetures
# 'volatile acidity , chlorides , free sulfur dioxide , total sulfur dioxide , density & pH' are weakly correlated 
# with 'quality' of the wine

wine_data.corr()

# ##  # D# e# c# i# s# i# o# n#  # t# r# e# e#  # m# o# d# e# l#  # u# s# i# n# g#  # “# e# n# t# r# o# p# y# ”#  # m# e# t# h# o# d#  # o# f#  # f# i# n# d# i# n# g#  # t# h# e#  # s# p# l# i# t#  # c# o# l# u# m# n# s#  # a# n# d#  # f# i# t#  # i# t#  # t# o#  # t# r# a# i# n# i# n# g#  # d# a# t# a# .

# In[None]

X = wine_data[['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
       'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
       'pH', 'sulphates', 'alcohol']]
Y = wine_data['quality']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1871693.npy", { "accuracy_score": score })

import pandas as pd
# In[None]


#Team Members
#Vinay Kumar S R - 01FB16ECS446
#Vivek R - 91FB16ECS455

import numpy as np 

import pandas as pd

File=pd.read_csv("../input/Absenteeism_at_work.csv")
File.head()

# In[None]

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
File.describe()

# In[None]

from sklearn.tree import DecisionTreeClassifier

# In[None]

#Preprocessing data - stage 1 (Removing outliers in label)
sns.boxplot(File['Absenteeism time in hours'])

median = np.median(File['Absenteeism time in hours'])
q75, q25 = np.percentile(File['Absenteeism time in hours'], [75 ,25])
iqr = q75 - q25
print("Lower outlier bound:",q25 - (1.5*iqr))
print("Upper outlier bound:",q75 + (1.5*iqr))

File= File[File['Absenteeism time in hours']<=17]
File= File[File['Absenteeism time in hours']>=-7]

# In[None]

print("count for Output class:")
File['Absenteeism time in hours'].value_counts(sort = False)

# In[None]

fig, ax = plt.subplots(figsize=(20, 20)) 
sns.heatmap(File.corr(), annot = True, ax = ax)

# In[None]

#Splitting data into training and testing
from sklearn.model_selection import train_test_split
y=File['Absenteeism time in hours']
X=File.drop('Absenteeism time in hours',axis=1)#Extracting only the features
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1886887.npy", { "accuracy_score": score })

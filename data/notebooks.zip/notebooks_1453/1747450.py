import pandas as pd
# In[None]

#import libs
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# In[None]

# read  and customize  dataset
data = pd.read_csv("../input/voice.csv")
data.label = [1 if each=="male" else 0 for each  in data.label ]
y = data.label.values
x_data= data.drop(["label"],axis=1).values
#normalization
x=(x_data-np.min(x_data))/(np.max(x_data)-np.min(x_data))
#train and test split
from sklearn.model_selection import train_test_split 
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1747450.npy", { "accuracy_score": score })

import pandas as pd
# ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # o# f#  # A# u# s# t# r# a# l# i# a# n#  # w# e# a# t# h# e# r#  # d# a# t# a#  # u# s# i# n# g#  # s# c# i# k# i# t# -# l# e# a# r# n

# ## ## ##  # I# m# p# o# r# t# i# n# g#  # l# i# b# r# a# r# i# e# s

# In[None]

import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# ## ## ##  # I# m# p# o# r# t#  # w# e# a# t# h# e# r#  # d# a# t# a

# In[None]

data = pd.read_csv('../input/weatherAUS.csv')

# In[None]

data.head()

# *#  # *# *# D# a# t# e# *# *#  # T# h# e#  # d# a# t# e#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# 
# *#  # *# *# L# o# c# a# t# i# o# n# *# *#  # T# h# e#  # c# o# m# m# o# n#  # n# a# m# e#  # o# f#  # t# h# e#  # l# o# c# a# t# i# o# n#  # o# f#  # t# h# e#  # w# e# a# t# h# e# r#  # s# t# a# t# i# o# n# 
# *#  # *# *# M# i# n# T# e# m# p# *# *#  # T# h# e#  # m# i# n# i# m# u# m#  # t# e# m# p# e# r# a# t# u# r# e#  # i# n#  # d# e# g# r# e# e# s#  # c# e# l# s# i# u# s# 
# *#  # *# *# M# a# x# T# e# m# p# *# *#  # T# h# e#  # m# a# x# i# m# u# m#  # t# e# m# p# e# r# a# t# u# r# e#  # i# n#  # d# e# g# r# e# e# s#  # c# e# l# s# i# u# s# 
# *#  # *# *# R# a# i# n# f# a# l# l# *# *#  # T# h# e#  # a# m# o# u# n# t#  # o# f#  # r# a# i# n# f# a# l# l#  # r# e# c# o# r# d# e# d#  # f# o# r#  # t# h# e#  # d# a# y#  # i# n#  # m# m# 
# *#  # *# *# E# v# a# p# o# r# a# t# i# o# n# *# *#  # T# h# e#  # s# o# -# c# a# l# l# e# d#  # C# l# a# s# s#  # A#  # p# a# n#  # e# v# a# p# o# r# a# t# i# o# n#  # (# m# m# )#  # i# n#  # t# h# e#  # 2# 4#  # h# o# u# r# s#  # t# o#  # 9# a# m# 
# *#  # *# *# S# u# n# s# h# i# n# e# *# *#  # T# h# e#  # n# u# m# b# e# r#  # o# f#  # h# o# u# r# s#  # o# f#  # b# r# i# g# h# t#  # s# u# n# s# h# i# n# e#  # i# n#  # t# h# e#  # d# a# y# .# 
# *#  # *# *# W# i# n# d# G# u# s# t# D# i# r# *# *#  # T# h# e#  # d# i# r# e# c# t# i# o# n#  # o# f#  # t# h# e#  # s# t# r# o# n# g# e# s# t#  # w# i# n# d#  # g# u# s# t#  # i# n#  # t# h# e#  # 2# 4#  # h# o# u# r# s#  # t# o#  # m# i# d# n# i# g# h# t# 
# *#  # *# *# W# i# n# d# G# u# s# t# S# p# e# e# d# *# *#  # T# h# e#  # s# p# e# e# d#  # (# k# m# /# h# )#  # o# f#  # t# h# e#  # s# t# r# o# n# g# e# s# t#  # w# i# n# d#  # g# u# s# t#  # i# n#  # t# h# e#  # 2# 4#  # h# o# u# r# s#  # t# o#  # m# i# d# n# i# g# h# t# 
# *#  # *# *# W# i# n# d# D# i# r# 9# a# m# *# *#  # D# i# r# e# c# t# i# o# n#  # o# f#  # t# h# e#  # w# i# n# d#  # a# t#  # 9# a# m# 
# *#  # *# *# W# i# n# d# D# i# r# 3# p# m# *# *#  # D# i# r# e# c# t# i# o# n#  # o# f#  # t# h# e#  # w# i# n# d#  # a# t#  # 3# p# m# 
# *#  # *# *# W# i# n# d# S# p# e# e# d# 9# a# m# *# *#  # W# i# n# d#  # s# p# e# e# d#  # (# k# m# /# h# r# )#  # a# v# e# r# a# g# e# d#  # o# v# e# r#  # 1# 0#  # m# i# n# u# t# e# s#  # p# r# i# o# r#  # t# o#  # 9# a# m# 
# *#  # *# *# W# i# n# d# S# p# e# e# d# 3# p# m# *# *#  # W# i# n# d#  # s# p# e# e# d#  # (# k# m# /# h# r# )#  # a# v# e# r# a# g# e# d#  # o# v# e# r#  # 1# 0#  # m# i# n# u# t# e# s#  # p# r# i# o# r#  # t# o#  # 3# p# m# 
# *#  # *# *# H# u# m# i# d# i# t# y# 9# a# m# *# *#  # H# u# m# i# d# i# t# y#  # (# p# e# r# c# e# n# t# )#  # a# t#  # 9# a# m# 
# *#  # *# *# H# u# m# i# d# i# t# y# 3# p# m# *# *#  # H# u# m# i# d# i# t# y#  # (# p# e# r# c# e# n# t# )#  # a# t#  # 3# p# m# 
# *#  # *# *# P# r# e# s# s# u# r# e# 9# a# m# *# *#  # A# t# m# o# s# p# h# e# r# i# c#  # p# r# e# s# s# u# r# e#  # (# h# p# a# )#  # r# e# d# u# c# e# d#  # t# o#  # m# e# a# n#  # s# e# a#  # l# e# v# e# l#  # a# t#  # 9# a# m# 
# *#  # *# *# P# r# e# s# s# u# r# e# 3# p# m# *# *#  # A# t# m# o# s# p# h# e# r# i# c#  # p# r# e# s# s# u# r# e#  # (# h# p# a# )#  # r# e# d# u# c# e# d#  # t# o#  # m# e# a# n#  # s# e# a#  # l# e# v# e# l#  # a# t#  # 3# p# m# 
# *#  # *# *# C# l# o# u# d# 9# a# m# *# *#  # F# r# a# c# t# i# o# n#  # o# f#  # s# k# y#  # o# b# s# c# u# r# e# d#  # b# y#  # c# l# o# u# d#  # a# t#  # 9# a# m# .#  # T# h# i# s#  # i# s#  # m# e# a# s# u# r# e# d#  # i# n#  # "# o# k# t# a# s# "# ,#  # w# h# i# c# h#  # a# r# e#  # a#  # u# n# i# t#  # o# f#  # e# i# g# t# h# s# .#  # I# t#  # r# e# c# o# r# d# s#  # h# o# w#  # m# a# n# y#  # e# i# g# t# h# s#  # o# f#  # t# h# e#  # s# k# y#  # a# r# e#  # o# b# s# c# u# r# e# d#  # b# y#  # c# l# o# u# d# .#  # A#  # 0#  # m# e# a# s# u# r# e#  # i# n# d# i# c# a# t# e# s#  # c# o# m# p# l# e# t# e# l# y#  # c# l# e# a# r#  # s# k# y#  # w# h# i# l# s# t#  # a# n#  # 8#  # i# n# d# i# c# a# t# e# s#  # t# h# a# t#  # i# t#  # i# s#  # c# o# m# p# l# e# t# e# l# y#  # o# v# e# r# c# a# s# t# .# 
# *#  # *# *# C# l# o# u# d# 3# p# m# *# *#  # F# r# a# c# t# i# o# n#  # o# f#  # s# k# y#  # o# b# s# c# u# r# e# d#  # b# y#  # c# l# o# u# d#  # (# i# n#  # "# o# k# t# a# s# "# :#  # e# i# g# h# t# h# s# )#  # a# t#  # 3# p# m# .#  # S# e# e#  # C# l# o# a# d# 9# a# m#  # f# o# r#  # a#  # d# e# s# c# r# i# p# t# i# o# n#  # o# f#  # t# h# e#  # v# a# l# u# e# s# 
# *#  # *# *# T# e# m# p# 9# a# m# *# *#  # T# e# m# p# e# r# a# t# u# r# e#  # (# d# e# g# r# e# e# s#  # C# )#  # a# t#  # 9# a# m# 
# *#  # *# *# T# e# m# p# 3# p# m# *# *#  # T# e# m# p# e# r# a# t# u# r# e#  # (# d# e# g# r# e# e# s#  # C# )#  # a# t#  # 3# p# m# 
# *#  # *# *# R# a# i# n# T# o# d# a# y# *# *#  # B# o# o# l# e# a# n# :#  # 1#  # i# f#  # p# r# e# c# i# p# i# t# a# t# i# o# n#  # (# m# m# )#  # i# n#  # t# h# e#  # 2# 4#  # h# o# u# r# s#  # t# o#  # 9# a# m#  # e# x# c# e# e# d# s#  # 1# m# m# ,#  # o# t# h# e# r# w# i# s# e#  # 0# 
# *#  # *# *# R# I# S# K# _# M# M# *# *#  # T# h# e#  # a# m# o# u# n# t#  # o# f#  # r# a# i# n# .#  # A#  # k# i# n# d#  # o# f#  # m# e# a# s# u# r# e#  # o# f#  # t# h# e#  # "# r# i# s# k# "# .# 
# *#  # *# *# R# a# i# n# T# o# m# o# r# r# o# w# *# *#  # T# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# .#  # D# i# d#  # i# t#  # r# a# i# n#  # t# o# m# o# r# r# o# w# ?

# ## ## ##  # C# h# e# c# k#  # f# o# r#  # n# u# l# l#  # v# a# l# u# e# s

# In[None]

data[data.isnull().any(axis=1)]

# ## ## ##  # D# a# t# a#  # C# l# e# a# n# i# n# g

# In[None]

del data['Date']

# In[None]

del data['Evaporation']

# In[None]

del data['Sunshine']

# In[None]

data.head()

# In[None]

del data['Location']

# In[None]

before_rows = data.shape[0]
data = data.dropna()
after_rows = data.shape[0]

# In[None]

before_rows

# In[None]

after_rows

# ## ## ##  # H# o# w#  # m# a# n# y#  # r# o# w# s#  # d# r# o# p# p# e# d# ?

# In[None]

before_rows - after_rows

# In[None]

clean_data = data.copy()
clean_data['RainTomorrow'] = clean_data['RainTomorrow'].map({'No':0, 'Yes':1})
clean_data['RainToday'] = clean_data['RainToday'].map({'No':0, 'Yes':1})
clean_data.head(10)

# ## ## ##  # U# s# i# n# g#  # m# o# r# n# i# n# g#  # f# e# a# t# u# r# e# s#  # a# n# d#  # r# a# i# n#  # t# o#  # p# r# e# d# i# c# t#  # n# e# x# t#  # d# a# y#  # r# a# i# n# .

# In[None]

features = ['WindSpeed9am', 'Humidity9am', 'Pressure9am', 
            'Cloud9am', 'Temp9am', 'RainToday']

# In[None]

X = clean_data[features].copy()

# In[None]

y = clean_data['RainTomorrow'].copy()

# ## ## ##  # T# e# s# t#  # a# n# d#  # t# r# a# i# n#  # s# p# l# i# t

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1975037.npy", { "accuracy_score": score })

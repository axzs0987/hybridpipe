import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# In[None]

data = pd.read_csv("../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")

# In[None]

data.shape

# In[None]

data.head()

# In[None]

data.info()

# In[None]

data.corr()['quality']

# In[None]

sns.heatmap(data.corr())

# In[None]

data[data==0].sum()

# In[None]

data.isnull().sum()

# In[None]

data.nunique()

# ##  # *# *# P# a# i# r# p# l# o# t# *# *

# In[None]

sns.pairplot(data)

# In[None]

columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
       'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
       'pH', 'sulphates', 'alcohol',]

# ##  # S# c# a# t# t# e# r# p# l# o# t

# In[None]

for i in columns:
    sns.scatterplot(data = data[i])
    plt.xlabel(i)
    plt.show()

# In[None]

li = list(data['chlorides'].sort_values()[-4:].index)
data['chlorides'][li] = int(data.drop(li)['chlorides'].mode())

# In[None]

li = list(data['total sulfur dioxide'].sort_values()[-2:].index)
data['total sulfur dioxide'][li] = int(data.drop(li)['total sulfur dioxide'].mode())

# In[None]

li = list(data['sulphates'].sort_values()[-7:].index)
data['sulphates'][li] = int(data.drop(li)['sulphates'].mode())

# In[None]

li = list(data['residual sugar'].sort_values()[-11:].index)
data['residual sugar'][li] = int(data.drop(li)['residual sugar'].mean())

# In[None]

for i in columns:
    sns.scatterplot(data = data[i])
    plt.xlabel(i)
    plt.show()

# ##  # B# a# r# p# l# o# t

# In[None]

for i in columns:
    sns.barplot(x='quality', y= i, data=data)
    plt.show()

# ##  # B# o# x# p# l# o# t

# In[None]

for i in columns:    
    sns.boxplot(x='quality', y= i, data=data)
    plt.show()

# *# *# T# r# a# n# s# f# o# r# m# i# n# g#  # Q# u# a# l# i# t# y#  # C# o# l# u# m# n# *# *

# In[None]

def quality_index(x):
    if x > 6:
        return 1
    else:
        return 0

# In[None]

data['quality'] = data['quality'].apply(quality_index)

# In[None]

for i in columns:    
    sns.boxplot(x='quality', y= i, data=data)
    plt.show()

# In[None]

data.head()

# In[None]

data.quality.value_counts()

# M# o# d# u# l# i# n# g

# In[None]

#Now seperate the dataset as response variable and feature variabes
X = data.drop('quality', axis = 1)
y = data['quality']

# In[None]

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

# In[None]

X = scaler.fit_transform(X)

# In[None]

from sklearn.decomposition import PCA
pca = PCA()
x_pca = pca.fit_transform(X)
plt.figure(figsize=(5,4))
plt.plot(np.cumsum(pca.explained_variance_ratio_), 'ro-')
plt.grid()

# In[None]

#Train and Test splitting of data 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_pca, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10869542.npy", { "accuracy_score": score })

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.naive_bayes import MultinomialNB
df = pd.read_csv('../input/heart.csv')
df.head(10)
#df['target'] = df['target'].astype('bool')
df.dtypes
df.describe().round(decimals = 2)
df.corr()
#f, ax = plt.subplots(figsize=(18, 18))
#sns.heatmap(df.corr(), cmap='YlGnBu', annot=True, linewidths=0.5, fmt='.1f', ax=ax)
#plt.show()
df.info()
df['cp'].value_counts()
#df['thalach'].plot(kind="hist", bins=20)
df_x = df.drop(['target'], axis=1)
x = df_x.values
y = df['target'].values
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
gnb = MultinomialNB()
#gnb.fit(x_train, y_train)
#print('Naive Bayes Score: %.3f' % gnb.score(x_test,y_test))
dt = tree.DecisionTreeClassifier()
#dt.fit(x_train, y_train)
#print('Decision Tree Score: %.3f' % dt.score(x_test,y_test))
rfc = RandomForestClassifier()
#rfc.fit(x_train, y_train)
#print('Random Forest Score: %.3f' % rfc.score(x_test,y_test))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amhunt_testing-different-classifications-heart-disease.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/amhunt_testing-different-classifications-heart-disease/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amhunt_testing-different-classifications-heart-disease/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amhunt_testing-different-classifications-heart-disease/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

import numpy as np # linear algebra
import pandas as pd 
import matplotlib.pyplot as plt
from matplotlib.pyplot import show
import seaborn as sns

# In[None]

# Read the data
df = pd.read_csv("/kaggle/input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# In[None]

# Print the data
df.head()

# In[None]

# Check for the summary statistics
df.describe()

# In[None]

# Plot the histogram
df.hist(bins=20,figsize=(20,20))

# In[None]

# Check for data types and missing values
df.info()

# In[None]

# Drop unnecessary columns
df.drop(["EmployeeNumber","EmployeeCount","StandardHours","Over18"],axis=1,inplace=True)

# In[None]

# Check for nulls
df.isnull().sum().plot.bar()

# N# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # a# t#  # a# l# l#  # i# n#  # t# h# e#  # d# a# t# a# !# 


# In[None]

# Plot Co-relation matrix
f, ax = plt.subplots(figsize=(20, 20))
sns.heatmap(df.corr(), annot=True)

# *# *# S# u# m# m# a# r# y#  # f# r# o# m#  # c# o# r# r# e# l# a# t# i# o# n#  # p# l# o# t# *# *# 
# *#  # J# o# b#  # l# e# v# e# l#  # i# s#  # s# t# r# o# n# g# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # t# o# t# a# l#  # w# o# r# k# i# n# g#  # h# o# u# r# s# 
# *#  # M# o# n# t# h# l# y#  # i# n# c# o# m# e#  # i# s#  # s# t# r# o# n# g# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # J# o# b#  # l# e# v# e# l# 
# *#  # M# o# n# t# h# l# y#  # i# n# c# o# m# e#  # i# s#  # s# t# r# o# n# g# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # t# o# t# a# l#  # w# o# r# k# i# n# g#  # h# o# u# r# s# 
# *#  # A# g# e#  # i# s#  # s# t# o# n# g# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e

# In[None]

# Plots
plt.figure(figsize=[20,20])
plt.subplot(611)
sns.countplot(x='JobRole',hue='Attrition',data=df)
plt.subplot(612)
sns.countplot(x='HourlyRate',hue='Attrition',data=df)
plt.subplot(613)
sns.countplot(x='JobInvolvement',hue='Attrition',data=df)
plt.subplot(614)
sns.countplot(x='JobLevel',hue='Attrition',data=df)
plt.subplot(615)
sns.countplot(x='DistanceFromHome',hue='Attrition',data=df)
plt.subplot(616)
sns.countplot(x='Age',hue='Attrition',data=df)

# *# *# S# u# m# m# a# r# y#  # f# r# o# m#  # a# b# o# v# e#  # p# l# o# t# s# *# *# 
# *#  # H# a# l# f#  # o# f#  # s# a# l# e#  # r# e# p# r# e# s# e# n# t# a# t# i# v# e#  # s# t# a# f# f#  # t# e# n# d#  # t# o#  # l# e# a# v# e#  # f# o# l# l# o# w# e# d#  # b# y#  # l# a# b#  # t# e# c# h# n# i# c# i# a# n# s#  # a# n# d#  # r# e# s# e# a# r# c# h#  # s# c# i# e# n# t# i# s# t# 
# *#  # T# h# e#  # e# m# p# l# o# y# e# e# s#  # w# i# t# h#  # J# o# b# I# n# v# o# l# v# e# m# n# e# t#  # s# c# o# r# e#  # 3#  # t# e# n# d#  # t# o#  # q# u# i# t# 
# *#  # M# o# s# t#  # o# f#  # t# h# e#  # s# t# a# f# f#  # i# n#  # J# o# b# L# e# v# e# l#  # 1#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e# 
# *#  # E# m# p# l# o# y# e# e# s#  # b# e# t# w# e# e# n#  # t# h# e#  # a# g# e#  # 2# 6#  # t# o#  # 3# 3#  # h# a# v# e#  # h# i# g# h#  # t# e# n# d# e# n# c# y#  # t# o#  # l# e# a# v# e# 


# In[None]

# Plot the count of Attrition
plt.figure(figsize=[12,12])
total = float(len(df)) 
ax=sns.countplot(df["Attrition"])
# set individual bar lables using above list
for i in ax.patches:
    # get_x pulls left or right; get_height pushes up or down
    ax.text(i.get_x()+0.3, i.get_height()+5,
        str(i.get_height()), fontsize=15,
    color='dimgrey')
        # get_x pulls left or right; get_height pushes up or down
    ax.text(i.get_x()+0.3, i.get_height()+35,
            '{:1.2f}%'.format(i.get_height()/total*100), fontsize=15,
    color='red')
show()


# In[None]

# What is the median salary of each job roles?

plt.figure(figsize=(15,10))
sns.boxplot(x=df.MonthlyIncome,y=df.JobRole)

# *# *# S# u# m# m# a# r# y# :# *# *# 
# 
# *#  # M# a# n# a# g# e# r# s#  # a# n# d#  # R# e# s# e# a# r# c# h#  # d# i# r# e# c# t# o# r# s#  # a# r# e#  # h# i# g# h# l# y#  # p# a# i# d# 
# *#  # S# a# l# e# s#  # R# e# p# r# e# s# e# n# t# a# t# i# v# e# ,#  # L# a# b# o# r# a# t# o# r# y#  # T# e# c# h# n# i# c# i# a# n#  # a# n# d#  # R# e# s# e# a# r# c# h#  # S# c# i# e# n# t# i# s# t#  # g# e# t#  # p# a# i# d#  # p# r# e# t# t# y#  # m# u# c# h#  # t# h# e#  # s# a# m# e# .

# In[None]

# Does people with higher salary work longer and the vice versa?
plt.figure(figsize=(15,10))
sns.boxplot(y=df.JobRole,x=df.TotalWorkingYears)

# *# *# S# u# m# m# a# r# y# :# *# *# 
# 
# *#  # M# a# n# a# g# e# r# s#  # a# n# d#  # R# e# s# e# a# r# c# h#  # d# i# r# e# c# t# o# r# s#  # a# r# e#  # h# i# g# h# l# y#  # p# a# i# d#  # a# n# d#  # s# t# a# y#  # f# o# r#  # l# o# n# g# e# r# 
# *#  # S# a# l# e# s#  # R# e# p# r# e# s# e# n# t# a# t# i# v# e# ,#  # L# a# b# o# r# a# t# o# r# y#  # T# e# c# h# n# i# c# i# a# n#  # a# n# d#  # R# e# s# e# a# r# c# h#  # S# c# i# e# n# t# i# s# t#  # g# e# t#  # p# a# i# d#  # p# r# e# t# t# y#  # m# u# c# h#  # t# h# e#  # s# a# m# e#  # a# n# d#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # q# u# i# t#  # o# f# t# e# n

# In[None]

# Does years with current manager influence the employee to stay longer?
plt.figure(figsize=(15,10))
sns.boxplot(x=df.YearsWithCurrManager,y=df.YearsAtCompany)

# *# *# S# u# m# m# a# r# y# *# *# 
# 
# E# m# p# l# o# y# e# e# s#  # t# e# n# d#  # t# o#  # s# t# a# y#  # l# o# n# g# e# r#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # i# f#  # t# h# e# y#  # s# t# a# y#  # m# o# r# e#  # y# e# a# r# s#  # u# n# d# e# r#  # t# h# e#  # s# a# m# e#  # m# a# n# a# g# e# r

# In[None]

# label encode target variable 
df["Attrition"]=df["Attrition"].astype('category')
df["Attrition"] = df["Attrition"].cat.codes

# In[None]

df["Attrition"]

# In[None]

# encode all categorical columns
Obj_col = df.select_dtypes(include='object')
Obj_col

# In[None]

Obj_col.nunique()

# P# a# n# d# a# s#  # a# s#  # h# a# s#  # i# n# b# u# i# l# t#  # f# u# n# c# t# i# o# n#  # "# g# e# t# _# d# u# m# m# i# e# s# "#  # t# o#  # g# e# t#  # o# n# e#  # h# o# t#  # e# n# c# o# d# i# n# g#  # o# f#  # t# h# a# t#  # p# a# r# t# i# c# u# l# a# r#  # c# o# l# u# m# n# /# s# .

# In[None]

# one line code for one-hot-encoding:
df_encoded=pd.get_dummies(df,columns=Obj_col.columns)
df_encoded.head()

# In[None]

X = df_encoded.loc[:,df_encoded.columns!="Attrition"]
y = df_encoded["Attrition"]
print(X.head())
print(y.head())

# In[None]

# Scaling

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
X= scaler.fit_transform(X)
y=y.values.reshape(-1,1)
print(X.shape)
print(y.shape)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10908552.npy", { "accuracy_score": score })

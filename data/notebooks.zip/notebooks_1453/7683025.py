import pandas as pd
# I# t#  # i# s#  # a#  # v# e# r# y#  # b# a# s# i# c#  # k# e# r# n# e# l#  # f# o# r#  # s# o# m# e# o# n# e#  # w# h# o#  # i# s#  # g# e# t# t# i# i# n# g#  # s# t# a# r# t# e# d#  # i# n#  # t# h# e#  # f# i# e# l# d#  # o# f#  # d# a# t# a#  # s# c# i# e# n# c# e# .# 
# I#  # h# a# v# e#  # t# r# i# e# d#  # t# o#  # p# r# e# d# i# c# t#  # l# o# a# n#  # a# p# p# l# i# c# a# t# i# o# n#  # a# p# p# r# o# v# a# l# s#  # w# i# t# h#  # a#  # r# e# l# a# t# i# v# e# l# y#  # s# m# a# l# l#  # d# a# t# a# s# e# t# .# 
# B# e# l# o# w#  # a# r# e#  # t# h# e#  # s# t# e# p# s#  # t# h# a# t#  # h# a# v# e#  # b# e# e# n#  # c# a# r# r# i# e# d#  # o# u# t#  # i# n#  # t# h# e#  # K# e# r# n# e# l# .# 
# 1# .#  # P# r# e#  # P# r# o# c# e# s# s# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# 
# 2# .#  # S# p# l# i# t# t# i# n# g#  # t# h# e#  # I# n# p# u# t#  # a# n# d#  # t# h# e#  # T# a# r# g# e# t# 
# 3# .#  # S# t# a# n# d# a# r# d# i# z# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# 
# 4# .#  # S# p# l# i# t# t# i# n# g#  # t# h# e#  # I# n# p# u# t#  # a# n# d#  # T# a# r# g# e# t#  # i# n# t# o#  # T# e# s# t#  # a# n# d#  # T# r# a# i# n#  # d# a# t# a# s# e# t# 
# 5# .#  # C# r# e# a# t# i# n# g#  # t# h# e#  # M# o# d# e# l# 
# 6# .#  # T# e# s# t# i# n# g#  # t# h# e#  # M# o# d# e# l

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# I# m# p# o# r# t# i# n# g#  # t# h# e#  # R# e# l# e# v# a# n# t#  # l# i# b# r# a# r# i# e# s#  # t# o#  # b# e#  # u# s# e# d#  # i# n#  # t# h# e#  # K# e# r# n# e# l

# In[None]

import numpy as np
import pandas as pd
import pandas_profiling
from sklearn.linear_model import LogisticRegressionCV, SGDClassifier, LogisticRegression
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix

# L# o# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t

# In[None]

raw_csv_data = pd.read_csv("../input/loan-predication/train_u6lujuX_CVtuZ9i (1).csv")

# S# o#  # t# h# e#  # f# i# r# s# t#  # s# t# e# p#  # i# s#  # p# r# e# p# r# o# c# e# s# s# i# n# g# .# 
# I# n#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # w# e#  # w# i# l# l#  # t# r# y#  # t# o#  # i# d# e# n# t# i# f# y#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # p# o# i# n# t# s# .# 
# 1# .#  # C# h# e# c# k# i# n# g#  # t# h# e#  # n# u# m# e# r# i# c# a# l#  # a# n# d#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# .# 
# 2# .#  # C# h# e# c# k# i# n# g#  # f# o# r#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .# 
# 3# .#  # F# i# l# l# i# n# g#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  # d# u# m# m# y#  # v# a# l# u# e# s# .# 
# 4# .#  # M# a# p# p# i# n# g#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# 
# 5# .#  # D# e# l# e# t# i# n# g#  # t# h# e#  # u# n# w# a# n# t# e# d#  # c# o# l# u# m# n# s# .

# I#  # w# i# l# l#  # u# s# e#  # t# h# e#  # P# a# n# d# a# s#  # P# r# o# f# i# l# i# n# g#  # t# o#  # s# e# e#  # t# h# e#  # d# i# f# f# e# r# e# n# t#  # v# a# r# i# a# b# l# e# s#  # u# s# e# d#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .# 
# I# t#  # w# i# l# l#  # h# e# l# p#  # u# s#  # i# d# e# n# t# i# f# y#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # o# u# t# l# i# e# r# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

raw_csv_data.profile_report()

# M# a# p#  # a# l# l#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# l# u# e# s#  # w# i# t# h#  # n# u# m# e# r# i# c# a# l

# In[None]

raw_csv_data['Gender'] = raw_csv_data['Gender'].map({'Male':1,'Female':0})
raw_csv_data['Married'] = raw_csv_data['Married'].map({'Yes':1,'No':0})
raw_csv_data['Education'] = raw_csv_data['Education'].map({'Graduate':1,'Not Graduate':0})
raw_csv_data['Self_Employed'] = raw_csv_data['Self_Employed'].map({'Yes':1,'No':0})
raw_csv_data['Property_Area'] = raw_csv_data['Property_Area'].map({'Urban':1,'Rural':2,'Semiurban':3})
raw_csv_data['Loan_Status'] = raw_csv_data['Loan_Status'].map({'Y':1,'N':0})

# In[None]

raw_csv_data

# A# s#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # t# h# e#  # c# o# l# u# m# n#  # D# e# p# e# n# d# e# n# t# s#  # h# a# v# e#  # s# o# m# e#  # v# a# l# u# e# s#  # a# s#  # 3# +# .# 
# W# e#  # w# i# l# l#  # c# r# e# a# t# e#  # 4#  # c# l# o# u# m# n# s#  # a# s#  # D# e# p# e# n# d# e# n# t# _# 1# ,#  # D# e# p# e# n# d# e# n# t# _# 2# ,#  # D# e# p# e# n# d# e# n# t# _# 3# ,#  # D# e# p# e# n# d# e# n# t# _# 4#  # f# o# r#  # e# a# c# h# (# 0# ,# 1# ,# 2# ,# 3# +# )#  # a# n# d#  # m# a# p#  # a# l# l#  # t# h# e#  # v# a# l# u# e# s#  # w# i# t# h#  # 1# .

# In[None]

#Keeping a checkpoint
pre_process_data = raw_csv_data

# In[None]

##Insert new columns for dependents
pre_process_data.insert(0, "Dependents_1", 0) 
pre_process_data.insert(1, "Dependents_2", 0) 
pre_process_data.insert(2, "Dependents_3", 0) 
pre_process_data.insert(3, "Dependents_4", 0) 

# In[None]

#Fill all the values for newly created Dependent Column.
for ind in pre_process_data.index: 
     if(pre_process_data['Dependents'][ind] == 0):
        pre_process_data['Dependents_1'][ind] = 1
     elif(pre_process_data['Dependents'][ind] == 1):
        pre_process_data['Dependents_2'][ind] = 1
     elif(pre_process_data['Dependents'][ind] == 2):
        pre_process_data['Dependents_3'][ind] = 1
     elif(pre_process_data['Dependents'][ind] == '3+'):
        pre_process_data['Dependents_4'][ind] = 1

# In[None]

##Drop the Loan Id and the Dependent Column.
pre_process_data = pre_process_data.drop(['Dependents'], axis=1)
pre_process_data = pre_process_data.drop(['Loan_ID'], axis=1)

# A# s#  # w# e#  # s# e# e#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # l# o# t#  # o# f#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # t# h# e#  # S# i# m# p# l# e#  # I# m# p# u# t# e#  # f# r# o# m#  # t# h# e#  # s# c# i# k# i# t#  # l# i# b# r# a# r# y#  # t# o#  # f# i# l# l#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# i# t# h#  # t# h# e#  # d# u# m# m# y#  # v# a# l# u# e# s# .

# In[None]

##Get Dummies
dummies= pd.get_dummies(pre_process_data, drop_first=True)

# We will now impute values
SimImp = SimpleImputer()
pre_process_data = pd.DataFrame(SimImp.fit_transform(dummies), columns=dummies.columns)

# In[None]

##All the missing values have been filled.
pre_process_data.info()

# A# s#  # t# h# e#  # C# o# l# u# m# n#  # L# o# a# n#  # S# t# a# t# u# s#  # i# s#  # o# u# r#  # T# a# r# g# e# t# ,#  # w# e#  # w# i# l# l#  # s# p# l# i# t#  # t# h# e#  # t# a# r# g# e# t# .# 
# A# f# t# e# r#  # t# h# a# t#  # w# e#  # w# i# l# l#  # S# t# a# n# d# a# r# d# i# z# e#  # t# h# e#  # I# n# p# u# t#  # b# y#  # u# s# i# n# g#  # S# t# a# n# d# a# r# d#  # S# c# a# l# e# r#  # o# f#  # S# k# l# e# a# r# n# .

# In[None]

unscaled_inputs=pre_process_data.iloc[:,:-1]

##Standardize the input
from sklearn.preprocessing import StandardScaler
loan_scaler = StandardScaler()
loan_scaler.fit(unscaled_inputs)

# In[None]

scaled_inputs = loan_scaler.transform(unscaled_inputs)
scaled_inputs

# In[None]

##Splitting the Target
targets = pre_process_data['Loan_Status'] 

# N# o# w#  # w# e#  # w# i# l# l#  # s# p# l# i# t#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # T# e# s# t#  # a# n# d#  # T# r# a# i# n#  # u# s# i# n# g#  # t# e# s# t# _# t# r# a# i# n# _# s# p# l# i# t#  # f# r# o# m#  # S# k# l# e# a# r# n

# In[None]

##Split the data into train test and shuffle
from sklearn.model_selection import train_test_split
train_test_split(scaled_inputs,targets)

# C# r# e# a# t# e#  # t# h# e#  # M# o# d# e# l

# In[None]

 ##Logistic Regression with SKlearn
from sklearn.linear_model import LogisticRegression
from sklearn import metrics

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(scaled_inputs, targets, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7683025.npy", { "accuracy_score": score })

import pandas as pd
# ##  # I# E# S# B# 
# ##  # P# ó# s#  # G# r# a# d# u# a# ç# ã# o#  # e# m#  # C# i# ê# n# c# i# a#  # d# e#  # D# a# d# o# s# 
# ## ##  # D# i# s# c# i# p# l# i# n# a#  # -#  # D# a# t# a#  # M# i# n# i# n# g#  # e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # I# I# 
# ## ##  # P# r# o# v# a#  # -#  # 1# 0# /# 0# 9# /# 2# 0# 1# 8# 
# 
# ## ## ##  # D# e# s# c# r# i# ç# ã# o# 
# A#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # "# H# o# m# e#  # E# q# u# i# t# y# "#  # p# o# s# s# u# i#  # d# a# d# o# s#  # p# e# s# s# o# a# s#  # e#  # i# n# f# o# r# m# a# ç# õ# e# s#  # d# e#  # e# m# p# r# é# s# t# i# m# o#  # d# e#  # 5# .# 9# 6# 0#  # e# m# p# r# é# s# t# i# m# o# s#  # r# e# c# e# n# t# e# s# .#  # P# a# r# a#  # c# a# d# a#  # e# m# p# r# é# s# t# i# m# o#  # e# x# i# s# t# e# m#  # 1# 2#  # v# a# r# i# á# v# e# i# s#  # r# e# g# i# s# t# r# a# d# a# s# .# 
# A#  # v# a# r# i# á# v# e# l#  # a# l# v# o#  # (# `# B# A# D# `# )#  # i# n# d# i# c# a#  # q# u# a# n# d# o#  # o#  # c# l# i# e# n# t# e#  # n# ã# o#  # p# a# g# o# u#  # o#  # e# m# p# r# é# s# t# i# m# o#  # (# v# a# l# o# r#  # 1# )# ,#  # e#  # q# u# a# n# d# o#  # e# l# e#  # h# o# n# r# o# u#  # o#  # c# o# m# p# r# o# m# i# s# s# o#  # (# v# a# l# o# r#  # 0# )# .# 
# 
# ## ## ##  # O# b# j# e# t# i# v# o# 
# C# r# i# a# r#  # u# m#  # m# o# d# e# l# o#  # d# e#  # M# L#  # u# s# a# n# d# o#  # R# a# n# d# o# m# F# o# r# r# e# s# t#  # p# a# r# a#  # p# r# e# v# e# r#  # s# e#  # d# e# t# e# r# m# i# n# a# d# o#  # c# l# i# e# n# t# e#  # i# r# á#  # o# u#  # n# ã# o#  # h# o# n# r# a# r#  # o#  # e# m# p# r# é# s# t# i# m# o#  # c# o# n# t# r# a# í# d# o# .# 
# 
# O#  # d# e# s# e# m# p# e# n# h# o#  # d# o#  # m# o# d# e# l# o#  # d# e# v# e#  # s# e# r#  # m# e# d# i# d# o#  # p# e# l# a#  # m# é# t# r# i# c# a#  # d# e#  # a# c# u# r# á# c# i# a#  # (# `# a# c# c# u# r# a# c# y# _# s# c# o# r# e# `# )# .

# In[None]

# Arquivo de dados
import os
#print(os.listdir("../input"))

# *# *# I# t# e# n# s#  # a# v# a# l# i# a# d# o# s# :# *# *# 
# 
# 1# .#  # C# a# r# r# e# g# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s# 
# 2# .#  # V# e# r# i# f# i# c# a# ç# ã# o#  # p# a# r# a#  # s# a# b# e# r#  # s# e#  # o# s#  # d# a# d# o# s#  # f# o# r# a# m#  # i# m# p# o# r# t# a# d# o# s#  # c# o# r# r# e# t# a# m# e# n# t# e# 
# 3# .#  # P# r# é# -# p# r# o# c# e# s# s# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s#  # (# p# r# e# e# n# c# h# i# m# e# n# t# o#  # d# e#  # v# a# l# o# r# e# s#  # e# m#  # b# r# a# n# c# o# ,#  # t# r# a# n# s# f# o# r# m# a# ç# ã# o#  # d# e#  # t# e# x# t# o#  # e# m#  # n# ú# m# e# r# o# )# 
# 4# .#  # S# e# p# a# r# a# r#  # d# a# d# o# s#  # e# m#  # t# r# e# i# n# o#  # e#  # v# a# l# i# d# a# ç# ã# o# 
# 5# .#  # I# n# s# t# a# n# c# i# a# r#  # e#  # t# r# e# i# n# a# r#  # u# m# a#  # `# R# a# n# d# o# m# F# o# r# e# s# t# `# 
# 6# .#  # A# v# a# l# i# a# ç# ã# o#  # d# a#  # p# e# r# f# o# r# m# a# n# c# e#  # d# o#  # m# o# d# e# l# o#  # p# e# l# a#  # m# é# t# r# i# c# a#  # d# e#  # a# c# u# r# á# c# i# a#  # (# `# a# c# c# u# r# a# c# y# _# s# c# o# r# e# `# )# .

# ##  # C# a# r# r# e# g# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s

# In[None]

import pandas as pd
import numpy as np

# In[None]

df = pd.read_csv('../input/hmeq.csv')

# In[None]

df.head()

# In[None]

df.fillna(df.mean(), inplace=True)

# In[None]

df.info()

# In[None]

for col in df.columns:
    if df[col].dtype == 'object':
        df[col]= df[col].astype('category').cat.codes

# In[None]

df.info()

# In[None]

df.sample(12)

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

y_varible = df["BAD"]
x_varible = df.drop(["BAD"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/1617000.npy", { "accuracy_score": score })

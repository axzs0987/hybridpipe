import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
df = pd.read_csv("../input/heart.csv")
df.columns 
df.head()  
df.tail()  
df.shape   
df.info()  
df.describe() 
print(df.sort_values(by=['age']))
#df['sex'] = df['sex'].astype('category') 
#plt.hist(df.age, bins=10, color='green')
#plt.xlabel('AGE')
#plt.ylabel('Frequency')
#plt.title('Histogram of Age')
#plt.show()
#sns.lmplot(x='age', y='trestbps', data=df, hue='sex', palette='muted')
#plt.show()
print('Correlation Coefficient:{}'.format(np.corrcoef(df.age, df.trestbps)[0,1]))
#sns.swarmplot(x='sex', y='thal', data=df, size=7)
#plt.show()
corrmat = df.corr()
#f, ax = plt.subplots(figsize=(10,9))
#sns.heatmap(corrmat, square=True, annot = True, annot_kws={'size':10})
#plt.show()
#sns.lmplot(x='age', y='trestbps', data=df, hue='fbs')
#plt.show()
#sns.set()
cols1= ['slope','cp', 'thalach', 'target']
#sns.pairplot(df[cols1], size=2)
#plt.show()
df1 = df[(df['sex']==1) & (df['fbs']==1)]
print(df1)
print("Average Cholestrol based on Gender")
print(df.groupby('sex')['chol'].mean())
print("Average Resting Blood Pressure based on Gender")
print(df.groupby('sex')['trestbps'].mean())
df.groupby(['thal','cp']).mean()
#plt.figure(figsize=(10,7))
#plt.subplot(3,1,1)
#sns.violinplot(x='cp', y='thalach', inner='points', data=df)
#plt.xticks
#plt.subplot(3,1,2)
#sns.violinplot(x='cp', y='chol', inner='points', data=df)
#plt.subplot(3,1,3)
#sns.violinplot(x='cp', y='trestbps', inner='points', data=df)
#plt.tight_layout()
#plt.show()
#sns.swarmplot(x='sex', y='age', hue='thal', data=df, size=7, palette='deep')
#plt.legend(title='thal', loc='lower center')
#plt.show()
#sns.swarmplot(x='cp', y='trestbps', hue='target', data=df)
#plt.title("0: Female , 1: Male")
#plt.show()
normalize = lambda col_name: df[col_name] /df[col_name].max()
#df['trestbps_norm'] = normalize('trestbps')
#df['chol_norm'] = normalize('chol')
#sns.jointplot(x='age', y='chol_norm', data=df, kind='kde')
#plt.show()
#plt.figure(figsize=(10,8))
#plt.subplot(3,1,1)
#plt.plot(df['trestbps'])
#plt.subplot(3,1,2)
#plt.plot(df['chol'])
#plt.subplot(3,1,3)
#plt.plot(df['thalach'])
#plt.tight_layout()
#plt.show()
def ecdf(data):
    """
    Function Definition: Empirical cumulative distribution function 
    to understand the distribution of Resting BP, Cholestrol and 
    Max. HR Ach.
    
    """
    n=len(data)
    x=np.sort(data)
    y=np.arange(1, n+1)/n
    return x, y
x1, y1 = ecdf(df['trestbps'])
#plt.plot(x1, y1, marker='.', linestyle='none')
#plt.xlabel('Resting Blood Pressure')
#plt.ylabel('ECDF')
#plt.title('Empirical Cumulative Distribution Functions')
#plt.margins(0.02)
#plt.show()
x2, y2 = ecdf(df['chol'])
#plt.plot(x2, y2, marker='.', linestyle='none')
#plt.xlabel('Cholestrol')
#plt.ylabel('ECDF')
#plt.margins(0.02)
#plt.show()
x3, y3 = ecdf(df['thalach'])
#plt.plot(x3, y3, marker='.', linestyle='none')
#plt.xlabel('Max. HR Achieved')
#plt.ylabel('ECDF')
#plt.margins(0.02)
#plt.show()
x4, y4 = ecdf(df['oldpeak'])
#plt.plot(x4, y4, marker='.', linestyle='none')
#plt.xlabel('ST depression induced by exercise relative to rest')
#plt.ylabel('ECDF')
#plt.margins(0.02)
#plt.show()
df.isnull().sum()
nom_fet = ['sex', 'cp', 'restecg', 'exang', 'ca', 'thal']
#df[nom_fet] = df[nom_fet].astype('category')
df_nom_fet = df[nom_fet]
df_onehot = pd.get_dummies(df_nom_fet, drop_first=False)
df.drop(nom_fet, axis=1, inplace=True)
df1 = pd.concat([df, df_onehot], axis=1)
cont_fet = ['trestbps', 'chol', 'thalach', 'oldpeak', 'slope']
df_cont = df1[cont_fet]
from sklearn.preprocessing import StandardScaler
ss = StandardScaler()
ss.fit(df_cont)
scaled = ss.transform(df_cont)
#for i, col in enumerate(cont_fet):
#    df1[col] = scaled[:,i]
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
X = df1.drop('target', axis=1).values
y = df1['target'].values
knn = KNeighborsClassifier(n_neighbors=10)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
#knn.fit(X_train, y_train)
#y_pred = knn.predict(X_test)
#print("Test Set Predictions:\n{}".format(y_pred))
#print("Score:", knn.score(X_test, y_test))
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
param_grid = {'n_neighbors':np.arange(1,50)}
knn = KNeighborsClassifier()
#knn_cv = GridSearchCV(knn, param_grid, cv=5)
#knn_cv.fit(X, y)
#print("Best Params:", knn_cv.best_params_)
#print("Best score:", knn_cv.best_score_)




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anastitan_heart-disease-improvised-model-with-hp-tuning.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anastitan_heart-disease-improvised-model-with-hp-tuning/testY.csv",encoding="gbk")


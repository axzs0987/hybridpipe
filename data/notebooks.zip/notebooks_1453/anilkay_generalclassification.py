import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("/kaggle/input/ph-recognition/ph-data.csv")
data.head()
x=data.iloc[:,0:3]
y=data.iloc[:,3:]
from sklearn.tree import DecisionTreeClassifier
dtc=DecisionTreeClassifier(criterion= "entropy")
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42)
#dtc.fit(x_train,y_train)
#ypred=dtc.predict(x_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
#print(metrik.classification_report(y_true=y_test,y_pred=ypred))
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scale_x=scaler.fit_transform(x)
X_train, X_test, y_train, y_test = train_test_split(scale_x, y, test_size=0.25, random_state=42)
from keras.models import Sequential
from keras.layers import Dense
model = Sequential()
#model.add(Dense(128, input_dim=3, kernel_initializer='normal', activation='relu'))
#model.add(Dense(60,kernel_initializer='normal', activation='relu'))
#model.add(Dense(15,kernel_initializer='normal', activation='softmax'))
#model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
encoder = LabelEncoder()
encoder.fit(y)
encoded_Y = encoder.transform(y)
dummy_y = np_utils.to_categorical(encoded_Y)
dummy_y
X_train, X_test, y_train, y_test = train_test_split(scale_x, dummy_y, test_size=0.25, random_state=42)
#model.fit(X_train,y_train,epochs=200)
#ypred2=model.predict(X_test)
#ypred=ypred2.argmax(1)
y_test=y_test.argmax(1)
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
#print(metrik.classification_report(y_true=y_test,y_pred=ypred))
model = Sequential()
#model.add(Dense(1024, input_dim=3, kernel_initializer='normal', activation='relu'))
#model.add(Dense(500,kernel_initializer='normal', activation='relu'))
#model.add(Dense(120,kernel_initializer='normal', activation='relu'))
#model.add(Dense(60,kernel_initializer='normal', activation='relu'))
#model.add(Dense(15,kernel_initializer='normal', activation='softmax'))
#model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
X_train, X_test, y2_train, y2_test = train_test_split(scale_x, dummy_y, test_size=0.25, random_state=42)
#model.fit(X_train,y2_train,epochs=200)
#ypred3=model.predict(X_test)
#ypred=ypred3.argmax(1)
y_test=y2_test.argmax(1)
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
#print(metrik.classification_report(y_true=y_test,y_pred=ypred))
print(data.shape)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=7)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42)
#knn.fit(x_train,y_train)
#ypred=knn.predict(x_test)
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
#print(metrik.classification_report(y_true=y_test,y_pred=ypred))
best=0
best_acc=0
for i in range(1,15):
    knn=KNeighborsClassifier(n_neighbors=i)
#    knn.fit(x_train,y_train)
#    ypred=knn.predict(x_test)
#    acc=metrik.accuracy_score(y_true=y_test,y_pred=ypred)
#    if best_acc<acc:
#        best=i
#        best_acc=acc
#print("Accuracy: "+str(best_acc))
print("neighbour: "+str(best))
ybinary=y>7
ybinary=ybinary.astype(int)
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, ybinary, train_size=0.8, test_size=1-0.8, random_state=0)
knn = KNeighborsClassifier(n_neighbors=1)
#knn.fit(x_train,y_train)
#ypred=knn.predict(x_test)
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))
#print(metrik.classification_report(y_true=y_test,y_pred=ypred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_generalclassification.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_generalclassification/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/anilkay_generalclassification/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/anilkay_generalclassification/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_generalclassification/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/anilkay_generalclassification/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/anilkay_generalclassification/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_generalclassification/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_generalclassification/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_generalclassification/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_generalclassification/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_generalclassification/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_generalclassification/testY.csv",encoding="gbk")


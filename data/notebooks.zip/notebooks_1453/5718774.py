import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv('/kaggle/input/voicegender/voice.csv')

# F# i# r# s# t# l# y# ,#  # l# o# o# k#  # t# h# e#  # d# a# t# a#  # f# o# r#  # w# h# a# t#  # w# e#  # h# a# v# e# :

# In[None]

data.info()

# In[None]

data.head()

# In[None]

# We need to classificate to genders, so we have to make labels integer rather than object. I decided to make 1 as man, 0 as woman. (I'm not sexist, it is only for implementation, no offense :) )
data.label = [1 if each == 'male' else 0 for each in data.label]

# In[None]

# Our new data
data.label.head() # 1's are for male

# In[None]

data.label.tail() # 0's are for females

# In[None]

y = data.label.values # set y as our genders
x_data = data.drop(['label'],axis=1) # other features in x_data 

# In[None]

# Normalization process is important for making data relevant, 
# which means it is kind of a protection of small datas for avoiding pressure of big datas. (Ex: 0.01 cannot be observed due to 1024.92)  
# This process makes all values between 0 and 1

x = (x_data - np.min(x_data)) / (np.max(x_data)-np.min(x_data)).values

# In[None]

# train test split
# import necessary libraries
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5718774.npy", { "accuracy_score": score })

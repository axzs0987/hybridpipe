import pandas as pd
# I# n#  # t# h# i# s#  # d# a# t# a#  # s# e# t#  # w# e#  # h# a# v# e#  # t# h# e#  # d# a# t# a#  # o# f#  # T# e# l# c# c# o# m#  # C# u# s# t# o# m# e# r# s# .# B# a# s# e# d#  # o# n#  # t# h# e#  # d# a# t# a# s# e# t#  # w# e#  # w# i# l# l#  # u# s# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # t# o#  # p# r# e# d# i# c# t#  # w# h# o#  # w# i# l# l#  # l# e# a# v# e#  # o# r#  # w# h# o#  # w# i# l# l#  # s# t# a# y# ,# P# r# e# d# i# c# t# i# n# g#  # t# h# e#  # c# h# u# r# n#  # c# o# u# l# d#  # b# e#  # u# s# e# f# u# l#  # f# o# r#  # a#  # c# o# m# p# a# n# y#  # t# o#  # d# o#  # t# a# r# g# e# t# e# d#  # m# a# r# k# e# t# i# n# g#  # t# o#  # e# n# s# u# r# e#  # t# h# a# t#  # c# u# s# t# o# m# e# r# s#  # d# o# n# t#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .# T# h# i# s#  # k# e# r# n# e# l#  # i# s#  # w# o# r# k#  # i# n#  # p# r# o# c# e# s# s# .# I# f#  # y# o# u#  # l# i# k# e#  # m# y#  # w# o# r# k#  # p# l# e# a# s# e#  # d# o#  # v# o# t# e# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ## ## ##  # I# m# p# o# r# t# i# n# g#  # P# y# t# h# o# n#  # M# o# d# u# l# e# s

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns
plt.style.use('fivethirtyeight')
import warnings
warnings.filterwarnings('ignore')

# ## ## ##  # I# m# p# o# r# t# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

df = pd.read_csv("../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv")
df.head()

# ## ## ##  # E# x# p# l# o# r# i# n# g#  # t# h# e#  # D# a# t# a

# In[None]

df.describe().T

# In[None]

df.SeniorCitizen.unique()

# In[None]

df.tenure.unique()

# In[None]

len(df.MonthlyCharges.unique())

# In[None]

# Summary of Dataset 
print('Rows     :',df.shape[0])
print('Columns  :',df.shape[1])
print('\nFeatures :\n     :',df.columns.tolist())
print('\nMissing values    :',df.isnull().values.sum())
print('\nUnique values :  \n',df.nunique())

# In[None]

df["Churn"].value_counts(sort = False)

# A# s#  # e# x# p# e# c# t# e# d#  # t# h# i# s#  # i# s#  # n# o# t#  # a#  # b# a# l# a# n# c# e# d#  # d# a# t# a# .# W# e#  # h# a# v# e#  # l# e# s# s#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n#  # c# o# m# p# a# r# e# d#  # t# o#  # r# e# t# e# b# t# i# o# n# .

# In[None]

# Creating a copy of the data 
df_copy = df.copy()

# I# n#  # c# a# s# e#  # w# e#  # w# a# n# t#  # t# o#  # s# e# e#  # t# h# e#  # r# e# a# l#  # d# a# t# a#  # i# t#  # g# o# o# d#  # t# o#  # h# a# v# e#  # a#  # b# a# c# k#  # u# p#  # i# f#  # t# h# e#  # d# a# t# a#  # w# i# t# h#  # u# s# .

# In[None]

df_copy.drop(['customerID','MonthlyCharges','TotalCharges','tenure'],axis=1,inplace = True)
df_copy.head()

# ## ## ## ##  # S# u# m# m# a# r# i# z# i# n# g#  # t# h# e#  # C# h# u# r# n#  # D# a# t# a

# In[None]

summary = pd.concat([pd.crosstab(df_copy[x],df_copy.Churn) for x in df_copy.columns[:-1]], keys= df_copy.columns[:-1])
summary

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # t# a# b# l# e#  # w# e#  # c# a# n#  # s# e# e#  # t# h# e#  # i# n# l# f# u# e# n# c# e#  # o# f#  # e# a# c# h#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e#  # o# n#  # t# h# e#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n#  # f# r# o# m#  # t# h# e#  # t# e# l# e# c# o# n#  # c# o# m# p# a# n# y# .

# ## ## ## ##  # L# e# t# s#  # g# e# t# s#  # p# e# r# c# e# n# t# a# g# e#  # s# u# m# m# a# r# y

# In[None]

summary['Churn_Percentage'] = summary['Yes']*100/(summary['No'] + summary['Yes'])
summary

# L# o# o# k# i# n# g#  # a# t#  # t# h# e#  # p# e# r# c# e# n# t# a# g# e#  # c# h# u# r# n#  # w# e#  # c# a# n#  # t# a# k# e#  # d# e# c# i# s# i# o# n#  # o# n#  # w# h# e# r# e#  # t# o#  # f# o# c# u# s#  # t# o#  # p# r# e# v# e# n# t#  # o# r#  # r# e# d# u# c# e#  # t# h# e#  # c# h# u# r# n#  # o# f#  # c# u# s# t# o# m# e# r# s# .

# ## ##  # V# i# z# u# a# l# i# z# i# n# g#  # t# h# e#  # d# a# t# a

# ## ## ##  # C# h# u# r# n#  # P# e# r# c# e# n# t# a# g# e

# In[None]

from pylab import rcParams # For customizing the plots

# Data to plot
labels = df['Churn'].value_counts(sort= True).index
sizes = df['Churn'].value_counts(sort = True)

colors = ["lightgreen","red"]
explode = (0.05,0)  # explode first slize

rcParams['figure.figsize'] = 7,7

#plot
plt.pie(sizes, explode = explode,labels = labels,colors=colors,autopct='%1.1f%%',shadow = True,startangle=90)

plt.title('Customer churn breakdown')
plt.show()

# ## ## ##  # E# f# f# e# c# t#  # o# f#  # M# o# n# t# h# l# y#  # C# h# a# r# g# e# s#  # o# n#  # C# h# u# r# n

# In[None]

g = sns.factorplot(x='Churn',y="MonthlyCharges",data=df,kind="violin",palette="spring")

# W# e#  # c# a# n#  # v# e# r# y#  # c# l# e# a# r# l# y#  # s# e# e#  # t# h# a# t#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # c# h# u# r# n# e# d#  # t# h# e#  # m# o# s# t#  # p# a# y#  # h# i# g# h#  # m# o# n# t# h# y#  # c# h# a# r# g# e# s# .# S# o#  # w# e#  # n# e# e# d#  # t# o#  # p# a# y#  # m# o# r# e#  # a# t# t# e# n# t# i# o# n#  # t# o#  # h# i# g# h#  # p# a# y# i# n# g#  # c# u# s# t# o# m# e# r# s#  # t# o#  # r# e# d# u# c# e#  # c# h# u# r# n# .

# ## ## ##  # E# f# f# e# c# t#  # o# f#  # t# e# n# u# r# e#  # o# n#  # C# h# u# r# n

# In[None]

g = sns.factorplot(x='Churn',y="tenure",data=df,kind="violin",palette="spring")

# W# e#  # c# a# n#  # v# e# r# y#  # c# l# e# a# r# l# y#  # s# e# e#  # t# h# a# t#  # c# h# u# r# n#  # i# s#  # h# i# g# h# e# r#  # w# h# e# n#  # t# h# e#  # c# u# s# t# o# m# e# r#  # i# s#  # n# e# w# .# S# o#  # w# e#  # h# a# v# e#  # t# o#  # t# a# k# e#  # c# a# r# e#  # d# u# r# i# n# g#  # i# n# i# t# i# a# l#  # t# e# n# u# r# e#  # t# o#  # s# e# e#  # t# h# a# t#  # t# h# e#  # c# h# u# r# n#  # i# s#  # l# o# w# .

# ## ## ##  # P# r# e# p# a# r# i# n# g#  # t# h# e#  # d# a# t# a#  # f# o# r#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # C# l# a# s# s# i# f# i# e# r

# In[None]

# Removing blank space in our date 
len(df[df["TotalCharges"] == ""])
df = df[df["TotalCharges"] != " "]

# In[None]

# Dropping missing values

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

# Customer id col
Id_col = ['customerID']

#Target columns
target_col = ["Churn"]

#categorical columns 
cat_cols = df.nunique()[df.nunique() < 6].keys().tolist()
cat_cols = [x for x in cat_cols if x not in target_col]

#numerical columns
num_cols = [x for x in df.columns if x not in cat_cols + target_col + Id_col]

#Binary columns with 2 values
bin_cols = df.nunique()[df.nunique() == 2].keys().tolist()

#Columns more than 2 values 
multi_cols = [i for i in cat_cols if i not in bin_cols]       

#Label encoding Binary columns 
le = LabelEncoder()
for i in bin_cols :
    df[i] = le.fit_transform(df[i])

#Duplicating columns for multi value columns
df = pd.get_dummies(data = df ,columns = multi_cols)
df.head()

# In[None]

len(df.columns)

# In[None]

num_cols

# In[None]

# Scaling Numerical columns 
std = StandardScaler()

# Scale data
scaled = std.fit_transform(df[num_cols])
scaled = pd.DataFrame(scaled,columns= num_cols)

#dropping original values merging scaled values for numerical values 
df_telecom_og = df.copy()
df = df.drop(columns = num_cols,axis =1)
df = df.merge(scaled,left_index = True,right_index=True,how='left')

#df.info()
df.head()

# S# o#  # n# o# w#  # w# i# t# h#  # t# h# e#  # a# b# o# v# e#  # l# i# n# e# s#  # o# f#  # c# o# d# e#  # w# e#  # h# a# v# e#  # m# a# n# a# g# e# d#  # t# o#  # s# c# a# l# e#  # t# h# e#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # a# n# d#  # k# e# e# p#  # t# h# e#  # e# n# c# o# d# e# d#  # f# e# a# t# u# r# e# s#  # a# s#  # i# t#  # i# s# .# T# o#  # s# e# e#  # t# h# e#  # e# f# f# e# c# t#  # o# f#  # s# c# a# l# l# i# n# g#  # c# h# e# c# k#  # t# o#  # t# h# e#  # r# i# g# h# t#  # s# o# d# e#  # o# f#  # o# u# r#  # d# a# t# a# f# r# a# m# e

# In[None]

df.drop(["customerID"],axis=1,inplace=True)
df.head()

# In[None]

df[df.isnull().any(axis=1)]

# In[None]

df = df.dropna()

# In[None]

# Double check that nulls been removed 
df[df.isnull().any(axis=1)]

# ## ## ##  # M# o# d# e# l# l# i# n# g

# In[None]

from sklearn.model_selection import train_test_split

# We remove the label values from our training data
X = df.drop(['Churn'],axis=1).values

# We have to get the matrix of target variables
y = df["Churn"].values

# In[None]

# Spliting the dataset

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8661017.npy", { "accuracy_score": score })

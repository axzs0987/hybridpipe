import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt
import warnings
warnings.simplefilter("ignore")

# In[None]

df = pd.read_csv("../input/student-grade-prediction/student-mat.csv")
df.head()

# In[None]

d = sns.countplot(df['school'])
d.axes.set_title("Count of School (GP/MS)")
d.axes.set_xlabel("Schools")
d.axes.set_ylabel("Number of Schools")

# In[None]

d = sns.countplot(df['sex'])
d.axes.set_title("Distribution of Gender")
d.axes.set_xlabel("Gender")
d.axes.set_ylabel("Total Student")

# In[None]

d = sns.countplot(df['address'],hue=df['health'])
d.axes.set_title("Distrution of Heath in Urban/Rural Students",fontsize=20)
d.axes.set_xlabel("Urban/Rural Students",fontsize=20)
d.axes.set_ylabel("Total Students",fontsize=20)

# In[None]

sns.swarmplot(df['age'],df['G3'])

# In[None]

plt.figure(figsize=(15,7))
d = sns.countplot(df['Medu'],hue=df['G3'])
d.set_title("Distribution Student Grade with Mother Education")
d.set_xlabel("Mother Education Level")
d.set_ylabel("Number of Grades")

# In[None]

plt.figure(figsize=(15,7))
d = sns.countplot(df['Mjob'],hue=df['G3'])
d.set_title("Distribution Student Grade with Mother Job")
d.set_xlabel("Mother Job")
d.set_ylabel("Number of Grades")

# In[None]

plt.figure(figsize=(15,7))
d = sns.countplot(df['Fedu'],hue=df['G3'])
d.set_title("Distribution Student Grade with Father Education")
d.set_xlabel("Father Education Level")
d.set_ylabel("Number of Grades")

# In[None]

plt.figure(figsize=(15,7))
d = sns.countplot(df['Fjob'],hue=df['G3'])
d.set_title("Distribution Student Grade with Father Job")
d.set_xlabel("Father Job Level")
d.set_ylabel("Number of Grades")

# In[None]

plt.figure(figsize=(17,5))
b = sns.boxplot(df['absences'],df['G3'])
b.axes.set_title("Distrution of Grade and Absenes")
b.axes.set_xlabel("Number of Absenes")
b.axes.set_ylabel("Grade")

# In[None]

d = sns.swarmplot(df['freetime'],y=df['G3'])
d.axes.set_title("Distribution of Freetime and Final Grade")
d.axes.set_xlabel("Free Time")
d.axes.set_ylabel("Grades")

# In[None]

fig, axs = plt.subplots(1,2)

plt.figure(figsize=(15,7))
d = sns.boxplot(df['Pstatus'],df['G3'],ax=axs[0])
d.set_title("Distribution of Parent Living Status with Final Grade")
d.set_xlabel("Parent Living Status")
d.set_ylabel("Final Score")


d = sns.swarmplot(df['Pstatus'],df['G3'],ax=axs[1])
d.set_title("Distribution of Parent Living Status with Final Grade")
d.set_xlabel("Parent Living Status")
d.set_ylabel("Final Score")

# In[None]

family_ed = df['Fedu'] + df['Medu'] 
b = sns.boxplot(x=family_ed,y=df['G3'])
plt.show()

# In[None]

# sns.countplot(df['school'],hue=df['G3'])

# In[None]

gpSchool = df[df['school']=='GP'][:40]
msSchool = df[df['school']=='MS'][:40]
twoSchool = pd.concat([gpSchool,msSchool])

# In[None]

d = sns.countplot(twoSchool['school'],hue=twoSchool['G3'])
d.axes.set_title("Distribution Grade between Two School")
d.axes.set_xlabel("Schools")
d.axes.set_ylabel("Grade")

# In[None]

b = sns.swarmplot(x=df['failures'],y=df['G3'])
b.axes.set_title('Students with less failures score higher', fontsize = 30)
b.set_xlabel('Number of failures', fontsize = 20)
b.set_ylabel('Final Grade', fontsize = 20)
plt.show()

# In[None]

b = sns.boxplot(x = df['higher'], y=df['G3'])
b.axes.set_title('Students who wish to go for higher studies score more', fontsize = 30)
b.set_xlabel('Higher education (1 = Yes)', fontsize = 20)
b.set_ylabel('Final Grade', fontsize = 20)
plt.show()

# In[None]

b = sns.boxplot(x = df['activities'], y=df['G3'])
b.axes.set_title('Students who do Extra Activites')
b.set_xlabel('Extra Activites')
b.set_ylabel('Final Grade')
plt.show()

# In[None]

plt.figure(figsize=(17,7))
b = sns.countplot(df['goout'],hue=df['G3'])
b.axes.set_title('How often do students go out with friends')
b.set_xlabel('Go out')
b.set_ylabel('Count')
plt.show()

# In[None]

df.corr()['G3'].sort_values()

# In[None]

from sklearn.model_selection import cross_val_score,train_test_split,GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder,StandardScaler
from sklearn.metrics import accuracy_score
from random import randint

# In[None]

enc = LabelEncoder()
category_colums = df.select_dtypes('object').columns
for i in category_colums:
    df[i] = enc.fit_transform(df[i])

# In[None]

df.head()

# In[None]

X = df.drop(['school', 'G1', 'G2'], axis=1)
y = df['G3']

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7992064.npy", { "accuracy_score": score })

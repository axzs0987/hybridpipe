import pandas as pd
# In[None]

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

from sklearn.svm import SVC

# In[None]

raw_data = pd.read_csv('../input/indian-liver-patient-records/indian_liver_patient.csv')
raw_data.head()

# In[None]

raw_data.isnull().sum()

# W# e#  # h# a# v# e#  # 4#  # N# u# l# l#  # v# a# l# u# e# s#  # t# o#  # d# e# a# l#  # w# i# t# h# .

# In[None]

raw_data['Dataset'].value_counts()

# T# h# e# r# e#  # a# r# e#  # 4# 1# 6#  # l# i# v# e# r#  # p# a# t# i# e# n# t# s#  # a# n# d#  # 1# 6# 7#  # n# o# n# -# l# i# v# e# r#  # p# a# t# i# e# n# t# s# .#  # S# i# n# c# e#  # i# t#  # i# s#  # m# o# r# e#  # i# m# p# o# r# t# a# n# t#  # f# o# r#  # u# s#  # t# o#  # i# d# e# n# t# i# f# y#  # t# h# e#  # l# i# v# e# r#  # p# a# t# i# e# n# t# s# ,#  # w# e#  # n# e# e# d#  # a# n#  # a# l# g# o# r# i# t# h# m#  # w# i# t# h#  # a#  # h# i# g# h#  # r# e# c# a# l# l#  # s# c# o# r# e# .

# ##  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n

# T# w# o#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # s# t# a# n# d#  # o# u# t#  # a# r# e#  # A# g# e#  # a# n# d#  # G# e# n# d# e# r# .#  # L# e# t# '# s#  # e# s# t# a# b# l# i# s# h#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # t# h# e# s# e# .

# In[None]

sns.lmplot(data=raw_data, x='Age', y='Albumin');
sns.lmplot(data=raw_data, x='Age', y='Total_Protiens');
sns.lmplot(data=raw_data, x='Age', y='Albumin_and_Globulin_Ratio');

# W# e#  # s# e# e#  # t# h# a# t#  # A# l# b# u# m# i# n# ,#  # T# o# t# a# l# _# P# r# o# t# i# e# n# s#  # a# n# d#  # A# l# b# u# m# i# n# _# a# n# d# _# G# l# o# b# u# l# i# n# _# R# a# t# i# o#  # a# r# e#  # l# i# n# e# a# r# l# y#  # d# e# p# e# n# d# e# n# t#  # o# n#  # A# g# e# .

# In[None]

sns.countplot(data=raw_data, x='Gender');

# T# h# e#  # d# a# t# a#  # h# a# s#  # m# o# r# e#  # M# a# l# e#  # r# e# c# o# r# d# s#  # t# h# a# n#  # f# e# m# a# l# e# .#  # W# e#  # w# i# l# l#  # h# a# v# e#  # t# o#  # o# b# s# e# r# v# e#  # t# h# e# m#  # s# e# p# a# r# a# t# e# l# y# .

# In[None]

g = sns.FacetGrid(raw_data, col="Dataset", row="Gender", margin_titles=True)
g.map(plt.hist, "Age")
plt.subplots_adjust(top=0.9)
g.fig.suptitle('Disease by Gender and Age');

# A# m# o# n# g#  # b# o# t# h#  # g# e# n# d# e# r# s# ,#  # m# o# s# t#  # l# i# v# e# r#  # p# a# t# i# e# n# t# s#  # a# r# e#  # a# g# e# d#  # b# e# t# w# e# e# n#  # 3# 0# -# 6# 0#  # y# e# a# r# s# .

# In[None]

corr = raw_data.drop('Dataset',axis=1).corr()
plt.figure(figsize=(30, 30))
sns.heatmap(corr, cbar = True,  square = True, annot=True, fmt= '.2f',annot_kws={'size': 15},
           cmap= 'coolwarm');

# T# h# e# r# e#  # s# e# e# m# s#  # t# o#  # b# e#  # a#  # h# i# g# h#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  #  # 
# T# o# t# a# l# _# B# i# l# i# r# u# b# i# n#  # a# n# d#  # D# i# r# e# c# t# _# B# i# l# i# r# u# b# i# n#  #  # 
# A# s# p# a# r# t# a# t# e# _# A# m# i# n# o# t# r# a# n# s# f# e# r# a# s# e#  # a# n# d#  # A# l# a# m# i# n# e# _# A# m# i# n# o# t# r# a# n# s# f# e# r# a# s# e#  #  # 
# A# l# b# u# m# i# n#  # a# n# d#  # T# o# t# a# l# _# P# r# o# t# i# e# n# s#  #  # 
#  #  # 
# W# e#  # c# a# n#  # r# e# m# o# v# e#  # s# o# m# e#  # o# f#  # t# h# e# s# e# .#  # W# e#  # w# i# l# l#  # r# e# m# o# v# e#  # t# h# e#  # o# n# e# s#  # w# i# t# h#  # l# o# w#  # v# a# r# i# a# t# i# o# n# .

# In[None]

total_direct_bil = raw_data[["Total_Bilirubin", "Direct_Bilirubin"]]
sns.violinplot(data=total_direct_bil);

# T# o# t# a# l# _# B# i# l# i# r# u# b# i# n#  # h# a# s#  # a#  # h# i# g# h# e# r#  # v# a# r# i# a# t# i# o# n# .

# In[None]

aspartate_alamine = raw_data[["Aspartate_Aminotransferase", "Alamine_Aminotransferase"]]
sns.violinplot(data=aspartate_alamine);

# A# s# p# a# r# t# a# t# e# _# A# m# i# n# o# t# r# a# n# s# f# e# r# a# s# e#  # h# a# s#  # a#  # h# i# g# h# e# r#  # v# a# r# i# a# t# i# o# n# .

# In[None]

Total_Protiens_alb = raw_data[["Albumin", "Total_Protiens"]]
sns.violinplot(data=Total_Protiens_alb);

# B# o# t# h#  # h# a# v# e#  # a#  # s# u# b# s# t# a# n# t# i# a# l# l# y#  # h# i# g# h#  # v# a# r# i# a# t# i# o# n# .#  #  # 
#  #  # 
# T# h# e#  # f# e# a# t# u# r# e# s#  # I#  # w# i# l# l#  # k# e# e# p#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t#  # a# r# e# :#  #  # 
# A# g# e# ,#  # G# e# n# d# e# r# ,#  # T# o# t# a# l# _# B# i# l# i# r# u# b# i# n# ,#  # A# s# p# a# r# t# a# t# e# _# A# m# i# n# o# t# r# a# n# s# f# e# r# a# s# e# ,#  # A# l# b# u# m# i# n# ,#  # T# o# t# a# l# _# P# r# o# t# i# e# n# s# ,#  # A# l# b# u# m# i# n# _# a# n# d# _# G# l# o# b# u# l# i# n# _# R# a# t# i# o# ,#  # D# a# t# a# s# e# t

# In[None]

reduced_data = raw_data[["Age","Gender","Total_Bilirubin","Aspartate_Aminotransferase","Albumin", "Total_Protiens", "Albumin_and_Globulin_Ratio","Dataset"]]
reduced_data.head()

# ##  # N# o# r# m# a# l# i# z# a# t# i# o# n#  # a# n# d#  # N# u# l# l# s

# In[None]

reduced_data[reduced_data['Albumin_and_Globulin_Ratio'].isnull()]

# In[None]

grouped = reduced_data.groupby(["Gender","Dataset"])
reduced_data['Albumin_and_Globulin_Ratio'] = grouped['Albumin_and_Globulin_Ratio'].transform(lambda x: x.fillna(x.mean()))

# W# e#  # r# e# p# l# a# c# e#  # t# h# e#  # N# u# l# l#  # v# a# l# u# e# s#  # w# i# t# h#  # g# r# o# u# p#  # m# e# a# n# s#  # t# o#  # m# a# i# n# t# a# i# n#  # t# h# e#  # e# f# f# e# c# t# s#  # o# f#  # G# e# n# d# e# r# .

# In[None]

le = LabelEncoder()
reduced_data.Gender = le.fit_transform(reduced_data.Gender)
reduced_data.head()

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(reduced_data, reduced_data.Dataset, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7333355.npy", { "accuracy_score": score })

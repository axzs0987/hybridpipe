import pandas as pd
# In[None]

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd

# In[None]

# set random seed
np.random.seed(123)

# In[None]

df = pd.read_csv("../input/weatherAUS.csv")
# remove RISK_MM as suggested
df = df.drop(['RISK_MM'], axis = 1)
df.head()

# In[None]

df.isna().sum()/df.count().max()*100

# In[None]

# add indicator columns for missing values
missing = df.isnull().astype(int).add_suffix("_missing")
print(missing.head())

# replace missing with mean
cleaned = df.fillna(df.mean())
cleaned = cleaned.dropna() # drop rows with NA for RainToday
cleaned = cleaned.join(missing)

# convert date to year and day of year[0-365]
cleaned['Year'] = pd.to_datetime(cleaned['Date']).dt.year
cleaned['Month'] = pd.to_datetime(cleaned['Date']).dt.month
cleaned['Day'] = pd.to_datetime(cleaned['Date']).dt.day
cleaned['DayOfYear'] = pd.to_datetime(cleaned['Date']).dt.strftime('%j')

# drop Date and unnecessary Missing Attributes
cleaned.drop(['Date','Date_missing','Location_missing','RainTomorrow_missing'],axis = 1, inplace=True)

# Convert categorical to numerical
cleaned = pd.get_dummies(cleaned, columns = ['Location','WindGustDir','WindDir9am','WindDir3pm'])

# Convert Yes/No to Boolean
cleaned = cleaned.replace({'RainToday': {'Yes': 1, 'No': 0}})
cleaned = cleaned.replace({'RainTomorrow': {'Yes': 1, 'No': 0}})
cleaned.head()

# In[None]

# Seperate X and Y
X = cleaned.drop('RainTomorrow',axis=1).astype('float64')
y = cleaned['RainTomorrow']


# Train Test Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2657673.npy", { "accuracy_score": score })

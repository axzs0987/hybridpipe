import numpy as np 
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt 
import os
#print(os.listdir("../input"))
data = pd.read_csv('../input/Churn_Modelling.csv')
data.head()
data.info()
data.drop(['RowNumber', 'CustomerId', 'Surname', 'Geography'], axis=1, inplace=True)
data.Gender = [1 if each == 'Male' else 0 for each in data.Gender]
data.sample(5)
#plt.figure(figsize=[5,5])
#sns.set(style='darkgrid')
#ax = sns.countplot(x='Exited', data=data, palette='Set3')
data.loc[:,'Exited'].value_counts()
y = data.Exited.values
x_data = data.drop(['Exited'], axis=1)
x_data.describe()
x = (x_data - np.min(x_data)) / (np.max(x_data)-np.min(x_data))
x.head()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
print('x_train shape: ', x_train.shape)
print('y_train shape: ', y_train.shape)
print('x_test shape: ', x_test.shape)
print('y_test shape: ', y_test.shape)
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
#lr.fit(x_train, y_train)
#y_pred0 = lr.predict(x_test)
from sklearn.metrics import confusion_matrix
#lr_cm = confusion_matrix(y_test, y_pred0)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(lr_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('Logistic Regression Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_lr = lr.score(x_test, y_test)
#print(score_lr)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=13)
#knn.fit(x_train, y_train)
#y_pred1 = knn.predict(x_test)
from sklearn.metrics import confusion_matrix
#knn_cm = confusion_matrix(y_test, y_pred1)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(knn_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('KNN Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_knn = knn.score(x_test, y_test)
#print(score_knn)
from sklearn.svm import SVC
svm = SVC(random_state=2)
#svm.fit(x_train, y_train)
#y_pred2 = svm.predict(x_test)
from sklearn.metrics import confusion_matrix
#svm_cm = confusion_matrix(y_test, y_pred2)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(svm_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('SVM Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_svm = svm.score(x_test, y_test)
#print(score_svm)
from sklearn.naive_bayes import GaussianNB
nb = GaussianNB()
#nb.fit(x_train, y_train)
#y_pred3 = nb.predict(x_test)
from sklearn.metrics import confusion_matrix
#nb_cm = confusion_matrix(y_test, y_pred3)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(nb_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('Naive Bayes Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_nb = nb.score(x_test, y_test)
#print(score_nb)
from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier()
#dt.fit(x_train, y_train)
#y_pred4 = dt.predict(x_test)
from sklearn.metrics import confusion_matrix
#dt_cm = confusion_matrix(y_test, y_pred4)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(dt_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('Decision Tree Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_dt = dt.score(x_test, y_test)
#print(score_dt)
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(n_estimators=100, random_state=3)
#rf.fit(x_train, y_train)
#y_pred5 = rf.predict(x_test)
from sklearn.metrics import confusion_matrix
#rf_cm = confusion_matrix(y_test, y_pred5)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(rf_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax, cmap='BrBG')
#plt.title('Random Forest Classification Confusion Matrix')
#plt.xlabel('y_pred')
#plt.ylabel('y_test')
#plt.show()
#score_rf = rf.score(x_test, y_test)
#print(score_rf)
#data_scores = pd.Series([score_lr, score_knn, score_svm, score_nb, score_dt, score_rf],                         index=['logistic_regression_score', 'knn_score', 'svm_score', 'naive_bayes_score', 'decision_tree_score', 'random_forest_score']) 
#data_scores
#d = {'y_test': y_test, 'log_reg_pred': y_pred0,'knn_prediction': y_pred1,      'svm_prediction': y_pred2, 'naive_bayes_prediction': y_pred3,      'decision_tree_prediction': y_pred4, 'random_forest_prediction': y_pred5}
#data01 = pd.DataFrame(data=d)
#data01.T
#fig = plt.figure(figsize=(15,15))
#ax1 = fig.add_subplot(3, 3, 1) 
#ax1.set_title('Logistic Regression Classification')
#ax2 = fig.add_subplot(3, 3, 2) 
#ax2.set_title('KNN Classification')
#ax3 = fig.add_subplot(3, 3, 3)
#ax3.set_title('SVM Classification')
#ax4 = fig.add_subplot(3, 3, 4)
#ax4.set_title('Naive Bayes Classification')
#ax5 = fig.add_subplot(3, 3, 5)
#ax5.set_title('Decision Tree Classification')
#ax6 = fig.add_subplot(3, 3, 6)
#ax6.set_title('Random Forest Classification')
#sns.heatmap(data=lr_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax1, cmap='BrBG')
#sns.heatmap(data=knn_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax2, cmap='BrBG')   
#sns.heatmap(data=svm_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax3, cmap='BrBG')
#sns.heatmap(data=nb_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax4, cmap='BrBG')
#sns.heatmap(data=dt_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax5, cmap='BrBG')
#sns.heatmap(data=rf_cm, annot=True, linewidth=0.7, linecolor='cyan', fmt='.0f', ax=ax6, cmap='BrBG')
#plt.show()




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/akdagmelih_classification-model-comparison-banks-customers.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/akdagmelih_classification-model-comparison-banks-customers/testY.csv",encoding="gbk")


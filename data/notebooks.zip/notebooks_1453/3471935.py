import pandas as pd
# In[29]

import numpy as np # 数组常用库
import pandas as pd # 读入csv常用库
from patsy import dmatrices # 可根据离散变量自动生成哑变量
from sklearn.linear_model import LogisticRegression # sk-learn库Logistic Regression模型
from sklearn.model_selection import train_test_split, cross_val_score # sk-learn库训练与测试
from sklearn import metrics # 生成各项测试指标库
import matplotlib.pyplot as plt # 画图常用库


# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)

# >#  # 从# .# .# /# i# n# p# u# t# /# H# R# _# c# o# m# m# a# _# s# e# p# .# c# s# v# 文# 件# 中# 读# 入# 数# 据# ，# 存# 入# d# a# t# a

# In[30]

data = pd.read_csv("../input/HR_comma_sep.csv")
print(data.shape)
print(data.dtypes)
data.head()

# In[31]

data.left = data.left.astype(int)

# 观# 察# 离# 职# 人# 数# 与# 工# 资# 分# 布# 的# 关# 系

# In[32]

pd.crosstab(data.salary, data.left).plot(kind='bar')
plt.show()

# 观# 察# 离# 职# 比# 例# 与# 工# 资# 分# 布# 的# 关# 系

# In[33]

analysis = pd.crosstab(data.salary, data.left)
print(analysis)
print(analysis.sum(1))

analysis.div(analysis.sum(1), axis = 0).plot(kind='bar', stacked = True)
plt.show()

# 员# 工# 满# 意# 度# 分# 布# 图

# In[35]

data[data.left==0].satisfaction_level.hist()
plt.show()

data[data.left==1].satisfaction_level.hist()
plt.show()

# d# m# a# t# r# i# c# e# s# 将# 数# 据# 中# 的# 离# 散# 变# 量# 变# 成# 哑# 变# 量# ，# 并# 指# 明# 用# s# a# t# i# s# f# a# c# t# i# o# n# _# l# e# v# e# l# ,#  # l# a# s# t# _# e# v# a# l# u# a# t# i# o# n# ,#  # .# .# .#  # 来# 预# 测# l# e# f# t

# In[36]

model = LogisticRegression()
y, X = dmatrices('left~satisfaction_level+last_evaluation+number_project+average_montly_hours+time_spend_company+Work_accident+promotion_last_5years+C(sales)+C(salary)', data, return_type='dataframe')

# In[37]

X = X.rename(columns = {
    'C(sales)[T.RandD]': 'Department: Random',
    'C(sales)[T.accounting]': 'Department: Accounting',
    'C(sales)[T.hr]': 'Department: HR',
    'C(sales)[T.management]': 'Department: Management',
    'C(sales)[T.marketing]': 'Department: Marketing',
    'C(sales)[T.product_mng]': 'Department: Product_Management',
    'C(sales)[T.sales]': 'Department: Sales',
    'C(sales)[T.support]': 'Department: Support',
    'C(sales)[T.technical]': 'Department: Technical',
    'C(salary)[T.low]': 'Salary: Low',
    'C(salary)[T.medium]': 'Salary: Medium'}) 
y = np.ravel(y) # 将y变成np的一维数组

# 用# X# 和# y# 训# 练# 模# 型# ，# 然# 后# 输# 出# X# 中# 每# 一# 项# 自# 变# 量# 对# 于# y# 的# 影# 响# 
# z# i# p# (# a# ,# b# )# 可# 将# a# 的# 每# 一# 个# 元# 素# 和# b# 里# 对# 应# 位# 置# 的# 元# 素# 组# 成# 一# 对

# In[38]

model.fit(X, y)
pd.DataFrame(list(zip(X.columns, np.transpose(model.coef_))))

# m# o# d# e# l# .# s# c# o# r# e# 为# 准# 确# 率# (# 0# 到# 1# 之# 间# )

# In[39]

print(model.score(X,y))
model.coef_

# 预# 测# 这# 样# 一# 个# 人# 的# 离# 职# 概# 率# ：# 
# 一# 个# 高# 工# 资# H# R# ，# 
# 对# 公# 司# 满# 意# 度# 0# .# 5# ,#  # 
# 上# 次# 评# 审# 0# .# 7# 分# ，# 
# 做# 过# 4# 个# 项# 目# ，# 
# 每# 月# 平# 均# 工# 作# 1# 6# 0# 小# 时# ，# 
# 在# 公# 司# 呆# 了# 3# 年# ，# 
# 过# 去# 5# 年# 没# 有# 被# 晋# 升# ，# 
# 没# 有# 工# 伤

# In[40]

model.predict_proba([[1,0,0,1,0,0,0,0,0,0,0,0, 0.5, 0.7, 4.0, 160, 3.0, 0, 0]])

# In[41]

model.predict_proba(X)
pred = model.predict(X)
(abs(pred-y)).sum() / len(y)

# 生# 成# 7# :# 3# 的# 训# 练# 测# 试# 集# 并# 在# 训# 练# 集# 上# 训# 练# 模# 型# m# o# d# e# l# 2

# In[42]

from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(Xtrain, ytrain)
y_pred = model.predict(Xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/3471935.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings                       
warnings.filterwarnings("ignore")
dataset = pd.read_csv('../input/advertising.csv')
dataset.head()

# In[None]

dataset.info()

# In[None]

#Check for duplicates
dataset.duplicated().sum()

# In[None]

#Check for missing features
dataset.isnull().sum()

# In[None]

#Correlation analysis
corrm = dataset.corr()
corrm['Clicked on Ad'].sort_values(ascending = False)

# In[None]

#Exploring target
dataset['Clicked on Ad'].value_counts()

# In[None]

sns.countplot(x = 'Clicked on Ad', data = dataset)

# In[None]

#Statistical information on the numeric features
dataset.describe()

# In[None]

#Statistical information on the categorical features
categ_cols = ['Ad Topic Line', 'City', 'Country']
dataset[categ_cols].describe(include = ['O'])

# E# x# t# r# a# c# t# i# n# g#  # D# a# t# e# t# i# m# e#  # f# e# a# t# u# r# e# s

# In[None]

dataset['Timestamp'] = pd.to_datetime(dataset['Timestamp'])
dataset['Timestamp']
dataset['Year'] = dataset['Timestamp'].dt.year
dataset['Month'] = dataset['Timestamp'].dt.month
dataset['Day'] = dataset['Timestamp'].dt.day
dataset['Hour'] = dataset['Timestamp'].dt.hour
dataset['Weekday'] = dataset['Timestamp'].dt.dayofweek
dataset = dataset.drop(['Timestamp'], axis=1)
dataset.head(10)

# 
# R# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # f# e# a# t# u# r# e# s# 


# In[None]

#Relationship between numerical featuers
sns.pairplot(dataset, hue = 'Clicked on Ad', 
             vars = ['Daily Time Spent on Site', 'Age', 'Area Income', 'Daily Internet Usage'], palette = 'Greens_r')

# In[None]

dataset = dataset.drop(['Year'], axis=1)
#Correlation heatmap with new features
fig = plt.figure(figsize = (12,10))
sns.heatmap(dataset.corr(), cmap='Greens', annot = True)

# B# u# i# l# d# i# n# g#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l

# In[None]

X = dataset.iloc[:,[0,1,2,3,6,9,10,11,12]].values
y = dataset.iloc[:,8].values
#Splitting the data into train and test sets 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3653930.npy", { "accuracy_score": score })

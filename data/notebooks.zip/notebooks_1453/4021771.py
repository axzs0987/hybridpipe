import pandas as pd
# In[1]

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier

# In[4]

#printing the first 5 rows
df=pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')
df.head()

# In[5]

#checking for null values in the dataset
df.isnull().sum()
#No null values in the dataset

# In[6]

#datatypes of all the fields in the dataset
df.dtypes

# In[7]

correlation_df = df.corr()
# The below correlation coefficients is NaN for Employee Count and Standard Hours Fields
#This may be because of the zero variance in those fields
employee_count_var = df["EmployeeCount"].var() #this is 0
standard_hours_var = df["StandardHours"].var() #this is 0

# In[8]

#Hence we drop these 2 rows
new_df = df.drop(["EmployeeCount","StandardHours"],axis = 1)

# In[9]

new_df.head()

# In[10]

correlation_new_df = new_df.corr()
correlation_new_df

# In[11]

#The above given matrix can also be drawn on MatplotLib for better visual Interpretation

sns.set()
f, ax = plt.subplots(figsize=(10, 8))
corr = new_df.corr()
sns.heatmap(corr, mask=np.zeros_like(corr), cmap=sns.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax)
plt.show()

# N# o# w#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # p# l# o# t# ,#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # Y# e# a# r# s# A# t# C# o# m# p# a# n# y# ,# Y# e# a# r# s# I# n# C# u# r# r# e# n# t# R# o# l# e# ,# Y# e# a# r# s# S# i# n# c# e# L# a# s# t# P# r# o# m# o# t# i# o# n#  # a# n# d#  # Y# e# a# r# s# W# t# i# h# C# u# r# r# M# a# n# a# g# e# r# 
# a# r# e#  # c# l# o# s# e# l# y#  # r# e# l# a# t# e# d# ,#  # H# e# n# c# e#  # w# e#  # d# r# o# p#  # t# h# o# s# e#  # c# o# l# u# m# n# s# .# 
# A# l# s# o# ,#  # w# e# '# l# l#  # d# r# o# p#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # r# o# w# s#  # b# a# s# e# d#  # o# n#  # t# h# e# i# r#  # H# i# g# h#  # C# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t#  # f# r# o# m#  # t# h# e#  # p# l# o# t# :# 
# 1# .#  # T# o# t# a# l# W# o# r# k# i# n# g# Y# e# a# r# s# 
# 2# .#  # P# e# r# c# e# n# t# S# a# l# a# r# y# H# i# k# e# 
# 3# .#  # P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# 
# 4# .#  # N# u# m# C# o# m# p# a# n# i# e# s# W# o# r# k# e# d# 
# 5# .#  # M# o# n# t# h# l# y# I# n# c# o# m# e# 
# 
# 


# In[12]

#After removing the strongly correlated variables
df_numerical = new_df[['Age','DailyRate','DistanceFromHome','Education',
                       'EnvironmentSatisfaction', 'HourlyRate',                     
                       'JobInvolvement', 'JobLevel','MonthlyRate',
                       'JobSatisfaction',
                       'RelationshipSatisfaction', 
                       'StockOptionLevel',
                        'TrainingTimesLastYear','WorkLifeBalance']].copy()
df_numerical.head()

# N# o# w#  # w# e#  # c# a# n#  # s# c# a# l# e#  # o# u# r#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # e# i# t# h# e# r#  # b# y#  # S# t# a# n# d# a# r# d# S# c# a# l# e# r#  # o# r#  # b# y#  # u# s# i# n# g#  # m# a# t# h#  # o# p# e# r# a# t# i# o# n# s# 


# In[13]

df_numerical = abs(df_numerical - df_numerical.mean())/df_numerical.std()  
df_numerical.head()

# A# s#  # w# e#  # h# a# v# e#  # g# o# t#  # o# u# r#  # n# u# m# e# r# i# c# a# l#  # d# a# t# a#  # s# e# t#  # u# p#  # f# o# r#  # m# o# d# e# l# l# i# n# g# ,#  # W# e#  # n# e# e# d#  # t# o#  # d# o#  # t# h# e#  # s# a# m# e#  # f# o# r#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a# .# 
# W# e#  # c# r# e# a# t# e#  # d# u# m# m# i# e# s#  # f# o# r#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a#  # a# n# d#  # r# e# m# o# v# e#  # a# n# y#  # r# e# d# u# n# d# a# n# t#  # r# o# w# s# .

# In[14]

df_categorical = new_df[['Attrition', 'BusinessTravel','Department',
                       'EducationField','Gender','JobRole',
                       'MaritalStatus',
                       'Over18', 'OverTime']].copy()
df_categorical.head()

# In[15]

df_categorical["Over18"].value_counts()
#Since all values are Y, we can drop this column

# In[16]

df_categorical = df_categorical.drop(["Over18"],axis = 1)

# In[17]

# We now Label Encode the Attrition data 
lbl = LabelEncoder()
lbl.fit(['Yes','No'])
df_categorical["Attrition"] = lbl.transform(df_categorical["Attrition"])
df_categorical.head()

# In[18]

# We create dummies for the remaining categorical variables

df_categorical = pd.get_dummies(df_categorical)
df_categorical.head()

# In[19]

#Now we finally join both the numerical and categorical dataframes for model evaluation

final_df = pd.concat([df_numerical,df_categorical], axis= 1)
final_df.head()


# N# o# w#  # w# e#  # f# i# n# a# l# l# y#  # h# a# v# e#  # t# o#  # s# p# l# i# t#  # o# u# r#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t#  # s# e# t# .#  # F# i# r# s# t# ,#  # w# e#  # a# l# l# o# t#  # t# h# e#  # i# n# p# u# t#  # a# n# d#  # t# h# e#  # o# u# t# p# u# t#  # v# a# r# i# a# b# l# e# s# 


# In[20]

X = final_df.drop(['Attrition'],axis= 1)
y = final_df["Attrition"]


# In[21]



from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4021771.npy", { "accuracy_score": score })

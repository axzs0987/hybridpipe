import pandas as pd
# ##  # E# D# A#  # a# n# d#  # P# r# e# d# i# c# t# i# o# n

# C# h# u# r# n#  # i# s#  # a#  # o# n# e#  # o# f#  # t# h# e#  # b# i# g# g# e# s# t#  # p# r# o# b# l# e# m#  # i# n#  #  # t# h# e#  # t# e# l# e# c# o# m#  # i# n# d# u# s# t# r# y# .#  # R# e# s# e# a# r# c# h#  # h# a# s#  # s# h# o# w# n#  # t# h# a# t#  # t# h# e#  # a# v# e# r# a# g# e#  # m# o# n# t# h# l# y#  # c# h# u# r# n#  # r# a# t# e#  # a# m# o# n# g#  # t# h# e#  # t# o# p#  # 4#  # w# i# r# e# l# e# s# s#  # c# a# r# r# i# e# r# s#  # i# n#  # t# h# e#  # U# S#  # i# s#  # 1# .# 9# %#  # -#  # 2# %# .#  

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns # For creating plots
import matplotlib.ticker as mtick # For specifying the axes tick format 
import matplotlib.pyplot as plt

sns.set(style = 'white')

# Input data files are available in the "../input/" directory.

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# L# e# t#  # u# s#  # r# e# a# d#  # t# h# e#  # d# a# t# a#  # f# i# l# e#  # i# n#  # t# h# e#  # p# y# t# h# o# n#  # n# o# t# e# b# o# o# k# *# *

# In[None]

telecom_cust = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

telecom_cust.head()

# In[None]

telecom_cust.columns.values

# *# *# L# e# t# '# s#  # e# x# p# l# o# r# e#  # t# h# e#  # d# a# t# a#  # t# o#  # s# e# e#  # i# f#  # t# h# e# r# e#  # a# r# e#  # a# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .# *# *

# In[None]

# Checking the data types of all the columns
telecom_cust.dtypes

# In[None]

# Converting Total Charges to a numerical data type.
telecom_cust.TotalCharges = pd.to_numeric(telecom_cust.TotalCharges, errors='coerce')
telecom_cust.isnull().sum()

# A# f# t# e# r#  # l# o# o# k# i# n# g#  # a# t#  # t# h# e#  # a# b# o# v# e#  # o# u# t# p# u# t# ,#  # w# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # 1# 1#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # f# o# r#  # T# o# t# a# l#  # C# h# a# r# g# e# s# .#  # L# e# t#  # u# s#  # r# e# p# l# a# c# e#  # r# e# m# o# v# e#  # t# h# e# s# e#  # 1# 1#  # r# o# w# s#  # f# r# o# m#  # o# u# r#  # d# a# t# a#  # s# e# t

# In[None]

#Removing missing values 
telecom_cust.dropna(inplace = True)
#Remove customer IDs from the data set
df2 = telecom_cust.iloc[:,1:]
#Convertin the predictor variable in a binary numeric variable
df2['Churn'].replace(to_replace='Yes', value=1, inplace=True)
df2['Churn'].replace(to_replace='No',  value=0, inplace=True)

#Let's convert all the categorical variables into dummy variables
df_dummies = pd.get_dummies(df2)
df_dummies.head()

# In[None]

#Get Correlation of "Churn" with other variables:
plt.figure(figsize=(15,8))
df_dummies.corr()['Churn'].sort_values(ascending = False).plot(kind='bar')

# M# o# n# t# h#  # t# o#  # m# o# n# t# h#  # c# o# n# t# r# a# c# t# s# ,#  # a# b# s# e# n# c# e#  # o# f#  # o# n# l# i# n# e#  # s# e# c# u# r# i# t# y#  # a# n# d#  # t# e# c# h#  # s# u# p# p# o# r# t#  # s# e# e# m#  # t# o#  # b# e#  # p# o# s# i# t# i# v# e# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # c# h# u# r# n# .#  # W# h# i# l# e# ,#  # t# e# n# u# r# e# ,#  # t# w# o#  # y# e# a# r#  # c# o# n# t# r# a# c# t# s#  # s# e# e# m#  # t# o#  # b# e#  # n# e# g# a# t# i# v# e# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # c# h# u# r# n# .#  # 
# 
# I# n# t# e# r# e# s# t# i# n# g# l# y# ,#  # s# e# r# v# i# c# e# s#  # s# u# c# h#  # a# s#  # O# n# l# i# n# e#  # s# e# c# u# r# i# t# y# ,#  # s# t# r# e# a# m# i# n# g#  # T# V# ,#  # o# n# l# i# n# e#  # b# a# c# k# u# p# ,#  # t# e# c# h#  # s# u# p# p# o# r# t# ,#  # e# t# c# .#  # w# i# t# h# o# u# t#  # i# n# t# e# r# n# e# t#  # c# o# n# n# e# c# t# i# o# n#  # s# e# e# m#  # t# o#  # b# e#  # n# e# g# a# t# i# v# e# l# y#  # r# e# l# a# t# e# d#  # t# o#  # c# h# u# r# n# .# 
# 
# W# e#  # w# i# l# l#  # e# x# p# l# o# r# e#  # t# h# e#  # p# a# t# t# e# r# n# s#  # f# o# r#  # t# h# e#  # a# b# o# v# e#  # c# o# r# r# e# l# a# t# i# o# n# s#  # b# e# l# o# w#  # b# e# f# o# r# e#  # w# e#  # d# e# l# v# e#  # i# n# t# o#  # m# o# d# e# l# l# i# n# g#  # a# n# d#  # i# d# e# n# t# i# f# y# i# n# g#  # t# h# e#  # i# m# p# o# r# t# a# n# t#  # v# a# r# i# a# b# l# e# s# .

# ## ##  # D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n# 
# 
# L# e# t#  # u# s#  # f# i# r# s# t#  # s# t# a# r# t#  # w# i# t# h#  # e# x# p# l# o# r# i# n# g#  # o# u# r#  # d# a# t# a#  # s# e# t# ,#  # t# o#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # p# a# t# t# e# r# n# s#  # i# n#  # t# h# e#  # d# a# t# a#  # a# n# d#  # p# o# t# e# n# t# i# a# l# l# y#  # f# o# r# m#  # s# o# m# e#  # h# y# p# o# t# h# e# s# i# s# .#  # F# i# r# s# t#  # w# e#  # w# i# l# l#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # i# n# d# i# v# i# d# u# a# l#  # v# a# r# i# a# b# l# e# s#  # a# n# d#  # t# h# e# n#  # s# l# i# c# e#  # a# n# d#  # d# i# c# e#  # o# u# r#  # d# a# t# a#  # f# o# r#  # a# n# y#  # i# n# t# e# r# e# s# t# i# n# g#  # t# r# e# n# d# s# .

# *# *# A# .# )# *# *#  # *# *# *# D# e# m# o# g# r# a# p# h# i# c# s# *# *# *#  # -#  # L# e# t#  # u# s#  # f# i# r# s# t#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # g# e# n# d# e# r# ,#  # a# g# e#  # r# a# n# g# e# ,#  # p# a# t# n# e# r#  # a# n# d#  # d# e# p# e# n# d# e# n# t#  # s# t# a# t# u# s#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s

# 1# .#  # *# *# G# e# n# d# e# r#  # D# i# s# t# r# i# b# u# t# i# o# n# *# *#  # -#  # A# b# o# u# t#  # h# a# l# f#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # i# n#  # o# u# r#  # d# a# t# a#  # s# e# t#  # a# r# e#  # m# a# l# e#  # w# h# i# l# e#  # t# h# e#  # o# t# h# e# r#  # h# a# l# f#  # a# r# e#  # f# e# m# a# l# e

# In[None]

colors = ['#4D3425','#E4512B']
ax = (telecom_cust['gender'].value_counts()*100.0 /len(telecom_cust)).plot(kind='bar',
                                                                           stacked = True,
                                                                          rot = 0,
                                                                          color = colors)
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.set_ylabel('% Customers')
ax.set_xlabel('Gender')
ax.set_ylabel('% Customers')
ax.set_title('Gender Distribution')

# create a list to collect the plt.patches data
totals = []

# find the values and append to list
for i in ax.patches:
    totals.append(i.get_width())

# set individual bar lables using above list
total = sum(totals)

for i in ax.patches:
    # get_width pulls left or right; get_y pushes up or down
    ax.text(i.get_x()+.15, i.get_height()-3.5, \
            str(round((i.get_height()/total), 1))+'%',
            fontsize=12,
            color='white',
           weight = 'bold')

# 2# .#  # *# *# %#  # S# e# n# i# o# r#  # C# i# t# i# z# e# n# s# *# *#  # -#  # T# h# e# r# e#  # a# r# e#  # o# n# l# y#  # 1# 6# %#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # a# r# e#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s# .#  # T# h# u# s#  # m# o# s# t#  # o# f#  # o# u# r#  # c# u# s# t# o# m# e# r# s#  # i# n#  # t# h# e#  # d# a# t# a#  # a# r# e#  # y# o# u# n# g# e# r#  # p# e# o# p# l# e# .# 


# In[None]

ax = (telecom_cust['SeniorCitizen'].value_counts()*100.0 /len(telecom_cust))\
.plot.pie(autopct='%.1f%%', labels = ['No', 'Yes'],figsize =(5,5), fontsize = 12 )                                                                           
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.set_ylabel('Senior Citizens',fontsize = 12)
ax.set_title('% of Senior Citizens', fontsize = 12)

# 3# .#  # *# *# P# a# r# t# n# e# r#  # a# n# d#  # d# e# p# e# n# d# e# n# t#  # s# t# a# t# u# s# *# *#  #  # -#  # A# b# o# u# t#  # 5# 0# %#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # a#  # p# a# r# t# n# e# r# ,#  # w# h# i# l# e#  # o# n# l# y#  # 3# 0# %#  # o# f#  # t# h# e#  # t# o# t# a# l#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # d# e# p# e# n# d# e# n# t# s# .#  

# In[None]

df2 = pd.melt(telecom_cust, id_vars=['customerID'], value_vars=['Dependents','Partner'])
df3 = df2.groupby(['variable','value']).count().unstack()
df3 = df3*100/len(telecom_cust)
colors = ['#4D3425','#E4512B']
ax = df3.loc[:,'customerID'].plot.bar(stacked=True, color=colors,
                                      figsize=(8,6),rot = 0,
                                     width = 0.2)

ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.set_ylabel('% Customers',size = 14)
ax.set_xlabel('')
ax.set_title('% Customers with dependents and partners',size = 14)
ax.legend(loc = 'center',prop={'size':14})

for p in ax.patches:
    width, height = p.get_width(), p.get_height()
    x, y = p.get_xy() 
    ax.annotate('{:.0f}%'.format(height), (p.get_x()+.25*width, p.get_y()+.4*height),
                color = 'white',
               weight = 'bold',
               size = 14)

# *# *# W# h# a# t#  # w# o# u# l# d#  # b# e#  # i# n# t# e# r# e# s# t# i# n# g#  # i# s#  # t# o#  # l# o# o# k#  # a# t#  # t# h# e#  # %#  # o# f#  # c# u# s# t# o# m# e# r# s# ,#  # w# h# o#  # h# a# v# e#  # p# a# r# t# n# e# r# s# ,#  # a# l# s# o#  # h# a# v# e#  # d# e# p# e# n# d# e# n# t# s# .#  # W# e#  # w# i# l# l#  # e# x# p# l# o# r# e#  # t# h# i# s#  # n# e# x# t# .#  # *# *

# I# n# t# e# r# e# s# t# i# n# g# l# y# ,#  #  # a# m# o# n# g#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # a#  # p# a# r# t# n# e# r# ,#  # o# n# l# y#  # a# b# o# u# t#  # h# a# l# f#  # o# f#  # t# h# e# m#  # a# l# s# o#  # h# a# v# e#  # a#  # d# e# p# e# n# d# e# n# t# ,#  # w# h# i# l# e#  # o# t# h# e# r#  # h# a# l# f#  # d# o#  # n# o# t#  # h# a# v# e#  # a# n# y#  # i# n# d# e# p# e# n# d# e# n# t# s# .#  # 
# A# d# d# i# t# i# o# n# a# l# l# y# ,#  # a# s#  # e# x# p# e# c# t# e# d# ,#  # a# m# o# n# g#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # d# o#  # n# o# t#  # h# a# v# e#  # a# n# y#  # p# a# r# t# n# e# r# ,#  # a#  # m# a# j# o# r# i# t# y#  # (# 8# 0# %# )#  # o# f#  # t# h# e# m#  # d# o#  # n# o# t#  # h# a# v# e#  # a# n# y#  # d# e# p# e# n# d# e# n# t# s#  # .

# In[None]

colors = ['#4D3425','#E4512B']
partner_dependents = telecom_cust.groupby(['Partner','Dependents']).size().unstack()

ax = (partner_dependents.T*100.0 / partner_dependents.T.sum()).T.plot(kind='bar',
                                                                width = 0.2,
                                                                stacked = True,
                                                                rot = 0, 
                                                                figsize = (8,6),
                                                                color = colors)
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.legend(loc='center',prop={'size':14},title = 'Dependents',fontsize =14)
ax.set_ylabel('% Customers',size = 14)
ax.set_title('% Customers with/without dependents based on whether they have a partner',size = 14)
ax.xaxis.label.set_size(14)

# Code to add the data labels on the stacked bar chart
for p in ax.patches:
    width, height = p.get_width(), p.get_height()
    x, y = p.get_xy() 
    ax.annotate('{:.0f}%'.format(height), (p.get_x()+.25*width, p.get_y()+.4*height),
                color = 'white',
               weight = 'bold',
               size = 14)

# I#  # a# l# s# o#  # l# o# o# k# e# d#  # a# t#  # a# n# y#  # d# i# f# f# e# r# e# n# c# e# s#  # b# e# t# w# e# e# n#  # t# h# e#  # %#  # o# f#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h# /# w# i# t# h# o# u# t#  # d# e# p# e# n# d# e# n# t# s#  # a# n# d#  # p# a# r# t# n# e# r# s#  # b# y#  # g# e# n# d# e# r# .#  # T# h# e# r# e#  # i# s#  # n# o#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # t# h# e# i# r#  # d# i# s# t# r# i# b# u# t# i# o# n#  # b# y#  # g# e# n# d# e# r# .#  # A# d# d# i# t# i# o# n# a# l# l# y# ,#  # t# h# e# r# e#  # i# s#  # n# o#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n#  # s# t# a# t# u# s#  # b# y#  # g# e# n# d# e# r# .

# ## ## ##  # B# .# )#  # *# *# C# u# s# t# o# m# e# r#  # A# c# c# o# u# n# t#  # I# n# f# o# r# m# a# t# i# o# n# *# *# :#  #  # L# e# t#  # u#  # n# o# w#  # l# o# o# k#  # a# t#  # t# h# e#  # t# e# n# u# r# e# ,#  # c# o# n# t# r# a# c# t

# *# *# 1# .#  # T# e# n# u# r# e# :# *# *#  #  # A# f# t# e# r#  # l# o# o# k# i# n# g#  # a# t#  # t# h# e#  # b# e# l# o# w#  # h# i# s# t# o# g# r# a# m#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # a#  # l# o# t#  # o# f#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # b# e# e# n#  # w# i# t# h#  # t# h# e#  # t# e# l# e# c# o# m#  # c# o# m# p# a# n# y#  # f# o# r#  # j# u# s# t#  # a#  # m# o# n# t# h# ,#  # w# h# i# l# e#  # q# u# i# t# e#  # a#  # m# a# n# y#  # a# r# e#  # t# h# e# r# e#  # f# o# r#  # a# b# o# u# t#  # 7# 2#  # m# o# n# t# h# s# .#  # T# h# i# s#  # c# o# u# l# d#  # b# e#  # p# o# t# e# n# t# i# a# l# l# y#  # b# e# c# a# u# s# e#  # d# i# f# f# e# r# e# n# t#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # d# i# f# f# e# r# e# n# t#  # c# o# n# t# r# a# c# t# s# .#  # T# h# u# s#  # b# a# s# e# d#  # o# n#  # t# h# e#  # c# o# n# t# r# a# c# t#  # t# h# e# y#  # a# r# e#  # i# n# t# o#  # i# t#  # c# o# u# l# d#  # b# e#  # m# o# r# e# /# l# e# s# s#  # e# a# s# i# e# r#  # f# o# r#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # t# o#  # s# t# a# y# /# l# e# a# v# e#  # t# h# e#  # t# e# l# e# c# o# m#  # c# o# m# p# a# n# y# .

# In[None]

ax = sns.distplot(telecom_cust['tenure'], hist=True, kde=False, 
             bins=int(180/5), color = 'darkblue', 
             hist_kws={'edgecolor':'black'},
             kde_kws={'linewidth': 4})
ax.set_ylabel('# of Customers')
ax.set_xlabel('Tenure (months)')
ax.set_title('# of Customers by their tenure')

# *# *# 2# .#  # C# o# n# t# r# a# c# t# s# :# *# *#  # T# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h# ,#  # l# e# t# s#  # f# i# r# s# t#  # l# o# o# k#  # a# t#  # t# h# e#  # ##  # o# f#  # c# u# s# t# o# m# e# r# s#  # b# y#  # d# i# f# f# e# r# e# n# t#  # c# o# n# t# r# a# c# t# s# .#  

# In[None]

ax = telecom_cust['Contract'].value_counts().plot(kind = 'bar',rot = 0, width = 0.3)
ax.set_ylabel('# of Customers')
ax.set_title('# of Customers by Contract Type')

# A# s#  # w# e#  # c# a# n#  # s# e# e#  # f# r# o# m#  # t# h# i# s#  # g# r# a# p# h#  # m# o# s# t#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # a# r# e#  # i# n#  # t# h# e#  # m# o# n# t# h#  # t# o#  # m# o# n# t# h#  # c# o# n# t# r# a# c# t# .#  # W# h# i# l# e#  # t# h# e# r# e#  # a# r# e#  # e# q# u# a# l#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r# s#  # i# n#  # t# h# e#  # 1#  # y# e# a# r#  # a# n# d#  # 2#  # y# e# a# r#  # c# o# n# t# r# a# c# t# s# .# 
# 


# B# e# l# o# w#  # w# e#  # w# i# l# l#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # t# e# n# u# r# e#  # o# f#  # c# u# s# t# o# m# e# r# s#  # b# a# s# e# d#  # o# n#  # t# h# e# i# r#  # c# o# n# t# r# a# c# t#  # t# y# p# e# .

# In[None]

fig, (ax1,ax2,ax3) = plt.subplots(nrows=1, ncols=3, sharey = True, figsize = (20,6))

ax = sns.distplot(telecom_cust[telecom_cust['Contract']=='Month-to-month']['tenure'],
                   hist=True, kde=False,
                   bins=int(180/5), color = 'turquoise',
                   hist_kws={'edgecolor':'black'},
                   kde_kws={'linewidth': 4},
                 ax=ax1)
ax.set_ylabel('# of Customers')
ax.set_xlabel('Tenure (months)')
ax.set_title('Month to Month Contract')

ax = sns.distplot(telecom_cust[telecom_cust['Contract']=='One year']['tenure'],
                   hist=True, kde=False,
                   bins=int(180/5), color = 'steelblue',
                   hist_kws={'edgecolor':'black'},
                   kde_kws={'linewidth': 4},
                 ax=ax2)
ax.set_xlabel('Tenure (months)',size = 14)
ax.set_title('One Year Contract',size = 14)

ax = sns.distplot(telecom_cust[telecom_cust['Contract']=='Two year']['tenure'],
                   hist=True, kde=False,
                   bins=int(180/5), color = 'darkblue',
                   hist_kws={'edgecolor':'black'},
                   kde_kws={'linewidth': 4},
                 ax=ax3)

ax.set_xlabel('Tenure (months)')
ax.set_title('Two Year Contract')

# I# n# t# e# r# e# s# t# i# n# g# l# y#  # m# o# s# t#  # o# f#  # t# h# e#  # m# o# n# t# h# l# y#  # c# o# n# t# r# a# c# t# s#  # l# a# s# t#  # f# o# r#  # 1# -# 2#  # m# o# n# t# h# s# ,#  # w# h# i# l# e#  # t# h# e#  # 2#  # y# e# a# r#  # c# o# n# t# r# a# c# t# s#  # t# e# n# d#  # t# o#  # l# a# s# t#  # f# o# r#  # a# b# o# u# t#  # 7# 0#  # m# o# n# t# h# s# .#  # T# h# i# s#  # s# h# o# w# s#  # t# h# a# t#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # t# a# k# i# n# g#  # a#  # l# o# n# g# e# r#  # c# o# n# t# r# a# c# t#  # a# r# e#  # m# o# r# e#  # l# o# y# a# l#  # t# o#  # t# h# e#  # c# o# m# p# a# n# y#  # a# n# d#  # t# e# n# d#  # t# o#  # s# t# a# y#  # w# i# t# h#  # i# t#  # f# o# r#  # a#  # l# o# n# g# e# r#  # p# e# r# i# o# d#  # o# f#  # t# i# m# e# .#  # 
# 
# T# h# i# s#  # i# s#  # a# l# s# o#  # w# h# a# t#  # w# e#  # s# a# w#  # i# n#  # t# h# e#  # e# a# r# l# i# e# r#  # c# h# a# r# t#  # o# n#  # c# o# r# r# e# l# a# t# i# o# n#  # w# i# t# h#  # t# h# e#  # c# h# u# r# n#  # r# a# t# e# .#  

# ## ## ##  #  # C# .#  # L# e# t#  # u# s#  # n# o# w#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # v# a# r# i# o# u# s#  # s# e# r# v# i# c# e# s#  # u# s# e# d#  # b# y#  # c# u# s# t# o# m# e# r# s

# In[None]


telecom_cust.columns.values

# In[None]

services = ['PhoneService','MultipleLines','InternetService','OnlineSecurity',
           'OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies']

fig, axes = plt.subplots(nrows = 3,ncols = 3,figsize = (15,12))
for i, item in enumerate(services):
    if i < 3:
        ax = telecom_cust[item].value_counts().plot(kind = 'bar',ax=axes[i,0],rot = 0)
        
    elif i >=3 and i < 6:
        ax = telecom_cust[item].value_counts().plot(kind = 'bar',ax=axes[i-3,1],rot = 0)
        
    elif i < 9:
        ax = telecom_cust[item].value_counts().plot(kind = 'bar',ax=axes[i-6,2],rot = 0)
    ax.set_title(item)

# ## ## ##  # D# .# )#  # N# o# w#  # l# e# t# '# s#  # t# a# k# e#  # a#  # q# u# i# c# k#  # l# o# o# k#  # a# t#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # m# o# n# t# h# l# y#  # a# n# d#  # t# o# t# a# l#  # c# h# a# r# g# e# s

# W# e#  # w# i# l# l#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e#  # t# o# t# a# l#  # c# h# a# r# g# e# s#  # i# n# c# r# e# a# s# e# s#  # a# s#  # t# h# e#  # m# o# n# t# h# l# y#  # b# i# l# l#  # f# o# r#  # a#  # c# u# s# t# o# m# e# r#  # i# n# c# r# e# a# s# e# s# .

# In[None]

telecom_cust[['MonthlyCharges', 'TotalCharges']].plot.scatter(x = 'MonthlyCharges',
                                                              y='TotalCharges')

# ## ## ##  # E# .# )#  # F# i# n# a# l# l# y# ,#  # l# e# t# '# s#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # o# u# t#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e#  # (# C# h# u# r# n# )#  # a# n# d#  # u# n# d# e# r# s# t# a# n# d#  # i# t# s#  # i# n# t# e# r# a# c# t# i# o# n#  # w# i# t# h#  # o# t# h# e# r#  # i# m# p# o# r# t# a# n# t#  # v# a# r# i# a# b# l# e# s#  # a# s#  # w# a# s#  # f# o# u# n# d#  # o# u# t#  # i# n#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # p# l# o# t# .#  

# 1# .#  # L# e# t# s#  # f# i# r# s# t#  # l# o# o# k#  # a# t#  # t# h# e#  # c# h# u# r# n#  # r# a# t# e#  # i# n#  # o# u# r#  # d# a# t# a

# In[None]

colors = ['#4D3425','#E4512B']
ax = (telecom_cust['Churn'].value_counts()*100.0 /len(telecom_cust)).plot(kind='bar',
                                                                           stacked = True,
                                                                          rot = 0,
                                                                          color = colors,
                                                                         figsize = (8,6))
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.set_ylabel('% Customers',size = 14)
ax.set_xlabel('Churn',size = 14)
ax.set_title('Churn Rate', size = 14)

# create a list to collect the plt.patches data
totals = []

# find the values and append to list
for i in ax.patches:
    totals.append(i.get_width())

# set individual bar lables using above list
total = sum(totals)

for i in ax.patches:
    # get_width pulls left or right; get_y pushes up or down
    ax.text(i.get_x()+.15, i.get_height()-4.0, \
            str(round((i.get_height()/total), 1))+'%',
            fontsize=12,
            color='white',
           weight = 'bold',
           size = 14)

# I# n#  # o# u# r#  # d# a# t# a# ,#  # 7# 4# %#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # d# o#  # n# o# t#  # c# h# u# r# n# .#  # C# l# e# a# r# l# y#  # t# h# e#  # d# a# t# a#  # i# s#  # s# k# e# w# e# d#  # a# s#  # w# e#  # w# o# u# l# d#  # e# x# p# e# c# t#  # a#  # l# a# r# g# e#  # m# a# j# o# r# i# t# y#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # t# o#  # n# o# t#  # c# h# u# r# n# .#  # T# h# i# s#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # k# e# e# p#  # i# n#  # m# i# n# d#  # f# o# r#  # o# u# r#  # m# o# d# e# l# l# i# n# g#  # a# s#  # s# k# e# w# e# n# e# s# s#  # c# o# u# l# d#  # l# e# a# d#  # t# o#  # a#  # l# o# t#  # o# f#  # f# a# l# s# e#  # n# e# g# a# t# i# v# e# s# .#  # W# e#  # w# i# l# l#  # s# e# e#  # i# n#  # t# h# e#  # m# o# d# e# l# l# i# n# g#  # s# e# c# t# i# o# n#  # o# n#  # h# o# w#  # t# o#  # a# v# o# i# d#  # s# k# e# w# n# e# s# s#  # i# n#  # t# h# e#  # d# a# t# a# .

# 2# .#  # L# e# t# s#  # n# o# w#  # e# x# p# l# o# r# e#  # t# h# e#  # c# h# u# r# n#  # r# a# t# e#  # b# y#  # t# e# n# u# r# e# ,#  # s# e# n# i# o# r# i# t# y# ,#  # c# o# n# t# r# a# c# t#  # t# y# p# e# ,#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # a# n# d#  # t# o# t# a# l#  # c# h# a# r# g# e# s#  # t# o#  # s# e# e#  # h# o# w#  # i# t#  # v# a# r# i# e# s#  # b# y#  # t# h# e# s# e#  # v# a# r# i# a# b# l# e# s# .

# *# *# i# .# )#  # C# h# u# r# n#  # v# s#  # T# e# n# u# r# e# *# *# :#  # A# s#  # w# e#  # c# a# n#  # s# e# e#  # f# o# r# m#  # t# h# e#  # b# e# l# o# w#  # p# l# o# t# ,#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # d# o#  # n# o# t#  # c# h# u# r# n# ,#  # t# h# e# y#  # t# e# n# d#  # t# o#  # s# t# a# y#  # f# o# r#  # a#  # l# o# n# g# e# r#  # t# e# n# u# r# e#  # w# i# t# h#  # t# h# e#  # t# e# l# e# c# o# m#  # c# o# m# p# a# n# y# .#  

# In[None]

sns.boxplot(x = telecom_cust.Churn, y = telecom_cust.tenure)

# *# *# i# i# .# )#  # C# h# u# r# n#  # b# y#  # C# o# n# t# r# a# c# t#  # T# y# p# e# *# *# :#  # S# i# m# i# l# a# r#  # t# o#  # w# h# a# t#  # w# e#  # s# a# w#  # i# n#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # p# l# o# t# ,#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # a#  # m# o# n# t# h#  # t# o#  # m# o# n# t# h#  # c# o# n# t# r# a# c# t#  # h# a# v# e#  # a#  # v# e# r# y#  # h# i# g# h#  # c# h# u# r# n#  # r# a# t# e# .

# In[None]

colors = ['#4D3425','#E4512B']
contract_churn = telecom_cust.groupby(['Contract','Churn']).size().unstack()

ax = (contract_churn.T*100.0 / contract_churn.T.sum()).T.plot(kind='bar',
                                                                width = 0.3,
                                                                stacked = True,
                                                                rot = 0, 
                                                                figsize = (10,6),
                                                                color = colors)
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.legend(loc='best',prop={'size':14},title = 'Churn')
ax.set_ylabel('% Customers',size = 14)
ax.set_title('Churn by Contract Type',size = 14)

# Code to add the data labels on the stacked bar chart
for p in ax.patches:
    width, height = p.get_width(), p.get_height()
    x, y = p.get_xy() 
    ax.annotate('{:.0f}%'.format(height), (p.get_x()+.25*width, p.get_y()+.4*height),
                color = 'white',
               weight = 'bold',
               size = 14)

# *# *# i# i# i# .# )#  # C# h# u# r# n#  # b# y#  # S# e# n# i# o# r# i# t# y# *# *# :#  # S# e# n# i# o# r#  # C# i# t# i# z# e# n# s#  # h# a# v# e#  # a# l# m# o# s# t#  # d# o# u# b# l# e#  # t# h# e#  # c# h# u# r# n#  # r# a# t# e#  # t# h# a# n#  # y# o# u# n# g# e# r#  # p# o# p# u# l# a# t# i# o# n# .

# In[None]

colors = ['#4D3425','#E4512B']
seniority_churn = telecom_cust.groupby(['SeniorCitizen','Churn']).size().unstack()

ax = (seniority_churn.T*100.0 / seniority_churn.T.sum()).T.plot(kind='bar',
                                                                width = 0.2,
                                                                stacked = True,
                                                                rot = 0, 
                                                                figsize = (8,6),
                                                                color = colors)
ax.yaxis.set_major_formatter(mtick.PercentFormatter())
ax.legend(loc='center',prop={'size':14},title = 'Churn')
ax.set_ylabel('% Customers')
ax.set_title('Churn by Seniority Level',size = 14)

# Code to add the data labels on the stacked bar chart
for p in ax.patches:
    width, height = p.get_width(), p.get_height()
    x, y = p.get_xy() 
    ax.annotate('{:.0f}%'.format(height), (p.get_x()+.25*width, p.get_y()+.4*height),
                color = 'white',
               weight = 'bold',size =14)

# *# *# i# v# .# )#  # C# h# u# r# n#  # b# y#  # M# o# n# t# h# l# y#  # C# h# a# r# g# e# s# *# *# :#  # H# i# g# h# e# r#  # %#  # o# f#  # c# u# s# t# o# m# e# r# s#  # c# h# u# r# n#  # w# h# e# n#  # t# h# e#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # a# r# e#  # h# i# g# h# .

# In[None]

ax = sns.kdeplot(telecom_cust.MonthlyCharges[(telecom_cust["Churn"] == 'No') ],
                color="Red", shade = True)
ax = sns.kdeplot(telecom_cust.MonthlyCharges[(telecom_cust["Churn"] == 'Yes') ],
                ax =ax, color="Blue", shade= True)
ax.legend(["Not Churn","Churn"],loc='upper right')
ax.set_ylabel('Density')
ax.set_xlabel('Monthly Charges')
ax.set_title('Distribution of monthly charges by churn')

# *# *# v# .# )#  # C# h# u# r# n#  # b# y#  # T# o# t# a# l#  # C# h# a# r# g# e# s# *# *# :#  # I# t#  # s# e# e# m# s#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # h# i# g# e# r#  # c# h# u# r# n#  # w# h# e# n#  # t# h# e#  # t# o# t# a# l#  # c# h# a# r# g# e# s#  # a# r# e#  # l# o# w# e# r# .

# In[None]

ax = sns.kdeplot(telecom_cust.TotalCharges[(telecom_cust["Churn"] == 'No') ],
                color="Red", shade = True)
ax = sns.kdeplot(telecom_cust.TotalCharges[(telecom_cust["Churn"] == 'Yes') ],
                ax =ax, color="Blue", shade= True)
ax.legend(["Not Churn","Churn"],loc='upper right')
ax.set_ylabel('Density')
ax.set_xlabel('Total Charges')
ax.set_title('Distribution of total charges by churn')

# ## ##  # A# f# t# e# r#  # g# o# i# n# g#  # t# h# r# o# u# g# h#  # t# h# e#  # a# b# o# v# e#  # E# D# A#  # w# e#  # w# i# l# l#  # d# e# v# e# l# o# p#  # s# o# m# e#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# s#  # a# n# d#  # c# o# m# p# a# r# e#  # t# h# e# m# .# 
# 
# W# e#  # w# i# l# l#  # d# e# v# e# l# o# p#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ,#  # R# a# n# d# o# m#  # F# o# r# e# s# t# ,#  # S# V# M# ,#  # A# D# A#  # B# o# o# s# t#  # a# n# d#  # X# G#  # B# o# o# s# t

# *# *# 1# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# *# *

# In[None]

# We will use the data frame where we had created dummy variables
y = df_dummies['Churn'].values
X = df_dummies.drop(columns = ['Churn'])

# Scaling all the variables to a range of 0 to 1
from sklearn.preprocessing import MinMaxScaler
features = X.columns.values
scaler = MinMaxScaler(feature_range = (0,1))
scaler.fit(X)
X = pd.DataFrame(scaler.transform(X))
X.columns = features

# I# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # s# c# a# l# e#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # i# n#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # s# o#  # t# h# a# t#  # a# l# l#  # o# f#  # t# h# e# m#  # a# r# e#  # w# i# t# h# i# n#  # a#  # r# a# n# g# e#  # o# f#  # 0#  # t# o#  # 1# .#  # T# h# i# s#  # h# e# l# p# e# d#  # m# e#  # i# m# p# r# o# v# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # f# r# o# m#  # 7# 9# .# 7# %#  # t# o#  # 8# 0# .# 7# %# .#  # F# u# r# t# h# e# r# ,#  # y# o# u#  # w# i# l# l#  # n# o# t# i# c# e#  # b# e# l# o# w#  # t# h# a# t#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # v# a# r# i# a# b# l# e# s#  # i# s#  # a# l# s# o#  # a# l# i# g# n# e# d#  # w# i# t# h#  # w# h# a# t#  # w# e#  # a# r# e#  # s# e# e# i# n# g#  # i# n#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # a# l# g# o# r# i# t# h# m#  # a# n# d#  # t# h# e#  # E# D# A#  # w# e#  # c# o# n# d# u# c# t# e# d#  # a# b# o# v# e# .

# In[None]

# Create Train & Test Data
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1517276.npy", { "accuracy_score": score })

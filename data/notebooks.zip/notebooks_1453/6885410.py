import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# plotly library

from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

data=pd.read_csv("../input/xAPI-Edu-Data/xAPI-Edu-Data.csv")

# In[None]


from sklearn.model_selection import train_test_split
# create new data containing only numerical values
data_new=data.loc[:,["gender","raisedhands","VisITedResources","AnnouncementsView","Discussion"]]
# write 1 for male and 0 for female
data_new.gender=[1 if i=="M" else 0 for i in data_new.gender]
#y: binary output 
y=data_new.gender.values
#x_data: rest of the data (i.e. features of data except gender)
x_data=data_new.drop("gender",axis=1)
# normalize the values in x_data
x=(x_data-np.min(x_data))/(np.max(x_data)-np.min(x_data))
#* create x_train, y_train, x_test and  y_test arrays with train_test_split method
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6885410.npy", { "accuracy_score": score })

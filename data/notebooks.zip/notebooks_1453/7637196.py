import pandas as pd
# >#  # ##  # P# r# e# d# i# c# t# i# n# g#  # P# u# l# s# a# r#  # S# t# a# r# s# 
# 
# ## ## ##  # K# a# g# g# l# e# 
# 
# 
# ## ## ## ##  # H# T# R# U# 2#  # i# s#  # a#  # d# a# t# a#  # s# e# t#  # w# h# i# c# h#  # d# e# s# c# r# i# b# e# s#  # a#  # s# a# m# p# l# e#  # o# f#  # p# u# l# s# a# r#  # c# a# n# d# i# d# a# t# e# s#  # c# o# l# l# e# c# t# e# d#  # d# u# r# i# n# g#  # t# h# e#  # H# i# g# h#  # T# i# m# e#  # R# e# s# o# l# u# t# i# o# n#  # U# n# i# v# e# r# s# e#  # S# u# r# v# e# y#  # .# 
# 
# ## ## ## ##  # P# u# l# s# a# r# s#  # a# r# e#  # a#  # r# a# r# e#  # t# y# p# e#  # o# f#  # N# e# u# t# r# o# n#  # s# t# a# r#  # t# h# a# t#  # p# r# o# d# u# c# e#  # r# a# d# i# o#  # e# m# i# s# s# i# o# n#  # d# e# t# e# c# t# a# b# l# e#  # h# e# r# e#  # o# n#  # E# a# r# t# h# .#  # T# h# e# y#  # a# r# e#  # o# f#  # c# o# n# s# i# d# e# r# a# b# l# e#  # s# c# i# e# n# t# i# f# i# c#  # i# n# t# e# r# e# s# t#  # a# s#  # p# r# o# b# e# s#  # o# f#  # s# p# a# c# e# -# t# i# m# e# ,#  # t# h# e#  # i# n# t# e# r# -# s# t# e# l# l# a# r#  # m# e# d# i# u# m# ,#  # a# n# d#  # s# t# a# t# e# s#  # o# f#  # m# a# t# t# e# r#  # .# 
# 
# ## ## ## ##  # A# s#  # p# u# l# s# a# r# s#  # r# o# t# a# t# e# ,#  # t# h# e# i# r#  # e# m# i# s# s# i# o# n#  # b# e# a# m#  # s# w# e# e# p# s#  # a# c# r# o# s# s#  # t# h# e#  # s# k# y# ,#  # a# n# d#  # w# h# e# n#  # t# h# i# s#  # c# r# o# s# s# e# s#  # o# u# r#  # l# i# n# e#  # o# f#  # s# i# g# h# t# ,#  # p# r# o# d# u# c# e# s#  # a#  # d# e# t# e# c# t# a# b# l# e#  # p# a# t# t# e# r# n#  # o# f#  # b# r# o# a# d# b# a# n# d#  # r# a# d# i# o#  # e# m# i# s# s# i# o# n# .#  # A# s#  # p# u# l# s# a# r# s#  # r# o# t# a# t# e#  # r# a# p# i# d# l# y# ,#  # t# h# i# s#  # p# a# t# t# e# r# n#  # r# e# p# e# a# t# s#  # p# e# r# i# o# d# i# c# a# l# l# y# .#  # T# h# u# s#  # p# u# l# s# a# r#  # s# e# a# r# c# h#  # i# n# v# o# l# v# e# s#  # l# o# o# k# i# n# g#  # f# o# r#  # p# e# r# i# o# d# i# c#  # r# a# d# i# o#  # s# i# g# n# a# l# s#  # w# i# t# h#  # l# a# r# g# e#  # r# a# d# i# o#  # t# e# l# e# s# c# o# p# e# s# .# 
# 
# ## ## ## ##  # E# a# c# h#  # p# u# l# s# a# r#  # p# r# o# d# u# c# e# s#  # a#  # s# l# i# g# h# t# l# y#  # d# i# f# f# e# r# e# n# t#  # e# m# i# s# s# i# o# n#  # p# a# t# t# e# r# n# ,#  # w# h# i# c# h#  # v# a# r# i# e# s#  # s# l# i# g# h# t# l# y#  # w# i# t# h#  # e# a# c# h#  # r# o# t# a# t# i# o# n#  # .#  # T# h# u# s#  # a#  # p# o# t# e# n# t# i# a# l#  # s# i# g# n# a# l#  # d# e# t# e# c# t# i# o# n#  # k# n# o# w# n#  # a# s#  # a#  # '# c# a# n# d# i# d# a# t# e# '# ,#  # i# s#  # a# v# e# r# a# g# e# d#  # o# v# e# r#  # m# a# n# y#  # r# o# t# a# t# i# o# n# s#  # o# f#  # t# h# e#  # p# u# l# s# a# r# ,#  # a# s#  # d# e# t# e# r# m# i# n# e# d#  # b# y#  # t# h# e#  # l# e# n# g# t# h#  # o# f#  # a# n#  # o# b# s# e# r# v# a# t# i# o# n# .#  # I# n#  # t# h# e#  # a# b# s# e# n# c# e#  # o# f#  # a# d# d# i# t# i# o# n# a# l#  # i# n# f# o# ,#  # e# a# c# h#  # c# a# n# d# i# d# a# t# e#  # c# o# u# l# d#  # p# o# t# e# n# t# i# a# l# l# y#  # d# e# s# c# r# i# b# e#  # a#  # r# e# a# l#  # p# u# l# s# a# r# .#  # H# o# w# e# v# e# r#  # i# n#  # p# r# a# c# t# i# c# e#  # a# l# m# o# s# t#  # a# l# l#  # d# e# t# e# c# t# i# o# n# s#  # a# r# e#  # c# a# u# s# e# d#  # b# y#  # r# a# d# i# o#  # f# r# e# q# u# e# n# c# y#  # i# n# t# e# r# f# e# r# e# n# c# e#  # (# R# F# I# )#  # a# n# d#  # n# o# i# s# e# ,#  # m# a# k# i# n# g#  # l# e# g# i# t# i# m# a# t# e#  # s# i# g# n# a# l# s#  # h# a# r# d#  # t# o#  # f# i# n# d# .# 
# 
# ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# 
# ## ## ## ##  # F# i# r# s# t# l# y# ,#  # w# e#  # w# i# l# l#  # t# a# k# e#  # a#  # l# o# o# k#  # i# n#  # t# h# e#  # b# e# h# a# v# i# o# u# r#  # o# f#  # o# u# r#  # d# a# t# a# !#  # W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e#  # a#  # c# o# u# p# l# e#  # o# f#  # m# a# n# i# f# o# l# d#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s#  # i# n#  # o# r# d# e# r#  # t# o#  # v# i# s# u# a# l# i# s# e#  # t# h# e#  # h# i# g# h#  # d# i# m# e# n# s# i# o# n# a# l#  # d# a# t# a#  # i# n#  # a#  # 2# D#  # p# l# o# t# !# 
# 
# ## ## ## ##  # L# a# s# t# l# y# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # s# o# m# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# p# p# r# o# a# c# h# e# s#  # t# o#  # c# o# r# r# e# c# t# l# y#  # i# d# e# n# t# i# f# y#  # P# u# l# s# a# r#  # S# t# a# r# s# .#  # W# e#  # w# a# n# t#  # t# o#  # f# i# n# d#  # t# h# e#  # b# e# s# t#  # a# l# g# o# r# i# t# h# m# ,#  # a# c# c# u# r# a# c# y# -# w# i# s# e# ,#  # h# o# w# e# v# e# r# ,#  # w# e#  # n# e# e# d#  # t# o#  # f# i# n# d#  # w# h# i# c# h#  # o# n# e#  # p# r# o# v# i# d# e# s#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # t# o#  # i# d# e# n# t# i# f# y#  # P# u# l# s# a# r#  # S# t# a# r# s# .

# In[None]

import pandas as pd

# In[None]

data = pd.read_csv('../input/predicting-a-pulsar-star/pulsar_stars.csv')

data.head()

# ## ## ## ##  # H# o# w#  # m# a# n# y#  # s# a# m# p# l# e# s#  # d# o#  # w# e#  # h# a# v# e#  # f# o# r#  # w# h# i# c# h#  # c# l# a# s# s# ?

# In[None]

target = data[['target_class']]

data.drop('target_class', axis=1, inplace=True)

target['target_class'].value_counts()

# ## ## ## ##  # S# o# m# e#  # s# t# a# t# i# s# t# i# c# a# l#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # o# u# r#  # d# a# t# a# :

# In[None]

data.describe()

# ## ## ## ##  # T# a# k# i# n# g#  # a#  # l# o# o# k#  # o# f#  # h# o# w#  # o# u# r#  # f# e# a# t# u# r# e# s#  # a# r# e#  # c# o# r# r# e# l# a# t# e# d# :

# In[None]

data.corr()

# ## ## ## ##  # W# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # a# r# e#  # "# g# r# o# u# p# s# "#  # o# f#  # f# e# a# t# u# r# e# s#  # t# h# a# t#  # a# r# e#  # h# i# g# h# l# y#  # c# o# r# r# e# l# a# t# e# d# .#  # T# h# a# t#  # i# s#  # g# o# o# d#  # n# e# w# s#  # f# o# r#  # l# i# n# e# a# r#  # a# p# p# r# o# a# c# h# e# s# !

# ## ##  # H# i# g# h#  # D# i# m# e# n# s# i# o# n# a# l#  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n#  # u# s# i# n# g#  # M# a# n# i# f# o# l# d#  # L# e# a# r# n# i# n# g#  # A# l# g# o# r# i# t# h# m# s

# ## ## ## ##  # I#  # h# i# g# h# l# y#  # r# e# c# o# m# m# e# n# d#  # t# o#  # v# i# s# u# a# l# i# s# e#  # d# a# t# a#  # i# n#  # t# h# e#  # o# r# i# g# i# n# a# l#  # s# p# a# c# e# ,#  # h# o# w# e# v# e# r# ,#  # o# u# r#  # d# a# t# a#  # h# a# s#  # 8#  # f# e# a# t# u# r# e# s# ,#  # t# h# e# r# e# f# o# r# e#  # w# e#  # c# a# n# n# o# t#  # p# l# o# t#  # i# t# .#  # B# u# t# ,#  # i# n#  # o# r# d# e# r#  # t# o#  # d# o#  # s# o# ,#  # w# e#  # c# a# n#  # u# s# e#  # m# a# n# i# f# o# l# d#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s#  # t# o#  # a# n# a# l# y# s# e#  # t# h# e#  # s# t# r# u# c# t# u# r# e#  # o# f#  # o# u# r#  # d# a# t# a#  # i# n#  # t# h# e#  # o# r# i# g# i# n# a# l#  # s# p# a# c# e#  # a# n# d# ,#  # t# h# e# n# ,#  # e# m# b# e# d# d# i# n# g#  # i# t#  # i# n#  # a#  # l# o# w#  # d# i# m# e# n# s# i# a# l#  # s# p# a# c# e# ,#  # s# o#  # w# e#  # c# a# n#  # p# l# o# t#  # i# t# !# 
# 
# ## ## ## ##  # W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e#  # t# w# o#  # a# l# g# o# r# i# t# h# m# s# :#  # (# 1# )#  # t# -# S# N# E#  # a# n# d#  # (# 2# )#  # I# S# O# M# A# P# .# 
# 
# ## ## ## ##  # t# -# S# N# E#  # u# s# e# s#  # a#  # s# t# a# t# i# s# t# i# c# a# l# /# p# r# o# b# a# b# i# l# i# t# y#  # a# p# p# r# o# a# c# h#  # t# o#  # i# d# e# n# t# i# f# y#  # a# n# d#  # r# e# c# o# n# s# t# r# u# c# t#  # t# h# e#  # o# r# i# g# i# n# a# l#  # s# p# a# c# .#  # M# e# a# n# w# h# i# l# e# ,#  # I# S# O# M# A# P#  # u# s# e# s#  # c# l# a# s# s# i# c# a# l#  # m# a# n# i# f# o# l# d#  # t# h# e# o# r# y#  # t# o#  # d# o#  # s# o# .#  

# In[None]

from sklearn.manifold import TSNE
from sklearn.manifold import Isomap

import numpy as np

import matplotlib.pyplot as plt

# ## ## ##  # (# 1# )#  # t# -# S# N# E

# In[None]

# tsne = TSNE(n_components=2, init='pca', perplexity = 40)
# tsne_data = tsne.fit_transform(data)

# In[None]

# not_pulsar = []
# pulsar = []

# for i in range(len(target)):
#     if target['target_class'][i] == 0:
#         not_pulsar.append(tsne_data[i])
#     if target['target_class'][i] == 1:
#         pulsar.append(tsne_data[i])
        
# not_pulsar = np.array(not_pulsar)
# pulsar = np.array(pulsar)

# In[None]

# plt.figure(figsize=(7,7))
# plt.scatter(not_pulsar[:,0], not_pulsar[:,1], c='blue', label='Not Pulsar Stars')
# plt.scatter(pulsar[:,0], pulsar[:,1], c='red', label='Pulsar Stars')
# plt.legend()
# plt.title('Low dimensional visualization (t-SNE) - Pulsar Stars');

# ## ## ##  # (# 2# )#  # I# S# O# M# A# P

# In[None]

# isomap = Isomap(n_components=2, n_neighbors=5, path_method='D', n_jobs=-1)

# isomap_data = isomap.fit_transform(data)

# In[None]

# not_pulsar = []
# pulsar = []

# for i in range(len(target)):
#     if target['target_class'][i] == 0:
#         not_pulsar.append(isomap_data[i])
#     if target['target_class'][i] == 1:
#         pulsar.append(isomap_data[i])
        
# not_pulsar = np.array(not_pulsar)
# pulsar = np.array(pulsar)

# In[None]

# plt.figure(figsize=(7,7))
# plt.scatter(not_pulsar[:,0], not_pulsar[:,1], c='blue', label='Not Pulsar Stars')
# plt.scatter(pulsar[:,0], pulsar[:,1], c='red', label='Pulsar Stars')
# plt.legend()
# plt.title('Low dimensional visualization (ISOMAP) - Pulsar Stars');

# ## ## ## ##  # O# n# e#  # o# f#  # t# h# e#  # b# e# n# e# f# i# t# s#  # o# f#  # t# h# e# s# e#  # a# p# p# r# o# a# c# h# s#  # i# s#  # t# h# a# t#  # i# t#  # o# f# t# e# n#  # c# l# u# s# t# e# r#  # o# u# r#  # d# a# t# a# .#  # B# o# t# h#  # m# e# t# h# o# d# s#  # i# l# l# u# s# t# r# a# t# e# d#  # s# a# m# p# l# e# s#  # o# f#  # P# u# l# s# a# r#  # S# t# a# r# s#  # c# l# u# s# t# e# r# e# d# ,#  # m# e# a# n# i# n# g#  # t# h# a# t#  # f# e# a# t# u# r# e# s#  # o# f#  # o# u# r#  # d# a# t# a#  # a# r# e#  # d# i# s# t# i# n# c# t#  # a# m# o# n# g#  # s# a# m# p# l# e#  # g# r# o# u# p# s# !

# ## ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # A# p# p# r# o# a# c# h# e# s# 
# 
# ## ## ## ##  # W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e#  # t# h# r# e# e#  # a# p# p# r# o# a# c# h# e# s# :#  # (# 1# )#  # P# C# A#  # +#  # k# N# N# ,#  # (# 2# )#  # L# D# A#  # +#  # k# N# N#  # a# n# d#  # (# 3# )#  # k# N# N# .# 
# 
# ## ## ## ##  # P# C# A#  # i# s#  # a#  # c# l# a# s# s# i# c# a# l#  # u# n# s# u# p# e# r# v# i# s# e# d#  # a# l# g# o# r# i# t# h# m#  # o# f#  # d# i# m# e# n# s# i# o# n# a# l# i# t# y#  # r# e# d# u# c# t# i# o# n#  # b# a# s# e# d#  # o# n#  # v# a# r# i# a# n# c# e# -# c# o# v# a# r# i# a# n# c# e#  # b# e# t# w# e# e# n#  # s# a# m# p# l# e#  # f# e# a# t# u# r# e# s# !#  # M# e# a# n# w# h# i# l# e# ,#  # L# D# A#  # i# s#  # a#  # s# u# p# e# r# v# i# s# e# d#  # m# e# t# h# o# d#  # t# o#  # d# i# s# c# r# i# m# i# n# a# t# e#  # s# a# m# p# l# e#  # g# r# o# u# p# s#  # f# i# n# d# i# n# g#  # a#  # h# y# p# e# r# p# l# a# n# e#  # o# f#  # n# -# 1#  # d# i# m# e# n# s# i# o# n# ,#  # w# h# e# r# e#  # n#  # =#  # (# n# u# m# b# e# r#  # o# f#  # d# i# s# t# i# n# c# t#  # s# a# m# p# l# e#  # g# r# o# u# p# s# )# .#  # F# i# n# a# l# l# y# ,#  # k# N# N#  # i# s#  # a#  # m# e# t# h# o# d#  # t# o#  # c# l# a# s# s# i# f# y#  # s# a# m# p# l# e# s#  # b# a# s# e# d#  # o# f#  # p# r# o# x# i# m# i# t# y#  # b# e# t# w# e# e# n#  # s# a# m# p# l# e# s# .#  # 
# 
# ## ## ## ##  # O# u# r#  # s# i# m# p# l# e# s# t#  # m# e# t# h# o# d#  # i# s#  # t# h# e#  # t# h# i# r# d#  # a# p# p# r# o# a# c# h# .#  # H# o# w# e# v# e# r#  # i# s#  # t# h# e#  # m# e# t# h# o# d#  # t# h# a# t#  # g# i# v# e# s#  # l# e# s# s#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # o# u# r#  # d# a# t# a# .

# In[None]

from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from scipy.stats import norm

# In[None]

from sklearn.model_selection import train_test_split
data_train, data_test, target_train, target_test = train_test_split(data, np.array(target['target_class']), train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(data_train, target_train)
y_pred = model.predict(data_test)
score = accuracy_score(target_test, y_pred)
import numpy as np
np.save("prenotebook_res/7637196.npy", { "accuracy_score": score })

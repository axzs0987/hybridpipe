import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import pandas_profiling as pp
from plotly.offline import init_notebook_mode, iplot
init_notebook_mode(connected=True)
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df=pd.read_csv("../input/voicegender/voice.csv")
df.describe()
df.info()
#my_report=pp.ProfileReport(df)
#my_report.to_file("my_report.html")
#my_report
import missingno as miss
miss.matrix(df)
#plt.show()
X=df.iloc[:, :-1]
X.head()
df.label.unique()
from sklearn.preprocessing import LabelEncoder
y=df.iloc[:,-1]
encoder = LabelEncoder()
y = encoder.fit_transform(y)
print(y)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.svm import SVC
from sklearn import metrics
svc=SVC()
#svc.fit(X_train,y_train)
#y_pred=svc.predict(X_test)
print('Accuracy Score:')
#print(metrics.accuracy_score(y_test,y_pred))
from sklearn.metrics import  f1_score
#f1_score = f1_score(y_test, y_pred)
print("F1 Score:")
#print(f1_score)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ajaydabas_notebookff85755ae4.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ajaydabas_notebookff85755ae4/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ajaydabas_notebookff85755ae4/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ajaydabas_notebookff85755ae4/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ajaydabas_notebookff85755ae4/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ajaydabas_notebookff85755ae4/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# ##  # I# n#  # t# h# i# s#  # d# a# t# a# s# e# t# ,#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # t# a# l# k#  # a# b# o# u# t#  # t# h# e#  # f# a# l# l# i# n# g#  # o# f#  # e# l# d# e# r# l# y#  # p# e# o# p# l# e#  # a# n# d#  # s# e# e#  # h# o# w#  # w# e#  # c# a# n#  # p# r# e# v# e# n# t#  # t# h# i# s# 


# T# o#  # s# t# a# r# t#  # o# f# f# ,#  # w# e#  # n# e# e# d#  # t# o#  # i# m# p# o# r# t#  # t# h# e#  # d# a# t# a# s# e# t#  # a# n# d#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # i# t

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

# Since we already have numpy and pandas loaded, we will need to load the others that we are going to need

# In[None]

detectfall = pd.read_csv(r"../input/falldeteciton.csv")

# In[None]

# Let us look at the data now
print(detectfall.head())

# If you prefer another amount than the default, you can customized it
print(detectfall.head(3))

# In[None]

# You can see I have provided two different printing and got two different answers. This is how you can customize how many rows you would like to see

# ##  # D# E# S# C# R# I# P# T# I# V# E#  # S# T# A# T# I# S# T# I# C# S

# In[None]

# Let us now take a further look at the data and inspect the distribution
detectfall.shape

# In[None]

detectfall.describe()

# In[None]

# Let us check to see if there are any null values. It is good to check for this
detectfall.isna().sum()

# ##  # N# o# w#  # i# t#  # i# s#  # p# l# o# t# t# i# n# g#  # t# i# m# e

# In[None]

cols = ['TIME', 'SL', 'EEG', 'BP', 'HR', 'CIRCLUATION']

# In[None]

# Let's look at some plots now
fig = plt.figure(figsize = (10, 20)) # (Breite, Lange)
for i in range (0, len(cols)):
    fig.add_subplot(len(cols), 1, i+1)
    sns.distplot(detectfall[cols[i]]);

# In[None]

# Boxplot
sns.boxplot(data = detectfall)

# In[None]

# It looks like we have some heavy outliers in the EEG column. Since it is only a few value, we need to cut them out of the distribution. Also, SL has some outliers that need to be removed
detectfall = detectfall[(detectfall['EEG'] < detectfall['EEG'].quantile(0.999) ) 
& (detectfall['EEG'] > detectfall['EEG'].quantile(0.001))]

# For SL
detectfall = detectfall[(detectfall['SL'] < detectfall['SL'].quantile(0.999) ) 
& (detectfall['SL'] > detectfall['SL'].quantile(0.001))]

# In[None]

# Let us look at another boxplot of detectfall
sns.boxplot(data = detectfall)

# In[None]

# Before we start with the regression, we should take a time to look at what a picture of the data looks like. 
sns.lmplot('TIME', 'HR', data = detectfall,
          palette='Set1', fit_reg=False, scatter_kws={"s": 70})

# In[None]

# We could as well do a joint plot with seaborn to gather both histogram and scatter plot. This is one of the thing I like with seaborn. It gives you more option than matplotlib.
sns.jointplot('TIME', 'HR', detectfall)

# In[None]

# Another great feature that comes with seaborn is the heatmap plot. It allows you to see a plot of the correlation that each attribute has with each other. So here, I am sure you can see that the darker an attribute is in comparison with another, the least like there is any correlation between these two attributes. Just as in statistics, the closer the probability is to 1, the more there is a correlation; if it is closer to 0, the least likelyhood there is a correlation. So, this heatmap from seaborn just basically answered a few questions we may have had. This is very cool!!!
sns.heatmap(detectfall.corr())

# I# n#  # t# h# i# s#  # h# e# a# t# m# a# p# ,#  # t# h# e#  # l# i# g# h# t# e# r#  # t# h# e#  # s# q# u# a# r# e# ,#  # t# h# e#  # h# i# g# h# e# r#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n# ;#  # t# h# e#  # d# a# r# k# e# r#  # t# h# e#  # s# q# u# a# r# e# ,#  # t# h# e#  #  # l# e# s# s#  # t# h# e# y#  # a# r# e#  # c# o# r# r# e# l# a# t# e# d

# ##  # M# A# C# H# I# N# E#  # L# E# A# R# N# I# N# G#  # 1

# In[None]

from sklearn.model_selection import train_test_split

# Classifier
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

# Metrics
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

# In[None]

# It is time to split the data and create a training and testing set
target = detectfall['ACTIVITY']
attribute = detectfall[['TIME','SL','EEG','BP','HR','CIRCLUATION']]

# Training and test sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(attribute, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4842633.npy", { "accuracy_score": score })

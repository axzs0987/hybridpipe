import pandas as pd
# ## ## ## ##  # P# r# o# b# l# e# m#  # S# t# a# t# e# m# e# n# t# 
# 
# U# n# d# e# r# s# t# a# n# d# i# n# g#  # w# h# y#  # a# n# d#  # w# h# e# n#  # e# m# p# l# o# y# e# e# s#  # a# r# e#  # m# o# s# t#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # c# a# n#  # l# e# a# d#  # t# o#  # a# c# t# i# o# n# s#  # t# o#  # i# m# p# r# o# v# e#  # e# m# p# l# o# y# e# e#  # r# e# t# e# n# t# i# o# n#  # a# s#  # w# e# l# l#  # a# s#  # p# o# s# s# i# b# l# y#  # p# l# a# n# n# i# n# g#  # n# e# w#  # h# i# r# i# n# g#  # i# n#  # a# d# v# a# n# c# e# .#  # I#  # w# i# l# l#  # b# e#  # u# s# i# g# n#  # a#  # s# t# e# p# -# b# y# -# s# t# e# p#  # s# y# s# t# e# m# a# t# i# c#  # a# p# p# r# o# a# c# h#  # u# s# i# n# g#  # a#  # m# e# t# h# o# d#  # t# h# a# t#  # c# o# u# l# d#  # b# e#  # u# s# e# d#  # f# o# r#  # a#  # v# a# r# i# e# t# y#  # o# f#  # M# L#  # p# r# o# b# l# e# m# s# .#  # T# h# i# s#  # p# r# o# j# e# c# t#  # w# o# u# l# d#  # f# a# l# l#  # u# n# d# e# r#  # w# h# a# t#  # i# s#  # c# o# m# m# o# n# l# y#  # k# n# o# w# n#  # a# s#  # "# H# R#  # A# n# l# y# t# i# c# s# "# ,#  # "# P# e# o# p# l# e#  # A# n# a# l# y# t# i# c# s# "# .# 
#  #  #  #  #  #  #  #  # 
# ## ## ## ##  # L# o# a# d#  # L# i# b# r# a# r# i# e# s

# In[None]

# Basics
import pandas as pd
import numpy as np

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Preprocessing
from sklearn.preprocessing import StandardScaler, MinMaxScaler, binarize, LabelEncoder

# Model Selection
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, RandomizedSearchCV

# Model
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

# Metrics 
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, roc_auc_score, auc, accuracy_score

# Feature Selection
from sklearn.feature_selection import SelectKBest, chi2

# Warnings
import warnings as ws
ws.filterwarnings('ignore')

pd.pandas.set_option('display.max_columns', None)
sns.set_style("whitegrid")

# In[None]

# Load Dataset
data_hr = pd.read_csv('../input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv')
data_hr.head()

# ## ## ## ##  # D# a# t# a#  # D# e# s# c# r# i# p# t# i# o# n#  # a# n# d#  # E# x# p# l# o# r# a# t# o# r# y#  # V# i# s# u# a# l# i# s# a# t# i# o# n# s# 
# 
# I# n#  # t# h# i# s#  # s# e# c# t# i# o# n# ,#  # w# e#  # w# i# l# l#  # p# r# o# v# i# d# e#  # d# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s#  # t# h# a# t#  # s# u# m# m# a# r# i# z# e# s#  # o# r#  # e# x# t# r# a# c# t# s#  # r# e# l# e# v# a# n# t#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # o# f#  # f# e# a# t# u# r# e# s#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t# .#  # L# e# t# '# s#  # l# o# o# k#  # a# t#  # e# a# c# h#  # c# o# l# u# m# n#  # i# n#  # d# e# t# a# i# l# ,#  # g# e# t#  # a#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # a# n# d#  # g# r# o# u# p#  # t# h# e# m#  # t# o# g# e# t# h# e# r#  # w# h# e# n#  # a# p# p# r# o# p# r# i# a# t# e# .

# In[None]

print( 'DataSet Shape {}'.format(data_hr.shape))

data_hr.columns

# In[None]

# Summary
def summary(data):
    df = {
     'Count' : data.shape[0],
     'NA values' : data.isna().sum(),
     '% NA' : round((data.isna().sum()/data.shape[0]) * 100, 2),
     'Unique' : data.nunique(),
     'Dtype' : data.dtypes
    } 
    return(pd.DataFrame(df))

print('Shape is :', data_hr.shape)
summary(data_hr)

# H# e# r# e#  # t# h# e# r# e#  # i# s#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# .#  #  # *# *# E# m# p# l# o# y# e# e# C# o# u# n# t# ,#  # O# v# e# r# 1# 8# ,#  # S# t# a# n# d# a# r# d# H# o# u# r# s# *# *#  # h# a# s#  # o# n# l# y#  # o# n# e#  # v# a# l# u# e#  # a# n# d#  # *# *# E# m# p# l# o# y# e# e# N# u# m# b# e# r# *# *#  # i# s#  # n# o# t# h# i# n# g#  # b# u# t#  # I# D# .#  # S# o#  # t# h# a# t#  # w# e#  # c# a# n#  # d# r# o# p#  # t# h# o# s# e#  # c# o# l# u# m# n# s# .

# In[None]

data = data_hr.copy()
data.drop(['EmployeeCount', 'Over18', 'StandardHours','EmployeeNumber'], axis = 1, inplace = True)

# In[None]

num_var = [var for var in data if data[var].dtypes != 'O']
cat_var = [var for var in data if data[var].dtypes == 'O']

# ## ## ## ## ##  # 1# .#  # N# u# m# e# r# i# c# a# l#  # V# a# r# i# a# b# l# e# s#  

# In[None]

data[num_var].hist(bins = 25, figsize = (20,20))
plt.show()

# A#  # f# e# w#  # o# b# s# e# r# v# a# t# i# o# n# s#  # c# a# n#  # b# e#  # m# a# d# e#  # b# a# s# e# d#  # o# n#  # t# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# n# d#  # h# i# s# t# o# g# r# a# m# s#  # f# o# r#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s# :# 
# 
# 1# .#  # M# a# n# y#  # h# i# s# t# o# g# r# a# m# s#  # a# r# e#  # t# a# i# l# -# h# e# a# v# y# ;#  # i# n# d# e# e# d#  # s# e# v# e# r# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # a# r# e#  # r# i# g# h# t# -# s# k# e# w# e# d#  # (# e# .# g# .#  # M# o# n# t# h# l# y# I# n# c# o# m# e#  # D# i# s# t# a# n# c# e# F# r# o# m# H# o# m# e# ,#  # Y# e# a# r# s# A# t# C# o# m# p# a# n# y# )# .#  # D# a# t# a#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n#  # m# e# t# h# o# d# s#  # m# a# y#  # b# e#  # r# e# q# u# i# r# e# d#  # t# o#  # a# p# p# r# o# a# c# h#  # a#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n#  # p# r# i# o# r#  # t# o#  # f# i# t# t# i# n# g#  # a#  # m# o# d# e# l#  # t# o#  # t# h# e#  # d# a# t# a# .# 
# 
# 2# .#  # A# g# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # i# s#  # a#  # s# l# i# g# h# t# l# y#  # r# i# g# h# t# -# s# k# e# w# e# d#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n#  # w# i# t# h#  # t# h# e#  # b# u# l# k#  # o# f#  # t# h# e#  # s# t# a# f# f#  # b# e# t# w# e# e# n#  # 2# 5#  # a# n# d#  # 4# 5#  # y# e# a# r# s#  # o# l# d# .# 
# 
# 3# .#  # E# m# p# l# o# y# e# e# C# o# u# n# t#  # a# n# d#  # S# t# a# n# d# a# r# d# H# o# u# r# s#  # a# r# e#  # c# o# n# s# t# a# n# t#  # v# a# l# u# e# s#  # f# o# r#  # a# l# l#  # e# m# p# l# o# y# e# e# s# .#  # T# h# e# y# '# r# e#  # l# i# k# e# l# y#  # t# o#  # b# e#  # r# e# d# u# n# d# a# n# t#  # f# e# a# t# u# r# e# s# .# 
# 
# 4# .#  # E# m# p# l# o# y# e# e#  # N# u# m# b# e# r#  # i# s#  # l# i# k# e# l# y#  # t# o#  # b# e#  # a#  # u# n# i# q# u# e#  # i# d# e# n# t# i# f# i# e# r#  # f# o# r#  # e# m# p# l# o# y# e# e# s#  # g# i# v# e# n#  # t# h# e#  # f# e# a# t# u# r# e# '# s#  # q# u# a# s# i# -# u# n# i# f# o# r# m#  # d# i# s# t# r# i# b# u# t# i# o# n# .# 
# 
# H# e# r# e#  # w# e#  # c# a# n#  # s# p# l# i# t#  # c# o# n# t# i# n# u# o# u# s#  # a# n# d#  # d# i# s# c# r# e# t# e#  # v# a# l# u# e#  # f# o# r#  # f# u# r# t# h# e# r#  # a# n# a# l# y# s# i# s

# In[None]

cont_var = [var for var in num_var if len(data[var].unique()) > 10]
disc_var = [var for var in num_var if len(data[var].unique()) <= 10]

# ## ## ## ## ##  # a# .# c# o# n# t# i# n# u# o# u# s#  # v# a# r# i# a# b# l# e# 
# 
# L# e# t# '# s#  # c# r# e# a# t# e#  # a#  # k# e# r# n# e# l#  # d# e# n# s# i# t# y#  # e# s# t# i# m# a# t# i# o# n#  # (# K# D# E# )#  # p# l# o# t#  # c# o# l# o# r# e# d#  # b# y#  # t# h# e#  # v# a# l# u# e#  # o# f#  # t# h# e#  # t# a# r# g# e# t# .

# In[None]

plt.figure(figsize = (13,15))
i = 0
for cont in cont_var:
    
    mu_yes = data[cont][data['Attrition'] == 'Yes'].mean()
    mu_no = data[cont][data['Attrition'] == 'No'].mean()
    
    plt.subplot(5,3,i+1)
    sns.kdeplot(data[cont][data['Attrition'] == 'Yes'], label = 'Yes (mean: {:.2f})'.format(mu_yes))
    sns.kdeplot(data[cont][data['Attrition'] == 'No'], label = 'No (mean: {:.2f})'.format(mu_no))
    plt.tight_layout()
    plt.title('{} vs Attrition'.format(cont))
    i+=1
plt.show()

# ## ## ## ## ##  # b# .#  # D# i# s# c# r# e# a# t# e#  # V# a# r# i# a# b# l# e

# In[None]

plt.figure(figsize = (13,15))
i = 0
for disc in disc_var:
    
    j=0
    col = ['Fields', '% of Leavers']
    df_field = pd.DataFrame(columns = col)
    
    for field in list(data[disc].unique()):    
        ratio = data[(data[disc] == field ) & (data['Attrition'] == 'Yes')].shape[0]/data[data[disc] == field].shape[0]
        df_field.loc[j] = [field, ratio * 100]
        j+=1
    
    plt.subplot(5,3,i+1)
    sns.barplot(x = 'Fields', y = '% of Leavers', data = df_field)
    plt.tight_layout()
    plt.title('{} vs Attrition'.format(disc))
    i+=1
plt.show()

# ## ## ## ##  # 2# .#  # C# a# t# e# g# o# r# i# c# a# l#  # V# a# r# i# a# b# l# e# s#  #  

# In[None]

plt.figure(figsize = (13,25))
i = 0
for cat in cat_var[1:]:
    
    j=0
    col = ['Fields', '% of Leavers']
    df_field = pd.DataFrame(columns = col)
    
    for field in list(data[cat].unique()):    
        ratio = data[(data[cat] == field ) & (data['Attrition'] == 'Yes')].shape[0]/data[data[cat] == field].shape[0]
        df_field.loc[j] = [field, ratio * 100]
        j+=1
    
    plt.subplot(5,3,i+1)
    sns.barplot(x = 'Fields', y = '% of Leavers', data = df_field)
    plt.tight_layout()
    plt.xticks(rotation = 90)
    plt.title('{} vs Attrition'.format(cat))
    i+=1
plt.show()

# In[None]

# Attrition Rate
sns.countplot(x = 'Attrition', data = data)

# ## ## ## ##  # 3# .#  # C# o# r# r# e# l# a# t# i# o# n# 
# L# e# t# '# s#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # s# o# m# e#  # o# f#  # m# o# s# t#  # s# i# g# n# i# f# i# c# a# n# t#  # c# o# r# r# e# l# a# t# i# o# n# s# .#  # I# t#  # i# s#  # w# o# r# t# h#  # r# e# m# e# m# b# e# r# i# n# g#  # t# h# a# t#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t# s#  # o# n# l# y#  # m# e# a# s# u# r# e#  # l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n# s# .

# In[None]

data.columns

# In[None]

data['Target'] = data['Attrition'].replace({'No':0,'Yes':1})

# Find correlations with the target and sort
corr = data.corr()['Target'].sort_values()

print('-'*25)
print('Top 5 Positive Correlation')
print('-'*25)
print(corr.tail(5))

print('-'*25)
print('Top 5 Negative Correlation')
print('-'*25)
print(corr.head(5))

# In[None]

# Correlation Map
corr = data.corr()
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True
# Heatmap
plt.figure(figsize=(15, 10))
sns.heatmap(corr, annot = True, fmt = '.2f', mask = mask, linewidths = 2, cmap="YlGnBu", vmax = 0.5 )
plt.plot()

# In[None]

data.drop('Target',axis = 1, inplace = True)

# ## ## ##  # E# D# A#  # C# o# n# c# l# u# d# i# n# g#  # R# e# m# a# r# k# s# 
# 
# 
# L# e# t# '# s#  # s# u# m# m# a# r# i# s# e#  # t# h# e#  # f# i# n# d# i# n# g# s#  # f# r# o# m#  # t# h# i# s#  # E# D# A# :# 
# 
# *#  # T# h# e#  # d# a# t# a# s# e# t#  # d# o# e# s#  # n# o# t#  # f# e# a# t# u# r# e#  # a# n# y#  # m# i# s# s# i# n# g#  # o# r#  # e# r# r# o# n# e# o# u# s#  # d# a# t# a#  # v# a# l# u# e# s# ,#  # a# n# d#  # a# l# l#  # f# e# a# t# u# r# e# s#  # a# r# e#  # o# f#  # t# h# e#  # c# o# r# r# e# c# t#  # d# a# t# a#  # t# y# p# e# .# 
# *#  # T# h# e#  # s# t# r# o# n# g# e# s# t#  # p# o# s# i# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n# s#  # w# i# t# h#  # t# h# e#  # t# a# r# g# e# t#  # f# e# a# t# u# r# e# s#  # a# r# e# :#  # P# e# r# f# o# r# m# a# n# c# e#  # R# a# t# i# n# g# ,#  # M# o# n# t# h# l# y#  # R# a# t# e# ,#  # N# u# m#  # C# o# m# p# a# n# i# e# s#  # W# o# r# k# e# d# ,#  # D# i# s# t# a# n# c# e#  # F# r# o# m#  # H# o# m# e# .# 
# 3# .#  # T# h# e#  # s# t# r# o# n# g# e# s# t#  # n# e# g# a# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n# s#  # w# i# t# h#  # t# h# e#  # t# a# r# g# e# t#  # f# e# a# t# u# r# e# s#  # a# r# e# :#  # T# o# t# a# l#  # W# o# r# k# i# n# g#  # Y# e# a# r# s# ,#  # J# o# b#  # L# e# v# e# l# ,#  # Y# e# a# r# s#  # I# n#  # C# u# r# r# e# n# t#  # R# o# l# e# ,#  # a# n# d#  # M# o# n# t# h# l# y#  # I# n# c# o# m# e# .# 
# 4# .#  # T# h# e#  # d# a# t# a# s# e# t#  # i# s#  # i# m# b# a# l# a# n# c# e# d#  # w# i# t# h#  # t# h# e#  # m# a# j# o# r# i# y#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s#  # d# e# s# c# r# i# b# i# n# g#  # C# u# r# r# e# n# t# l# y#  # A# c# t# i# v# e#  # E# m# p# l# o# y# e# e# s# .# 
# 5# .#  # S# e# v# e# r# a# l#  # f# e# a# t# u# r# e# s#  # (# i# e#  # c# o# l# u# m# n# s# )#  # a# r# e#  # r# e# d# u# n# d# a# n# t#  # f# o# r#  # o# u# r#  # a# n# a# l# y# s# i# s# ,#  # n# a# m# e# l# y# :#  # E# m# p# l# o# y# e# e# C# o# u# n# t# ,#  # E# m# p# l# o# y# e# e# N# u# m# b# e# r# ,#  # S# t# a# n# d# a# r# d# H# o# u# r# s# ,#  # a# n# d#  # O# v# e# r# 1# 8# .# 
# 6# .#  # S# i# n# g# l# e#  # e# m# p# l# o# y# e# e# s#  # s# h# o# w#  # t# h# e#  # l# a# r# g# e# s# t#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s# ,#  # c# o# m# p# a# r# e# d#  # t# o#  # M# a# r# r# i# e# d#  # a# n# d#  # D# i# v# o# r# c# e# d#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# *#  # L# o# y# a# l#  # e# m# p# l# o# y# e# e# s#  # w# i# t# h#  # h# i# g# h# e# r#  # s# a# l# a# r# i# e# s#  # a# n# d#  # m# o# r# e#  # r# e# s# p# o# n# s# b# i# l# i# t# i# e# s#  # s# h# o# w#  # l# o# w# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e# i# r#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# 9# .#  # P# e# o# p# l# e#  # w# h# o#  # l# i# v# e#  # f# u# r# t# h# e# r#  # a# w# a# y#  # f# r# o# m#  # t# h# e# i# r#  # w# o# r# k#  # s# h# o# w#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e# i# r#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# 1# 0# .#  # P# e# o# p# l# e#  # w# h# o#  # t# r# a# v# e# l#  # f# r# e# q# u# e# n# t# l# y#  # s# h# o# w#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e# i# r#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# 1# 1# .#  # P# e# o# p# l# e#  # w# h# o#  # h# a# v# e#  # t# o#  # w# o# r# k#  # o# v# e# r# t# i# m# e#  # s# h# o# w#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e# i# r#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# 1# 2# .#  # E# m# p# l# o# y# e# e#  # w# h# o#  # w# o# r# k#  # a# s#  # S# a# l# e# s#  # R# e# p# r# e# s# e# n# t# a# t# i# v# e# s#  # s# h# o# w#  # a#  # s# i# g# n# i# f# i# c# a# n# t#  # p# e# r# c# e# n# t# a# g# e#  # o# f#  # L# e# a# v# e# r# s#  # i# n#  # t# h# e#  # s# u# b# m# i# t# t# e# d#  # d# a# t# a# s# e# t# .# 
# 1# 3# .#  # E# m# p# l# o# y# e# e# s#  # t# h# a# t#  # h# a# v# e#  # a# l# r# e# a# d# y#  # w# o# r# k# e# d#  # a# t#  # s# e# v# e# r# a# l#  # c# o# m# p# a# n# i# e# s#  # p# r# e# v# i# o# u# s# l# y#  # (# a# l# r# e# a# d# y#  # "# b# o# u# n# c# e# d# "#  # b# e# t# w# e# e# n#  # w# o# r# k# p# l# a# c# e# s# )#  # s# h# o# w#  # h# i# g# h# e# r#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # c# o# m# p# a# r# e# d#  # t# o#  # t# h# e# i# r#  # c# o# u# n# t# e# r# p# a# r# t# s# .# 
# 
# 
# ## ## ##  # P# r# e# -# p# r# o# c# e# s# s# i# n# g#  # P# i# p# e# l# i# n# e# 
# 
# ## ## ## ##  # E# n# c# o# d# i# n# g# 
# 
# M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s#  # c# a# n#  # t# y# p# i# c# a# l# l# y#  # o# n# l# y#  # h# a# v# e#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # a# s#  # t# h# e# i# r#  # p# r# e# d# i# c# t# o# r#  # v# a# r# i# a# b# l# e# s# .#  # H# e# n# c# e#  # L# a# b# e# l#  # E# n# c# o# d# i# n# g#  # b# e# c# o# m# e# s#  # n# e# c# e# s# s# a# r# y#  # a# s#  # t# h# e# y#  # e# n# c# o# d# e#  # c# a# t# e# g# o# r# i# c# a# l#  # l# a# b# e# l# s#  # w# i# t# h#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s# .#  # T# o#  # a# v# o# i# d#  # i# n# t# r# o# d# u# c# i# n# g#  # f# e# a# t# u# r# e#  # i# m# p# o# r# t# a# n# c# e#  # f# o# r#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# s#  # w# i# t# h#  # l# a# r# g# e#  # n# u# m# b# e# r# s#  # o# f#  # u# n# i# q# u# e#  # v# a# l# u# e# s# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # b# o# t# h#  # L# a# b# l# e#  # E# n# c# o# d# i# n# g#  # a# n# d#  # O# n# e# -# H# o# t#  # E# n# c# o# d# i# n# g#  # a# s#  # s# h# o# w# n#  # b# e# l# o# w# .# 
# 
# ## ## ## ## ## ##  # 1# .#  # L# a# b# e# l#  # E# n# c# o# d# i# n# g

# In[None]

label_var = [var for var in cat_var if len(data[var].unique()) <=2]

le = LabelEncoder()
for label in label_var:
    data[label] = le.fit_transform(data[label])
    
print('{} columns were Label Encoded'.format(label_var))

# ## ## ## ## ##  # 2# .#  # O# n# e# H# o# t# E# n# c# o# d# i# n# g#  

# In[None]

data = pd.get_dummies(data, drop_first = True)
print('Shape of the data is {}'.format(data.shape))

# In[None]

# Scaling Data (MinMaxScaler)
scale = MinMaxScaler(feature_range = (0,5))
HR_col = list(data.columns)
HR_col.remove('Attrition')
for col in HR_col:
    data[col] = data[col].astype(float)
    data[[col]] = scale.fit_transform(data[[col]])
data['Attrition'] = pd.to_numeric(data['Attrition'], downcast='float')
data.head()

# ## ## ## ##  # S# p# l# i# t# i# n# g#  # D# a# t# a# s# e# t#  # i# n# t# o#  # T# r# a# i# n#  # a# n# d#  # T# e# s# t#  # s# e# t# s

# In[None]

X = data.drop('Attrition', axis = 1)
Y = data['Attrition']

# In[None]

# Train Test Split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8899943.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # :# -#  # *# *# A# d# u# l# t#  # C# e# n# s# u# s#  # d# a# t# a#  # A# n# a# l# y# s# i# s# *# *# 
# 
# *# *# *# O# b# j# e# c# t# i# v# e# :# *# *# *# 
# 
# 1# )#  # T# h# e# r# e#  # i# s#  # a# n# y#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # G# e# n# d# e# r#  # a# n# d#  # i# n# c# o# m# e# .# 
# 
# 2# )#  # I# f#  # t# h# e# r# e#  # i# s#  # a# n# y#  # a# s# s# o# c# i# a# t# i# o# n#  # ,#  # t# h# e# n#  # i# s#  # i# t#  # p# o# s# i# t# i# v# e#  # o# r#  # n# e# g# a# t# i# v# e# .# 
# 
# 3# )#  # C# h# e# c# k#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # m# e# n#  # a# r# e#  # e# a# r# n# i# n# g#  # m# o# r# e#  # m# o# n# e# y#  # t# h# a# n#  # f# e# m# a# l# e# 
# 
# P# r# e# d# i# c# t# i# o# n#  # 
# 
# *# *# O# b# j# e# c# t# i# v# e# *# *# 
# 
# P# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # i# n# c# o# m# e#  # e# x# c# e# e# d#  # 5# 0# K# /#  # y# r#  # b# a# s# e# d#  # o# n#  # C# e# n# s# u# s#  # D# a# t# a

# In[None]

import pandas as pd
import seaborn as sns
import matplotlib 
import matplotlib.pyplot as plt
import csv

# In[None]

census_data = pd.read_csv('../input/adult-census-income/adult.csv')
census_data.head()

# C# h# e# c# k# i# n# g#  # a# n# y#  # n# u# l# l#  # v# a# l# u# e#  # i# n#  # t# h# e#  # d# a# t# a# f# r# a# m# e

# In[None]

census_data.isnull().sum()

# F# o# l# l# o# w# i# n# g#  # i# s#  # s# u# m# m# a# r# y#  # t# a# b# l# e#  # o# f#  # c# o# n# t# i# n# o# u# s#  # v# a# r# i# a# b# l# e#  # o# f#  # D# a# t# a# F# r# a# m# e# ,#  # W# h# i# c# h#  # c# o# n# t# a# i# n#  # f# o# l# l# o# w# i# n# g#  # i# n# f# o# r# m# a# t# i# o# n# :# 
# 
# 1# )#  # N# u# m# b# e# r#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n#  # i# n#  # e# a# c# h#  # c# o# l# u# m# n# 
# 
# 2# )#  # A# v# e# r# a# g# e#  # ,#  # m# i# n# i# m# u# m#  # a# n# d#  # m# a# x# i# m# u# m# m#  # v# a# l# u# e#  # o# f#  # e# a# c# h#  # c# o# l# u# m# n# 
# 
# 3# )#  # f# i# r# s# t#  # ,#  # s# e# c# o# n# d#  # a# n# d#  # t# h# i# r# d#  # q# u# a# r# t# i# l# e

# In[None]

census_data.describe()

# In[None]

census_data.info()

# R# e# n# a# m# i# n# g#  # c# o# l# u# m# n# s#  # n# a# m# e#  # a# s#  # w# e# l# l#  # a# s#  # r# e# p# l# a# c# i# n# g#  # v# a# l# u# e#  # o# f#  # p# a# r# i# t# i# c# u# l# a# r#  # c# o# l# u# m# n# s# .

# In[None]

census_data.workclass = census_data.workclass.replace({'?':'Not-Known'})
census_data.occupation = census_data.occupation.replace({'?':'Not-Known'})
census_data = census_data.rename(columns = {'education.num':'education_num'})
census_data = census_data.rename(columns ={'marital.status':'marital_status'})
census_data = census_data.rename(columns ={'capital.gain':'capital_gain'})
census_data = census_data.rename(columns ={'capital.loss':'capital_loss'})
census_data = census_data.rename(columns = {'hours.per.week':'hours_per_week'})
census_data = census_data.rename(columns ={'native.country':'native_country'})
census_data.head()

# F# o# l# l# o# w# i# n# g#  # i# s#  # g# r# a# p# h# i# c# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # v# a# r# i# o# u# s#  # c# o# l# u# m# n# s#  # o# f#  # d# a# t# a#  # s# e# t# .

# In[None]

sns.countplot(x = 'sex',data = census_data)
plt.title("Gender")

# In[None]

census_data4 =census_data.groupby('workclass').sex.count().sort_values()
plt.title('Work - class')
census_data4.plot.bar()

# In[None]

census_data5 =census_data.groupby('occupation').sex.count().sort_values()
plt.title('Occupation')
census_data5.plot.bar()

# In[None]

census_data6 =census_data.groupby('marital_status').sex.count().sort_values()
plt.title('Marital_status')
census_data6.plot.bar()

# In[None]

census_data7 =census_data.groupby('relationship').sex.count().sort_values()
plt.title('Relationship')
census_data7.plot.bar()

# In[None]

census_data8 =census_data.groupby('race').sex.count().sort_values()
plt.title('Race')
census_data8.plot.bar()

# D# o# i# n# g#  # s# t# a# t# i# s# t# i# c# a# l#  # c# h# i# s# q# u# a# r# e#  # t# e# s# t#  # t# o#  # c# h# e# c# k#  # a# s# s# o# c# i# a# t# i# o# n#  # b# e# t# w# e# e# n#  # G# e# n# d# e# r#  # a# n# d#  # i# n# c# o# m# e#  # 
# 
# H# y# p# o# t# h# e# s# i# s#  # 
# 
# N# u# l# l#  # h# y# p# o# t# h# e# s# i# s#  # *# *# H# o#  # =#  # T# h# e# r# e#  # i# s#  # n# o#  # a# s# s# o# c# i# a# t# i# o# n#  # b# e# t# w# e# e# n#  # G# e# n# d# e# r#  # a# n# d#  # i# n# c# o# m# e# *# *# 
# 
# V# s#  # A# l# t# e# r# n# a# t# i# v# e#  # h# y# p# o# t# h# e# s# i# s#  # *# *# H# 1#  # =#  # T# h# e# r# e#  # i# s#  # a# s# s# o# c# i# a# t# i# o# n# *# *

# In[None]

census_data9 = pd.crosstab(census_data.sex , census_data.income)
print("Following is contigency table")
census_data9

# In[None]

a1 = [9592,1179]
a2 = [15128,6662]

a3 = np.array([a1,a2])

from scipy import stats
stats.chi2_contingency(a3)

chi2_stat, p_val, dof, ex = stats.chi2_contingency(a3)
print("Chisquare test value is : ",chi2_stat)
print("\nDegree of freedom is : ",dof)
print("\nP-Value is : ",p_val)
print("\nExpected observation contiggency table\n")
print(ex)

# S# i# n# c# e#  # f# r# o# m#  # a# b# o# v# e#  # r# e# s# u# l# t#  # ,#  # 
# 
# C# h# i# s# q# u# a# r# e#  # v# a# l# u# e#  # i# s#  # g# r# e# a# t# e# r#  # t# h# a# n#  # p# -# v# a# l# u# e#  # s# o#  # w# e#  # r# e# j# e# c# t#  # H# 0#  # a# n# d#  # c# o# n# c# l# u# d# e#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # a# s# s# o# c# i# a# t# i# o# n#  # b# e# t# w# e# e# n#  # G# e# n# d# e# r#  # a# n# d#  # i# n# c# o# m# e# .# 
# 
# *# *# O# b# j# e# c# t# i# v# e#  # 1#  # i# s#  # c# o# m# p# l# e# t# e# d# .# *# *# 
# 
# N# o# w#  # w# e#  # c# h# e# c# k# i# n# g#  # s# e# c# o# n# d#  # o# b# j# e# c# t# i# v# e# ,#  # w# h# e# t# h# e# r#  # i# t#  # i# s#  # p# o# s# i# t# i# v# e#  # o# r#  # n# e# g# a# t# i# v# e#  # a# s# s# o# c# i# a# t# i# o# n# .# 
# 
# *# T# o#  # c# h# e# c# k#  # P# o# s# i# t# i# v# e#  # o# r#  # n# e# g# a# t# i# v# e#  # a# s# s# o# c# i# a# t# i# o# n# ,#  # W# e#  # u# s# e#  # c# o# n# c# e# p# t# s#  # a# s#  # f# o# l# l# o# w# ,# *# 
# 
# G# e# n# d# e# r#  # h# a# s#  # t# w# o#  # l# e# v# e# l#  # a# 1#  # =#  # F# e# m# a# l# e#  # a# n# d#  # a# 2#  # =#  # M# a# l# e# .#  # I# n# c# o# m# e#  # h# a# s#  # t# w# o#  # l# e# v# e# l#  # b# 1#  # =#  # '# <# =# 5# 0# K# '#  # a# n# d#  # b# 2#  # =#  # '# ># 5# 0# k# '# 
# 
# t# h# e# n#  # f# o# l# l# o# w# i# n# g#  # i# s#  # f# o# r# m# u# l# a#  # i# s#  # u# s# e# d#  # t# o#  # f# i# n# d#  # a# s# s# o# c# i# a# t# i# o# n# 
# 
# *# *# f# o# r#  # p# o# s# i# t# i# v# e#  # a# s# s# o# c# i# a# t# i# o# n#  #  # (# a# 1# b# 1# )#  # >#  # (# (# a# 1# )# (# b# 1# )# )# /# N# *# *# 
# 
# *# *# f# o# r#  # n# e# g# a# t# i# v# e#  # a# s# s# o# c# i# a# t# i# o# n#  # (# a# 1# b# 1# )#  # <#  # (# (# a# 1# )# (# b# 1# )# )# /# N# *# *# 
# 
# 
# w# h# e# r# e# ,# 
# 
# (# a# 1# b# 1# )#  # =#  # N# u# m# b# e# r#  # o# f#  # F# e# m# a# l# e#  # e# a# r# n# i# n# g#  # l# e# s# s#  # t# h# a# n#  # <# =# 5# 0# K# 
# (# a# 1# )#  # =#  # T# o# t# a# l#  # n# u# m# b# e# r#  # o# f#  # F# e# m# a# l# e#  # o# b# s# e# r# v# a# t# i# o# n# 
# (# b# 1# )#  # =#  # T# o# t# a# l#  # n# u# m# b# e# r#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n#  # e# a# r# n# i# n# g#  # l# e# s# s#  # t# h# a# n#  # <# =# 5# 0# K# 
# N#  # =#  # T# o# t# a# l#  # n# u# m# b# e# r#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s# 


# In[None]

x,y,z = a3[0][1]+a3[0][0],a3[1][1]+a3[1][0],a3[0][0]+a3[1][0]+a3[0][1]+a3[1][1]
print('Number of female earning less than <=50K is ',a3[0][0])
print('Number of female observation is ',a3[0][1]+a3[0][0])
print('Number of male ',a3[1][1]+a3[1][0])
print('Total observation is ',a3[0][0]+a3[1][0]+a3[0][1]+a3[1][1])
print("Value of evaluation metric is ",((x*y)/z))

# F# r# o# m#  # a# b# o# v# e#  # r# e# s# u# l# t# ,#  # (# a# 1# b# 1# )#  # >#  # (# a# 1# )# (# b# 1# )# /# N#  # h# e# n# c# e#  # i# t#  # i# s#  # p# o# s# i# t# i# v# e#  # a# s# s# o# c# i# a# t# i# o# n# .#  # 
# 
# H# e# n# c# e#  # o# u# r#  # s# e# c# o# n# d#  # o# b# j# e# c# t# i# v# e#  # i# s#  # a# l# s# o#  # c# o# m# p# l# e# t# e# d# .# 
# 
# N# o# w#  # w# e#  # w# i# l# l#  # c# h# e# c# k#  # t# h# i# r# d#  # o# b# j# e# c# t# i# v# e#  # t# h# a# t#  # i# s# ,#  # d# o# e# s#  # m# a# n#  # e# a# r# n# i# n# g#  # m# o# r# e#  # m# o# n# e# r# y#  # t# h# a# n#  # f# e# m# a# l# e# 
# 
# F# o# l# l# o# w# i# n# g#  # i# s#  # g# e# n# d# e# r#  # ,#  # i# n# c# o# m# e# w# i# s# e#  # p# e# r# c# e# n# t#  # d# i# s# t# r# i# b# u# t# i# o# n

# In[None]

census_data10 = (census_data.groupby(['sex','income']).workclass.count()/census_data.groupby(['sex']).workclass.count())*100
census_data10

# F# r# o# m#  # a# b# o# v# e#  # r# e# s# u# l# t#  # ,#  # 
# 
# 2# 0# %#  # m# o# r# e#  # f# e# m# a# l# e#  # i# s#  # e# a# r# n# i# n# g#  # <# =# 5# 0# K#  # t# h# a# n#  # m# a# l# e# ,#  # w# h# i# l# e#  # 2# 0# %#  #  # m# o# r# e#  # m# a# l# e#  # i# s#  # e# a# r# n# i# n# g#  # ># 5# 0# K#  # t# h# a# n#  # f# e# m# a# l# e# .# 
# 
# T# h# i# s#  # r# e# v# e# a# l# e# d#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # M# a# l# e#  # m# a# k# e#  # m# o# r# e#  # m# o# n# e# y#  # t# h# a# n#  # f# e# m# a# l# e#  # i# f#  # i# n# c# o# m# e#  # ># 5# 0# K#  # w# h# i# l# e#  # F# e# m# a# l# e#  # m# a# k# e#  # m# o# r# e#  # m# o# n# e# y#  # i# f#  # i# n# c# o# m# e#  # <# =# 5# 0# K# .

# In[None]

census_data11 = (census_data.groupby(['sex','income','workclass']).workclass.count()/census_data.groupby(['sex','income']).workclass.count())*100
census_data11

# N# o# w#  # w# e#  # g# o#  # o# n# e#  # s# t# e# p#  # m# o# r# e#  # ,#  # H# e# r# e#  # i# s#  # a# n# a# l# y# s# i# s

# In[None]

census_data11 = (census_data.groupby(['sex','income','marital_status']).workclass.count()/census_data.groupby(['sex','income']).workclass.count())*100
census_data11

# F# r# o# m#  # a# b# o# v# e#  # r# e# s# u# l# t# s# ,# 
# 
# 3# %#  # m# o# r# e#  # n# u# m# b# e# r#  # o# f#  # p# r# i# v# a# t# e#  # f# e# m# a# l# e#  # e# m# p# l# o# y# e# e# s#  # i# s#  # e# a# r# n# i# n# g#  # <# =# 5# 0# K#  # t# h# a# n#  # m# a# l# e# ,# w# h# i# l# e#  # o# n# l# y#  # 2# %#  # m# o# r# e#  # n# u# m# b# e# r#  # o# f#  # m# o# r# e#  # p# r# i# v# a# t# e#  # m# a# l# e#  # e# m# p# l# o# y# e# e#  # i# s#  # e# a# r# n# i# n# g#  # ># 5# 0# K#  # t# h# a# n#  # f# e# m# a# l# e# .# 
# 
# M# o# r# e#  # d# i# v# o# r# c# e# d#  # a# n# d#  # u# n# m# a# r# r# i# e# d#  # f# e# m# a# l# e#  # i# s#  # e# a# r# n# i# n# g#  # <# =# 5# 0# K#  # t# h# a# n#  # m# a# l# e#  # ,#  # W# h# i# l# e#  # M# o# r# e#  # M# a# l# e#  # m# a# r# r# i# e# d# -# c# i# v# -# s# p# o# u# s# e#  # i# s#  # e# a# r# n# i# n# g#  # ># 5# 0# K#  # t# h# a# n#  # F# e# m# a# l# e# .# 
# 
# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -#  #  # E# N# D#  # O# F#  # E# D# A#  #  # -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -

# *# *# O# b# j# e# c# t# i# v# e# *# *# 
# 
# P# r# e# d# i# c# t# i# n# g#  # w# h# e# t# h# e# r#  # i# n# c# o# m# e#  # e# x# c# e# e# d#  # 5# 0# K# /# y# r#  # b# a# s# e# d#  # o# n#  # c# e# n# s# u# s#  # d# a# t# a

# In[None]

census_data_v1 = census_data
census_data_v1.head()

# In[None]

dummy = pd.get_dummies(census_data_v1['workclass'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['workclass'],axis = 1)
dummy = pd.get_dummies(census_data_v1['education'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['education'],axis = 1)
dummy = pd.get_dummies(census_data_v1['marital_status'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['marital_status'],axis = 1)
dummy = pd.get_dummies(census_data_v1['occupation'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['occupation'],axis = 1)
dummy = pd.get_dummies(census_data_v1['relationship'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['relationship'],axis = 1)
dummy = pd.get_dummies(census_data_v1['race'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['race'],axis = 1)
dummy = pd.get_dummies(census_data_v1['sex'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['sex'],axis = 1)
dummy = pd.get_dummies(census_data_v1['native_country'])
census_data_v1 = pd.concat([census_data_v1 ,dummy],axis = 1)
census_data_v1 = census_data_v1.drop(['native_country'],axis = 1)

# In[None]

X = census_data_v1[census_data_v1.columns.difference(['income'])]
y = census_data_v1['income']
y = y.replace('>50K',1)
y = y.replace('<=50K',0)

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score
from sklearn.metrics import mean_squared_error

# In[None]

from sklearn.model_selection import train_test_split
X_train, val_X, y_train, val_y = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(val_X)
score = accuracy_score(val_y, y_pred)
import numpy as np
np.save("prenotebook_res/7589719.npy", { "accuracy_score": score })

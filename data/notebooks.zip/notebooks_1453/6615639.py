import pandas as pd
# 
# 
# ##  # A# d# u# l# t#  # I# n# c# o# m# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n

# ## ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # P# r# o# j# e# c# t

# ## ## ##  # C# o# n# t# e# n# t# s# 
# 
# ## ## ##  # 1# .#  # I# n# t# r# o# d# u# c# t# i# o# n# 
# 
# ## ## ##  # 2# .#  # G# e# n# e# r# a# l#  # V# i# e# w#  # o# f#  # t# h# e#  # D# a# t# a# 
# 
# ## ## ##  # 3# .#  # D# a# t# a#  # C# l# e# a# n# i# n# g# 
# 
# ## ## ##  # 4# .#  # E# x# p# l# o# r# i# n# g#  # t# h# e#  # D# a# t# a# 
# 
# ## ## ##  # 5# .# M# o# d# e# l# s# 
# 
# ## ## ##  # 6# .# C# o# n# c# l# u# s# i# o# n# s#  

# ## ##  # 1# .#  # I# n# t# r# o# d# u# c# t# i# o# n

# O# u# r#  # a# i# m#  # i# n#  # t# h# i# s#  # p# r# o# j# e# c# t#  # i# s#  # t# o#  # p# r# e# d# i# c# t#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # b# y#  # i# n# c# o# m# e# .# T# h# e#  # p# r# e# d# i# c# t# i# o# n#  # t# a# s# k#  # i# s#  # t# o#  # d# e# t# e# r# m# i# n# e#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # m# a# k# e# s#  # o# v# e# r#  # $# 5# 0# K#  # a#  # y# e# a# r# .# T# h# i# s#  # d# a# t# a#  # u# s# e# d#  # w# a# s#  # e# x# t# r# a# c# t# e# d#  # f# r# o# m#  # t# h# e#  # 1# 9# 9# 4#  # C# e# n# s# u# s#  # b# u# r# e# a# u#  # d# a# t# a# b# a# s# e#  # b# y#  # R# o# n# n# y#  # K# o# h# a# v# i#  # a# n# d#  # B# a# r# r# y#  # B# e# c# k# e# r# .# A#  # s# e# t#  # o# f#  # r# e# a# s# o# n# a# b# l# y#  # c# l# e# a# n#  # r# e# c# o# r# d# s#  # w# a# s#  # e# x# t# r# a# c# t# e# d#  # u# s# i# n# g#  # f# o# l# l# o# w# i# n# g#  # c# o# n# d# i# t# i# o# n# s# :#  # (# (# A# A# G# E# ># 1# 6# )#  # &# &#  # (# A# G# I# ># 1# 0# 0# )#  # &# &#  # (# A# F# N# L# W# G# T# ># 1# )#  # &# &#  # (# H# R# S# W# K# ># 0# )# )# .# 


# ## ##  # 2# .#  # G# e# n# e# r# a# l#  # V# i# e# w#  # o# f#  # t# h# e#  # D# a# t# a

#  # *# *# C# o# l# u# m# n# s# *# *# 
# *#  # a# g# e#  # 
# *#  # w# o# r# k# c# l# a# s# s#  # 
# *#  # f# n# l# w# g# t#  # 
# *#  # e# d# u# c# a# t# i# o# n#  # 
# *#  # e# d# u# c# a# t# i# o# n# -# n# u# m#  # 
# *#  # m# a# r# i# t# a# l# -# s# t# a# t# u# s#  # 
# *#  # o# c# c# u# p# a# t# i# o# n# 
# *#  # r# e# l# a# t# i# o# n# s# h# i# p#  # 
# *#  # r# a# c# e#  # 
# *#  # s# e# x#  # 
# *#  # c# a# p# i# t# a# l# -# g# a# i# n#  # 
# *#  # c# a# p# i# t# a# l# -# l# o# s# s#  # 
# *#  # h# o# u# r# s# -# p# e# r# -# w# e# e# k#  # 
# *#  # n# a# t# i# v# e# -# c# o# u# n# t# r# y#  # 
# *#  # i# n# c# o# m# e#  

#  # _# _# C# a# t# e# g# o# r# i# c# a# l#  # V# a# r# i# a# b# l# e# s# _# _# 
#  # 
#  # 
#  # *#  # s# e# x#  # 
#  # *#  # r# a# c# e# 
#  # *#  # i# n# c# o# m# e# 
#  # *#  # w# o# r# k# c# l# a# s# s#  #  #  #  #  #  #  #  #  # 
#  # *#  # e# d# u# c# a# t# i# o# n# 
#  # *#  # o# c# c# u# p# a# t# i# o# n# 
#  # *#  # r# e# l# a# t# i# o# n# s# h# i# p#  # 
#  # *#  # m# a# r# i# t# a# l# -# s# t# a# t# u# s#  #  #  #  # 
#  # *#  # n# a# t# i# v# e# -# c# o# u# n# t# r# y#  #  #  #  #  #  #  #  #  #  # 
#  #  #  #  # 
#  #  # _# _# C# o# n# t# i# n# u# o# u# s#  # V# a# r# i# a# b# l# e# s# _# _# 
#  #  # 
# 
#  # *#  # a# g# e# 
#  # *#  # f# n# l# w# g# t#  # 
#  # *#  # c# a# p# i# t# a# l# -# l# o# s# s# 
#  # *#  # c# a# p# i# t# a# l# -# g# a# i# n# 
#  # *#  # e# d# u# c# a# t# i# o# n# -# n# u# m#  # 
#  # *#  # h# o# u# r# s# -# p# e# r# -# w# e# e# k

# ## ## ##  # L# e# t# '# s#  # s# t# a# r# t#  # b# y#  # i# m# p# o# r# t# i# n# g#  # l# i# b# r# a# r# i# e# s

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ## ## ##  # V# i# e# w# i# n# g#  # D# a# t# a

# In[None]

df = pd.read_csv("../input/adult-census-income/adult.csv")
df.columns = df.columns.str.replace(" ","")

# In[None]

df.head()

# In[None]

df.info()

# In[None]

df.describe().T

# ## ##  # 3# .#  # D# a# t# a#  # C# l# e# a# n# i# n# g

# ## ## ##  # I# s#  # t# h# e# r# e#  # m# i# s# s# i# n# g#  # d# a# t# a#  # ?

# In[None]

df.isna().values.any()

# ## ## ##  # I# s#  # t# h# e# r# e#  # p# r# o# b# l# e# m# a# t# i# c#  # v# a# l# u# e# s#  # ?

# In[None]

for sutun_adi in df.columns:
    print("{} sütundaki benzersiz değerler".format(sutun_adi))
    print("{}".format(df[sutun_adi].unique()),"\n")

# In[None]

df["native.country"] = df["native.country"].apply(str.strip).replace("?",np.nan)
liste_1 =df["native.country"]

for i in range(0,len(liste_1)):
    if pd.isnull(liste_1[i]):
        liste_1[i] = liste_1[i-1]
        
df["native.country"].unique()        
                

# In[None]

df["occupation"] = df["occupation"].apply(str.strip).replace("?",np.nan)

liste_2 =df["occupation"]

for i in range(0,len(liste_2)):
    if pd.isnull(liste_2[i]):
        liste_2[i] = liste_2[i+1]
        
df["occupation"].unique() 

# In[None]

df["workclass"] = df["workclass"].apply(str.strip).replace("?",np.nan)
liste_3 =df["workclass"]

for i in range(0,len(liste_3)):
    if pd.isnull(liste_3[i]):
        liste_3[i] = liste_3[i+1]
        
df["workclass"].unique() 

# ## ## ##  # A# n# d#  # l# a# s# t#  # h# o# w#  # a# b# a# o# u# t#  # t# h# e#  # o# u# t# l# i# e# r# s#  # ?

# In[None]

plt.figure(figsize=(19,12))


num_feat = df.select_dtypes(include=['int64']).columns

for i in range(6):
    plt.subplot(2,3,i+1)
    plt.boxplot(df[num_feat[i]])
    plt.title(num_feat[i],color="g",fontsize=20)
    plt.yticks(fontsize=14)
    plt.xticks(fontsize=14)


plt.show()

# ## ## ##  # L# e# t# '# s#  # g# e# t#  # r# i# d#  # o# f#  # t# h# e#  # o# u# t# l# i# e# r# s#  # b# y#  # w# i# n# s# o# r# i# z# a# t# i# o# n

# In[None]

from scipy.stats.mstats import winsorize
df["age"]           = winsorize(df["age"],(0,0.15))
df["fnlwgt"]        = winsorize(df["fnlwgt"],(0,0.15))
df["capital.gain"]  = winsorize(df["capital.gain"],(0,0.099))
df["capital.loss"]  = winsorize(df["capital.loss"],(0,0.099))
df["hours.per.week"]= winsorize(df["hours.per.week"],(0.12,0.18))

# In[None]

plt.rcParams['figure.figsize'] = (25,7)

baslik_font = {'family':'arial','color':'purple','weight':'bold','size':25}

col_list=['age',"fnlwgt",'capital.gain', 'capital.loss', 'hours.per.week']

for i in range(5):
    plt.subplot(1,5,i+1)
    plt.boxplot(df[col_list[i]])
    plt.title(col_list[i],fontdict=baslik_font)

plt.show()

# ## ##  # 4# .#  # E# x# p# l# o# r# i# n# g#  # t# h# e#  # D# a# t# a

# ## ## ##  # C# o# n# t# i# n# u# o# u# s#  # V# a# r# i# a# b# l# e# s# '# s#  # D# i# s# t# r# i# b# u# t# i# o# n#  # G# r# a# p# h# s#  # a# b# o# u# t#  # I# n# c# o# m# e

# In[None]

con_var=['age', 'fnlwgt', 'education.num','hours.per.week']

# In[None]

plt.figure(figsize=(15,10))
plt.subplot(221)

i=0
for x in con_var:
    plt.subplot(2, 2, i+1)
    i += 1
    ax1=sns.kdeplot(df[df['income'] == '<=50K'][x], shade=True,label="income <=50K")
    sns.kdeplot(df[df['income'] == '>50K'][x], shade=False,label="income   >50K", ax=ax1)
    plt.title(x,fontsize=15)

plt.show()

# ## ## ##  # C# a# t# e# g# o# r# i# c# a# l#  # V# a# r# i# a# b# l# e# s# '# s#  # G# r# a# p# h# s#  # b# y#  # C# o# u# n# t#  # P# l# o# t#  # a# b# o# u# t#  # İ# n# c# o# m# e

# In[None]

plt.figure(figsize=(15,7))

deg=["race","sex"]

for i in range(2):
    plt.subplot(1,2,i+1)
    sns.countplot(x=deg[i],data=df,hue='income')
    plt.xlabel(deg[i],color="darkorange",fontsize=18)
    plt.ylabel("Count",color="darkorange",fontsize=18)
    plt.yticks(fontsize=13)
    plt.xticks(rotation=90,fontsize=13)

plt.show()

# O# f#  # c# o# u# r# s# e#  # w# e#  # a# r# e#  # a# g# a# i# n# s# t#  # r# a# c# i# a# l#  # a# n# d#  # g# e# n# d# e# r#  # d# i# s# c# r# i# m# i# n# a# t# i# o# n#  # :# )#  

# In[None]

plt.figure(figsize=(15,7))

deg=["occupation","hours.per.week"]

for i in range(2):
    plt.subplot(1,2,i+1)
    sns.countplot(x=deg[i],data=df,hue="income")
    plt.xlabel(deg[i],color="darkorange",fontsize=20)
    plt.ylabel("Count",color="darkorange",fontsize=20)
    plt.yticks(fontsize=13)
    plt.xticks(rotation=90,fontsize=13)

plt.show()

# In[None]

plt.figure(figsize=(16,7))

deg=["education","education.num"]

for i in range(2):
    plt.subplot(1,2,i+1)
    sns.countplot(x=deg[i],data=df,hue="income")
    plt.xlabel(deg[i],color="darkorange",fontsize=20)
    plt.ylabel("Count",color="darkorange",fontsize=20)
    plt.yticks(fontsize=13)
    plt.xticks(rotation=90,fontsize=13)

plt.show()

# In[None]

plt.figure(figsize=(16,7))

deg = ["relationship","marital.status"]

for i in range(2):
    plt.subplot(1,2,i+1)
    sns.countplot(x=deg[i],data=df,hue="income")
    plt.xlabel(deg[i],color="darkorange",fontsize=18)
    plt.ylabel("Count",color="darkorange",fontsize=18)
    plt.xticks(rotation=90,fontsize=15)
    plt.yticks(fontsize=15)

plt.show()    

# In[None]

plt.figure(figsize=(13,10))
sns.countplot(x=df["native.country"],data=df)
plt.xlabel("native.country",color="purple",fontsize=20)
plt.ylabel("Count",color="purple",fontsize=20)
plt.xticks(rotation=90,fontsize=15)
plt.yticks(fontsize=15)
plt.show()

# ## ## ##  # C# o# r# r# e# l# a# t# i# o# n#  # M# a# t# r# i# x#  # b# e# t# w# e# e# n#  # N# u# m# e# r# i# c# a# l#  # V# a# l# u# e# s

# In[None]

list=['age','education.num',"hours.per.week","fnlwgt"]

# In[None]

plt.figure(figsize=(12,7))
sns.heatmap(df[list].corr(),annot=True, fmt = ".2f", cmap = "YlGnBu")
plt.title("Correlation Matrix",color="darkblue",fontsize=20)
plt.show()

# ## ##  # 5# .#  # F# e# a# t# u# r# e#  # E# n# g# i# n# e# e# r# i# n# g

# In[None]

df["woman?"]  = df.sex.replace({"Female":1,"Male":0})
df["income_"] = df.income.replace({"<=50K":0,">50K":1})

# In[None]

df1 = pd.get_dummies(df['workclass'])
df2 = pd.get_dummies(df["education"])
df3 = pd.get_dummies(df["marital.status"])
df4 = pd.get_dummies(df["occupation"])
df5 = pd.get_dummies(df["relationship"])
df6 = pd.get_dummies(df["race"])
df7 = pd.get_dummies(df["native.country"])

df  = pd.concat([df,df1,df2,df3,df4,df5,df6,df7],axis=1)

# In[None]

df.head()

# ## ##  # 6# .# M# o# d# e# l# s

# ## ## ##  # I# m# b# a# l# a# n# c# e# d#  # D# a# t# a

# In[None]

plt.figure(figsize=(7,5))
sns.countplot(df["income_"])
plt.xlabel("İncome Case",fontsize=15)
plt.ylabel("Count",fontsize=15)
print(">50K  rate : %{:.2f}".format(sum(df["income_"])/len(df["income_"])*100))
print("<=50K rate : %{:.2f}".format((len(df["income_"])-sum(df["income_"]))/len(df["income_"])*100))

# _# _# %# 2# 4# .# 0# 8#  # o# f#  # t# h# e#  # d# a# t# a#  # i# n#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# s#  # c# l# a# s# s# i# f# i# e# d#  # a# s#  # p# o# s# i# t# i# v# e# .# T# h# e# r# e# f# o# r# e#  # w# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# s#  # n# o# t#  # b# a# l# a# n# c# e# d# .# _# _

# ## ## ##  # M# o# d# e# l#  # 1

# In[None]

y = df["income_"]
X = df[['age','hours.per.week',"fnlwgt",
       'woman?','Federal-gov', 'Local-gov',
       'Never-worked', 'Private', 'Self-emp-inc', 'Self-emp-not-inc',
       'State-gov', 'Without-pay', 'Federal-gov', 'Local-gov', 'Never-worked',
       'Private', 'Self-emp-inc','Self-emp-not-inc', 'State-gov', 'Without-pay', '10th', '11th',
       '12th', '1st-4th', '5th-6th', '7th-8th', '9th', 'Assoc-acdm',
       'Assoc-voc', 'Bachelors', 'Doctorate', 'HS-grad', 'Masters',
       'Preschool', 'Prof-school', 'Some-college', 'Adm-clerical',
       'Armed-Forces', 'Craft-repair', 'Exec-managerial', 'Farming-fishing',
       'Handlers-cleaners', 'Machine-op-inspct', 'Other-service',
       'Priv-house-serv', 'Prof-specialty', 'Protective-serv', 'Sales',
       'Tech-support', 'Transport-moving', 'Husband', 'Not-in-family',
       'Other-relative', 'Own-child', 'Unmarried', 'Wife',
       'Amer-Indian-Eskimo','Asian-Pac-Islander', 'Black', 'Other', 'White', 'Cambodia',
       'Canada', 'China', 'Columbia', 'Cuba', 'Dominican-Republic', 'Ecuador',
       'El-Salvador', 'England', 'France', 'Germany', 'Greece', 'Guatemala',
       'Haiti', 'Holand-Netherlands', 'Honduras', 'Hong', 'Hungary', 'India',
       'Iran', 'Ireland', 'Italy', 'Jamaica', 'Japan', 'Laos', 'Mexico',
       'Nicaragua', 'Outlying-US(Guam-USVI-etc)', 'Peru', 'Philippines',
       'Poland', 'Portugal', 'Puerto-Rico', 'Scotland', 'South', 'Taiwan',
       'Thailand', 'Trinadad&Tobago', 'United-States', 'Vietnam',
       'Yugoslavia']]

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6615639.npy", { "accuracy_score": score })

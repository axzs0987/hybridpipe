import pandas as pd
# In[77]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[38]

data = pd.read_csv('../input/voice.csv')

# In[29]

data.info()

# In[44]

#%%read csv
data = pd.read_csv('../input/voice.csv')
data = data.rename(columns = {"label": "gender"}) 
#data.drop(["Unnamed: 32","id"],axis=1,inplace = True) #droba gerek yok
data.gender =  [1 if each == "male" else 0 for each in data.gender]
y = data.gender.values
x_data = data.drop(["gender"],axis=1)
#data.gender

# In[45]

x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data)).values # normalize edildi

# In[52]

#train test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3930185.npy", { "accuracy_score": score })

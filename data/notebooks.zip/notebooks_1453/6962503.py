import pandas as pd
# ## ## ## ##  # F# E#  # -#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# v# b# m# o# k# i# n# /# f# e# a# t# u# r# e# -# i# m# p# o# r# t# a# n# c# e# -# x# g# b# -# l# g# b# m# -# l# o# g# r# e# g# -# l# i# n# r# e# g# 
# ## ## ## ##  # M# o# d# e# l#  # t# u# n# i# n# g#  # -#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# v# b# m# o# k# i# n# /# t# i# t# a# n# i# c# -# 0# -# 8# 3# 2# 5# 3# -# c# o# m# p# a# r# i# s# o# n# -# 2# 0# -# p# o# p# u# l# a# r# -# m# o# d# e# l# s

# ## ##  # 1# .#  # I# m# p# o# r# t# s

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import lightgbm as lgbm
import eli5
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn import preprocessing
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier

# ## ##  # 2# .#  # D# o# w# n# l# o# a# d#  # d# a# t# a# s# e# t

# In[None]

train_data = pd.read_csv('../input/weather-dataset-rattle-package/weatherAUS.csv')
test_data = pd.read_csv('../input/weather-dataset-rattle-package/weatherAUS.csv')

# In[None]

train_data.head()

# ## ##  # 3# .#  # P# r# e# p# a# r# i# n# g#  # t# o#  # a# n# a# l# y# s# i# s

# In[None]

mapping = {'Yes': 1, 'No': 0}

train_data = train_data.replace({'RainToday': mapping})
train_data = train_data.replace({'RainTomorrow': mapping})

test_data = test_data.replace({'RainToday': mapping})

# In[None]

# Drop useless coluns
cols_to_remove = ['Date', 'Location', 'RISK_MM'] 
train_data.drop(cols_to_remove, axis=1, inplace=True)

test_data.drop(['RainTomorrow'], axis=1, inplace=True)

# In[None]

train_data = train_data.dropna(how='any')
test_data = test_data.dropna(how='any')

# In[None]

numerics = ['int8', 'int16', 'int32', 'int64', 'float16', 'float32', 'float64']
categorical_columns = []
features = train_data.columns.values.tolist()
for col in features:
    if train_data[col].dtype in numerics: continue
    categorical_columns.append(col)
indexer = {}
for col in categorical_columns:
    if train_data[col].dtype in numerics: continue
    _, indexer[col] = pd.factorize(train_data[col])
    
for col in categorical_columns:
    if train_data[col].dtype in numerics: continue
    train_data[col] = indexer[col].get_indexer(train_data[col])

# In[None]

train_data.head()

# In[None]

train_data.info()

# In[None]

corr = train_data.corr()
fig = plt.figure(figsize=(15,10))
sns.heatmap(corr)

# In[None]

corr.sort_values(by=["RainTomorrow"],ascending=False).iloc[0].sort_values(ascending=False)

# In[None]

plt.figure(figsize=(8,8))
sns.FacetGrid(train_data, hue="RainTomorrow", size=8).map(sns.kdeplot, "Humidity3pm").add_legend()
plt.ioff() 
plt.show()

# In[None]

plt.figure(figsize=(8,8))
sns.countplot(data=train_data,x='RainToday')

# In[None]

plt.figure(figsize=(8,8))
sns.FacetGrid(train_data, hue="RainTomorrow", size=8).map(sns.kdeplot, "MinTemp").add_legend()
plt.ioff() 
plt.show()

# In[None]

plt.figure(figsize=(8,8))
sns.FacetGrid(train_data, hue="RainTomorrow", size=8).map(sns.kdeplot, "MaxTemp").add_legend()
plt.ioff() 
plt.show()

# In[None]

plt.figure(figsize=(8,8))
sns.countplot(data=train_data,x='WindGustDir')

# In[None]

plt.figure(figsize=(8,8))
sns.countplot(data=train_data,x='WindDir9am')

# In[None]

y = train_data['RainTomorrow']
del train_data['RainTomorrow']

X = train_data;

# In[None]

# data split
from sklearn.model_selection import train_test_split
X_train, X_valid, y_train, y_valid = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_valid)
score = accuracy_score(y_valid, y_pred)
import numpy as np
np.save("prenotebook_res/6962503.npy", { "accuracy_score": score })

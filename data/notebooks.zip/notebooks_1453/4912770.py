import pandas as pd
# <# h# r# /# ># 
# [# *# *# T# o# l# g# a# h# a# n#  # C# e# p# e# l# *# *# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# t# o# l# g# a# h# a# n# c# e# p# e# l# )# 
# <# h# r# /# ># 
# <# f# o# n# t#  # c# o# l# o# r# =# g# r# e# e# n# ># 
# 1# .#  # [# O# v# e# r# v# i# e# w# ]# (# ## 1# )# 
# 1# .#  # [# I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # R# e# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# ]# (# ## 2# )# 
# 1# .#  # [# D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n#  # a# n# d#  # P# r# e# p# r# o# c# e# s# s# i# n# g# ]# (# ## 3# )# 
# 1# .#  # [# C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # M# o# d# e# l# s# ]# (# ## 4# )#  # 
#  #  #  #  # *#  # [# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ]# (# ## 5# )#  # 
#  #  #  #  # *#  # [# K# -# N# e# a# r# e# s# t#  # N# e# i# g# h# b# o# r# s# (# K# -# N# N# )# ]# (# ## 6# )# 
#  #  #  #  # *#  # [# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # (# S# V# M#  # -#  # L# i# n# e# a# r# )# ]# (# ## 7# )# 
#  #  #  #  # *#  # [# S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # (# S# V# M#  # -#  # K# e# r# n# e# l# )# ]# (# ## 8# )# 
#  #  #  #  # *#  # [# N# a# i# v# e#  # B# a# y# e# s# ]# (# ## 9# )#  # 
#  #  #  #  # *#  # [# D# e# c# i# s# i# o# n#  # T# r# e# e#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## 1# 0# )#  # 
#  #  #  #  # *#  # [# R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# ]# (# ## 1# 1# )#  # 
# 1# .#  # [# M# e# a# s# u# r# i# n# g#  # t# h# e#  # E# r# r# o# r# ]# (# ## 1# 2# )# 
#  #  #  #  # *#  # [# V# i# s# u# a# l# i# z# i# n# g#  # M# o# d# e# l# s#  # P# e# r# f# o# r# m# a# n# c# e# ]# (# ## 1# 3# )#  # 
# 1# .#  # [# C# o# n# c# l# u# s# i# o# n# ]# (# ## 1# 4# )# 
# <# h# r# /# >

# ## ##  # <# s# p# a# n#  # i# d# =# "# 1# "# ># <# /# s# p# a# n# >#  # *# *#  # 1# .#  # O# v# e# r# v# i# e# w#  # *# *

# I# n# p# u# t#  # V# a# r# i# a# b# l# e# s# :# 
# -#  # *# *# f# i# x# e# d#  # a# c# i# d# i# t# y# :#  # *# *#  # m# o# s# t#  # a# c# i# d# s#  # i# n# v# o# l# v# e# d#  # w# i# t# h#  # w# i# n# e#  # o# r#  # f# i# x# e# d#  # o# r#  # n# o# n# v# o# l# a# t# i# l# e# 
# -#  # *# *# v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y# :#  # *# *#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # a# c# e# t# i# c#  # a# c# i# d#  # i# n#  # w# i# n# e# 
# -#  # *# *# c# i# t# r# i# c#  # a# c# i# d# :#  # *# *#  # f# o# u# n# d#  # i# n#  # s# m# a# l# l#  # q# u# a# n# t# i# t# i# e# s# ,#  # c# i# t# r# i# c#  # a# c# i# d#  # c# a# n#  # a# d# d#  # '# f# r# e# s# h# n# e# s# s# '#  # a# n# d#  # f# l# a# v# o# r#  # t# o#  # w# i# n# e# s#  # 
# -#  # *# *# r# e# s# i# d# u# a# l#  # s# u# g# a# r# :#  # *# *#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # s# u# g# a# r#  # r# e# m# a# i# n# i# n# g#  # a# f# t# e# r#  # f# e# r# m# e# n# t# a# t# i# o# n#  # s# t# o# p# s# 
# -#  # *# *# c# h# l# o# r# i# d# e# s# :#  # *# *#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # s# a# l# t#  # i# n#  # t# h# e#  # w# i# n# e# 
# -#  # *# *# f# r# e# e#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e# :#  # *# *#  # t# h# e#  # f# r# e# e#  # f# o# r# m#  # o# f#  # S# O# 2#  # e# x# i# s# t# s#  # i# n#  # e# q# u# i# l# i# b# r# i# u# m#  # b# e# t# w# e# e# n#  # m# o# l# e# c# u# l# a# r#  # S# O# 2#  # (# a# s#  # a#  # d# i# s# s# o# l# v# e# d#  # g# a# s# )#  # a# n# d#  # b# i# s# u# l# f# i# t# e#  # i# o# n# 
# -#  # *# *# t# o# t# a# l#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e# :#  # *# *#  # a# m# o# u# n# t#  # o# f#  # f# r# e# e#  # a# n# d#  # b# o# u# n# d#  # f# o# r# m# s#  # o# f#  # S# 0# 2# 
# -#  # *# *# d# e# n# s# i# t# y# :#  # *# *#  # t# h# e#  # d# e# n# s# i# t# y#  # o# f#  # w# a# t# e# r#  # i# s#  # c# l# o# s# e#  # t# o#  # t# h# a# t#  # o# f#  # w# a# t# e# r#  # d# e# p# e# n# d# i# n# g#  # o# n#  # t# h# e#  # p# e# r# c# e# n# t#  # a# l# c# o# h# o# l#  # a# n# d#  # s# u# g# a# r#  # c# o# n# t# e# n# t# 
# -#  # *# *# p# H# :#  # *# *#  # d# e# s# c# r# i# b# e# s#  # h# o# w#  # a# c# i# d# i# c#  # o# r#  # b# a# s# i# c#  # a#  # w# i# n# e#  # i# s#  # o# n#  # a#  # s# c# a# l# e#  # f# r# o# m#  # 0#  # (# v# e# r# y#  # a# c# i# d# i# c# )#  # t# o#  # 1# 4#  # (# v# e# r# y#  # b# a# s# i# c# )# 
# -#  # *# *# s# u# l# p# h# a# t# e# s# :#  # *# *#  # a#  # w# i# n# e#  # a# d# d# i# t# i# v# e#  # w# h# i# c# h#  # c# a# n#  # c# o# n# t# r# i# b# u# t# e#  # t# o#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e#  # g# a# s#  # (# S# 0# 2# )#  # l# e# v# e# l# s#  # 
# -#  # *# *# a# l# c# o# h# o# l# :#  # *# *#  # t# h# e#  # p# e# r# c# e# n# t#  # a# l# c# o# h# o# l#  # c# o# n# t# e# n# t#  # o# f#  # t# h# e#  # w# i# n# e# <# b# r# ># 
# 
# O# u# t# p# u# t#  # V# a# r# i# a# b# l# e# :# 
# -#  # *# *# q# u# a# l# i# t# y# :#  # *# *#  # o# u# t# p# u# t#  # v# a# r# i# a# b# l# e#  # (# b# a# s# e# d#  # o# n#  # s# e# n# s# o# r# y#  # d# a# t# a# ,#  # s# c# o# r# e#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# 0# )

# ## ##  # <# s# p# a# n#  # i# d# =# "# 2# "# ># <# /# s# p# a# n# >#  # *# *#  # 2# .#  # I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # R# e# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t#  # *# *

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from collections import Counter
from IPython.core.display import display, HTML
sns.set_style('darkgrid')

# In[None]

dataset = pd.read_csv('../input/winequality-red.csv')
dataset.head()

# ## ##  # <# s# p# a# n#  # i# d# =# "# 3# "# ># <# /# s# p# a# n# >#  # *# *#  # 3# .#  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n#  # a# n# d#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # *# *

# In[None]

dataset.isnull().sum()

# In[None]

bins = (2, 6.5, 8)
labels = ['bad', 'good']
dataset['quality'] = pd.cut(x = dataset['quality'], bins = bins, labels = labels)

# In[None]

dataset['quality'].value_counts()

# N# o# t#  # b# a# d# !#  # I#  # m# e# a# n#  # t# h# e#  # r# e# s# u# l# t#  # :# )

# In[None]

from sklearn.preprocessing import LabelEncoder
labelencoder_y = LabelEncoder()
dataset['quality'] = labelencoder_y.fit_transform(dataset['quality'])

# In[None]

dataset.head()

# In[None]

corr = dataset.corr()
#Plot figsize
fig, ax = plt.subplots(figsize=(10, 8))
#Generate Heat Map, allow annotations and place floats in map
sns.heatmap(corr, cmap='coolwarm', annot=True, fmt=".2f")
#Apply xticks
plt.xticks(range(len(corr.columns)), corr.columns);
#Apply yticks
plt.yticks(range(len(corr.columns)), corr.columns)
#show plot
plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['fixed acidity'], ax = axes[0])
axes[0].set_xlabel('Fixed Acidity', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'fixed acidity', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Fixed Acidity', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['volatile acidity'], ax = axes[0])
axes[0].set_xlabel('Volatile Acidity', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'volatile acidity', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Volatile Acidity', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['citric acid'], ax = axes[0])
axes[0].set_xlabel('Citric Acid', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.boxenplot(x = 'quality', y = 'citric acid', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Citric Acid', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['residual sugar'], ax = axes[0])
axes[0].set_xlabel('Residual Sugar', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'residual sugar', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Residual Sugar', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['chlorides'], ax = axes[0])
axes[0].set_xlabel('Chlorides', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'chlorides', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Chlorides', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(2,2,figsize=(14,8))

sns.distplot(dataset['free sulfur dioxide'], ax = axes[0,0])
axes[0,0].set_xlabel('Free Sulfur Dioxide', fontsize=14)
axes[0,0].set_ylabel('Count', fontsize=14)
axes[0,0].yaxis.tick_left()

sns.boxenplot(x = 'quality', y = 'free sulfur dioxide', data = dataset, hue = 'quality',ax = axes[0,1])
axes[0,1].set_xlabel('Quality', fontsize=14)
axes[0,1].set_ylabel('Free Sulfur Dioxide', fontsize=14)
axes[0,1].yaxis.set_label_position("right")
axes[0,1].yaxis.tick_right()

sns.distplot(dataset['total sulfur dioxide'], ax = axes[1,0])
axes[1,0].set_xlabel('Total Sulfur Dioxide', fontsize=14)
axes[1,0].set_ylabel('Count', fontsize=14)
axes[1,0].yaxis.tick_left()

sns.boxenplot(x = 'quality', y = 'total sulfur dioxide', data = dataset, hue = 'quality',ax = axes[1,1])
axes[1,1].set_xlabel('Quality', fontsize=14)
axes[1,1].set_ylabel('Total Sulfur Dioxide', fontsize=14)
axes[1,1].yaxis.set_label_position("right")
axes[1,1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['density'], ax = axes[0])
axes[0].set_xlabel('Density', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'density', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Density', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['pH'], ax = axes[0])
axes[0].set_xlabel('pH', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'pH', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('pH', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['sulphates'], ax = axes[0])
axes[0].set_xlabel('Sulphates', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'sulphates', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Sulphates', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

f, axes = plt.subplots(1,2,figsize=(14,4))

sns.distplot(dataset['alcohol'], ax = axes[0])
axes[0].set_xlabel('Alcohol', fontsize=14)
axes[0].set_ylabel('Count', fontsize=14)
axes[0].yaxis.tick_left()

sns.violinplot(x = 'quality', y = 'alcohol', data = dataset, hue = 'quality',ax = axes[1])
axes[1].set_xlabel('Quality', fontsize=14)
axes[1].set_ylabel('Alcohol', fontsize=14)
axes[1].yaxis.set_label_position("right")
axes[1].yaxis.tick_right()

plt.show()

# In[None]

dataset['quality'].value_counts()

# In[None]

X = dataset.drop('quality', axis = 1).values
y = dataset['quality'].values.reshape(-1,1)

# In[None]

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4912770.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

df = pd.read_csv('/kaggle/input/logistic-regression/Social_Network_Ads.csv')
print(df.shape)
print('-'*40)
print(df.info())
print('-'*40)
print(df.describe())
print('-'*40)
print(df.isnull().sum())



# In[None]

df.head()

# In[None]

from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
df['Gender'] = encoder.fit_transform(df['Gender'])

# 0#  # =#  # F# e# m# a# l# e# ,# 
# 1#  # =#  # M# a# l# e

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = (20, 10)
sns.heatmap(df.corr(), annot=True)
plt.title('Data Correlation')

# A# g# e#  # a# n# d#  # E# s# t# i# m# a# t# e# d# S# a# l# a# r# y#  # i# s#  # h# a# v# e#  # h# i# g# h#  # c# o# r# e# l# l# a# t# i# o# n#  # w# i# t# h#  # P# u# r# c# a# s# h# e# d

# In[None]

g = sns.FacetGrid(df, col='Purchased')
g.map(plt.hist, 'Age')

# In[None]

X = df.iloc[:, [2,3]].values
y = df.iloc[:, -1].values

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10355365.npy", { "accuracy_score": score })

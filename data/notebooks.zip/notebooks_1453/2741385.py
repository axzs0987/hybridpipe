import pandas as pd
# *# *# >#  # C# U# S# T# O# M# E# R#  # C# H# U# R# N# *# *# 
# 
# T# h# i# s#  # c# a# s# e#  # i# s#  # f# o# r#  # p# r# e# d# i# c# t# i# n# g#  # c# h# u# r# n#  # b# e# h# a# v# i# o# r#  # o# f#  # c# u# s# t# o# m# e# r# s# .

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

import os
#print(os.listdir("../input"))



# F# i# r# s# t# ,#  # w# e#  # n# e# e# d#  # t# o#  # u# p# l# o# a# d#  # t# h# e#  # d# a# t# a# .

# In[None]

data = pd.read_csv(r"../input/WA_Fn-UseC_-Telco-Customer-Churn.csv")
#first few rows
data.head()

# *# *# D# a# t# a#  # M# a# n# i# p# u# l# a# t# i# o# n# *# *

# In[None]

# Uploading the packages we need:
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
data.head()
data.describe()



# In[None]

# Take a look at Tenure dimension using distibution, dimensions can be changed.
sns.distplot(data['tenure'])

# In[None]

# Correlation check
data.corr()
sns.heatmap(data.corr(),cmap='BuGn')


# In[None]

# Excluding the ID column, it won't be useful.
data = data.drop(['customerID'], axis= 1)
data.head()

# In[None]

# Converting categorical data to numeric 
char_cols = data.dtypes.pipe(lambda x: x[x == 'object']).index
for c in char_cols:
    data[c] = pd.factorize(data[c])[0]
data.head()

# In[None]

# Define the target variable (dependent variable) 
y = data.Churn 
data = data.drop(['Churn'], axis= 1)

# *# *# M# o# d# e# l# l# i# n# g# *# *

# In[None]

# Splitting training and testing data
from sklearn.model_selection import train_test_split  
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(data, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2741385.npy", { "accuracy_score": score })

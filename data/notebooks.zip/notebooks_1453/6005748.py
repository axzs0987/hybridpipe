import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv('/kaggle/input/international-football-results-from-1872-to-2017/results.csv')

# In[None]

data

# In[None]

from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
data["neutral"] = le.fit_transform(data["neutral"])
data["neutral"] = data["neutral"].astype("category") 

data["country"] = le.fit_transform(data["country"])
data["country"] = data["country"].astype("category") 

data["city"] = le.fit_transform(data["city"])
data["city"] = data["city"].astype("category") 

data["tournament"] = le.fit_transform(data["tournament"])
data["tournament"] = data["tournament"].astype("category") 

data["away_team"] = le.fit_transform(data["away_team"])
data["away_team"] = data["away_team"].astype("category") 

data["home_team"] = le.fit_transform(data["home_team"])
data["home_team"] = data["home_team"].astype("category") 

data["date"] = le.fit_transform(data["date"])
data["date"] = data["date"].astype("category") 

# In[None]

data

# In[None]

y = data["neutral"]
x = data.values[: ,0:8]

# In[None]

print(data.shape)
print(x.shape)


# In[None]

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import confusion_matrix

from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/6005748.npy", { "accuracy_score": score })

import pandas as pd
# T# e# a# m#  # M# e# m# b# e# r# s# 
# 
# S# u# m# a# n# t#  # P# a# t# i# l# :#  # 0# 1# F# B# 1# 6# E# C# S# 4# 0# 1# 
# 
# S# h# r# i# j# e# e# t#  # P# a# i# :#  # 0# 1# F# B# 1# 6# E# C# S# 3# 7# 5

# In[None]


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

import os
#print(os.listdir("../input"))
df = pd.read_csv('../input/Absenteeism_at_work.csv', delimiter=',')
features = df.iloc[:, 1:14].values
target = df.iloc[:, 14].values


# In[None]

df.head()

# In[None]

df.isnull().sum()

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1900541.npy", { "accuracy_score": score })

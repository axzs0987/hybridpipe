import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from sklearn import metrics
from sklearn.preprocessing import OneHotEncoder 
from sklearn.svm import LinearSVC
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import cross_val_predict
from sklearn import preprocessing

from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier ,AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn import tree
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[None]

st = pd.read_csv("../input/xAPI-Edu-Data.csv")

# In[None]

st.Class =st.Class.astype('category')
class_order = {'H':3, 'M':2, 'L':1}
st.Class =st.Class.map(class_order)

# L# 1# -# b# a# s# e# d#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n# ¶# 
# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# -# 
# 
# L# i# n# e# a# r#  # m# o# d# e# l# s#  # p# e# n# a# l# i# z# e# d#  # w# i# t# h#  # t# h# e#  # L# 1#  # n# o# r# m#  # h# a# v# e#  # s# p# a# r# s# e#  # s# o# l# u# t# i# o# n# s# :#  # m# a# n# y#  # o# f#  # t# h# e# i# r#  # e# s# t# i# m# a# t# e# d#  # c# o# e# f# f# i# c# i# e# n# t# s#  # a# r# e#  # z# e# r# o# .#  # W# h# e# n#  # t# h# e#  # g# o# a# l#  # i# s#  # t# o#  # r# e# d# u# c# e#  # t# h# e#  # d# i# m# e# n# s# i# o# n# a# l# i# t# y#  # o# f#  # t# h# e#  # d# a# t# a#  # t# o#  # u# s# e#  # w# i# t# h#  # a# n# o# t# h# e# r#  # c# l# a# s# s# i# f# i# e# r# ,#  # t# h# e# y#  # c# a# n#  # b# e#  # u# s# e# d#  # a# l# o# n# g#  # w# i# t# h#  # f# e# a# t# u# r# e# _# s# e# l# e# c# t# i# o# n# .# S# e# l# e# c# t# F# r# o# m# M# o# d# e# l#  # t# o#  # s# e# l# e# c# t#  # t# h# e#  # n# o# n# -# z# e# r# o#  # c# o# e# f# f# i# c# i# e# n# t# s# .#  # I# n#  # p# a# r# t# i# c# u# l# a# r# ,#  # s# p# a# r# s# e#  # e# s# t# i# m# a# t# o# r# s#  # u# s# e# f# u# l#  # f# o# r#  # t# h# i# s#  # p# u# r# p# o# s# e#  # a# r# e#  # t# h# e#  # l# i# n# e# a# r# _# m# o# d# e# l# .# L# a# s# s# o#  # f# o# r#  # r# e# g# r# e# s# s# i# o# n# ,#  # a# n# d#  # o# f#  # l# i# n# e# a# r# _# m# o# d# e# l# .# L# o# g# i# s# t# i# c# R# e# g# r# e# s# s# i# o# n#  # a# n# d#  # s# v# m# .# L# i# n# e# a# r# S# V# C#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# :#  # W# i# t# h#  # S# V# M# s#  # a# n# d#  # l# o# g# i# s# t# i# c# -# r# e# g# r# e# s# s# i# o# n# ,#  # t# h# e#  # p# a# r# a# m# e# t# e# r#  # C#  # c# o# n# t# r# o# l# s#  # t# h# e#  # s# p# a# r# s# i# t# y# :#  # t# h# e#  # s# m# a# l# l# e# r#  # C#  # t# h# e#  # f# e# w# e# r#  # f# e# a# t# u# r# e# s#  # s# e# l# e# c# t# e# d# .#  # W# i# t# h#  # L# a# s# s# o# ,#  # t# h# e#  # h# i# g# h# e# r#  # t# h# e#  # a# l# p# h# a#  # p# a# r# a# m# e# t# e# r# ,#  # t# h# e#  # f# e# w# e# r#  # f# e# a# t# u# r# e# s#  # s# e# l# e# c# t# e# d# .

# In[None]

def Feature_Selector(data):
    
    st1 =data.drop('Class',axis=1)
    st2= data['Class']
    st1 = pd.get_dummies(st1)
    st1 = pd.DataFrame(preprocessing.scale(st1) ,columns=st1.columns )
    st1_columns = st1.columns
    lsvc = LinearSVC(C=0.01, penalty="l1", dual=False).fit(st1, st2)
    selector =  SelectFromModel(lsvc, prefit=True)
    selector.transform(st1)
    labels = [st1_columns[x] for x in selector.get_support(indices=True)]
    st1 = pd.DataFrame(selector.transform(st1),columns=labels)
    data = pd.concat([st1,st2],axis=1)
    return data

# In[None]

red =Feature_Selector(st)
red.head()

# ## ##  # W# i# t# h#  # R# e# d# u# c# e# d#  # F# e# a# t# u# r# e# s#  # ## #

# In[None]

X, y = red.drop('Class',axis=1) , red.Class
#Split the data into train and test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/184296.npy", { "accuracy_score": score })

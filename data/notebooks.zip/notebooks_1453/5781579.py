import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ##  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# In[None]

data = pd.read_csv('../input/weather-dataset-rattle-package/weatherAUS.csv')

data.tail()

# In[None]

data.isnull().sum()

# In[None]

data.drop(['Date', 'Location', 'WindGustDir', 'WindDir9am', 'WindDir3pm'], axis=1, inplace=True)


for i in range(0, len(data.columns)):
    if i==16 or i==18:
        continue  # Çünkü raintoday ve raintomorrow column'ları yes ve no'dan oluşuyor.
    
    mean = data.iloc[:, i].mean()
    
    data.iloc[:, i] = [mean if str(each)=='nan' else each for each in data.iloc[:, i]]  # Boş data'lara, aynı column'daki diğer data'ların ortalama değerini ekledim.

    
data.RainToday = [1 if each=='Yes' else 0 for each in data.RainToday]
data.RainTomorrow = [1 if each=='Yes' else 0 for each in data.RainTomorrow]


data.isnull().sum()  # you can see alteration

# ##  # K# N# N#  # w# i# t# h#  # s# k# l# e# a# r# n

# In[None]

y = data.RainTomorrow.values
x_head = data.drop('RainTomorrow', axis=1).values

# In[None]

#normalize
x = (x_head - np.min(x_head)) / (np.max(x_head) - np.min(x_head))

# In[None]

#split
from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5781579.npy", { "accuracy_score": score })

import pandas as pd
# In[1]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns 

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# İ# m# p# o# r# t#  # l# i# b# r# a# r# y

# In[3]

df=pd.read_csv('../input/pulsar_stars.csv')

# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# In[4]

# look first five data 
df.head()

# In[5]

df.info()

# In[6]

# summary statistic data 
df.describe()

# In[7]

df.target_class.value_counts()
sns.countplot(df.target_class)
plt.show()

# In[8]

# pair plot 
sns.pairplot(data=df,
             diag_kind="kde", 
             markers=".",
             plot_kws=dict(s=50, edgecolor="b", linewidth=1),
             hue="target_class",
             vars=[" Mean of the integrated profile",
                   " Excess kurtosis of the integrated profile",
                   " Skewness of the integrated profile",
                   " Mean of the DM-SNR curve",
                   " Excess kurtosis of the DM-SNR curve",
                   " Skewness of the DM-SNR curve"],
                   diag_kws=dict(shade=True))

plt.tight_layout()
plt.show() 

# In[9]

# heatmap 
df.corr()
sns.heatmap(df.corr(),cmap="YlGnBu",linewidths=.5)
plt.title('Corelation Heatmap')
plt.show()

# In[10]

f,ax = plt.subplots(figsize=(18, 18))
sns.heatmap(df.corr(), annot=True, linewidths=.5, cmap="YlGnBu",fmt= '.1f',ax=ax)
plt.title('Corelation Map')
plt.show()

# In[11]

# violinplot
# data normalization
df_nor=(df - np.min(df))/(np.max(df)-np.min(df))

sns.violinplot(data=df,y=" Mean of the integrated profile",x="target_class")
plt.show()

sns.violinplot(data=df,y=" Mean of the DM-SNR curve",x="target_class")
plt.show()

# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n

# In[13]

#Set x and y values
y=df.target_class.values
x_df=df.drop(['target_class'],axis=1)
#normalization
x=(x_df-np.min(x_df))/(np.max(x_df)-np.min(x_df))

# In[14]

# train/test
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3964833.npy", { "accuracy_score": score })

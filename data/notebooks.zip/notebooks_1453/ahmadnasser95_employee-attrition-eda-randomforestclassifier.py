import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('../input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv')
df.head()
df.describe().transpose()
df.isnull().sum()
df.info()
df['Attrition'].unique()
df['Attrition'].replace(to_replace = dict(Yes = 1, No = 0), inplace = True)
categorical_cols = []
for col, value in df.iteritems():
    if value.dtype == 'object':
        categorical_cols.append(col)
df_cat = df[categorical_cols]
df_cat.head()
for column in categorical_cols:
    print(f"{column} : {df[column].unique()}")
    print("-"*40)
from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()
for column in categorical_cols:
    df[column] = label.fit_transform(df[column])
df.head()
df.hist(figsize=(20, 20));
#plt.figure(figsize=(20,20))
#plt.subplot(421)
#sns.countplot(x='Age',data=df,hue='Attrition')
#plt.subplot(422)
#sns.countplot(x='OverTime', data=df, hue='Attrition')
#plt.subplot(423)
#sns.countplot(x='MaritalStatus', data=df, hue='Attrition')
#plt.subplot(424)
#sns.countplot(x='JobRole', data=df, hue='Attrition')
#plt.subplot(425)
#sns.countplot(x='JobLevel', data=df, hue='Attrition')
#plt.subplot(426)
#sns.countplot(x='JobSatisfaction', data=df, hue='Attrition')
#plt.subplot(427)
#sns.countplot(x='TotalWorkingYears', data=df, hue='Attrition')
#plt.subplot(428)
#sns.countplot(x='WorkLifeBalance', data=df, hue='Attrition')
#plt.show()
df.drop(['StandardHours','Over18','EmployeeCount','EmployeeNumber'],axis=1,inplace=True)
#plt.figure(figsize=(25,25))
#sns.heatmap(df.corr(),annot=True,cmap='coolwarm')
df_final = df.drop('Attrition',axis=1)
y = df['Attrition']
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
X = scaler.fit_transform(df_final)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=71)
from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=1000)
#rfc.fit(X_train,y_train)
#predictions = rfc.predict(X_test)
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
print('classification report: ')
print('='*40)
#print(classification_report(y_test,predictions))
print('\n')
print('confusion matrix: ')
print('='*40)
#print(confusion_matrix(y_test,predictions))
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
sm = SMOTE(random_state=71)
X_train, y_train = sm.fit_sample(X_train, y_train)
rfc = RandomForestClassifier(n_estimators=1000)
#rfc.fit(X_train,y_train)
#predictions = rfc.predict(X_test)
print('classification report: ')
print('='*40)
#print(classification_report(y_test,predictions))
print('\n')
print('confusion matrix: ')
print('='*40)
#print(confusion_matrix(y_test,predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ahmadnasser95_employee-attrition-eda-randomforestclassifier.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ahmadnasser95_employee-attrition-eda-randomforestclassifier/testY.csv",encoding="gbk")


import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
import seaborn as sns
import matplotlib.pyplot as plt
df= pd.read_csv("../input/heart.csv")
df.head()
df.info()
#sns.countplot(df['sex'])
#sns.countplot(df['target'], hue=df['sex'])
#sns.violinplot(x='target', y='age', data=df, hue='sex', split=True)
#sns.boxplot(x='target', y='age', data=df)
#sns.distplot(df[df['target'] == 0]['age'])
#sns.distplot(df[df['target'] == 1]['age'],color='red')
X = df.drop('target', axis=1)
y = df['target']
category_cols = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal']
X = pd.get_dummies(X, columns=category_cols, drop_first=True)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
y_test.value_counts()
from sklearn.tree import DecisionTreeClassifier
tree = DecisionTreeClassifier()
#tree.fit(X_train, y_train)
from sklearn.metrics import classification_report
#test_predictions = tree.predict(X_test)
#train_predictions = tree.predict(X_train)
print("TRAIN:")
#print(classification_report(y_train, train_predictions))
print("TEST:")
#print(classification_report(y_test, test_predictions))
#feature_importance = pd.Series(data=tree.feature_importances_, index=X_train.columns)
#feature_importance.sort_values(ascending=False)
from sklearn.ensemble import RandomForestClassifier
rf_clf = RandomForestClassifier(n_estimators=50)
#rf_clf.fit(X_train, y_train)
#test_predictions = rf_clf.predict(X_test)
#train_predictions = rf_clf.predict(X_train)
print("TRAIN:")
#print(classification_report(y_train, train_predictions))
print("TEST:")
#print(classification_report(y_test, test_predictions))
rf_clf = RandomForestClassifier(n_estimators=100, max_depth=5)
#rf_clf.fit(X_train, y_train)
#test_predictions = rf_clf.predict(X_test)
#train_predictions = rf_clf.predict(X_train)
print("TRAIN:")
#print(classification_report(y_train, train_predictions))
print("TEST:")
#print(classification_report(y_test, test_predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/annatshngryan_decision-tree-and-random-forest.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_decision-tree-and-random-forest/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/annatshngryan_decision-tree-and-random-forest/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/annatshngryan_decision-tree-and-random-forest/testY.csv",encoding="gbk")


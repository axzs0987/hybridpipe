import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
df=pd.read_csv('../input/loan-prediction-problem-dataset/train_u6lujuX_CVtuZ9i.csv')
df.head()
df.info()
df.isnull().sum()
df.fillna(df.mean(),inplace=True)
df.isnull().sum()
df.dropna(how='any',inplace=True)
df.info()
df.head()
df=df.drop(['Loan_ID'],axis=1)
a=df.select_dtypes('object').columns[:-1]
a
df1=pd.DataFrame()
for i in a:
    df2=pd.get_dummies(df[i],drop_first=True)
    df1=pd.concat([df2,df1],axis=1)
    df=df.drop(i,axis=1)
df=pd.concat([df1,df],axis=1)
df.head()
df.info()
x=df.iloc[:,:-1]
y=df.iloc[:,-1]
x.head()
y.head()
from sklearn.model_selection import train_test_split
x = x.loc[:,~x.columns.duplicated()]
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
model=LogisticRegression()
#model.fit(x_train,y_train)
#y_pred=model.predict(x_test)
#print(confusion_matrix(y_test, y_pred))
#print(accuracy_score(y_test, y_pred))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aadityajaiswal_loan-prediction-project.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/aadityajaiswal_loan-prediction-project/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/aadityajaiswal_loan-prediction-project/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aadityajaiswal_loan-prediction-project/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aadityajaiswal_loan-prediction-project/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aadityajaiswal_loan-prediction-project/testY.csv",encoding="gbk")


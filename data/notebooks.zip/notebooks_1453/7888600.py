import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, cross_val_predict
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix


# In[None]

df=pd.read_csv('/kaggle/input/indian-liver-patient-records/indian_liver_patient.csv')
df.head()

# In[None]

df['Gender']=df['Gender'].apply(lambda x:1 if x=='Male' else 0)#Convert categorical to numerical


# In[None]

df.isnull().sum()

# In[None]

df['Albumin_and_Globulin_Ratio'].mean()

# In[None]

df=df.fillna(.94)

# In[None]

df.isnull().sum()

# In[None]

#Let us compare the albumin and albumin and globulin ratio by a scatterplot.
f, ax = plt.subplots(figsize=(8, 6))
sns.scatterplot(x="Albumin", y="Albumin_and_Globulin_Ratio",color='mediumspringgreen',data=df)
plt.show()

# In[None]

#Let us compare the Gender based on the Protein Intake.
plt.figure(figsize=(8,6))
df.groupby('Gender').sum()["Total_Protiens"].plot.bar(color='coral')

# In[None]

#Let us compare male and female based on Albumin Level.

plt.figure(figsize=(8,6))
df.groupby('Gender').sum()['Albumin'].plot.bar(color='midnightblue')

# In[None]

#Albumin Level is higher in the case in the case of male compared to female.
#Finally Let us compare them based on the Bilirubin content.
plt.figure(figsize=(8,6))
df.groupby('Gender').sum()['Total_Bilirubin'].plot.bar(color='fuchsia')

# In[None]

#We can clearly see that males has more bilirubin content compared to females.
#Another point to be noted here is that higher the Bilirubin content, higher the case is prone to Liver disease.
#Train the model
X=df.drop('Dataset',axis=1)
X = StandardScaler().fit_transform(X)
y = df['Dataset']


# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7888600.npy", { "accuracy_score": score })

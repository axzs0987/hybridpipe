import pandas as pd
# ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# T# h# i# s#  # a# n# a# l# y# s# i# s#  # e# x# p# l# o# r# e# s#  # t# h# e#  # w# o# r# l# d#  # o# f#  # S# t# a# r# c# r# a# f# t#  # 2# ,#  # a# n#  # o# n# l# i# n# e#  # m# a# s# s# i# v# e#  # m# u# l# t# i# p# l# a# y# e# r#  # P# C#  # b# a# s# e# d#  # g# a# m# e#  # p# r# o# d# u# c# e# d#  # b# y#  # B# l# i# z# z# a# r# d#  # E# n# t# e# r# t# a# i# n# m# e# n# t# .#  #  # T# h# e#  # s# p# e# c# i# f# i# c#  # p# u# r# p# o# s# e#  # o# f#  # t# h# i# s#  # n# o# t# e# b# o# o# k#  # i# s#  # t# o#  # c# r# e# a# t# e#  # m# o# d# e# l# s#  # t# h# a# t#  # p# r# e# d# i# c# t#  # L# e# a# g# u# e#  # I# n# d# e# x#  #  # (# m# o# d# e# l#  # t# a# r# g# e# t# )#  # b# a# s# e# d#  # o# f# f#  # c# e# r# t# a# i# n#  # p# l# a# y# e# r#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # (# p# o# t# e# n# t# i# a# l#  # m# o# d# e# l#  # f# e# a# t# u# r# e# s# )# .#  #  #  # I# t#  # o# p# e# n# s#  # w# i# t# h#  # a#  # d# a# t# a#  # d# i# v# e#  # f# o# r#  # g# e# n# e# r# a# l#  # e# x# p# l# o# r# a# t# i# o# n# ,#  # p# o# i# n# t# s#  # o# u# t#  # s# o# m# e#  # h# i# g# h#  # l# e# v# e# l#  # o# b# s# e# r# v# a# t# i# o# n# s#  # a# n# d#  # c# o# n# c# e# r# n# s# ,#  # a# n# d#  # w# o# r# k# s#  # u# p#  # t# o#  # c# r# e# a# t# i# n# g#  # a# n# d#  # e# v# a# l# u# a# t# i# n# g#  # v# a# r# i# o# u# s#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# s# .# 
# 
# *# *# A# d# d# i# t# i# o# n# a# l#  # C# o# m# m# e# n# t# s# *# *#  #  # 
#  # -#  # T# h# a# n# k# s#  # t# o#  # *# S# i# m# o# n#  # F# r# a# s# e# r#  # U# n# i# v# e# r# s# i# t# y#  # -#  # S# u# m# m# i# t# *#  # f# o# r#  # p# r# o# v# i# d# i# n# g#  # t# h# i# s#  # d# a# t# a#  # s# e# t#  #  # 
#  # -#  # T# h# i# s#  # i# s#  # a#  # w# o# r# k#  # i# n#  # p# r# o# g# r# e# s# s#  # p# r# i# m# a# r# i# l# y#  # u# s# e# d#  # t# o#  # h# e# l# p#  # s# h# a# r# e#  # P# y# t# h# o# n#  # k# n# o# w# l# e# d# g# e#  # w# i# t# h#  # a#  # s# m# a# l# l#  # g# r# o# u# p# ,#  # s# o#  # p# l# e# a# s# e#  # e# x# c# u# s# e#  # t# h# e#  # p# e# d# a# g# o# g# i# c# a# l#  # t# o# n# e#  # a# n# d#  # m# u# l# t# i# p# l# e#  # p# u# b# l# i# s# h# e# d#  # u# p# d# a# t# e# s#  # a# s#  # I#  # c# o# n# t# i# n# u# e#  # t# o#  # w# o# r# k#  # i# n#  # c# l# e# a# r# e# r#  # e# x# p# l# a# n# a# t# i# o# n# s# .#  #  # 
#  # -#  # P# l# e# a# s# e#  # f# e# e# l#  # f# r# e# e#  # t# o#  # c# o# m# m# e# n# t#  # (# e# v# e# n#  # o# n#  # s# n# o# o# t# y#  # w# o# r# d#  # c# h# o# i# c# e# s#  # l# i# k# e#  # p# e# d# a# g# o# g# i# c# a# l# )# ,#  # p# o# i# n# t#  # o# u# t#  # a# n# y#  # g# o# o# f# s# ,#  # a# n# d#  # /#  # o# r#  # i# d# e# a# s# !

# ## ##  # D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n#  # a# n# d#  # A# n# a# l# y# s# i# s

# In[None]

# Import packages
import numpy as np
import pandas as pd
from pandas import DataFrame
import matplotlib.pyplot as plt
import seaborn as sns
from subprocess import check_output
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import train_test_split # Deprecated
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
print(check_output(["ls", "../input"]).decode("utf8"))

# In[None]

# Import dataset and see what type of data we're working with
df_raw = pd.read_csv('../input/starcraft.csv',sep=',')
df_raw.info()

# *# *# L# o# t# s#  # o# f#  # f# l# o# a# t# s#  # a# n# d#  # i# n# t# e# g# e# r# s#  # a# c# r# o# s# s#  # 3# .# 4# k#  # r# o# w# s#  # o# f#  # d# a# t# a# .#  #  # 2#  # q# u# i# c# k#  # t# a# k# e# a# w# a# y# s#  # h# e# r# e# :# *# *# 
# 
#  # -#  # R# e# q# u# i# r# e# d#  # m# e# m# o# r# y#  # t# o#  # a# n# a# l# y# z# e#  # t# h# i# s#  # d# a# t# a#  # s# h# o# u# l# d#  # b# e#  # a#  # n# o# n# -# i# s# s# u# e# 
#  # -#  # T# h# e#  # e# n# t# i# r# e# l# y#  # n# u# m# e# r# i# c#  # b# a# s# e# d#  # d# a# t# a#  # t# y# p# e# s#  # s# h# o# u# l# d#  # m# a# k# e#  # f# o# r#  # a# n#  # e# a# s# y#  # l# o# o# k#  # i# n# t# o#  # t# h# e#  # d# a# t# a#  # w# i# t# h# o# u# t#  # t# o# o#  # m# u# c# h#  # c# l# e# a# n# i# n# g# ,#  # b# u# t#  # l# e# t# '# s#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # t# h# e#  # s# o# m# e#  # o# f#  # t# h# e#  # d# a# t# a#  # a# n# d#  # t# h# e#  # s# p# r# e# a# d#  # w# i# t# h# i# n#  # e# a# c# h#  # a# t# t# r# i# b# u# t# e

# In[None]

# First 5 rows of data
df_raw.head()

# ## ## ## ## A#  # p# r# e# v# i# o# u# s#  # l# o# o# k#  # a# t#  # t# h# i# s#  # d# a# t# a#  # s# h# o# w# e# d#  # s# o# m# e#  # i# n# v# a# l# i# d#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # r# a# w#  # d# a# t# a# ,#  # w# h# i# c# h#  # w# e# r# e#  # a# t# t# r# i# b# u# t# e# d#  # t# o#  # N# a# N#  # v# a# l# u# e# s# .#  #  # H# e# r# e#  # w# e#  # d# r# o# p#  # t# h# o# s# e#  # N# a# N# s#  # a# n# d#  # s# e# e#  # h# o# w#  # m# a# n# y#  # r# o# w# s#  # w# e# r# e#  # a# f# f# e# c# t# e# d# .

# In[None]

df = df_raw.dropna()
df = df[df['LeagueIndex']!=8]

# Number of rows with incomplete data and / or with LeagueIndex value of 8
print("Number of incomplete data rows dropped: " + str(len(df_raw) - len(df)))
print("Remaining records = " + str(len(df)))

# ## ## ## ## L# o# s# i# n# g#  # 5# 7#  # r# o# w# s#  # o# n#  # a# c# c# o# u# n# t#  # o# f#  # i# n# c# o# m# p# l# e# t# e#  # d# a# t# a#  # w# h# e# n#  # w# e#  # s# t# a# r# t# e# d#  # w# i# t# h#  # 3# .# 4# k#  # r# o# w# s#  # w# o# r# k# s#  # f# o# r#  # m# e# .#  #  # N# o# w#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# s#  # "# c# l# e# a# n# "#  # l# e# t# s#  # t# a# k# e#  # l# o# o# k#  # a# t#  # t# h# e#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e#  # t# h# a# t#  # o# u# r#  # m# o# d# e# l# s#  # w# i# l# l#  # p# r# e# d# i# c# t# ,#  # L# e# a# g# u# e#  # I# n# d# e# x# .

# -# -# -# -# -# -# -# -# -# -

# ## ## ##  # L# e# a# g# u# e#  # I# n# d# e# x#  # P# l# a# y# e# r#  # D# i# s# t# r# i# b# u# t# i# o# n#  # (# D# e# p# e# n# d# e# n# t#  # V# a# r# i# a# b# l# e# )# 
# ## ## ## ## H# o# w#  # a# r# e#  # p# l# a# y# e# r# s#  # d# i# s# t# r# i# b# u# t# e# d#  # a# c# r# o# s# s#  # t# h# e#  # 7#  # S# C# 2#  # l# e# a# g# u# e# s# ?#  #  # A#  # c# u# r# s# o# r# y#  # l# o# o# k#  # b# e# l# o# w# .

# In[None]

# Select Style
plt.style.use('fivethirtyeight')

# Create Figure
fig, ax = plt.subplots(1,2, figsize = (14,8))
fig.suptitle('Starcraft 2 League Player Distribution', fontweight='bold', fontsize = 22)

# Specify histogram attributes
bins = np.arange(0, 9, 1)
weights = np.ones_like(df['LeagueIndex']) / len(df['LeagueIndex'])

# Count Histogram
p1 = plt.subplot(1,2,1)
p1.hist(df['LeagueIndex'], bins=bins, align='left') # Pure Count
plt.xlabel('League Index', fontweight='bold')
plt.title('Count')

# Percentage Histogram
p2 = plt.subplot(1,2,2)
p2.hist(df['LeagueIndex'], bins=bins, weights = weights, align='left') # % of Total (weights)
plt.xlabel('League Index', fontweight='bold')
plt.title('Percentage', )
yvals = plt.subplot(1,2,2).get_yticks()
plt.subplot(1,2,2).set_yticklabels(['{:3.1f}%'.format(y*100) for y in yvals])

plt.show()

# ## ## ## ## *# *# H# i# s# t# o# g# r# a# m#  # C# o# m# m# e# n# t# s# *# *# 
# T# h# e#  # L# e# a# g# u# e#  # D# e# s# c# r# i# p# t# i# o# n# s#  # o# v# e# r# v# i# e# w#  # d# e# t# a# i# l# e# d#  # h# e# r# e# ,#  # '# h# t# t# p# :# /# /# w# i# k# i# .# t# e# a# m# l# i# q# u# i# d# .# n# e# t# /# s# t# a# r# c# r# a# f# t# 2# /# B# a# t# t# l# e# .# n# e# t# _# L# e# a# g# u# e# s# '# ,#  # s# a# y# s# :#  #  # 
#  # 
# *# "# P# l# a# y# e# r# s#  # a# r# e#  # p# l# a# c# e# d#  # i# n#  # a#  # l# e# a# g# u# e#  # a# f# t# e# r#  # h# a# v# i# n# g#  # c# o# m# p# l# e# t# e# d#  # 5#  # p# l# a# c# e# m# e# n# t#  # m# a# t# c# h# e# s# .#  # A# f# t# e# r#  # t# h# a# t# ,#  # a#  # p# l# a# y# e# r#  # m# a# y#  # g# e# t#  # m# o# v# e# d#  # t# o#  # a# n# o# t# h# e# r#  # l# e# a# g# u# e# ,#  # d# e# p# e# n# d# i# n# g#  # o# n#  # p# e# r# f# o# r# m# a# n# c# e# .#  # T# h# o# u# g# h#  # t# h# e#  # t# i# m# e#  # a# n# d#  # f# r# e# q# u# e# n# c# y#  # o# f#  # t# h# e# s# e#  # m# o# v# e# m# e# n# t# s#  # a# r# e#  # k# e# p# t#  # e# x# p# l# i# c# i# t# l# y#  # h# i# d# d# e# n# .#  # R# e# g# a# r# d# l# e# s# s#  # o# f#  # a#  # p# l# a# y# e# r# '# s#  # p# e# r# f# o# r# m# a# n# c# e# ,#  # h# o# w# e# v# e# r# ,#  # p# l# a# c# e# m# e# n# t#  # m# a# t# c# h# e# s#  # c# u# r# r# e# n# t# l# y#  # d# o#  # n# o# t#  # p# l# a# c# e#  # p# l# a# y# e# r# s#  # i# n#  # t# h# e#  # h# i# g# h# e# s# t#  # l# e# a# g# u# e# ,#  # G# r# a# n# d# m# a# s# t# e# r# .#  # W# i# t# h#  # e# v# e# n#  # a#  # p# e# r# f# e# c# t#  # p# l# a# c# e# m# e# n# t#  # r# e# c# o# r# d# ,#  # a#  # p# l# a# y# e# r#  # m# u# s# t#  # w# o# r# k#  # t# h# e# i# r#  # w# a# y#  # t# h# r# o# u# g# h#  # t# h# e#  # i# n# i# t# i# a# l#  # p# l# a# c# e# m# e# n# t#  # d# i# v# i# s# i# o# n# (# s# )#  # b# e# f# o# r# e#  # b# e# i# n# g#  # p# l# a# c# e# d#  # i# n#  # G# r# a# n# d# m# a# s# t# e# r# .# "# *# 
# 
# 
# I# f#  # w# e#  # c# o# u# p# l# e#  # t# h# a# t#  # q# u# o# t# e# d#  # c# o# n# t# e# x# t#  # w# i# t# h#  # t# h# e#  # h# i# s# t# o# g# r# a# m# s#  # d# i# r# e# c# t# l# y#  # a# b# o# v# e# ,#  # i# t# '# s#  # c# l# e# a# r#  # w# h# y#  # o# n# l# y#  # a# b# o# u# t#  # 1# %#  # o# f#  # a# l# l#  # L# e# a# g# u# e#  # p# l# a# y# e# r# s#  # a# r# e#  # i# n#  # t# h# e#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# a# g# u# e#  # (# L# e# a# g# u# e#  # I# n# d# e# x#  # 7# )# .#  #  # T# h# e# s# e#  # a# r# e#  # t# h# e#  # b# e# s# t#  # o# f#  # t# h# e#  # b# e# s# t#  # S# C# 2#  # p# l# a# y# e# r# s# ,#  # w# h# e# r# e#  # e# v# e# n#  # h# a# v# i# n# g#  # a#  # p# e# r# f# e# c# t#  # u# n# d# e# f# e# a# t# e# d#  # r# e# c# o# r# d#  # i# n#  # a#  # p# l# a# y# e# r# s#  # f# i# r# s# t#  # 5#  # p# l# a# c# e# m# e# n# t#  # m# a# t# c# h# e# s#  # d# o# e# s# n# '# t#  # g# u# a# r# a# n# t# e# e#  # G# r# a# n# d# m# a# s# t# e# r#  # d# e# s# i# g# n# a# t# i# o# n# .#  #  # 
# 
# F# r# o# m#  # a#  # d# a# t# a#  # p# e# r# s# p# e# c# t# i# v# e# ,#  # t# h# e#  # l# a# c# k#  # o# f#  # a#  # s# a# m# p# l# e#  # s# i# z# e#  # (# r# o# u# g# h# l# y#  # 3# 4#  # r# o# w# s# )#  # m# i# g# h# t#  # m# a# k# e#  # i# t#  # h# a# r# d#  # f# o# r#  # o# u# r#  # m# o# d# e# l# s#  # t# o#  # a# c# c# u# r# a# t# e# l# y#  # p# r# e# d# i# c# t#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# v# e# l#  # p# l# a# y# e# r# s# .#  #  # T# h# a# t#  # s# a# i# d# ,#  # I#  # a# l# s# o#  # w# o# n# d# e# r#  # i# f#  # t# h# e# r# e#  # a# r# e#  # a# n# y#  # a# t# t# r# i# b# u# t# e# s#  # t# h# a# t#  # c# l# e# a# r# l# y#  # d# i# f# f# e# r# e# n# t# i# a# t# e#  # M# a# s# t# e# r#  # (# L# e# a# g# u# e#  # I# n# d# e# x#  # 6# )#  # f# r# o# m#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# a# g# u# e#  # p# l# a# y# e# r# s# .

# -# -# -# -# -# -# -# -# -# -

# ## ## ##  # P# l# a# y# e# r#  # A# t# t# r# i# b# u# t# e# s#  # (# I# n# d# e# p# e# n# d# e# n# t#  # V# a# r# i# a# b# l# e# s# )# 
# ## ## ## ##  # H# e# r# e#  # w# e#  # j# u# m# p#  # i# n# t# o#  # t# h# e#  # m# a# j# o# r# i# t# y#  # o# f#  # t# h# e#  # d# a# t# a# ,#  # t# a# k# i# n# g#  # a#  # h# e# l# i# c# o# p# t# e# r#  # v# i# e# w#  # o# f#  # s# o# m# e#  # p# l# a# y# e# r#  # a# t# t# r# i# b# u# t# e# s#  # w# h# i# l# e#  # d# i# g# g# i# n# g#  # d# e# e# p# e# r#  # i# n# t# o#  # o# t# h# e# r# s# .#  #  # L# e# v# e# r# a# g# i# n# g#  # t# h# e#  # p# o# w# e# r# f# u# l#  # P# y# t# h# o# n#  # d# e# s# c# r# i# b# e#  # m# e# t# h# o# d#  # i# s#  # h# o# w#  # w# e#  # j# u# m# p#  # i# n# .#  #  # T# h# i# s#  # a# l# s# o#  # s# e# r# v# e# s#  # a# s#  # a#  # g# o# o# d#  # d# o# u# b# l# e#  # c# h# e# c# k#  # t# h# a# t#  # t# h# e#  # r# e# m# a# i# n# i# n# g#  # d# a# t# a#  # p# o# i# n# t# s#  # i# n#  # t# h# e#  # d# a# t# a# f# r# a# m# e#  # d# f#  # h# a# v# e#  # r# e# m# o# v# e# d#  # a# l# l#  # n# o# n# -# h# e# l# p# f# u# l#  # d# a# t# a#  # p# o# i# n# t# s# .

# In[None]

df.describe()

# ## ## ## ## *# *# I# m# m# e# d# i# a# t# e#  # r# e# a# c# t# i# o# n# s# :# *# *# 
#  # -#  # I#  # m# i# g# h# t#  # c# o# n# s# i# d# e# r#  # r# e# m# o# v# i# n# g#  # *# *# G# a# m# e# I# D# *# *#  # f# o# r#  # l# a# t# e# r#  # a# n# a# l# y# s# e# s#  # a# s#  # t# h# a# t#  # d# a# t# a#  # p# r# o# v# i# d# e# s#  # l# i# t# t# l# e#  # t# o#  # n# o#  # c# o# n# t# e# x# t#  # h# e# r# e# .#  #  # T# h# e#  # o# n# l# y#  # v# a# l# u# e#  # I#  # f# e# e# l#  # i# t#  # c# o# u# l# d#  # b# r# i# n# g#  # i# s#  # i# n#  # a#  # t# i# m# e#  # s# e# r# i# e# s#  # a# n# a# l# y# s# i# s# .#  #  # T# h# e#  # s# m# a# l# l# e# r#  # t# h# e#  # G# a# m# e# I# D# ,#  # t# h# e#  # e# a# r# l# i# e# r#  # o# n#  # t# h# e#  # g# a# m# e#  # w# a# s#  # p# l# a# y# e# d# .#  #  # C# o# u# l# d#  # b# e#  # i# n# t# e# r# e# s# t# i# n# g#  # t# o#  # s# e# e#  # p# l# a# y# e# r#  # a# t# t# r# i# b# u# t# e# s#  # c# h# a# n# g# e# d#  # o# v# e# r#  # t# i# m# e#  # a# c# r# o# s# s#  # l# e# a# g# u# e# s# .#  #  # 
#  # -#  # I# '# m#  # s# u# r# p# r# i# s# e# d#  # a# t#  # t# h# e#  # 1# 6#  # m# i# n#  # a# n# d#  # 4# 4#  # m# a# x#  # *# *# A# g# e# *# *#  # a# r# e# n# '# t#  # m# o# r# e#  # e# x# t# r# e# m# e# .#  #  # S# u# r# e# l# y#  # s# o# m# e#  # 1# 2#  # y# e# a# r#  # o# l# d#  # i# s#  # p# l# a# y# i# n# g#  # c# o# m# p# e# t# i# t# i# v# e#  # S# C# 2#  # b# a# c# k#  # M# o# m#  # a# n# d#  # D# a# d# '# s#  # b# a# c# k# .#  #  # A# n# d#  # w# i# t# h#  # p# r# i# z# e#  # m# o# n# e# y#  # i# n#  # t# h# e#  # m# i# l# l# i# o# n# s# ,#  # i# t# '# s#  # s# u# r# p# r# i# s# i# n# g#  # t# o#  # s# e# e#  # t# h# e# r# e#  # i# s# n# '# t#  # s# o# m# e#  # s# o# m# e#  # 5# 5#  # y# e# a# r#  # o# l# d#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# a# g# u# e#  # p# l# a# y# e# r# .#  #  # G# r# a# n# d# f# a# t# h# e# r# m# a# s# t# e# r# ?# 
#  # -#  # A#  # p# l# a# y# e# r#  # l# o# g# g# e# d#  # 1#  # m# i# l# l# i# o# n#  # *# *# T# o# t# a# l# H# o# u# r# s# *# *# ?#  #  # S# e# e# m# s#  # a#  # t# a# d#  # t# o# o#  # m# u# c# h# .#  #  # 1#  # m# i# l# l# i# o# n#  # h# o# u# r# s#  # /#  # 2# 4#  # h# o# u# r# s#  # i# n#  # a#  # d# a# y#  # /#  # 3# 6# 5#  # d# a# y# s#  # i# n#  # a#  # y# e# a# r#  # =#  # s# o# m# e#  # S# C# 2#  # p# l# a# y# e# r#  # g# a# m# i# n# g#  # f# o# r#  # 1# 1# 4# .# 6#  # y# e# a# r# s# .#  #  # T# h# a# t#  # c# o# n# t# r# a# d# i# c# t# s#  # t# h# e#  # 4# 4#  # m# a# x#  # p# l# a# y# e# r#  # a# g# e# .#  #  # T# h# i# s#  # m# a# t# h#  # i# s#  # b# o# n# k# e# r# s# .#  #  # O# r#  # m# a# y# b# e#  # I# '# m#  # b# o# n# k# e# r# s# .#  #  # N# e# e# d#  # t# o#  # l# o# o# k#  # i# n# t# o#  # t# h# i# s#  # a# n# d#  # p# o# t# e# n# t# i# a# l# l# y#  # r# e# m# o# v# e#  # t# h# a# t#  # 1#  # m# i# l# l# i# o# n#  # T# o# t# a# l# H# o# u# r# s#  # d# a# t# a#  # p# o# i# n# t# .# 
#  # -#  # I#  # w# i# s# h#  # I#  # h# a# d#  # a# n#  # a# v# e# r# a# g# e#  # o# f#  # 1# 5# .# 9#  # *# *# H# o# u# r# s# P# e# r# W# e# e# k# *# *#  # w# e# e# k#  # t# o#  # p# l# a# y#  # S# t# a# r# c# r# a# f# t#  # 2# !#  #  # A# n# d#  # D# A# M# N# I# T#  # I#  # k# n# e# w#  # I#  # s# h# o# u# l# d#  # h# a# v# e#  # u# s# e# d#  # m# o# r# e#  # h# o# t#  # k# e# y# s#  # w# h# e# n#  # I#  # p# l# a# y# e# d# .# 
#  # -#  # I#  # d# o# n# '# t#  # g# e# t#  # t# h# e#  # *# *# W# o# r# k# e# r# s# M# a# d# e# ,#  # U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# *# *#  # m# e# t# r# i# c# s# .#  #  # H# o# w#  # d# o#  # y# o# u#  # m# a# k# e#  # a# n#  # a# v# e# r# a# g# e#  # o# f#  # 0# .# 0# 0# 1# 0# 3# 1#  # w# o# r# k# e# r# s# ?#  #  # I# '# m#  # m# i# s# s# i# n# g#  # s# o# m# e# t# h# i# n# g#  # h# e# r# e# .

# *# *# S# t# r# o# n# g# e# r#  # a# t# t# r# i# b# u# t# e#  # m# e# t# r# i# c#  # c# o# n# t# e# x# t#  # i# s#  # s# o# r# e# l# y#  # n# e# e# d# e# d# .# *# *#  #  # 
# 
# A#  # r# e# f# r# e# s# h#  # o# n#  # t# h# o# s# e#  # d# e# s# c# r# i# p# t# i# o# n# s# ,#  # t# a# k# e# n#  # f# r# o# m#  # t# h# e#  # K# a# g# g# l# e#  # S# t# a# r# c# r# a# f# t#  # I# I#  # R# e# p# l# a# y#  # A# n# a# l# y# s# i# s#  # p# a# g# e#  # i# s#  # b# e# l# o# w# .# 
# 
# T# h# i# s#  # d# a# t# a# s# e# t#  # c# o# n# t# a# i# n# s#  # 2# 1#  # v# a# r# i# a# b# l# e# s# :#  #  # 
# -#  # *# *# G# a# m# e# I# D# :# *# *#  # U# n# i# q# u# e#  # I# D#  # f# o# r#  # e# a# c# h#  # g# a# m# e#  #  # 
# -#  # *# *# L# e# a# g# u# e# I# n# d# e# x# :# *# *#  # 1# -# 8#  # f# o# r#  # B# r# o# n# z# e# ,#  # S# i# l# v# e# r# ,#  # G# o# l# d# ,#  # D# i# a# m# o# n# d# ,#  # M# a# s# t# e# r# ,#  # G# r# a# n# d# M# a# s# t# e# r# ,#  # P# r# o# f# e# s# s# i# o# n# a# l#  # l# e# a# g# u# e# s#  #  # 
# -#  # *# *# A# g# e# :# *# *#  # A# g# e#  # o# f#  # e# a# c# h#  # p# l# a# y# e# r#  #  # 
# -#  # *# *# H# o# u# r# s# P# e# r# W# e# e# k# :# *# *#  # H# o# u# r# s#  # s# p# e# n# t#  # p# l# a# y# i# n# g#  # p# e# r#  # w# e# e# k#  #  # 
# -#  # *# *# T# o# t# a# l# H# o# u# r# s# :# *# *#  # T# o# t# a# l#  # h# o# u# r# s#  # s# p# e# n# t#  # p# l# a# y# i# n# g#  #  # 
# -#  # *# *# A# P# M# :# *# *#  # A# c# t# i# o# n#  # p# e# r#  # m# i# n# u# t# e#  #  # 
# -#  # *# *# S# e# l# e# c# t# B# y# H# o# t# k# e# y# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # u# n# i# t#  # s# e# l# e# c# t# i# o# n# s#  # m# a# d# e#  # u# s# i# n# g#  # h# o# t# k# e# y# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# A# s# s# i# g# n# T# o# H# o# t# k# e# y# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # u# n# i# t# s#  # a# s# s# i# g# n# e# d#  # t# o#  # h# o# t# k# e# y# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# U# n# i# q# u# e# H# o# t# k# e# y# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # u# n# i# q# u# e#  # h# o# t# k# e# y# s#  # u# s# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# M# i# n# i# m# a# p# A# t# t# a# c# k# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # a# t# t# a# c# k#  # a# c# t# i# o# n# s#  # o# n#  # m# i# n# i# m# a# l#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# M# i# n# i# m# a# p# R# i# g# h# t# C# l# i# c# k# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # r# i# g# h# t# -# c# l# i# c# k# s#  # o# n#  # m# i# n# i# m# a# l#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# N# u# m# b# e# r# O# f# P# A# C# s# :# *# *#  # N# u# m# b# e# r#  # o# f#  # P# A# C# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# G# a# p# B# e# t# w# e# e# n# P# A# C# s# :# *# *#  # M# e# a# n#  # d# u# r# a# t# i# o# n#  # b# e# t# w# e# e# n#  # P# A# C# s#  # (# m# i# l# l# i# s# e# c# o# n# d# s# )#  #  # 
# -#  # *# *# A# c# t# i# o# n# L# a# t# e# n# c# y# :# *# *#  # M# e# a# n#  # l# a# t# e# n# c# y#  # f# r# o# m#  # t# h# e#  # o# n# s# e# t#  # o# f#  # P# A# C# s#  # t# o#  # t# h# e# i# r#  # f# i# r# s# t#  # a# c# t# i# o# n#  # (# m# i# l# l# i# s# e# c# o# n# d# s# )#  #  # 
# -#  # *# *# A# c# t# i# o# n# s# I# n# P# A# C# :# *# *#  # M# e# a# n#  # n# u# m# b# e# r#  # o# f#  # a# c# t# i# o# n# s#  # w# i# t# h# i# n#  # e# a# c# h#  # P# A# C#  #  # 
# -#  # *# *# T# o# t# a# l# M# a# p# E# x# p# l# o# r# e# d# :# *# *#  # N# u# m# b# e# r#  # o# f#  # 2# 4# x# 2# 4#  # g# a# m# e#  # c# o# o# r# d# i# n# a# t# e#  # g# r# i# d# s#  # v# i# e# w# e# d#  # b# y#  # p# l# a# y# e# r#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# W# o# r# k# e# r# s# M# a# d# e# :# *# *#  # N# u# m# b# e# r#  # o# f#  # S# C# V# s# ,#  # d# r# o# n# e# s# ,#  # p# r# o# b# e# s#  # t# r# a# i# n# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# :# *# *#  # U# n# i# q# u# e#  # u# n# i# t# s#  # m# a# d# e#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# C# o# m# p# l# e# x# U# n# i# t# s# M# a# d# e# :# *# *#  # N# u# m# b# e# r#  # o# f#  # g# h# o# s# t# s# ,#  # i# n# v# e# s# t# o# r# s# ,#  # a# n# d#  # h# i# g# h#  # t# e# m# p# l# a# r# s#  # t# r# a# i# n# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# C# o# m# p# l# e# x# A# b# i# l# i# t# y# U# s# e# d# :# *# *#  # A# b# i# l# i# t# i# e# s#  # r# e# q# u# i# r# i# n# g#  # s# p# e# c# i# f# i# c#  # t# a# r# g# e# t# i# n# g#  # i# n# s# t# r# u# c# t# i# o# n# s#  # u# s# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p#  #  # 
# -#  # *# *# M# a# x# T# i# m# e# S# t# a# m# p# :# *# *#  # T# i# m# e#  # s# t# a# m# p#  # o# f#  # g# a# m# e# '# s#  # l# a# s# t#  # r# e# c# o# r# d# e# d#  # e# v# e# n# t#  #  # 


# T# a# c# k# l# i# n# g#  # t# h# e#  # *# *# A# g# e# *# *#  # a# t# t# r# i# b# u# t# e#  # f# i# r# s# t# .# 
# 
# M# y#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # i# s#  # t# h# a# t#  # e# a# c# h#  # r# o# w#  # r# e# c# o# r# d# s#  # a#  # p# a# r# t# i# c# u# l# a# r#  # p# l# a# y# e# r# s#  # g# a# m# e#  # s# t# a# t# s#  # f# o# r#  # a#  # s# p# e# c# i# f# i# c#  # S# C# 2#  # L# e# a# g# u# e#  # g# a# m# e# ,#  # r# e# p# r# e# s# e# n# t# e# d#  # b# y#  # G# a# m# e# I# D# .#  #  # T# h# e#  # *# *# A# g# e# *# *#  # d# e# s# c# r# i# p# t# i# o# n#  # a# b# o# v# e#  # c# o# n# f# i# r# m# s#  # t# h# i# s#  # t# o# o# ,#  # b# u# t#  # I# '# l# l#  # t# r# u# s# t#  # t# h# i# s#  # a#  # b# i# t#  # m# o# r# e#  # i# f#  # t# h# e#  # d# i# s# t# i# n# c# t#  # a# g# e#  # v# a# l# u# e# s#  # a# r# e#  # a# l# l#  # w# h# o# l# e#  # n# u# m# b# e# r# s#  # (# s# u# g# g# e# s# t# i# n# g#  # i# t# '# s#  # n# o# t#  # s# o# m# e#  # a# v# e# r# a# g# e#  # o# f#  # p# l# a# y# e# r# s#  # w# i# t# h# i# n#  # t# h# e#  # g# a# m# e# )# .

# In[None]

pd.unique(df['Age'])

# A# w# e# s# o# m# e# ,#  # e# a# c# h#  # r# o# w#  # r# e# p# r# e# s# e# n# t# i# n# g#  # a#  # s# i# n# g# l# e#  # p# l# a# y# e# r#  # a# n# d#  # h# i# s#  # g# a# m# e# p# l# a# y#  # m# e# t# r# i# c# s#  # s# e# e# m# s#  # t# o#  # c# h# e# c# k#  # o# u# t# .#  #  # 
# 
# A# s#  # f# a# r#  # a# s#  # t# h# e#  # 0# .# 0# 0# 1# 0# 3# 1#  # *# *# W# o# r# k# e# r# s# M# a# d# e# *# *#  # u# n# i# t# ,#  # i# t# '# s#  # c# l# e# a# r#  # t# h# i# s#  # m# e# t# r# i# c#  # i# s#  # p# e# r#  # t# i# m# e#  # s# t# a# m# p#  # a# n# d#  # c# a# p# t# u# r# e# s#  # a#  # v# e# r# y#  # s# p# e# c# i# f# i# c#  # m# o# m# e# n# t#  # i# n#  # t# i# m# e# .#  #  # M# y#  # g# u# e# s# s#  # i# s#  # i# t# '# s#  # d# o# w# n#  # t# o#  # t# h# e#  # s# e# c# o# n# d# .#  #  # S# o#  # m# a# k# i# n# g#  # o# n# l# y#  # 0# .# 0# 0# 1# 0# 3# 1#  # w# o# r# k# e# r# s#  # p# e# r#  # s# e# c# o# n# d#  # s# e# e# m# s#  # t# o#  # m# a# k# e#  # s# e# n# s# e# .#  #  # S# a# m# e#  # a# p# p# l# i# e# s#  # f# o# r#  # a#  # l# o# t#  # o# f#  # t# h# e#  # o# t# h# e# r#  # *# *# T# i# m# e# S# t# a# m# p# *# *#  # b# a# s# e# d#  # m# e# t# r# i# c# s# .#  #  # 
# 
# T# i# m# e#  # t# o#  # i# n# v# e# s# t# i# g# a# t# e#  # t# h# a# t#  # 1#  # m# i# l# l# i# o# n#  # *# *# T# o# t# a# l# H# o# u# r# s# *# *#  # d# a# t# a#  # p# o# i# n# t# .

# In[None]

# Looking at that 1 million TotalHours row
df[df['TotalHours']==1000000]

# S# o#  # a# n#  # 1# 8#  # y# e# a# r#  # o# l# d#  # k# i# d#  # h# a# s#  # a# l# r# e# a# d# y#  # p# l# a# y# e# d#  # 1#  # m# i# l# l# i# o# n#  # h# o# u# r# s# ,#  # w# h# i# c# h#  # w# e#  # p# r# e# v# i# o# u# s# l# y#  # c# a# l# c# u# l# a# t# e# d#  # t# o#  # b# e#  # 1# 1# 4# .# 6#  # y# e# a# r# s# .#  #  # R# i# i# i# i# i# i# g# h# t# .#  #  # B# e# f# o# r# e#  # t# h# r# o# w# i# n# g#  # t# h# i# s#  # d# a# t# a#  # p# o# i# n# t#  # o# u# t#  # i# t# '# s#  # p# r# o# b# a# b# l# y#  # g# o# o# d#  # t# o#  # c# h# e# c# k#  # t# h# a# t#  # n# o#  # o# t# h# e# r#  # p# l# a# y# e# r# s#  # h# a# v# e#  # T# o# t# a# l# H# o# u# r# s#  # (# c# o# n# v# e# r# t# e# d#  # t# o#  # y# e# a# r# s# )#  # t# h# a# t#  # e# x# c# e# e# d#  # t# h# e# i# r#  # A# g# e# .

# In[None]

df_temp = df[['Age', 'TotalHours']].copy(deep=True)
df_temp['TotalHoursYears'] = df_temp['TotalHours'] / 24 / 365
df_temp['Age_Less_GP_Years'] = df_temp['Age'] - df_temp['TotalHoursYears']
df_temp.head()

# T# i# m# e#  # t# o#  # s# e# e#  # i# f#  # a# n# y#  # o# t# h# e# r#  # d# a# t# a#  # p# o# i# n# t# s#  # s# h# o# w#  # p# l# a# y# e# r# s#  # w# i# t# h#  # m# o# r# e#  # S# C# 2#  # p# l# a# y# i# n# g#  # y# e# a# r# s#  # t# h# a# n#  # t# h# e# y# '# v# e#  # b# e# e# n#  # a# l# i# v# e# .

# In[None]

df_temp[df_temp['Age_Less_GP_Years']<0]

# O# k# a# y# ,#  # g# r# e# a# t#  # I# '# m#  # n# o# t#  # c# r# a# z# y#  # a# n# d#  # t# h# a# t#  # 1#  # m# i# l# l# i# o# n#  # d# a# t# a#  # p# o# i# n# t#  # n# e# e# d# s#  # t# o#  # b# e#  # r# e# m# o# v# e# d# .

# In[None]

# Removing that 1 million TotalHours row
df = df[df['TotalHours']!=1000000]
print('Remaining records in df= ' + str(len(df)))

# Deleting df_temp
del(df_temp)

# T# i# m# e#  # t# o#  # s# t# a# r# t#  # m# o# v# i# n# g#  # t# o# w# a# r# d# s#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s#  # f# o# r#  # m# o# r# e#  # i# n# s# i# g# h# t# .#  #  # A#  # q# u# i# c# k#  # s# e# t# u# p#  # o# f#  # t# h# e#  # c# o# l# u# m# n# s#  # w# e#  # w# a# n# t#  # t# o#  # f# o# c# u# s#  # o# n#  # i# s#  # f# o# l# l# o# w# e# d#  # b# y#  # s# o# m# e#  # p# l# o# t# s#  # b# e# l# o# w# .

# In[None]

# Create list of player attributes (potential features) for data analysis
lst_pf = list(df.columns)
lst_pf = lst_pf[2:20]
num_of_pf = len(lst_pf)
lst_counter = list(np.arange(1,num_of_pf + 1,1))
print(lst_pf)
print(lst_counter)

# In[None]

# Create and apply dictionary of League Index Names for future plot labels
dct_league_names = {1:'Bronze', 2:'Silver', 3:'Gold', 4:'Platinum', 5:'Diamond', 
                    6:'Master', 7:'Grandmaster'}
df['LeagueName'] = df['LeagueIndex'].map(dct_league_names)

# Check mapping was applied correctly
df[['LeagueIndex', 'LeagueName']].head(10)

pvt_num_lpt = df.pivot_table(index='LeagueName', values=['LeagueIndex'], aggfunc='count', 
                             margins=False)

# In[None]

# Setup graph formatting
plt.style.use('seaborn')
sns.set_palette("dark")
sns.set_style("whitegrid")

# Boxplots of the potential features
fig, axes = plt.subplots(num_of_pf, 1, sharex = True, figsize = (14,30))
fig.suptitle('Attribute Percentile Distributions', fontsize=22, 
             fontweight='bold')
fig.subplots_adjust(top=0.95)

for pf, c in zip(lst_pf, lst_counter):
    p = plt.subplot(num_of_pf,1,c) # (rows, columns, graph number)
    sns.boxplot(x = 'LeagueIndex', y = pf, data=df, showfliers=False) 
    # outliers excluded from plots given visual density, but data points have not been removed
    if c < num_of_pf: # remove xtick labels and xaxis title for all plots, excluding the last
        labels = [item.get_text() for item in p.get_xticklabels()]
        empty_string_labels = [''] * len(labels)
        p.set_xticklabels(empty_string_labels)
        p.set(xlabel='')
    if c== 1:
        p.set_title('Box and Whisker Plots\n', fontsize=16)
     
plt.show()

# *# *# O# b# s# e# r# v# a# t# i# o# n# s# *# *# 
# 
# H# o# p# e#  # y# o# u#  # h# a# v# e#  # a#  # g# i# a# n# t#  # a# n# d#  # /#  # o# r#  # p# o# r# t# r# a# i# t#  # o# r# i# e# n# t# e# d#  # m# o# n# i# t# o# r#  # t# o#  # s# e# e#  # a# l# l#  # 1# 8#  # p# l# o# t# s# !#  #  # I# f#  # n# o# t#  # a#  # s# t# r# o# n# g#  # i# n# d# e# x#  # f# i# n# g# e# r#  # t# o#  # s# c# r# o# l# l#  # d# o# w# n#  # s# h# o# u# l# d#  # d# o# .#  #  # I# n#  # e# i# t# h# e# r#  # c# a# s# e# ,#  # h# e# r# e#  # a# r# e#  # a#  # f# e# w#  # o# b# s# e# r# v# a# t# i# o# n# s# :# 
# 
#  # 1# .#  # *# *# A# g# e# *# *#  # o# f#  # p# l# a# y# e# r# s#  # a# c# r# o# s# s#  # l# e# a# g# u# e# s#  # i# s#  # e# s# s# e# n# t# i# a# l# l# y#  # t# h# e#  # s# a# m# e# .#  #  # C# o# m# m# e# n# t# s#  # s# p# e# a# k# i# n# g#  # t# o#  # t# h# e#  # w# i# d# e# r#  # (# t# a# l# l# e# r# )#  # i# n# t# e# r# q# u# a# r# t# i# l# e#  # r# a# n# g# e#  # (# I# Q# R#  # =#  # t# h# e#  # b# o# x# )#  # f# o# r#  # t# h# e#  # b# r# o# n# z# e#  # l# e# a# g# u# e#  # a# n# d#  # h# i# g# h# e# r#  # m# e# d# i# a# n#  # f# o# r#  # t# h# e#  # G# r# a# n# d# m# a# s# t# e# r#  # l# e# a# g# u# e#  # c# o# u# l# d#  # b# e#  # m# a# d# e#  # b# u# t#  # I#  # b# e# l# i# e# v# e#  # t# h# e#  # H# o# u# r# s# P# e# r# W# e# e# k#  # a# t# t# r# i# b# u# t# e#  # w# o# u# l# d#  # b# e#  # s# t# r# o# n# g# e# r#  # "# e# x# p# e# r# i# e# n# c# e# "#  # a# t# t# r# i# b# u# t# e#  # t# o#  # t# h# i# n# k#  # t# h# r# o# u# g# h# .#  #  # 
# 
#  # 2# .#  # *# *# H# o# u# r# s# P# e# r# W# e# e# k# ,#  # T# o# t# a# l# H# o# u# r# s# ,#  # A# P# M# ,#  # S# e# l# e# c# t# B# y# H# o# t# K# e# y# s# ,#  # A# s# s# i# g# n# T# o# H# o# t# k# e# y# s# ,#  # U# n# i# q# u# e# H# o# t# k# e# y# s# *# *#  # a# l# l#  # s# u# g# g# e# s# t#  # t# h# e#  # s# a# m# e#  # v# o# l# u# m# e#  # =#  # p# l# a# y# e# r#  # s# t# r# e# n# g# t# h#  # t# h# e# m# e# .#  #  #  # E# v# e# r# y#  # a# t# t# r# i# b# u# t# e#  # (# w# i# t# h#  # t# h# e#  # e# x# c# e# p# t# i# o# n#  # o# f#  # t# h# e#  # *# *# G# a# p# B# e# t# w# e# e# n# P# A# C# s# *# *#  # a# n# d#  # *# *# A# c# t# i# o# n# L# a# t# e# n# c# y# *# *# ,#  # w# h# e# r# e#  # l# o# w# e# r#  # m# e# t# r# i# c# s#  # t# r# a# n# s# l# a# t# e#  # t# o#  # s# t# r# o# n# g# e# r#  # g# a# m# e#  # p# l# a# y# )#  # t# r# e# n# d# s#  # u# p#  # a# n# d#  # t# o#  # t# h# e#  # r# i# g# h# t#  # a# c# r# o# s# s#  # L# e# a# g# u# e# s# .# 
# 
#  # 3# .#  # I# t# '# s#  # w# o# r# t# h#  # n# o# t# i# n# g#  # t# h# a# t#  # t# h# e#  # *# *# H# o# u# r# s# P# e# r# W# e# e# k# *# *#  # a# t# t# r# i# b# u# t# e#  # h# a# s#  # t# h# e#  # g# r# e# a# t# e# s# t#  # I# Q# R#  # a# n# d#  # m# e# d# i# a# n# .#  #  # I# f#  # a#  # p# l# a# y# e# r#  # i# s#  # i# n#  # t# h# e#  # m# o# s# t#  # c# o# m# p# e# t# i# t# i# v# e#  # G# r# a# n# d# m# a# s# t# e# r#  # l# e# a# g# u# e# ,#  # i# t#  # m# a# k# e# s#  # s# e# n# s# e#  # t# h# a# t#  # s# o# m# e#  # o# f#  # t# h# o# s# e#  # p# l# a# y# e# r# s#  # p# u# t#  # i# n#  # a#  # l# o# t#  # o# f#  # t# i# m# e#  # t# o#  # r# e# a# c# h#  # t# h# a# t#  # l# e# v# e# l#  # v# s#  # o# t# h# e# r# s#  # t# h# a# t#  # a# r# e#  # "# n# a# t# u# r# a# l# l# y# "#  # t# a# l# e# n# t# e# d#  # a# t#  # t# h# e#  # g# a# m# e#  # (# s# p# e# a# k# i# n# g#  # t# o#  # t# h# e#  # w# i# d# e#  # r# a# n# g# e# )# .#  #  # R# e# g# a# r# d# l# e# s# s# ,#  # G# r# a# n# d# m# a# s# t# e# r#  # l# e# v# e# l#  # p# l# a# y# e# r# s#  # d# o#  # p# l# a# y#  # m# o# r# e#  # f# r# o# m#  # a#  # m# e# d# i# a# n#  # p# e# r# s# p# e# c# t# i# v# e# .#  #  # 
# 
#  # 4# .#  # *# *# N# u# m# b# e# r# o# f# P# A# C# s# *# *# ,#  # w# h# e# r# e#  # a#  # P# A# C#  # s# t# a# n# d# s#  # f# o# r#  # a#  # *# P# e# r# c# e# p# t# i# o# n#  # A# c# t# i# o# n#  # C# y# c# l# e# *#  # a# n# d#  # i# s#  # d# e# f# i# n# e# d#  # b# y#  # i# t# '# s#  # w# i# k# i#  # a# s#  # "# w# h# e# n#  # o# n# e#  # c# h# a# n# g# e# s#  # s# c# r# e# e# n#  # l# o# c# a# t# i# o# n#  # a# n# d#  # p# e# r# f# o# r# m# s#  # 1# +#  # a# c# t# i# o# n# s#  # b# e# f# o# r# e#  # c# h# a# n# g# i# n# g#  # s# c# r# e# e# n#  # l# o# c# a# t# i# o# n#  # a# g# a# i# n#  # t# o#  # r# e# p# e# a# t# .# "#  #  # S# o#  # t# h# e#  # m# o# r# e#  # a#  # p# l# a# y# e# r#  # i# n# c# r# e# a# s# e# s#  # h# i# s#  # v# i# s# i# b# i# l# i# t# y#  # a# n# d#  # p# e# r# f# o# r# m# s#  # g# a# m# e#  # a# c# t# i# o# n# s#  # t# h# e#  # m# o# r# e#  # l# i# k# e# l# y#  # h# e#  # i# s#  # t# o#  # b# e#  # a#  # b# e# t# t# e# r#  # p# l# a# y# e# r# .#  #  # M# a# k# e# s#  # s# e# n# s# e# .#  #  # 
# 
#  # 5# .#  # *# *# G# a# p# B# e# t# w# e# e# n# P# A# C# s# *# *#  # w# o# r# k# s#  # i# n#  # t# h# e#  # o# p# p# o# s# i# t# e#  # d# i# r# e# c# t# i# o# n#  # w# h# e# r# e#  # t# h# e#  # f# e# w# e# r#  # s# e# c# o# n# d# s#  # t# h# a# t#  # p# a# s# s#  # b# e# t# w# e# e# n#  # P# A# C# s#  # m# e# a# n# s#  # a#  # p# l# a# y# e# r#  # i# s#  # m# o# r# e#  # a# c# t# i# v# e#  # w# i# t# h#  # h# i# s#  # m# o# u# s# e#  # a# n# d#  # i# n# c# r# e# a# s# i# n# g#  # h# i# s#  # *# *# N# u# m# b# e# r# o# f# P# A# C# s# *# *# .#  #  # I#  # s# u# s# p# e# c# t#  # w# e#  # m# a# y#  # r# u# n#  # i# n# t# o#  # s# o# m# e#  # *# *# *# m# u# l# t# i# c# o# l# l# i# n# e# a# r# i# t# y# *# *# *#  # i# s# s# u# e# s#  # f# r# o# m#  # t# h# i# s#  # l# a# t# e# r# ,#  # s# o# m# e# t# h# i# n# g#  # t# o#  # w# a# t# c# h#  # o# u# t#  # f# o# r# .# 
# 
# A# d# d# i# t# i# o# n# a# l#  # c# o# m# m# e# n# t# a# r# y#  # s# p# e# a# k# i# n# g#  # t# o#  # i# n# d# i# v# i# d# u# a# l#  # a# t# t# r# i# b# u# t# e# s#  # t# o#  # b# e#  # a# d# d# e# d#  # l# a# t# e# r# .

# ## ## ##  # A# t# t# r# i# b# u# t# e#  # A# n# a# l# y# s# i# s#  # -#  # U# n# i# q# u# e# U# n# i# t# s# M# a# d# e#  #  # 
# 
# I# '# v# e#  # s# e# p# a# r# a# t# e# d#  # t# h# e#  # *# *# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# *# *#  # a# t# t# r# i# b# u# t# e#  # o# u# t#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # b# e# c# a# u# s# e#  # i# t#  # i# s#  # m# o# r# e#  # i# n# t# e# r# e# s# t# i# n# g#  # t# o#  # m# e#  # t# h# a# n#  # a# n# y#  # o# t# h# e# r#  # a# t#  # t# h# i# s#  # e# a# r# l# y#  # s# t# a# g# e#  # o# f#  # a# n# a# l# y# s# i# s# .#  #  # T# h# e#  # r# e# a# s# o# n#  # h# e# r# e#  # i# s#  # b# e# c# a# u# s# e#  # U# n# i# q# u# e# U# n# i# t# s# M# a# d# e#  # i# s#  # t# h# e#  # o# n# l# y#  # a# t# t# r# i# b# u# t# e#  # t# h# a# t#  # r# e# v# e# r# s# e# s#  # t# h# e#  # c# l# e# a# r#  # t# r# e# n# d#  # y# o# u#  # s# e# e#  # f# r# o# m#  # B# r# o# n# z# e#  # t# o#  # M# a# s# t# e# r#  # l# e# a# g# u# e#  # f# o# r#  # o# t# h# e# r#  # a# t# t# r# i# b# u# t# e# s# ,#  # w# h# e# r# e#  # t# h# e#  # m# e# d# i# a# n#  # a# n# d#  # I# Q# R#  # a# l# l#  # c# o# n# t# i# n# u# e#  # i# n#  # t# h# e#  # s# a# m# e#  # d# i# r# e# c# t# i# o# n# .#  #  # 
# 
# W# i# t# h#  # *# *# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# *# *# ,#  # G# r# a# n# d# m# a# s# t# e# r#  # l# e# a# g# u# e#  # p# l# a# y# e# r# s#  # a# p# p# e# a# r#  # t# o#  # c# r# e# a# t# e#  # l# e# s# s#  # u# n# i# q# u# e#  # u# n# i# t# s#  # p# e# r#  # t# i# m# e#  # s# t# a# m# p#  # t# h# a# n#  # a# n# y#  # o# t# h# e# r#  # l# e# v# e# l# -#  # e# v# e# n#  # l# e# s# s#  # t# h# a# n#  # B# r# o# n# z# e#  # l# e# v# e# l#  # p# l# a# y# e# r# s# !#  #  # M# y#  # g# u# e# s# s#  # i# s#  # t# h# a# t#  # t# h# e#  # a# m# o# u# n# t#  # o# f#  # m# i# c# r# o# m# a# n# a# g# e# m# e# n# t#  # r# e# q# u# i# r# e# d#  # t# o#  # c# o# n# t# r# o# l#  # m# u# l# t# i# p# l# e#  # u# n# i# q# u# e#  # u# n# i# t# s#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t#  # a# b# i# l# i# t# i# e# s#  # o# u# t# w# e# i# g# h# s#  # t# h# e#  # b# e# n# e# f# i# t# s#  # t# h# a# t#  # h# a# v# i# n# g#  # t# h# a# t#  # d# i# v# e# r# s# i# t# y# .#  #  # I# n#  # o# t# h# e# r#  # w# o# r# d# s# ,#  # b# e# i# n# g#  # a# b# l# e#  # t# o#  # d# i# r# e# c# t#  # 2# 0#  # o# f#  # t# h# e#  # s# a# m# e#  # u# n# i# t# s#  # a# n# d#  # a# b# i# l# i# t# i# e# s#  # m# a# y#  # b# e#  # m# o# r# e#  # e# f# f# e# c# t# i# v# e#  # t# h# a# n#  # 4#  # d# i# f# f# e# r# e# n# t#  # g# r# o# u# p# s#  # o# f#  # 5#  # u# n# i# t# s# .#  #  # 
# 
# A# n# o# t# h# e# r#  # t# h# o# u# g# h# t#  # i# s#  # t# h# a# t#  # G# r# a# n# d# m# a# s# t# e# r#  # l# e# a# g# u# e#  # p# l# a# y# e# r# s#  # m# a# y#  # "# r# u# s# h# "#  # t# h# e# i# r#  # o# p# p# o# n# e# n# t# s#  # a# t#  # t# h# e#  # s# t# a# r# t#  # o# f#  # a#  # g# a# m# e#  # m# o# r# e#  # f# r# e# q# u# e# n# t# l# y#  # t# h# a# n#  # p# l# a# y# e# r# s#  # i# n#  # o# t# h# e# r#  # l# e# a# g# u# e# s# .#  #  # S# p# e# n# d# i# n# g#  # m# o# r# e#  # t# i# m# e#  # e# a# r# l# y#  # o# n#  # t# r# y# i# n# g#  # t# o#  # f# i# n# d#  # a# n# d#  # a# t# t# a# c# k#  # y# o# u# r#  # e# n# e# m# y#  # v# s#  # b# u# i# l# d# i# n# g#  # u# p#  # a#  # v# a# s# t#  # f# l# e# e# t#  # o# f#  # u# n# i# t# s#  # a# n# d#  # a# t# t# a# c# k# i# n# g#  # t# h# e# m#  # l# a# t# e# r#  # i# n#  # t# h# e#  # g# a# m# e#  # s# e# e# m# s#  # t# o#  # a# g# r# e# e#  # w# i# t# h#  # h# a# v# i# n# g#  # l# e# s# s#  # *# *# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# .# *# *#  # T# h# e#  # *# *# T# o# t# a# l# M# a# p# E# x# p# l# o# r# e# d# *# *#  # a# t# t# r# i# b# u# t# e#  # s# e# e# m# s#  # t# o#  # s# u# p# p# o# r# t#  # t# h# i# s#  # t# o# o# .# 
# 
# H# o# w# e# v# e# r# ,#  # i# t# '# s#  # s# t# i# l# l#  # v# e# r# y#  # i# n# t# r# i# g# u# i# n# g#  # t# h# a# t#  # M# a# s# t# e# r#  # L# e# v# e# l#  # p# l# a# y# e# r# s#  # d# o# n# '# t#  # s# h# o# w#  # e# v# e# n#  # a#  # s# l# i# g# h# t#  # d# e# c# l# i# n# e#  # v# s#  # D# i# a# m# o# n# d#  # L# e# v# e# l#  # p# l# a# y# e# r# s#  # a# n# d#  # t# h# e#  # d# r# a# s# t# i# c#  # d# r# o# p#  # o# f# f#  # o# f#  # *# *# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# *# *#  # f# r# o# m#  # M# a# s# t# e# r#  # t# o#  # G# r# a# n# d# m# a# s# t# e# r# .#  #  # T# h# e#  # s# m# a# l# l#  # s# a# m# p# l# e#  # s# i# z# e#  # f# o# r#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# v# e# l#  # p# l# a# y# e# r# s#  # c# o# u# l# d#  # a# l# s# o#  # s# p# e# a# k#  # t# o#  # t# h# e#  # b# r# e# a# k#  # i# n#  # t# r# e# n# d# .#  #  # E# n# o# u# g# h#  # t# h# i# n# k# i# n# g# ,#  # t# i# m# e#  # f# o# r#  # s# o# m# e#  # d# i# g# g# i# n# g# .

# In[None]

sns.set_palette("dark")
sns.set_style("whitegrid")

# Use Facetgrid to visualize distributions of UniqueUnitsMade across LeagueIndexes
g = sns.FacetGrid(df, col='LeagueIndex', col_wrap=3, margin_titles=True)
g.map(plt.hist, 'UniqueUnitsMade')
g.fig.suptitle('Unique Units Made', fontweight='bold', fontsize=16)
plt.subplots_adjust(top=0.90)

# W# e#  # a# l# r# e# a# d# y#  # k# n# e# w#  # f# r# o# m#  # t# h# e#  # f# i# r# s# t#  # s# e# t#  # o# f#  # h# i# s# t# o# g# r# a# m# s#  # a# t#  # t# h# e#  # s# t# a# r# t#  # o# f#  # t# h# i# s#  # n# o# t# e# b# o# o# k#  # t# h# a# t#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # G# r# a# n# d# m# a# s# t# e# r#  # p# l# a# y# e# r# s#  # i# s#  # q# u# i# t# e#  # s# m# a# l# l#  # i# n#  # c# o# m# p# a# r# i# s# o# n#  # t# o#  # o# t# h# e# r#  # l# e# a# g# u# e# s# .#  #  # D# o# n# '# t#  # t# h# i# n# k#  # t# h# i# s#  # p# l# o# t#  # t# e# l# l# s#  # u# s#  # v# e# r# y#  # m# u# c# h# .#  #  # T# h# e#  # r# a# n# g# e#  # o# f#  # t# h# e#  # y# -# a# x# i# s#  # i# s#  # a#  # b# i# t#  # t# o# o#  # w# i# d# e#  # f# o# r#  # G# r# a# n# d# m# a# s# t# e# r#  # L# e# a# g# u# e#  # d# a# t# a# ,#  # r# e# q# u# i# r# i# n# g#  # n# e# w#  # p# l# o# t# .

# In[None]

sns.set_palette("dark")
sns.set_style("whitegrid")

plt.hist(df['UniqueUnitsMade'][df['LeagueIndex']==7])
plt.title('Grandmaster League (Index = 7)')
plt.ylabel('Count')
plt.xlabel('Unique Units Made')
plt.show()

# *# *# E# h# ,#  # t# h# e#  # v# a# l# u# e#  # o# f#  # t# h# i# s#  # p# l# o# t#  # d# o# e# s# n# '# t#  # r# e# a# l# l# y#  # t# e# l# l#  # m# e#  # m# u# c# h#  # e# i# t# h# e# r# .# *# *#  #  # A# t#  # b# e# s# t#  # I#  # c# a# n#  # s# a# y#  # t# h# a# t#  # t# h# i# s#  # d# i# s# t# r# i# b# u# t# i# o# n#  # v# e# r# y#  # *# *# *# l# o# o# s# e# l# y# *# *# *#  # r# e# s# e# m# b# l# e# s#  # t# h# e#  # g# e# n# e# r# a# l#  # s# h# a# p# e#  # s# e# e# n#  # i# n#  # o# t# h# e# r#  # l# e# a# g# u# e# s# .#  #  # T# h# e#  # s# m# a# l# l#  # s# a# m# p# l# e#  # s# i# z# e#  # m# a# k# e# s#  # i# t#  # d# i# f# f# i# c# u# l# t#  # t# o#  # s# a# y#  # m# u# c# h#  # e# l# s# e#  # h# e# r# e# .#  #  # I# '# m#  # g# o# i# n# g#  # t# o#  # s# i# d# e#  # s# t# e# p#  # t# h# i# s#  # f# o# r#  # n# o# w#  # a# n# d#  # h# o# p# e#  # t# o#  # h# a# v# e#  # a#  # s# h# o# w# e# r#  # t# h# o# u# g# h# t#  # a# b# o# u# t#  # t# h# i# s#  # l# a# t# e# r# .#  #  # E# p# i# p# h# a# n# y#  # t# o#  # c# o# m# e# !

# ## ##  # A# t# t# r# i# b# u# t# e#  # R# e# l# a# t# i# o# n# s# h# i# p# s#  # 
# W# e# '# v# e#  # l# o# o# k# e# d#  # a# t#  # t# h# e#  # p# l# a# y# e# r#  # a# t# t# r# i# b# u# t# e# s#  # o# n#  # a#  # s# t# a# n# d# a# l# o# n# e#  # b# a# s# i# s#  # i# n#  # t# h# e#  # p# r# e# v# i# o# u# s#  # s# e# c# t# i# o# n# .#  #  # I# t# '# s#  # n# o# w#  # t# i# m# e#  # t# o#  # s# e# e#  # h# o# w#  # t# h# e# s# e#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # r# e# l# a# t# e#  # t# o#  # o# n# e#  # a# n# o# t# h# e# r#  # t# h# r# o# u# g# h#  # a#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x# .#  #  # W# e#  # d# o# n# '# t#  # r# e# a# l# l# y#  # n# e# e# d#  # G# a# m# e# I# D#  # h# e# r# e# ,#  # s# o#  # w# e#  # s# t# a# r# t#  # o# f# f#  # b# y#  # r# e# m# o# v# i# n# g#  # t# h# i# s#  # a# t# t# r# i# b# u# t# e# .#  #  # W# e#  # t# h# e# n#  # b# u# i# l# d#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# x#  # a# n# d#  # c# a# n#  # e# a# s# i# l# y#  # s# e# e#  # h# o# w#  # e# a# c# h#  # o# f#  # t# h# e#  # p# o# t# e# n# t# i# a# l#  # f# e# a# t# u# r# e# s#  # (# i# n# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# s# )#  # c# o# r# r# e# l# a# t# e#  # t# o#  # o# u# r#  # t# a# r# g# e# t#  # (# d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# )#  # i# n#  # *# *# L# e# a# g# u# e# I# n# d# e# x# *# *# ,#  # c# l# e# a# n# l# y#  # p# o# s# i# t# i# o# n# e# d#  # a# t#  # t# h# e#  # o# r# i# g# i# n#  # o# f#  # t# h# e#  # m# a# t# r# i# x# .

# In[None]

# Copy all df columns to new df, excluding GameID for easy matrix reading
df_for_r = df.copy(deep=True)
del df_for_r['GameID']

# Set figure style
plt.style.use('fivethirtyeight')

# Create figure
fig, axes = plt.subplots(nrows=1, ncols = 1, figsize = (14,10))
fig.suptitle('Attribute Relationships', fontsize=22, fontweight='bold')
# fig.subplots_adjust(top=0.95)

# Generate a mask to hide the upper triangle for a cleaner heatmap.  Less visual noise the better.
mask = np.zeros_like(df_for_r.corr(), dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Create correlation matrix heatma[]
r_matrix = df_for_r.corr().round(decimals=1)
sns.heatmap(r_matrix, mask=mask, square=True, cmap='YlGnBu', linewidths=.5, annot=True, fmt='g', 
            annot_kws={'size':10})
axes.set_title('     Correlation Matrix\n')
plt.show()

# I#  # r# e# a# l# l# y#  # l# o# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # m# a# t# r# i# c# e# s#  # b# e# c# a# u# s# e#  # o# f#  # t# h# e#  # c# l# e# a# r# ,#  # c# o# n# c# i# s# e# ,#  # a# n# d#  # c# l# e# a# n#  # m# e# s# s# a# g# e#  # t# h# e# y# '# r# e#  # o# f# t# e# n#  # a# c# c# o# m# p# a# n# i# e# d#  # b# y# .#  #  # A# f# t# e# r#  # d# o# i# n# g#  # s# o# m# e#  # p# r# e# p#  # w# o# r# k#  # i# n#  # t# h# e#  # c# o# d# e#  # t# o#  # m# i# n# i# m# i# z# e#  # n# o# i# s# e# ,#  # w# e#  # c# a# n#  # s# e# e#  # h# o# w#  # e# a# c# h#  # o# f#  # t# h# e#  # a# t# t# r# i# b# u# t# e# s#  # w# i# t# h# i# n#  # t# h# e#  # d# a# t# a#  # (# o# u# t# l# i# e# r# s#  # i# n# c# l# u# d# e# d# )# ,#  # a# r# e#  # p# o# s# i# t# i# v# e# l# y#  # o# r#  # n# e# g# a# t# i# v# e# l# y#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # *# *# L# e# a# g# u# e# I# n# d# e# x# .# *# *#  #  # 
# 
# P# o# s# i# t# i# v# e#  # v# a# l# u# e# s#  # c# l# o# s# e# s# t#  # t# o#  # 1#  # m# e# a# n#  # a#  # s# t# r# o# n# g#  # c# o# r# r# e# l# a# t# i# o# n# ,#  # w# h# e# r# e#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # s# h# a# r# i# n# g#  # t# h# a# t#  # c# o# r# r# e# l# a# t# i# o# n#  # m# e# t# r# i# c#  # i# n# c# r# e# a# s# e#  # o# r#  # d# e# c# r# e# a# s# e#  # t# o# g# e# t# h# e# r# .#  #  # T# h# e#  # r# e# v# e# r# s# e#  # h# o# l# d# s#  # t# r# u# e#  # f# o# r#  # n# e# g# a# t# i# v# e#  # v# a# l# u# e# s# ,#  # w# h# e# r# e#  # i# f#  # o# n# e#  # v# a# r# i# a# b# l# e#  # i# n# c# r# e# a# s# e# s# ,#  # t# h# e#  # o# t# h# e# r#  # v# a# r# i# a# b# l# e#  # d# e# c# r# e# a# s# e# s# .# 
# 
# H# e# r# e# ,#  # i# t#  # l# o# o# k# s#  # l# i# k# e#  # t# h# e#  # d# a# r# k# e# s# t#  # b# l# u# e#  # b# o# x# e# s#  # i# n#  # (# A# P# M# ,#  # S# e# l# e# c# t# B# y# H# o# t# K# e# y# s# ,#  # A# s# s# i# g# n# T# o# H# o# t# K# e# y# s# ,#  # N# u# m# b# e# r# O# f# P# A# C# s# )#  # a# n# d#  # t# h# e#  # l# i# g# h# t# e# s# t#  # y# e# l# l# o# w#  # b# o# x# e# s#  # (# G# a# p# B# e# t# w# e# e# n#  # P# A# C# s# ,#  # A# c# t# i# o# n# L# a# t# e# n# c# y# )#  # h# a# v# e#  # t# h# e#  # s# t# r# o# n# g# e# s# t#  # a# s# s# o# c# i# a# t# i# o# n# s#  # w# i# t# h#  # *# *# L# e# a# g# u# e# I# n# d# e# x# .# *# *#  #  #  #  # S# o#  # p# l# a# y# e# r# s#  # w# i# t# h#  # g# r# e# a# t# e# r#  # *# *# A# P# M# *# *#  # (# A# c# t# i# o# n# s#  # P# e# r#  # M# i# n# u# t# e# )#  # t# e# n# d#  # t# o#  # b# e#  # a# s# s# o# c# i# a# t# e# d#  # w# i# t# h#  # a#  # h# i# g# h# e# r#  # *# *# L# e# a# g# u# e# I# n# d# e# x# .# *# *# 
# 
# H# o# w# e# v# e# r# ,#  # a# n# y#  # s# t# a# t# s#  # 1# 0# 1#  # t# u# t# o# r# i# a# l#  # w# i# l# l#  # s# a# y#  # t# h# a# t#  # c# o# r# r# e# l# a# t# i# o# n#  # d# o# e# s# n# '# t#  # n# e# c# e# s# s# a# r# i# l# y#  # i# m# p# l# y#  # c# a# u# s# a# t# i# o# n#  # -#  # a# n# d#  # t# h# e#  # s# a# m# e#  # h# o# l# d# s#  # t# r# u# e#  # h# e# r# e# .#  #  # B# u# t# ,#  # a# t#  # t# h# e#  # s# a# m# e#  # t# i# m# e# ,#  # I#  # d# o#  # b# e# l# i# e# v# e#  # t# h# a# t#  # A# P# M#  # c# o# n# t# r# i# b# u# t# e# s#  # t# o#  # h# o# w#  # l# i# k# e# l# y#  # a#  # p# l# a# y# e# r#  # i# s#  # t# o#  # w# i# n#  # a#  # m# a# t# c# h# ,#  # u# l# t# i# m# a# t# e# l# y#  # t# r# a# n# s# l# a# t# i# n# g#  # t# o#  # h# o# w#  # h# i# g# h#  # o# f#  # a#  # *# *# L# e# a# g# u# e# I# n# d# e# x# *# *#  # a# n#  # S# C# 2#  # p# l# a# y# e# r#  # f# i# n# d# s#  # h# i# m# s# e# l# f#  # i# n# .

# In[None]

lst_best_features = ['TotalHours', 'APM','SelectByHotkeys', 'AssignToHotkeys', 'NumberOfPACs',
                     'GapBetweenPACs', 'ActionLatency']

# ## ##  # M# o# d# e# l#  # C# r# e# a# t# i# o# n#  # (# t# o#  # b# e#  # c# o# n# t# i# n# u# e# d# )

# !# [# e# s# t# i# m# a# t# o# r# ]# (# h# t# t# p# :# /# /# s# c# i# k# i# t# -# l# e# a# r# n# .# o# r# g# /# s# t# a# b# l# e# /# _# s# t# a# t# i# c# /# m# l# _# m# a# p# .# p# n# g# )

# In[None]

df.head()

# In[None]

# SelectKBest Work

# In[None]

x_features = df.copy(deep=True)
x_features = x_features[lst_best_features]
y_target = df['LeagueIndex']
x_features.head()

# In[None]

lin_model = svm.LinearSVC()
lin_model = lin_model.fit(x_features, y_target)
print('SVM Score:', lin_model.score(x_features, y_target))
predicted = lin_model.predict(x_features)
print(sorted(pd.unique(predicted)))

# In[None]

from sklearn.naive_bayes import GaussianNB
# Naive Bayes Model
bayes_model = GaussianNB()

bayes_model.fit(x_features, y_target)
bayes_model.score(x_features, y_target)

# In[None]

log_model = LogisticRegression()
log_model = log_model.fit(x_features, y_target)
log_model.score(x_features, y_target)
print('Log Score:', log_model.score(x_features, y_target)) 
predicted = log_model.predict(x_features) 
print(sorted(pd.unique(predicted)))

# In[None]

test_sizes = [0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_features, y_target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/319001.npy", { "accuracy_score": score })

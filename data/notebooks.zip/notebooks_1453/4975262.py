import pandas as pd
# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# In[None]

df = pd.read_csv('../input/indian_liver_patient.csv')
df.head(1)

# In[None]

df.shape

# In[None]

df.info()

# In[None]

# what is dataset  - Target column 
# 0 - no issue, 1 - disease 
df['Dataset'].unique()

# In[None]

# loooking for statistical properties 
df.describe()

# In[None]

# entire dataset is numerical except gender 
# gender can be labelencoded 
from sklearn.preprocessing import LabelEncoder

# create an instance of the labelencoder
le = LabelEncoder()

# apply 
df['Gender'] = le.fit_transform(df['Gender'])

# In[None]

df.head()

# In[None]

# how many na values in one column
df['Albumin_and_Globulin_Ratio'].isna().sum() # 4 

# In[None]

df['Albumin_and_Globulin_Ratio'].hist()

# fillna with mean
df['Albumin_and_Globulin_Ratio'].fillna(df['Albumin_and_Globulin_Ratio'].mean(), inplace = True)

# In[None]

# corr matrix 
corr = df.corr()
sns.heatmap(corr)

# In[None]

X = df.drop(['Dataset'], axis = 1)
X.shape

# In[None]

Y = df['Dataset']
Y.shape

# In[None]

# apply logistic regression 

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4975262.npy", { "accuracy_score": score })

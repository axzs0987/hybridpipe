import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score , confusion_matrix

# In[None]

data = pd.read_csv("../input/logistic-regression/Social_Network_Ads.csv")
data.head(10)

# In[None]

data.info()

# In[None]

data.describe()

# In[None]

l = LabelEncoder()
data["Gender"] = l.fit_transform(data["Gender"])

# In[None]

data.head(5)

# In[None]

plt.figure(figsize=(10,10))
sns.heatmap(data.corr(),annot=True,cmap='inferno')

# In[None]

data.drop(labels = ['User ID','Gender'], axis = 1, inplace = True)
data.info()

# In[None]

sum(data.duplicated())

# In[None]

data.drop_duplicates(keep = False, inplace = True)

# In[None]

sum(data.duplicated())

# In[None]

plt.figure(figsize=(20, 12))

plt.subplot(3,3,1)
sns.boxplot(data['Age'],color='yellow')
plt.subplot(3,3,2)
sns.boxplot(data['EstimatedSalary'], color='yellow')

plt.show()

# In[None]

plt.figure(figsize=(6, 4))
sns.countplot('Purchased', data=data)
plt.title('Class Distributions')
plt.show()

# In[None]

x = data.iloc[:,:-1].values
y = data.iloc[:,-1].values

# In[None]

from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/11548372.npy", { "accuracy_score": score })

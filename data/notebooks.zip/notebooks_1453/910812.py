import pandas as pd
# ##  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  # A# l# l#  # N# e# c# e# s# s# a# r# y#  # l# i# b# r# a# r# i# e# s#  # o# f#  # s# c# i# k# i# t# -# l# e# a# r# n

# In[None]

import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score

# ##  # R# e# a# d# i# n# g#  # C# S# V#  # D# a# t# a#  # s# e# t#  

# In[None]

df=pd.read_csv("../input/security.csv")
df.shape

# ##  # C# o# n# v# e# r# t# i# n# g#  # s# t# r# i# n# g#  # V# a# l# u# e# s#  # o# f#  # B# e# l# o# w#  # C# o# l# u# m# n# s#  # i# n# t# o#  # N# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s#  # u# s# i# n# g#  # P# a# n# d# a# s#  # L# i# b# r# a# r# y

# In[None]

#Using Pandas get dummies function to convert the string columns into numerics

new_df=pd.get_dummies(df, columns=['DOMAIN_NAME','URL','WHOIS_COUNTRY','WHOIS_STATE_CITY','SERVER'])

# ##  # M# e# t# h# o# d#  # t# o#  # i# n# c# r# e# a# s# e#  # t# h# e#  # d# i# s# p# l# a# y#  # s# i# z# e#  # i# n#  # j# y# p# u# t# e# r#  # N# o# t# e# b# o# o# k

# In[None]

pd.options.display.max_seq_items=100000
pd.options.display.max_seq_items

# ##  # C# o# n# v# e# r# t# i# n# g#  # t# h# e#  # L# a# b# e# l#  # ## B# e# n# i# g# n# a#  # 0#  # a# n# d#  # M# a# l# i# g# n# a#  # 1#  # i# n# t# o#  # c# a# t# e# g# o# r# y#  # d# a# t# a

# In[None]

new_df['TIPO']= new_df['TIPO'].astype('category')

# ##  # S# a# v# i# n# g#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# l# u# e#  # i# n# t# o#  # n# e# w#  # C# o# l# u# m# n#  # c# a# l# l# e# d#  # T# a# r# g# e# t

# In[None]

new_df['Target']=new_df['TIPO'].cat.codes
new_df.head()

# ##  # C# r# e# a# t# i# n# g#  # D# u# p# l# i# c# a# t# e#  # D# a# t# a#  # f# r# a# m# e#  

# In[None]

target_df=new_df
target_df.columns

# ##  # D# r# o# p# i# n# g#  # t# h# e#  # c# o# l# u# m# n# s#  # t# h# a# t#  # g# i# v# e# s#  # l# e# s# s#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # t# h# e#  # d# a# t# a#  # s# e# t

# In[None]

new_df=new_df.drop(['TIPO','CHARSET','CACHE_CONTROL','Target'], axis=1)


# ##  # S# t# o# r# i# n# g#  # a# l# l#  # t# h# e#  # c# o# l# u# m# n# s#  # o# f#  # N# e# w#  # d# a# t# a#  # f# r# a# m# e#  # i# n# t# o#  # v# a# r# i# a# b# l# e#  # F# e# t# a# u# r# e# _# C# o# l# s#  # t# o#  # m# a# k# e#  # F# e# a# t# u# r# e#  # m# a# t# r# i# x

# In[None]

feature_cols=new_df.columns

# In[None]

x=new_df[feature_cols]
x.shape

# ##  # T# a# r# g# e# t#  # m# a# t# r# i# x

# In[None]

#Benigna       0
#Maligna       1
y=target_df['Target']
y.shape

# ##  # s# p# l# i# t# t# i# n# g#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# n# t# o#  # t# w# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # T# e# s# t# i# n# g#  # D# a# t# a# .

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/910812.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import xgboost as xgb
import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

# In[None]

dataset = pd.read_csv('../input/adult-census-income/adult.csv') #read file with data set
# Let's see first 10 lines of our table just to know whith what we will work
dataset.head(10)

# In[None]

# We can see that there are 32561 instances(lines) and 15 attributes(columns) in the data set.
dataset.shape

# In[None]

# This is all columns from data set
dataset.columns

# In[None]

# We can see that our table has missing values "?"(for example line 0, line 2)
# We have to correct it, because if not our program will think that person 0 and person 2 
# have the same workclass which call "?" and have the same occupation also "?",
# I guess it is not true so I just change all "?" to NaN value
dataset[dataset == "?"] = np.nan
dataset.head(3)

# In[None]

# Ok now Thre is NaN 

# In[None]

# In this part of code we change NaN with the most frequent value
for col in dataset.columns:
    dataset[col].fillna(dataset[col].mode()[0], inplace=True)
dataset.head(10)

# In[None]

dataset.dtypes

# In[None]

# Above we see all types of columns I think "age" don't need such big number like int64,
# so I chage to smaller number int8
dataset.astype({'age':'int8', 'education.num':'int8','hours.per.week':'int8'}).dtypes


# In[None]

# Classify columns to numerical group (comparable values) and categorical group (non comparable group)
CATEGORICAL = ['workclass', 'education', 'marital.status', 'occupation', 'relationship', 'race', 'sex', 'native.country']
NUMERICAL = ['age', 'fnlwgt', 'education.num', 'capital.gain', 'capital.loss', 'hours.per.week']

# In[None]

# We do this becouse it is not comfortable to work with string values and we will hash(encrypt) it to numvers,
# the same values correspond to the same number, the difference values correspond to the different numbers
# we use function fit_transform to do this

# In[None]

for i in CATEGORICAL:
    dataset[i] = LabelEncoder().fit_transform(dataset[i])

# In[None]

# Lts's see what happen, there are only numbers now
dataset.sample(10)

# In[None]

# We do the same with 'income' but manually
dataset['income'] = dataset['income'].apply(lambda x: 0 if(x == '<=50K') else 1)


# In[None]

# look 'income' was changed
dataset.sample(5)

# In[None]

# Divide the table into input and output,  
y = dataset.pop('income') #output
X = dataset.copy() #input
# it is seems like function in math y(x), so we have x and must find y 

# In[None]

# Split data into separate training and test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7255288.npy", { "accuracy_score": score })

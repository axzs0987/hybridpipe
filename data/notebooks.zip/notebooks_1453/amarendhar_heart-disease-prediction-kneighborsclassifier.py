import numpy as np 
import pandas as pd 
import os
#print(os.listdir("../input"))
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import os
#print(os.listdir("../input"))
df = pd.read_csv("../input/heart.csv")
df.head()
df.target.value_counts()
#sns.countplot(x="target", data=df, palette="bwr")
#plt.show()
countNoDisease = len(df[df.target == 0])
countHaveDisease = len(df[df.target == 1])
print("percentage of persons haven't heart disease: {:.2f}%".format((countNoDisease/(len(df.target))*100)))
print("percentage have disease: {:.2f}%".format((countHaveDisease / (len(df.target))*100)))
df.target.unique()
y = df.target.values
x_data = df.drop(['target'],axis=1)
x = (x_data - np.min(x_data)) / (np.max(x_data)-np.min(x_data)).values
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=18)
#knn.fit(x_train, y_train)
#prediction = knn.predict(x_test)
#print("{}-NN Score : {}".format(18,knn.score(x_test,y_test)))
score_list=[]
for each in range(5,20):
    knn2=KNeighborsClassifier(n_neighbors=each)
#    knn2.fit(x_train,y_train)
#    score_list.append(knn2.score(x_test,y_test))
    
#plt.plot(range(5,20),score_list)
#plt.show()



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amarendhar_heart-disease-prediction-kneighborsclassifier.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amarendhar_heart-disease-prediction-kneighborsclassifier/testY.csv",encoding="gbk")


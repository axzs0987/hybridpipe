import pandas as pd
# In[None]

#importing the required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[None]

#Importing the dataset
data = pd.read_csv("../input/social-network-ads/Social_Network_Ads.csv")
data.head(5)

#  # T# h# e# m# e#  # o# f#  # t# h# e#  # p# r# o# j# e# c# t# :#  # G# i# v# e# n#  # a# n#  # i# n# p# u# t#  # *# *# A# g# e# *# *#  # a# n# d#  # a# n#  # *# *# E# s# t# i# m# a# t# e# d# S# a# l# a# r# y# *# *#  # w# e#  # h# a# v# e#  # t# o#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a#  # c# u# s# t# o# m# e# r#  # w# i# l# l#  # *# P# U# R# C# H# A# S# E# *#  # o# r#  # *# N# O# T#  # P# U# R# C# H# A# S# E# *

# In[None]

X=data.iloc[:,2:4].values #Age and EstimatedSalary are our primary requirements (storing them as a NUMPY ARRAY)
X.shape

# In[None]

y=data.iloc[:,-1]  #IF x is the input(Age and EstimatedSalary), then y is the output that is the customer purcases the product or not.
y.shape

# In[None]

#importing the train_test_split module to train a module with 80% data and testing with the rest of the data
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6456754.npy", { "accuracy_score": score })

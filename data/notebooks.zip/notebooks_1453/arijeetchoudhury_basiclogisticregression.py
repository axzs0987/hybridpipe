import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
iris_data = pd.read_csv('/kaggle/input/iris-dataset/Iris.csv')
print(iris_data.shape)
print(iris_data.head())
iris_data.drop('Id',inplace=True,axis=1)
print(iris_data.head())
print(iris_data['Species'].value_counts())
iris_data.isnull().sum()
iris_data_shuffled = iris_data.sample(frac=1).reset_index(drop=True)
print(iris_data_shuffled)
train_x = iris_data_shuffled.drop('Species',axis=1)
print(train_x.head())
train_y = iris_data_shuffled['Species']
print(train_y.head())
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
labels = le.fit_transform(train_y)
print(labels)
X = train_x.values
y = labels
print(X.shape)
print(y.shape)
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
print('no. of training samples:',len(X_train))
print('no. of testing samples:',len(X_test))
lr_model = LogisticRegression(multi_class='multinomial')
#lr_model.fit(X_train,y_train)
#y_pred = lr_model.predict(X_test)
#print(y_pred)
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix
#print('test accuracy:',accuracy_score(y_test,y_pred))
#print(classification_report(y_test,y_pred))
#print(confusion_matrix(y_test,y_pred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/arijeetchoudhury_basiclogisticregression.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/arijeetchoudhury_basiclogisticregression/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/arijeetchoudhury_basiclogisticregression/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/arijeetchoudhury_basiclogisticregression/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/arijeetchoudhury_basiclogisticregression/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/arijeetchoudhury_basiclogisticregression/testY.csv",encoding="gbk")


import pandas as pd
# ##  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  # T# e# l# c# o#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n# 
# ##  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  #  # F# o# c# u# s# e# d#  # c# u# s# t# o# m# e# r#  # r# e# t# e# n# t# i# o# n#  # p# r# o# g# r# a# m# s

# ## ##  # O# B# J# E# C# T# I# V# E# :#  # P# r# e# d# i# c# t#  # c# h# u# r# n#  # t# o#  # r# e# t# a# i# n#  # c# u# s# t# o# m# e# r# s# .#  # 
# 1# .#  # C# a# l# c# u# l# a# t# i# o# n#  # o# f#  # C# h# u# r# n#  # P# r# o# b# a# b# i# l# i# t# y#  # a# n# d#  # r# a# n# k# i# n# g#  # o# f#  # C# u# s# t# o# m# e# r# I# d# s#  # b# a# s# e# d#  # o# n#  # t# h# e#  # P# r# o# b# (# C# h# u# r# n# )# 
# 2# .#  # R# a# n# k# i# n# g#  # o# f#  # F# e# a# t# u# r# e# s

# ##  # D# a# t# a#  # P# r# e# -# P# r# o# c# e# s# s# i# n# g

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# ## ## ## ##  # G# e# t#  # t# h# e#  # d# a# t# a

# In[None]

data = pd.read_csv("../input/WA_Fn-UseC_-Telco-Customer-Churn.csv")

# ##  # C# o# n# t# e# n# t#  # A# n# a# l# y# s# i# s

# In[None]

data.head()

# In[None]

data.shape

# In[None]

data.info()                                                  ## data type of each column, missing values, shape of table..

# ## ## ## ##  # C# o# n# v# e# r# t#  # T# o# t# a# l# C# h# a# r# g# e# s#  # c# o# l# u# m# n#  # t# o#  # n# u# m# e# r# i# c

# In[None]

data.TotalCharges=pd.to_numeric(data.TotalCharges,errors='coerce')

# ##  # U# n# i# v# a# r# i# a# t# e#  # A# n# a# l# y# s# i# s

# ## ## ##  # U# n# i# v# a# r# i# a# t# e#  # A# n# a# l# y# s# i# s#  # f# o# r#  # N# o# n# -# N# u# m# e# r# i# c# /# C# a# t# e# g# o# r# i# c# a# l#  # t# y# p# e#  # V# a# r# i# a# b# l# e# s

# In[None]

data.describe(include=[np.object])

# ## ## ## ##  # W# h# a# t#  # a# r# e#  # t# h# e#  # l# e# v# e# l# s#  # a# n# d#  # i# t# s#  # d# i# s# t# r# i# b# u# t# i# o# n#  # w# i# t# h# i# n#  # e# a# c# h#  # C# a# t# e# g# o# r# i# c# a# l#  # C# o# l# u# m# n

# In[None]

col_names=list(data.columns)

# In[None]

col_names.remove('customerID')

# In[None]

col_names.remove('tenure')
col_names.remove('MonthlyCharges')
col_names.remove('TotalCharges')

# In[None]

col_names

# In[None]

for i in col_names:
    j=data[i].value_counts()
    print('-----------------------------------')
    print(j)

# In[None]

for m in col_names:
    data[m].hist()
    plt.show()

# ## ## ##  # U# n# i# v# a# r# i# a# t# e#  # A# n# a# l# y# s# i# s#  # o# f#  # t# h# e#  # N# u# m# e# r# i# c#  # t# y# p# e#  # V# a# r# i# a# b# l# e# s

# In[None]

data.describe(include=[np.number])

# ##  # M# i# s# s# i# n# g#  # V# a# l# u# e#  # T# r# e# a# t# m# e# n# t

# ## ## ## ##  # W# h# e# r# e#  # a# r# e#  # t# h# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# ?# ?

# In[None]

data.info()                                     ## Check the Missing Value

# In[None]

data.isnull().sum()                               ## Check the number missing value

# ## ## ## ##  # R# e# p# l# a# c# e#  # /# I# m# p# u# t# e#  # t# h# e#  # M# i# s# s# i# n# g#  # V# a# l# u# e# .

# In[None]

## Calculate the median of the column

q=data.TotalCharges.quantile([0.1,0.5,0.9])

# In[None]

type(q)                                                                                 ## one Dimensional labelled Array

# In[None]

q

# In[None]

TC_median=q[.5]

# In[None]

TC_median

# In[None]

#data.loc[null_value].index             ## Indexes of the Missing Values

# In[None]

column_names=list(data.columns)
column_names

# In[None]

column_names[18:20]

# In[None]

plt.scatter(data.MonthlyCharges,data.TotalCharges, alpha=0.1)
plt.xlabel(column_names[18])
plt.ylabel(column_names[19])

# In[None]

plt.scatter(data.tenure,data.TotalCharges, alpha=0.01)
plt.xlabel(column_names[5])
plt.ylabel(column_names[19])

# ## ## ## ##  # R# e# p# l# a# c# e#  # t# h# e#  # m# i# s# s# i# n# g#  # V# a# l# u# e#  # w# i# t# h#  # M# e# d# i# a# n

# In[None]

data.TotalCharges =  data.TotalCharges.fillna(TC_median)           

# In[None]

data.info()

# ##  # O# U# T# L# I# E# R#  # T# r# e# a# t# m# e# n# t

# In[None]

data.boxplot(column=['MonthlyCharges','tenure'])

# In[None]

data.boxplot(column='TotalCharges')

# In[None]

sns.kdeplot(data.MonthlyCharges)

# ## ##  # C# o# r# r# e# l# a# t# i# o# n#  # A# n# a# l# y# s# i# s

# In[None]

print(data[['MonthlyCharges','TotalCharges','tenure']].corr())

# In[None]

print(data.corr())

# ## ##  # C# r# e# a# t# e#  # D# u# m# m# y#  # V# a# r# i# a# b# l# e# s

# In[None]

data_copy=data
data_copy=data_copy.drop(columns=['customerID', 'TotalCharges'])

# In[None]

data_dummy=pd.get_dummies(data_copy,drop_first=True)

# In[None]

len(data_dummy.columns)

# In[None]

data_dummy.head()

# ##  # B# u# i# l# d# i# n# g#  # a#  # P# r# e# d# i# c# t# i# v# e#  # M# o# d# e# l

# ## ## ## ##  # P# R# E# D# I# C# T# O# R# S

# In[None]

X=data_dummy.iloc[:,0:29]

# ## ## ## ##  # T# A# R# G# E# T#  # V# A# R# I# A# B# L# E

# In[None]

y=data_dummy.iloc[:,29]

# ## ## ##  # T# e# s# t#  # T# r# a# i# n#  # S# p# l# i# t

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1440342.npy", { "accuracy_score": score })

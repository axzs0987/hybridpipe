import pandas as pd
# L# o# a# d# i# n# g#  # D# a# t# a# :

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data = pd.read_csv("../input/predicting-a-pulsar-star/pulsar_stars.csv")
# Any results you write to the current directory are saved as output.

# L# e# t# s#  # s# p# l# i# t#  # o# u# r#  # d# a# t# a#  # i# n#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # s# u# b# s# e# t# s#  #  # 
# *# *# y# *# *#  # i# s#  # t# a# r# g# e# t#  # d# a# t# a#  # -#  # i# f#  # o# b# j# e# c# t#  # i# s#  # a#  # p# u# l# s# a# r#  # s# t# a# r#  #  # 
# *# *# X# *# *#  # i# s#  # o# b# s# e# r# v# a# b# l# e#  # v# a# r# i# a# b# l# e# s

# In[None]

from sklearn.model_selection import train_test_split

X = np.array(data.drop(columns=['target_class']))
y = np.array(data['target_class'])

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6553202.npy", { "accuracy_score": score })

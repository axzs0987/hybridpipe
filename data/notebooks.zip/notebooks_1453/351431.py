import pandas as pd
# E# v# a# l# u# a# t# i# n# g#  # a#  # c# a# r#  # u# s# i# n# g#  # 6#  # v# a# r# i# a# b# l# e# s# .#  # D# a# t# a#  # A# n# a# l# y# s# i# s# ,#  # D# a# t# a#  # v# i# s# u# a# l# i# z# a# t# i# o# n# ,#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n#  # a# n# d#  # R# e# d# u# c# t# i# o# n# ,#  # K# -# N# e# a# r# e# s# t#  # N# e# i# g# h# b# o# r# (# K# N# N# )#  # e# s# t# i# m# a# t# o# r# /# m# o# d# e# l# .#  # M# u# l# t# i# l# a# y# e# r#  # P# e# r# c# e# p# t# r# o# n# (# D# e# e# p#  # L# e# a# r# n# i# n# g# /# A# r# t# i# f# i# c# i# a# l#  # N# e# u# r# a# l#  # N# e# t# w# o# r# k# )# .#  # D# a# t# a# s# e# t#  # s# p# l# i# t# t# e# d#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # d# a# t# a#  # i# n#  # o# r# d# e# r#  # t# o#  # a# v# o# i# d#  # o# v# e# r# f# i# t# t# i# n# g# .

# In[None]

import numpy
import pandas
from keras.utils import np_utils
import matplotlib.pyplot as plt
from keras.utils import to_categorical


from sklearn.preprocessing import LabelEncoder
from sklearn.cross_validation import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score



from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.constraints import maxnorm



# fix random seed for reproducibility
seed = 7
numpy.random.seed(seed)

# In[None]

# load dataset
dataframe = pandas.read_csv(r"../input/car_evaluation.csv")

# Assign names to Columns
dataframe.columns = ['buying','maint','doors','persons','lug_boot','safety','classes']

# Encode Data
dataframe.buying.replace(('vhigh','high','med','low'),(1,2,3,4), inplace=True)
dataframe.maint.replace(('vhigh','high','med','low'),(1,2,3,4), inplace=True)
dataframe.doors.replace(('2','3','4','5more'),(1,2,3,4), inplace=True)
dataframe.persons.replace(('2','4','more'),(1,2,3), inplace=True)
dataframe.lug_boot.replace(('small','med','big'),(1,2,3), inplace=True)
dataframe.safety.replace(('low','med','high'),(1,2,3), inplace=True)
dataframe.classes.replace(('unacc','acc','good','vgood'),(1,2,3,4), inplace=True)

# In[None]

print("dataframe.head: ", dataframe.head())

# In[None]

print("dataframe.describe: ", dataframe.describe())

# In[None]

plt.hist((dataframe.classes))


# S# a# m# p# l# e# s#  # d# i# s# t# r# i# b# u# t# e# d#  # a# m# o# n# g#  # '# C# l# a# s# s# e# s# '#  # h# a# v# e#  # a#  # p# o# s# i# t# i# v# e#  # s# k# e# w# ,#  # w# i# t# h#  # m# a# j# o# r# i# t# y#  # b# e# i# n# g#  # i# n#  # t# h# e#  # '# u# n# a# c# c# '# (# u# n# a# c# c# e# p# t# a# b# l# e# )# ,# '# a# c# c# '# (# a# c# c# e# p# t# a# b# l# e# )#  # o# u# t# p# u# t#  # c# l# a# s# s

# In[None]

dataframe.hist()

# E# v# e# r# y#  # i# n# p# u# t#  # f# e# a# t# u# r# e#  # s# e# e# m# s#  # e# v# e# n# l# y#  # d# i# s# t# r# i# b# u# t# e# d# ,#  # i# m# p# l# y# i# n# g#  # t# h# e# i# r#  # m# u# l# t# i# v# a# r# i# a# t# e#  # i# n# t# e# r# e# l# a# t# i# o# n#  # i# s#  # w# h# a# t#  # c# a# u# s# e# s#  # t# h# e#  # s# k# e# w#  # i# n#  # t# h# e#  # '# c# l# a# s# s# e# s# '#  

# In[None]

dataset = dataframe.values


X = dataset[:,0:6]
Y = numpy.asarray(dataset[:,6], dtype="S6")


# Split Data to Train and Test
from sklearn.model_selection import train_test_split
X_Train, X_Test, Y_Train, Y_Test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_Train, Y_Train)
y_pred = model.predict(X_Test)
score = accuracy_score(Y_Test, y_pred)
import numpy as np
np.save("prenotebook_res/351431.npy", { "accuracy_score": score })

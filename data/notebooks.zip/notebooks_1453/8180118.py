import pandas as pd
# ##  # L# I# V# E# R#  # D# I# S# E# A# S# E#  # P# R# E# D# I# C# T# I# O# N

# *# *# I# n#  # t# h# i# s#  # p# r# o# j# e# c# t# ,#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e#  # t# h# e#  # I# n# d# i# a# n#  # L# i# v# e# r#  # P# a# t# i# e# n# t#  # R# e# c# o# r# d# s#  # d# a# t# a# s# e# t#  # f# r# o# m#  # k# a# g# g# l# e# .# *# *

# *# *# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a#  # p# a# t# i# e# n# t#  # h# a# s#  # l# i# v# e# r#  # d# i# s# e# a# s# e#  # o# r#  # n# o# t#  # b# a# s# e# d#  # o# n#  # c# e# r# t# a# i# n#  # f# e# a# t# u# r# e# s# .# *# *

# *# *# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # c# h# e# c# k#  # w# i# t# h#  # t# h# e#  # t# o# t# a# l#  # p# r# o# t# e# i# n# s# ,# a# l# b# u# m# i# n#  # e# t# c#  # w# h# e# t# h# e# r#  # i# t#  # i# s#  # a# s# s# c# o# i# a# t# e# d#  # w# i# t# h#  # d# i# s# e# a# s# e#  # o# r#  # n# o# t# .# *# *

# *# *# I# m# p# o# r# t# i# n# g#  # t# h# e#  # N# e# c# e# s# s# a# r# y#  # L# i# b# r# a# r# i# e# s# :# *# *

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# *# *# F# o# r#  # t# h# e#  # p# u# r# p# o# s# e#  # o# f#  # p# r# e# d# i# c# t# i# o# n# ,#  # w# e#  # n# e# e# d#  # t# o#  # i# m# p# o# r# t#  # m# o# r# e#  # l# i# b# r# a# r# i# e# s# .#  # A# s#  # w# e#  # m# o# v# e#  # o# n# ,#  # w# e#  # w# i# l# l#  # i# m# p# o# r# t#  # t# h# e# m# .# *# *

# *# *# R# e# a# d# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t# :# *# *

# In[None]


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
patients=pd.read_csv('/kaggle/input/indian-liver-patient-records/indian_liver_patient.csv')

# In[None]

patients.head()

# In[None]

patients.shape

# In[None]

patients.info()

# In[None]

patients.describe().T

# *# *# S# o#  # t# h# e# r# e#  # a# r# e#  # 5# 8# 3#  # r# o# w# s#  # a# n# d#  # 1# 1#  # c# o# l# u# m# n# s#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t# .# *# *

# *# *# L# e# t#  # u# s#  # m# a# k# e#  # t# h# e#  # G# e# n# d# e# r#  # c# o# l# u# m# n#  # i# n# t# o#  # n# u# m# e# r# i# c# a# l#  # f# o# r# m# a# t# :# *# *

# In[None]

patients['Gender']=patients['Gender'].apply(lambda x:1 if x=='Male' else 0)

# In[None]

patients.head()

# *# *# H# e# r# e#  # t# h# e# r# e#  # i# s#  # a#  # c# o# l# u# m# n#  # n# a# m# e# d#  # D# a# t# a# s# e# t#  # w# h# i# c# h#  # h# a# s#  # t# w# o#  # v# a# l# u# e# s# .#  # H# e# r# e#  # o# n# e#  # o# f#  # t# h# e#  # v# a# l# u# e#  # s# y# m# b# o# l# i# s# e# s#  # t# h# a# t#  # t# h# e#  # p# a# t# i# e# n# t#  # h# a# s#  # 
# d# i# s# e# a# s# e#  # a# n# d#  # t# h# e#  # o# t# h# e# r#  # v# a# l# u# e#  # s# y# m# b# o# l# i# s# e# s#  # t# h# a# t#  # t# h# e#  # p# a# t# i# e# n# t#  # h# a# s#  # n# o#  # d# i# s# e# a# s# e# .# *# *

# *# *# L# e# t#  # u# s#  # c# h# e# c# k#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # u# s# i# n# g#  # a#  # c# o# u# n# t# p# l# o# t# .# *# *

# In[None]

patients['Gender'].value_counts().plot.bar(color='peachpuff')
plt.show()

# *# *# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # g# r# a# p# h# ,#  # w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # N# u# m# b# e# r#  # o# f#  # m# a# l# e# s#  # a# r# e#  # m# o# r# e#  # t# h# a# n#  # t# h# e#  # N# u# m# b# e# r#  # o# f#  # f# e# m# a# l# e# s# .# *# *

# *# *# L# e# t#  # u# s#  # c# h# e# c# k#  # t# h# e#  # c# o# u# n# t# p# l# o# t#  # o# f#  # o# u# r#  # D# a# t# a# s# e# t#  # c# o# l# u# m# n# :# *# *

# In[None]

patients['Dataset'].value_counts().plot.bar(color='blue')
plt.show()

# *# *# L# e# t#  # u# s#  # c# h# e# c# k#  # f# o# r#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s# :# *# *

# In[None]

patients.isnull().sum()

# *# *# W# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # t# h# e# r# e#  # a# r# e#  # 4#  # n# u# l# l#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # A# l# b# u# m# i# n#  # a# n# d#  # G# l# o# b# u# l# i# n#  # R# a# t# i# o#  # c# o# l# u# m# n# .# *# *

# *# *# L# e# t#  # u# s#  # f# i# l# l#  # t# h# e# s# e#  # n# u# l# l#  # v# a# l# u# e# s#  # b# y#  # i# m# p# u# t# i# n# g#  # t# h# e#  # m# e# a# n#  # o# f#  # t# h# a# t#  # c# o# l# u# m# n# .# *# *

# In[None]

patients['Albumin_and_Globulin_Ratio'].mean()

# In[None]

patients=patients.fillna(0.94)

# *# *# Y# e# s# !#  # N# o# w#  # w# e#  # h# a# v# e#  # f# i# l# l# e# d#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # w# i# t# h#  # t# h# e#  # m# e# a# n#  # o# f#  # t# h# a# t#  # c# o# l# u# m# n# .# *# *#  

# In[None]

patients.isnull().sum()

# *# *# S# o#  # w# e#  # h# a# v# e#  # r# e# m# o# v# e# d#  # a# l# l#  # t# h# e#  # n# u# l# l#  # v# a# l# u# e# s#  # a# n# d#  # w# e#  # a# r# e#  # r# e# a# d# y#  # t# o#  # g# o#  # !# *# *

# *# *# L# e# t#  # u# s#  # c# h# e# c# k#  # t# h# e#  # a# g# e#  # g# r# o# u# p#  # o# f#  # t# h# e#  # p# a# t# i# e# n# t# s# .# *# *

# In[None]

sns.set_style('darkgrid')
plt.figure(figsize=(25,10))
patients['Age'].value_counts().plot.bar(color='darkviolet')
plt.show()

# *# *# L# e# t#  # u# s#  # v# i# e# w#  # t# h# e#  # p# a# i# r# p# l# o# t#  # o# f#  # p# a# t# i# e# n# t# s#  # b# a# s# e# d#  # o# n#  # G# e# n# d# e# r# .# *# *

# In[None]

plt.rcParams['figure.figsize']=(10,10)
sns.pairplot(patients,hue='Gender')
plt.show()

# In[None]

sns.pairplot(patients)
plt.show()

# *# *# L# e# t#  # u# s#  # c# o# m# p# a# r# e#  # t# h# e#  # a# l# b# u# m# i# n#  # a# n# d#  # a# l# b# u# m# i# n#  # a# n# d#  # g# l# o# b# u# l# i# n#  # r# a# t# i# o#  # b# y#  # a#  # s# c# a# t# t# e# r# p# l# o# t# .# *# *

# In[None]

f, ax = plt.subplots(figsize=(8, 6))
sns.scatterplot(x="Albumin", y="Albumin_and_Globulin_Ratio",color='mediumspringgreen',data=patients);
plt.show()

# *# *# L# e# t#  # u# s#  # c# o# m# p# a# r# e#  # t# h# e#  # G# e# n# d# e# r#  # b# a# s# e# d#  # o# n#  # t# h# e#  # P# r# o# t# e# i# n#  # I# n# t# a# k# e# .# *# *

# In[None]

plt.figure(figsize=(8,6))
patients.groupby('Gender').sum()["Total_Protiens"].plot.bar(color='coral')
plt.show()

# *# *# S# o#  # p# r# o# t# e# i# n#  # i# n# t# a# k# e#  # i# s#  # h# i# g# h# e# r#  # i# n#  # t# h# e#  # c# a# s# e#  # o# f#  # M# a# l# e#  # a# n# d#  # c# o# m# p# a# r# i# t# i# v# e# l# y#  # l# e# s# s#  # i# n#  # f# e# m# a# l# e# s# .# *# *

# *# *# L# e# t#  # u# s#  # c# o# m# p# a# r# e#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # b# a# s# e# d#  # o# n#  # A# l# b# u# m# i# n#  # L# e# v# e# l# .# *# *

# In[None]

plt.figure(figsize=(8,6))
patients.groupby('Gender').sum()['Albumin'].plot.bar(color='midnightblue')
plt.show()

# *# *# A# l# b# u# m# i# n#  # L# e# v# e# l#  # i# s#  # h# i# g# h# e# r#  # i# n#  # t# h# e#  # c# a# s# e#  # i# n#  # t# h# e#  # c# a# s# e#  # o# f#  # m# a# l# e#  # c# o# m# p# a# r# e# d#  # t# o#  # f# e# m# a# l# e# .# *# *

# *# *# F# i# n# a# l# l# y#  # L# e# t#  # u# s#  # c# o# m# p# a# r# e#  # t# h# e# m#  # b# a# s# e# d#  # o# n#  # t# h# e#  # B# i# l# i# r# u# b# i# n#  # c# o# n# t# e# n# t# .# *# *

# In[None]

plt.figure(figsize=(8,6))
patients.groupby('Gender').sum()['Total_Bilirubin'].plot.bar(color='fuchsia')
plt.show()

# *# *# W# e#  # c# a# n#  # c# l# e# a# r# l# y#  # s# e# e#  # t# h# a# t#  # m# a# l# e# s#  # h# a# s#  # m# o# r# e#  # b# i# l# i# r# u# b# i# n#  # c# o# n# t# e# n# t#  # c# o# m# p# a# r# e# d#  # t# o#  # f# e# m# a# l# e# s# .# *# *

# *# *# A# n# o# t# h# e# r#  # p# o# i# n# t#  # t# o#  # b# e#  # n# o# t# e# d#  # h# e# r# e#  # i# s#  # t# h# a# t#  # h# i# g# h# e# r#  # t# h# e#  # B# i# l# i# r# u# b# i# n#  # c# o# n# t# e# n# t# ,#  # h# i# g# h# e# r#  # t# h# e#  # c# a# s# e#  # i# s#  # p# r# o# n# e#  # t# o#  # L# i# v# e# r#  # d# i# s# e# a# s# e# .# *# *

# *# *# L# e# t#  # u# s#  # c# h# e# c# k#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # f# e# a# t# u# r# e# s#  # u# s# i# n# g#  # a#  # h# e# a# t# m# a# p# :# *# *

# In[None]

corr=patients.corr()

# In[None]

plt.figure(figsize=(20,10)) 
sns.heatmap(corr,cmap="Greens",annot=True)
plt.show()

# *# *# S# o#  # L# e# t#  # u# s#  # s# t# a# r# t#  # b# u# i# l# d# i# n# g#  # o# u# r#  # m# o# d# e# l# .# *# *

# *# *# I# n# o# r# d# e# r#  # t# o#  # b# u# i# l# d#  # a#  # s# u# c# c# e# s# s# f# u# l#  # m# o# d# e# l#  # w# e#  # h# a# v# e#  # t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # t# h# e#  # m# o# d# e# l# .# *# *

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

patients.columns

# *# *# N# o# w#  # l# e# t#  # u# s#  # d# e# f# i# n# e#  # o# u# r#  # X#  # a# n# d#  # y# .# *# *

# *# *# H# e# r# e#  # X#  # i# s#  # o# u# r#  # f# e# a# t# u# r# e# s#  # a# n# d#  # y#  # i# s#  # o# u# r#  # t# a# r# g# e# t# .# *# *

# In[None]

X=patients[['Age', 'Gender', 'Total_Bilirubin', 'Direct_Bilirubin',
       'Alkaline_Phosphotase', 'Alamine_Aminotransferase',
       'Aspartate_Aminotransferase', 'Total_Protiens', 'Albumin',
       'Albumin_and_Globulin_Ratio']]
y=patients['Dataset']

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8180118.npy", { "accuracy_score": score })

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
ds = pd.read_csv('../input/heart.csv')
ds.info()
#sns.heatmap(ds.isnull(), yticklabels = False, cbar=False, cmap='viridis')
ds.head(5)
#sns.set_style('whitegrid')
#sns.countplot(x='target', hue='sex', data=ds, palette='RdBu_r')
#sns.countplot(x='target', hue='cp', data=ds)
ds['age'].plot.hist(bins=35)
ds.head(5)
ds['trestbps'].hist(bins=40, figsize=(10, 4))
#plt.figure(figsize=(10, 8))
#sns.boxplot(x='ca', y='age', data=ds)
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
ds.head(5)
y = ds.iloc[:, 13].values.reshape(-1, 1)
X = ds.iloc[:, 0:13].values
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
model_forScaledFeatures = LogisticRegression()
#model_forScaledFeatures.fit(X_train, y_train)
#y_pred_forscaledfeatures = model_forScaledFeatures.predict(X_test)
#print(classification_report(y_test, y_pred_forscaledfeatures))
print('\n')
#print(confusion_matrix(y_test, y_pred_forscaledfeatures))
from sklearn.neighbors import KNeighborsClassifier
error_rate = []
for i in range(1, 30):
    knn = KNeighborsClassifier(n_neighbors=i, metric='minkowski', p=2)
#    knn.fit(X_train, y_train)
#    pred_i = knn.predict(X_test)
#    error_rate.append(np.mean(pred_i != y_test))
#plt.figure(figsize=(12, 8))
#plt.plot(range(1, 30), error_rate, color='blue', linestyle='dashed', marker='o', markerfacecolor='red', markersize=10)
#plt.title('Error Rate v/s K value')
#plt.xlabel('K value')
#plt.ylabel('Error rate')
#plt.show()
classifier_knn = KNeighborsClassifier(n_neighbors=11, metric='minkowski', p=2)
#classifier_knn.fit(X_train, y_train)
#ypred_from_knn = classifier_knn.predict(X_test)
#print(classification_report(y_test, ypred_from_knn))
print('\n')
#print(confusion_matrix(y_test, ypred_from_knn))
from sklearn.svm import SVC
model_SVC = SVC(kernel='linear', random_state=0)
#model_SVC.fit(X_train, y_train)
#ypred_from_svc = model_SVC.predict(X_test)
#print(classification_report(y_test, ypred_from_svc))
print('\n')
#print(confusion_matrix( y_test, ypred_from_svc))
model_SVM_Kernel = SVC(kernel='rbf', random_state=0)
#model_SVM_Kernel.fit(X_train, y_train)
#ypred_from_SVMKernel = model_SVM_Kernel.predict(X_test)
#print(classification_report(y_test, ypred_from_SVMKernel))
print('\n')
#print(confusion_matrix( y_test, ypred_from_SVMKernel))
from sklearn.tree import DecisionTreeClassifier
model_tree = DecisionTreeClassifier()
#model_tree.fit(X_train, y_train)
#ypred_from_tree = model_tree.predict(X_test)
#print(classification_report(y_test, ypred_from_tree))
print('\n')
#print(confusion_matrix( y_test, ypred_from_tree))
from sklearn.ensemble import RandomForestClassifier
model_randomtree = RandomForestClassifier(n_estimators=200)
#model_randomtree.fit(X_train, y_train)
#ypred_from_randomtree = model_randomtree.predict(X_test)
#print(classification_report(y_test, ypred_from_randomtree))
print('\n')
#print(confusion_matrix( y_test, ypred_from_randomtree))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amreshd04_heart-disease-classification-kernel-svm-random-f.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amreshd04_heart-disease-classification-kernel-svm-random-f/testY.csv",encoding="gbk")


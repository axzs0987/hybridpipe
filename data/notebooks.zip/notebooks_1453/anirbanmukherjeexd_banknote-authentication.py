import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.model_selection import cross_val_score,train_test_split
from sklearn.preprocessing import StandardScaler
dataframe=pd.read_csv('../input/BankNote_Authentication.csv')
dataset=dataframe.values
dataframe.head()
#sns.countplot(x='class',data=dataframe)
print(dataframe.info())
dataframe.corr(method='spearman').style.background_gradient(cmap='coolwarm')
#sns.pairplot(dataframe, hue="class")
X=dataframe.iloc[:,0:4].values
Y=dataframe.iloc[:,4].values
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
from sklearn.linear_model import LogisticRegression
classifier=LogisticRegression(solver='liblinear',random_state=42)
#classifier.fit(X_train,Y_train)
#accuracies=cross_val_score(estimator=classifier,X=X_train,y=Y_train,cv=10)
#print("Accuracies:\n",accuracies)
#Y_test_pred=classifier.predict(X_test)
#cm=confusion_matrix(Y_test,Y_test_pred)
#acc=accuracy_score(Y_test,Y_test_pred)
#print("Mean Accuracy: ",accuracies.mean())
from sklearn.svm import SVC
classifier=SVC(kernel='linear')
#classifier.fit(X_train,Y_train)
#accuracies=cross_val_score(estimator=classifier,X=X_train,y=Y_train,cv=10)
#print("Accuracies:\n",accuracies)
#Y_test_pred=classifier.predict(X_test)
#cm=confusion_matrix(Y_test,Y_test_pred)
#acc=accuracy_score(Y_test,Y_test_pred)
#print("Mean Accuracy: ",accuracies.mean())
from sklearn.svm import SVC
classifier=SVC(kernel='rbf',gamma='auto')
#classifier.fit(X_train,Y_train)
#accuracies=cross_val_score(estimator=classifier,X=X_test,y=Y_test,cv=10)
#print("Accuracies:\n",accuracies)
#print("Mean Accuracy: ",accuracies.mean())
from sklearn.ensemble import RandomForestClassifier
classifier=RandomForestClassifier(n_estimators=50,criterion='entropy',random_state=0)
#classifier.fit(X_train,Y_train)
#accuracies=cross_val_score(estimator=classifier,X=X_test,y=Y_test,cv=10)
 
#print("Accuracies:\n",accuracies)
#print("Mean Accuracy: ",accuracies.mean())
from sklearn.neural_network import MLPClassifier
classifier=MLPClassifier(hidden_layer_sizes=(8,4), max_iter=8000, alpha=0.0001, solver='sgd', verbose=10,  random_state=21,tol=0.000000001)
#classifier.fit(X_train,Y_train)
#accuracies=cross_val_score(estimator=classifier,X=X_test,y=Y_test,cv=10)
#print("Accuracies:\n",accuracies)
#print("Mean Accuracy: ",accuracies.mean())



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anirbanmukherjeexd_banknote-authentication.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anirbanmukherjeexd_banknote-authentication/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/testX.csv",encoding="gbk")

if type(Y_train).__name__ == "ndarray":
    np.save("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainY.npy", Y_train)
if type(Y_train).__name__ == "Series":
    Y_train.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainY.csv",encoding="gbk")
if type(Y_train).__name__ == "DataFrame":
    Y_train.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/trainY.csv",encoding="gbk")

if type(Y_test).__name__ == "ndarray":
    np.save("hi_res_data/anirbanmukherjeexd_banknote-authentication/testY.npy", Y_test)
if type(Y_test).__name__ == "Series":
    Y_test.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/testY.csv",encoding="gbk")
if type(Y_test).__name__ == "DataFrame":
    Y_test.to_csv("hi_res_data/anirbanmukherjeexd_banknote-authentication/testY.csv",encoding="gbk")


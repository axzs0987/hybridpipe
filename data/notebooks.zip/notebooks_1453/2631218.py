import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you writee to the current directory are saved as output.

# In[None]

#loading data in to csv
data = pd.read_csv("../input/winequality-red.csv")
# viewing top 10 rows
data.head(10)

# In[None]

#viewing information of data features
data.info()

# In[None]

#describe data
data.describe()

# In[None]

# couting number of types of quality
data['quality'].value_counts()

# In[None]

data['quality'].value_counts().plot.bar()

# In[None]

data.corr()


# In[None]

data.head(10)

# In[None]

data['quality'] = data['quality'].astype(int)

# In[None]

bins = (2, 6, 8)
group_names = ['bad','good']
data['quality'] = pd.cut(data['quality'], bins = bins, labels = group_names, include_lowest = False)

# In[None]

data.head(10)
#quality is divided in binary classification from multilabel classification

# In[None]

#couting the number of bad and good value
data['quality'].value_counts()

# In[None]

#assign label to quality
from sklearn.preprocessing import LabelEncoder
qual = LabelEncoder()
data['quality']=qual.fit_transform(data['quality'])


# In[None]

#after fitting encoding bad becomes 0 and good becomes 1
data['quality'].value_counts()

# In[None]

#separate dataset as features and target
y = data['quality']
X = data.drop('quality',axis=1)

# In[None]

from sklearn.model_selection import train_test_split , cross_val_score, GridSearchCV
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import SGDClassifier


# In[None]

#splitting data set into  train and test
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/2631218.npy", { "accuracy_score": score })

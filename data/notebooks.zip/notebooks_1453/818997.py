import pandas as pd
# *# *# W# E# L# C# O# M# E#  # T# O#  # M# Y#  # N# O# T# E# B# O# O# K# *# *# 
# 
# T# h# i# s#  # n# o# t# e# b# o# o# k#  # i# s#  # a# n#  # i# n# t# r# o# d# u# c# t# i# o# n#  # o# f#  # h# o# w#  # t# o#  # u# s# e#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # f# o# r#  # d# e# t# e# r# m# i# n# i# n# g#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # w# i# n# e#  # a# n# d#  # h# o# w#  # t# o#  # c# h# o# o# s# e#  # a# p# p# r# o# p# r# i# a# t# e#  # p# a# r# a# m# e# t# e# r# s#  # f# o# r#  # f# i# t# t# i# n# g#  # o# u# r#  # m# o# d# e# l# .

# *# *# I# M# P# O# R# T# I# N# G#  # P# A# C# K# A# G# E# S#  # R# E# Q# U# I# R# E# D#  # *# *

# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

import statsmodels
import statsmodels.api as sm
from statsmodels.formula.api import ols

import scipy.stats as stats 
from scipy.stats.stats import pearsonr

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report

import seaborn as sns

# *# *# I# M# P# O# R# T# I# N# G#  # M# Y#  # D# A# T# A# *# *

# In[None]

wine=pd.read_csv("../input/winequality-red.csv")
wine.head()

# *# *# L# O# O# K# I# N# G#  # I# N# T# O#  # D# A# T# A# *# *

# In[None]

wine.shape

# In[None]

wine.describe()#no missing values

# In[None]

wine.columns=['fixed_acidity','volatile_acidity','citric_acid','residual_sugar','chlorides','free_sulfur_dioxide','total_sulfur_dioxide','density','pH','sulphates','alcohol','quality']


# *# *# F# E# A# T# U# R# E#  # F# I# N# D# I# N# G# *# *# 
# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e#  # A# N# O# V# A#  # t# e# s# t#  # t# o#  # d# e# t# e# r# m# i# n# e#  # w# e# a# t# h# e# r#  # t# o#  # u# s#  # u# s# e#  # a#  # p# a# t# i# c# u# l# a# r#  # c# o# l# u# m# n#  # a# s#  # a#  # f# e# a# t# u# r# e#  # o# r#  # n# o# t# .

# A# N# O# V# A#  # i# a#  # a#  # p# a# r# a# m# e# t# r# i# c#  # t# e# s# t#  # s# o#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # m# u# s# t#  # b# e#  # n# o# r# m# a# l#  # f# o# r#  # i# t#  # t# o#  # g# i# v# e#  # r# e# l# i# a# b# l# r#  # r# e# s# u# l# t# .# 
# H# e# r# e#  # w# e#  # a# r# e#  # p# l# o# t# t# i# n# g#  # a# l# l#  # t# h# e#  # t# e# n# t# e# t# i# v# e#  # f# e# a# t# u# r# e# s#  # t# o#  # s# e# e#  # t# h# e# i# r#  # d# i# s# t# r# i# b# u# t# i# o# n# .#  #  

# In[None]

def hist_plotter(wine,column):
     wine[column].plot.hist(figsize=(10,5))
     plt.xlabel("Rating",fontsize=10)
     plt.ylabel(column,fontsize=10)
     plt.title(column+" vs Rating",fontsize=10)
     plt.show()

# w# e#  # a# r# e#  # w# r# i# t# i# n# g#  # a#  # f# u# n# c# t# i# o# n#  # t# o#  # r# e# d# u# c# e#  # o# u# r#  # w# o# r# k#  # o# r#  # w# r# i# t# i# n# g#  # p# l# t#  # a# g# a# i# n#  # a# n# d#  # a# g# a# i# n# .

# In[None]

def skew(wine,col):
    wine[col] = np.log(wine[col])
    

# T# h# i# s#  # i# s#  # a#  # s# k# e# w# n# e# s# s#  # c# o# r# r# e# c# t# i# o# n#  # f# u# n# c# t# i# o# n# .# w# e#  # w# i# l# l#  # s# e# e#  # i# t# s#  # u# s# e#  # v# e# r# y#  # s# o# o# n

# W# e#  # c# a#  # s# e# e#  # t# h# e#  # b# e# l# o# w#  # p# l# o# t# t# e# d#  # g# r# a# p# h#  # i# s#  # n# o# t#  # a# c# c# u# r# a# t# e# l# y#  # b# e# l# l#  # s# h# a# p# e# d#  # b# u# t#  # s# k# e# w# e# d#  # t# o# w# a# r# d# s#  # l# e# f# t# .#  # 
# 
# T# h# i# s#  # l# e# a# d#  # t# o#  # a# n#  # i# n# c# o# r# r# e# c# t#  # r# e# s# u# l# t#  # i# n#  # A# N# O# V# A#  # .

# In[None]


hist_plotter(wine,'volatile_acidity')


# In[None]

skew(wine,'volatile_acidity')
hist_plotter(wine,'volatile_acidity')


# W# e#  # a# r# e#  # t# r# y# i# n# g#  # t# o#  # c# o# r# r# e# c# t#  # t# h# e#  # s# k# e# w# n# e# s# s#  # p# r# o# b# l# e# m#  # b# y#  # t# a# k# i# n# g#  # l# o# g#  # t# r# a# n# s# f# o# r# m#  # o# f#  # i# t#  # w# h# e# n# e# v# e# r#  # i# t#  # i# s#  # n# e# c# e# s# s# a# r# y# .

# In[None]

hist_plotter(wine,'citric_acid')


# In[None]

skew(wine,'residual_sugar')
hist_plotter(wine,'residual_sugar')

# In[None]

skew(wine,'chlorides')
hist_plotter(wine,'chlorides')

# In[None]

skew(wine,'free_sulfur_dioxide')
hist_plotter(wine,'free_sulfur_dioxide')

# In[None]

skew(wine,'total_sulfur_dioxide')
hist_plotter(wine,'total_sulfur_dioxide')

# In[None]

hist_plotter(wine,'density')

# In[None]

hist_plotter(wine,'pH')

# In[None]

skew(wine,'sulphates')
hist_plotter(wine,'sulphates')

# In[None]

skew(wine,'alcohol')
hist_plotter(wine,'alcohol')

# *# *# A# N# O# V# A#  # T# E# S# T# *# *

# W# e#  # a# r# e#  # r# u# n# n# i# n# g#  # a# n# o# v# a#  # t# e# s# t#  # a# n# d#  # t# r# y# i# n# g#  # t# o#  # d# e# t# e# r# m# i# n# e#  # w# e# a# t# h# e# r#  # i# t#  # i# s#  # a#  # g# o# o# d#  # f# e# a# t# u# r# e#  # o# r#  # n# o# t# .# 
# 
# A#  # g# o# o# d#  # f# e# a# t# u# r# e#  # i# s#  # s# o# m# t# h# i# n# g#  # w# h# i# c# h#  # h# e# l# p#  # u# s#  # d# e# t# e# r# m# i# n# e#  # d# i# f# f# e# r# e# n# t#  # l# a# b# e# l# s# .# (# I# n#  # t# h# i# s#  # c# a# s# e#  # w# h# a# t#  # m# a# k# e# s#  # a#  # w# i# n# e#  # g# o# o# d# )

# I# n#  # a# n#  # A# N# O# V# A#  # t# e# s# t#  # w# e#  # w# i# l# l#  # l# o# o# k#  # i# n# t# o#  # F# -# S# t# a# t# i# s# t# i# c#  # v# a# l# u# e#  # .# 
# 
# A#  # h# i# g# h#  # F#  # v# a# l# u# e#  # s# h# o# w# s#  # v# a# r# i# a# t# i# o# n#  # b# e# t# w# e# e# n#  # d# i# f# f# e# r# e# n# t#  # g# r# o# u# p# s#  # a# r# e#  # h# i# g# h# e# r#  # t# h# a# n#  # v# a# r# i# a# t# i# o# n#  # a# m# o# n# g#  # s# a# m# e#  # g# r# o# u# p# .

# In[None]

model=ols('chlorides ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('fixed_acidity ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('free_sulfur_dioxide ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) 

# In[None]

model=ols('citric_acid ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('residual_sugar ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) 

# In[None]

model=ols('total_sulfur_dioxide~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('density ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('pH ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) 

# In[None]

model=ols('sulphates ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('alcohol ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# In[None]

model=ols('volatile_acidity ~ quality',data=wine).fit()
aov_table = sm.stats.anova_lm(model, typ=2)
print (aov_table) #take

# L# i# k# e#  # o# t# h# e# r#  # p# a# r# a# m# e# t# r# i# c#  # t# e# s# t# s# ,#  # t# h# e#  # a# n# a# l# y# s# i# s#  # o# f#  # v# a# r# i# a# n# c# e#  # a# s# s# u# m# e# s#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # f# i# t#  # t# h# e#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n# .#  # I# f#  # y# o# u# r#  # m# e# a# s# u# r# e# m# e# n# t#  # v# a# r# i# a# b# l# e#  # i# s#  # n# o# t#  # n# o# r# m# a# l# l# y#  # d# i# s# t# r# i# b# u# t# e# d# ,#  # y# o# u#  # m# a# y#  # b# e#  # i# n# c# r# e# a# s# i# n# g#  # y# o# u# r#  # c# h# a# n# c# e#  # o# f#  # a#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e#  # r# e# s# u# l# t#  # i# f#  # y# o# u#  # a# n# a# l# y# z# e#  # t# h# e#  # d# a# t# a#  # w# i# t# h#  # a# n#  # a# n# o# v# a#  # o# r#  # o# t# h# e# r#  # t# e# s# t#  # t# h# a# t#  # a# s# s# u# m# e# s#  # n# o# r# m# a# l# i# t# y# .#  # F# o# r# t# u# n# a# t# e# l# y# ,#  # a# n#  # a# n# o# v# a#  # i# s#  # n# o# t#  # v# e# r# y#  # s# e# n# s# i# t# i# v# e#  # t# o#  # m# o# d# e# r# a# t# e#  # d# e# v# i# a# t# i# o# n# s#  # f# r# o# m#  # n# o# r# m# a# l# i# t# y# ;#  # s# i# m# u# l# a# t# i# o# n#  # s# t# u# d# i# e# s# ,#  # u# s# i# n# g#  # a#  # v# a# r# i# e# t# y#  # o# f#  # n# o# n# -# n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n# s# ,#  # h# a# v# e#  # s# h# o# w# n#  # t# h# a# t#  # t# h# e#  # f# a# l# s# e#  # p# o# s# i# t# i# v# e#  # r# a# t# e#  # i# s#  # n# o# t#  # a# f# f# e# c# t# e# d#  # v# e# r# y#  # m# u# c# h#  # b# y#  # t# h# i# s#  # v# i# o# l# a# t# i# o# n#  # o# f#  # t# h# e#  # a# s# s# u# m# p# t# i# o# n#  # (# G# l# a# s# s#  # e# t#  # a# l# .#  # 1# 9# 7# 2# ,#  # H# a# r# w# e# l# l#  # e# t#  # a# l# .#  # 1# 9# 9# 2# ,#  # L# i# x#  # e# t#  # a# l# .#  # 1# 9# 9# 6# )# .#  # T# h# i# s#  # i# s#  # b# e# c# a# u# s# e#  # w# h# e# n#  # y# o# u#  # t# a# k# e#  # a#  # l# a# r# g# e#  # n# u# m# b# e# r#  # o# f#  # r# a# n# d# o# m#  # s# a# m# p# l# e# s#  # f# r# o# m#  # a#  # p# o# p# u# l# a# t# i# o# n# ,#  # t# h# e#  # m# e# a# n# s#  # o# f#  # t# h# o# s# e#  # s# a# m# p# l# e# s#  # a# r# e#  # a# p# p# r# o# x# i# m# a# t# e# l# y#  # n# o# r# m# a# l# l# y#  # d# i# s# t# r# i# b# u# t# e# d#  # e# v# e# n#  # w# h# e# n#  # t# h# e#  # p# o# p# u# l# a# t# i# o# n#  # i# s#  # n# o# t#  # n# o# r# m# a# l# .# 
# 
# I# t#  # i# s#  # p# o# s# s# i# b# l# e#  # t# o#  # t# e# s# t#  # t# h# e#  # g# o# o# d# n# e# s# s# -# o# f# -# f# i# t#  # o# f#  # a#  # d# a# t# a#  # s# e# t#  # t# o#  # t# h# e#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n# .#  # I#  # d# o#  # n# o# t#  # s# u# g# g# e# s# t#  # t# h# a# t#  # y# o# u#  # d# o#  # t# h# i# s# ,#  # b# e# c# a# u# s# e#  # m# a# n# y#  # d# a# t# a#  # s# e# t# s#  # t# h# a# t#  # a# r# e#  # s# i# g# n# i# f# i# c# a# n# t# l# y#  # n# o# n# -# n# o# r# m# a# l#  # w# o# u# l# d#  # b# e#  # p# e# r# f# e# c# t# l# y#  # a# p# p# r# o# p# r# i# a# t# e#  # f# o# r#  # a# n#  # a# n# o# v# a# .# 
# 
# I# n# s# t# e# a# d# ,#  # i# f#  # y# o# u#  # h# a# v# e#  # a#  # l# a# r# g# e#  # e# n# o# u# g# h#  # d# a# t# a#  # s# e# t# ,#  # I#  # s# u# g# g# e# s# t#  # y# o# u#  # j# u# s# t#  # l# o# o# k#  # a# t#  # t# h# e#  # f# r# e# q# u# e# n# c# y#  # h# i# s# t# o# g# r# a# m# .#  # I# f#  # i# t#  # l# o# o# k# s#  # m# o# r# e# -# o# r# -# l# e# s# s#  # n# o# r# m# a# l# ,#  # g# o#  # a# h# e# a# d#  # a# n# d#  # p# e# r# f# o# r# m#  # a# n#  # a# n# o# v# a# .#  # I# f#  # i# t#  # l# o# o# k# s#  # l# i# k# e#  # a#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n#  # t# h# a# t#  # h# a# s#  # b# e# e# n#  # p# u# s# h# e# d#  # t# o#  # o# n# e#  # s# i# d# e# ,#  # l# i# k# e#  # t# h# e#  # s# u# l# p# h# a# t# e#  # d# a# t# a#  # a# b# o# v# e# ,#  # y# o# u#  # s# h# o# u# l# d#  # t# r# y#  # d# i# f# f# e# r# e# n# t#  # d# a# t# a#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n# s#  # a# n# d#  # s# e# e#  # i# f#  # a# n# y#  # o# f#  # t# h# e# m#  # m# a# k# e#  # t# h# e#  # h# i# s# t# o# g# r# a# m#  # l# o# o# k#  # m# o# r# e#  # n# o# r# m# a# l# .#  # I# f#  # t# h# a# t#  # d# o# e# s# n# '# t#  # w# o# r# k# ,#  # a# n# d#  # t# h# e#  # d# a# t# a#  # s# t# i# l# l#  # l# o# o# k#  # s# e# v# e# r# e# l# y#  # n# o# n# -# n# o# r# m# a# l# ,#  # i# t# '# s#  # p# r# o# b# a# b# l# y#  # s# t# i# l# l#  # o# k# a# y#  # t# o#  # a# n# a# l# y# z# e#  # t# h# e#  # d# a# t# a#  # u# s# i# n# g#  # a# n#  # a# n# o# v# a# .#  # H# o# w# e# v# e# r# ,#  # y# o# u#  # m# a# y#  # w# a# n# t#  # t# o#  # a# n# a# l# y# z# e#  # i# t#  # u# s# i# n# g#  # a#  # n# o# n# -# p# a# r# a# m# e# t# r# i# c#  # t# e# s# t# .#  # J# u# s# t#  # a# b# o# u# t#  # e# v# e# r# y#  # p# a# r# a# m# e# t# r# i# c#  # s# t# a# t# i# s# t# i# c# a# l#  # t# e# s# t#  # h# a# s#  # a#  # n# o# n# -# p# a# r# a# m# e# t# r# i# c#  # s# u# b# s# t# i# t# u# t# e# ,#  # s# u# c# h#  # a# s#  # t# h# e#  # K# r# u# s# k# a# l# –# W# a# l# l# i# s#  # t# e# s# t#  # i# n# s# t# e# a# d#  # o# f#  # a#  # o# n# e# -# w# a# y#  # a# n# o# v# a# ,#  # W# i# l# c# o# x# o# n#  # s# i# g# n# e# d# -# r# a# n# k#  # t# e# s# t#  # i# n# s# t# e# a# d#  # o# f#  # a#  # p# a# i# r# e# d#  # t# -# t# e# s# t# ,#  # a# n# d#  # S# p# e# a# r# m# a# n#  # r# a# n# k#  # c# o# r# r# e# l# a# t# i# o# n#  # i# n# s# t# e# a# d#  # o# f#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .#  # T# h# e# s# e#  # n# o# n# -# p# a# r# a# m# e# t# r# i# c#  # t# e# s# t# s#  # d# o#  # n# o# t#  # a# s# s# u# m# e#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # f# i# t#  # t# h# e#  # n# o# r# m# a# l#  # d# i# s# t# r# i# b# u# t# i# o# n# .#  # T# h# e# y#  # d# o#  # a# s# s# u# m# e#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # i# n#  # d# i# f# f# e# r# e# n# t#  # g# r# o# u# p# s#  # h# a# v# e#  # t# h# e#  # s# a# m# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # a# s#  # e# a# c# h#  # o# t# h# e# r# ,#  # h# o# w# e# v# e# r# ;#  # i# f#  # d# i# f# f# e# r# e# n# t#  # g# r# o# u# p# s#  # h# a# v# e#  # d# i# f# f# e# r# e# n# t#  # s# h# a# p# e# d#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # (# f# o# r#  # e# x# a# m# p# l# e# ,#  # o# n# e#  # i# s#  # s# k# e# w# e# d#  # t# o#  # t# h# e#  # l# e# f# t# ,#  # a# n# o# t# h# e# r#  # i# s#  # s# k# e# w# e# d#  # t# o#  # t# h# e#  # r# i# g# h# t# )# ,#  # a#  # n# o# n# -# p# a# r# a# m# e# t# r# i# c#  # t# e# s# t#  # m# a# y#  # n# o# t#  # b# e#  # a# n# y#  # b# e# t# t# e# r#  # t# h# a# n#  # a#  # p# a# r# a# m# e# t# r# i# c#  # o# n# e# .

# F# o# r#  # n# o# w#  # w# e#  # w# i# l# l#  # u# s# e#  # t# h# e# m#  # a# s#  # i# t#  # i# s# .

# N# o# w#  # w# e#  # a# r# e#  # d# o# n# e#  # w# i# t# h#  # s# e# l# e# c# t# i# n# g#  # F# e# a# t# u# r# e# s#  # f# o# r#  # o# u# r#  # m# o# d# e# l# .

# *# *# F# I# N# A# L#  # F# E# A# T# U# R# E# S# *# *# 
# 
# N# o# w#  # w# e#  # w# i# l# l#  # d# r# p#  # a# l# l#  # t# h# e#  # u# n# d# e# s# i# r# a# b# l# e#  # f# e# a# t# u# r# e# s#  # w# h# i# c#  # w# i# l# l#  # n# o# t#  # g# i# v# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # w# i# n# e#  # q# u# a# l# i# t# y# .# 
# 
# a# n# d#  # w# e#  # p# l# a# c# e#  # "#  # q# u# a# l# i# t# y#  # "#  # i# n#  # y#  # w# h# i# c# h#  # w# e#  # h# a# v# e#  # t# o#  # p# r# e# d# i# c# t# .

# In[None]

y=wine['quality']
wine=wine.drop(['quality','pH','residual_sugar','free_sulfur_dioxide'],axis=1)

# In[None]

wine.head()

# *# *# D# A# T# A#  # S# P# L# I# T# *# *# 
# 
# N# o# w#  # w# e#  # w# i# l# l#  # s# p# l# i# t#  # d# a# t# a#  # i# n#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # d# a# t# a#  # .

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(wine, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/818997.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

#Imports necessários
import numpy as np
import pandas as pds
import collections
from sklearn import preprocessing
from pandas import concat
import matplotlib

# In[None]

#Analise do dataset
data = pds.read_csv('../input/chicago-bike-sharedatasetprediction/dataset_prediction.csv')
print(len(data)) 
data.head()

# In[None]

#Correlação de atributos
corrData = data.copy()
df_corr = corrData.corr()
df_corr

# In[None]

#Dados de locacao de dia de semana por fim de semana
data.groupby(['is_weekend'])['rentals'].sum().plot(kind='bar')

# In[None]

#Dados de locacao por clima (chuva ou neve)
data.groupby(['rain_or_snow'])['rentals'].sum().plot(kind='bar')

# In[None]

#Dados de locacao por clima nublado
data.groupby(['tstorms'])['rentals'].sum().plot(kind='bar')

# In[None]

#Dados de locacao por clima nublado
data.groupby(['cloudy'])['rentals'].sum().plot(kind='bar')

# In[None]

data.groupby(['month'])['rentals'].sum().plot(kind='bar')

# In[None]

data.groupby(['year'])['rentals'].sum().plot(kind='bar')

# In[None]

data.groupby(['hour'])['rentals'].sum().plot(kind='bar')

# In[None]

#Pre-Processamento dos dados

#Normalizacao
data.year = preprocessing.scale(list(data.year))
data.month = preprocessing.scale(list(data.month))
data.week = preprocessing.scale(list(data.week))
data.day = preprocessing.scale(list(data.day))
data.hour = preprocessing.scale(list(data.hour))
data.mean_temperature = preprocessing.scale(list(data.mean_temperature))
data.median_temperature = preprocessing.scale(list(data.median_temperature))

#Visualização dos dados
data.head()

# In[None]

#Verificacao de dados do dataset
collections.Counter(data.is_weekend)

# In[None]

#Modelos a serem testados
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.linear_model import LinearRegression, BayesianRidge, LogisticRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor, RandomForestRegressor

#Retirada da variável target das features de predição
X = data.drop('rentals',1)
y = data.rentals

#Separação de conjunto de testes
from sklearn.model_selection import train_test_split
X_model, X_test, y_model, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_model, y_model)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1831322.npy", { "accuracy_score": score })

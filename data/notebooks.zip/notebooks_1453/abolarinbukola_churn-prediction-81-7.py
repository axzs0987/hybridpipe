import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
#sns.set()
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
path = '/kaggle/input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv'
df = pd.read_csv(path)
df.head()
df.describe(include = 'all')
df.info()
df['TotalCharges'].value_counts()
df['TotalCharges'].replace(' ', 0, inplace = True)
df[df['TotalCharges'].apply (lambda x: x== ' ')]
df['TotalCharges'] = df['TotalCharges'].astype('float')
#sns.distplot(df['tenure']) 
#sns.distplot(df['MonthlyCharges']) 
#sns.distplot(df['TotalCharges'])
df.describe()
df[df['TotalCharges'].apply (lambda x: x > 8500)]
df.columns.values
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
variable = df[['tenure', 'MonthlyCharges','TotalCharges',]]
X = add_constant(variable)
vif = pd.DataFrame()
vif['VIF']  = [variance_inflation_factor(X.values, i) for i in range (X.shape[1])]
vif['features'] = X.columns
vif
scale_int = df[['MonthlyCharges']]
scaler = StandardScaler()
scaler.fit(scale_int)
df['scaled_monthly']= scaler.transform(scale_int)
scale_int = df[['tenure']] 
scaler = StandardScaler()
scaler.fit(scale_int)
df['scaled_tenure']= scaler.transform(scale_int)
scale_int = df[['tenure']] 
scaler = StandardScaler()
scaler.fit(scale_int)
df['scaled_charges']= scaler.transform(scale_int)
df.describe()
df.describe(include = 'all')
df.drop(['tenure','MonthlyCharges','customerID', 'TotalCharges'], axis = 1, inplace = True)
df['Churn'] = df['Churn'].map({'Yes':1, 'No':0})
df.columns.values
df_dummies = pd.get_dummies(df, drop_first = True)
df_dummies
x = df_dummies.drop('Churn', axis = 1)
y = df_dummies['Churn']
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
reg = LogisticRegression() 
#reg.fit(x_train, y_train) 
#y_hat = reg.predict(x_test)
#acc = metrics.accuracy_score(y_hat, y_test)
#acc
#reg.intercept_
#reg.coef_
#cm = confusion_matrix(y_hat,y_test)
#cm
#cm_df = pd.DataFrame(cm)
#cm_df.columns = ['Predicted 0','Predicted 1']
#cm_df = cm_df.rename(index={0: 'Actual 0',1:'Actual 1'})
#cm_df
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier 
from sklearn import svm 
dt = DecisionTreeClassifier()
#dt.fit(x_train,y_train)
#y1 = dt.predict(x_test)
#acc1 = metrics.accuracy_score(y1, y_test)
#acc1
kk = KNeighborsClassifier()
#kk.fit(x_train,y_train)
#y2 = kk.predict(x_test)
#acc2 = metrics.accuracy_score(y2, y_test)
#acc2
sv = svm.SVC()
#sv.fit(x_train,y_train)
#y3 = sv.predict(x_test)
#acc3 = metrics.accuracy_score(y3, y_test)
#acc3
result = pd.DataFrame(data = x.columns.values, columns = ['features'] )
#result['weight'] = np.transpose(reg.coef_)
#result['odds'] = np.exp(np.transpose(reg.coef_))
result



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/abolarinbukola_churn-prediction-81-7.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/abolarinbukola_churn-prediction-81-7/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/abolarinbukola_churn-prediction-81-7/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/abolarinbukola_churn-prediction-81-7/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/abolarinbukola_churn-prediction-81-7/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/abolarinbukola_churn-prediction-81-7/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# G# e# t# t# i# n# g#  # t# h# e#  # d# a# t# a#  # f# r# o# m#  # t# h# e#  # C# S# V#  # F# i# l# e#  # a# n# d#  # s# p# l# i# t# t# i# n# g#  # i# n# t# o#  # i# n# p# u# t#  # a# n# d#  # p# r# e# d# i# c# t# i# o# n# s# .

# In[None]

df = pd.read_csv("/kaggle/input/pulsar_stars.csv")
print(df.head())
values = df.values
print(values.shape)
X = values[:, 0:7]
Y = values[:, 8]

# I# m# p# o# r# t# i# n# g#  # S# c# i# k# i# t# -# l# e# a# r# n#  # l# i# b# r# a# r# i# e# s# .# 
# U# s# i# n# g#  # S# V# C#  # a# s#  # i# t#  # i# s#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# .# 
# U# s# i# n# g#  # a# c# c# u# r# a# c# y#  # a# s#  # m# e# a# s# u# r# e# m# e# n# t#  # i# n# d# e# x# .

# In[None]

from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

# S# p# l# i# t# t# i# n# g#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # s# e# t# s# .# 
# A# l# s# o#  # a# p# p# l# y# i# n# g#  # a#  # s# t# a# n# d# a# r# d#  # s# c# a# l# e# r# .

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5267977.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler,LabelEncoder

# In[None]

from sklearn.model_selection import train_test_split

# In[None]

df=pd.read_csv("../input/xAPI-Edu-Data.csv")
df.head()

# In[None]

df.isnull().sum()

# In[None]

df['Class'].value_counts()

# In[None]

sns.countplot(df.Class)

# In[None]

df['Topic'].value_counts()

# In[None]

sns.countplot(df.Topic.sort_index(ascending=False))
plt.xticks(rotation=45)

# In[None]

pd.crosstab(df['Class'],df['Topic'])

# In[None]

df.columns

# In[None]

sns.countplot(df.gender)

# In[None]

df.NationalITy.value_counts()

# In[None]

sns.countplot(df.NationalITy)
plt.xticks(rotation=45)

# In[None]

print(df.dtypes)

# In[None]

label=LabelEncoder()

# In[None]

gender=label.fit_transform(df['gender'])
Nationality=label.fit_transform(df['NationalITy'])
PlaceOfBirth=label.fit_transform(df['PlaceofBirth'])
StageID=label.fit_transform(df['StageID'])
GradeID=label.fit_transform(df['GradeID'])
SectionID=label.fit_transform(df['SectionID'])
Topic=label.fit_transform(df['Topic'])
Semester=label.fit_transform(df['Semester'])
Relation=label.fit_transform(df['Relation'])
ParentAnsweringSurvey=label.fit_transform(df['ParentAnsweringSurvey'])
ParentschoolSatisfaction=label.fit_transform(df['ParentschoolSatisfaction'])
StudentAbsenceDays=label.fit_transform(df['StudentAbsenceDays'])
Class=label.fit_transform(df['Class'])

# In[None]

df.drop(['gender', 'NationalITy', 'PlaceofBirth', 'StageID', 'GradeID', 'SectionID', 'Topic', 'Semester', 'Relation', 'ParentAnsweringSurvey', 'ParentschoolSatisfaction', 'StudentAbsenceDays', 'Class'], axis=1, inplace=True)

# In[None]

df.head()

# In[None]

df['gender']=gender
df['NationalITy']=Nationality
df['PlaceofBirth']=PlaceOfBirth
df['StageID']=StageID
df['GradeID']=GradeID
df['SectionID']=SectionID
df['Topic']=Topic
df['Semester']=Semester
df['Relation']=Relation
df['ParentAnsweringSurvey']=ParentAnsweringSurvey
df['ParentschoolSatisfaction']=ParentschoolSatisfaction
df['StudentAbsenceDays']=StudentAbsenceDays
df['Class']=Class

# In[None]

df.head()

# In[None]

plt.figure(figsize=(12,10))
sns.heatmap(df.corr())

# In[None]

x=df.iloc[:,:-1]
y=df.iloc[:,-1]

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1407110.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier 
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit, cross_val_score, GridSearchCV
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import classification_report, roc_curve, roc_auc_score, auc, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import label_binarize, LabelEncoder
from scipy import stats
from itertools import cycle

# ##  # R# e# a# d# i# n# g#  # d# a# t# a

# In[None]

data = pd.read_csv('/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')
data.head()

# ##  # E# D# A# :#  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# N# o# t# e# :#  # W# e# '# l# l#  # c# o# n# s# i# d# e# r#  # a# l# l#  # p# o# s# s# i# b# l# e#  # q# u# a# l# i# t# i# e# s# .#  # I# n#  # a#  # f# u# r# t# h# e# r#  # s# t# e# p#  # w# e#  # c# a# n#  # t# r# a# n# s# f# o# r# m#  # i# t#  # i# n# t# o#  # a#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m

# In[None]

print(f'Data length: {len(data)}')

# In[None]

#check missing data
data.isnull().sum()

# In[None]

#correlation matrix
plt.figure(figsize=(10,5))
heatmap = sns.heatmap(data.corr(), annot=True, fmt=".1f")
heatmap.yaxis.set_ticklabels(heatmap.yaxis.get_ticklabels(), rotation=0, ha='right', fontsize=14)
heatmap.xaxis.set_ticklabels(heatmap.xaxis.get_ticklabels(), rotation=45, ha='right', fontsize=14)
plt.show()

# In[None]

#Plot pairwise relationships in data for few features  (plot size constraint)
cols_sns = ['residual sugar', 'chlorides', 'density', 'pH', 'alcohol', 'quality']
sns.set(style="ticks")
sns.pairplot(data[cols_sns], hue='quality')

# In[None]

sns.countplot(x='quality', data=data)

# In[None]

# Features distribution over quality's possible values
fig, ax = plt.subplots(4, 3, figsize=(15, 15))
for var, subplot in zip(data.columns, ax.flatten()):
    if var == "quality":
        continue
    else:
        sns.boxplot(x=data['quality'], y=data[var], data=data, ax=subplot)

# ##  # P# r# e# p# a# r# i# n# g#  # D# a# t# a

# In[None]

features, labels = data.loc[:,data.columns !='quality'], data['quality']

# In[None]

sns.distplot(labels, kde=True, hist=False)
plt.title('KDE: Kernel Density Estimation')
plt.show()

# W# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # d# a# t# a#  # i# s#  # s# k# e# w# e# d#  # a# n# d#  # s# o# m# e#  # q# u# a# l# i# t# i# e# s#  # a# r# e#  # m# o# r# e#  # p# r# o# b# a# b# l# e#  # (# 5#  # a# n# d#  # 6# )#  # t# o#  # o# c# c# u# r#  # t# h# a# n#  # t# h# e#  # o# t# h# e# r# s# .

# In[None]

#scaling data
scaler = MinMaxScaler()
X = scaler.fit_transform(features)

# In[None]

#classic split the data into train and test sets for unbalanced data isn't a good idea
from sklearn.model_selection import train_test_split
xtr, xts, ytr, yts = train_test_split(X, labels, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(xtr, ytr)
y_pred = model.predict(xts)
score = accuracy_score(yts, y_pred)
import numpy as np
np.save("prenotebook_res/8241310.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[None]

#Read the dataset into pandas dataframe
dataset = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')
dataset.head()

# In[None]

#Check for null values and data types of columns
dataset.info()

# In[None]

dataset['TotalCharges'] = pd.to_numeric(dataset['TotalCharges'],errors='coerce')

# In[None]

#No null values present. Now lets check some statistics for continuous variable columns
dataset.describe()

# In[None]

#Notice that TotalCharges column now has 11 missing values after its conversion to numeric
df = dataset[pd.isnull(dataset).any(axis=1)]
df

# In[None]

#For other records, total charges is somewhat close to the product of tenure and monthly charges. So i will be using 
# this formula to fill the missing values
dataset['TotalCharges'].fillna(dataset['tenure']*dataset['MonthlyCharges'],inplace=True)

# In[None]

df = dataset[pd.isnull(dataset).any(axis=1)]
df

# In[None]

#Check for outliers

# In[None]

plt.boxplot(dataset['tenure'])
plt.show()

# In[None]

plt.boxplot(dataset['MonthlyCharges'])
plt.show()

# In[None]

plt.boxplot(dataset['TotalCharges'])
plt.show()

# In[None]

#None of the three numeric columns have outliers

# In[None]

#Lets check the number of target values each of 'Yes' and 'No' in the churn flag
dataset['Churn'].value_counts()

# In[None]



# In[None]

#The ratio of Yes to No is almost 1:3. Not a bad spread of classification
dataset['Churn'].value_counts().plot(kind='bar')
plt.show()

# In[None]

set(dataset['Churn'])

# In[None]

#Lets begin by converting the categorical variables from string to integer
dataset.loc[dataset['Churn'] == 'Yes','Churn'] = 1
dataset.loc[dataset['Churn'] == 'No','Churn'] = 0
dataset['Churn'] = dataset['Churn'].astype(int)

# In[None]

set(dataset['gender'])

# In[None]

dataset.loc[dataset['gender'] == 'Male','gender'] = 1
dataset.loc[dataset['gender'] == 'Female','gender'] = 2
dataset['gender'] = dataset['gender'].astype(int)

# In[None]

dataset.loc[dataset['Partner'] == 'Yes','Partner'] = 1
dataset.loc[dataset['Partner'] == 'No','Partner'] = 0
dataset['Partner'] = dataset['Partner'].astype(int)

# In[None]

dataset.loc[dataset['Dependents'] == 'Yes','Dependents'] = 1
dataset.loc[dataset['Dependents'] == 'No','Dependents'] = 0
dataset['Dependents'] = dataset['Dependents'].astype(int)

# In[None]

set(dataset['PhoneService'])

# In[None]

dataset.loc[dataset['PhoneService'] == 'Yes','PhoneService'] = 1
dataset.loc[dataset['PhoneService'] == 'No','PhoneService'] = 0
dataset['PhoneService'] = dataset['PhoneService'].astype(int)

# In[None]

set(dataset['MultipleLines'])

# In[None]

dataset.loc[dataset['MultipleLines'] == 'No','MultipleLines'] = 0
dataset.loc[dataset['MultipleLines'] == 'Yes','MultipleLines'] = 1
dataset.loc[dataset['MultipleLines'] == 'No phone service','MultipleLines'] = 2
dataset['MultipleLines'] = dataset['MultipleLines'].astype(int)

# In[None]

set(dataset['InternetService'])

# In[None]

dataset.loc[dataset['InternetService'] == 'No','InternetService'] = 0
dataset.loc[dataset['InternetService'] == 'DSL','InternetService'] = 1
dataset.loc[dataset['InternetService'] == 'Fiber optic','InternetService'] = 2
dataset['InternetService'] = dataset['InternetService'].astype(int)

# In[None]

set(dataset['OnlineSecurity'])

# In[None]

dataset.loc[dataset['OnlineSecurity'] == 'No','OnlineSecurity'] = 0
dataset.loc[dataset['OnlineSecurity'] == 'Yes','OnlineSecurity'] = 1
dataset.loc[dataset['OnlineSecurity'] == 'No internet service','OnlineSecurity'] = 2
dataset['OnlineSecurity'] = dataset['OnlineSecurity'].astype(int)

# In[None]

set(dataset['OnlineBackup'])

# In[None]

dataset.loc[dataset['OnlineBackup'] == 'No','OnlineBackup'] = 0
dataset.loc[dataset['OnlineBackup'] == 'Yes','OnlineBackup'] = 1
dataset.loc[dataset['OnlineBackup'] == 'No internet service','OnlineBackup'] = 2
dataset['OnlineBackup'] = dataset['OnlineBackup'].astype(int)

# In[None]

set(dataset['DeviceProtection'])

# In[None]

dataset.loc[dataset['DeviceProtection'] == 'No','DeviceProtection'] = 0
dataset.loc[dataset['DeviceProtection'] == 'Yes','DeviceProtection'] = 1
dataset.loc[dataset['DeviceProtection'] == 'No internet service','DeviceProtection'] = 2
dataset['DeviceProtection'] = dataset['DeviceProtection'].astype(int)

# In[None]

set(dataset['TechSupport'])

# In[None]

dataset.loc[dataset['TechSupport'] == 'No','TechSupport'] = 0
dataset.loc[dataset['TechSupport'] == 'Yes','TechSupport'] = 1
dataset.loc[dataset['TechSupport'] == 'No internet service','TechSupport'] = 2
dataset['TechSupport'] = dataset['TechSupport'].astype(int)

# In[None]

set(dataset['StreamingTV'])

# In[None]

dataset.loc[dataset['StreamingTV'] == 'No','StreamingTV'] = 0
dataset.loc[dataset['StreamingTV'] == 'Yes','StreamingTV'] = 1
dataset.loc[dataset['StreamingTV'] == 'No internet service','StreamingTV'] = 2
dataset['StreamingTV'] = dataset['StreamingTV'].astype(int)

# In[None]

dataset.loc[dataset['StreamingMovies'] == 'No','StreamingMovies'] = 0
dataset.loc[dataset['StreamingMovies'] == 'Yes','StreamingMovies'] = 1
dataset.loc[dataset['StreamingMovies'] == 'No internet service','StreamingMovies'] = 2
dataset['StreamingMovies'] = dataset['StreamingMovies'].astype(int)

# In[None]

set(dataset['Contract'])

# In[None]

item_mapping = {"Month-to-month":1,"One year":2,"Two year":3}
dataset['Contract'] = dataset['Contract'].map(item_mapping)
dataset['Contract'] = dataset['Contract'].astype(int)

# In[None]

set(dataset['PaperlessBilling'])

# In[None]

dataset.loc[dataset['PaperlessBilling'] == 'No','PaperlessBilling'] = 0
dataset.loc[dataset['PaperlessBilling'] == 'Yes','PaperlessBilling'] = 1
dataset['PaperlessBilling'] = dataset['PaperlessBilling'].astype(int)

# In[None]

set(dataset['PaymentMethod'])

# In[None]

item_mapping = {"Bank transfer (automatic)":1,"Credit card (automatic)":2, "Electronic check":3,"Mailed check":4}
dataset['PaymentMethod'] = dataset['PaymentMethod'].map(item_mapping)
dataset['PaymentMethod'] = dataset['PaymentMethod'].astype(int)

# In[None]

dataset['Churn'] = dataset['Churn'].astype(int)

# In[None]

#How many senior citizens contained in the data
dataset['SeniorCitizen'].value_counts().plot(kind='bar')
plt.show()

# In[None]

#Are senior citizens prone to switching network providers as easily as the rest of the population
import seaborn as sns
plt.figure(figsize=(10,3))
g = sns.barplot(x='SeniorCitizen',y='Churn',data=dataset)
plt.show()

# In[None]

data1 = dataset[['SeniorCitizen','Churn']].groupby(['SeniorCitizen'],as_index=False).mean()
data1

# In[None]

#This implies there are a good number of senior citizens who are disappointed with a particular provider and have switched connections
#Lets check the impact of gender on churn flag
data1 = dataset[['gender','Churn']].groupby(['gender'],as_index=False).mean()
data1

# In[None]

#dataset['TotalCharges'] = dataset['TotalCharges'].astype(float)
dataset['MonthlyCharges'] = dataset['MonthlyCharges'].astype(float)

# In[None]

#Lets first see how the values Total Charges and Monthly CHarges have an impact on Churn
data1 = dataset[['MonthlyCharges','Churn']].groupby(['Churn'],as_index=False).mean()
data1

# In[None]

#The monthly charges are a little higher in the case of Churn = 1. THis could be one reason for the shift
#We should probably look at why the charges are high, i.e. what services have been acquired for the same

# In[None]

data1 = dataset[['tenure','Churn']].groupby(['Churn'],as_index=False).mean()
data1

# In[None]

#The average tenure for churn = 1 is lower than that of churn = 0. So the company is possibly retaining its old customers
query = dataset[dataset['Churn'] == 1]
query

# In[None]

g = sns.barplot(x='InternetService',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='PhoneService',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='MultipleLines',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='OnlineSecurity',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='OnlineBackup',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='Partner',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='Dependents',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='DeviceProtection',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='TechSupport',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='StreamingTV',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='StreamingMovies',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='Contract',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='PaperlessBilling',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='PaymentMethod',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='SeniorCitizen',y='Churn',data=dataset)
plt.show()

# In[None]

g = sns.barplot(x='gender',y='Churn',data=dataset)
plt.show()

# In[None]

#For now, we consider the following columns:
#Payment Method
#Paperless Billing
#Contract
#Techsupport, DeviceProtection
#Partnet
#Dependents
#Online Security, Online Backup
#InternetService
#Totalcharges
#SeniorCitizen

# In[None]

from sklearn.model_selection import train_test_split
cols = ['SeniorCitizen','Contract','PaymentMethod','TechSupport','DeviceProtection','Partner','Dependents','OnlineSecurity','OnlineBackup','InternetService','PaperlessBilling','TotalCharges']
X = dataset[cols]
y = dataset['Churn']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1531319.npy", { "accuracy_score": score })

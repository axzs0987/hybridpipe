import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv("/kaggle/input/breast-cancer-prediction-dataset/Breast_cancer_data.csv",sep=",")
df.head()
df.tail()
df.info()
df.describe().T
df.isnull().sum()
df.columns
df.diagnosis.value_counts()
#sns.countplot(df.diagnosis)
#plt.show()
#sns.pairplot(df)
#plt.show()
from statsmodels.tools import add_constant
import statsmodels.api as sm
df_logit = add_constant(df)
df_logit.head()
logitmodel=sm.Logit(endog=df_logit.diagnosis,exog=df_logit.drop('diagnosis',axis=1)).fit()
print(logitmodel.summary())
para=np.exp(logitmodel.params)
para=round(para,2)
pd.DataFrame([para, logitmodel.pvalues],columns=logitmodel.params.index,index=['Odds Ratio','pvalue']).T
from sklearn.model_selection import train_test_split
x=df.drop('diagnosis',axis=1)
y=df.diagnosis
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
#lr.fit(xtrain,ytrain)
#ypred = lr.predict(xtest)
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix
#print("Accuracy with Logisitic Regression model is ",accuracy_score(ytest,ypred)*100, "%")
#print("Classification Report", classification_report(ytest,ypred))
#print("Confusion Matrix ",confusion_matrix(ytest,ypred))
#cm=sklearn.metrics.confusion_matrix(ytest,ypred)
#plt.figure(figsize=(8,5))
#sns.heatmap(cm,annot=True,fmt='.3g',xticklabels=['Predicted 0','Predicted 1'],yticklabels=['Actual 0','Actual 1'],cmap='Blues')
#plt.title('Confusion Matrix')
#plt.show()
#True_Postive= cm[1,1]
#True_Negative=cm[0,0]
#False_Positive=cm[0,1] 
#False_Negative=cm[1,0] 
#Sensitivity= True_Postive/(True_Postive+False_Negative)
#Specificity=True_Negative/(True_Negative+False_Positive)
#print('Sensitivity is ',round(Sensitivity,2))
#print('Specificity is',round(Specificity,2))
#predicted_prob=lr.predict_proba(xtest)
#predicted_prob=pd.DataFrame(predicted_prob,columns=['Prob of No cancer 0','Prob of Cancer 1'])
#predicted_prob.head()
from sklearn.metrics import roc_curve,roc_auc_score
#tpr,fpr,thresholds=roc_curve(ytest,predicted_prob['Prob of No cancer 0'])
#plt.plot(fpr,tpr)
#plt.ylabel('True Positive Rate')
#plt.xlabel('False Positive Rate')
#plt.title('ROC Curve for Breast Cancer Prediction Classfier')
#plt.show()
#print('Area Under Curve is',roc_auc_score(ytest,predicted_prob['Prob of Cancer 1']))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/abheeshnair3393_breast-cancer-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(xtrain).__name__ == "ndarray":
    np.save("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainX.npy", xtrain)
if type(xtrain).__name__ == "Series":
    xtrain.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainX.csv",encoding="gbk")
if type(xtrain).__name__ == "DataFrame":
    xtrain.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainX.csv",encoding="gbk")

if type(xtest).__name__ == "ndarray":
    np.save("hi_res_data/abheeshnair3393_breast-cancer-prediction/testX.npy", xtest)
if type(xtest).__name__ == "Series":
    xtest.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/testX.csv",encoding="gbk")
if type(xtest).__name__ == "DataFrame":
    xtest.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/testX.csv",encoding="gbk")

if type(ytrain).__name__ == "ndarray":
    np.save("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainY.npy", ytrain)
if type(ytrain).__name__ == "Series":
    ytrain.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainY.csv",encoding="gbk")
if type(ytrain).__name__ == "DataFrame":
    ytrain.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/trainY.csv",encoding="gbk")

if type(ytest).__name__ == "ndarray":
    np.save("hi_res_data/abheeshnair3393_breast-cancer-prediction/testY.npy", ytest)
if type(ytest).__name__ == "Series":
    ytest.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/testY.csv",encoding="gbk")
if type(ytest).__name__ == "DataFrame":
    ytest.to_csv("hi_res_data/abheeshnair3393_breast-cancer-prediction/testY.csv",encoding="gbk")


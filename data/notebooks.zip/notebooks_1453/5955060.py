import pandas as pd
# *# *# I# N# T# R# O# D# U# C# T# I# O# N# *# *# 
# 
# *#  # I#  # w# i# l# l#  # e# x# p# l# a# i# n#  # h# o# w#  # t# o#  # m# a# k# e#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # f# o# r#  # b# i# n# a# r# y#  # l# a# b# e# l# e# d#  # d# a# t# a# 
# *#  # W# e#  # w# i# l# l#  # u# s# e#  # t# h# e#  # p# a# n# d# a# s# ,#  # n# u# m# p# y#  # a# n# d#  # m# a# t# p# l# o# t# l# i# b#  # l# i# b# r# a# r# i# e# s# .# B# u# t#  # I# '# m#  # g# o# n# n# a#  # s# h# o# w#  # y# o# u#  # h# o# w#  # t# o#  # d# o#  # i# t#  # w# i# t# h#  # t# h# e#  # s# k# l# e# a# r# n#  # l# i# b# r# a# r# y# .# 
# 
# 
# 
# 
# 


# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt # for graphics

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

data=pd.read_csv("/kaggle/input/voicegender/voice.csv")

# O# u# r#  # d# a# t# a#  # t# y# p# e#  # a# l# l#  # f# l# o# a# t#  # 3# 4# .#  # B# u# t#  # "# l# a# b# e# l#  # d# a# t# a# "#  # i# s#  # n# o# t# .#  # I# t#  # i# s#  # c# h# a# n# g# i# n# g# .# W# e#  # w# i# l# l#  # m# a# k# e#  # w# o# m# a# n#  # 1#  # a# n# d#  # m# a# n#  # 0# .#  # T# h# e# n#  # w# e#  # t# r# a# n# s# f# e# r#  # t# h# i# s#  # d# a# t# a#  # t# o#  # Y#  # a# n# d#  # l# a# b# e# l#  # d# a# t# a#  # w# i# l# l#  # d# r# o# p#  # f# r# o# m#  # x# _# d# a# t# a# .#  

# In[None]

data.label=[0 if each == "male" else 1 for each in data.label] # male -> 0 , female -> 1
y=data.label.values
x_data=data.drop(["label"],axis=1)

# W# e#  # w# i# l# l#  # s# c# a# l# e#  # a# l# l#  # v# a# l# u# e# s#  # f# r# o# m#  # 0#  # t# o#  # 1# .

# In[None]

#Normalization
x = (x_data-np.min(x_data))/(np.max(x_data)+np.max(x_data))

# W# e#  # a# r# e#  # s# p# l# i# t# t# i# n# g#  # o# u# r#  # d# a# t# a#  # f# o# r#  # t# r# a# i# n# i# n# g# .#  # W# e#  # a# r# e#  # u# s# i# n# g#  # s# k# l# e# a# r# n#  # l# i# b# r# a# r# y#  # h# e# r# e# .#  # W# e#  # t# a# k# e#  # t# h# e#  # t# r# a# n# s# p# o# s# e#  # t# o#  # m# a# t# c# h#  # t# h# e#  # m# a# t# r# i# c# e# s#  # o# f#  # t# h# e#  # t# r# a# i# n# i# n# g#  # d# a# t# a

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5955060.npy", { "accuracy_score": score })

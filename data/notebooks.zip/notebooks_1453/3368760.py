import pandas as pd
# 1# .#  # E# D# A#  # (# E# x# p# l# o# t# a# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# )# 
# 2# .#  # H# a# n# d# -# m# a# d# e#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# 3# .#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # w# i# t# h#  # s# k# l# e# a# r# n

# *# *# *# *# E# D# A#  # (# E# x# p# l# o# t# a# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# )# *# *# *# *

# In[31]

# libraries
import numpy as np                
import pandas as pd
import matplotlib.pyplot as plt

# In[32]

# read csv
data = pd.read_csv("../input/weatherAUS.csv")

# In[33]

# drop the unnecessary columns
data.drop(["Date", "Location", "WindGustDir", "WindDir9am", "WindDir3pm"], axis=1, inplace=True)

# W# e#  # h# a# v# e#  # t# o#  # g# e# t#  # r# i# d#  # o# f#  # *# *# N# a# N# *# *# ,#  # *# *# Y# E# S# *# *#  # a# n# d#  # *# *# N# O# *# *# .

# In[34]

# convert "NO" to 0 and "YES" to 1
data.RainTomorrow = [ 1 if each == "Yes" else 0 for each in data.RainTomorrow ]
data.RainToday = [ 1 if each == "Yes" else 0 for each in data.RainToday ]

# convert Nan to 0
data = data.fillna(0)

data.head()

# In[35]

data.info()

# In[36]

# y is results. x is features without "RainTomorrow" and 'nan'
y = data.RainTomorrow.values
x = data.drop(["RainTomorrow"], axis=1)


# *# *# *# *# H# a# n# d# -# m# a# d# e#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# *# *# *# *

# In[37]

# normalization
x = ((x - np.min(x))/(np.max(x) - np.min(x))).values

# In[38]

# train/test split
from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3368760.npy", { "accuracy_score": score })

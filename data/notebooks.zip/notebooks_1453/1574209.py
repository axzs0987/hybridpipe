import pandas as pd
# ##  # C# o# n# t# e# n# t# s# 
# 1# .#  # [# I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # P# a# c# k# a# g# e# s# ]# (# ## p# 1# )# 
# 2# .#  # [# L# o# a# d# i# n# g#  # a# n# d#  # V# i# e# w# i# n# g#  # D# a# t# a#  # S# e# t# ]# (# ## p# 2# )# 
# 3# .#  # [# C# l# e# a# n#  # a# n# d#  # N# o# r# m# a# l# i# z# a# t# i# o# n#  # D# a# t# a# ]# (# ## p# 3# )# 
# 4# .#  # [# V# i# s# u# a# l# i# z# a# t# i# o# n# ]# (# ## p# 4# )# 
# 5# .#  # [# I# n# i# t# i# a# l# i# z# i# n# g# ,#  # O# p# t# i# m# i# z# i# n# g# ,#  # a# n# d#  # P# r# e# d# i# c# t# i# n# g# ]# (# ## p# 5# )

# <# a#  # i# d# =# "# p# 1# "# ># <# /# a# ># 
# ##  # 1# .#  # I# m# p# o# r# t# i# n# g#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # P# a# c# k# a# g# e# s# 
# W# e#  # w# i# l# l#  # u# s# e#  # t# h# e# s# e#  # p# a# c# k# a# g# e# s#  # t# o#  # h# e# l# p#  # u# s#  # m# a# n# i# p# u# l# a# t# e#  # t# h# e#  # d# a# t# a#  # a# n# d#  # v# i# s# u# a# l# i# z# e#  # t# h# e#  # f# e# a# t# u# r# e# s# /# l# a# b# e# l# s#  # a# s#  # w# e# l# l#  # a# s#  # m# e# a# s# u# r# e#  # h# o# w#  # w# e# l# l#  # o# u# r#  # m# o# d# e# l#  # p# e# r# f# o# r# m# e# d# .#  # N# u# m# p# y#  # a# n# d#  # P# a# n# d# a# s#  # a# r# e#  # h# e# l# p# f# u# l#  # f# o# r#  # m# a# n# i# p# u# l# a# t# i# n# g#  # t# h# e#  # d# a# t# a# f# r# a# m# e#  # a# n# d#  # i# t# s#  # c# o# l# u# m# n# s#  # a# n# d#  # c# e# l# l# s# .#  # W# e#  # w# i# l# l#  # u# s# e#  # m# a# t# p# l# o# t# l# i# b#  # a# l# o# n# g#  # w# i# t# h#  # S# e# a# b# o# r# n#  # t# o#  # v# i# s# u# a# l# i# z# e#  # o# u# r#  # d# a# t# a# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# <# a#  # i# d# =# "# p# 2# "# ># <# /# a# ># 
# ##  # 2# .#  # L# o# a# d# i# n# g#  # a# n# d#  # V# i# e# w# i# n# g#  # D# a# t# a#  # S# e# t# 
# W# i# t# h#  # P# a# n# d# a# s# ,#  # w# e#  # c# a# n#  # l# o# a# d#  # b# o# t# h#  # t# h# e#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # s# e# t#  # t# h# a# t#  # w# e#  # w# i# l#  # l# a# t# e# r#  # u# s# e#  # t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # o# u# r#  # m# o# d# e# l# .#  # B# e# f# o# r# e#  # w# e#  # b# e# g# i# n# ,#  # w# e#  # s# h# o# u# l# d#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # o# u# r#  # d# a# t# a#  # t# a# b# l# e#  # t# o#  # s# e# e#  # t# h# e#  # v# a# l# u# e# s#  # t# h# a# t#  # w# e# '# l# l#  # b# e#  # w# o# r# k# i# n# g#  # w# i# t# h# .#  # W# e#  # c# a# n#  # u# s# e#  # t# h# e#  # h# e# a# d#  # a# n# d#  # d# e# s# c# r# i# b# e#  # f# u# n# c# t# i# o# n#  # t# o#  # l# o# o# k#  # a# t#  # s# o# m# e#  # s# a# m# p# l# e#  # d# a# t# a#  # a# n# d#  # s# t# a# t# i# s# t# i# c# s# .

# In[None]

# Import dataset
data = pd.read_csv("../input/voice.csv")

# In[None]

# Showing five columns
data.head()

# In[None]

# Showing five column
data.tail()

# In[None]

# Describing data show us statics features
data.describe()

# <# a#  # i# d# =# "# p# 3# "# ># <# /# a# ># 
# ##  # 3# .#  # C# l# e# a# n#  # a# n# d#  # N# o# r# m# a# l# i# z# a# t# i# o# n#  # D# a# t# a# 
# W# e#  # n# e# e# d#  # t# o#  # c# h# a# n# g# e#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a#  # t# o#  # n# u# m# e# r# i# c#  # d# a# t# a# .

# In[None]

data.label = [1 if each == "female" else 0 for each in data.label ]
y = data.label.values
x_data = data.drop(["label"], axis = 1)

# In[None]

# Normalization
x = (x_data -np.min(x_data))/(np.max(x_data)-np.min(x_data)).values

# <# a#  # i# d# =# "# p# 4# "# ># <# /# a# ># 
# ##  # 4# .#  # V# i# s# u# a# l# i# z# a# t# i# o# n# 
# 
# I# n#  # o# r# d# e# r#  # t# o#  # v# i# s# u# a# l# i# z# a# t# e#  # t# h# e#  # d# a# t# a# ,#  # w# e#  # a# r# e#  # g# o# i# n# g# o#  # t# o#  # u# s# e#  # m# a# t# p# l# o# t# l# i# b#  # a# n# d#  # s# e# a# b# o# r# n# .#  # B# e# f# o# r# e#  # t# h# e#  # v# i# s# u# a# l# i# z# a# t# i# o# n#  # d# o# n# '# t#  # f# o# r# g# e# t#  # t# h# e#  # n# o# r# m# a# l# i# z# e#  # t# h# e#  # d# a# t# a# .

# In[None]

#correlation map
f,ax = plt.subplots(figsize=(20, 20))
sns.heatmap(x.corr(), annot=True, linewidths=.5, fmt= '.1f',ax=ax)

# In[None]

sns.set(style="white")
df = x.loc[:,['meandom','mindom','maxdom']]
g = sns.PairGrid(df, diag_sharey=False)
g.map_lower(sns.kdeplot, cmap="Blues_d")
g.map_upper(plt.scatter)
g.map_diag(sns.kdeplot, lw=3)

# In[None]

# Plotting
data.plot(kind='scatter', x='meanfreq', y='dfrange')
data.plot(kind='kde', y='meanfreq')

# In[None]

# Pairplotting
sns.pairplot(data[['meanfreq', 'Q25', 'Q75', 'skew', 'centroid', 'label']], 
                 hue='label', size=3)

# <# a#  # i# d# =# "# p# 5# "# ># <# /# a# ># 
# ##  # 5# .#  # I# n# i# t# i# a# l# i# z# i# n# g# ,#  # O# p# t# i# m# i# z# i# n# g# ,#  # a# n# d#  # P# r# e# d# i# c# t# i# n# g# 
# N# o# w#  # t# h# a# t#  # o# u# r#  # d# a# t# a#  # h# a# s#  # b# e# e# n#  # p# r# o# c# e# s# s# e# d#  # a# n# d#  # f# o# r# m# m# a# t# e# d#  # p# r# o# p# e# r# l# y# ,#  # a# n# d#  # t# h# a# t#  # w# e#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # g# e# n# e# r# a# l#  # d# a# t# a#  # w# e# '# r# e#  # w# o# r# k# i# n# g#  # w# i# t# h#  # a# s#  # w# e# l# l#  # a# s#  # t# h# e#  # t# r# e# n# d# s#  # a# n# d#  # a# s# s# o# c# i# a# t# i# o# n# s# ,#  # w# e#  # c# a# n#  # s# t# a# r# t#  # t# o#  # b# u# i# l# d#  # o# u# r#  # m# o# d# e# l# .#  # W# e#  # c# a# n#  # i# m# p# o# r# t#  # d# i# f# f# e# r# e# n# t#  # c# l# a# s# s# i# f# i# e# r# s#  # f# r# o# m#  # s# k# l# e# a# r# n# .#  

# ##  # S# V# M

# In[None]

# Train and test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1574209.npy", { "accuracy_score": score })

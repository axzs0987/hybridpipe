import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv("../input/us-news-and-world-reports-college-data/College.csv", index_col=0)
df.head()
df.info()
df["Private"] = pd.get_dummies(df["Private"], drop_first=True) 
df.head()
X = df.drop("Private", axis=1) 
y = df["Private"] 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
logm = LogisticRegression()
#logm.solver = "liblinear" 
#logm.fit(X_train, y_train) 
#predictions = logm.predict(X_test)
from sklearn.metrics import classification_report, confusion_matrix
#print(classification_report(y_test, predictions))
#print(confusion_matrix(y_test, predictions))
from sklearn.model_selection import cross_val_score 
#print(cross_val_score(logm, X, y, cv=10))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aonursert_ml-hw-2-university-classification-with-log-reg.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aonursert_ml-hw-2-university-classification-with-log-reg/testY.csv",encoding="gbk")


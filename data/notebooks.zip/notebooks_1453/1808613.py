import pandas as pd
# ##  # *# *# 5# E# D# 3# S#  # M# i# n# i#  # P# r# o# j# e# c# t#  # ## 9# *# *# 
# ## ##  # M# o# t# i# v# a# t# i# o# n# 
# I#  # h# a# v# e#  # b# e# e# n#  # w# o# r# k# i# n# g#  # o# n#  # t# h# i# s#  # k# e# r# n# e# l#  # a# s#  # p# a# r# t#  # o# f#  # t# h# e#  # 5# t# h#  # E# u# r# o# p# e# a# n#  # D# a# t# a#  # S# c# i# e# n# c# e#  # S# u# m# m# e# r#  # S# c# h# o# o# l# .#  # I# n#  # a# d# d# i# t# i# o# n#  # t# o#  # d# e# v# e# l# o# p# i# n# g#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l#  # f# o# r#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # t# h# e#  # a# i# m#  # i# s#  # a# l# s# o#  # t# o#  # d# e# v# e# l# o# p#  # a#  # b# u# s# i# n# e# s# s#  # m# o# d# e# l#  # w# h# o# s# e#  # c# o# r# e#  # e# l# e# m# e# n# t#  # i# s#  # t# h# e#  # s# o# l# u# t# i# o# n#  # t# o#  # t# h# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # p# r# o# b# l# e# m# .# 
# 
# T# h# e#  # p# r# o# b# l# e# m#  # i# s#  # t# o#  # c# l# a# s# s# i# f# y#  # w# h# e# t# h# e# r#  # a#  # p# e# r# s# o# n#  # e# a# r# n# s#  # m# o# r# e#  # o# r#  # l# e# s# s#  # t# h# a# n#  # 5# 0# k# .#  # A# s#  # d# a# t# a#  # s# o# u# r# c# e#  # t# h# e#  # [# U# C# I#  # A# d# u# l# t#  # D# a# t# a#  # S# e# t# ]# (# h# t# t# p# :# /# /# a# r# c# h# i# v# e# .# i# c# s# .# u# c# i# .# e# d# u# /# m# l# /# d# a# t# a# s# e# t# s# /# A# d# u# l# t# )#  # i# s#  # u# s# e# d#  # w# h# i# c# h#  # i# s#  # a# l# s# o#  # a# v# a# i# l# a# b# l# e#  # f# o# r#  # i# m# p# o# r# t#  # o# n#  # K# a# g# g# l# e# .# 
# 
# T# h# i# s#  # k# e# r# n# e# l#  # i# s#  # s# t# r# u# c# t# u# r# e# d#  # i# n#  # f# i# v# e#  # p# a# r# t# s# :# 
# 1# .#  # G# a# t# h# e# r# i# n# g#  # D# a# t# a# 
# 2# .#  # D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n# 
# 3# .#  # D# e# v# e# l# o# p# i# n# g#  # a#  # B# u# s# i# n# e# s# s#  # M# o# d# e# l# l# 
# 4# .#  # D# a# t# a#  # C# l# e# a# n# i# n# g# 
# 5# .#  # M# o# d# e# l#  # t# h# e#  # D# a# t# a# 
# 6# .#  # C# o# n# c# l# u# s# i# o# n

# ##  # 1# .#  # G# a# t# h# e# r# i# n# g#  # D# a# t# a# 
# ## ##  # 1# .# 1#  # T# h# e#  # D# a# t# a# s# e# t# 
# 
# T# h# e#  # d# a# t# a# s# e# t#  # w# a# s#  # c# r# e# a# t# e# d#  # i# n#  # 1# 9# 9# 4#  # b# y#  # B# a# r# r# y#  # B# e# c# k# e# r# .#  # I# t#  # i# s#  # a# n#  # e# x# t# r# a# c# t# i# o# n#  # o# f#  # t# h# e#  # c# e# n# s# u# s#  # d# a# t# a# b# a# s# e#  # o# f#  # t# h# e#  # [# U# n# i# t# e# d#  # S# t# a# t# e# s#  # C# e# n# s# u# s#  # B# u# r# e# u# s# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# c# e# n# s# u# s# .# g# o# v# /# e# n# .# h# t# m# l# )#  # f# r# o# m#  # 1# 9# 9# 4# .#  # T# o# g# e# t# h# e# r#  # w# i# t# h#  # R# o# n# n# y#  # K# o# h# a# v# i# ,#  # B# e# c# k# e# r#  # p# u# b# l# i# s# h# e# d#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n#  # 1# 9# 9# 6# .

# ## ##  # 1# .# 2#  # G# e# t#  # t# h# e#  # D# a# t# a# 
# L# e# t# '# s#  # s# t# a# r# t#  # w# i# t# h#  # c# h# e# c# k# i# n# g#  # t# h# e#  # p# y# h# t# o# n#  # v# e# r# s# i# o# n#  # a# n# d#  # i# m# p# o# r# t# i# n# g#  # t# h# e#  # d# a# t# a# .

# In[None]

#Start with importing system and operating system libraries
import sys
import os

#Suppress warnings, this will not affect the result
import warnings
from sklearn.exceptions import DataConversionWarning
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)
warnings.filterwarnings(action='ignore', category=DataConversionWarning)

#Check python version
print('Python version:',sys.version)

#Import pandas and numpy
import pandas as pd
import numpy as np

#Load the data set
data = pd.read_csv('../input/adult.csv', sep=',')
data.head()

# ##  # 2# .#  # D# a# t# a#  # E# x# p# l# o# r# a# t# i# o# n# 
# A# s#  # s# e# e# n#  # a# b# o# v# e# ,#  # t# h# e# r# e#  # a# r# e#  # a# l# r# e# a# d# y#  # s# o# m# e#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # f# i# r# s# t#  # r# o# w# s#  # o# f#  # t# h# e#  # d# a# t# a#  # s# e# t# .#  # S# o#  # l# e# t# '# s#  # l# o# o# k#  # a# t#  # t# h# e#  # r# e# l# a# t# i# v# e#  # a# m# o# u# n# t#  # o# f#  # m# i# s# s# i# n# g#  # d# a# t# a#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t#  # a# n# d#  # s# e# e#  # i# f#  # i# t#  # h# a# s#  # a# n#  # i# m# p# a# c# t# .

# In[None]

import matplotlib.pyplot as plt

#Initialize an empty array to collect the sum of missing values per column
mvs = []

#Count the missing values
for x in data.columns:
    mvs.append(data[x].isin(["?"]).sum())

#Build the plot
fig, ax =  plt.subplots(figsize=(10,3))
index   = np.arange(data.shape[1])

ax.bar(index, mvs, alpha = 0.4, color = 'b')
ax.set_ylabel('Missing Values')
ax.set_xticks(index)
ax.set_xticklabels((data.columns))

fig.tight_layout()

plt.xticks(rotation=45)
plt.show()

# In[None]

#Only three features contain missing values
#To see if the missing values have an significant effect on the dataset
#Visualize the missing values compared with the complete dataset to see the effect

#Build the plot
yvalues = [data.shape[0], mvs[1], mvs[6], mvs[13]]

fig, ax = plt.subplots()
index   = np.arange(4)

ax.bar(index, yvalues, alpha = 0.4, color = 'b')
ax.set_ylabel('Data')
ax.set_xticks(index)
ax.set_xticklabels(('data set size','workclass','occupation','native.country'))

fig.tight_layout()

plt.xticks(rotation=45)
plt.show()

# I# n#  # a# d# d# i# t# i# o# n#  # t# o#  # t# h# e#  # s# t# r# u# c# t# u# r# a# l#  # p# r# o# p# e# r# t# i# e# s#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # w# e#  # a# l# s# o#  # w# a# n# t#  # t# o#  # k# n# o# w#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # w# i# t# h# i# n#  # t# h# e#  # d# a# t# a# .#  # W# h# a# t#  # i# s#  # t# h# e#  # a# v# e# r# a# g# e#  # a# g# e#  # a# n# d#  # w# h# a# t#  # i# s#  # t# h# e#  # a# g# e#  # s# t# r# u# c# t# u# r# e#  # l# i# k# e# ?#  # A# r# e#  # t# h# e# r# e#  # m# o# r# e#  # m# e# n#  # o# r#  # w# o# m# e# n#  # c# o# v# e# r# e# d#  # b# y#  # t# h# e#  # d# a# t# a# s# e# t# ?#  # H# o# w#  # m# a# n# y#  # h# o# u# r# s#  # d# o#  # p# e# o# p# l# e#  # w# o# r# k#  # o# n#  # a# v# e# r# a# g# e# ?#  # W# h# a# t#  # a# r# e#  # t# h# e#  # t# o# p#  # 5#  # n# a# t# i# v# e#  # c# o# u# n# t# r# i# e# s# ?#  # A# n# d#  # h# o# w#  # i# s#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # v# a# r# i# a# b# l# e# ,#  # i# n# c# o# m# e# ,#  # d# i# s# t# r# i# b# u# t# e# d# ?

# In[None]

#Question 1: Age

#Set up a histogram
plt.hist(data.age, facecolor='green', alpha=0.5, bins=18, edgecolor='black')
plt.xlabel('Age')
plt.axvline(data.age.mean(), color='red', label='average age')
plt.axis([15, 95, 0, 3500])
plt.legend()
plt.show()

# T# h# e#  # h# i# s# t# o# g# r# a# m#  # a# c# t# s#  # a# s#  # e# x# p# e# c# t# e# d# .#  # T# h# e#  # n# u# m# b# e# r#  # o# f#  # e# m# p# l# o# y# e# e# s#  # r# i# s# e# s#  # s# h# a# r# p# l# y#  # a# t#  # t# h# e#  # b# e# g# i# n# n# i# n# g#  # o# f#  # t# h# e#  # g# r# a# p# h#  # u# n# t# i# l#  # i# t#  # r# e# a# c# h# e# s#  # i# t# s#  # m# a# x# i# m# u# m#  # b# e# t# w# e# e# n#  # 3# 0#  # a# n# d#  # 4# 5#  # y# e# a# r# s# .#  # T# h# i# s#  # i# s#  # a# l# s# o#  # w# h# e# r# e#  # t# h# e#  # a# v# e# r# a# g# e#  # a# g# e#  # o# f#  # 3# 8#  # i# s# .#  # A# f# t# e# r#  # t# h# a# t# ,#  # t# h# e#  # g# r# a# p# h#  # f# a# l# l# s#  # s# l# o# w# l# y# .#  # W# h# a# t#  # i# s#  # n# o# t# i# c# e# a# b# l# e#  # i# s#  # t# h# a# t#  # t# o# w# a# r# d# s#  # t# h# e#  # e# n# d#  # t# h# e# r# e#  # i# s#  # g# r# o# w# t# h#  # a# g# a# i# n# .

# In[None]

#Question 2: Gender

#Count male and female
m = 0
f = 0
for g in data.sex:
    if g == 'Male':
        m += 1
    if g == 'Female':
        f += 1

#Set up pie chart
colors = ['lightskyblue', 'lightcoral']
values = [m, f] 
labels = ['Male', 'Female'] 
plt.pie(values, labels=labels, colors=colors, shadow=True, startangle=90, autopct='%.2f')
plt.axis('equal')
plt.tight_layout()
plt.show()

# T# h# e#  # g# r# a# p# h#  # s# h# o# w# s#  # t# h# a# t#  # m# o# r# e#  # t# h# a# n#  # t# w# i# c# e#  # a# s#  # m# a# n# y#  # m# e# n#  # a# r# e#  # r# e# p# r# e# s# e# n# t# e# d#  # i# n#  # t# h# i# s#  # d# a# t# a# s# e# t#  # t# h# a# n#  # w# o# m# e# n# .

# In[None]

#Question 3: Hours per Week

print('Mean:', data['hours.per.week'].mean())
#Set up a histogram
plt.hist(data['hours.per.week'], facecolor='green', alpha=0.5, bins=18, edgecolor='black')
plt.xlabel('Age')
plt.axvline(data['hours.per.week'].mean(), color='red', label='average hour per week')
plt.legend()
plt.show()

# T# h# i# s#  # s# t# a# t# i# s# t# i# c#  # w# a# s#  # t# o#  # b# e#  # e# x# p# e# c# t# e# d# .#  # I# n#  # t# h# e#  # d# a# t# a# s# e# t#  # t# h# e# r# e#  # i# s#  # a#  # b# i# g#  # p# e# a# k#  # o# f#  # 4# 0#  # h# o# u# r# s#  # p# e# r#  # w# e# e# k# .#  # T# h# i# s#  # i# s#  # a# l# s# o#  # p# r# o# v# e# n#  # b# y#  # t# h# e#  # a# v# e# r# a# g# e#  # t# i# m# e#  # o# f#  # 4# 0# .# 4# 3#  # h# o# u# r# s#  # p# e# r#  # w# e# e# k# .#  # T# h# e#  # i# n# c# r# e# a# s# e#  # o# f#  # a# l# m# o# s# t#  # 1# 0# 0# 0#  # e# m# p# l# o# y# e# e# s#  # w# o# r# k# i# n# g#  # i# n#  # a#  # 5# 0#  # h# o# u# r#  # w# e# e# k#  # s# h# o# u# l# d#  # a# l# s# o#  # b# e#  # n# o# t# e# d# .

# In[None]

#Question 4: Native Country

#Count the countries 
f = data['native.country'].value_counts()

#Show the top 5
f.head()

# A# b# o# u# t#  # 9# 0# %#  # o# f#  # a# l# l#  # p# e# r# s# o# n# s#  # c# o# m# e#  # f# r# o# m#  # t# h# e#  # U# S# A# .#  # T# h# i# s#  # i# s#  # d# u# e#  # t# o#  # t# h# e#  # f# a# c# t#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # w# a# s#  # t# a# k# e# n#  # f# r# o# m#  # t# h# e#  # d# a# t# a# b# a# s# e#  # o# f#  # t# h# e#  # U# .# S# .#  # C# e# n# s# u# s#  # B# u# r# e# a# u# ,#  # s# o#  # i# t#  # w# a# s#  # a#  # c# e# n# s# u# s#  # i# n#  # t# h# e#  # U# S# .

# In[None]

#Question 5: Income

#Count how often people earn more and less than 50k
m = 0
l = 0
for i in data.income:
    if i == '<=50K':
        l += 1
    if i == '>50K':
        m += 1

#Set up pie chart
colors = ['lightskyblue', 'lightcoral']
values = [l, m] 
labels = ['<=50k', '>50k'] 
plt.pie(values, labels=labels, colors=colors, shadow=True, startangle=90, autopct='%.2f')
plt.axis('equal')
plt.tight_layout()
plt.show()

# A# b# o# u# t#  # t# h# r# e# e#  # q# u# a# r# t# e# r# s#  # o# f#  # e# m# p# l# o# y# e# e# s#  # e# a# r# n#  # l# e# s# s#  # t# h# a# n#  # 5# 0# k# .#  # T# h# i# s#  # f# i# g# u# r# e#  # w# i# l# l#  # a# l# s# o#  # b# e#  # i# m# p# o# r# t# a# n# t#  # d# u# r# i# n# g#  # t# h# e#  # e# v# a# l# u# a# t# i# o# n#  # o# f#  # o# u# r#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l# .#  # T# o#  # b# e#  # u# s# a# b# l# e# ,#  # i# t#  # m# u# s# t#  # b# e#  # s# i# g# n# i# f# i# c# a# n# t# l# y#  # b# e# t# t# e# r#  # t# h# a# n#  # 7# 5# %# .

# ##  # 3# .#  # D# e# v# e# l# o# p# i# n# g#  # a#  # B# u# s# i# n# e# s# s#  # M# o# d# e# l# 
# 
# N# o# w#  # t# h# a# t#  # y# o# u#  # h# a# v# e#  # g# a# i# n# e# d#  # a# n#  # i# n# s# i# g# h# t#  # i# n# t# o#  # t# h# e#  # d# a# t# a#  # s# e# t# ,#  # y# o# u#  # c# a# n#  # b# e# g# i# n#  # t# o#  # d# e# f# i# n# e#  # t# h# e#  # p# r# o# b# l# e# m# .#  # S# e# v# e# r# a# l#  # Q# u# e# s# t# i# o# n# s#  # h# a# v# e#  # t# o#  # b# e#  # a# s# k# e# d# .#  # W# h# i# c# h#  # p# r# o# b# l# e# m#  # s# h# o# u# l# d#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l#  # s# o# l# v# e# ?#  # W# h# y#  # i# s#  # i# t#  # r# e# l# e# v# a# n# t#  # t# o#  # s# o# l# v# e#  # t# h# e#  # p# r# o# b# l# e# m# ?#  # F# o# r#  # w# h# o# m#  # i# s#  # t# h# e#  # s# o# l# u# t# i# o# n#  # i# m# p# o# r# t# a# n# t# ?# 
# 
# B# e# f# o# r# e#  # w# e#  # d# e# v# o# t# e#  # o# u# r# s# e# l# v# e# s#  # t# o#  # t# h# e#  # b# e# n# e# f# i# t# s#  # o# f#  # p# r# o# b# l# e# m#  # s# o# l# v# i# n# g# ,#  # w# e#  # f# i# r# s# t#  # c# l# a# r# i# f# y#  # f# o# r#  # w# h# o# m#  # t# h# e#  # p# r# o# b# l# e# m#  # w# i# l# l#  # b# e#  # i# m# p# o# r# t# a# n# t# .#  # T# h# i# s#  # q# u# e# s# t# i# o# n#  # i# s#  # v# e# r# y#  # e# a# s# y#  # t# o#  # a# n# s# w# e# r#  # b# e# c# a# u# s# e#  # i# t#  # i# s#  # a# n#  # U# S#  # A# m# e# r# i# c# a# n#  # d# a# t# a# s# e# t# .#  # T# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t#  # o# n# l# y#  # c# o# n# c# e# r# n# s#  # t# h# e#  # A# m# e# r# i# c# a# n#  # m# a# r# k# e# t# ,#  # w# h# i# c# h#  # w# e#  # w# e# r# e#  # a# b# l# e#  # t# o#  # s# h# o# w#  # i# n#  # p# a# r# t#  # w# i# t# h#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# h# e#  # n# a# t# i# v# e#  # c# o# u# n# t# r# i# e# s# .#  # A#  # s# p# e# c# i# a# l#  # f# e# a# t# u# r# e#  # o# f#  # t# h# e#  # U# S#  # m# a# r# k# e# t#  # i# s#  # t# h# e#  # h# a# n# d# l# i# n# g#  # o# f#  # m# o# n# e# y# .#  # O# r#  # r# a# t# h# e# r# ,#  # d# e# a# l# i# n# g#  # w# i# t# h#  # d# e# b# t# .#  # I# n#  # c# o# n# t# r# a# s# t#  # t# o#  # o# t# h# e# r#  # m# a# r# k# e# t# s# ,#  # s# u# c# h#  # a# s#  # t# h# e#  # G# e# r# m# a# n# -# s# p# e# a# k# i# n# g#  # c# o# u# n# t# r# i# e# s# ,#  # c# r# e# d# i# t# s#  # i# n#  # t# h# e#  # U# S#  # a# r# e#  # n# o# t#  # s# o#  # r# i# d# i# c# u# l# e# d#  # a# n# d#  # a# r# e#  # o# f# t# e# n#  # t# h# e#  # o# n# l# y#  # m# e# a# n# s# .#  # A# n#  # e# x# a# m# p# l# e#  # o# f#  # t# h# i# s#  # w# o# u# l# d#  # b# e#  # t# h# e#  # i# n# d# e# b# t# e# d# n# e# s# s#  # t# h# a# t#  # t# h# e#  # m# a# j# o# r# i# t# y#  # o# f#  # s# t# u# d# e# n# t# s#  # h# a# v# e#  # t# o#  # a# f# f# o# r# d#  # b# e# c# a# u# s# e#  # t# h# e# y#  # w# o# u# l# d#  # o# t# h# e# r# w# i# s# e#  # n# o# t#  # b# e#  # a# b# l# e#  # t# o#  # p# a# y#  # t# h# e#  # h# i# g# h#  # t# u# i# t# i# o# n#  # f# e# e# s# .#  # 
# 
# T# h# a# t#  # i# s#  # w# h# y#  # c# r# e# d# i# t#  # i# n# s# t# i# t# u# t# i# o# n# s#  # o# f# t# e# n#  # h# a# v# e#  # t# o#  # a# s# k#  # t# h# e# m# s# e# l# v# e# s#  # w# h# e# t# h# e# r#  # s# o# m# e# o# n# e#  # i# s#  # c# r# e# d# i# t# w# o# r# t# h# y# .#  # A# n# d#  # h# e# r# e#  # t# h# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l#  # s# h# o# u# l# d#  # b# e#  # a#  # s# o# l# u# t# i# o# n# .#  # B# y#  # r# e# c# o# r# d# i# n# g#  # s# i# m# p# l# e#  # p# e# r# s# o# n# a# l#  # d# a# t# a# ,#  # e# m# p# l# o# y# e# e# s# ,#  # w# i# t# h# o# u# t#  # a#  # s# t# a# t# i# s# t# i# c# a# l#  # b# a# c# k# g# r# o# u# n# d# ,#  # s# h# o# u# l# d#  # b# e#  # a# b# l# e#  # t# o#  # d# e# t# e# r# m# i# n# e#  # t# h# e#  # c# r# e# d# i# t# w# o# r# t# h# i# n# e# s# s#  # o# f#  # i# n# d# i# v# i# d# u# a# l#  # p# e# r# s# o# n# s# .# 
# 
# N# o# w#  # t# h# a# t#  # t# h# e#  # p# r# o# b# l# e# m#  # h# a# s#  # b# e# e# n#  # d# e# f# i# n# e# d# ,#  # y# o# u#  # c# a# n#  # p# r# o# c# e# e# d#  # a# n# d#  # t# a# k# e#  # t# h# e#  # n# e# x# t#  # s# t# e# p#  # d# e# v# e# l# o# p# i# n# g#  # a#  # m# o# d# e# l# .

# ##  # 4# .#  # D# a# t# a#  # C# l# e# a# n# i# n# g# 
# 
# D# a# t# a#  # c# l# e# a# n# i# n# g#  # i# s#  # a# b# o# u# t#  # s# i# m# p# l# i# f# y# i# n# g#  # t# h# e#  # d# a# t# a# .#  # A#  # d# a# t# a#  # m# o# d# e# l#  # i# s#  # t# o#  # b# e#  # c# r# e# a# t# e# d#  # w# h# i# c# h#  # e# n# a# b# l# e# s#  # a#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # t# o#  # p# r# o# c# e# s# s#  # t# h# e#  # i# n# f# o# r# m# a# t# i# o# n#  # o# p# t# i# m# a# l# l# y# .#  # F# o# r#  # t# h# i# s#  # p# u# r# p# o# s# e# ,#  # i# t#  # s# h# o# u# l# d#  # b# e#  # a# v# o# i# d# e# d#  # t# o#  # l# e# a# v# e#  # u# n# n# e# c# e# s# s# a# r# y#  # d# a# t# a#  # a# n# d#  # i# n# f# o# r# m# a# t# i# o# n#  # r# e# d# u# n# d# a# n# c# i# e# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .# 
# 
# B# u# t#  # b# e# f# o# r# e#  # w# e#  # t# a# k# e#  # a#  # c# l# o# s# e# r#  # l# o# o# k#  # a# t#  # t# h# e#  # i# n# d# i# v# i# d# u# a# l#  # f# e# a# t# u# r# e# s# ,#  # w# e#  # f# i# r# s# t#  # g# o#  # i# n# t# o#  # t# h# e#  # s# t# r# u# c# t# u# r# a# l#  # c# o# n# d# i# t# i# o# n#  # o# f#  # t# h# e#  # d# a# t# a# .#  # A# s#  # s# e# e# n#  # a# b# o# v# e# ,#  # a#  # s# m# a# l# l#  # p# a# r# t#  # o# f#  # t# h# e#  # d# a# t# a#  # h# a# s#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .#  # D# u# e#  # t# o#  # t# h# e#  # f# a# c# t#  # t# h# e# r# e#  # i# s#  # o# n# l# y#  # a#  # l# o# w#  # p# e# r# c# e# n# t# a# g# e#  # o# f#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # d# a# t# a# ,#  # w# e#  # c# a# n#  # d# e# l# e# t# e#  # t# h# i# s#  # r# o# w# s# .

# In[None]

print('Number of rows with missing values:', data.shape[0],'\n')

#Save the number of size of the dataset before deleting the missing values
numRows = data.shape[0]

#Check if there are missing values in the dataset and delete the data if so
for x in data.columns:
    mv = data[x].isin(["?"]).sum()
    if mv > 0:
        data = data[data[x] != '?']

print('Number of rows without missing values:',data.shape[0])
print('We dropped of',numRows - data.shape[0],'rows')

#Plot a pie chart to visualize the result
colors = ['lightskyblue', 'lightcoral']
patches, texts = plt.pie([data.shape[0], numRows - data.shape[0]], colors=colors, shadow=True, startangle=90)
plt.legend(patches, ['Number of Rows', 'Number of dropped Rows'], loc="best")
plt.axis('equal')
plt.tight_layout()
plt.show()

# A# f# t# e# r#  # d# e# l# e# t# i# n# g#  # a# b# o# u# t#  # 2# 4# 0# 0#  # r# o# w# s#  # c# o# n# t# a# i# n# i# n# g#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # t# h# e#  # d# a# t# a#  # s# e# t#  # i# s#  # s# t# i# l# l#  # b# i# g#  # e# n# o# u# g# h#  # t# o#  # b# u# i# l# d#  # a#  # v# a# l# i# d#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l#  # o# n#  # i# t# .# 
# 
# ## ##  # 4# .# 1#  # F# e# a# t# u# r# e#  # T# u# n# i# n# g# 
# I# n#  # t# h# e#  # n# e# x# t#  # s# t# e# p#  # w# e#  # w# a# n# t#  # t# o#  # l# o# o# k#  # o# n#  # t# h# e#  # a# t# t# r# i# b# u# t# e# s#  # o# f#  # e# a# c# h#  # f# e# a# t# u# r# e#  # a# n# d#  # i# d# e# n# t# i# f# y#  # i# f#  # t# h# e# r# e#  # a# r# e#  # s# i# m# i# l# a# r#  # a# t# t# r# i# b# u# t# e# s#  # w# h# i# c# h#  # w# e#  # c# a# n#  # c# o# m# b# i# n# e# .

# In[None]

#Print the attributes of workclass an their occurrence.
f = data['workclass'].value_counts().reset_index()
f.columns = ['workclass', 'count']
print(f)

# D# u# e#  # t# o#  # s# i# m# i# l# a# r# i# t# y#  # w# e#  # c# a# n#  # c# o# m# b# i# n# e#  # *# S# e# l# f# -# e# m# p# -# n# o# t# -# i# n# c# *#  # a# n# d#  # *# S# e# l# f# -# e# m# p# -# i# n# c# *#  # t# o#  # o# n# e#  # a# t# t# r# i# b# u# t# e#  # a# s#  # w# e# l# l#  # a# s#  # *# L# o# c# a# l# -# g# o# v# *# ,#  # *# S# t# a# t# e# -# g# o# v# *#  # a# n# d#  # *# F# e# d# e# r# a# l# -# g# o# v# *# .#  #  # I# n# s# t# e# a# d#  # o# f#  # 5# ,#  # w# e#  # n# o# w#  # h# a# v# e#  # 2#  # n# e# w#  # a# t# t# r# i# b# u# t# e# s#  # -#  # *# S# e# l# f# -# e# m# p# *#  # a# n# d#  # *# G# o# v# *# .

# In[None]

#Combine the mentioned attributes
data.workclass = data.workclass.replace({'Self-emp-not-inc': 'Self-emp',
                                        'Self-emp-inc': 'Self-emp',
                                        'Local-gov': 'Gov',
                                        'Federal-gov': 'Gov',
                                        'State-gov': 'Gov'})

#Count all distinct attributes of fnlwgt
f = data['fnlwgt'].value_counts().reset_index()
f.columns = ['fnlwgt', 'count']
print('Number of distinct attribute in column fnlwgt :',f.shape[0])

# C# o# l# u# m# n#  # *# f# n# l# w# g# t# *#  # h# a# s#  # o# v# e# r#  # 2# 0# 0# 0# 0#  # d# i# s# t# i# n# c# t#  # a# t# t# r# i# b# u# t# e# s# .#  # T# h# e# r# e#  # a# r# e#  # t# o# o#  # m# a# n# y#  # f# o# r#  # s# i# m# p# l# i# f# i# c# a# t# i# o# n# .

# In[None]

#Print the attributes of education and their occurrence.
f = data['education'].value_counts().reset_index()
f.columns = ['education', 'count']
print('\n',f)

# A# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e#  # c# a# l# c# u# l# a# t# i# o# n#  # o# f#  # *# e# d# u# c# a# t# i# o# n# *# ,#  # w# e#  # c# a# n#  # c# o# m# b# i# n# e#  # s# o# m# e#  # f# e# a# t# u# r# e# s# .#  # *# P# r# e# s# c# h# o# o# l# *# ,#  # *# 1# s# t# -# 4# t# h# *# ,#  # *# 5# t# h# -# 6# t# h# *# ,#  # *# 7# t# h# -# 8# t# h# *# ,#  # *# 9# t# h# *# ,#  # *# 1# 0# t# h# *# ,#  # *# 1# 1# t# h# *#  # a# n# d#  # *# 1# 2# t# h# *#  # w# e#  # s# u# m# m# a# r# i# z# e#  # a# s#  # *# N# o# -# s# c# h# o# o# l# *# .#  # *# S# o# m# e# -# c# o# l# l# e# g# e# *# ,#  # *# A# s# s# o# c# -# v# o# c# *#  # a# n# d#  # *# A# s# s# o# c# -# a# c# d# m# *#  # c# a# n#  # b# e#  # c# o# m# b# i# n# e# d#  # a# s#  # *# C# o# l# l# e# g# e# *# .#  

# In[None]

#Combine the mentioned attributes
data.education = data.education.replace({'Preschool': 'No-school',
                                        '1st-4th': 'No-school',
                                        '5th-6th': 'No-school',
                                        '7th-8th': 'No-school',
                                        '9th': 'No-school',
                                        '10th': 'No-school',
                                        '11th': 'No-school',
                                        '12th': 'No-school',
                                        'Some-college': 'College',
                                        'Assoc-voc': 'College',
                                        'Assoc-acdm': 'College'})

#Print the attributes of education an their occurrence
f = data['marital.status'].value_counts().reset_index()
f.columns = ['marital.status', 'count']
print('\n',f)

# F# o# r#  # r# e# a# s# o# n# s#  # o# f#  # s# i# m# p# l# i# c# i# t# y# ,#  # w# e#  # s# i# m# p# l# i# f# y#  # t# h# e#  # a# t# t# r# i# b# u# t# e# s# .#  # *# M# a# r# r# i# e# d# -# c# i# v# -# s# p# o# u# s# e# *#  # a# n# d#  # *# M# a# r# r# i# e# d# -# A# F# -# s# p# o# u# s# e# *#  # a# r# e#  # c# o# m# b# i# n# e# d#  # a# s#  # *# M# a# r# r# i# e# d# *# .#  # *# N# e# v# e# r# -# m# a# r# r# i# e# d# *#  # a# n# d#  # *# M# a# r# r# i# e# d# -# s# p# o# u# s# e# -# a# b# s# e# n# t# *#  # a# r# e#  # c# o# m# b# i# n# e# d#  # a# s#  # *# N# o# t# -# m# a# r# r# i# e# d# *# .#  # *# D# i# v# o# r# c# e# d# *#  # i# s#  # a# d# d# e# d#  # t# o#  # *# S# e# p# a# r# a# t# e# d# *# .#  # *# W# i# d# o# w# e# d# *#  # r# e# m# a# i# n# s#  # u# n# t# o# u# c# h# e# d# .

# In[None]

#Combine the mentioned attributes
data['marital.status'].replace(['Married-civ-spouse'], 'Married', inplace=True)
data['marital.status'].replace('Never-married', 'Not-married', inplace=True)
data['marital.status'].replace(['Divorced'], 'Separated', inplace=True)
data['marital.status'].replace(['Separated'], 'Separated', inplace=True)
data['marital.status'].replace(['Married-spouse-absent'], 'Not-married', inplace=True)
data['marital.status'].replace(['Married-AF-spouse'], 'Married', inplace=True)

#Show the result
f = data['marital.status'].value_counts().reset_index()
f.columns = ['marital.status', 'count']
print('\n',f)

# N# e# x# t#  # w# e#  # l# o# o# k#  # a# t#  # *# o# c# c# u# p# a# t# i# o# n# *# ,#  # *# r# e# l# a# t# i# o# n# s# h# i# p# *# ,#  # *# r# a# c# e# *#  # a# n# d#  # *# s# e# x# *# .#  

# In[None]

#Print the attributes of occupation an their occurrence
f = data['occupation'].value_counts().reset_index()
f.columns = ['occupation', 'count']
print('\n',f)

#Print the attributes of relationship an their occurrence
f = data['relationship'].value_counts().reset_index()
f.columns = ['relationship', 'count']
print('\n',f)

#Print the attributes of race an their occurrence
f = data['race'].value_counts().reset_index()
f.columns = ['race', 'count']
print('\n',f)

#Print the attributes of sex an their occurrence
f = data['sex'].value_counts().reset_index()
f.columns = ['sex', 'count']
print('\n',f)

# *# o# c# c# u# p# a# t# i# o# n# *#  # i# s#  # o# n# e#  # o# f#  # t# h# e#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # s# o#  # w# e#  # l# e# a# v# e#  # i# t#  # u# n# c# h# a# n# g# e# d# .# 
# *# r# e# l# a# t# i# o# n# s# h# i# p# *# ,#  # *# r# a# c# e# *#  # a# n# d#  # *# s# e# x# *# ,#  # a# l# l#  # h# a# v# e#  # a#  # m# o# d# e# r# a# t# e#  # n# u# m# b# e# r#  # o# f#  # d# i# f# f# e# r# e# n# t#  # a# t# t# r# i# b# u# t# e# s# ,#  # w# h# i# c# h#  # d# i# f# f# e# r#  # i# n#  # t# h# e# i# r#  # i# n# f# o# r# m# a# t# i# o# n#  # c# o# n# t# e# n# t# .#  # T# h# i# s#  # m# e# a# n# s#  # t# h# a# t#  # w# e#  # d# o# n# '# t#  # h# a# v# e#  # t# o#  # c# h# a# n# g# e#  # t# h# e# s# e#  # c# o# l# u# m# n# s# .# 
# 
# F# i# n# a# l# l# y# ,#  # w# e#  # c# o# n# s# i# d# e# r#  # t# h# e#  # n# a# t# i# v# e#  # c# o# u# n# t# r# i# e# s#  # o# f#  # t# h# e#  # p# e# o# p# l# e# .

# In[None]

#Print the attributes of native.country an their occurrence
f = data['native.country'].value_counts().reset_index()
f.columns = ['native.country', 'count']
print('\n',f)

# T# h# e#  # *# U# n# i# t# e# d# -# S# t# a# t# e# s# *#  # i# s#  # s# i# g# n# i# f# i# c# a# n# t# l# y#  # a# h# e# a# d#  # o# f#  # *# M# e# x# i# c# o# *#  # a# s#  # n# a# t# i# v# e#  # c# o# u# n# t# r# y# ,#  # t# h# e#  # s# e# c# o# n# d#  # i# n#  # t# h# e#  # l# i# s# t# ,#  # a# s#  # w# e#  # a# l# r# e# a# d# y#  # s# a# w#  # a# b# o# v# e# .#  # T# h# e#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # t# h# e#  # o# t# h# e# r#  # c# o# u# n# t# r# i# e# s#  # i# s#  # n# o# t#  # s# o#  # c# l# e# a# r# .#  # B# e# c# a# u# s# e#  # t# h# e# r# e#  # a# r# e#  # m# o# r# e#  # t# h# a# n#  # 4# 0#  # c# o# u# n# t# r# i# e# s#  # i# n#  # t# h# e#  # l# i# s# t# ,#  # a#  # g# r# o# u# p# i# n# g#  # b# y#  # c# o# n# t# i# n# e# n# t#  # m# a# k# e# s#  # s# e# n# s# e# .#  

# In[None]

data['native.country'].replace(['United-States'], 'N-America', inplace=True)
data['native.country'].replace(['Mexico'], 'N-America', inplace=True)
data['native.country'].replace(['Philippines'], 'Asia', inplace=True)
data['native.country'].replace(['Germany'], 'Europe', inplace=True)
data['native.country'].replace(['Puerto-Rico'], 'N-America', inplace=True)
data['native.country'].replace(['Canada'], 'N-America', inplace=True)
data['native.country'].replace(['India'], 'Asia', inplace=True)
data['native.country'].replace(['El-Salvador'], 'MS-America', inplace=True)
data['native.country'].replace(['Cuba'], 'MS-America', inplace=True)
data['native.country'].replace(['England'], 'Europe', inplace=True)
data['native.country'].replace(['Jamaica'], 'MS-America', inplace=True)
data['native.country'].replace(['Italy'], 'Europe', inplace=True)

data['native.country'].replace(['China'], 'Asia', inplace=True)
data['native.country'].replace(['Dominican-Republic'], 'MS-America', inplace=True)
data['native.country'].replace(['Vietnam'], 'Asia', inplace=True)
data['native.country'].replace(['Guatemala'], 'MS-America', inplace=True)
data['native.country'].replace(['Japan'], 'Asia', inplace=True)
data['native.country'].replace(['Columbia'], 'MS-America', inplace=True)
data['native.country'].replace(['Poland'], 'Europe', inplace=True)
data['native.country'].replace(['Taiwan'], 'Asia', inplace=True)
data['native.country'].replace(['Haiti'], 'MS-America', inplace=True)
data['native.country'].replace(['Iran'], 'Asia', inplace=True)
data['native.country'].replace(['Portugal'], 'Europe', inplace=True)
data['native.country'].replace(['Nicaragua'], 'MS-America', inplace=True)

data['native.country'].replace(['Peru'], 'MS-America', inplace=True)
data['native.country'].replace(['Greece'], 'Europe', inplace=True)
data['native.country'].replace(['Ecuador'], 'MS-America', inplace=True)
data['native.country'].replace(['France'], 'Europe', inplace=True)
data['native.country'].replace(['Ireland'], 'Europe', inplace=True)
data['native.country'].replace(['Hong'], 'Asia', inplace=True)
data['native.country'].replace(['Trinadad&Tobago'], 'MS-America', inplace=True)
data['native.country'].replace(['Cambodia'], 'Asia', inplace=True)
data['native.country'].replace(['Laos'], 'Asia', inplace=True)
data['native.country'].replace(['Thailand'], 'Asia', inplace=True)
data['native.country'].replace(['Yugoslavia'], 'Europe', inplace=True)
data['native.country'].replace(['Outlying-US(Guam-USVI-etc)'], 'N-America', inplace=True)

data['native.country'].replace(['Hungary'], 'Europe', inplace=True)
data['native.country'].replace(['Honduras'], 'MS-America', inplace=True)
data['native.country'].replace(['Scotland'], 'Europe', inplace=True)
data['native.country'].replace(['Holand-Netherlands'], 'Europe', inplace=True)

#Show the result
f = data['native.country'].value_counts().reset_index()
f.columns = ['native.country', 'count']
print('\n',f)

# N# o# w#  # w# e#  # c# a# n#  # l# o# o# k#  # a# t#  # o# u# r#  # d# a# t# a# s# e# t#  # a# g# a# i# n# .

# In[None]

print('dataset size')
print('# of rows:', data.shape[0])
print('# of columns:', data.shape[1])
data.head()

# T# h# e#  # d# a# t# a#  # i# s#  # s# i# m# p# l# f# i# e# d#  # b# u# t#  # t# h# e# r# e#  # a# r# e#  # s# t# i# l# l#  # h# a# v# e#  # 1# 5#  # c# o# l# u# m# n# s#  # i# n# c# l# u# d# i# n# g#  # t# h# e#  # *# i# n# c# o# m# e# *#  # c# o# l# u# m# n#  # l# e# f# t# .#  # W# h# e# n#  # l# o# o# k# i# n# g#  # a# t#  # *# e# d# u# c# a# t# i# o# n# *#  # a# n# d#  # *# e# d# u# c# a# t# i# o# n# .# n# u# m# *#  # ,#  # y# o# u#  # c# a# n#  # q# u# i# c# k# l# y#  # s# e# e#  # t# h# a# t#  # t# h# e# y#  # c# o# n# t# a# i# n#  # t# h# e#  # s# a# m# e#  # i# n# f# o# r# m# a# t# i# o# n# .#  # P# e# o# p# l# e#  # w# i# t# h#  # a#  # h# i# g# h#  # l# e# v# e# l#  # o# f#  # e# d# u# c# a# t# i# o# n#  # h# a# v# e#  # u# s# u# a# l# l# y#  # i# n# v# e# s# t# e# d#  # m# o# r# e#  # y# e# a# r# s#  # i# n#  # t# h# e# i# r#  # e# d# u# c# a# t# i# o# n#  # t# h# a# n#  # t# h# o# s# e#  # w# i# t# h#  # a#  # l# o# w# e# r#  # l# e# v# e# l#  # o# f#  # e# d# u# c# a# t# i# o# n# .#  # T# h# e# r# e# f# o# r# e# ,#  # i# n#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # w# e#  # w# i# l# l#  # o# n# l# y#  # l# o# o# k#  # a# t#  # o# n# e#  # c# o# l# u# m# n#  # i# n#  # o# u# r#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l#  # -#  # *# e# d# u# c# a# t# i# o# n# *# .# 
# F# o# r#  # f# u# r# t# h# e# r#  # s# i# m# p# l# i# f# i# c# a# t# i# o# n# ,#  # w# e#  # w# i# l# l#  # a# l# s# o#  # r# e# m# o# v# e#  # t# h# e#  # c# o# l# u# m# n# s#  # *# r# e# l# a# t# i# o# n# s# h# i# p# *#  # a# n# d#  # *# f# n# l# w# g# t# *# .#  #  # 
# T# h# e#  # s# t# a# t# e# m# e# n# t#  # o# f#  # *# f# n# l# w# g# t# *# ,#  # f# i# n# a# l#  # w# e# i# g# h# t# ,#  # i# s#  # v# e# r# y#  # c# o# m# p# l# e# x# .#  # T# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# i# s# ,#  # o# n# e#  # h# a# s#  # t# o#  # k# n# o# w#  # t# h# a# t#  # t# h# e#  # d# a# t# a#  # s# e# t#  # o# f#  # t# h# e#  # U# .# S# .#  # C# e# n# s# u# s#  # B# u# r# e# a# u# s#  # c# o# n# s# i# s# t# s#  # o# f#  # 5# 1#  # i# n# d# i# v# i# d# u# a# l#  # s# t# a# t# e#  # s# a# m# p# l# e# s# ,#  # w# h# i# c# h#  # w# e# r# e#  # c# o# l# l# e# c# t# e# d#  # w# i# t# h#  # d# i# f# f# e# r# e# n# t#  # m# e# t# h# o# d# s# .#  # P# e# r# s# o# n# s#  # w# i# t# h#  # t# h# e#  # s# a# m# e#  # d# e# m# o# g# r# a# p# h# i# c#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # s# h# o# u# l# d#  # h# a# v# e#  # a#  # s# i# m# i# l# a# r#  # w# e# i# g# h# t# .#  # H# o# w# e# v# e# r# ,#  # t# h# i# s#  # w# e# i# g# h# t#  # s# h# o# u# l# d#  # o# n# l# y#  # h# a# v# e#  # s# i# g# n# i# f# i# c# a# n# c# e#  # w# i# t# h# i# n#  # a#  # s# t# a# t# e# ,#  # s# o#  # t# h# a# t#  # w# e#  # c# a# n# n# o# t#  # t# a# k# e#  # i# t#  # f# u# r# t# h# e# r#  # i# n# t# o#  # a# c# c# o# u# n# t#  # f# o# r#  # t# h# e#  # o# v# e# r# a# l# l#  # a# n# a# l# y# s# i# s#  # (# [# m# o# r# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # f# n# l# w# g# t# ]# (# h# t# t# p# :# /# /# a# r# c# h# i# v# e# .# i# c# s# .# u# c# i# .# e# d# u# /# m# l# /# m# a# c# h# i# n# e# -# l# e# a# r# n# i# n# g# -# d# a# t# a# b# a# s# e# s# /# a# d# u# l# t# /# a# d# u# l# t# .# n# a# m# e# s# )# )# .#  # *# r# e# l# a# t# i# o# n# s# h# i# p# *#  # c# o# n# t# a# i# n# s#  # i# n# f# o# r# m# a# t# i# o# n#  # t# h# a# t#  # c# a# n#  # b# e#  # p# a# r# t# l# y#  # d# e# r# i# v# e# d#  # f# r# o# m#  # t# h# e#  # d# a# t# a#  # i# n#  # *# g# e# n# d# e# r# *#  # a# n# d#  # *# m# a# r# i# t# a# l# .# s# t# a# t# u# s# *# .#  # R# e# d# u# n# d# a# n# t#  # i# n# f# o# r# m# a# t# i# o# n#  # i# s#  # n# o# t#  # n# e# e# d# e# d#  # i# n#  # o# u# r#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l# .#  #  # I# t#  # c# a# n#  # b# i# a# s#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n# .#  # C# o# n# s# e# q# u# e# n# t# i# a# l# ,#  # *# r# e# l# a# t# i# o# n# s# h# i# p# *#  # i# s#  # a# l# s# o#  # d# r# o# p# p# e# d# .

# In[None]

#Drop the columns not needed
data.drop(columns=['education.num', 'fnlwgt', 'relationship'], axis=1, inplace=True)
data.head()

# ## ##  # 4# .# 2#  # P# r# o# c# e# s# s#  # t# h# e#  # D# a# t# a# 
# 
# N# o# w#  # t# h# a# t#  # a# l# l#  # f# e# a# t# u# r# e# s#  # a# r# e#  # s# e# l# e# c# t# e# d# ,#  # w# e#  # w# a# n# t#  # t# o#  # p# r# e# p# a# r# e#  # t# h# e#  # d# a# t# a# .#  # T# h# e#  # p# r# e# d# i# c# t# i# o# n#  # v# a# r# i# a# b# l# e# ,#  # *# i# n# c# o# m# e# *# ,#  # i# s#  # e# n# c# o# d# e# d#  # b# i# n# a# r# y# ,#  # i# n#  # 0#  # a# n# d#  # 1# .#  # N# u# m# e# r# i# c#  # f# e# a# t# u# r# e# s#  # a# r# e#  # s# c# a# l# e# d#  # w# i# t# h#  # a#  # M# i# n# M# a# x#  # m# e# t# h# o# d#  # i# n# t# o#  # a#  # n# u# m# b# e# r#  # r# a# n# g# e#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .#  # T# h# e#  # r# e# m# a# i# n# i# n# g#  # f# e# a# t# u# r# e# s#  # a# r# e#  # f# i# r# s# t#  # l# a# b# e# l#  # e# n# c# o# d# e# d#  # a# n# d#  # a# f# t# e# r# w# a# r# d# s#  # o# n# e#  # h# o# t#  # e# n# c# o# d# e# d# .#  # T# h# u# s# ,#  # t# h# e#  # f# i# n# a# l#  # d# a# t# a#  # m# o# d# e# l#  # c# o# n# s# i# s# t# s#  # o# f#  # 4# 7#  # a# t# t# r# i# b# u# t# e# s#  # w# i# t# h#  # a#  # v# a# l# u# e#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .

# In[None]

#Import OneHotEncoder, LabelEncoder & MinMaxScaler
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, MinMaxScaler

#Define how to process which feature
columns_to_label_encode   = ['income']
columns_to_scale          = ['age', 'capital.gain', 'capital.loss', 'hours.per.week']

#Instantiate encoder/scaler
ohe    = OneHotEncoder(sparse=False)
le     = LabelEncoder()
mms    = MinMaxScaler()

#To one hot encode the string values, they need to be in a numeric format,
#To do so, we first label encode those features  
w = np.reshape(le.fit_transform(data['workclass']), (30162, 1))
e = np.reshape(le.fit_transform(data['education']), (30162, 1))
m = np.reshape(le.fit_transform(data['marital.status']), (30162, 1))
o = np.reshape(le.fit_transform(data['occupation']), (30162, 1))
r = np.reshape(le.fit_transform(data['race']), (30162, 1))
s = np.reshape(le.fit_transform(data['sex']), (30162, 1))
n = np.reshape(le.fit_transform(data['native.country']), (30162, 1))

#Concatenate the label encoded features
wemorsn = np.concatenate([w, e, m, o, r, s, n], axis=1)

#Scale and encode separate columns
one_hot_encoded_columns = ohe.fit_transform(wemorsn)
label_encoded_columns   = np.reshape(le.fit_transform(data[columns_to_label_encode]), (30162, 1))
min_max_scaled_columns  = mms.fit_transform(data[columns_to_scale])

#Concatenate again
processed_data = np.concatenate([min_max_scaled_columns, one_hot_encoded_columns, label_encoded_columns], axis=1)

#Turn processed data into DataFrame typ
pd_df = pd.DataFrame(processed_data, index=data.index)

pd_df.head(10)

# ##  # 5# .#  # M# o# d# e# l#  # t# h# e#  # D# a# t# a# 
# I# n#  # t# h# i# s#  # s# t# e# p#  # w# e#  # w# a# n# t#  # t# o#  # t# r# a# i# n#  # d# i# f# f# e# r# e# n# t#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l# s#  # a# n# d#  # c# o# m# p# a# r# e#  # t# h# e# m#  # w# i# t# h#  # e# a# c# h#  # o# t# h# e# r# .#  # W# e#  # d# o#  # t# h# i# s#  # i# n#  # o# r# d# e# r#  # t# o#  # s# e# l# e# c# t#  # m# o# d# e# l# s# ,#  # w# h# i# c# h#  # w# e#  # w# i# l# l#  # e# x# a# m# i# n# e#  # i# n#  # m# o# r# e#  # d# e# t# a# i# l#  # i# n#  # a#  # f# u# r# t# h# e# r#  # s# t# e# p# .# 
# 
# B# u# t#  # b# e# f# o# r# e#  # w# e#  # t# r# a# i# n#  # t# h# e#  # m# o# d# e# l# s# ,#  # w# e#  # h# a# v# e#  # t# o#  # s# e# p# e# r# a# t# e#  # o# u# r#  # p# r# e# d# i# c# t# i# o# n#  # v# a# r# i# a# b# l# e#  # o# f#  # t# h# e#  # f# e# a# t# u# r# e# s

# In[None]

from sklearn.model_selection import train_test_split

#Split prediction variable and features
X = pd_df.values[:, :-1]
y = pd_df.values[:, -1]

#Split test and training data
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1808613.npy", { "accuracy_score": score })

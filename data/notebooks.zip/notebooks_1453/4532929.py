import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import cm
import itertools
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

# Read the Data
star = pd.read_csv('../input/pulsar_stars.csv')

# ## ##  # D# a# t# a#  # A# n# a# l# y# s# i# s

# In[None]

# Head of the Data
star.head()

# In[None]

# Info
star.info()

# In[None]

# Describe
star.describe()

# ##  # T# a# k# e# a# w# a# y#  # :#  # N# o#  # N# a# N#  # e# n# t# r# i# e# s

# In[None]

# Columns
star.columns

# ##  # E# D# A

# In[None]

#-----Lets do some EDA--------
#Check the correlation between the various features
plt.figure(figsize=(10,6), dpi =100)
sns.heatmap(star.corr(), cmap="YlGnBu", annot=True)

# ##  # T# a# k# e# a# w# a# y#  # :#  # T# a# r# g# e# t#  # c# l# a# s# s#  # i# s#  # m# o# s# t#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e# ,#  # S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e

# In[None]

plt.figure(figsize=(10,7), dpi =100)
sns.scatterplot(x=' Mean of the integrated profile', y= ' Skewness of the integrated profile',hue='target_class', data = star, palette='coolwarm',
markers=['o','v'])

# In[None]

plt.figure(figsize=(10,10), dpi =100)
sns.pairplot(data=star)

# In[None]

plt.figure(figsize=(100,6), dpi =100)
for col in star.columns.drop('target_class'):
    plt.figure(figsize=(10,6), dpi =100)
    #star[col].plot.kde()
    sns.distplot(star[col], bins=1000)

# ##  # M# o# d# e# l# i# n# g

# In[None]

#-------------Machine learning-----------------
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix,mean_absolute_error,mean_squared_error 
#-- Models
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV

# In[None]

#Scaling the dataframe
scaler = MinMaxScaler()
scaler.fit(star.drop(['target_class'], axis = 1))
star_scaler =scaler.transform(star.drop(['target_class'], axis = 1))

# In[None]

#Train-test-split
X = star_scaler
y = star['target_class']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4532929.npy", { "accuracy_score": score })

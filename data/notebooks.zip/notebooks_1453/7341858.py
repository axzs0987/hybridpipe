import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

df_income = pd.read_csv('/kaggle/input/adult-income-dataset/adult.csv')

# In[None]

df_income.head()

# In[None]

df_income.shape

# In[None]

df_income.info()

# R# e# p# l# a# c# i# n# g#  # a# l# l#  # "# ?# "#  # w# i# t# h#  # N# a# N

# In[None]

df_income.replace('?',np.nan,inplace=True)
df_income.info()

# In[None]

#Dropping all NULL values
df_income.dropna(inplace=True)
df_income.info()

# In[None]

df_income.describe()

# I# m# p# u# t# i# n# g#  # v# a# l# u# e# s#  # o# f#  # A# g# e# s# .#  # C# r# e# a# t# i# n# g#  # b# r# a# c# k# e# t# s#  # o# f#  # a# g# e#  # a# n# d#  # r# e# p# l# a# c# i# n# g#  # t# h# e# m

# In[None]

def impute_age(age):
    if((age>15) & (age<=30)):
        return 1
    elif((age>30) & (age<=45)):
        return 2
    elif((age>45) & (age<=60)):
        return 3
    elif((age>60) & (age<=75)):
        return 4
    else:
        return 5

df_income.age = df_income.age.apply(impute_age)

df_income.age.value_counts()

# In[None]

sns.countplot(data=df_income,x='income',hue='age')

# In[None]

plt.figure(figsize=(12,20))
sns.countplot(data=df_income,y='native-country',hue='income')

# In[None]

plt.figure(figsize=(12,6))
sns.countplot(data=df_income,x='workclass',hue='income')

# In[None]

plt.figure(figsize=(20,10))
sns.countplot(data=df_income,x='education',hue='income')

# In[None]

plt.figure(figsize=(15,8))
sns.countplot(data=df_income,x='marital-status',hue='income')

# In[None]

plt.figure(figsize=(25,10))
sns.countplot(data=df_income,x='occupation',hue='income')

# In[None]

plt.figure(figsize=(10,6))
sns.countplot(data=df_income,x='race',hue='income')

# In[None]

sns.countplot(data=df_income,x='gender',hue='income')

# In[None]

#Encoding the Categorical values to Numericals using LabelEncoder
from sklearn.preprocessing import LabelEncoder

Labelenc_workclass = LabelEncoder()
df_income['workclass'] = Labelenc_workclass.fit_transform(df_income['workclass'])

Labelenc_education = LabelEncoder()
df_income['education'] = Labelenc_education.fit_transform(df_income['education'])

Labelenc_marital_status = LabelEncoder()
df_income['marital-status'] = Labelenc_marital_status.fit_transform(df_income['marital-status'])

Labelenc_occupation = LabelEncoder()
df_income['occupation'] = Labelenc_occupation.fit_transform(df_income['occupation'])

Labelenc_relationship = LabelEncoder()
df_income['relationship'] = Labelenc_relationship.fit_transform(df_income['relationship'])

Labelenc_race = LabelEncoder()
df_income['race'] = Labelenc_race.fit_transform(df_income['race'])

Labelenc_gender = LabelEncoder()
df_income['gender'] = Labelenc_gender.fit_transform(df_income['gender'])

Labelenc_native_country = LabelEncoder()
df_income['native-country'] = Labelenc_native_country.fit_transform(df_income['native-country'])

Labelenc_income = LabelEncoder()
df_income['income'] = Labelenc_income.fit_transform(df_income['income'])

df_income.info()

# In[None]

#Creating a HeatMap

plt.figure(figsize=(10,8))
sns.heatmap(df_income.corr())

# In[None]

#Scaling the values using StandardScaler

from sklearn.preprocessing import StandardScaler
st_scaler = StandardScaler()

st_scaler.fit(df_income.drop('income',axis=1))

scaled_features = st_scaler.transform(df_income.drop('income',axis=1))

# In[None]

#Creating X & y for train test split & Splitting them for the model
X = pd.DataFrame(scaled_features,columns=df_income.columns[:-1])
y = df_income['income']

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7341858.npy", { "accuracy_score": score })

import pandas as pd
# <# h# 1# ># <# c# e# n# t# e# r# ># C# e# n# t# r# o#  # U# n# i# v# e# r# s# i# t# á# r# i# o#  # I# E# S# B# <# /# c# e# n# t# e# r# ># <# /# h# 1# ># 
# C# u# r# s# o# :#  # C# i# ê# n# c# i# a# s#  # d# e#  # D# a# d# o# s#  # -#  # P# õ# s# -# G# r# a# d# u# a# ç# ã# o# <# b# r# ># 
# A# l# u# n# o# :#  # R# O# B# S# O# N#  # B# A# T# I# S# T# A#  # D# A#  # S# I# L# V# A# <# b# r# ># 
# D# i# s# c# i# p# l# i# n# a# :#  # D# a# t# a#  # M# i# n# i# n# g#  # e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # I# I# 
# 
#  #  #  

# ##  # I# m# p# o# r# t# a# n# d# o#  # a# s#  # b# i# b# l# i# o# t# e# c# a# s

# In[None]


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns


import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ##  # <# c# e# n# t# e# r# ># D# i# c# i# o# n# á# r# i# o#  # d# e#  # D# a# d# o# s# <# /# c# e# n# t# e# r# ># 
# 
# 
# *# *# B# A# D# :# *# *#  # 1#  # =#  # c# l# i# e# n# t# e#  # i# n# a# d# i# m# p# l# e# n# t# e#  # n# o#  # e# m# p# r# é# s# t# i# m# o#  # 0#  # =#  # e# m# p# r# é# s# t# i# m# o#  # r# e# e# m# b# o# l# s# a# d# o#  # (# v# a# r# i# á# v# e# l#  # t# a# r# g# e# t# )# 
# 
# *# *# L# O# A# N# *# *# :#  # V# a# l# o# r#  # d# o#  # e# m# p# r# é# s# t# i# m# o# 
# 
# *# *# M# O# R# T# D# U# E# *# *# :#  # V# a# l# o# r#  # d# e# v# i# d# o#  # d# a#  # h# i# p# o# t# e# c# a#  # e# x# i# s# t# e# n# t# e# 
# 
# *# *# V# A# L# U# E# *# *# :#  # v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # a# t# u# a# l# 
# 
# *# *# R# E# A# S# O# N# *# *# :#  # D# e# b# t# C# o# n#  # =#  # c# o# n# s# o# l# i# d# a# ç# ã# o#  # d# a#  # d# í# v# i# d# a# ;#  # H# o# m# e# I# m# p#  # =#  # m# e# l# h# o# r# a# m# e# n# t# o#  # d# a#  # c# a# s# a# 
# 
# *# *# J# O# B# *# *# :#  # S# e# i# s#  # c# a# t# e# g# o# r# i# a# s#  # p# r# o# f# i# s# s# i# o# n# a# i# s# 
# 
# *# *# Y# O# J# *# *# :#  # A# n# o# s#  # n# o#  # e# m# p# r# e# g# o#  # a# t# u# a# l# 
# 
# *# *# D# E# R# O# G# *# *# :#  # N# ú# m# e# r# o#  # d# e#  # p# r# i# n# c# i# p# a# i# s#  # r# e# l# a# t# ó# r# i# o# s#  # d# e# p# r# e# c# i# a# t# i# v# o# s# 
# 
# *# *# D# E# L# I# N# Q# *# *# :#  # n# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # i# n# a# d# i# m# p# l# e# n# t# e# s# 
# 
# *# *# C# L# A# G# E# *# *# :#  # I# d# a# d# e#  # d# a#  # l# i# n# h# a#  # c# o# m# e# r# c# i# a# l#  # m# a# i# s#  # a# n# t# i# g# a#  # e# m#  # m# e# s# e# s# 
# 
# *# *# N# I# N# Q# *# *# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # r# e# c# e# n# t# e# s# 
# 
# *# *# C# L# N# O# *# *# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o# 
# 
# *# *# D# E# B# T# I# N# C# *# *# :#  # R# á# c# i# o#  # d# í# v# i# d# a#  # /#  # r# e# n# d# i# m# e# n# t# o

# *#  # ## ## ##  # C# a# r# r# e# g# a# n# d# o#  # o# s#  # d# a# d# o# s

# In[None]

df = pd.read_csv('/kaggle/input/hmeq-data/hmeq.csv')
df.head()

# *#  # ##  # V# e# r# i# f# i# c# a# n# d# o#  # o# s#  # t# i# p# o# s#  # e#  # o# s#  # v# a# l# o# r# e# s#  # n# u# l# o# s

# In[None]

df.info()

# O#  # D# a# t# a# s# e# t#  # p# o# s# s# u# i#  # 5# .# 9# 6# 0#  # l# i# n# h# a# s#  # e#  # 1# 3#  # c# o# l# u# n# a# s# ,# c# o# m#  # e# x# c# e# ç# ã# o#  # d# a# s#  # v# a# r# i# á# v# e# i# s#  # B# A# D#  # e#  # L# O# A# N#  # t# o# d# a# s#  # a# s#  # o# u# t# r# a# s#  # v# a# r# i# á# v# e# i# s#  # p# o# s# s# u# i#  # v# a# l# o# r# e# s#  # m# i# s# s# i# n# g#  # e#  # d# u# a# s#  # v# a# r# i# á# v# e# i# s#  # o# b# j# e# c# t#  # J# O# B#  # e#  # R# E# A# S# O# N

# ##  # <# c# e# n# t# e# r# ># *# *# E# x# p# l# o# r# a# ç# ã# o#  # d# o# s#  # D# a# d# o# s# *# *# <# /# c# e# n# t# e# r# >

# In[None]

#Estatísticas Descritivas
df.describe()

# E# s# t# a# t# í# s# t# i# c# a# s#  # d# e#  # t# o# d# a# s#  # v# a# r# i# á# v# e# i# s#  # q# u# a# n# t# i# t# a# t# i# v# a# s

# In[None]

# Verificando a distribuição da variável BAD(Target)
df['BAD'].plot.hist(bins=5)

# In[None]

#frenquência dos dados da variável BAD
df['BAD'].value_counts()

# C# o# m# o#  # p# o# d# e# m# o# s#  # o# b# s# e# r# v# a# r#  # n# o#  # g# r# á# f# i# c# o#  # a# c# i# m# a#  # e#  # n# a#  # f# r# e# q# u# ê# n# c# i# a# ,#  # a#  # d# i# s# t# r# i# b# u# i# ç# ã# o#  # d# a#  # v# a# r# i# á# v# e# l#  # T# a# r# g# e# t# (# B# A# D# )#  # n# ã# o#  # e# s# t# á#  # e# q# u# i# l# i# b# r# a# d# a# ,#  # p# r# o# v# a# v# e# l# m# e# n# t# e#  # a# s#  # p# e# s# s# o# a# s#  # q# u# e#  # p# a# g# a# r# a# m#  # v# ã# o#  # e# n# v# i# e# s# a# r#  # o#  # m# o# d# e# l# o# .

# ##  # <# c# e# n# t# e# r# ># T# r# a# t# a# m# e# n# t# o#  # d# o# s#  # D# a# d# o# s# <# /# c# e# n# t# e# r# >

# In[None]

#Verificando a quantidade de valores missing nas variáveis
df.isnull().sum()

# A# o#  # a# n# a# l# i# s# a# r#  # a#  # q# u# a# n# t# i# d# a# d# e#  # d# e#  # m# i# s# s# i# n# g#  # n# a#  # b# a# s# e# ,#  # t# e# m# o# s#  # d# u# a# s#  # o# p# ç# õ# e# s# :#  # i# m# p# u# t# a# ç# ã# o#  # d# e#  # d# a# d# o# s#  # o# u#  # a#  # r# e# m# o# ç# ã# o#  # d# o# s#  # v# a# l# o# r# e# s#  # c# o# m#  # m# i# s# s# i# n# g# ,#  # n# e# s# s# e#  # c# a# s# o#  # e# u#  # v# o# u#  # r# e# m# o# v# e# r#  # o# s#  # v# a# l# o# r# e# s#  # m# i# s# s# i# n# g# .

# In[None]

# Removendo os valores missing value da base
#df2 =df.copy()
df.dropna(axis=0,how='any',inplace= True)
df.info(), df.isna().any() 


# In[None]

#valores da variável target
df['BAD'].value_counts().plot(kind='bar',title='Frequência da Variável BAD')
df['BAD'].value_counts()

# A# o#  # r# e# m# o# v# e# r#  # o# s#  # m# i# s# s# i# n# g#  # d# a#  # b# a# s# e#  # a#  # v# a# r# i# á# v# e# l#  # t# a# r# g# e# t# ,#  # c# o# n# t# i# n# u# o# u#  # m# u# i# t# o#  # d# e# s# b# a# l# a# n# c# e# a# d# a#  

# ## ## ##  # A# n# á# l# i# s# e#  # D# e# s# c# r# i# t# i# v# a#  # E# x# p# l# o# r# a# t# ó# r# i# a# 
# 


# A#  # a# v# a# l# i# a# ç# ã# o#  # d# o# s#  # h# i# s# t# o# g# r# a# m# a# s#  # m# o# s# t# r# a#  # i# n# i# c# i# a# l# m# e# n# t# e#  # q# u# e#  # :# 
# -#  # A#  # v# a# r# i# á# v# e# l#  # B# A# D#  # (# T# a# r# g# e# t# )#  # p# o# s# s# u# i#  # p# o# u# c# o# s#  # v# a# l# o# r# e# s#  # 1#  # p# a# r# a#  # t# r# e# i# n# a# m# e# n# t# o#  # d# o#  # m# o# d# e# l# o# 
# -#  # A#  # m# a# i# o# r#  # p# a# r# t# e#  # d# o# s#  # v# a# l# o# r# e# s#  # t# o# t# a# i# s#  # d# e#  # f# i# n# a# n# c# i# a# m# e# n# t# o#  # (# L# O# A# N# )#  # p# o# s# s# u# e# m#  # u# m# a#  # d# i# s# t# r# i# b# u# i# ç# ã# o#  # p# r# ó# x# i# m# a#  # d# a#  # n# o# r# m# a# l# i# d# a# d# e# ,#  # e#  # o# s#  # v# a# l# o# r# e# s#  # a#  # r# e# c# e# b# e# r# (# M# O# R# T# D# U# E# )# ,#  # n# a#  # m# é# d# i# a# ,#  # s# ã# o#  # m# a# i# o# r# e# s#  # q# u# e#  # o# s#  # t# o# t# a# i# s#  # e# m# p# r# e# s# t# a# d# o# s# .#  # O# b# s# e# r# v# a# -# s# e#  # o#  # t# e# r# r# o# r#  # d# o# s#  # j# u# r# o# s#  # b# a# n# c# á# r# i# o# s# 
# -#  # O# s#  # v# a# l# o# r# e# s#  # d# a# s#  # p# r# o# p# r# i# e# d# a# d# e# s#  # p# o# s# s# u# e# m#  # d# i# s# t# r# i# b# u# i# ç# ã# o#  # p# r# ó# x# i# m# a#  # d# o# s#  # v# a# l# o# r# e# s#  # d# o# s#  # f# i# n# a# n# c# i# a# m# e# n# t# o# s# 
# -#  # O#  # D# E# R# O# G# ,#  # a# l# g# o#  # e# q# u# i# v# a# l# e# n# t# e#  # à#  # u# m#  # a# v# i# s# o#  # d# e#  # n# e# g# a# t# i# v# a# ç# ã# o#  # d# o#  # s# e# r# v# i# ç# o#  # d# e#  # p# r# o# t# e# ç# ã# o#  # a# o#  # c# o# n# s# u# m# i# d# o# r# ,#  # é#  # b# a# i# x# o# ,#  # c# o# n# t# u# d# o#  # p# o# s# s# u# i#  # u# m# a#  # c# o# r# r# e# l# a# ç# ã# o#  # p# r# ó# x# i# m# a#  # d# e#  # m# o# d# e# r# a# d# a# (# p# =# 0# ,# 2# 5# )#  # c# o# m#  # o# s#  # m# a# u# s#  # p# a# g# a# d# o# r# e# s# .# 
# -#  # O#  # D# E# L# I# N# Q# ,#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # c# o# m#  # i# n# a# d# i# m# p# l# ê# n# c# i# a# ,#  # t# a# m# b# é# m#  # p# o# s# s# u# i#  # c# o# r# r# e# l# a# ç# ã# o#  # p# r# ó# x# i# m# a#  # à#  # m# o# d# e# r# a# d# a# (# p# =# 0# ,# 2# 7# )#  # c# o# m#  # m# a# u# s#  # p# a# g# a# d# o# r# e# s# 
# -#  # O#  # n# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # p# o# s# s# u# i#  # c# o# r# r# e# l# a# ç# ã# o# ,#  # m# a# s#  # a#  # i# n# t# e# n# s# i# d# a# d# e#  # é#  # m# e# n# o# r# (# p# =# 0# ,# 1# 3# )# ,#  # c# o# m#  # m# a# u# s#  # p# a# g# a# d# o# r# e# s# 
# -#  # P# o# r#  # f# i# m# ,#  # a#  # b# a# s# e#  # p# o# s# s# u# i#  # u# m#  # i# n# d# i# c# a# d# o# r#  # (# D# é# b# i# t# o# s# /# R# e# n# d# a# )#  # q# u# e#  # p# o# s# s# u# i#  # u# m# a#  # c# o# r# r# e# l# a# ç# ã# o#  # p# r# ó# x# i# m# a#  # a#  # m# o# d# e# r# a# d# a#  # (# p# =# 0# ,# 2# 3# )# ,#  # s# e# n# d# o#  # u# m#  # b# o# m#  # i# n# d# i# c# a# d# o# r# .

# In[None]

# Correlação das variáveis numéricas
plt.figure(figsize= (15, 8))
sns.heatmap(df.corr(), square=True, annot=True, linewidth=0.5)

# A# o#  # v# e# r# i# f# i# c# a# r#  # a#  # a# n# á# l# i# s# e#  # d# e#  # c# o# r# r# e# l# a# ç# ã# o# ,#  # o# b# s# e# r# v# a# -# s# e#  # q# u# e#  # a# s#  # v# a# r# i# á# v# e# i# s#  # V# A# L# U# E#  # X#  # M# O# R# T# D# U# E#  # t# e# m#  # a#  # m# a# i# o# r#  # c# o# r# r# e# l# a# ç# ã# o# .

# In[None]

#Distribuição da variável REASON por BAD
df.groupby(['BAD'])['REASON'].value_counts()

# A#  # v# a# r# i# á# v# e# l#  # r# a# z# ã# o#  # d# o#  # d# é# b# i# t# o#  # a# p# r# e# s# e# n# t# o# u#  # n# a#  # c# a# t# e# g# o# r# i# a#  # D# e# b# t# c# o# n#  # a#  # m# a# i# o# r#  # q# u# a# t# i# d# a# d# e#  # d# e#  # n# ã# o#  # p# a# g# a# r# ,#  # m# a# s#  # p# o# r#  # u# m#  # o# u# t# r# o#  # l# a# d# o#  # e# s# s# a#  # c# a# t# e# g# o# r# i# a#  # é#  # a# q# u# e#  # m# a# i# s#  # q# u# i# n# t# a#  # s# e# u#  # d# e# b# i# d# o# s# .

# In[None]

#Distribuição da variável JOB por BAD
df.groupby(['BAD'])['JOB'].value_counts()

# O# b# s# e# r# v# a# -# s# e#  # q# u# e#  # o#  # g# r# u# p# o#  # q# u# e#  # t# r# a# b# a# l# h# o#  # O# t# h# e# r#  # e#  # P# r# o# f# E# x# e#  # p# o# s# s# u# e# m#  # u# m#  # n# ú# m# e# r# o#  # m# a# i# o# r#  # d# e#  # m# a# u# s#  # p# a# g# a# d# o# r# e# s

# ## ## ##  # F# e# a# t# u# r# i# n# g#  # E# n# g# i# n# e# e# r# i# n# g

# P# a# r# a#  # m# e# l# h# o# r#  # a# j# u# s# t# e#  # a# o#  # m# o# d# e# l# o# ,#  # f# o# r# a# m#  # d# u# m# m# i# z# a# d# a# s#  # a# s#  # t# a# b# e# l# a# s#  # c# o# m#  # t# y# p# e#  # O# b# j# e# c# t

# In[None]

# Gerando Dummies para modelos que utilizam apenas variaveis numéricas

df = pd.get_dummies(df, columns=['REASON', 'JOB'])
df.head().T

# In[None]

#Normalizando os dados

#from sklearn.preprocessing import StandardScaler
#sc = StandardScaler()
#df = pd.DataFrame(sc.fit_transform(df), columns=df.columns)

# ## ##  # G# e# r# a# ç# ã# o#  # A# m# o# s# t# r# a# s#  # d# e#  # T# r# e# i# n# o#  # e#  # T# e# s# t# e

# N# o# t# a# :#  # N# e# s# t# e#  # t# r# a# b# a# l# h# o#  # f# o# i#  # r# e# a# l# i# z# a# d# a#  # a#  # m# o# d# e# l# a# g# e# m#  # u# t# i# l# z# a# n# d# o#  # u# m# a#  # a# m# o# s# t# r# a#  # p# a# r# a#  # v# a# l# i# d# a# ç# ã# o#  # i# n# c# l# u# s# i# v# e# ,#  # c# o# n# t# u# d# o# ,#  # d# e# v# i# d# a#  # a#  # b# a# i# x# a#  # q# u# a# n# t# i# d# a# d# e#  # d# e#  # r# e# g# i# s# t# r# o# s# ,#  # f# o# i#  # u# t# i# l# i# z# a# d# o#  # a# p# e# n# a# s#  # t# r# e# i# n# o#  # e#  # t# e# s# t# e#  

# In[None]

# importando a biblioteca
from sklearn.model_selection import train_test_split

#Separando em treino e teste
y_varible = df["BAD"]
x_varible = df.drop(["BAD"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/8908712.npy", { "accuracy_score": score })

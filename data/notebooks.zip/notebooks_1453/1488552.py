import pandas as pd
# <# h# 3# ># B# u#  # ç# a# l# ı# ş# m# a# d# a#  # w# i# s# c# o# n# s# i# n#  # b# r# e# a# s# t#  # c# a# n# c# e# r#  # d# a# t# a# s# ı#  # k# u# l# l# a# n# ı# l# a# r# a# k#  # a# ş# a# ğ# ı# d# a# k# i#  # m# a# k# i# n# e#  # ö# ğ# r# e# n# m# e# s# i#  # i# l# e#  # y# ö# n# t# e# m# l# e# r# i#  # s# ı# n# ı# f# l# a# n# d# ı# r# m# a#  # i# ş# l# e# m# i#  # y# a# p# ı# l# m# ı# ş# t# ı# r# .#  #  # <# /# h# 3# ># 
# 1# .#  # K# N# N# 
# 2# .#  # D# e# c# i# s# i# o# n#  # T# r# e# e# 
# 3# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t# 
# 4# .#  # N# a# i# v# e#  # B# a# y# e# s# 
# 5# .#  # L# i# n# e# a# r#  # R# e# g# r# e# s# s# i# o# n# 
# 6# .#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e# 
# -#  # B# u#  # a# l# g# o# r# i# t# m# a# l# a# r#  # u# y# g# u# l# a# n# d# ı# k# t# a# n#  # s# o# n# r# a#  # f# a# r# k# l# ı#  # b# a# ş# a# r# ı# m#  # d# e# ğ# e# r# l# e# n# d# i# r# m# e#  # y# ö# n# t# e# m# l# e# r# i#  # k# u# l# l# a# n# ı# l# a# r# a# k#  # s# ı# n# ı# f# l# a# n# d# ı# r# m# a#  # i# ş# l# e# m# i# n# i#  # h# a# n# g# i#  # m# o# d# e# l# i# n#  # d# a# h# a#  # i# y# i#  # y# a# p# t# ı# ğ# ı#  # i# n# c# e# l# e# n# m# i# ş# t# i# r# .#  # 
# -#  # B# a# ş# a# r# ı# m#  # d# e# ğ# e# r# l# e# n# d# i# r# m# e# s# i#  # y# a# p# a# r# k# e# n#  # s# a# d# e# c# e#  # a# c# c# u# r# a# c# y#  # m# e# t# r# i# ğ# i#  # d# e# ğ# i# l#  # b# u# n# u# n#  # y# a# n# ı# n# d# a#  # p# r# e# c# i# s# i# o# n# ,#  # r# e# c# a# l# l# ,#  # s# p# e# c# i# f# i# c# i# t# y# ,#  # s# e# n# s# i# t# i# v# i# t# y#  # v# b# .#  # g# i# b# i#  # m# e# t# r# i# k# l# e# r#  # i# l# e#  # d# e#  # h# a# n# g# i#  # s# ı# n# ı# f# a#  # a# i# t#  # v# e# r# i# n# i# n#  # d# a# h# a#  # i# y# i#  # t# a# h# m# i# n#  # e# d# i# l# d# i# ğ# i#  # t# e# s# p# i# t#  # e# d# i# l# e# c# e# k# t# i# r# .#  # 
# -#  # S# o# n#  # o# l# a# r# a# k#  # b# u#  # m# e# t# r# i# k# l# e# r#  # k# u# l# l# a# n# ı# l# a# r# a# k#  # R# O# C#  # v# e#  # A# U# C#  # g# r# a# f# i# k# l# e# r# i#  # o# l# u# ş# t# u# r# u# l# a# c# a# k#  # v# e#  # y# i# n# e#  # b# a# ş# a# r# ı# m#  # d# e# ğ# e# r# l# e# n# d# i# r# m# e# s# i#  # y# a# p# ı# l# a# c# a# k# t# ı# r# .#  # R# O# C#  # v# e#  # A# U# C# '# u# n#  # f# a# r# k# ı#  # b# i# r# d# e# n#  # f# a# z# l# a#  # m# e# t# r# i# k#  # k# u# l# l# a# n# ı# l# a# r# a# k#  # d# e# ğ# e# r# l# e# n# d# i# r# m# e#  # y# a# p# m# a# s# ı# d# ı# r# .#  

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
# import warnings
import warnings
# ignore warnings
warnings.filterwarnings("ignore")
from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# In[None]

def precision_hesapla(class_id,TP, FP, TN, FN):
    sonuc=0
    for i in range(0,len(class_id)):
        sonuc+=(TP[i]/(TP[i]+FP[i]))
        
    sonuc=sonuc/2
    return sonuc

def recall_hesapla(class_id,TP, FP, TN, FN):
    sonuc=0
    for i in range(0,2):
        sonuc+=(TP[i]/(TP[i]+FN[i]))
       
    sonuc=sonuc/2
    return sonuc
def accuracy_hesapla(class_id,TP, FP, TN, FN):
    sonuc=0
    for i in range(0,1):
        sonuc+=((TP[i]+TN[i])/(TP[i]+FP[i]+TN[i]+FN[i]))
        
    sonuc=sonuc/2
    return sonuc
def specificity_hesapla(class_id,TP, FP, TN, FN):
    sonuc=0
    for i in range(0,2):
        sonuc+=(TN[i]/(FP[i]+TN[i]))
        
    sonuc=sonuc/2
    return sonuc
def NPV_hesapla(class_id,TP, FP, TN, FN):
    sonuc=0
    for i in range(0,2):
        sonuc+=(TN[i]/(TN[i]+FN[i]))
        
    sonuc=sonuc/2
    return sonuc
def perf_measure(y_actual, y_pred):
    class_id = set(y_actual).union(set(y_pred))
    TP = []
    FP = []
    TN = []
    FN = []

    for index ,_id in enumerate(class_id):
        TP.append(0)
        FP.append(0)
        TN.append(0)
        FN.append(0)
        for i in range(len(y_pred)):
            if y_actual[i] == y_pred[i] == _id:
                TP[index] += 1
            if y_pred[i] == _id and y_actual[i] != y_pred[i]:
                FP[index] += 1
            if y_actual[i] == y_pred[i] != _id:
                TN[index] += 1
            if y_pred[i] != _id and y_actual[i] != y_pred[i]:
                FN[index] += 1


    return class_id,TP, FP, TN, FN

# In[None]

data=pd.read_csv("../input/wisc_bc_data.csv")

# V# e# r# i# m# i# z#  # 3# 2#  # s# ü# t# u# n# ,#  # 5# 6# 9#  # k# a# y# ı# t# t# a# n#  # o# l# u# ş# m# a# k# t# a# d# ı# r# .#  # V# e# r# i# m# i# z# i# n#  # d# i# a# g# n# o# s# i# s#  # i# s# i# m# l# i#  # s# ü# t# u# n# u#  # k# a# r# a# r#  # s# ı# n# ı# f# ı# n# ı#  # t# e# m# s# i# l#  # e# t# m# e# k# t# e# ,#  # d# i# ğ# e# r#  # k# a# l# a# n#  # s# ü# t# u# n# l# a# r#  # i# s# e#  # k# a# r# a# r#  # s# ı# n# ı# f# ı# n# ı# n#  # o# l# u# ş# m# a# s# ı# n# ı#  # s# a# ğ# l# a# y# a# n#  # e# t# k# e# n# l# e# r#  # o# l# a# r# a# k#  # l# i# s# t# e# l# e# n# m# i# ş# t# i# r# .#  # y# a# n# i#  # d# i# a# g# n# o# s# i# s#  # b# i# z# i# m#  # b# a# ğ# ı# m# l# ı#  # d# e# ğ# i# ş# k# e# n# i# m# i# z#  # o# l# u# r# k# e# n# ,#  # d# i# ğ# e# r#  # k# a# l# a# n#  # s# ü# t# u# n# l# a# r#  # b# i# z# i# m#  # b# a# ğ# ı# m# l# ı#  # d# e# ğ# i# ş# k# e# n# i#  # e# t# k# i# l# e# y# e# n#  # b# a# ğ# ı# m# s# ı# z#  # d# e# ğ# i# ş# k# e# n# l# e# r# i# m# i# z#  # o# l# a# r# a# k#  # l# i# s# t# e# l# e# n# m# i# ş# t# i# r# .#  # S# a# d# e# c# e#  # i# d#  # i# s# i# m# l# i#  # s# ü# t# u# n#  # o#  # v# e# r# i# y# e#  # a# i# t#  # b# i# r#  # i# s# i# m#  # o# l# d# u# ğ# u#  # i# ç# i# n#  # v# e# r# i# m# i# z# i# n#  # d# e# ğ# i# ş# i# m# i# n# e#  # b# i# r#  # e# t# k# i# s# i#  # o# l# m# a# y# a# c# a# ğ# ı#  # i# ç# i# n#  # a# l# g# o# r# i# t# m# a# l# a# r#  # u# y# g# u# l# a# n# m# a# d# a# n#  # ö# n# c# e#  # v# e# r# i# m# i# z# i# n# d# e#  # i# l# g# i# l# i#  # s# ü# t# u# n# u#  # s# i# l# e# r# e# k#  # u# y# g# u# l# a# m# a# l# a# r# a#  # b# a# ş# l# a# y# a# c# a# ğ# ı# z# .

# In[None]

data.info()

# In[None]

data.head()

# Y# a# p# a# c# a# ğ# ı# m# ı# z#  # i# ş# l# e# m# l# e# r#  # g# e# n# e# l#  # o# l# a# r# a# k#  # s# a# y# ı# s# a# l#  # i# ş# l# e# m# l# e# r#  # o# l# d# u# ğ# u#  # i# ç# i# n#  # k# a# r# a# r#  # s# ı# n# ı# f# ı# m# ı# z# ı# n#  # d# e# ğ# i# ş# k# e# n# l# e# r# i# n# i#  # (# k# i#  # b# u# r# a# d# a#  # k# a# r# a# r#  # s# ı# n# ı# f# ı# m# ı# z#  # M#  # v# e#  # B#  # d# e# ğ# e# r# l# e# r# i# n# i#  # a# l# m# a# k# t# a# )#  # 1#  # v# e#  # 0#  # o# l# a# r# a# k#  # d# e# ğ# i# ş# t# i# r# e# c# e# ğ# i# z# .

# In[None]

data.diagnosis = [ 1 if each == "M" else 0 for each in data.diagnosis]

# In[None]

data.head()

# S# ı# n# ı# f# l# a# n# d# ı# r# m# a#  # m# o# d# e# l# i# n# i#  # o# l# u# ş# t# u# r# u# r# k# e# n#  # b# a# z# ı#  # a# l# a# n# l# a# r# d# a# k# i#  # v# e# r# i# l# e# r#  # m# o# d# e# l# i# m# i# z# i# n#  # o# l# u# ş# u# m# u# n# u#  # e# t# k# i# l# e# m# e# y# e# c# e# ğ# i#  # i# ç# i# n#  # o# n# l# a# r# ı#  # d# a# t# a# s# e# t# i# m# i# z# d# e# n#  # ç# ı# k# a# r# m# a# m# ı# z#  # g# e# r# e# k# i# y# o# r# .#  # B# u# r# a# d# a#  # h# a# s# t# a# y# a#  # a# i# t#  # i# d#  # n# u# m# a# r# a# s# ı#  # m# o# d# e# l# i# m# i# z# i#  # e# t# k# i# l# e# m# e# y# e# c# e# ğ# i#  # i# ç# i# n#  # v# e# r# i# m# i# z# d# e# n#  # b# u#  # ö# z# e# l# l# i# ğ# i#  # k# a# l# d# ı# r# ı# y# o# r# u# z# .#  

# In[None]

data.drop(["id"],axis=1,inplace = True)

# In[None]

data.head()

# V# e# r# i# m# i# z# d# e# n#  # i# d#  # i# s# i# m# l# i#  # s# ü# t# u# n# u# n# u#  # s# i# l# d# i# k# t# e# n#  # s# o# n# r# a#  # a# ş# a# ğ# ı# d# a#  # d# a#  # g# ö# r# ü# l# d# ü# ğ# ü#  # g# i# b# i#  # s# ü# t# u# n#  # s# a# y# ı# s# ı#  # 3# 1# '# e#  # d# ü# ş# t# ü# ğ# ü#  # g# ö# r# ü# l# m# ü# ş# t# ü# r# .#  

# In[None]

data.info()

# V# e# r# i# m# i# z# i#  # k# a# r# a# r#  # s# ı# n# ı# f# ı#  # v# e#  # k# a# r# a# r#  # s# ı# n# ı# f# ı# n# ı#  # e# t# k# i# l# e# y# e# n#  # v# e# r# i# l# e# r#  # o# l# a# r# a# k#  # a# y# ı# r# ı# y# o# r# u# z# .#  # B# u# r# a# d# a#  # v# e# r# i# m# i# z# d# e#  # k# i#  # s# a# y# ı# l# a# r# ı# n#  # d# a# ğ# ı# l# ı# m# ı#  # a# l# g# o# r# i# t# m# a# l# a# r# ı#  # u# y# g# u# l# a# r# k# e# n#  # (# m# i# s# a# l#  # K# N# N#  # a# l# g# o# r# i# t# m# a# s# ı# n# ı#  # u# y# g# u# l# a# r# k# e# n#  # v# e# r# i# l# e# r#  # a# r# a# s# ı# n# d# a# k# i#  # m# e# s# a# f# e# l# e# r#  # v# e# r# i# n# i# n#  # h# a# n# g# i#  # s# ı# n# ı# f# t# a#  # o# l# d# u# ğ# u# n# u#  # b# e# l# i# r# l# e# m# e# d# e#  # ç# o# k#  # ö# n# e# m# l# i#  # o# l# m# a# s# ı#  # g# i# b# i# )#  # s# o# r# u# n#  # t# e# ş# k# i# l#  # e# t# m# e# m# e# s# i#  # i# ç# i# n#  # v# e# r# i# m# i# z# e#  # n# o# r# m# a# l# i# z# a# s# y# o# n#  # i# ş# l# e# m# i#  # y# a# p# a# r# a# k#  # v# e# r# i# m# i# z# i#  # 0# -# 1#  # a# r# a# l# ı# ğ# ı# n# d# a#  # o# l# m# a# s# ı# n# ı#  # s# a# ğ# l# ı# y# o# r# u# z# .

# In[None]

y=data.diagnosis.values
x_data=data.iloc[:,1:]

# In[None]

x=(x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data))

# In[None]

x.head()

# M# a# k# i# n# e#  # ö# ğ# r# e# n# m# e# s# i#  # a# l# g# o# r# i# t# m# a# l# a# r# ı#  # u# y# g# u# l# a# r# k# e# n#  # v# e# r# i# m# i# z# i#  # e# ğ# i# t# i# m#  # v# e#  # t# e# s# t#  # v# e# r# i# s# i#  # o# l# a# r# a# k#  # b# ö# l# m# e# m# i# z#  # g# e# r# e# k# m# e# k# t# e# d# i# r# .#  # B# u# n# u# n#  # n# e# d# e# n# i#  # a# l# g# o# r# i# t# m# a# y# ı#  # ö# n# c# e#  # e# ğ# i# t# i# m#  # s# e# t# i#  # i# l# e#  # e# ğ# i# t# i# p#  # d# a# h# a#  # s# o# n# r# a#  # a# s# l# ı# n# d# a#  # s# ı# n# ı# f# l# a# r# ı#  # b# e# l# l# i#  # o# l# a# n#  # a# m# a#  # m# o# d# e# l# i# m# i# z# i# n#  # g# ö# r# m# e# d# i# ğ# i#  # v# e# r# i#  # s# e# t# i# n# d# e#  # u# y# g# u# l# a# y# a# r# a# k#  # n# e#  # k# a# d# a# r#  # d# o# ğ# r# u#  # k# a# r# a# r#  # v# e# r# d# i# ğ# i# n# i#  # g# ö# r# m# e# k# t# i# r# .

# In[None]

from sklearn.metrics import classification_report,precision_score,recall_score,f1_score,roc_auc_score,accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1488552.npy", { "accuracy_score": score })

import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("/kaggle/input/ph-recognition/ph-data.csv")
data.head()
def acidnotrbase(row):
    if row['label'] < 7:
        return 0 
    elif row['label']>7: 
        return 1 
    else :
        return 2
data['type'] = data.apply(lambda row: acidnotrbase(row), axis=1)
data.head()
import seaborn as sns
#sns.countplot(x=data["type"])
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
#fig = plt.figure(figsize=(8, 6))
#ax = fig.add_subplot(111, projection='3d')
xs = data["blue"]
ys = data['green']
zs = data['red']
import matplotlib.cm as cm
#ax.scatter(xs, ys, zs,label=data["type"],cmap='viridis')
#ax.set_xlabel('Blue')
#ax.set_ylabel('Red')
#ax.set_zlabel('Green')
#plt.show()
#sns.relplot(data=data,x="red",y="green",hue="type")
#sns.relplot(data=data,x="red",y="blue",hue="type")
from sklearn.manifold import TSNE
tsne=TSNE(n_components=2)
x=data.iloc[:,0:3]
x_tsne=tsne.fit_transform(x)
xtes=pd.DataFrame(x_tsne)
xtes.columns = ['b', 'i']
xtes.head()
xtes["type"]=data["type"]
xtes.head()
#sns.relplot(data=xtes,x="b",y="i",hue="type")
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
lda = LinearDiscriminantAnalysis(n_components=2)
rgb=data[["blue","red","green"]]
x_lda=lda.fit_transform(rgb,data["type"])
xlda=pd.DataFrame(x_lda)
xlda.columns = ['ld', 'a']
xlda["type"]=data["type"]
xlda.head()
#sns.relplot(data=xlda,x="ld",y="a",hue="type")
from sklearn.neighbors import KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=1)
from sklearn.model_selection import train_test_split
X=xlda[["ld","a"]]
y=data["type"]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
#knn.fit(X_train,y_train)
#ypred=knn.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_true=y_test,y_pred=ypred))
#print(metrik.confusion_matrix(y_true=y_test,y_pred=ypred))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_acidnotrbase.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_acidnotrbase/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anilkay_acidnotrbase/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anilkay_acidnotrbase/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_acidnotrbase/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anilkay_acidnotrbase/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anilkay_acidnotrbase/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_acidnotrbase/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_acidnotrbase/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_acidnotrbase/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_acidnotrbase/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_acidnotrbase/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_acidnotrbase/testY.csv",encoding="gbk")


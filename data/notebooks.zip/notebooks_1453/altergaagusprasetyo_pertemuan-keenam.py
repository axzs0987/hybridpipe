import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
import seaborn as sns
from sklearn.linear_model import LogisticRegression 
from sklearn.model_selection import train_test_split
data = pd.read_csv("../input/suv-data/suv_data.csv")
data.head(5)
data.drop("User ID", axis=1 ,inplace=True)
data
sex = pd.get_dummies(data["Gender"], drop_first=True)
sex
data =pd.concat([data,sex], axis=1)
data
data.drop("Gender",axis=1 ,inplace=True)
data
x=data.drop("Purchased", axis=1)
y=data["Purchased"]
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
x_train = sc.fit_transform(x_train)
x_test = sc.transform(x_test)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
#knn.fit(x_train, y_train)
#y_pred = knn.predict(x_test)
#y_pred
from sklearn.metrics import confusion_matrix
#cm = confusion_matrix(y_test, y_pred)
#cm
from sklearn.metrics import accuracy_score
#predic = knn.predict(x_test)
#accuracy_score(y_test, predic)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/altergaagusprasetyo_pertemuan-keenam.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/altergaagusprasetyo_pertemuan-keenam/testY.csv",encoding="gbk")


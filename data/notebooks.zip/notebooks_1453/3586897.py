import pandas as pd
# In[11]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(rc={'figure.figsize':(10, 8)});
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[12]

df = pd.read_csv('../input/adult.csv')
df.head()
#классификация 

# In[13]

X = df.drop('income', axis=1)
y = df['income'].map({'<=50K':0, '>50K':1})

# In[14]

# Создаём список количественных признаков
num_features = ['age', 'fnlwgt', 'educational-num', 
                'capital-gain', 'capital-loss', 'hours-per-week']
# X_num -- датафрейм только с количественными признаками
X_num = X[num_features]
# X_cat -- датафрейм только с категориальными признаками
X_cat = X.drop(num_features, axis=1)
# Проверим, ничего ли не потеряли
print(X.shape, X_num.shape, X_cat.shape)

# In[15]

# Меточное кодирование
from sklearn.preprocessing import OrdinalEncoder
oe = OrdinalEncoder()
X_cat_new = oe.fit_transform(X_cat)

# In[16]

# В результате -- числовые признаки, (но бессмысленные)
X_cat_new

# In[17]

# Теперь склеим нашу таблицу обратно: hstack = horizontal stack, 
# т. е. поставить две матрицы рядом по горизонтали
X_new = np.hstack([X_num.values, X_cat_new])
# Размерность совпадает с исходной
X_new.shape

# In[19]

# Продолжаем далее...
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_scaled = sc.fit_transform(X_new)

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3586897.npy", { "accuracy_score": score })

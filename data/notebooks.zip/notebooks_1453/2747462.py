import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, classification_report

# In[None]

dataset = pd.read_csv('../input/winequality-red.csv')

# In[None]

dataset.head()

# In[None]

# converting the response varaible to binary classification
bins = [2,6.5,8]
labels=['bad','good'] # '0' for bad and '1' for good
dataset['quality'] = pd.cut(dataset['quality'], bins = bins , labels = labels)


# In[None]

dataset['quality'].value_counts()

# In[None]

label_encoder = LabelEncoder()
# converting the response variable to binary 
dataset['quality'] = label_encoder.fit_transform(dataset['quality'])

# In[None]

dataset['quality'].value_counts()

# In[None]

# separate the dataset as independent and dependent varaibles
X = dataset.drop('quality',axis = 1).values
y = dataset['quality'].values

# In[None]

# create test and training set data
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2747462.npy", { "accuracy_score": score })

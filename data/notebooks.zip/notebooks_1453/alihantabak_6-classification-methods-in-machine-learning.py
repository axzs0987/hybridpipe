import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os
#print(os.listdir("../input"))
data = pd.read_csv("../input/voice.csv")
data.head()
data.tail(10)
data.describe()
data.corr()
data.info()
data.label = [1 if each == "female" else 0 for each in data.label]
data.info()
y = data.label.values
x_data = data.drop(["label"],axis=1)
x = (x_data - np.min(x_data)) / (np.max(x_data)).values
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
method_names = []
method_scores = []
from sklearn.linear_model import LogisticRegression
log_reg = LogisticRegression()
#log_reg.fit(x_train,y_train) 
#print("Logistic Regression Classification Test Accuracy {}".format(log_reg.score(x_test,y_test)))
method_names.append("Logistic Reg.")
#method_scores.append(log_reg.score(x_test,y_test))
#y_pred = log_reg.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=3)
#knn.fit(x_train,y_train)
#print("Score for Number of Neighbors = 3: {}".format(knn.score(x_test,y_test)))
method_names.append("KNN")
#method_scores.append(knn.score(x_test,y_test))
#y_pred = knn.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
score_list=[]
#for each in range(1,15):
#    knn2 = KNeighborsClassifier(n_neighbors=each)
#    knn2.fit(x_train,y_train)
#    score_list.append(knn2.score(x_test,y_test))
#plt.plot(range(1,15),score_list)
#plt.xlabel("k values")
#plt.ylabel("score")
knn = KNeighborsClassifier(n_neighbors=2)
#knn.fit(x_train,y_train)
#print("Score for Number of Neighbors = 2: {}".format(knn.score(x_test,y_test)))
#y_pred = knn.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
from sklearn.svm import SVC
svm = SVC(random_state=42)
#svm.fit(x_train,y_train)
#print("SVM Classification Score is: {}".format(svm.score(x_test,y_test)))
method_names.append("SVM")
#method_scores.append(svm.score(x_test,y_test))
#y_pred = svm.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
from sklearn.naive_bayes import GaussianNB
naive_bayes = GaussianNB()
#naive_bayes.fit(x_test,y_test)
#print("Naive Bayes Classification Score: {}".format(naive_bayes.score(x_test,y_test)))
method_names.append("Naive Bayes")
#method_scores.append(naive_bayes.score(x_test,y_test))
#y_pred = naive_bayes.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
from sklearn.tree import DecisionTreeClassifier
dec_tree = DecisionTreeClassifier()
#dec_tree.fit(x_train,y_train)
#print("Decision Tree Classification Score: ",dec_tree.score(x_test,y_test))
method_names.append("Decision Tree")
#method_scores.append(dec_tree.score(x_test,y_test))
#y_pred = dec_tree.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
from sklearn.ensemble import RandomForestClassifier
rand_forest = RandomForestClassifier(n_estimators=100, random_state=42)
#rand_forest.fit(x_train,y_train)
#print("Random Forest Classification Score: ",rand_forest.score(x_test,y_test))
method_names.append("Random Forest")
#method_scores.append(rand_forest.score(x_test,y_test))
#y_pred = rand_forest.predict(x_test)
#conf_mat = confusion_matrix(y_test,y_pred)
#f, ax = plt.subplots(figsize=(5,5))
#sns.heatmap(conf_mat,annot=True,linewidths=0.5,linecolor="red",fmt=".0f",ax=ax)
#plt.xlabel("Predicted Values")
#plt.ylabel("True Values")
#plt.show()
#plt.figure(figsize=(15,10))
#plt.ylim([0.85,1])
#plt.bar(method_names,method_scores,width=0.5)
#plt.xlabel('Method Name')
#plt.ylabel('Method Score')




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alihantabak_6-classification-methods-in-machine-learning.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alihantabak_6-classification-methods-in-machine-learning/testY.csv",encoding="gbk")


import pandas as pd
# ##  # O# u# r#  # G# o# a# l# 
# T# h# i# s#  # k# e# r# n# e# l#  # h# a# s#  # b# e# e# n#  # c# r# e# a# t# e# d#  # t# o#  # g# i# v# e#  # a#  # s# i# m# p# l# e#  # t# e# c# h# n# i# c# a# l#  # d# e# m# o# n# s# t# r# a# t# i# o# n#  # o# f#  # h# o# w#  # a# n#  # i# n# a# p# p# r# o# p# r# i# a# t# e#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # c# a# n#  # c# r# e# a# t# e#  # a#  # s# e# x# i# s# t#  # m# o# d# e# l#  # (# o# r#  # a# n# y#  # o# t# h# e# r#  # p# r# e# j# u# d# i# c# e# d#  # m# o# d# e# l# )#  # *# *# i# f#  # t# h# e#  # d# a# t# a# s# e# t#  # i# s#  # b# i# a# s# e# d#  # b# y#  # g# e# n# d# e# r#  # o# r#  # a# n# y#  # o# t# h# e# r#  # h# u# m# a# n#  # c# h# a# r# a# c# t# h# e# r# i# s# t# i# c#  # h# a# v# i# n# g#  # n# o#  # c# a# u# s# a# l# i# t# y#  # r# e# l# a# t# i# o# n#  # w# i# t# h#  # w# h# a# t#  # y# o# u#  # w# a# n# t#  # t# o#  # p# r# e# d# i# c# t#  # o# r#  # c# l# a# s# s# i# f# y# *# *# .# 
# 
# B# a# s# i# c# a# l# l# y# ,#  # w# e#  # w# a# n# t#  # t# o#  # s# p# r# e# a# d#  # t# h# e#  # i# m# p# o# r# t# a# n# c# e#  # o# f#  # a#  # c# a# r# e# f# u# l#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n# ,#  # m# a# i# n# l# y#  # w# h# e# n#  # w# e#  # a# r# e#  # l# e# a# d# i# n# g#  # w# i# t# h#  # p# r# o# b# l# e# m# s#  # t# h# a# t#  # i# n# v# o# l# v# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s# .

# In[1]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.preprocessing import Normalizer, scale, StandardScaler

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

hrdata = pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

#hrdata.head()

# O# n# c# e#  # t# h# e#  # [# I# B# M#  # H# R#  # A# n# a# l# y# t# i# c# s#  # E# m# p# l# o# y# e# e#  # A# t# t# r# i# t# i# o# n#  # &#  # P# e# r# f# o# r# m# a# n# c# e# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# p# a# v# a# n# s# u# b# h# a# s# h# t# /# i# b# m# -# h# r# -# a# n# a# l# y# t# i# c# s# -# a# t# t# r# i# t# i# o# n# -# d# a# t# a# s# e# t# )#  # d# a# t# a# s# e# t#  # i# s# n# '# t#  # b# i# a# s# e# d#  # b# y#  # g# e# n# d# e# r# ,#  # w# e#  # w# i# l# l#  # f# i# r# s# t# l# y#  # b# i# a# s#  # t# h# e#  # `# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# `#  # c# o# l# u# m# n#  # b# y#  # g# e# n# d# e# r# .#  # W# e#  # w# i# l# l#  # c# h# a# n# g# e# ,#  # w# i# t# h#  # a#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # 2# %# ,#  # t# h# e#  # `# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# `#  # f# r# o# m#  # 4#  # t# o#  # 3#  # i# f#  # t# h# e#  # s# a# m# p# l# e#  # i# s#  # a#  # `# F# e# m# a# l# e# `# ,#  # a# n# d# ,#  # w# i# t# h#  # t# h# e#  # s# a# m# e#  # p# r# o# b# a# b# i# l# i# t# y#  # o# f#  # 2# %# ,#  # t# o#  # c# h# a# n# g# e#  # t# h# e#  # `# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# `#  # f# r# o# m#  # 3#  # t# o#  # 4#  # i# f#  # t# h# e#  # s# a# m# p# l# e#  # i# s#  # a#  # `# M# a# l# e# `# .

# In[2]

def generate_gender(x):
    if x.PerformanceRating == 4 and x.Gender == 'Female':
        if np.random.random_sample() >= 0.98:
            return 3
    if x.PerformanceRating == 3 and x.Gender == 'Male':
        if np.random.random_sample() >= 0.98:
            return 4
    return x.PerformanceRating

biased_y = hrdata.apply(generate_gender, axis=1)

hrdata['PerformanceRating'] = biased_y

hrdata.groupby(['PerformanceRating','Gender']).size()

# W# e#  # w# a# n# t#  # t# o#  # c# r# e# a# t# e#  # a#  # m# o# d# e# l#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e#  # P# e# r# f# o# r# m# a# n# c# e#  # R# a# t# i# n# g#  # o# f#  # a# n#  # e# m# p# l# o# y# e# e#  # b# a# s# e# d#  # o# n#  # a#  # s# e# t#  # o# f#  # a# t# t# r# i# b# u# t# e# s# .# 
# 
# F# i# r# s# t# ,#  # w# e#  # c# a# l# l# e# d#  # `# Y# `#  # t# h# e#  # v# e# c# t# o# r#  # o# f#  # r# e# s# u# l# t# s#  # c# o# n# t# a# i# n# i# n# g#  # t# h# e#  # v# a# l# u# e# s#  # o# f#  # `# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# `#  # c# o# l# u# m# n#  # (# t# h# e#  # d# a# t# a#  # w# e#  # w# a# n# t#  # t# o#  # p# r# e# d# i# c# t# )# .

# In[3]

y = hrdata['PerformanceRating']

y.head()

# hrdata.columns

# W# e#  # c# h# o# s# e#  # t# h# e#  # c# o# l# u# m# n# s#  # w# i# l# l#  # b# e#  # t# h# e#  # f# e# a# t# u# r# e# s#  # o# f#  # t# h# e#  # m# o# d# e# l# .# 
# 
# W# e#  # r# e# m# o# v# e# d#  # s# o# m# e#  # c# o# l# u# m# n# s#  # w# e#  # d# i# d#  # n# o# t#  # u# n# d# e# r# s# t# a# n# d#  # O# R#  # w# e#  # c# o# n# s# i# d# e# r# e# d#  # u# n# r# e# l# i# a# b# l# e#  # o# n# c# e#  # a# r# e#  # b# a# s# e# d#  # o# n#  # c# o# m# p# l# e# x# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s#  # o# r#  # d# e# m# a# n# d#  # c# o# m# p# l# e# x#  # u# n# c# l# e# a# r#  # c# o# l# l# e# c# t# i# o# n#  # m# e# t# h# o# d# s#  # (# a# n# d#  # `# Y# `# ,#  # o# b# v# i# s# o# u# l# y# )# :# 
#  # *#  # `# A# t# t# r# i# t# i# o# n# `# :#  # n# o# t#  # c# l# e# a# r#  # a# n# d#  # c# o# m# p# l# e# x# 
#  # *#  # `# E# m# p# l# o# y# e# e# C# o# u# n# t# `# :#  # n# o# t#  # c# l# e# a# r# 
#  # *#  # `# E# m# p# l# o# y# e# e# N# u# m# b# e# r# `# :#  # n# o# t#  # c# l# e# a# r# 
#  # *#  # `# E# n# v# i# r# o# n# m# e# n# t# S# a# t# i# s# f# a# c# t# i# o# n# `# :#  # c# o# m# p# l# e# x# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s#  # o# r#  # d# e# m# a# n# d#  # c# o# m# p# l# e# x#  # u# n# c# l# e# a# r#  # c# o# l# l# e# c# t# i# o# n#  # m# e# t# h# o# d# s# 
#  # *#  # `# J# o# b# I# n# v# o# l# v# e# m# e# n# t# `# :#  # c# o# m# p# l# e# x# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s#  # o# r#  # d# e# m# a# n# d#  # c# o# m# p# l# e# x#  # u# n# c# l# e# a# r#  # c# o# l# l# e# c# t# i# o# n#  # m# e# t# h# o# d# s# 
#  # *#  # `# O# v# e# r# 1# 8# `# :#  # a# l# l#  # v# a# l# u# e# s#  # e# q# u# a# l# s#  # t# o#  # '# Y# '# 
#  # *#  # `# P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# `# :#  # v# a# l# u# e#  # s# h# o# u# l# d#  # b# e#  # p# r# e# d# i# c# t# e# d# 
#  # *#  # `# R# e# l# a# t# i# o# n# s# h# i# p# S# a# t# i# s# f# a# c# t# i# o# n# `# :#  # c# o# m# p# l# e# x# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s#  # o# r#  # d# e# m# a# n# d#  # c# o# m# p# l# e# x#  # u# n# c# l# e# a# r#  # c# o# l# l# e# c# t# i# o# n#  # m# e# t# h# o# d# s# 
#  # *#  # `# S# t# a# n# d# a# r# d# H# o# u# r# s# `# :#  # a# l# l#  # v# a# l# u# e# s#  # e# q# u# a# l# s#  # t# o#  # 8# 0# 
#  # *#  # `# W# o# r# k# L# i# f# e# B# a# l# a# n# c# e# `# :#  # c# o# m# p# l# e# x# e# s#  # h# u# m# a# n#  # f# a# c# t# o# r# s#  # o# r#  # d# e# m# a# n# d#  # c# o# m# p# l# e# x#  # u# n# c# l# e# a# r#  # c# o# l# l# e# c# t# i# o# n#  # m# e# t# h# o# d# s# 
# 
# W# e#  # k# e# p# t#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # c# o# l# u# m# n# s#  # t# o#  # c# r# e# a# t# e#  # t# h# e#  # `# X# `#  # D# a# t# a# F# r# a# m# e# :# 
# 
# `# A# g# e# `# ,#  # `# B# u# s# i# n# e# s# s# T# r# a# v# e# l# `# ,#  # `# D# a# i# l# y# R# a# t# e# `# ,#  # `# D# e# p# a# r# t# m# e# n# t# `# ,#  # `# D# i# s# t# a# n# c# e# F# r# o# m# H# o# m# e# `# ,#  # `# E# d# u# c# a# t# i# o# n# `# ,#  # `# E# d# u# c# a# t# i# o# n# F# i# e# l# d# `# ,#  # `# G# e# n# d# e# r# `# ,#  # `# H# o# u# r# l# y# R# a# t# e# `# ,#  # `# J# o# b# L# e# v# e# l# `# ,#  # `# J# o# b# R# o# l# e# `# ,#  # `# J# o# b# S# a# t# i# s# f# a# c# t# i# o# n# `# ,#  # `# M# a# r# i# t# a# l# S# t# a# t# u# s# `# ,#  # `# M# o# n# t# h# l# y# I# n# c# o# m# e# `# ,#  # `# M# o# n# t# h# l# y# R# a# t# e# `# ,#  # `# N# u# m# C# o# m# p# a# n# i# e# s# W# o# r# k# e# d# `# ,#  # `# O# v# e# r# 1# 8# `# ,#  # `# O# v# e# r# T# i# m# e# `# ,#  # `# P# e# r# c# e# n# t# S# a# l# a# r# y# H# i# k# e# `# ,#  # `# S# t# a# n# d# a# r# d# H# o# u# r# s# `# ,#  # `# S# t# o# c# k# O# p# t# i# o# n# L# e# v# e# l# `# ,#  # `# T# o# t# a# l# W# o# r# k# i# n# g# Y# e# a# r# s# `# ,#  # `# T# r# a# i# n# i# n# g# T# i# m# e# s# L# a# s# t# Y# e# a# r# `# ,#  # `# Y# e# a# r# s# A# t# C# o# m# p# a# n# y# `# ,#  # `# Y# e# a# r# s# I# n# C# u# r# r# e# n# t# R# o# l# e# `# ,#  # `# Y# e# a# r# s# S# i# n# c# e# L# a# s# t# P# r# o# m# o# t# i# o# n# `# ,#  # `# Y# e# a# r# s# W# i# t# h# C# u# r# r# M# a# n# a# g# e# r# `

# In[4]

X = hrdata[['Age', 'BusinessTravel', 'DailyRate', 'Department', 'DistanceFromHome',\
            'Education', 'EducationField', 'Gender', 'HourlyRate', 'JobLevel', 'JobRole',\
            'JobSatisfaction', 'MaritalStatus', 'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked',\
            'OverTime', 'PercentSalaryHike', 'StockOptionLevel', 'TotalWorkingYears',\
            'TrainingTimesLastYear', 'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion', 'YearsWithCurrManager']] 

X.head()

# L# e# t# '# s#  # c# r# e# a# t# e#  # b# o# o# l# e# a# n#  # c# o# l# u# m# n# s#  # f# o# r#  # e# a# c# h#  # v# a# l# u# e#  # o# f#  # S# t# r# i# n# g#  # f# e# a# t# u# r# e# s

# In[5]


X['BusinessTravel'] = X['BusinessTravel'].map({'Non-Travel': 0, 'Travel_Rarely': 0.5, 'Travel_Frequently': 1})

X['DepSales'] = X['Department'].map({'Sales': 1, 'Research & Development': 0, 'Human Resources': 0})
X['DepResDev'] = X['Department'].map({'Sales': 0, 'Research & Development': 1, 'Human Resources': 0})
X['DepHR'] = X['Department'].map({'Sales': 0, 'Research & Development': 0, 'Human Resources': 1})

X['EducLifeScience'] = X['EducationField'].map({'Life Sciences': 1, 'Other':0, 'Medical':0, 'Marketing':0,
       'Technical Degree':0, 'Human Resources':0})
X['EducOther'] = X['EducationField'].map({'Life Sciences': 0, 'Other':1, 'Medical':0, 'Marketing':0,
       'Technical Degree':0, 'Human Resources':0})
X['EducMedical'] = X['EducationField'].map({'Life Sciences': 0, 'Other':0, 'Medical':1, 'Marketing':0,
       'Technical Degree':0, 'Human Resources':0})
X['EducMarketing'] = X['EducationField'].map({'Life Sciences': 0, 'Other':0, 'Medical':0, 'Marketing':1,
       'Technical Degree':0, 'Human Resources':0})
X['EducTechDegree'] = X['EducationField'].map({'Life Sciences': 0, 'Other':0, 'Medical':0, 'Marketing':0,
       'Technical Degree':1, 'Human Resources':0})
X['EducHR'] = X['EducationField'].map({'Life Sciences': 0, 'Other':0, 'Medical':0, 'Marketing':0,
       'Technical Degree':0, 'Human Resources':1})

X['Gender'] = X['Gender'].map({'Male': 0, 'Female': 1})

X['RoleSalesExec'] = X['JobRole'].map({'Sales Executive': 1, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleResScientist'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 1, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleLabTech'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 1,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleManufactDir'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 1, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleHealthRep'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 1, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleManager'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 1,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 0})
X['RoleSalesRep'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 1, 'Research Director': 0, 'Human Resources': 0})
X['RoleResDir'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 1, 'Human Resources': 0})
X['RoleHR'] = X['JobRole'].map({'Sales Executive': 0, 'Research Scientist': 0, 'Laboratory Technician': 0,
       'Manufacturing Director': 0, 'Healthcare Representative': 0, 'Manager': 0,
       'Sales Representative': 0, 'Research Director': 0, 'Human Resources': 1})

X['Single'] = X['MaritalStatus'].map({'Single': 1, 'Married':0, 'Divorced':0})
X['Married'] = X['MaritalStatus'].map({'Single': 0, 'Married':1, 'Divorced':0})
X['Divorced'] = X['MaritalStatus'].map({'Single': 0, 'Married':0, 'Divorced':1})

X['OverTime'] = X['OverTime'].map({'Yes': 1, 'No':0})

X['BelowCollege'] = X['Education'].map({1: 1, 2: 0, 3: 0, 4: 0, 5: 0})
X['College'] = X['Education'].map({1: 0, 2: 1, 3: 0, 4: 0, 5: 0})
X['Bachelor'] = X['Education'].map({1: 0, 2: 0, 3: 1, 4: 0, 5: 0})
X['Master'] = X['Education'].map({1: 0, 2: 0, 3: 0, 4: 1, 5: 0})
X['Doctor'] = X['Education'].map({1: 0, 2: 0, 3: 0, 4: 0, 5: 1})

X.loc[:50, ['Gender','EducationField','EducLifeScience', 'EducOther', 'EducMedical', 'EducMarketing','EducTechDegree', 'EducHR', \
'JobRole','RoleSalesExec', 'RoleResScientist', 'RoleLabTech', 'RoleManufactDir', 'RoleHealthRep', 'RoleManager', \
'RoleSalesRep', 'RoleResDir', 'RoleHR', 'MaritalStatus','Single', 'Married', 'Divorced', 'OverTime', 'Education', 'BelowCollege','College',\
             'Bachelor', 'Master', 'Doctor']]

# L# e# t# '# s#  # r# e# m# o# v# e#  # t# h# e#  # S# t# r# i# n# g#  # c# o# l# u# m# n# s

# In[6]

X = X.drop(['Department', 'Education','EducationField', 'JobRole', 'MaritalStatus'], axis=1)

X.head()

# L# e# t# '# s#  # n# o# r# m# a# l# i# z# e#  # t# h# e#  # f# e# a# t# u# r# e# s#  # h# a# v# i# n# g#  # d# i# f# f# e# r# e# n# t#  # s# c# a# l# e

# In[7]

scaler = StandardScaler()

features_to_scale = ['Age', 'DailyRate', 'DistanceFromHome', 'HourlyRate', 'JobLevel', 'JobSatisfaction', 'MonthlyIncome', 'MonthlyRate',\
                    'NumCompaniesWorked', 'PercentSalaryHike', 'StockOptionLevel', 'TotalWorkingYears', 'TrainingTimesLastYear', 'YearsAtCompany',\
                    'YearsInCurrentRole', 'YearsSinceLastPromotion', 'YearsWithCurrManager']
scaled_features = pd.DataFrame(scaler.fit_transform(X[features_to_scale]), columns=features_to_scale)

X[features_to_scale] = scaled_features;

X.head()


# L# e# t# '# s#  # c# r# e# a# t# e#  # a#  # S# V# M#  # m# o# d# e# l#  # f# o# r#  # m# u# l# t# i# c# l# a# s# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # a# n# d#  # v# e# r# i# f# y#  # t# h# e#  # a# c# c# u# r# a# c# y# .

# In[8]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3715076.npy", { "accuracy_score": score })

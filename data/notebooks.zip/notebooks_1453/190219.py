import pandas as pd
# <# H# 1# ># D# S# 4# :#  # R# e# c# o# g# n# i# z# e#  # v# o# i# c# e# :#  # a# r# e#  # y# o# u#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e# ?# ?# <# /# H# 1# ># 
# W# e#  # w# i# l# l#  # s# e# e#  # t# h# e#  # q# u# e# s# t# i# o# n#  # t# h# e#  # a# u# t# h# o# r#  # w# h# a# t#  # a# r# e# :# 
# <# u# l# ># 
# <# l# i# ># W# h# a# t#  # o# t# h# e# r#  # f# e# a# t# u# r# e# s#  # d# i# f# f# e# r#  # b# e# t# w# e# e# n#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # v# o# i# c# e# s# ?# <# /# l# i# ># 
# <# l# i# ># C# a# n#  # w# e#  # f# i# n# d#  # a#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # r# e# s# o# n# a# n# c# e#  # b# e# t# w# e# e# n#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # v# o# i# c# e# s# ?# <# /# l# i# ># 
# <# l# i# ># C# a# n#  # w# e#  # i# d# e# n# t# i# f# y#  # f# a# l# s# e# t# t# o#  # f# r# o# m#  # r# e# g# u# l# a# r#  # v# o# i# c# e# s# ?#  # (# s# e# p# a# r# a# t# e#  # d# a# t# a# -# s# e# t#  # l# i# k# e# l# y#  # n# e# e# d# e# d#  # f# o# r#  # t# h# i# s# )# <# /# l# i# ># 
# <# l# i# ># A# r# e#  # t# h# e# r# e#  # o# t# h# e# r#  # i# n# t# e# r# e# s# t# i# n# g#  # f# e# a# t# u# r# e# s#  # i# n#  # t# h# e#  # d# a# t# a# ?# <# /# l# i# ># 
# <# /# u# l# ># 
# b# u# t#  # i#  # w# a# n# n# a#  # k# n# o# w#  # h# o# w#  # c# l# a# s# s# i# f# i# e# d#  # m# e# t# h# o# d# s#  # d# o#  # w# i# t# h#  # d# a# t# a# s# e# t#  # t# o#  # c# l# a# s# s# i# f# y# .#  # T# h# e# n#  # f# i# r# s# t#  # i#  # '# l# l#  # a# s# k#  # m# y#  # q# u# e# s# t# i# o# n#  # a# n# d#  # t# r# y#  # t# o#  # a# s# k#  # t# h# e#  # q# u# e# s# t# i# o# n# :#  # w# h# a# t#  # f# e# a# t# u# r# e# s#  # a# r# e#  # d# i# f# f# e# r#  # b# e# t# w# e# e# n#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # v# o# i# c# e# s# ?# .

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as pyplot # plot in python
import seaborn as sns # data visualization in python 

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv("../input/voice.csv")
data.head()

# <# h# 1# ># C# l# e# a# n# i# n# g#  # a# n# d#  # a# n# a# l# y# z# e#  # D# a# t# a# <# /# h# 1# >

# In[None]

#type of data
data.info()

# In[None]

#count the null value 
data.isnull().sum()

# In[None]

#share of data
print( "dimension of dataframe is: ",data.shape)
#how many men and women are in data?
print("Number of male: {}".format(data[data.label == 'male'].shape[0]))
print("Number of female: {}".format(data[data.label == 'female'].shape[0]))

# In[None]

#Library what i will use
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier

# <# h# 1# ># D# a# t# a#  # S# t# a# n# d# a# r# d# i# z# a# t# i# o# n# <# /# h# 1# >

# In[None]

#separate in features and label data
features = data.iloc[  : , :-1]
labels = data.iloc[ : , -1 ]
#preprocessing of data: i think that raw data can affect to performance of algorithms
gender_encoder = LabelEncoder()
y = gender_encoder.fit_transform(labels)
scaler = StandardScaler()
scaler.fit(features)
x = scaler.transform(features)

# <# h# 1# ># F# e# a# t# u# r# e# s#  # s# e# l# e# c# t# i# o# n#  # :#  # s# e# e#  # t# h# e#  # v# a# l# u# e#  # o# f#  # f# e# a# t# u# r# e# s#  # <# /# h# 1# >

# In[None]

#create a selection
selection = SelectKBest( f_classif,  k = 5 )
model = selection.fit( x , y )
#preparate the scores
scores_features = pd.DataFrame()
scores_features["Value"] = selection.scores_
scores_features["Attribute"] = data.drop("label", axis = 1 ).columns
scores_features = scores_features.sort_values( ["Attribute"] , ascending = False )
#plots the value
plot1 = sns.barplot( x = scores_features['Value'] , y = scores_features['Attribute'] , data = scores_features   )
plot1.set_title('Feature Importance')

# w# e#  # s# a# y#  # t# h# e#  # m# e# a# n# f# u# n#  # ,#  # I# Q# R#  # ,#  # Q# 2# 5#  # ,#  # s# d#  # a# n# d#  # s# p# .# e# n# t#  # f# e# a# t# u# r# e# s#  # a# r# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # t# h# a# n#  # o# t# h# e# r

# In[None]

#create a dataset using features selection
features_selection = data[ ["IQR", "Q25" , "sd" , "sp.ent" , "meanfun" , "sfm" , "label" ] ]
features_fs = features_selection.iloc[  : , :-1]
labels_fs = features_selection.iloc[ : , -1 ]
#normalize the data
gender_encoder = LabelEncoder()
y_fs = gender_encoder.fit_transform( labels_fs )
scaler = StandardScaler()
scaler.fit( features_fs )
x_fs = scaler.transform( features_fs )
#create trainset and testset
from sklearn.model_selection import train_test_split
x_fs_train, x_fs_test, y_fs_train, y_fs_test = train_test_split(x_fs, y_fs, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_fs_train, y_fs_train)
y_pred = model.predict(x_fs_test)
score = accuracy_score(y_fs_test, y_pred)
import numpy as np
np.save("prenotebook_res/190219.npy", { "accuracy_score": score })

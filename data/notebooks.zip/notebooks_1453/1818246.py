import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

#importing required packages
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.svm import SVC
import sklearn
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

# In[None]

df1 = pd.read_csv('../input/Absenteeism_at_work.csv', delimiter=',')#dataset
features = df1.iloc[:, 1:14]#features used for training and testing
target = df1.iloc[:, 14]#values that has to be predicted
print("Missing Values: ",np.count_nonzero(features.isnull()))#checking for missing values

# In[None]

#converting to a numpy array
features = features.values
target = target.values

# f# r# o# m#  # s# k# l# e# a# r# n# .# d# e# c# o# m# p# o# s# i# t# i# o# n#  # i# m# p# o# r# t#  # P# C# A# <# b# r# ># 
# p# c# a#  # =#  # P# C# A# (# .# 9# 5# )# <# b# r# ># 
# p# c# a# .# f# i# t# (# f# _# t# r# a# i# n# )# <# b# r# ># 
# t# r# a# i# n# _# i# m# g#  # =#  # p# c# a# .# t# r# a# n# s# f# o# r# m# (# f# _# t# r# a# i# n# )# <# b# r# ># 
# t# e# s# t# _# i# m# g#  # =#  # p# c# a# .# t# r# a# n# s# f# o# r# m# (# f# _# t# e# s# t# )# <# b# r# ># 
# *# *# P# E# R# F# O# R# M# I# N# G#  # P# C# A#  # D# I# D# N# T#  # H# E# L# P#  # U# S#  # I# N# C# R# E# A# S# E#  # T# H# E#  # A# C# C# U# R# A# C# Y#  # S# O#  # W# E#  # D# I# D# N# T#  # I# N# C# L# U# D# E#  # I# T#  # I# N#  # O# U# R#  # T# E# C# H# N# I# Q# U# E# S# .# *# *

# In[None]

#dividing the dataset into training and testing in ratio 70%:30%
from sklearn.model_selection import train_test_split
f_train, f_test, t_train, t_test = train_test_split(features, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(f_train, t_train)
y_pred = model.predict(f_test)
score = accuracy_score(t_test, y_pred)
import numpy as np
np.save("prenotebook_res/1818246.npy", { "accuracy_score": score })

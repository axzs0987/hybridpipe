import pandas as pd
# ##  # I# B# M#  # H# R#  # A# n# a# l# y# t# i# c# s

# ## ##  # D# a# t# a# s# e# t# :#  # [# I# B# M#  # H# R#  # A# n# a# l# y# t# i# c# s#  # A# t# t# r# i# t# i# o# n#  # D# a# t# a# s# e# t# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# p# a# v# a# n# s# u# b# h# a# s# h# t# /# i# b# m# -# h# r# -# a# n# a# l# y# t# i# c# s# -# a# t# t# r# i# t# i# o# n# -# d# a# t# a# s# e# t# )

# ## ## ##  # I# m# p# o# r# t#  # a# l# l#  # t# h# e#  # n# e# c# e# s# s# a# r# y#  # h# e# a# d# e# r#  # f# i# l# e# s#  # a# s#  # f# o# l# l# o# w# s# :

# *# *# p# a# n# d# a# s# *# *#  # :#  # A# n#  # o# p# e# n#  # s# o# u# r# c# e#  # l# i# b# r# a# r# y#  # u# s# e# d#  # f# o# r#  # d# a# t# a#  # m# a# n# i# p# u# l# a# t# i# o# n# ,#  # c# l# e# a# n# i# n# g# ,#  # a# n# a# l# y# s# i# s#  # a# n# d#  # v# i# s# u# a# l# i# z# a# t# i# o# n# .#  # <# b# r# ># 
# *# *# n# u# m# p# y# *# *#  # :#  # A#  # l# i# b# r# a# r# y#  # u# s# e# d#  # t# o#  # m# a# n# i# p# u# l# a# t# e#  # m# u# l# t# i# -# d# i# m# e# n# s# i# o# n# a# l#  # d# a# t# a#  # i# n#  # t# h# e#  # f# o# r# m#  # o# f#  # n# u# m# p# y#  # a# r# r# a# y# s#  # w# i# t# h#  # u# s# e# f# u# l#  # i# n# -# b# u# i# l# t#  # f# u# n# c# t# i# o# n# s# .#  # <# b# r# ># 
# *# *# m# a# t# p# l# o# t# l# i# b# *# *#  # :#  # A#  # l# i# b# r# a# r# y#  # u# s# e# d#  # f# o# r#  # p# l# o# t# t# i# n# g#  # a# n# d#  # v# i# s# u# a# l# i# z# a# t# i# o# n#  # o# f#  # d# a# t# a# .#  # <# b# r# ># 
# *# *# s# e# a# b# o# r# n# *# *#  # :#  # A#  # l# i# b# r# a# r# y#  # b# a# s# e# d#  # o# n#  # m# a# t# p# l# o# t# l# i# b#  # w# h# i# c# h#  # i# s#  # u# s# e# d#  # f# o# r#  # p# l# o# t# t# i# n# g#  # o# f#  # d# a# t# a# .#  # <# b# r# ># 
# *# *# s# k# l# e# a# r# n# .# m# e# t# r# i# c# s# *# *#  # :#  # A#  # l# i# b# r# a# r# y#  # u# s# e# d#  # t# o#  # c# a# l# c# u# l# a# t# e#  # t# h# e#  # a# c# c# u# r# a# c# y# ,#  # p# r# e# c# i# s# i# o# n#  # a# n# d#  # r# e# c# a# l# l# .#  # <# b# r# ># 
# *# *# s# k# l# e# a# r# n# .# p# r# e# p# r# o# c# e# s# s# i# n# g# *# *#  # :#  # A#  # l# i# b# r# a# r# y#  # u# s# e# d#  # t# o#  # e# n# c# o# d# e#  # a# n# d#  # o# n# e# h# o# t# e# n# c# o# d# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# r# i# a# b# l# e# s# .#  # <# b# r# >

# In[None]

# Importing libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn import metrics

# ## ## ##  # R# e# a# d#  # t# h# e#  # d# a# t# a#  # f# r# o# m#  # t# h# e#  # d# a# t# a# s# e# t#  # u# s# i# n# g#  # t# h# e#  # r# e# a# d# _# c# s# v# (# )#  # f# u# n# c# t# i# o# n#  # f# r# o# m#  # t# h# e#  # p# a# n# d# a# s#  # l# i# b# r# a# r# y# .

# In[None]

# Importing the dataset
data = pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# ## ## ##  # I# n# s# p# e# c# t# i# n# g#  # a# n# d#  # c# l# e# a# n# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

# Printing the 1st 5 columns
data.head()

# In[None]

# Printing the dimenions of data
data.shape

# In[None]

# Viewing the column heading
data.columns

# In[None]

# Inspecting the target variable
data.Attrition.value_counts()

# In[None]

data.dtypes

# In[None]

# Identifying the unique number of values in the dataset
data.nunique()

# In[None]

# Checking if any NULL values are present in the dataset
data.isnull().sum()

# In[None]

# See rows with missing values
data[data.isnull().any(axis=1)]

# In[None]

# Viewing the data statistics
data.describe()

# In[None]

# Here the value for columns, Over18, StandardHours and EmployeeCount are same for all rows, we can eliminate these columns
data.drop(['EmployeeCount','StandardHours','Over18','EmployeeNumber'],axis=1, inplace=True)

# ## ## ##  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# In[None]

# Plotting a boxplot to study the distribution of features
fig,ax = plt.subplots(1,3, figsize=(20,5))               
plt.suptitle("Distribution of various factors", fontsize=20)
sns.boxplot(data['DailyRate'], ax = ax[0]) 
sns.boxplot(data['MonthlyIncome'], ax = ax[1]) 
sns.boxplot(data['DistanceFromHome'], ax = ax[2])  
plt.show()

# In[None]

# Finding out the correlation between the features
corr = data.corr()
corr.shape

# In[None]

# Plotting the heatmap of correlation between features
plt.figure(figsize=(20,20))
sns.heatmap(corr, cbar=True, square= True, fmt='.1f', annot=True, annot_kws={'size':15}, cmap='Greens')

# In[None]

# Check for multicollinearity using correlation plot
f,ax = plt.subplots(figsize=(10,10))
sns.heatmap(data[['DailyRate','HourlyRate','MonthlyIncome','MonthlyRate']].corr(), annot=True, linewidths=.5, fmt= '.1f',ax=ax)
plt.show()

# In[None]

# Plotting countplots for the categorical variables
fig,ax = plt.subplots(2,3, figsize=(20,20))            
plt.suptitle("Distribution of various factors", fontsize=20)
sns.countplot(data['Attrition'], ax = ax[0,0]) 
sns.countplot(data['BusinessTravel'], ax = ax[0,1]) 
sns.countplot(data['Department'], ax = ax[0,2]) 
sns.countplot(data['EducationField'], ax = ax[1,0])
sns.countplot(data['Gender'], ax = ax[1,1])  
sns.countplot(data['OverTime'], ax = ax[1,2]) 
plt.xticks(rotation=20)
plt.subplots_adjust(bottom=0.4)
plt.show()

# In[None]

# Combine levels in a categorical variable by seeing their distribution
JobRoleCrossTab = pd.crosstab(data['JobRole'], data['Attrition'], margins=True)
JobRoleCrossTab

# In[None]

JobRoleCrossTab.div(JobRoleCrossTab["All"], axis=0)

# In[None]

# Combining job roles with high similarities together
data['JobRole'].replace(['Human Resources','Laboratory Technician'],value= 'HR-LT',inplace = True)
data['JobRole'].replace(['Research Scientist','Sales Executive'],value= 'RS-SE',inplace = True)
data['JobRole'].replace(['Healthcare Representative','Manufacturing Director'],value= 'HE-MD',inplace = True)

# In[None]

# Encoding Yes / No values in Attrition column to 1 / 0
data.Attrition.replace(["Yes","No"],[1,0],inplace=True)
data.head()

# In[None]

# One hot encoding for categorical variables
final_data = pd.get_dummies(data)
final_data.head().T

# In[None]

final_data.shape

# ## ## ## ##  # O# n# c# e#  # t# h# e#  # d# a# t# a#  # i# s#  # c# l# e# a# n# e# d# ,#  # w# e#  # s# p# l# i# t#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n# i# n# g#  # s# e# t#  # a# n# d#  # t# e# s# t#  # s# e# t#  # t# o#  # p# r# e# p# a# r# e#  # i# t#  # f# o# r#  # o# u# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l#  # i# n#  # a#  # s# u# i# t# a# b# l# e#  # p# r# o# p# o# r# t# i# o# n# .

# In[None]

# Spliting target variable and independent variables
X = final_data.drop(['Attrition'], axis = 1)
y = final_data['Attrition']

# In[None]

# Splitting the data into training set and testset
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3045538.npy", { "accuracy_score": score })

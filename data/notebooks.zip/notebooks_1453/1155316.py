import pandas as pd
# In[2]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt


# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[5]

### importing the dataset
dataset = pd.read_csv("../input/Social_Network_Ads.csv")
X = dataset.iloc[:, [2, 3]].values
y = dataset.iloc[:, 4].values

# ## s# p# l# i# t# t# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# h# e#  # t# r# a# i# n# i# n# g#  # s# e# t#  # a# n# d#  # t# e# s# t#  # s# e# t# 
# f# r# o# m#  # s# k# l# e# a# r# n# .# c# r# o# s# s# _# v# a# l# i# d# a# t# i# o# n#  # i# m# p# o# r# t#  # t# r# a# i# n# _# t# e# s# t# _# s# p# l# i# t# 
# X# _# t# r# a# i# n# ,#  # X# _# t# e# s# t# ,#  # y# _# t# r# a# i# n# ,#  # y# _# t# e# s# t#  # =#  # t# r# a# i# n# _# t# e# s# t# _# s# p# l# i# t# (# X# ,#  # y# ,#  # t# e# s# t# _# s# i# z# e#  # =#  # 0# .# 2# 5# ,#  # r# a# n# d# o# m# _# s# t# a# t# e#  # =#  # 0# )

# In[6]

#splitting the dataset into the training set and test set
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1155316.npy", { "accuracy_score": score })

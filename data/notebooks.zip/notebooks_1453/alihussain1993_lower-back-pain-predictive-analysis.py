import pandas as pd
df = pd.read_csv('../input/Dataset_spine.csv',                 usecols=['Col1','Col2','Col3','Col4','Col5','Col6','Col7',                          'Col8','Col9','Col10','Col11','Col12','Class_att'])
df.columns = ['pelvic_incidence','pelvic_tilt','lumbar_lordosis_angle',              'sacral_slope','pelvic_radius','degree_spondylolisthesis',              'pelvic_slope','Direct_tilt','thoracic_slope','cervical_tilt',              'sacrum_angle','scoliosis_slope','Class_att']
df.describe()
df[df['degree_spondylolisthesis']>400]
clean_df = df.drop(115,0)
clean_df.describe()
features = clean_df.drop('Class_att', axis=1)
target = clean_df['Class_att']
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
logicModel = LogisticRegression()
#logicModelFit = logicModel.fit(X_train, y_train)
#logicModelPred = logicModelFit.predict(X_test)
#logicModelPredScore = accuracy_score(y_test,logicModelPred)
#print("Logistic Regression proves to be", logicModelPredScore*100, "% accurate here!")
from sklearn import svm
svmModel = svm.SVC(kernel='linear')
#svmModelFit = svmModel.fit(X_train, y_train)
#svmModelFitPred = svmModel.predict(X_test)
#svmModelPredScore = accuracy_score(y_test, svmModelFitPred)
#print("Support Vector Machines proves to be", svmModelPredScore*100, "% accurate here!")




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alihussain1993_lower-back-pain-predictive-analysis.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alihussain1993_lower-back-pain-predictive-analysis/testY.csv",encoding="gbk")


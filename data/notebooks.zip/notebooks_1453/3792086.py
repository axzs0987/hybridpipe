import pandas as pd
# ## ##  #  # <# f# o# n# t#  # c# o# l# o# r# =# s# e# a# b# l# u# e# >#  # I# n#  # t# h# i# s#  # p# r# o# j# e# c# t#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # f# i# n# d#  # o# u# t#  # w# h# y#  # a#  # c# u# s# t# o# m# e# r#  # i# s#  # l# e# a# v# i# n# g#  # c# o# m# p# a# n# y#  # p# r# o# d# u# c# t# s#  # a# n# d#  # w# h# a# t#  # a# r# e#  # f# a# c# t# o# r# s#  # l# e# a# d# i# n# g#  # c# u# s# t# o# m# e# r# s#  # t# o#  # c# h# u# r# n# .#  # A# n# d#  # i# s#  # t# h# e# r# e#  # a#  # w# a# y#  # w# e#  # c# a# n#  # a# d# d#  # m# o# r# e#  # c# u# s# t# o# m# e# r#  # o# r#  # s# t# o# p#  # c# u# s# t# o# m# e# r# s#  # f# r# o# m#  # c# h# u# r# i# n# g# .#  # L# e# t# s#  # f# i# n# d#  # o# u# t# .# <# /# f# o# n# t# >

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

data=pd.read_csv("../input/WA_Fn-UseC_-Telco-Customer-Churn.csv")

# In[None]

data.head()

# ## ## ##  # <# f# o# n# t#  # c# o# l# o# r# =# s# e# a# b# l# u# e# >#  # A# s#  # i#  # t# h# i# n# k#  # w# e#  # s# h# o# u# l# d#  # d# r# o# p#  # c# u# s# t# o# m# e# r# I# D#  # a# s#  # i# t#  # n# o# t#  # g# o# i# n# g#  # t# o#  # h# e# l# p#  # u# s# .# <# /# f# o# n# t# >

# In[None]

data.drop('customerID',axis=1, inplace=True)

# In[None]

data.head()

# ## ## ##  # l# e# t# s#  # l# o# o# k#  # i# n# s# i# g# h# t#  # o# f#  # o# u# r#  # d# a# t# a# .# 
# *#  # f# r# o# m#  # t# e# n# u# r# e#  # c# o# l# u# m# n#  # w# e#  # c# a# n#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # 0#  # m# i# n# i# m# u# m#  # v# a# l# u# e#  # w# h# i# c# h#  # i# s#  # n# o# t#  # g# o# o# d#  # a# s#  # i# t#  # l# e# a# d#  # t# o#  # 0#  # T# o# t# a# l#  # c# h# a# r# e# g# e# s# .#  # A# n# d#  # m# a# x# i# m# u# m#  # t# e# n# u# r# e#  # i# s#  # o# f#  # 7# 2#  # m# o# n# t# h# s#  # a# k# a#  # 6#  # y# e# a# r# s# .

# In[None]

data.describe()

# In[None]

data.shape

# In[None]

data.info()

# ## ## ##  # f# r# o# m#  # o# v# e# r#  # 2# 0#  # c# o# l# u# m# n# s#  # o# n# l# y#  # 3#  # a# r# e#  # h# a# v# i# n# g#  # n# u# m# e# r# i# c# a# l#  # v# a# l# u# e# s# .

# In[None]

data.isnull().sum()

# ## ## ##  # b# u# t#  # h# e# r# e#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # i# s#  # n# o# t#  # s# h# o# w# i# n# g#  # a# n# y#  # n# u# l# l#  # v# a# l# u# e# s# .#  # L# e# t#  # c# o# n# v# e# r# t#  # i# t#  # i# n# t# o#  # i# n# t# e# g# e# r#  # v# a# l# u# e#  # f# r# o# m#  # o# b# j# e# c# t#  # v# a# l# u# e#  # f# i# r# s# t# .

# In[None]

data.TotalCharges= pd.to_numeric(data.TotalCharges, errors='coerce')
data.info()
data.isnull().sum()

# ## ## ##  # A# h# h#  # n# o# w#  # w# e#  # c# a# n#  # s# e# e#  # n# u# l# l#  # v# a# l# u# e# s#  # a# n# d#  # i# t# s#  # o# n# l# y#  # 1# 1# .#  # W# e#  # c# a# n#  # d# e# l# e# t# e#  # t# h# e# m#  # a# s#  # t# h# e# y#  # a# r# e#  # n# e# g# l# i# g# i# b# l# e

# In[None]

data.dropna(inplace=True)
data.info()

# ## ## ##  # <# f# o# n# t#  # c# o# l# o# r# =# s# e# a# b# l# u# e# >#  # D# a# t# a#  # V# i# s# u# a# l# i# s# a# t# i# o# n#  # <# /# f# o# n# t# >

# In[None]

import seaborn as sns
import matplotlib.pyplot as plt

sns.countplot(x='Churn', data=data)

# ## ## ##  # T# h# e# r# e#  # a# r# e#  # l# e# s# s#  # c# u# s# t# o# m# e# r# s#  # c# h# u# r# i# n# g# .#  # B# u# t#  # w# e#  # h# a# v# e#  # t# o#  # f# i# n# d# o# u# t#  # w# h# y#  # t# h# e# r# e#  # i# s#  # c# h# u# r# i# n# g# ?# ?#  # A# r# e#  # t# h# e# y#  # n# o# t#  # h# a# p# p# y#  # w# i# t# h#  # c# o# m# p# a# n# y#  # p# o# l# i# c# i# e# s# .#  # L# e# t# s#  # d# i# g#  # s# o# m# e#  # m# o# r# e# .

# In[None]

sns.countplot(x="Churn",hue="Contract", data=data)

# ## ## ##  # M# o# n# t# h# -# t# o# -# m# o# n# t# h#  # c# u# s# t# o# m# e# r#  # a# r# e#  # m# o# r# e#  # p# r# o# n# e#  # t# o#  # c# h# u# r# n# .# 
# *#  # ## ## ## ##  #  #  # c# o# m# p# a# n# y#  # s# h# o# u# l# d#  # i# n# t# r# o# d# u# c# e# s#  # s# o# m# e#  # p# l# a# n# e# s#  # w# h# i# c# h#  # c# a# n#  # a# t# t# r# a# c# t#  # m# o# r# e#  # m# o# n# t# h# l# y#  # b# a# s# e#  # c# u# s# t# o# m# e# r# s#  # o# r#  # m# a# k# e#  # y# e# a# r# l# y#  # p# l# a# n#  # m# o# r# e#  # a# t# t# r# a# a# c# t# i# v# e#  # t# o#  # l# u# r# e#  # m# o# r# e#  # c# u# s# t# o# m# e# r# s# .

# In[None]

sns.countplot(x='Churn',hue='gender', data=data)

# ## ## ##  # M# a# l# e#  # v# s#  # F# e# m# a# l# e#  # i# s#  # a# l# m# o# s# t#  # s# a# m# e#  # f# o# r#  # c# h# u# r# n#  # c# u# s# t# o# m# e# r# s# .

# In[None]

sns.countplot(x='Churn',hue='SeniorCitizen', data=data)

# ## ## ##  # S# e# n# i# o# r#  # C# i# t# i# z# e# n#  # a# r# e#  # l# e# s# s#  # l# i# k# e# l# y#  # t# o#  # c# h# u# r# n

# In[None]

sns.countplot(x='Churn',hue='Partner', data=data)

# ## ## ##  # C# u# s# t# o# m# e# r#  # h# a# v# i# n# g#  # n# o#  # p# a# r# t# n# e# r#  # a# r# e#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # c# h# u# r# n# .

# In[None]

def tenure_m(data) :
    
    if data["tenure"] <= 12 :
        return "Tenure_0-12"
    elif (data["tenure"] > 12) & (data["tenure"] <= 24 ):
        return "Tenure_12-24"
    elif (data["tenure"] > 24) & (data["tenure"] <= 48) :
        return "Tenure_24-48"
    elif (data["tenure"] > 48) & (data["tenure"] <= 60) :
        return "Tenure_48-60"
    elif data["tenure"] > 60 :
        return "Tenure_gt_60"

data["tenure_group"] = data.apply(lambda data:tenure_m(data),
                                      axis = 1)


# In[None]

sns.set(style='darkgrid')
sns.countplot(x='Churn',hue='tenure_group', data=data)

# ## ## ##  # C# u# s# t# o# m# e# r#  # f# r# o# m#  # 0#  # t# o#  # 1# 2#  # m# o# n# t# h# s#  # t# e# n# u# r# e#  # a# r# e#  # m# o# s# t#  # l# i# k# e# l# y#  # t# o#  # c# h# u# r# n# .

# In[None]

sns.countplot(x='Churn', hue='Dependents', data=data)

# In[None]

sns.countplot(x="Churn",hue="PhoneService", data=data)

# In[None]

sns.countplot(x="Churn",hue="MultipleLines", data=data)

# In[None]

sns.countplot(x="Churn",hue="InternetService", data=data)

# In[None]

sns.countplot(x="Churn",hue="OnlineSecurity", data=data)

# In[None]

sns.countplot(x="Churn",hue="OnlineBackup", data=data)

# In[None]

sns.countplot(x="Churn",hue="DeviceProtection", data=data)

# ## ## ##  # N# o# w#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # p# r# e# p# a# r# e#  # d# a# t# a#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # b# e# c# a# u# s# e#  # o# u# r#  # d# a# t# a#  # s# t# i# l# l#  # c# o# n# t# a# i# n#  # o# b# j# e# c# t#  # v# a# l# u# e# s#  # a# n# d#  # w# e#  # h# a# v# e#  # t# o#  # c# o# n# v# e# r# t#  # t# h# e# m#  # i# n# t# o#  # i# n# t# e# g# e# r# .

# In[None]

columns_to_convert = ['Partner', 
                      'Dependents', 
                      'PhoneService', 
                      'MultipleLines',
                      'OnlineSecurity',
                      'OnlineBackup',
                      'DeviceProtection',
                      'TechSupport',
                      'StreamingTV',
                      'StreamingMovies',
                      'PaperlessBilling', 
                      'Churn']

for item in columns_to_convert:
    data[item] = [1 if each == "Yes" else 0 if each == "No" else 2 for each in data[item]]
    
data.head()

# In[None]

data.drop('tenure',axis=1, inplace=True)

# In[None]

data['gender']=data['gender'].replace({'Male':1,'Female':0},)
data['Contract']=data['Contract'].replace({'Month-to-month':0,'One year':1,'Two year':2})
data['InternetService']=data['InternetService'].replace({'DSL':1,'Fiber optic':2,'No':0})
data['PaymentMethod']=data['PaymentMethod'].replace({'Electronic check':0,'Mailed check':1,'Bank transfer (automatic)':2,'Credit card (automatic)':3})
data['tenure_group']=data['tenure_group'].replace({'Tenure_0-12':0,'Tenure_12-24':1,'Tenure_24-48':2,'Tenure_48-60':3,'Tenure_gt_60':4})

# In[None]

data.info()
data.head()

# ## ##  # <# f# o# n# t#  # c# o# l# o# r# =# s# e# a# b# l# u# e# >#  # I# t# '# s#  # l# o# o# k#  # l# i# k# e#  # o# u# r#  # d# a# t# a#  # i# s#  # c# l# e# a# n#  # i# s#  # r# e# a# d# y#  # t# o#  # u# s# e#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g# .#  # <# /# f# o# n# t# ># 
# *#  # ## ## ##  # A# s#  # i# t#  # l# o# o# k#  # l# i# k# e#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m#  # s# o#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # u# s# e# :# 
# *#  # ## ## ## ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# 
# *#  # ## ## ## ##  # D# e# c# i# s# i# o# n# T# r# e# e# C# l# a# s# s# i# f# i# e# r# 
# *#  # ## ## ## ##  # R# a# n# d# o# m# F# o# r# e# s# t# C# l# a# s# s# i# f# i# e# r# 
# *#  # ## ## ## ##  # K# N# e# i# g# h# b# o# r# s# C# l# a# s# s# i# f# i# e# r

# In[None]

data.isnull().sum()

# In[None]

y = data['Churn']


# In[None]

new = data.drop('Churn', axis=1)
x = new




# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3792086.npy", { "accuracy_score": score })

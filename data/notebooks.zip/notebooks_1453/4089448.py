import pandas as pd
# In[1]

import pandas as pd
import numpy as np

# In[2]

data = pd.read_csv("../input/winequality-red.csv")

data.head()

# In[3]

data.isnull().sum()

# In[4]

data.corr()

# In[5]

list(data)

# In[6]

x = data[['fixed acidity',
 'volatile acidity',
 'citric acid',
 'chlorides',
 'total sulfur dioxide',
 'density',
 'sulphates',
 'alcohol']]

y = data['quality']

# In[7]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4089448.npy", { "accuracy_score": score })

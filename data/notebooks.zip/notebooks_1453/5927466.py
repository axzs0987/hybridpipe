import pandas as pd
# ##  # B# a# n# k#  # m# a# r# k# e# t# i# n# g#  # c# a# m# p# a# i# g# n# s#  # d# a# t# a# s# e# t#  # a# n# a# l# y# s# i# s# 
# 
# ## ##  # A# b# s# t# r# a# c# t# 
# 
# T# h# i# s#  # i# s#  # d# a# t# a# s# e# t#  # t# h# a# t#  # d# e# s# c# r# i# b# e#  # P# o# r# t# u# g# a# l#  # b# a# n# k#  # m# a# r# k# e# t# i# n# g#  # c# a# m# p# a# i# g# n# s#  # r# e# s# u# l# t# s# .#  # C# o# n# d# u# c# t# e# d#  # c# a# m# p# a# i# g# n# s#  # w# e# r# e#  # b# a# s# e# d#  # m# o# s# t# l# y#  # o# n#  # d# i# r# e# c# t#  # p# h# o# n# e#  # c# a# l# l# s# ,#  # o# f# f# e# r# i# n# g#  # b# a# n# k# '# s#  # c# l# i# e# n# t# s#  # t# o#  # p# l# a# c# e#  # a#  # t# e# r# m#  # d# e# p# o# s# i# t# .#  # I# f#  # a# f# t# e# r#  # a# l# l#  # m# a# r# k# i# n# g#  # a# f# f# o# r# t# s#  # c# l# i# e# n# t#  # h# a# d#  # a# g# r# e# e# d#  # t# o#  # p# l# a# c# e#  # d# e# p# o# s# i# t#  # -#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # m# a# r# k# e# d#  # '# y# e# s# '# ,#  # o# t# h# e# r# w# i# s# e#  # '# n# o# '# .# 
# 
# S# o# u# r# s# e#  # o# f#  # t# h# e#  # d# a# t# a#  # h# t# t# p# s# :# /# /# a# r# c# h# i# v# e# .# i# c# s# .# u# c# i# .# e# d# u# /# m# l# /# d# a# t# a# s# e# t# s# /# b# a# n# k# +# m# a# r# k# e# t# i# n# g# 
# 
# D# a# t# a# s# e# t#  # d# e# s# c# r# i# p# t# i# o# n#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# v# o# l# o# d# y# m# y# r# g# a# v# r# y# s# h# /# b# a# n# k# -# m# a# r# k# e# t# i# n# g# -# c# a# m# p# a# i# g# n# s# -# d# a# t# a# -# s# e# t# -# d# e# s# c# r# i# p# t# i# o# n# 
# 
# 
# ## ##  # C# i# t# a# t# i# o# n#  # R# e# q# u# e# s# t# :# 
# 
# T# h# i# s#  # d# a# t# a# s# e# t#  # i# s#  # p# u# b# l# i# c#  # a# v# a# i# l# a# b# l# e#  # f# o# r#  # r# e# s# e# a# r# c# h# .#  # T# h# e#  # d# e# t# a# i# l# s#  # a# r# e#  # d# e# s# c# r# i# b# e# d#  # i# n#  # S# .#  # M# o# r# o# ,#  # P# .#  # C# o# r# t# e# z#  # a# n# d#  # P# .#  # R# i# t# a# .#  # "# A#  # D# a# t# a# -# D# r# i# v# e# n#  # A# p# p# r# o# a# c# h#  # t# o#  # P# r# e# d# i# c# t#  # t# h# e#  # S# u# c# c# e# s# s#  # o# f#  # B# a# n# k#  # T# e# l# e# m# a# r# k# e# t# i# n# g# .# "#  # D# e# c# i# s# i# o# n#  # S# u# p# p# o# r# t#  # S# y# s# t# e# m# s# ,#  # E# l# s# e# v# i# e# r# ,#  # 6# 2# :# 2# 2# -# 3# 1# ,#  # J# u# n# e#  # 2# 0# 1# 4#  # <# 
# 
# ## ##  # T# a# s# k# 
# p# r# e# d# i# c# t# i# n# g#  # t# h# e#  # f# u# t# u# r# e#  # r# e# s# u# l# t# s#  # o# f#  # m# a# r# k# e# t# i# n# g#  # c# o# m# p# a# n# i# e# s#  # b# a# s# e# d#  # o# n#  # a# v# a# i# l# a# b# l# e#  # s# t# a# t# i# s# t# i# c# s#  # a# n# d# ,#  # a# c# c# o# r# d# i# n# g# l# y# ,#  # f# o# r# m# u# l# a# t# i# n# g#  # r# e# c# o# m# m# e# n# d# a# t# i# o# n# s#  # f# o# r#  # s# u# c# h#  # c# o# m# p# a# n# i# e# s#  # i# n#  # t# h# e#  # f# u# t# u# r# e# .# 
# b# u# i# l# d# i# n# g#  # a#  # p# r# o# f# i# l# e#  # o# f#  # a#  # c# o# n# s# u# m# e# r#  # o# f#  # b# a# n# k# i# n# g#  # s# e# r# v# i# c# e# s#  # (# d# e# p# o# s# i# t# s# )# .# 
# A# p# p# r# o# a# c# h# 
# ## ##  # T# h# e#  # f# o# l# l# o# w# i# n# g#  # s# t# e# p# s#  # w# i# l# l#  # b# e#  # p# e# r# f# o# r# m# e# d#  # t# o#  # c# o# m# p# l# e# t# e#  # t# h# e#  # t# a# s# k# :# 
# 
# 1# .#  # L# o# a# d# i# n# g#  # d# a# t# a#  # a# n# d#  # h# o# l# d# i# n# g# 
# 2# .#  # E# x# p# a# n# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # (# E# D# A# )# .# 
# 2# .#  # F# o# r# m# u# l# a# t# i# n# g#  # h# y# p# o# t# h# e# s# e# s#  # r# e# g# a# r# d# i# n# g#  # i# n# d# i# v# i# d# u# a# l#  # f# a# c# t# o# r# s#  # (# f# e# a# t# u# r# e# s# )#  # f# o# r#  # c# o# n# d# u# c# t# i# n# g#  # c# o# r# r# e# c# t#  # d# a# t# a#  # c# l# e# a# r# i# n# i# n# g#  # a# n# d#  # d# a# t# a#  # p# r# e# p# a# r# a# t# i# o# n#  # f# o# r#  # m# o# d# e# l# i# n# g# .# 
# 3# .#  # T# h# e#  # c# h# o# i# c# e#  # o# f#  # m# e# t# r# i# c# s#  # r# e# s# u# l# t# .# 
# 4# .#  # B# u# i# l# d# i# n# g#  # m# o# d# e# l# s# 
# 5# .#  # T# h# e#  # c# h# o# i# c# e#  # o# f#  # t# h# e#  # m# o# s# t#  # e# f# f# e# c# t# i# v# e#  # m# o# d# e# l# 
# 6# .#  # C# o# n# c# l# u# s# i# o# n# s#  # a# n# d#  # r# e# c# o# m# e# n# d# a# t# i# o# n# s# .

# ##  # 1# .#  # L# o# a# d# i# n# g#  # d# a# t# a

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
sns.set(style='whitegrid', palette='muted', font_scale=1.5)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

MAIN_PATH = '../input/'
df = pd.read_csv('../input/bank-marketing-dataset/bank.csv')
# term_deposits = df.copy()
# Have a grasp of how our data looks.
df.head()


# In[None]

df.describe()


# >#  # *# *# I# n# p# u# t#  # v# a# r# i# a# b# l# e# s# :# *# *# 
# *#  # B# a# n# k#  # C# l# i# e# n# t#  # D# a# t# a# :# 
# 1# .#  # 1#  # -#  # a# g# e#  # (# n# u# m# e# r# i# c# )# 
# 1# .#  # 2#  # -#  # j# o# b#  # :#  # t# y# p# e#  # o# f#  # j# o# b#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# a# d# m# i# n# .# '# ,# '# b# l# u# e# -# c# o# l# l# a# r# '# ,# '# e# n# t# r# e# p# r# e# n# e# u# r# '# ,# '# h# o# u# s# e# m# a# i# d# '# ,# '# m# a# n# a# g# e# m# e# n# t# '# ,# '# r# e# t# i# r# e# d# '# ,# '# s# e# l# f# -# e# m# p# l# o# y# e# d# '# ,# '# s# e# r# v# i# c# e# s# '# ,# '# s# t# u# d# e# n# t# '# ,# '# t# e# c# h# n# i# c# i# a# n# '# ,# '# u# n# e# m# p# l# o# y# e# d# '# ,# '# u# n# k# n# o# w# n# '# )# 
# 1# .#  # 3#  # -#  # m# a# r# i# t# a# l#  # :#  # m# a# r# i# t# a# l#  # s# t# a# t# u# s#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# d# i# v# o# r# c# e# d# '# ,# '# m# a# r# r# i# e# d# '# ,# '# s# i# n# g# l# e# '# ,# '# u# n# k# n# o# w# n# '# ;#  # n# o# t# e# :#  # '# d# i# v# o# r# c# e# d# '#  # m# e# a# n# s#  # d# i# v# o# r# c# e# d#  # o# r#  # w# i# d# o# w# e# d# )# 
# 1# .#  # 4#  # -#  # e# d# u# c# a# t# i# o# n#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# b# a# s# i# c# .# 4# y# '# ,# '# b# a# s# i# c# .# 6# y# '# ,# '# b# a# s# i# c# .# 9# y# '# ,# '# h# i# g# h# .# s# c# h# o# o# l# '# ,# '# i# l# l# i# t# e# r# a# t# e# '# ,# '# p# r# o# f# e# s# s# i# o# n# a# l# .# c# o# u# r# s# e# '# ,# '# u# n# i# v# e# r# s# i# t# y# .# d# e# g# r# e# e# '# ,# '# u# n# k# n# o# w# n# '# )# 
# 1# .#  # 5#  # -#  # d# e# f# a# u# l# t# :#  # h# a# s#  # c# r# e# d# i# t#  # i# n#  # d# e# f# a# u# l# t# ?#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# n# o# '# ,# '# y# e# s# '# ,# '# u# n# k# n# o# w# n# '# )# 
# 1# .#  # 6#  # -#  # h# o# u# s# i# n# g# :#  # h# a# s#  # h# o# u# s# i# n# g#  # l# o# a# n# ?#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# n# o# '# ,# '# y# e# s# '# ,# '# u# n# k# n# o# w# n# '# )# 
# 1# .#  # 7#  # -#  # l# o# a# n# :#  # h# a# s#  # p# e# r# s# o# n# a# l#  # l# o# a# n# ?#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# n# o# '# ,# '# y# e# s# '# ,# '# u# n# k# n# o# w# n# '# )# 
# *#  # L# a# s# t#  # c# o# n# t# a# c# t#  # i# n# f# o# r# m# a# t# i# n# :# 
# 1# .#  # 8#  # -#  # c# o# n# t# a# c# t# :#  # c# o# n# t# a# c# t#  # c# o# m# m# u# n# i# c# a# t# i# o# n#  # t# y# p# e#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# c# e# l# l# u# l# a# r# '# ,# '# t# e# l# e# p# h# o# n# e# '# )# 
# 1# .#  # 9#  # -#  # m# o# n# t# h# :#  # l# a# s# t#  # c# o# n# t# a# c# t#  # m# o# n# t# h#  # o# f#  # y# e# a# r#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# j# a# n# '# ,#  # '# f# e# b# '# ,#  # '# m# a# r# '# ,#  # .# .# .# ,#  # '# n# o# v# '# ,#  # '# d# e# c# '# )# 
# 1# .#  # 1# 0#  # -#  # d# a# y# _# o# f# _# w# e# e# k# :#  # l# a# s# t#  # c# o# n# t# a# c# t#  # d# a# y#  # o# f#  # t# h# e#  # w# e# e# k#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# m# o# n# '# ,# '# t# u# e# '# ,# '# w# e# d# '# ,# '# t# h# u# '# ,# '# f# r# i# '# )# 
# 1# .#  # 1# 1#  # -#  # d# u# r# a# t# i# o# n# :#  # l# a# s# t#  # c# o# n# t# a# c# t#  # d# u# r# a# t# i# o# n# ,#  # i# n#  # s# e# c# o# n# d# s#  # (# n# u# m# e# r# i# c# )# .#  # I# m# p# o# r# t# a# n# t#  # n# o# t# e# :#  # t# h# i# s#  # a# t# t# r# i# b# u# t# e#  # h# i# g# h# l# y#  # a# f# f# e# c# t# s#  # t# h# e#  # o# u# t# p# u# t#  # t# a# r# g# e# t#  # (# e# .# g# .# ,#  # i# f#  # d# u# r# a# t# i# o# n# =# 0#  # t# h# e# n#  # y# =# '# n# o# '# )# .#  # Y# e# t# ,#  # t# h# e#  # d# u# r# a# t# i# o# n#  # i# s#  # n# o# t#  # k# n# o# w# n#  # b# e# f# o# r# e#  # a#  # c# a# l# l#  # i# s#  # p# e# r# f# o# r# m# e# d# .#  # A# l# s# o# ,#  # a# f# t# e# r#  # t# h# e#  # e# n# d#  # o# f#  # t# h# e#  # c# a# l# l#  # y#  # i# s#  # o# b# v# i# o# u# s# l# y#  # k# n# o# w# n# .#  # T# h# u# s# ,#  # t# h# i# s#  # i# n# p# u# t#  # s# h# o# u# l# d#  # o# n# l# y#  # b# e#  # i# n# c# l# u# d# e# d#  # f# o# r#  # b# e# n# c# h# m# a# r# k#  # p# u# r# p# o# s# e# s#  # a# n# d#  # s# h# o# u# l# d#  # b# e#  # d# i# s# c# a# r# d# e# d#  # i# f#  # t# h# e#  # i# n# t# e# n# t# i# o# n#  # i# s#  # t# o#  # h# a# v# e#  # a#  # r# e# a# l# i# s# t# i# c#  # p# r# e# d# i# c# t# i# v# e#  # m# o# d# e# l# .# 
# *#  # ##  # o# t# h# e# r#  # a# t# t# r# i# b# u# t# e# s# :# 
# 1# .#  # 1# 2#  # -#  # c# a# m# p# a# i# g# n# :#  # n# u# m# b# e# r#  # o# f#  # c# o# n# t# a# c# t# s#  # p# e# r# f# o# r# m# e# d#  # d# u# r# i# n# g#  # t# h# i# s#  # c# a# m# p# a# i# g# n#  # a# n# d#  # f# o# r#  # t# h# i# s#  # c# l# i# e# n# t#  # (# n# u# m# e# r# i# c# ,#  # i# n# c# l# u# d# e# s#  # l# a# s# t#  # c# o# n# t# a# c# t# )# 
# 1# .#  # 1# 3#  # -#  # p# d# a# y# s# :#  # n# u# m# b# e# r#  # o# f#  # d# a# y# s#  # t# h# a# t#  # p# a# s# s# e# d#  # b# y#  # a# f# t# e# r#  # t# h# e#  # c# l# i# e# n# t#  # w# a# s#  # l# a# s# t#  # c# o# n# t# a# c# t# e# d#  # f# r# o# m#  # a#  # p# r# e# v# i# o# u# s#  # c# a# m# p# a# i# g# n#  # (# n# u# m# e# r# i# c# ;#  # 9# 9# 9#  # m# e# a# n# s#  # c# l# i# e# n# t#  # w# a# s#  # n# o# t#  # p# r# e# v# i# o# u# s# l# y#  # c# o# n# t# a# c# t# e# d# )# 
# 1# .#  # 1# 4#  # -#  # p# r# e# v# i# o# u# s# :#  # n# u# m# b# e# r#  # o# f#  # c# o# n# t# a# c# t# s#  # p# e# r# f# o# r# m# e# d#  # b# e# f# o# r# e#  # t# h# i# s#  # c# a# m# p# a# i# g# n#  # a# n# d#  # f# o# r#  # t# h# i# s#  # c# l# i# e# n# t#  # (# n# u# m# e# r# i# c# )# 
# 1# .#  # 1# 5#  # -#  # p# o# u# t# c# o# m# e# :#  # o# u# t# c# o# m# e#  # o# f#  # t# h# e#  # p# r# e# v# i# o# u# s#  # m# a# r# k# e# t# i# n# g#  # c# a# m# p# a# i# g# n#  # (# c# a# t# e# g# o# r# i# c# a# l# :#  # '# f# a# i# l# u# r# e# '# ,# '# n# o# n# e# x# i# s# t# e# n# t# '# ,# '# s# u# c# c# e# s# s# '# )# 
# 
# *#  # O# u# t# p# u# t#  # v# a# r# i# a# b# l# e#  # (# d# e# s# i# r# e# d#  # t# a# r# g# e# t# )# :# 
# 1# .#  # 2# 1#  # -#  # d# e# p# o# s# i# t#  # /#  # y#  # -#  # h# a# s#  # t# h# e#  # c# l# i# e# n# t#  # s# u# b# s# c# r# i# b# e# d#  # a#  # t# e# r# m#  # d# e# p# o# s# i# t# ?#  # (# b# i# n# a# r# y# :#  # '# y# e# s# '# ,# '# n# o# '# )

# ##  # 2# .#  # E# x# p# l# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# In[None]

df['y'] = df['deposit']

# In[None]

# Build a function to show categorical values disribution
def plot_bar(column):
    # temp df 
    temp_1 = pd.DataFrame()
    # count categorical values
    temp_1['No_deposit'] = df[df['y'] == 'no'][column].value_counts()
    temp_1['Yes_deposit'] = df[df['y'] == 'yes'][column].value_counts()
    temp_1.plot(kind='bar')
    plt.xlabel(f'{column}')
    plt.ylabel('Number of clients')
    plt.title('Distribution of {} and deposit'.format(column))
    plt.show();

# In[None]

# Build a function to show categorical values disribution
def plot_bar_stacked(column):
    # temp df 
    temp_1 = pd.DataFrame()
    # count categorical values
    temp_1['Open Deposit'] = df[df['y'] == 'yes'][column].value_counts()/(df[column].value_counts())
    temp_1.plot(kind='bar')
    plt.xlabel(f'{column}')
    plt.ylabel('Reponse Rate %')
    plt.title('Reponse Rate on offer'.format(column))
    plt.show();

# In[None]

plot_bar('job'), plot_bar_stacked('job')

# In[None]

plot_bar('marital'), plot_bar_stacked('marital')

# In[None]

plot_bar('education'), plot_bar_stacked('education')

# In[None]

plot_bar('contact'), plot_bar_stacked('contact')

# In[None]

plot_bar('poutcome'), plot_bar_stacked('poutcome')

# In[None]

plot_bar('loan'), plot_bar_stacked('loan')

# In[None]

plot_bar('housing'), plot_bar_stacked('housing')

# In[None]

plot_bar('contact'), plot_bar_stacked('contact')

# In[None]

# Convert target variable into numeric
df.y = df.y.map({'no':0, 'yes':1}).astype('uint8')

# In[None]

df.describe()

# In[None]

# Build correlation matrix
corr = df.corr()
corr.style.background_gradient(cmap='PuBu')

# 
# 


# ##  # 3# .#  # D# A# T# A#  # P# R# E# P# A# R# I# N# G

# ## ##  # 3# .# 1#  # N# u# l# l#  # i#  # N# A# N#  # c# h# e# c# k# i# n# g

# In[None]

#Verifying null values
sns.heatmap(df.isnull(), yticklabels=False, cbar=False, cmap='viridis')

# In[None]

df.isna().any()

# In[None]

df.isna().sum()

# ## ##  #  # 3# .# 2#  # C# R# E# A# T# I# N# G#  # A# N# D#  # F# O# R# M# A# T# I# N# G#  # D# A# T# A

# In[None]

# Replacing values with binary ()
df.contact = df.contact.map({'cellular': 1, 'telephone': 0, 'unknown':0}).astype('uint8') #0 will means other
df.loan = df.loan.map({'yes': 1, 'unknown': 0, 'no' : 0}).astype('uint8')
df.housing = df.housing.map({'yes': 1, 'unknown': 0, 'no' : 0}).astype('uint8')
df.default = df.default.map({'no': 1, 'unknown': 0, 'yes': 0}).astype('uint8')
df.pdays = df.pdays.replace(999, 0) # replace with 0 if not contact 
df.previous = df.previous.apply(lambda x: 1 if x > 0 else 0).astype('uint8') # binary has contact or not

# binary if were was an outcome of marketing campane
df.poutcome = df.poutcome.map({'unknown':0, 'failure':0,'other':0, 'success':1}).astype('uint8')  #what mean unknow - not in campaign?

# In[None]

df.info()

# In[None]

corr = df.corr()
corr.style.background_gradient(cmap='PuBu')

# In[None]

'''Convert Duration Call into 5 category'''
def duration(data):
    data.loc[data['duration'] <= 102, 'duration'] = 1
    data.loc[(data['duration'] > 102) & (data['duration'] <= 180)  , 'duration'] = 2
    data.loc[(data['duration'] > 180) & (data['duration'] <= 319)  , 'duration'] = 3
    data.loc[(data['duration'] > 319) & (data['duration'] <= 645), 'duration'] = 4
    data.loc[data['duration']  > 645, 'duration'] = 5
    return data


duration(df);


# In[None]

df.head()

# In[None]

df_a = df.drop(columns=['day','month'],axis = 1) #drop features which shouldn't influent outcome of campaign and remove targer feature - y

# In[None]

#get dummies data for job,education and marital status
job_dum = pd.get_dummies(df_a['job']).rename(columns=lambda x: 'job_' + str(x))
education_dum = pd.get_dummies(df['education']).rename(columns=lambda x: 'education_' + str(x))
marital_dum = pd.get_dummies(df['marital']).rename(columns=lambda x: 'marital' + str(x))
## dummies for age and pdays - zrob buckety */

# In[None]

#create dataset with dummies variables
df_b = pd.concat([df_a,job_dum,education_dum,marital_dum],axis=1)

# In[None]

df_b.head()

# In[None]

df_target = df_b['y']
df_feat =  df_b.drop(columns=['job','marital','education','y','deposit'],axis = 1)

# ##  # 3# .# 3#  # S# c# a# l# i# n# g#  # D# a# t# a

# In[None]

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(df_feat)
scaled_features = scaler.transform(df_feat)
df_feat_sc = pd.DataFrame(scaled_features,columns=df_feat.columns)

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df_feat, df_target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5927466.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv('../input/wisc_bc_data.csv')

# F# o# r#  #  # E# D# A#  # (# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# )

# In[None]

data.head(10)

# In[None]

data.drop(["id"],axis=1,inplace=True)


# In[None]

data.head(10)

# In[None]

M = data[data.diagnosis=='M']
B = data[data.diagnosis=='B']

# In[None]

plt.scatter(M.smoothness_mean,M.compactness_mean,color='purple',label='Malignant',alpha=0.3)
plt.scatter(B.smoothness_mean,B.compactness_mean,color='blue',label='Benign',alpha=0.3)
plt.xlabel('Malignant')
plt.ylabel('Benign')
plt.legend()
plt.show()

# In[None]

data.diagnosis= [1 if each=="M" else 0 for each in data.diagnosis]
y=data.diagnosis.values
x_data = data.drop(["diagnosis"],axis=1)

# In[None]

x = (x_data-np.min(x_data))/(np.max(x_data)-np.min(x_data))  # Normalization

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1872578.npy", { "accuracy_score": score })

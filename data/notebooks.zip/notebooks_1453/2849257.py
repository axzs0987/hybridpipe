import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]



# In[None]

patient= pd.read_csv("../input/indian_liver_patient.csv")
patient.head()


# In[None]



# In[None]

pd.get_dummies(patient['Gender'], prefix = 'Gender').head()

# In[None]



# In[None]

patient = pd.concat([patient,pd.get_dummies(patient['Gender'], prefix = 'Gender')], axis=1)

# In[None]



# In[None]

patient["Albumin_and_Globulin_Ratio"] = patient.Albumin_and_Globulin_Ratio.fillna(patient['Albumin_and_Globulin_Ratio'].mean())

# In[None]



# In[None]

X = patient.drop(['Gender','Dataset'], axis=1)

# In[None]



# In[None]

y = patient['Dataset']

# In[None]



# In[None]

from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.ensemble import RandomForestClassifier


# In[None]



# In[None]



# In[None]



# In[None]



# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2849257.npy", { "accuracy_score": score })

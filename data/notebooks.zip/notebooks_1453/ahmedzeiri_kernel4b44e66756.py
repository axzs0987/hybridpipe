import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data= pd.read_csv('/kaggle/input/africa-economic-banking-and-systemic-crisis-data/african_crises.csv')
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
data["banking_crisis"] = le.fit_transform(data["banking_crisis"])
data["banking_crisis"] = data["banking_crisis"].astype("category") 
data["cc3"] = le.fit_transform(data["cc3"])
data["cc3"] = data["cc3"].astype("category") 
data["country"] = le.fit_transform(data["country"])
data["country"] = data["country"].astype("category")
x = data.values[: , 0:13]
y = data["banking_crisis"]
print(x.shape)
print(data.shape)
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
clf = DecisionTreeClassifier()
#clf = clf.fit(xtrain,ytrain)
#y_pred = clf.predict(xtest)
#acc1 = metrics.accuracy_score(ytest, y_pred)
#matrix=confusion_matrix(ytest,y_pred)
#matrix
from sklearn.ensemble import RandomForestClassifier
clf=RandomForestClassifier()
#clf.fit(xtrain,ytrain)
#y_pred2=clf.predict(xtest)
#acc2 = metrics.accuracy_score(ytest, y_pred2)
#matrix2=confusion_matrix(ytest,y_pred2)
#acc2



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ahmedzeiri_kernel4b44e66756.npy", { "accuracy_score": score })
import pandas as pd
if type(xtrain).__name__ == "ndarray":
    np.save("hi_res_data/ahmedzeiri_kernel4b44e66756/trainX.npy", xtrain)
if type(xtrain).__name__ == "Series":
    xtrain.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/trainX.csv",encoding="gbk")
if type(xtrain).__name__ == "DataFrame":
    xtrain.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/trainX.csv",encoding="gbk")

if type(xtest).__name__ == "ndarray":
    np.save("hi_res_data/ahmedzeiri_kernel4b44e66756/testX.npy", xtest)
if type(xtest).__name__ == "Series":
    xtest.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/testX.csv",encoding="gbk")
if type(xtest).__name__ == "DataFrame":
    xtest.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/testX.csv",encoding="gbk")

if type(ytrain).__name__ == "ndarray":
    np.save("hi_res_data/ahmedzeiri_kernel4b44e66756/trainY.npy", ytrain)
if type(ytrain).__name__ == "Series":
    ytrain.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/trainY.csv",encoding="gbk")
if type(ytrain).__name__ == "DataFrame":
    ytrain.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/trainY.csv",encoding="gbk")

if type(ytest).__name__ == "ndarray":
    np.save("hi_res_data/ahmedzeiri_kernel4b44e66756/testY.npy", ytest)
if type(ytest).__name__ == "Series":
    ytest.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/testY.csv",encoding="gbk")
if type(ytest).__name__ == "DataFrame":
    ytest.to_csv("hi_res_data/ahmedzeiri_kernel4b44e66756/testY.csv",encoding="gbk")


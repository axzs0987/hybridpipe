import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#inline matplotlib

# In[None]

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# In[None]

#importing the data

# In[None]

dataset = pd.read_csv('../input/social-network-ads/Social_Network_Ads.csv')


# In[None]

#selecting the most gender as most valuable feature

# In[None]

df_getdummy = pd.get_dummies(data=dataset, columns=['Gender'])

# In[None]

dataset.head(5)

# In[None]

#Declaring dummy data

# In[None]

x = df_getdummy.drop('Purchased',axis=1)

# In[None]

y = df_getdummy['Purchased']

# In[None]

#Splitting my data between training and test data

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8637973.npy", { "accuracy_score": score })

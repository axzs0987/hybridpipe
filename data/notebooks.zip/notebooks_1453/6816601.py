import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

#load-data
data = pd.read_csv("/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")

# >#  # *# *# A# N# A# L# Y# Z# I# N# G#  # D# A# T# A# *# *

# In[None]

data.head()

# In[None]

data.info()

# In[None]

data.columns

# In[None]

data.describe()

# In[None]

#correlation 
data.corr()

# In[None]

#correlation map

f,ax = plt.subplots(figsize=(10,10))
sns.heatmap(data.corr(),annot = True , linewidth = .5, fmt = '.2f',ax = ax)
plt.show()

# In[None]

#counts of quality types
data.quality.value_counts()

# >#  # *# *# V# i# s# u# a# l# i# z# a# t# i# o# n# *# *

# In[None]

#visualization

#pie_graph
plt.figure(1, figsize=(8,8))
data.quality.value_counts().plot.pie(autopct="%1.1f%%")

# In[None]

sns.countplot(x="quality", data=data)
data.loc[:,'quality'].value_counts()

# In[None]

#scatter plot
data.plot(kind = "scatter" , x = "alcohol" , y = "quality" , color = "red")
plt.xlabel("alcohol")
plt.ylabel("quality")
plt.title("alcohol-quality Scatter Plot")
plt.show()

# In[None]

#line plot 
data.sulphates.plot(kind = "line" , color = "red" , alpha = 0.5 , grid = True , linestyle = ":",label = "sulphates")
data.chlorides.plot(kind = "line" , color = "green" , alpha = 0.5 , linestyle = "-",label = "chlorides")
plt.legend(loc = "upper right")
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("sulphates-chlorides Scatter Plot")
plt.show()

# >#  # >#  # *# *# M# L#  # A# l# g# o# r# t# i# h# m# s# *# *

# In[None]

y = data.quality.values
x_data = data.drop(["quality"],axis = 1)


# In[None]

#normalization
x = (x_data - np.min(x_data))/(np.max(x_data) - np.min(x_data))

# In[None]

#train-test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6816601.npy", { "accuracy_score": score })

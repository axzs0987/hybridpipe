import pandas as pd
# ##  # P# R# E# D# I# C# T#  # A#  # P# U# L# S# A# R#  # S# T# A# R# 
# ## ##  # C# l# a# s# s# i# f# i# c# a# t# i# o# n

# ## ## ##  # L# o# a# d#  # D# a# t# a

# In[None]

import os
import pandas as pd

DATA_PATH = '../input/predicting-a-pulsar-star/'
FILE_NAME = 'pulsar_stars.csv'
def load_data(data_path=DATA_PATH, file_name=FILE_NAME):
    csv_path = os.path.join(data_path, file_name)
    return pd.read_csv(csv_path)

dataset = load_data()

# ## ## ##  # V# i# e# w#  # D# a# t# a#  # a# n# d#  # I# n# f# o# r# m# a# t# i# o# n# s

# In[None]

dataset.head()

# In[None]

dataset.info()

# In[None]

not_pulsar, pulsar = dataset['target_class'].value_counts()

print("Pulsar Star:\t ", pulsar,"\nNot Pulsar Star: ", not_pulsar)

# In[None]

import matplotlib.pyplot as plt

custom_color = '#ff7400'
dataset.hist(bins=50, figsize=(20,15), color=custom_color)
plt.show()

# ## ## ##  # S# p# l# i# t#  # D# a# t# a# s# e# t

# ## ## ## ##  # G# e# t#  # t# h# e#  # L# a# b# e# l# s

# In[None]

X, y =  dataset.drop('target_class', axis=1), dataset['target_class'].copy()

print("X:",X.shape,"\ny:",y.shape)

# ## ## ## ##  # T# r# a# i# n#  # S# e# t#  # a# n# d#  # T# e# s# t#  # S# e# t

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8770153.npy", { "accuracy_score": score })

import pandas as pd
import numpy as np 
import re
import nltk
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
import scikitplot as skplt
from sklearn.linear_model import LogisticRegression
df=pd.read_csv('../input/restaurant-reviews/Restaurant_Reviews.csv')
df.head()
from nltk.corpus import stopwords
xyz=stopwords.words('english') 
xyz.remove('not')
from nltk.stem.porter import PorterStemmer
ps=PorterStemmer()
corpus=[]
for i in range(len(df)):
    review=re.sub('[^a-zA-Z]',' ',df.iloc[i,0]) 
    review=review.lower() 
    review=review.split() 
    ps=PorterStemmer() 
    review=[ps.stem(word) for word in review if not word in set(xyz)] 
    review=' '.join(review)
    corpus.append(review)
    
original=list(df.Review)
original[:10]
corpus[0:10]
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer()
no_of_words=cv.fit_transform(corpus).toarray()
len(no_of_words[0])
cv = CountVectorizer(max_features = 1500)
X = cv.fit_transform(corpus).toarray()
y = df.iloc[:, 1].values
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
classifier = GaussianNB()
#classifier.fit(X_train, y_train)
#print('Test Score : {} %'.format(classifier.score(X_test,y_test)*100))
#cross_val_score(classifier,X_train,y_train,cv=10).mean()*100
#skplt.metrics.plot_confusion_matrix(y_test,classifier.predict(X_test),figsize=(8,8))
logistic_classifier=LogisticRegression()
#logistic_classifier.fit(X_train,y_train)
#print('Test Score : {} %'.format(logistic_classifier.score(X_test,y_test)*100))
#cross_val_score(logistic_classifier,X_train,y_train,cv=10).mean()*100
#skplt.metrics.plot_confusion_matrix(y_test,logistic_classifier.predict(X_test),figsize=(8,8))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anuragmishra2311_restaurant-reviews-binary-classification.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anuragmishra2311_restaurant-reviews-binary-classification/testY.csv",encoding="gbk")


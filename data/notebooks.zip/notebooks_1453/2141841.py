import pandas as pd
# I# n#  # t# h# i# s#  # e# x# a# m# p# l# e# ,#  # I#  # w# i# l# l#  # t# r# y#  # t# o#  # b# u# i# l# d#  # a#  # m# o# d# e# l#  # w# h# i# c# h#  # w# i# l# l#  # p# r# e# d# i# c# t#  # i# f#  # i# t#  # w# i# l# l#  # r# a# i# n#  # t# o# m# o# r# r# o# w# !# 
# C# l# e# a# r# l# y# ,#  # i# t#  # i# s#  # a#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# .#  # T# h# e#  # m# o# d# e# l#  # w# i# l# l#  # g# i# v# e# s#  # u# s#  # 2#  # c# l# a# s# s# e# s#  # -#  # e# i# t# h# e# r#  # Y# E# S#  # o# r#  # N# O# .# 
# W# e#  # s# h# a# l# l#  # t# r# y#  # v# a# r# i# o# u# s#  # c# l# a# s# s# i# f# i# e# r# s#  # t# o#  # f# i# n# d#  # t# h# e#  # b# e# s# t#  # m# o# d# e# l#  # f# o# r#  # t# h# e#  # d# a# t# a# .# 
# 
# *# *# D# a# t# a#  # P# r# e# -# p# r# o# c# e# s# s# i# n# g# *# *

# In[None]

#Load the csv file as data frame.
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

df = pd.read_csv('../input/weatherAUS.csv')
print('Size of weather data frame is :',df.shape)
#Let us see how our data looks like!
df[0:5]

# In[None]

# We see there are some columns with null values. 
# Before we start pre-processing, let's find out which of the columns have maximum null values
df.count().sort_values()

# In[None]

# As we can see the first four columns have less than 60% data, we can ignore these four columns
# We don't need the location column because 
# we are going to find if it will rain in Australia(not location specific)
# We are going to drop the date column too.
# We need to remove RISK_MM because we want to predict 'RainTomorrow' and RISK_MM can leak some info to our model
df = df.drop(columns=['Sunshine','Evaporation','Cloud3pm','Cloud9am','Location','RISK_MM','Date'],axis=1)
df.shape

# In[None]

#Let us get rid of all null values in df
df = df.dropna(how='any')
df.shape

# In[None]

#its time to remove the outliers in our data - we are using Z-score to detect and remove the outliers.
from scipy import stats
z = np.abs(stats.zscore(df._get_numeric_data()))
print(z)
df= df[(z < 3).all(axis=1)]
print(df.shape)

# In[None]

#Lets deal with the categorical cloumns now
# simply change yes/no to 1/0 for RainToday and RainTomorrow
df['RainToday'].replace({'No': 0, 'Yes': 1},inplace = True)
df['RainTomorrow'].replace({'No': 0, 'Yes': 1},inplace = True)

#See unique values and convert them to int using pd.getDummies()
categorical_columns = ['WindGustDir', 'WindDir3pm', 'WindDir9am']
for col in categorical_columns:
    print(np.unique(df[col]))
# transform the categorical columns
df = pd.get_dummies(df, columns=categorical_columns)
df.iloc[4:9]

# In[None]

#next step is to standardize our data - using MinMaxScaler
from sklearn import preprocessing
scaler = preprocessing.MinMaxScaler()
scaler.fit(df)
df = pd.DataFrame(scaler.transform(df), index=df.index, columns=df.columns)
df.iloc[4:10]

# *# *# F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n# *# *

# In[None]

#now that we are done with the pre-processing part, let's see which are the important features for RainTomorrow!
#Using SelectKBest to get the top features!
from sklearn.feature_selection import SelectKBest, chi2
X = df.loc[:,df.columns!='RainTomorrow']
y = df[['RainTomorrow']]
selector = SelectKBest(chi2, k=3)
selector.fit(X, y)
X_new = selector.transform(X)
print(X.columns[selector.get_support(indices=True)]) #top 3 columns

# In[None]

#Let's get hold of the important features as assign them as X
df = df[['Humidity3pm','Rainfall','RainToday','RainTomorrow']]
X = df[['Humidity3pm']] # let's use only one feature Humidity3pm
y = df[['RainTomorrow']]

# *# *# F# i# n# d# i# n# g#  # t# h# e#  # b# e# s# t#  # m# o# d# e# l# *# *

# In[None]

#Logistic Regression 
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import time

t0=time.time()
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2141841.npy", { "accuracy_score": score })

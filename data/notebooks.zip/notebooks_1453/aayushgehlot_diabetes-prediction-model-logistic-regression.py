import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.linear_model import LogisticRegression
#sns.set_style('whitegrid')
data = pd.read_csv('../input/diabetes-dataset/diabetes2.csv')
data.head()
data.info()
#sns.pairplot(data)
data.isnull().sum()
#sns.heatmap(data.isnull(),yticklabels=False,cbar=False,cmap='viridis')
#sns.distplot(data['BMI'])
#sns.distplot(data['SkinThickness'])
#sns.countplot(data['Outcome'])
#sns.heatmap(data.corr(), cmap='Blues')
X = data.drop('Outcome', axis = 1)
y= data['Outcome']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42)
lm = LogisticRegression()
#lm.fit(X_train, y_train)
#pred = lm.predict(X_test)
#confusion_matrix(y_test, pred)
#print(classification_report(y_test, pred))
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(data.drop('Outcome',axis=1))
scaled_features = scaler.transform(data.drop('Outcome',axis=1))
df_feat = pd.DataFrame(scaled_features,columns=data.columns[:-1])
df_feat.head()
df_feat.shape
y = data['Outcome']

from sklearn.model_selection import train_test_split
S_X_train, S_X_test, S_y_train, S_y_test = train_test_split(scaled_features, y, train_size=0.8, test_size=1-0.8, random_state=0)
slm = LogisticRegression()
#slm.fit(S_X_train, S_y_train)
#predict = slm.predict(S_X_test)
#confusion_matrix(S_y_test, predict)
#print(classification_report(S_y_test, predict))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(S_X_train, S_y_train)
y_pred = model.predict(S_X_test)
score = accuracy_score(S_y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aayushgehlot_diabetes-prediction-model-logistic-regression.npy", { "accuracy_score": score })
import pandas as pd
if type(S_X_train).__name__ == "ndarray":
    np.save("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainX.npy", S_X_train)
if type(S_X_train).__name__ == "Series":
    S_X_train.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainX.csv",encoding="gbk")
if type(S_X_train).__name__ == "DataFrame":
    S_X_train.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainX.csv",encoding="gbk")

if type(S_X_test).__name__ == "ndarray":
    np.save("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testX.npy", S_X_test)
if type(S_X_test).__name__ == "Series":
    S_X_test.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testX.csv",encoding="gbk")
if type(S_X_test).__name__ == "DataFrame":
    S_X_test.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testX.csv",encoding="gbk")

if type(S_y_train).__name__ == "ndarray":
    np.save("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainY.npy", S_y_train)
if type(S_y_train).__name__ == "Series":
    S_y_train.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainY.csv",encoding="gbk")
if type(S_y_train).__name__ == "DataFrame":
    S_y_train.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/trainY.csv",encoding="gbk")

if type(S_y_test).__name__ == "ndarray":
    np.save("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testY.npy", S_y_test)
if type(S_y_test).__name__ == "Series":
    S_y_test.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testY.csv",encoding="gbk")
if type(S_y_test).__name__ == "DataFrame":
    S_y_test.to_csv("hi_res_data/aayushgehlot_diabetes-prediction-model-logistic-regression/testY.csv",encoding="gbk")


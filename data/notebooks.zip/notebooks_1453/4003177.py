import pandas as pd
# ##  # A# n# a# l# y# z# i# n# g#  # S# t# u# d# e# n# t# '# s#  # B# e# h# a# v# i# o# r#  # a# n# d#  # M# o# d# e# l#  # s# u# g# g# e# s# t# i# o# n#  # f# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # l# e# v# e# l# s# 
# ## ## ##  # M# a# r# l# o# n#  # F# e# r# r# a# r# i# 
# >#  # ## ## ## ##  # T# h# i# s#  # D# a# t# a#  # S# c# i# e# n# c# e#  # p# r# o# j# e# c# t#  # w# a# s#  # m# a# d# e#  # u# n# d# e# r#  # C# a# p# s# t# o# n# e#  # D# a# t# a#  # S# c# i# e# n# c# e#  # I# B# M#  # C# e# r# t# i# f# i# c# a# t# i# o# n#  # P# r# o# g# r# a# m# .

# ## ##  # T# a# b# l# e#  # o# f#  # c# o# n# t# e# n# t# s# 
# *#  # [# I# n# t# r# o# d# u# c# t# i# o# n# :#  # B# u# s# i# n# e# s# s#  # P# r# o# b# l# e# m# ]# (# ## i# n# t# r# o# d# u# c# t# i# o# n# )# 
# *#  # [# D# a# t# a# ]# (# ## d# a# t# a# )# 
# *#  # [# M# e# t# h# o# d# o# l# o# g# y# ]# (# ## m# e# t# h# o# d# o# l# o# g# y# )# 
# *#  # [# A# n# a# l# y# s# i# s# ]# (# ## a# n# a# l# y# s# i# s# )# 
# *#  # [# R# e# s# u# l# t# s#  # a# n# d#  # D# i# s# c# u# s# s# i# o# n# ]# (# ## r# e# s# u# l# t# s# )# 
# *#  # [# C# o# n# c# l# u# s# i# o# n# ]# (# ## c# o# n# c# l# u# s# i# o# n# )

# ##  # 1# .#  # I# n# t# r# o# d# u# c# t# i# o# n#  # <# a#  # n# a# m# e# =# "# i# n# t# r# o# d# u# c# t# i# o# n# "# ># <# /# a# ># 
# A#  # d# e# s# c# r# i# p# t# i# o# n#  # o# f#  # t# h# e#  # p# r# o# b# l# e# m#  # a# n# d#  # a#  # d# i# s# c# u# s# s# i# o# n#  # o# f#  # t# h# e#  # b# a# c# k# g# r# o# u# n# d# 
# 
# T# h# e#  # I# n# t# e# r# n# e# t#  # r# e# v# o# l# u# t# i# o# n#  # b# r# o# u# g# h# t#  # m# o# r# e#  # t# h# a# n#  # s# o# c# i# a# l#  # m# e# d# i# a# s#  # a# n# d#  # f# a# s# t# e# r#  # i# n# f# o# r# m# a# t# i# o# n#  # e# x# c# h# a# n# g# e# s# .#  # I# t#  # b# r# o# u# g# h# t#  # a# l# s# o#  # a#  # g# e# n# e# r# a# t# i# o# n#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # s# t# u# d# i# e# s#  # t# h# r# o# u# g# h#  # t# h# e#  # d# i# g# i# t# a# l#  # e# n# v# i# r# o# n# m# e# n# t# s# .#  # U# n# d# e# r#  # t# h# i# s#  # c# o# n# t# e# x# t# ,#  # t# h# e#  # o# n# l# i# n# e#  # e# d# u# c# a# t# i# o# n#  # e# v# o# l# v# e# d#  # q# u# i# c# k# l# y#  # a# n# d#  # t# h# e#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n#  # o# f#  # t# h# e#  # s# o# c# i# e# t# i# e# s#  # r# e# a# l# l# y#  # s# t# a# r# t# e# d# .#  # N# o# w# a# d# a# y# s# ,#  # p# e# o# p# l# e#  # i# n#  # d# i# s# t# a# n# t#  # p# l# a# c# e# s# ,#  # p# o# o# r#  # c# o# u# n# t# r# i# e# s#  # c# a# n#  # b# e# n# e# f# i# t#  # f# r# o# m#  # t# e# c# h# n# o# l# o# g# y#  # t# o#  # a# c# h# i# e# v# e#  # i# n# f# o# r# m# a# t# i# o# n#  # a# n# d#  # i# n#  # t# h# i# s#  # c# a# s# e# ,#  # t# h# e#  # M# a# s# s# i# v# e#  # O# p# e# n#  # O# n# l# i# n# e#  # C# o# u# r# s# e# s# ,#  # M# O# O# C# s#  # h# a# d#  # a#  # m# a# j# o# r#  # r# o# l# e# .# 
# M# O# O# C# s#  # c# a# n#  # j# o# i# n#  # p# e# o# p# l# e#  # a# l# l#  # a# r# o# u# n# d#  # t# h# e#  # w# o# r# l# d#  # t# o#  # a# c# h# i# e# v# e#  # u# n# d# e# r# s# t# a# n# d#  # i# n#  # a#  # w# i# d# e#  # r# a# n# g# e#  # o# f#  # a# r# e# a# s# ,#  # d# e# l# i# v# e# r# i# n# g#  # s# c# i# e# n# c# e#  # a# n# d#  # c# u# l# t# u# r# e# .# 
# 
# I# t#  # i# s#  # k# n# o# w# n# ,#  # a# l# s# o# ,#  # t# h# a# t#  # o# n# l# i# n# e#  # l# e# a# r# n# i# n# g#  # s# u# f# f# e# r# s#  # m# a# s# s# i# v# e#  # u# n# e# n# r# o# l# l# m# e# n# t# .#  # T# h# e#  # l# o# g# i# c# a# l#  # b# o# r# d# e# r#  # a# n# d#  # t# h# e#  # l# a# c# k#  # o# f#  # m# o# t# i# v# a# t# i# o# n#  # c# a# n#  # m# a# k# e#  # t# h# e#  # s# t# u# d# e# n# t# s#  # l# e# a# v# e# .#  # U# n# d# e# r#  # t# h# i# s#  # c# o# n# t# e# x# t# ,#  # w# h# a# t#  # a# r# e#  # t# h# e#  # r# e# l# a# t# e# d#  # f# e# a# t# u# r# e# s#  # w# h# i# c# h#  # c# a# u# s# e# s#  # i# t# ?#  # H# o# w#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t#  # s# c# e# n# a# r# i# o#  # a# n# d#  # p# r# e# d# i# c# t#  # h# i# s#  # c# h# u# r# n#  # o# r#  # l# o# w#  # g# r# a# d# e# s# ?# 
# I#  # t# h# i# n# k#  # t# h# a# t#  # i# s#  # a#  # r# e# l# e# v# a# n# t#  # p# o# i# n# t# .#  # I# f#  # M# O# O# C# s#  # p# l# a# t# f# o# r# m# s#  # a# c# h# i# e# v# e#  # s# t# u# d# e# n# t#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # a# n# d#  # p# r# e# d# i# c# t# i# n# g# ,#  # I#  # t# h# i# n# k#  # i# t# '# s#  # p# o# s# s# i# b# l# e#  # t# o#  # m# e# n# a# g# e#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # c# h# u# r# n#  # a# n# d#  # f# i# n# d#  # a#  # w# a# y#  # t# o#  # g# i# v# e#  # t# h# e# m#  # t# h# e#  # n# e# e# d# e# d#  # m# o# t# i# v# a# t# i# o# n# .# 
# 
# W# i# t# h#  # t# h# i# s#  # s# e# t#  # i# n#  # m# i# n# d# ,#  # I#  # s# t# a# r# t# e# d#  # a#  # s# e# a# r# c# h#  # f# o# r#  # M# O# O# C# s#  # g# e# n# e# r# a# t# e# d#  # S# t# u# d# e# n# t# s#  # D# a# t# a#  # t# o#  # i# n# v# e# s# t# i# g# a# t# e#  # a# n# d#  # p# r# e# p# a# r# e#  # s# o# m# e#  # c# o# n# c# l# u# s# i# o# n# s#  # a# b# o# u# t#  # t# h# e#  # t# h# e# m# e# .# 


# ##  # 2# .#  # D# a# t# a# 
# A#  # d# e# s# c# r# i# p# t# i# o# n#  # o# f#  # t# h# e#  # d# a# t# a#  # a# n# d#  # h# o# w#  # i# t#  # w# i# l# l#  # b# e#  # u# s# e# d#  # t# o#  # s# o# l# v# e#  # t# h# e#  # p# r# o# b# l# e# m# 
# 
# T# o#  # g# u# i# d# e#  # m# y#  # i# n# v# e# s# t# i# g# a# t# i# o# n# ,#  # I#  # w# a# s#  # l# o# o# k# i# n# g#  # f# o# r#  # a#  # S# e# t#  # t# o#  # h# e# l# p#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # b# e# h# a# v# i# o# r# ,#  # m# o# t# i# v# a# t# i# o# n#  # a# n# d#  # c# o# r# r# e# l# a# t# e# d#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # i# n#  # o# r# d# e# r#  # t# o#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d#  # w# h# y#  # o# r#  # h# o# w#  # i# s#  # t# h# e#  # r# e# s# u# l# t#  # o# f#  # a# n#  # e# n# r# o# l# l# m# e# n# t# .#  # S# o# ,#  # i# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # f# i# n# d#  # a#  # d# a# t# a# s# e# t#  # w# i# t# h#  # s# o# m# e#  # k# e# y#  # f# e# a# t# u# r# e# s#  # l# i# k# e#  # g# r# a# d# e# ,#  # g# e# n# d# e# r# ,#  # e# n# r# o# l# l# m# e# n# t#  # l# e# v# e# l# s# ,#  # a# n# d#  # s# o#  # o# n# .#  # L# o# c# a# t# i# o# n#  # d# a# t# a#  # i# s#  # a# l# s# o#  # i# m# p# o# r# t# a# n# t#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # c# u# l# t# u# r# a# l#  # m# a# r# k# s# ,#  # w# h# i# c# h#  # w# i# l# l#  # b# e#  # e# x# p# l# o# r# e# d#  # b# y#  # l# o# c# a# t# i# o# n# s#  # A# P# I# s# .# 
# G# u# i# d# e# d#  # b# y#  # t# h# e#  # a# n# a# l# y# s# i# s#  # e# x# p# l# o# r# a# t# i# o# n# ,#  # I# '# l# l#  # b# e#  # a# b# l# e#  # t# o#  # b# u# i# l# d#  # a#  # m# o# d# e# l#  # t# o#  # p# r# e# d# i# c# t#  # s# t# u# d# e# n# t# '# s#  # b# e# h# a# v# i# o# r#  # o# r#  # r# e# s# u# l# t# s# .# 
# A# f# t# e# r#  # q# u# e# r# y# i# n# g#  # c# o# r# r# e# l# a# t# e# d#  # d# a# t# a# s# e# t# s#  # i# n#  # o# r# d# e# r#  # t# o#  # f# i# n# d#  # t# h# o# s# e#  # w# i# t# h#  # b# e# t# t# e# r#  # c# o# l# u# m# n# s# ,#  # I#  # f# o# u# n# d#  # a#  # n# i# c# e#  # D# a# t# a# S# e# t#  # f# r# o# m#  # K# a# g# g# l# e#  # c# a# l# l# e# d#  # "# S# t# u# d# e# n# t# s# '#  # A# c# a# d# e# m# i# c#  # P# e# r# f# o# r# m# a# n# c# e#  # D# a# t# a# s# e# t# "# .#  # Y# o# u#  # c# a# n#  # c# h# e# c# k#  # i# t#  # h# e# r# e#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# a# l# j# a# r# a# h# /# x# A# P# I# -# E# d# u# -# D# a# t# a# .# 
# <# p# >#  # T# h# e#  # d# a# t# a#  # c# o# m# p# o# u# n# d# s#  # 1# 6#  # c# o# l# u# m# n# s#  # w# i# t# h#  # a# g# g# r# e# g# a# t# e# d#  # i# n# f# o# r# m# a# t# i# o# n# s#  # a# b# o# u# t#  # o# v# e# r#  # 4# 8# 0#  # s# t# u# d# e# n# t# s#  # o# f#  # a#  # L# e# a# r# n# i# n# g#  # P# l# a# t# f# o# r# m#  # c# a# l# l# e# d#  # K# a# l# b# o# a# r# d# 3# 6# 0# .#  # T# h# e#  # d# a# t# a# i# l# s#  # w# i# l# l#  # b# e#  # s# h# o# w# n#  # n# e# x# t#  # s# e# c# t# i# o# n# .# 


# ## ##  # 2# .# 1#  # D# a# t# a#  # S# t# r# u# c# t# u# r# e

# A# s#  # p# r# e# v# i# o# u# s# l# y#  # m# e# n# t# i# o# n# e# d# ,#  # t# h# i# s#  # d# a# t# a# s# e# t#  # i# n# c# l# u# d# e# s#  # 1# 6#  # c# o# l# u# m# n# s# :# 
# 
# 1# .#  # G# e# n# d# e# r#  # -#  # s# t# u# d# e# n# t# '# s#  # g# e# n# d# e# r#  # (# n# o# m# i# n# a# l# :#  # '# M# a# l# e# '#  # o# r#  # '# F# e# m# a# l# e# ’# )# 
# 
# 2# .#  # N# a# t# i# o# n# a# l# i# t# y# -#  # s# t# u# d# e# n# t# '# s#  # n# a# t# i# o# n# a# l# i# t# y#  # (# n# o# m# i# n# a# l# :# ’#  # K# u# w# a# i# t# ’# ,# ’#  # L# e# b# a# n# o# n# ’# ,# ’#  # E# g# y# p# t# ’# ,# ’#  # S# a# u# d# i# A# r# a# b# i# a# ’# ,# ’#  # U# S# A# ’# ,# ’#  # J# o# r# d# a# n# ’# ,# ’#  # V# e# n# e# z# u# e# l# a# ’# ,# ’#  # I# r# a# n# ’# ,# ’#  # T# u# n# i# s# ’# ,# ’#  # M# o# r# o# c# c# o# ’# ,# ’#  # S# y# r# i# a# ’# ,# ’#  # P# a# l# e# s# t# i# n# e# ’# ,# ’#  # I# r# a# q# ’# ,# ’#  # L# y# b# i# a# ’# )# 
# 
# 3# .#  # P# l# a# c# e#  # o# f#  # b# i# r# t# h# -#  # s# t# u# d# e# n# t# '# s#  # P# l# a# c# e#  # o# f#  # b# i# r# t# h#  # (# n# o# m# i# n# a# l# :# ’#  # K# u# w# a# i# t# ’# ,# ’#  # L# e# b# a# n# o# n# ’# ,# ’#  # E# g# y# p# t# ’# ,# ’#  # S# a# u# d# i# A# r# a# b# i# a# ’# ,# ’#  # U# S# A# ’# ,# ’#  # J# o# r# d# a# n# ’# ,# ’#  # V# e# n# e# z# u# e# l# a# ’# ,# ’#  # I# r# a# n# ’# ,# ’#  # T# u# n# i# s# ’# ,# ’#  # M# o# r# o# c# c# o# ’# ,# ’#  # S# y# r# i# a# ’# ,# ’#  # P# a# l# e# s# t# i# n# e# ’# ,# ’#  # I# r# a# q# ’# ,# ’#  # L# y# b# i# a# ’# )# 
# 
# 4# .#  # E# d# u# c# a# t# i# o# n# a# l#  # S# t# a# g# e# s# -#  # e# d# u# c# a# t# i# o# n# a# l#  # l# e# v# e# l#  # s# t# u# d# e# n# t#  # b# e# l# o# n# g# s#  # (# n# o# m# i# n# a# l# :#  # ‘# l# o# w# e# r# l# e# v# e# l# ’# ,# ’# M# i# d# d# l# e# S# c# h# o# o# l# ’# ,# ’# H# i# g# h# S# c# h# o# o# l# ’# )# 
# 
# 5# .#  # G# r# a# d# e#  # L# e# v# e# l# s# -#  # g# r# a# d# e#  # s# t# u# d# e# n# t#  # b# e# l# o# n# g# s#  # (# n# o# m# i# n# a# l# :#  # ‘# G# -# 0# 1# ’# ,#  # ‘# G# -# 0# 2# ’# ,#  # ‘# G# -# 0# 3# ’# ,#  # ‘# G# -# 0# 4# ’# ,#  # ‘# G# -# 0# 5# ’# ,#  # ‘# G# -# 0# 6# ’# ,#  # ‘# G# -# 0# 7# ’# ,#  # ‘# G# -# 0# 8# ’# ,#  # ‘# G# -# 0# 9# ’# ,#  # ‘# G# -# 1# 0# ’# ,#  # ‘# G# -# 1# 1# ’# ,#  # ‘# G# -# 1# 2#  # ‘# )# 
# 
# 6# .#  # S# e# c# t# i# o# n#  # I# D# -#  # c# l# a# s# s# r# o# o# m#  # s# t# u# d# e# n# t#  # b# e# l# o# n# g# s#  # (# n# o# m# i# n# a# l# :# ’# A# ’# ,# ’# B# ’# ,# ’# C# ’# )# 
# 
# 7# .#  # T# o# p# i# c# -#  # c# o# u# r# s# e#  # t# o# p# i# c#  # (# n# o# m# i# n# a# l# :# ’#  # E# n# g# l# i# s# h# ’# ,# ’#  # S# p# a# n# i# s# h# ’# ,#  # ‘# F# r# e# n# c# h# ’# ,# ’#  # A# r# a# b# i# c# ’# ,# ’#  # I# T# ’# ,# ’#  # M# a# t# h# ’# ,# ’#  # C# h# e# m# i# s# t# r# y# ’# ,#  # ‘# B# i# o# l# o# g# y# ’# ,#  # ‘# S# c# i# e# n# c# e# ’# ,# ’#  # H# i# s# t# o# r# y# ’# ,# ’#  # Q# u# r# a# n# ’# ,# ’#  # G# e# o# l# o# g# y# ’# )# 
# 
# 8# .#  # S# e# m# e# s# t# e# r# -#  # s# c# h# o# o# l#  # y# e# a# r#  # s# e# m# e# s# t# e# r#  # (# n# o# m# i# n# a# l# :# ’#  # F# i# r# s# t# ’# ,# ’#  # S# e# c# o# n# d# ’# )# 
# 
# 9# .#  # P# a# r# e# n# t#  # r# e# s# p# o# n# s# i# b# l# e#  # f# o# r#  # s# t# u# d# e# n# t#  # (# n# o# m# i# n# a# l# :# ’# m# o# m# ’# ,# ’# f# a# t# h# e# r# ’# )# 
# 
# 1# 0# .#  # R# a# i# s# e# d#  # h# a# n# d# -#  # h# o# w#  # m# a# n# y#  # t# i# m# e# s#  # t# h# e#  # s# t# u# d# e# n# t#  # r# a# i# s# e# s#  # h# i# s# /# h# e# r#  # h# a# n# d#  # o# n#  # c# l# a# s# s# r# o# o# m#  # (# n# u# m# e# r# i# c# :# 0# -# 1# 0# 0# )# 
# 
# 1# 1# .#  # V# i# s# i# t# e# d#  # r# e# s# o# u# r# c# e# s# -#  # h# o# w#  # m# a# n# y#  # t# i# m# e# s#  # t# h# e#  # s# t# u# d# e# n# t#  # v# i# s# i# t# s#  # a#  # c# o# u# r# s# e#  # c# o# n# t# e# n# t# (# n# u# m# e# r# i# c# :# 0# -# 1# 0# 0# )# 
# 
# 1# 2# .#  # V# i# e# w# i# n# g#  # a# n# n# o# u# n# c# e# m# e# n# t# s# -# h# o# w#  # m# a# n# y#  # t# i# m# e# s#  # t# h# e#  # s# t# u# d# e# n# t#  # c# h# e# c# k# s#  # t# h# e#  # n# e# w#  # a# n# n# o# u# n# c# e# m# e# n# t# s# (# n# u# m# e# r# i# c# :# 0# -# 1# 0# 0# )# 
# 
# 1# 3# .#  # D# i# s# c# u# s# s# i# o# n#  # g# r# o# u# p# s# -#  # h# o# w#  # m# a# n# y#  # t# i# m# e# s#  # t# h# e#  # s# t# u# d# e# n# t#  # p# a# r# t# i# c# i# p# a# t# e#  # o# n#  # d# i# s# c# u# s# s# i# o# n#  # g# r# o# u# p# s#  # (# n# u# m# e# r# i# c# :# 0# -# 1# 0# 0# )# 
# 
# 1# 4# .#  # P# a# r# e# n# t#  # A# n# s# w# e# r# i# n# g#  # S# u# r# v# e# y# -#  # p# a# r# e# n# t#  # a# n# s# w# e# r# e# d#  # t# h# e#  # s# u# r# v# e# y# s#  # w# h# i# c# h#  # a# r# e#  # p# r# o# v# i# d# e# d#  # f# r# o# m#  # s# c# h# o# o# l#  # o# r#  # n# o# t#  # (# n# o# m# i# n# a# l# :# ’# Y# e# s# ’# ,# ’# N# o# ’# )# 
# 
# 1# 5# .#  # P# a# r# e# n# t#  # S# c# h# o# o# l#  # S# a# t# i# s# f# a# c# t# i# o# n# -#  # t# h# e#  # D# e# g# r# e# e#  # o# f#  # p# a# r# e# n# t#  # s# a# t# i# s# f# a# c# t# i# o# n#  # f# r# o# m#  # s# c# h# o# o# l# (# n# o# m# i# n# a# l# :# ’# Y# e# s# ’# ,# ’# N# o# ’# )# 
# 
# 1# 6# .#  # S# t# u# d# e# n# t#  # A# b# s# e# n# c# e#  # D# a# y# s# -# t# h# e#  # n# u# m# b# e# r#  # o# f#  # a# b# s# e# n# c# e#  # d# a# y# s#  # f# o# r#  # e# a# c# h#  # s# t# u# d# e# n# t#  # (# n# o# m# i# n# a# l# :#  # a# b# o# v# e# -# 7# ,#  # u# n# d# e# r# -# 7# )# 
# 
# T# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c#  # o# f#  # t# h# i# s#  # d# a# t# a# s# e# t#  # i# s#  # t# h# a# t#  # i# t#  # h# a# s#  # i# n# c# l# u# d# e# d#  # t# h# e#  # p# a# r# e# n# t# '# s#  # d# a# t# a# ,#  # w# h# i# c# h#  # i# s#  # a#  # n# i# c# e#  # a# p# p# r# o# a# c# h#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t# .

# ##  # 3# .#  # M# e# t# h# o# d# o# l# o# g# y# 
# 
# T# h# e#  # f# i# r# s# t#  # s# t# e# p# s#  # a# r# e#  # t# h# e#  # d# a# t# a#  # e# x# p# l# o# r# a# t# i# o# n#  # a# n# d#  # i# n# s# i# g# h# t# -# t# a# k# i# n# g#  # a# p# p# r# o# a# c# h#  # i# n#  # o# r# d# e# r#  # t# o#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # d# a# t# a#  # a# n# d#  # t# h# e#  # c# o# l# u# m# n# s# .#  # T# h# e#  # p# u# r# p# o# s# e#  # o# f#  # t# h# i# s#  # e# x# p# l# o# r# a# t# o# r# y#  # a# n# a# l# y# s# i# s#  # i# s#  # t# o#  # i# d# e# n# t# i# f# y#  # h# i# d# d# e# n#  # f# e# a# t# u# r# e# s#  # a# n# d#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # r# e# l# a# t# i# o# n# s#  # b# e# t# w# e# e# n#  # t# h# e#  # f# e# a# t# u# r# e# s# .# 
# N# e# x# t# ,#  # I# '# l# l#  # d# o#  # a#  # d# e# s# c# r# i# t# i# v# e#  # a# n# a# l# y# s# i# s#  # b# y#  # b# u# i# l# d# i# n# g#  # a#  # d# a# t# a# s# e# t#  # f# o# r#  # a#  # c# l# u# s# t# e# r# i# n# g#  # a# l# g# o# r# i# t# h# m# .#  # T# h# i# s#  # w# a# y# ,#  # t# h# e#  # d# a# t# a#  # u# n# d# e# r# s# t# a# n# d# i# n# g#  # w# i# l# l#  # b# e# c# o# m# e#  # a#  # m# o# r# e#  # p# o# w# e# r# f# u# l# l#  # d# e# c# i# s# i# o# n#  # m# a# k# i# n# g# ,#  # f# o# c# u# s# e# d#  # o# n#  # s# t# u# d# e# n# t# '# s#  # b# e# h# a# v# i# o# r# s# .# 
# F# i# n# a# l# l# y# ,#  # I# '# l# l#  # c# r# e# a# t# e#  # a#  # m# y#  # p# r# e# d# i# c# t# i# v# e#  # a# n# a# l# y# s# i# s#  # b# y#  # b# u# i# l# d# i# n# g#  # a#  # d# a# t# a# s# e# t#  # w# i# t# h#  # t# h# e#  # b# e# s# t#  # f# e# a# t# u# r# e# s#  # f# o# r#  # a#  # s# u# p# e# r# v# i# s# e# d#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # b# e# a# h# v# i# o# r#  # u# n# d# e# r#  # c# e# r# t# a# i# n#  # c# o# n# d# i# t# i# o# n# s# ,#  # w# h# i# c# h#  # w# i# l# l#  # a# c# h# i# e# v# e#  # m# y#  # f# i# n# a# l#  # o# b# j# e# c# t# i# v# e# .

# ##  # 4# .#  # A# n# a# l# y# s# i# s

# A# s#  # m# e# n# t# i# o# n# e# d# ,#  # t# h# i# s#  # s# e# c# t# i# o# n#  # w# i# l# l#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # d# a# t# a#  # i# n#  # o# r# d# e# r#  # t# o#  # c# o# m# p# o# s# e#  # t# h# e#  # c# l# u# s# t# e# r# i# n# g#  # d# a# t# a# s# e# t# .

# ## ## ##  # 4# .# 1#  # E# x# p# l# o# r# a# t# o# r# y#  # A# n# a# l# y# s# i# s

# In[110]

import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt

# In[111]

dataset = pd.read_csv('../input/xAPI-Edu-Data.csv')
dataset.head(5)

# I# n#  # t# h# e#  # c# o# n# t# e# x# t#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t#  # a# n# d#  # h# i# s#  # r# e# s# u# l# t# s# ,#  # s# e# t# t# i# n# g#  # u# p#  # a#  # d# a# t# a# f# r# a# m# e#  # w# i# t# h#  # c# e# r# t# a# i# n#  # c# o# l# u# m# n# s

# In[112]

df = dataset[['gender','PlaceofBirth','StageID','Topic','raisedhands','VisITedResources','AnnouncementsView','Discussion', 'ParentAnsweringSurvey','ParentschoolSatisfaction','StudentAbsenceDays', 'Class']]
df.head()

# T# r# y#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # r# e# s# u# l# t# s#  # f# r# o# m#  # c# o# u# n# t# r# i# e# s

# In[113]

df.groupby(['ParentschoolSatisfaction'])['Class'].value_counts(normalize=True)


# In[114]

df.groupby(['ParentAnsweringSurvey'])['ParentschoolSatisfaction'].value_counts(normalize=True)

# I# t#  # s# e# e# m# s#  # t# h# a# t#  # p# a# r# e# n# t# s#  # w# h# i# c# h#  # a# r# e# n# '# t#  # e# n# v# o# l# v# e# d#  # i# n#  # a# n# s# w# e# r# i# n# g#  # t# h# e#  # s# c# h# o# l# a# r# '# s#  # s# u# r# v# e# y# s#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # b# e# c# o# m# e#  # u# n# s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e#  # S# c# h# o# o# l# .#  # T# h# i# s#  # c# a# n#  # m# e# a# n#  # t# h# a# t#  # w# e# l# l#  # i# n# f# o# r# m# e# d#  # p# a# r# e# n# t# s#  # c# a# n#  # b# e# t# t# e# r#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # e# n# r# o# l# l# m# e# n# t#  # a# n# d#  # r# e# a# l# i# t# y#  # a# n# d#  # a# r# e#  # b# e# t# t# e# r#  # s# a# t# i# s# f# i# e# d# .

# ## ## ##  # Q# u# e# s# t# i# o# n# :#  # W# h# a# t#  # i# s#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # a# c# t# i# v# e#  # p# a# r# e# n# t# s#  # a# n# d#  # s# t# u# d# e# n# t# '# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ?

# In[115]

df.groupby(['ParentAnsweringSurvey'])['Class'].value_counts(normalize=True)

# S# o# ,#  # d# e# f# i# n# i# t# i# v# e# l# y#  # p# a# r# e# n# t# '# s#  # a# c# t# i# v# e#  # b# e# h# a# v# i# o# r#  # h# a# s#  # a# n#  # i# m# p# o# r# t# a# n# t#  # r# o# l# e#  # o# n#  # s# t# u# d# e# n# t# '# s#  # g# r# o# w# t# h# .

# ## ##  # U# n# d# e# r# s# t# a# n# d# i# n# g#  # s# t# u# d# e# n# t# '# s#  # b# e# h# a# v# i# o# r#  

# N# e# x# t# ,#  # i# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # k# n# o# w#  # w# h# a# t#  # c# h# a# r# a# c# t# e# r# i# s# t# i# c# s#  # a# r# e#  # l# i# n# k# e# d#  # t# o#  # s# t# u# d# e# n# t# s#  # s# u# c# e# s# s# .#  # S# o# ,#  # w# e# '# r# e#  # g# o# i# n# g#  # t# o#  # t# e# s# t#  # t# h# e#  # f# e# a# t# u# r# e# s#  # r# e# l# a# t# e# d# .

# In[116]

df2 = dataset[['gender','raisedhands','VisITedResources','AnnouncementsView','Discussion','StudentAbsenceDays', 'Class']]
df2.head()

# ## ## ##  # Q# u# e# s# t# i# o# n# :#  # W# h# a# t# '# s#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # r# a# i# s# i# n# g#  # h# a# n# d# s#  # a# n# d#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ?

# In[117]

df2['raisedhands'] = pd.cut(df2.raisedhands, bins=3, labels=np.arange(3), right=False)
df2.groupby(['raisedhands'])['Class'].value_counts(normalize=True)

# S# o# ,#  # i# t#  # s# e# e# m# s#  # t# h# a# t#  # s# t# u# d# e# n# t# s#  # w# h# i# c# h#  # h# a# s#  # l# o# w#  # l# e# v# e# l# s#  # o# f#  # r# a# i# s# i# n# g#  # h# a# n# d# s#  # a# r# e#  # m# o# s# t#  # l# i# k# e# l# y#  # t# o#  # h# a# v# e#  # L# o# w#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .#  # I# n#  # t# h# e#  # o# t# h# e# r# s# i# d# e# ,#  # h# i# g# h#  # f# r# e# q# u# e# n# c# y#  # o# f#  # r# a# i# s# i# n# g#  # h# a# n# d# s#  # a# r# e#  # l# i# n# k# e# d#  # t# o#  # h# i# g# h# e# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .

# N# e# x# t# ,#  # w# e# '# r# e#  # g# o# i# n# g#  # t# o#  # c# h# e# c# k#  # t# h# e#  # a# c# t#  # o# f#  # v# i# s# i# t# i# n# g#  # t# h# e#  # c# o# u# r# s# e#  # r# e# s# o# u# r# c# e# s# .

# In[118]

df2['VisITedResources'] = pd.cut(df2.VisITedResources, bins=3, labels=np.arange(3), right=False)
df2.groupby(['VisITedResources'])['Class'].value_counts(normalize=True)

# L# o# w#  # l# e# v# e# l# s#  # o# f#  # r# e# s# o# u# r# c# e#  # e# x# p# l# o# r# i# n# g#  # m# e# a# n# s#  # l# o# w# e# r#  # l# e# v# e# l# s#  # o# f#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .#  # H# i# g# h#  # l# e# v# e# l# s#  # o# f#  # v# i# s# i# t# i# n# g#  # r# e# s# o# u# r# c# e# s#  # a# r# e#  # l# i# n# k# e# d#  # t# o#  # h# i# g# h# e# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .

# In[119]

df2['AnnouncementsView'] = pd.cut(df2.AnnouncementsView, bins=3, labels=np.arange(3), right=False)
df2.groupby(['AnnouncementsView'])['Class'].value_counts(normalize=True)

# T# h# e#  # a# c# t#  # o# f#  # v# i# s# u# a# l# i# z# i# n# g#  # t# h# e#  # a# n# n# o# u# n# c# e# m# e# n# t# s#  # m# a# k# e# s#  # t# h# e#  # s# t# u# d# e# n# t# s#  # m# o# r# e#  # p# r# e# p# a# r# e# d#  # f# o# r#  # t# h# e#  # t# a# s# k# s#  # a# n# d#  # t# h# e# y#  # a# r# e#  # m# o# s# t#  # l# i# k# e# l# y#  # t# o#  # p# l# a# n#  # t# h# e#  # a# s# s# e# s# s# m# e# n# t# s#  # o# f#  # t# h# e#  # w# e# e# k# .#  # H# i# g# h#  # v# i# s# u# a# l# i# z# a# t# i# o# n#  # f# r# e# q# u# e# n# c# y#  # i# s#  # l# i# n# e# d# ,#  # i# n# d# e# e# d# ,#  # t# o#  # b# e# t# t# e# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# s# .

# In[120]

df2['Discussion'] = pd.cut(df2.Discussion, bins=3, labels=np.arange(3), right=False)
df2.groupby(['Discussion'])['Class'].value_counts(normalize=True)

# S# u# p# r# i# s# i# n# g# l# y# ,#  # d# i# s# c# u# s# s# i# o# n#  # f# r# e# q# u# e# n# c# y#  # i# s#  # w# e# a# k# l# y#  # l# i# n# k# e# d#  # t# o#  # h# i# g# h# e# r#  # r# e# s# u# l# t# s# ,#  # a# t#  # l# e# a# s# t# ,#  # d# i# r# e# c# t# l# y# .#  # O# f#  # c# o# u# r# s# e# ,#  # t# h# e# r# e#  # a# r# e#  # h# i# g# h# e# r#  # i# n# t# e# r# a# c# t# i# o# n# s#  # l# e# v# e# l# s#  # o# c# r# r# i# n# g#  # w# i# t# h#  # H# i# g# h# e# r#  # g# r# a# d# e# d#  # s# t# u# d# e# n# t# s#  # b# u# t#  # t# h# e#  # d# a# t# a#  # s# h# o# w# s#  # t# h# a# t#  # d# i# s# c# u# s# s# i# o# n#  # i# s#  # a#  # s# e# c# o# n# d# a# r# y#  # a# c# t# .

# C# o# n# c# l# u# d# i# n# g#  # t# h# i# s#  # s# t# e# p#  # o# n#  # a# n# a# l# y# s# i# s# ,#  # w# e# '# r# e#  # g# o# i# n# g#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # a# b# s# e# n# c# e#  # r# a# t# e#  # w# i# t# h#  # t# h# e#  # g# r# a# d# e#  # l# e# v# e# l

# In[121]

df2.groupby(['StudentAbsenceDays'])['Class'].value_counts(normalize=True)

# A# s#  # e# x# p# e# c# t# e# d# ,#  # t# h# e#  # l# o# w# e# r#  # t# h# e#  # a# b# s# e# n# c# e#  # o# f#  # t# h# e#  # s# t# u# d# e# n# t# ,#  # t# h# e#  # h# i# g# h# e# r#  # t# e# n# d# s#  # t# o#  # b# e# c# o# m# e#  # t# h# e# i# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# .#  # L# e# t# '# s#  # k# e# e# p#  # t# h# i# s#  # f# e# a# t# u# r# e# .

# ## ## ##  # 4# .# 1# .# 1#  # C# l# u# s# t# e# r# i# n# g#  # D# a# t# a# S# e# t

# N# o# w#  # t# h# a# t#  # w# e#  # k# n# o# w#  # w# h# a# t#  # a# r# e#  # t# h# e#  # i# m# p# o# r# t# a# n# t#  # f# e# a# t# u# r# e# s#  # t# o#  # u# n# d# e# r# s# t# a# n# d#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # b# e# h# a# v# i# o# r#  # a# n# d#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n# ,#  # w# e# '# r# e#  # g# o# i# n# g#  # t# o#  # b# u# i# l# d#  # a#  # d# a# t# a# s# e# t#  # f# o# r#  # a#  # K# -# M# e# a# n# s#  # a# l# g# o# r# i# t# h# m# ,#  # w# h# i# c# h#  # w# i# l# l#  # s# h# o# w#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # c# l# u# s# t# e# r# .

# T# o#  # m# a# k# e#  # t# h# e#  # c# o# n# s# t# r# u# c# t# i# o# n#  # p# r# o# c# e# s# s#  # e# a# s# i# e# s# t#  # t# o#  # u# n# d# e# r# s# t# a# n# d# ,#  # w# e# '# r# e#  # g# o# i# n# g#  # t# o#  # r# e# i# m# p# l# e# m# e# n# t#  # t# h# e#  # d# a# t# a# s# e# t#  # b# u# i# l# d# i# n# g#  # p# h# a# s# e# s# .

# In[122]

df2 = dataset[['gender','raisedhands','VisITedResources','AnnouncementsView','Discussion','StudentAbsenceDays', 'Class']]
df2.tail()


# L# e# t# '# s#  # i# d# e# n# t# i# f# y#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n# s#  # b# e# t# w# e# e# n#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # a# c# t# i# o# n# s

# In[123]

correlation = df2[['raisedhands','VisITedResources','AnnouncementsView','Discussion']].corr(method='pearson')
correlation

# T# h# i# s#  # m# a# d# e#  # c# l# e# a# r#  # t# h# a# t#  # o# u# r#  # b# e# s# t#  # c# o# r# r# e# l# a# t# e# d#  # f# e# a# t# u# r# e# s#  # a# r# e#  # r# a# i# s# e# d# H# a# n# d# s#  # a# n# d#  # v# i# s# i# t# e# d# R# e# s# o# u# r# c# e# s# ,#  # w# h# i# c# h#  # w# i# l# l#  # c# o# m# p# o# s# e#  # o# u# r#  # m# o# d# e# l#  # d# a# t# a# s# e# t#  # f# u# r# t# h# e# r# .

# S# o# ,#  # w# e#  # n# e# e# d#  # a# n#  # <# b# ># o# n# e#  # h# o# t#  # e# n# c# o# d# i# n# g# <# /# b# >#  # o# n#  # c# o# l# u# m# n# s#  # g# e# n# d# e# r# ,# a# b# s# e# n# c# e#  # a# n# d#  # c# l# a# s# s

# In[124]

df2 = pd.concat([df2,pd.get_dummies(df2['gender'], prefix='gender_')], axis=1)
df2 = pd.concat([df2,pd.get_dummies(df2['StudentAbsenceDays'], prefix='absence_')], axis=1)
df2 = pd.concat([df2,pd.get_dummies(df2['Class'], prefix='class_')], axis=1)

df2.drop(['gender'], axis = 1,inplace=True)
df2.drop(['StudentAbsenceDays'], axis = 1,inplace=True)
df2.drop(['Class'], axis = 1,inplace=True)

df2.head()

# In[125]

from sklearn.cluster import KMeans
from sklearn import preprocessing

X = df2[['raisedhands', 'VisITedResources']].values
#NORMALIZE OUR ARRAY
min_max_scaler = preprocessing.MinMaxScaler()
x_scaled = min_max_scaler.fit_transform(X)
#GET X AXIS
X = pd.DataFrame(x_scaled).values
X[:5]

# U# s# i# n# g#  # t# h# e#  # E# l# b# o# w#  # M# e# t# h# o# d#  # t# o#  # f# i# n# d#  # t# h# e#  # b# e# s# t#  # K#  # f# o# r#  # K# m# e# a# n# s#  # b# a# s# e# d#  # o# n#  # o# u# r#  # d# a# t# a

# In[127]

wcss = []
 
for i in range(1, 11):
    kmeans = KMeans(n_clusters = i, init = 'k-means++')
    kmeans.fit(X)
    #print (i,kmeans.inertia_)
    wcss.append(kmeans.inertia_)  
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method')
plt.xlabel('N of Clusters')
plt.ylabel('WSS') #within cluster sum of squares
plt.show()

# S# o# ,#  # t# h# e#  # i# d# e# a# l#  # K#  # i# s#  # 3# .#  # N# o# w#  # w# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # b# u# i# l# d#  # t# h# e#  # K# m# e# a# n# s#  # w# i# t# h#  # k# =# 3

# In[128]

kmeans = KMeans(n_clusters = 3, init = 'k-means++')
kmeans.fit(X)

# In[129]

k_means_labels = kmeans.labels_
k_means_cluster_centers = kmeans.cluster_centers_

# In[130]

import matplotlib.pyplot as plt

plt.scatter(X[:, 0], X[:,1], s = 10, c = kmeans.labels_)
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s = 30, c = 'red',label = 'Centroids')
plt.title('Students Clustering')
plt.xlabel('RaisedHands')
plt.ylabel('VisITedResources')
plt.legend()

plt.show()

# S# o# ,#  # n# o# w#  # w# e#  # c# a# n#  # s# e# e#  # 3#  # c# l# u# s# t# e# r# s# :#  # 
# *#  # H# i# g# h#  # a# p# p# l# i# e# d#  # S# t# u# d# e# n# t# s# 
# *#  # M# i# d#  # A# p# p# l# i# e# d#  # S# t# u# d# e# n# t# s# 
# *#  # L# o# w#  # A# p# p# l# i# e# d#  # S# t# u# d# e# n# t# s

# ## ## ##  # 4# .# 1# .# 2#  # B# u# i# l# d# i# n# g#  # a#  # s# u# p# e# r# v# i# s# e# d#  # a# l# g# o# r# i# t# h# m

# N# o# w#  # i# t# '# s#  # t# i# m# e#  # t# o#  # b# u# i# l# d#  # a#  # m# o# d# e# l#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # s# t# u# d# e# n# t# '# s#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # b# a# s# e# d#  # o# n#  # h# i# s#  # a# c# t# i# o# n# s#  # o# n#  # t# h# e#  # O# n# l# i# n# e#  # L# e# a# r# n# i# n# g#  # e# n# v# i# r# o# m# e# n# t# .

# In[131]

df3 = dataset[['raisedhands','VisITedResources','AnnouncementsView','Discussion','Class']]
df3.head()

# E# x# t# r# a# c# t#  # o# u# r#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e#  # Y

# In[132]

y = df3['Class'].values
y[0:5]


X = df3[['raisedhands', 'VisITedResources', 'AnnouncementsView', 'Discussion']].values
X= preprocessing.StandardScaler().fit(X).transform(X)
X[:5]


from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4003177.npy", { "accuracy_score": score })

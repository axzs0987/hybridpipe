import pandas as pd
# ## ## ##  # L# o# a# d#  # n# e# c# e# s# s# a# r# y#  # l# i# b# r# a# r# i# e# s

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
from statsmodels.formula.api import ols
pd.set_option('precision', 3)
import seaborn as sns

# ## ## ##  # L# o# a# d# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

wine = pd.read_csv("../input/winequality-red.csv")
wine.head()

# ## ## ##  # D# a# t# a#  # e# x# p# l# o# r# a# t# i# o# n

# In[None]

wine[pd.isnull(wine).any(axis=1)]

# In[None]

# Dropping the null rows
wine.dropna(axis=0,inplace=True)

# In[None]

wine.describe()

# In[None]

wine.quality.value_counts()
#plt.hist(wine.quality)

# ## ## ## ##  # C# O# M# M# E# N# T#  # :#  # H# i# g# h# l# y#  # i# m# b# a# l# a# n# c# e#  # c# l# a# s# s# e# s#  # w# i# t# h#  # m# a# j# o# r# i# t# y#  # b# e# i# n# g#  # 5#  # &#  # 6

# In[None]

plt.figure(figsize=(10,5))

cor = wine.corr()
mask = np.zeros_like(cor, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

sns.heatmap(cor,mask=mask,annot=True)

# ## ## ## ##  # C# O# M# M# E# N# T#  # :#  # A#  # f# e# w#  # v# a# r# i# a# b# l# e# s#  # l# i# k# e#  # f# i# x# e# d#  # a# c# i# d# i# t# y# ,#  # p# H# ,#  # t# o# t# a# l#  # &#  # f# i# x# e# d#  # s# u# l# p# h# u# r#  # d# i# o# x# i# d# e#  # a# r# e#  # c# o# r# r# e# l# a# t# e# d#  # a# s#  # e# x# p# e# c# t# e# d#  # b# u# t#  # c# o# r# r# e# l# a# t# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t#  # a# i# n# '# t#  # r# e# a# l# l# y#  # h# i# g# h#  # s# o#  # a# s#  # t# o#  # d# r# o# p#  # t# h# e# m#  # f# r# o# m#  # t# h# e#  # d# a# t# a# s# e# t# .#  # S# o#  # w# e#  # w# i# l# l#  # c# o# n# s# i# d# e# r#  # a# l# l#  # t# h# e#  # v# a# r# i# a# b# l# e# s#  # t# o#  # b# e#  # t# h# e#  # p# a# r# t#  # o# f#  # o# u# r#  # t# r# a# i# n# i# n# g#  # d# a# t# a

# In[None]

wine.groupby('quality').mean()

# In[None]

plt.figure(figsize=(25,35))
i=1
for col in wine.columns[:-1] :
    plt.subplot(4,3,i)
    sns.boxplot(x='quality',y=col,data=wine)
    i = i+1

# ## ## ## ##  # C# O# M# M# E# N# T#  # :#  # E# x# c# e# p# t#  # f# o# r#  # a# l# l#  # 3#  # k# i# n# d# s#  # o# f#  # a# c# i# d# i# t# i# e# s#  # &#  # a# l# c# o# h# o# l# ,#  # t# h# e# r# e#  # a# i# n# '# t#  # m# u# c# h#  # t# r# e# n# d#  # b# e# t# w# e# e# n#  # q# u# a# l# i# t# y#  # o# f#  # w# i# n# e#  # a# n# d#  # t# h# e#  # v# a# r# i# a# b# l# e# s# .#  # T# h# e# r# e#  # a# r# e# ,#  # t# h# o# u# g# h# ,#  # h# u# g# e#  # n# u# m# b# e# r#  # o# f#  # o# u# t# l# i# e# r# s#  # i# n#  # a#  # f# e# w#  # v# a# r# i# a# b# l# e# s# .

# ## ## ##  # S# p# l# i# t# t# i# n# g#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t

# In[None]

from sklearn.model_selection import train_test_split
x = wine.drop('quality',axis=1)
y = wine.quality

# ## ## ##  # S# t# a# n# d# a# r# d# i# s# e#  # t# h# e#  # t# r# a# i# n# i# n# g#  # a# n# d#  # t# e# s# t# i# n# g#  # d# a# t# a#  # a# n# d#  # o# v# e# r# s# a# m# p# l# i# n# g#  # u# s# i# n# g#  # S# M# O# T# E

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4043453.npy", { "accuracy_score": score })

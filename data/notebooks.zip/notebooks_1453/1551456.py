import pandas as pd
# *# *# H# i# .#  # I#  # a# m#  # l# e# a# r# n# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# n# d#  # w# a# n# t#  # t# o#  # s# h# a# r# e#  # w# h# a# t#  # i#  # l# e# a# r# n# .#  # I#  # h# o# p# e#  # l# i# k# e#  # t# h# i# s#  # k# e# r# n# e# l# .# *# *

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# L# i# n# e# a# r#  # R# e# g# r# e# s# s# i# o# n# *# *# 
# 
# W# e#  # a# r# e#  # g# o# i# n# g#  # t# o#  # s# t# a# r# t#  # w# i# t# h#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .# 
# 
# F# i# r# s# t# l# y#  # i#  # a# m#  # g# o# i# n# g#  # t# o#  # c# r# e# a# t# e#  # a#  # d# a# t# a# s# e# t#  # a# n# d#  # s# e# t#  # u# p#  # a#  # m# o# d# e# l#  # o# f#  # b# a# s# i# c#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .# 
# 
# L# e# t# s#  # s# t# a# r# t# .# .

# In[None]

#Create a simple dataset from dictionary.
dictionary_1 = {"dogru_soru_sayisi":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
              "puan":[10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200]}
data_1 = pd.DataFrame(dictionary_1)
data_1.head(20)

# In[None]

#Visualize the data
plt.scatter(data_1.dogru_soru_sayisi,data_1.puan)
plt.xlabel("dogru_soru_sayisi")
plt.ylabel("puan")
plt.show()

# N# i# c# e# .# .# .# 
# 
# N# o# w#  # w# e#  # m# a# k# e#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# .

# In[None]

#Lets look a type
type(data_1.dogru_soru_sayisi)

# In[None]

#Want a array
x = data_1.dogru_soru_sayisi.values
y = data_1.puan.values

# In[None]

type(x)

# In[None]

#How we x of shape?
x.shape

# In[None]

#Want shape (20,1)
x = data_1.dogru_soru_sayisi.values.reshape(-1,1)
y = data_1.puan.values.reshape(-1,1)

# In[None]

x.shape

# W# e#  # o# r# g# a# n# i# z# e# d#  # x#  # a# n# d#  # y# .

# In[None]

#We need sklearn library
from sklearn.linear_model import LinearRegression
lr = LinearRegression()

# A#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n#  # l# i# n# e#  # h# a# s#  # a# n#  # e# q# u# a# t# i# o# n#  # o# f#  # t# h# e#  # f# o# r# m#  # Y#  # =#  # a#  # +#  # b# X# ,#  # w# h# e# r# e#  # X#  # i# s#  # t# h# e#  # e# x# p# l# a# n# a# t# o# r# y#  # v# a# r# i# a# b# l# e#  # a# n# d#  # Y#  # i# s#  # t# h# e#  # d# e# p# e# n# d# e# n# t#  # v# a# r# i# a# b# l# e# .#  # T# h# e#  # s# l# o# p# e#  # o# f#  # t# h# e#  # l# i# n# e#  # i# s#  # b# ,#  # a# n# d#  # a#  # i# s#  # t# h# e#  # i# n# t# e# r# c# e# p# t#  # (# t# h# e#  # v# a# l# u# e#  # o# f#  # y#  # w# h# e# n#  # x#  # =#  # 0# )# .

# In[None]

#We should make fit
lr.fit(x,y)
#Visualize
plt.scatter(x,y)
plt.xlabel("dogru_soru_sayisi")
plt.ylabel("puan")
#We should make predict
y_head = lr.predict(x)
#Visualize
plt.plot(x,y_head, color = "red")
plt.show()

# *# *# P# o# l# y# n# o# m# i# a# l#  # L# i# n# e# a# r#  # R# e# g# r# e# s# s# i# o# n# *# *# 
# 
# I# n#  # s# o# m# e#  # c# a# s# e# s# ,#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # v# a# r# i# a# b# l# e# s#  # m# a# y#  # n# o# t#  # b# e#  # l# i# n# e# a# r# .#  # I# n#  # t# h# e# s# e#  # c# a# s# e# s# ,#  # p# o# l# y# n# o# m# i# a# l#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # u# s# e# d# .

# In[None]

#Create a simple dataset from dictionary.
dictionary_2 = {"enerji":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
                "guc":[10,22,34,46,56,61,70,83,97,100,101,104,109,109,118,120,123,123,123,124]}
data_2 = pd.DataFrame(dictionary_2)
data_2.head(20)

# S# o# m# e# t# i# m# e# s# ,#  # a#  # p# l# o# t#  # o# f#  # t# h# e#  # r# e# s# i# d# u# a# l# s#  # v# e# r# s# u# s#  # a#  # p# r# e# d# i# c# t# o# r#  # m# a# y#  # s# u# g# g# e# s# t#  # t# h# e# r# e#  # i# s#  # a#  # n# o# n# l# i# n# e# a# r#  # r# e# l# a# t# i# o# n# s# h# i# p# .#  # O# n# e#  # w# a# y#  # t# o#  # t# r# y#  # t# o#  # a# c# c# o# u# n# t#  # f# o# r#  # s# u# c# h#  # a#  # r# e# l# a# t# i# o# n# s# h# i# p#  # i# s#  # t# h# r# o# u# g# h#  # a#  # p# o# l# y# n# o# m# i# a# l#  # r# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l# .#  # S# u# c# h#  # a#  # m# o# d# e# l#  # f# o# r#  # a#  # s# i# n# g# l# e#  # p# r# e# d# i# c# t# o# r# .# 
# 
# Y# =# β# 0# +# β# 1# *# X# +# β# 2# *# X# ^# 2# +# …# +# β# h# *# X# ^# h# 
# 
# w# h# e# r# e#  # h#  # i# s#  # c# a# l# l# e# d#  # t# h# e#  # d# e# g# r# e# e#  # o# f#  # t# h# e#  # p# o# l# y# n# o# m# i# a# l# .#  # F# o# r#  # l# o# w# e# r#  # d# e# g# r# e# e# s# ,#  # t# h# e#  # r# e# l# a# t# i# o# n# s# h# i# p#  # h# a# s#  # a#  # s# p# e# c# i# f# i# c#  # n# a# m# e#  # (# i# .# e# .# ,#  # h#  # =#  # 2#  # i# s#  # c# a# l# l# e# d#  # q# u# a# d# r# a# t# i# c# ,#  # h#  # =#  # 3#  # i# s#  # c# a# l# l# e# d#  # c# u# b# i# c# ,#  # h#  # =#  # 4#  # i# s#  # c# a# l# l# e# d#  # q# u# a# r# t# i# c# ,#  # a# n# d#  # s# o#  # o# n# )# .#  # A# l# t# h# o# u# g# h#  # t# h# i# s#  # m# o# d# e# l#  # a# l# l# o# w# s#  # f# o# r#  # a#  # n# o# n# l# i# n# e# a# r#  # r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # Y#  # a# n# d#  # X# ,#  # p# o# l# y# n# o# m# i# a# l#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # s# t# i# l# l#  # c# o# n# s# i# d# e# r# e# d#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n#  # s# i# n# c# e#  # i# t#  # i# s#  # l# i# n# e# a# r#  # i# n#  # t# h# e#  # r# e# g# r# e# s# s# i# o# n#  # c# o# e# f# f# i# c# i# e# n# t# s

# In[None]

#How we make polynomial regression on python?
x2 = data_2.enerji.values.reshape(-1,1)
y2 = data_2.guc.values.reshape(-1,1)
#Library
from sklearn.linear_model import LinearRegression
lr2 = LinearRegression() 
#Fit
lr2.fit(x2,y2)
#Visualize
plt.scatter(x2,y2, color = "blue") #our values
plt.ylabel("guc")
plt.xlabel("enerji")
#Predict
y_head2 = lr.predict(x2)
#Visualize
plt.plot(x2, y_head2 , color="red" )  #that does not represent our values well

#Library
from sklearn.preprocessing import PolynomialFeatures
polynomial_regression = PolynomialFeatures(degree = 4)  #degree of the polynomial
#Fit
x_polynomial = polynomial_regression.fit_transform(x2)
lr3 = LinearRegression()
lr3.fit(x_polynomial,y2)
#Predict
y_head3 = lr3.predict(x_polynomial)
#Visualize
plt.plot(x2,y_head3, color = "green")  #this is better
plt.show()


# *# *# D# e# c# i# s# i# o# n#  # T# r# e# e#  # R# e# g# r# e# s# s# i# o# n# *# *# 
# 
# D# e# c# i# s# i# o# n#  # T# r# e# e# s#  # a# r# e#  # a#  # t# y# p# e#  # o# f#  # S# u# p# e# r# v# i# s# e# d#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g# ,#  # w# h# e# r# e#  # d# a# t# a#  # i# s#  # c# o# n# s# t# a# n# t# l# y#  # d# i# v# i# d# e# d#  # a# c# c# o# r# d# i# n# g#  # t# o#  # a#  # c# e# r# t# a# i# n#  # p# a# r# a# m# e# t# e# r# .#  # T# h# e#  # t# r# e# e#  # c# a# n#  # b# e#  # e# x# p# l# a# i# n# e# d#  # b# y#  # t# w# o#  # e# n# t# i# t# i# e# s# ,#  # d# e# c# i# s# i# o# n#  # n# o# d# e# s#  # a# n# d#  # l# e# a# v# e# s# .#  # L# e# a# v# e# s#  # a# r# e#  # d# e# c# i# s# i# o# n# s#  # o# r#  # f# i# n# a# l#  # r# e# s# u# l# t# s# .#  # A# n# d#  # t# h# e#  # d# e# c# i# s# i# o# n#  # n# o# d# e# s#  # s# h# o# w#  # w# h# e# r# e#  # t# h# e#  # d# a# t# a#  # i# s#  # d# i# v# i# d# e# d# .

# In[None]

#How we use decision tree regression on python?
#We used the data(data_1) we created above.
x = data_1.dogru_soru_sayisi.values.reshape(-1,1)
y = data_1.puan.values.reshape(-1,1)
#Library
from sklearn.tree import DecisionTreeRegressor
dtr = DecisionTreeRegressor()
#Fit
dtr.fit(x,y)
#Step
x_ = np.arange(min(x),max(x),0.01).reshape(-1,1)
#Predict
y_head4 = dtr.predict(x_)
#Visualize
plt.scatter(x,y,color = "red")
plt.plot(x_,y_head4, color = "green")
plt.show()



# *# *# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n# *# *# 
# 
# T# h# e#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # p# r# e# d# i# c# t# s#  # t# h# e#  # l# i# k# e# l# i# h# o# o# d#  # o# f#  # a#  # r# e# s# u# l# t#  # t# h# a# t#  # c# a# n#  # o# n# l# y#  # h# a# v# e#  # t# w# o#  # v# a# l# u# e# s# .# T# h# e#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # p# r# o# d# u# c# e# s#  # a#  # l# o# g# i# s# t# i# c#  # c# u# r# v# e#  # t# h# a# t#  # i# s#  # l# i# m# i# t# e# d#  # t# o#  # v# a# l# u# e# s#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .#  # L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # i# s#  # s# i# m# i# l# a# r#  # t# o#  # a#  # l# i# n# e# a# r#  # r# e# g# r# e# s# s# i# o# n# ,#  # e# x# c# e# p# t#  # t# h# a# t#  # t# h# e#  # c# u# r# v# e#  # i# s#  # c# o# n# s# t# r# u# c# t# e# d#  # u# s# i# n# g#  # t# h# e#  # n# a# t# u# r# a# l#  # l# o# g# a# r# i# t# h# m#  # o# f#  # t# h# e#  # p# r# o# b# a# b# i# l# i# t# i# e# s#  # o# f#  # t# h# e#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # i# n# s# t# e# a# d#  # o# f#  # p# r# o# b# a# b# i# l# i# t# y# .

# In[None]

#We build data frames from csv.
df = pd.read_csv("../input/voice.csv")

# In[None]

df.head()

# In[None]

df.info()

# In[None]

#df = pd.read_csv("../input/voice.csv")
df.label.unique()

# W# e#  # n# e# e# d#  # t# o#  # t# r# a# n# s# f# o# r# m#  # t# h# e#  # o# u# t# p# u# t#  # o# f#  # t# h# e#  # l# a# b# e# l# s#  # w# e#  # h# a# v# e#  # i# n# t# o#  # 0#  # a# n# d#  # 1# .

# In[None]

df.label = [ 1 if each == "male" else 0 for each in df.label]
df.label.unique()

# In[None]

y = df.label.values
x_df = df.drop(["label"], axis = 1)

# *# *# N# o# r# m# a# l# i# z# a# t# i# o# n# *# *# 
# 
# R# e# s# c# a# l# i# n# g#  # d# a# t# a#  # t# o#  # h# a# v# e#  # v# a# l# u# e# s#  # b# e# t# w# e# e# n#  # 0#  # a# n# d#  # 1# .#  # T# h# i# s#  # i# s#  # u# s# u# a# l# l# y#  # c# a# l# l# e# d#  # f# e# a# t# u# r# e#  # s# c# a# l# i# n# g# .#  # O# n# e#  # p# o# s# s# i# b# l# e#  # f# o# r# m# u# l# a#  # t# o#  # a# c# h# i# e# v# e#  # t# h# i# s#  # i# s# :# 
# *# *# (# x#  # -#  # m# i# n# (# x# )# )# /# (# m# a# x# (# x# )# -# m# i# n# (# x# )# )# *# *#  

# In[None]

#Normalization on python
x = (x_df - np.min(x_df))/(np.max(x_df) - np.min(x_df)).values


# W# e#  # b# u# i# l# d#  # x# _# t# r# a# i# n#  # f# r# o# m#  # %# 8# 0#  # o# f#  # o# u# r#  # d# a# t# a#  # a# n# d#  # x# _# t# e# s# t#  # f# r# o# m#  # %# 2# 0#  # o# f#  # o# u# r#  # d# a# t# a# .#  # X# _# t# r# a# i# n#  # w# i# l# l#  # l# e# a# r# n#  # a# n# d#  # a# r# r# i# v# e#  # y# _# t# r# a# i# n# .#  # L# a# t# e# r#  # x# _# t# e# s# t#  # w# i# l# l#  # a# r# r# i# v# e#  # y# _# t# e# s# t#  # s# a# m# e#  # w# a# y# .

# In[None]

#Train test split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1551456.npy", { "accuracy_score": score })

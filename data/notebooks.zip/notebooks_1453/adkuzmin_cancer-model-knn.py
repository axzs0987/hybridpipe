import numpy as np 
import pandas as pd 
import os
#for dirname, _, filenames in os.walk('/kaggle/input'):
#    for filename in filenames:
#        print(os.path.join(dirname, filename))
from mlxtend.plotting import plot_decision_regions
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#sns.set()
mock = pd.read_csv('../input/prostate-cancer/Prostate_Cancer.csv')
mock.head(30)
mock.describe()
mock = mock.replace('B', '0')
mock.head(30)
#p=sns.pairplot(mock, hue = 'diagnosis_result')
#plt.figure(figsize=(12,10))
#p=sns.heatmap(mock.corr(), annot=True,cmap ='RdYlGn') 
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X =  pd.DataFrame(sc_X.fit_transform(mock.drop(["diagnosis_result"],axis = 1),),columns=['id', 'radius', 'texture', 'parameter', 'area', 'smoothness', 'compactness', 'symmetry', 'fractal_dimension'])
X.drop(columns='id')
y = mock.diagnosis_result
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.neighbors import KNeighborsClassifier
test_scores = []
train_scores = []
for i in range(1,15):
    knn = KNeighborsClassifier(i)
#    knn.fit(X_train,y_train)
    
#    train_scores.append(knn.score(X_train,y_train))
#    test_scores.append(knn.score(X_test,y_test))
#max_train_score = max(train_scores)
#train_scores_ind = [i for i, v in enumerate(train_scores) if v == max_train_score]
#print('Max train score {} % and k = {}'.format(max_train_score*100,list(map(lambda x: x+1, train_scores_ind))))
#max_test_score = max(test_scores)
#test_scores_ind = [i for i, v in enumerate(test_scores) if v == max_test_score]
#print('Max test score {} % and k = {}'.format(max_test_score*100,list(map(lambda x: x+1, test_scores_ind))))
#plt.figure(figsize=(12,5))
#p = sns.lineplot(range(1,15),train_scores,marker='*',label='Train Score')
#p = sns.lineplot(range(1,15),test_scores,marker='o',label='Test Score')
knn = KNeighborsClassifier(10)
#knn.fit(X_train,y_train)
#knn.score(X_test,y_test)
from sklearn.metrics import confusion_matrix
#y_pred = knn.predict(X_test)
#confusion_matrix(y_test,y_pred)
#pd.crosstab(y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=True)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/adkuzmin_cancer-model-knn.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/adkuzmin_cancer-model-knn/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/adkuzmin_cancer-model-knn/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/adkuzmin_cancer-model-knn/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/adkuzmin_cancer-model-knn/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/adkuzmin_cancer-model-knn/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/adkuzmin_cancer-model-knn/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/adkuzmin_cancer-model-knn/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/adkuzmin_cancer-model-knn/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/adkuzmin_cancer-model-knn/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/adkuzmin_cancer-model-knn/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/adkuzmin_cancer-model-knn/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/adkuzmin_cancer-model-knn/testY.csv",encoding="gbk")


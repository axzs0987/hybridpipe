import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

df=pd.read_csv('../input/voicegender/voice.csv')

# In[None]

df.head(2)

# In[None]

df.info()

# In[None]

df.describe()

# In[None]

df['label']=[1 if each=='female' else 0 for each in df['label']]

# In[None]

df.head(3)

# In[None]

df.tail(3)

# In[None]

from sklearn.preprocessing import StandardScaler

# In[None]

scaler=StandardScaler()

# In[None]

scaler.fit(df.drop('label',axis=1))

# In[None]

scaled_features=scaler.transform(df.drop('label',axis=1))

# In[None]

scaled_features

# In[None]

df_feat=pd.DataFrame(scaled_features,columns=df.columns[:-1])

# In[None]

df_feat.head(3)

# In[None]

from sklearn.model_selection import train_test_split
X=df_feat
y=df['label']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/10826912.npy", { "accuracy_score": score })

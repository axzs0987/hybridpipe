import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder
wine_data = pd.read_csv("../input/redwinequality/datasets_4458_8204_winequality-red.csv")
wine_data.head()
wine_data.quality.value_counts()
wine_data.isnull().sum()
wine_data.info()
#fig = plt.figure(figsize = (10,6))
#sns.barplot(x = 'quality', y = 'fixed acidity', data = wine_data)
bins = (2, 6, 8)
group_names = ['bad', 'good']
wine_data['quality_name'] = pd.cut(wine_data['quality'], bins = bins, labels = group_names)
wine_data.head()
le = LabelEncoder()
wine_data['quality_mark'] = le.fit_transform(wine_data.quality_name)
wine_data.quality_name.value_counts()
wine_data.quality_mark.value_counts()
#for ingredients in wine_data.columns[:11]:
#    plt.title(ingredients)
#    sns.boxplot(x='quality_mark', y=ingredients, data=wine_data)
#    plt.show()
pd.plotting.scatter_matrix(wine_data.drop(['quality','quality_name','quality_mark'], axis=1), c=wine_data.quality_mark)
#sns.heatmap(wine_data.drop(['quality','quality_name'], axis=1),annot=True, cmap='YlGnBu')
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.linear_model import LinearRegression, SGDClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
X = wine_data.drop(['quality','quality_name','quality_mark'], axis=1)
y = wine_data.quality_mark
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
classifiers = [LinearRegression(), SVC(), LinearSVC(), SGDClassifier(penalty=None), RandomForestClassifier(n_estimators=100, max_depth=6)]
st_scl = StandardScaler()
X_train = st_scl.fit_transform(X_train)
X_test = st_scl.fit_transform(X_test)
train_model = []
#for classes in classifiers:
#    classes.fit(X_train, y_train)
#    train_score = classes.score(X_train, y_train)
#    test_score = classes.score(X_test, y_test)
#    train_model.append([classes, train_score, test_score])
#for train_score in train_model:
#    if train_score[1]<0.88:
#        train_model.remove(train_score)
#train_model
#train_model[0][0].fit(X_train, y_train)
#y_predict_svc = train_model[0][0].predict(X_test)
#print(accuracy_score(y_test, y_predict_svc))
#print(classification_report(y_test, y_predict_svc))
#train_model[1][0].fit(X_train, y_train)
#y_predict_lsvc = train_model[1][0].predict(X_test)
#print(accuracy_score(y_test, y_predict_lsvc))
#print(classification_report(y_test, y_predict_lsvc))
#train_model[2][0].fit(X_train, y_train)
#y_predict_rfc = train_model[2][0].predict(X_test)
#print(accuracy_score(y_test, y_predict_rfc))
#print(classification_report(y_test, y_predict_rfc))
params = {
    'C': list(np.linspace(0.1,2,20)),    'kernel':['linear', 'rbf'],    'gamma' :list(np.linspace(0.1,2,20))
}
svc=SVC()
grid_svc = GridSearchCV(estimator=svc, param_grid=params, scoring='roc_auc', cv=5, refit=True, return_train_score=True)
#grid_svc.fit(X_train, y_train)
#grid_svc.best_params_
svc_new = SVC(C=0.8999999999999999, gamma=1.0999999999999999, kernel='rbf')
#svc_new.fit(X_train, y_train)
#y_predict = svc_new.predict(X_test)
#accuracy_score(y_test, y_predict)
#print(classification_report(y_test, y_predict))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/arkajitmajumder_wine-quality-model-building.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/arkajitmajumder_wine-quality-model-building/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/arkajitmajumder_wine-quality-model-building/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/arkajitmajumder_wine-quality-model-building/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/arkajitmajumder_wine-quality-model-building/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/arkajitmajumder_wine-quality-model-building/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ##  #  #  #  # P# r# e# v# i# s# ã# o#  # d# e#  # *# D# e# f# a# u# l# t# *#  # e# m#  # F# i# n# a# n# c# i# a# m# e# n# t# o#  # B# a# n# c# á# r# i# o

# ## ##  # P# o# r#  # a# l# u# n# a#  # m# a# t# r# í# c# u# l# a#  # 1# 9# 3# 1# 1# 3# 3# 0# 8# 7#  

# O#  # p# r# e# s# e# n# t# e#  # t# r# a# b# a# l# h# o#  # u# t# i# l# i# z# a#  # o#  # d# a# t# a# s# e# t#  # H# o# m# e#  # E# q# u# i# t# y#  # D# A# t# a# s# e# t# (# H# M# E# Q# )#  # d# i# s# p# o# n# í# v# e# l#  # n# o#  # K# a# g# g# l# e#  # p# a# r# a# ,#  # m# e# d# i# a# n# t# e#  # m# o# d# e# l# o#  # d# e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g# ,#  # p# r# e# v# e# r#  # o#  # D# e# f# a# u# l# t#  # o# u#  # n# ã# o#  # d# o#  # f# i# n# a# n# c# i# a# m# e# n# t# o#  # b# a# n# c# á# r# i# o#  # c# o# n# t# r# a# t# a# d# o#  # p# e# l# o#  # c# l# i# e# n# t# e# .# 
# 
# O#  # D# a# t# a# s# e# t#  # H# M# E# Q#  # a# p# r# e# s# e# n# t# a#  # i# n# f# o# r# m# a# ç# õ# e# s#  # d# e#  # 5# 9# 6# 0#  # c# o# n# t# r# a# t# a# n# t# e# s#  # e#  # d# e#  # s# e# u# s#  # f# i# n# a# n# c# i# a# m# e# n# t# o# s#  # b# a# n# c# á# r# i# o# s#  # d# i# s# t# r# i# b# u# í# d# a# s#  # n# a# s#  # 1# 2#  # v# a# r# i# á# v# e# i# s#  # a# b# a# i# x# o#  # e#  # t# a# m# b# é# m#  # a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a#  # "# B# A# D# "#  # q# u# e#  # i# n# f# o# r# m# a#  # s# e#  # o#  # c# l# i# e# n# t# e#  # d# e# i# x# o# u#  # d# e#  # h# o# n# r# a# r#  # s# e# u#  # e# m# p# r# é# s# t# i# m# o#  # (# d# e# f# a# u# l# t# )#  # o# u#  # n# ã# o# .# 
# 
# A# s#  # v# a# r# i# á# v# e# i# s#  # p# r# e# d# i# t# o# r# a# s#  # c# o# n# s# t# a# n# t# e# s#  # d# a#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # s# ã# o# :# 
# 
# *#  # L# O# A# N# :#  # V# a# l# o# r#  # d# a#  # p# a# r# c# e# l# a#  # (# v# a# l# o# r#  # $# )# ;# 
# 
# *#  # M# O# R# T# D# U# E# :#  # V# a# l# o# r#  # d# e# v# i# d# o#  # n# a#  # h# i# p# o# t# e# c# a#  # e# x# i# s# t# e# n# t# e#  # (# v# a# l# o# r#  # $# )# ;# 
# 
# *#  # V# A# L# U# E# :#  # V# a# l# o# r#  # c# o# r# r# e# n# t# e#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # f# i# n# a# n# c# i# a# d# a#  # (# v# a# l# o# r#  # $# )# ;# 
# 
# *#  # R# E# A# S# O# N# :#  # D# e# s# t# i# n# a# ç# ã# o#  # d# o#  # c# r# é# d# i# t# o#  # (# s# e#  # d# e# b# t#  # c# o# n# s# o# l# i# d# a# t# i# o# =#  # D# e# b# t# C# o# n#  # o# u#  # h# o# m# e#  # i# m# p# r# o# v# e# m# e# n# t# =#  # H# o# m# e# I# m# p# ;# 
# 
# *#  # J# O# B# :#  # O# c# u# p# a# ç# ã# o# .#  # P# o# s# s# u# i#  # s# e# x#  # c# l# a# s# s# e# s# :#  # O# t# h# e# r# ,#  # P# r# o# f# E# x# e# ,#  # O# f# f# i# c# e# ,#  # M# g# r# ,#  # S# e# l# f#  # e#  # S# a# l# e# s# ;# 
# 
# *#  # Y# O# J# :#  # A# n# o# s#  # n# o#  # e# m# p# r# e# g# o#  # a# t# u# a# l#  # (# e# m#  # a# n# o# s# )# ;# 
# 
# *#  # D# E# R# O# G# :#  # N# ú# m# e# r# o#  # d# e#  # r# e# l# a# t# ó# r# i# o# s#  # d# e# p# r# e# c# i# a# t# i# v# o# s# ;# 
# 
# *#  # D# E# L# I# N# Q# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # i# n# a# d# i# m# p# l# e# n# t# e# s# ;# 
# 
# *#  # C# L# A# G# E# :#  # I# d# a# d# e#  # d# a#  # l# i# n# h# a#  # d# e#  # c# r# é# d# i# t# o#  # m# a# i# s#  # a# n# t# i# g# a# ;# 
# 
# *#  # N# I# N# Q# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o#  # r# e# c# e# n# t# e# s# ;# 
# 
# *#  # C# L# N# O# :#  # N# ú# m# e# r# o#  # d# e#  # l# i# n# h# a# s#  # d# e#  # c# r# é# d# i# t# o# ;# 
# 
# *#  # D# E# B# T# I# C#  # :#  # R# a# z# ã# o#  # D# í# v# i# d# a# /# R# e# n# d# i# m# e# n# t# o# .# 
# 
# A#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a#  # B# A# D#  # é#  # b# i# n# á# r# i# a#  # e#  # a# p# r# e# s# e# n# t# a#  # a# s#  # s# e# g# u# i# n# t# e# s#  # c# l# a# s# s# e# s# :#  # 0#  # -#  # o#  # c# l# i# e# n# t# e#  # n# ã# o#  # f# i# c# o# u#  # i# n# a# d# i# m# p# l# e# n# t# e#  # e#  # 1#  # -#  # o#  # c# l# i# e# n# t# e#  # a# p# r# e# s# e# n# t# o# u#  # D# e# f# a# u# l# t# .#  # L# o# g# o# ,#  # é#  # e# s# t# a#  # v# a# r# i# á# v# e# l#  # q# u# e#  # c# o# n# t# e# r# á#  # a# s#  # p# r# e# v# i# s# õ# e# s#  # r# e# a# l# i# z# a# d# a# s# .# 


# ##  # 1# .#  # C# a# r# r# e# g# a# m# e# n# t# o#  # d# a#  # B# a# s# e#  # d# e#  # D# a# d# o# s#  # H# M# E# Q

# In[None]

# Carregamento do Dataset:
df = pd.read_csv('/kaggle/input/hmeq-data/hmeq.csv')
df.shape

# A#  # B# a# s# e#  # d# e#  # D# a# d# o# s#  # p# o# s# s# u# i#  # 5# 9# 6# 0#  # o# b# s# e# r# v# a# ç# õ# e# s#  # e#  # 1# 3#  # c# o# l# u# n# a# s

# In[None]

# Visualizando os dados:
df.head()

# In[None]

# Verificando uma amostra aleatória
df.sample(5)

# In[None]

# Verificando os tipos dos dados e os tamanhos
df.info()

# N# e# s# t# a#  # v# i# s# u# a# l# i# z# a# ç# ã# o# ,#  # v# e# r# i# f# i# c# a# -# s# e#  # g# r# a# n# d# e#  # q# u# a# n# t# i# d# a# d# e#  # d# e#  # c# o# l# u# n# a# s#  # c# o# m#  # d# a# d# o# s#  # '# m# i# s# s# i# n# g# '# .#  # A# l# i# á# s# ,#  # s# o# m# e# n# t# e#  # a#  # c# o# l# u# n# a#  # c# o# m#  # a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a#  # '# B# A# D#  # e#  # a#  # '# V# A# L# U# E# '#  # n# ã# o#  # d# e# m# a# n# d# a# m#  # t# r# a# t# a# m# e# n# t# o# .# 
# A# l# é# m#  # d# i# s# s# o# ,#  # h# á#  # d# u# a# s#  # v# a# r# i# á# v# e# i# s#  # d# o#  # t# i# p# o#  # '# o# b# j# e# c# t# '# ,#  # o# u#  # s# e# j# a# ,#  # n# ã# o#  # n# u# m# é# r# i# c# a# s# .#  # 
# L# o# g# o# ,#  # o#  # t# r# a# t# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s#  # s# e#  # d# e# s# t# i# n# a# r# á#  # a#  # s# o# l# u# c# i# o# n# a# r#  # e# s# t# a# s#  # d# u# a# s#  # s# i# t# u# a# ç# õ# e# s#  # p# a# r# a#  # q# u# e#  # s# e# j# a#  # v# i# á# v# e# l#  # a#  # a# p# l# i# c# a# ç# ã# o#  # d# o#  # m# o# d# e# l# o#  # e# s# c# o# l# h# i# d# o# .

# ##  # 2# .#  # T# r# a# t# a# m# e# n# t# o#  # d# o# s#  # D# a# d# o# s

# ## ##  # 2# .# 1# .#  # T# r# a# t# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s#  # F# a# l# t# a# n# t# e# s

# ## ## ##  # 2# .# 1# .# 1# .#  # E# x# c# l# u# s# ã# o#  # d# e#  # o# b# s# e# r# v# a# ç# õ# e# s#  # c# o# m#  # i# n# f# o# r# m# a# ç# õ# e# s#  # s# o# b# r# e#  # o#  # f# i# n# a# n# c# i# a# m# e# n# t# o#  # n# u# l# a# s# .# 
# 
# E# s# t# u# d# a# n# d# o#  # o# s#  # d# a# d# o# s# ,#  # e# n# t# e# n# d# e# u# -# s# e#  # q# u# e#  # a# s#  # o# b# s# e# r# v# a# ç# õ# e# s#  # o# n# d# e#  # a# s#  # v# a# r# i# á# v# e# i# s#  # '# M# O# R# T# D# U# E# '#  # (# v# a# l# o# r#  # d# e# v# i# d# o# )#  # e#  # '# V# A# L# U# E# '#  # (# v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e# )#  # e# s# t# ã# o#  # c# o# m#  # d# a# d# o# s#  # n# u# l# o# s#  # (# e# m#  # c# o# n# j# u# n# t# o# )# ,#  # d# e# v# e# m#  # s# e# r#  # e# x# c# l# u# í# d# a# s#  # p# o# i# s#  # n# ã# o#  # a# g# r# e# g# a# m#  # i# n# f# o# r# m# a# ç# õ# e# s#  # r# e# l# e# v# a# n# t# e# s#  # p# a# r# a#  # o#  # e# s# t# u# d# o#  # d# e#  # p# r# e# d# i# ç# ã# o# ,#  # p# o# d# e# n# d# o#  # a# t# é#  # d# i# s# t# o# r# c# e# r# ,#  # c# a# s# o#  # h# a# j# a#  # i# m# p# u# t# a# ç# ã# o# .# 
# 
# D# e# s# t# a#  # f# o# r# m# a# ,#  # i# n# i# c# i# a# l# m# e# n# t# e#  # s# e# r# á#  # f# e# i# t# o#  # a#  # v# e# r# i# f# i# c# a# ç# ã# o#  # d# a# s#  # o# b# s# e# r# v# a# ç# õ# e# s#  # c# o# m#  # e# s# t# a#  # c# a# r# a# c# t# e# r# í# s# t# i# c# a#  # e#  # a# p# ó# s# ,#  # s# u# a#  # e# x# c# l# u# s# ã# o# .

# In[None]

# Verificando quantas observações possuem esta característica: 
df[df['MORTDUE'].isnull() & df['VALUE'].isnull()]

# S# e# r# ã# o#  # e# x# c# l# u# í# d# o# s#  # o# s#  # 2# 7#  # r# e# g# i# s# t# r# o# s#  # q# u# e#  # p# o# s# s# u# e# m#  # e# s# t# a#  # c# a# r# a# c# t# e# r# i# s# t# i# c# a# :

# In[None]

# Usando o comando drop para excluir os registros que possuem valores nulos nas 2 varíaveis com dados 
#sobre o atual financiamento.
df.dropna(how='all', subset = ['MORTDUE', 'VALUE'], inplace=True)

# In[None]

# conferindo se o comando de exclusão deu certo: 
df[df['MORTDUE'].isnull() & df['VALUE'].isnull()]

# ## ## ##  # 2# .# 1# .# 2#  # I# m# p# u# t# a# ç# ã# o#  # d# e#  # d# a# d# o# s#  # f# a# l# t# a# n# t# e# s# 
# 


# ## ## ## ##  # V# A# R# I# Á# V# E# I# S#  # M# O# R# T# D# U# E#  # E#  # V# A# L# U# E# 
# A# i# n# d# a#  # e# x# i# s# t# e# m#  # m# u# i# t# o# s#  # c# a# s# o# s#  # d# e#  # v# a# l# o# r# e# s#  # n# u# l# o# s#  # n# a# s#  # c# o# l# u# n# a# s#  # '# M# O# R# T# D# U# E# '#  # e#  # '# V# A# L# U# E# '# .#  # P# a# r# a#  # i# m# p# u# t# a# r#  # o# s#  # v# a# l# o# r# e# s#  # d# e# s# t# a# s#  # c# o# l# u# n# a# s#  # a# d# o# t# a# r# e# m# o# s#  # o#  # s# e# g# u# i# n# t# e# :# 
# C# a# s# o#  # d# e#  # n# u# l# o#  # n# o#  # v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # (# V# A# L# U# E# )# :#  # S# e# r# á#  # i# m# p# u# t# a# d# o#  # o#  # v# a# l# o# r#  # d# a#  # d# í# v# i# d# a#  # a# t# u# a# l#  # (# M# O# R# T# D# U# E# )# ,#  # g# a# r# a# n# t# i# n# d# o#  # a# s# s# i# m#  # q# u# e#  # o#  # v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # s# e# r# á#  # a# o#  # m# e# n# o# s#  # o#  # v# a# l# o# r#  # d# a#  # d# í# v# i# d# a# .# 
# C# a# s# o#  # d# e#  # n# u# l# o#  # n# o#  # v# a# l# o# r#  # d# a#  # d# í# v# i# d# a#  # a# u# t# a# l#  # (# M# O# R# T# D# U# E# )# :#  # S# e# r# á#  # i# m# p# u# t# a# d# o#  # o#  # v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # g# a# r# a# n# t# i# d# o# r# a#  # d# a#  # o# p# e# r# a# ç# ã# o# ,#  # c# o# n# s# i# d# e# r# a# n# d# o#  # a# s# s# i# m#  # o#  # v# a# l# o# r#  # d# a#  # p# r# o# p# r# i# e# d# a# d# e#  # c# o# m# o#  # v# a# l# o# r#  # e# s# t# i# m# a# d# o#  # d# o#  # f# i# n# a# n# c# i# a# m# e# n# t# o# .

# In[None]

# verificando a quantidade de casos enquadrados nesta situação (nulo em MORTDUE ou VALUE:
df[df['MORTDUE'].isnull() | df['VALUE'].isnull()]

# A# q# u# i#  # s# e#  # v# e# r# i# f# i# c# a#  # q# u# e#  # q# u# a# s# e#  # 1# 0# %#  # d# a#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # e# n# c# o# n# t# r# a# -# s# e#  # n# e# s# t# a#  # s# i# t# u# a# ç# ã# o#  # (# 5# 7# 6#  # r# e# g# i# s# t# r# o# s# )# .

# In[None]

# imputando o valor da Propriedade pelo valor da dívida:
df['VALUE'] = df.apply(lambda row: row['MORTDUE'] if np.isnan(row['VALUE']) else row['VALUE'],axis=1)

# In[None]

# imputando o valor da dívida pelo valor da propriedade: 
df['MORTDUE'] = df.apply(lambda row: row['VALUE'] if np.isnan(row['MORTDUE']) else row['MORTDUE'],axis=1)

# In[None]

# Conferindo que não existem mais registros com valores nulos nas colunas MORTDUE e VALUE:
df[df['MORTDUE'].isnull() | df['VALUE'].isnull()]

# In[None]

# Verificando os primeiros dados após efeito da imputação
df.head(10)

# In[None]

# Verificando como ficou o Dataset após esta primeira imputação:
df.info()

# A#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # f# i# c# o# u#  # c# o# m#  # 2# 7#  # r# e# g# i# s# t# r# o# s#  # a#  # m# e# n# o# s# ,#  # c# o# m#  # n# e# n# h# u# m#  # v# a# l# o# r#  # n# u# l# o#  # n# a# s#  # q# u# a# t# r# o#  # p# r# i# m# e# i# r# a# s#  # c# o# l# u# n# a# s# .

# V# A# R# I# Á# V# E# L#  # '# R# E# A# S# O# N# '

# In[None]

# Verificando a quantidade de dados nulos:
df[df['REASON'].isnull()]

# V# e# r# i# f# i# c# a# -# s# e#  # 2# 4# 2#  # c# o# m#  # d# a# d# o#  # n# u# l# o#  # n# a#  # v# a# r# i# á# v# e# l#  # '# R# E# A# S# O# N# '# .

# In[None]

# Verificando as classes da variável 'REASON' e a frequência de cada um delas.
df['REASON'].value_counts()

# A# q# u# i#  # v# e# r# i# f# i# c# a# -# s# e#  # q# u# e#  # a#  # m# a# i# o# r#  # f# r# e# q# u# ê# n# c# i# a#  # é#  # d# a#  # c# l# a# s# s# e#  # '# D# e# b# t# C# o# n# '# .

# C# o# m# o#  # a# p# o# i# o#  # à#  # d# e# c# i# s# ã# o#  # s# o# b# r# e#  # i# m# p# u# t# a# r#  # o# s#  # d# a# d# o# s#  # m# i# s# s# i# n# g#  # d# a#  # v# a# r# i# á# v# e# l#  # '# R# E# A# S# O# N# '#  # p# e# l# o#  # v# a# l# o# r#  # d# a#  # c# l# a# s# s# e#  # c# o# m#  # m# a# i# o# r#  # f# r# e# q# u# ê# n# c# i# a# ,#  # d# e# c# i# d# i# u# -# s# e#  # v# e# r# i# f# i# c# a# r#  # e# m#  # u# m# a#  # t# a# b# e# l# a#  # c# r# u# z# a# d# a#  # s# e#  # a# s#  # c# l# a# s# s# e# s#  # d# e# s# t# a#  # v# a# r# i# á# v# e# l#  # a# p# r# e# s# e# n# t# a# m#  # g# r# a# n# d# e#  # d# i# f# e# r# e# n# ç# a#  # d# e#  # p# r# o# p# o# r# ç# ã# o#  # n# a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a# .#  # U# m#  # d# e# s# p# r# o# p# o# r# ç# ã# o#  # i# n# d# i# c# a# r# i# a#  # t# e# n# t# a# r#  # o# u# t# r# o#  # m# é# t# o# d# o#  # p# a# r# a#  # i# m# p# u# t# a# ç# ã# o#  # v# i# s# t# o#  # a#  # p# o# s# s# i# b# i# l# i# d# a# d# e#  # d# e#  # d# i# s# t# o# r# ç# ã# o#  # n# a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a# .#  #  

# In[None]

# Verificando as proporção dos dados distribuídos entre as variáveis 'REASON' e 'BAD':
totals=pd.crosstab(df['REASON'],df['BAD'],margins=True).reset_index()
percentages = pd.crosstab(df['REASON'],
   df['BAD']).apply(lambda row: row/row.sum(),axis=1).reset_index()
totals



# In[None]

# Verificando os percentuais cruzados entre 'REASON' e 'BAD':
percentages

# A#  # a# n# á# l# i# s# e#  # d# a#  # t# a# b# e# l# a#  # c# r# u# z# a# d# a#  # m# o# s# t# r# o# u#  # p# o# u# c# o#  # d# e# s# b# a# l# a# n# c# e# a# m# e# n# t# o#  # e# n# t# r# e#  # c# l# a# s# s# e# s#  # d# a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a#  # (# 0# ,# 1# 8#  # e#  # 0# ,# 2# 1# )# ,#  # e# n# t# ã# o#  # o# p# t# o# u# -# s# e#  # p# e# l# a#  # i# m# p# u# t# a# ç# ã# o#  # u# s# a# n# d# o#  # a#  # c# l# a# s# s# e#  # d# e#  # m# a# i# o# r#  # f# r# e# q# u# ê# n# c# i# a# ,#  # '# D# e# b# t# C# o# n# '# ,#  # p# a# r# a#  # o#  # t# r# a# t# a# m# e# n# t# o#  # d# o# s#  # d# a# d# o# s#  # m# i# s# s# i# n# g# .

# In[None]

# Realizando a imputação da variável 'REASON':
df['REASON'].fillna('DebtCon', inplace=True)


# In[None]

# Verificando como ficou a distribuição de frequências da variável 'REASON':
df['REASON'].value_counts()

# In[None]

# Verificando como ficou o Dataset:
df.info()

# In[None]

# Verificando as classes e frequência da variável 'JOB':
df['JOB'].value_counts()

# A#  # c# l# a# s# s# e#  # '# O# t# h# e# r# '#  # p# o# s# s# u# i#  # a#  # m# a# i# o# r# i# a#  # d# o# s#  # r# e# g# i# s# t# r# o# s#  # v# á# l# i# d# o# s# .

# In[None]

# Verificando os registros nulos na variável 'JOB':
df[df['JOB'].isnull()]

# V# e# r# i# f# i# c# a# -# s# e#  # 2# 6# 7#  # r# e# g# i# s# t# r# o# s#  # c# o# m#  # d# a# d# o#  # f# a# l# t# a# n# t# e#  # n# a#  # v# a# r# i# á# v# e# l#  # '# J# O# B# '# .

# V# i# s# t# o#  # a#  # c# l# a# s# s# e#  # '# O# t# h# e# r# '#  # p# o# s# s# u# i# r#  # a#  # m# a# i# o# r#  # p# a# r# t# e#  # d# o# s#  # r# e# g# i# s# t# r# o# s# ,#  # o# p# t# o# u# -# s# e#  # p# e# l# a#  # i# m# p# u# t# a# ç# ã# o#  # d# o# s#  # v# a# l# o# r# e# s#  # '# m# i# s# s# i# n# g# '#  # p# e# l# o#  # v# a# l# o# r#  # d# e# s# t# a#  # c# l# a# s# s# e# .

# In[None]

# Imputação dos valores nulos da variável 'JOB'pelo valor da classe 'Other':
df['JOB'].fillna('Other', inplace=True)

# In[None]

# Verificando como ficou a distribuição das classes da variável 'JOB':
df['JOB'].value_counts()

# In[None]

#Verificando como ficou o Dataset:
df.info()

# V# A# R# I# Á# V# E# L#  # '# Y# O# J# '

# In[None]

# Verificando a distribuição da variável:
df['YOJ'].value_counts()

# In[None]

# Verificando os dados nulos da variável 'YOJ':
df[df['YOJ'].isnull()]

# C# o# n# s# t# a# t# a# -# s# e#  # 5# 0# 5#  # r# e# g# i# s# t# r# o# s#  # c# o# m#  # d# a# d# o# s#  # n# u# l# o# s#  # n# a#  # v# a# r# i# á# v# e# l#  # '# Y# O# J# '# ;# 
# V# i# s# t# o#  # a#  # v# a# r# i# á# v# e# l#  # s# e# r#  # c# o# n# t# í# n# u# a# ,#  # v# e# r# i# f# i# c# o# u# -# s# e#  # a#  # e# x# i# s# t# ê# n# c# i# a#  # d# e#  # v# á# r# i# o# s#  # d# o# m# í# n# i# o# s# ,#  # s# e# m#  # p# r# e# d# o# m# i# n# â# n# c# i# a#  # d# e#  # u# m#  # d# e# l# e# s# .#  # D# e# s# t# a#  # f# o# r# m# a#  # p# a# r# t# i# u# -# s# e#  # p# a# r# a#  # a#  # a# n# á# l# i# s# e#  # d# o#  # s# e# u#  # r# e# s# u# m# o#  # e# s# t# a# t# í# s# t# i# c# o#  # e#  # d# e#  # s# u# a#  # d# i# s# t# r# i# b# u# i# ç# ã# o# :

# In[None]

# Verificando o resumo de medidas estísiticas da variável 'YOJ':
df['YOJ'].describe()

# In[None]

# Verificando uma medida estatística extra, a mediana:
df['YOJ'].median()

# In[None]

# Verificando a distribuição dos dados por meio do Histograma:
df['YOJ'].plot.hist(bins=50)

# C# o# n# s# i# d# e# r# a# n# d# o#  # o# s#  # d# a# d# o# s#  # e# s# t# a# r# e# m#  # m# a# i# s#  # d# i# s# t# r# i# b# u# í# d# o# s#  # à#  # e# s# q# u# e# r# d# a# ,#  # u# s# a# r# e# m# o# s#  # a#  # M# e# d# i# a# n# a#  # a# o#  # i# n# v# é# s#  # d# a#  # M# é# d# i# a#  # p# a# r# a#  # a#  # i# m# p# u# t# a# ç# ã# o#  # d# o# s#  # v# a# l# o# r# e# s#  # m# i# s# s# i# n# g#  # d# a#  # c# o# l# u# n# a#  # "# Y# O# J# "# .#  

# In[None]

# Efetuando a imputação pela Mediana: 
df['YOJ'].fillna(7, inplace=True)

# In[None]

# Verificando o dataset:
df.info()

# V# A# R# I# Á# V# E# I# S#  # '# D# E# R# O# G# '# ,#  # '# D# E# L# I# N# Q# ,#  # '# C# L# A# G# E# '# ,#  # '# N# I# N# Q# '# ,#  # '# C# L# N# O# '# ,#  # D# E# B# T# I# N# C# '# :

# In[None]

# Verificando as classes e distribuição da 'DEROG':
df['DEROG'].value_counts()

# In[None]

# Verificando a quantidade de registros com dados missing na variável 'DEROG': 
df[df['DEROG'].isnull()]

# T# e# n# d# o#  # e# m#  # v# i# s# t# a#  # a#  # q# u# a# s# e#  # t# o# t# a# l# i# d# a# d# e#  # d# o# s#  # r# e# g# i# s# t# r# o# s#  # e# s# t# a# r# e# m#  # c# o# m#  # v# a# l# o# r#  # z# e# r# o#  # p# a# r# a#  # a#  # v# a# r# i# á# v# e# l#  # '# D# E# R# O# G# '#  # u# s# a# r# e# m# o# s#  # a#  # i# m# p# u# t# a# ç# ã# o#  # p# o# r#  # z# e# r# o# .

# In[None]

# Verificando as classes e distribuição da 'DELINQ':
df['DELINQ'].value_counts()

# In[None]

# Verificando a quantidade de registros com dados missing na variável 'DELINQ': 
df[df['DELINQ'].isnull()]

# T# e# n# d# o#  # e# m#  # v# i# s# t# a# ,#  # a# s# s# i# m#  # c# o# m# o#  # a#  # '# D# E# R# O# G# ,#  # q# u# e#  # a#  # q# u# a# s# e#  # t# o# t# a# l# i# d# a# d# e#  # d# o# s#  # r# e# g# i# s# t# r# o# s#  # e# s# t# ã# o#  # c# o# m#  # v# a# l# o# r#  # z# e# r# o#  # p# a# r# a#  # a#  # v# a# r# i# á# v# e# l#  # '# D# E# L# I# N# Q# '#  # u# s# a# r# e# m# o# s#  # a#  # i# m# p# u# t# a# ç# ã# o#  # p# o# r#  # z# e# r# o

# In[None]

# Verificando as classes e frequência da variável 'CLAGE':
df['CLAGE'].value_counts()

# In[None]

df[df['CLAGE'].isnull()]

# A# q# u# i#  # t# a# m# b# é# m#  # t# r# a# t# a# -# s# e#  # d# e#  # v# a# r# i# á# v# e# l#  # c# o# n# t# í# n# u# a#  # s# e# m#  # p# r# e# d# o# m# i# n# â# n# c# i# a#  # d# e#  # c# l# a# s# s# e# .#  # É#  # n# e# c# e# s# s# á# r# i# a#  # a#  # a# n# á# l# i# s# e#  # d# e#  # s# u# a# s#  # m# e# d# i# d# a# s#  # e# s# t# a# t# í# s# t# i# c# a# s#  # p# a# r# a#  # a#  # t# o# m# a# d# a#  # d# e#  # d# e# c# i# s# ã# o#  # q# u# a# n# t# o#  # a#  # i# m# p# u# t# a# ç# ã# o#  # d# e#  # d# a# d# o# s#  # n# u# l# o# s# .

# In[None]

# Verificando o resumo de medidas estísiticas da variável 'CLAGE':
df['CLAGE'].describe()

# In[None]

# Verificando a Mediana:
df['CLAGE'].median()

# In[None]

# Verificando a distribuição dos dados por meio do Histograma:
df['CLAGE'].plot.hist(bins=50)

# T# e# n# d# o#  # e# m#  # v# i# s# t# a#  # a#  # d# i# s# t# r# i# b# u# i# ç# ã# o#  # d# o# s#  # d# a# d# o# s# ,#  # p# a# r# a#  # C# L# A# G# E#  # u# s# a# r# e# m# o# s#  # a#  # i# m# p# u# t# a# ç# ã# o#  # p# e# l# a#  # m# e# d# i# a# n# a

# In[None]

# Verificando as classes e distribuição entre estas para a variável 'NINQ': 
df['NINQ'].value_counts()

# In[None]

# Verificando os dados nulos para a variável 'NINQ':
df[df['NINQ'].isnull()]

# In[None]

# Sumário estatístico para 'NINQ':
df['NINQ'].describe()

# In[None]

# Verificando a Mediana:
df['NINQ'].median()

# In[None]

# Verificando o Histograma:
df['CLAGE'].plot.hist(bins=50)

# P# a# r# a#  # N# I# N# Q#  # u# s# a# r# e# m# o# s#  # a#  # m# e# d# i# a# n# a# ,#  # v# i# s# t# o#  # o# s#  # d# a# d# o# s#  # e# s# t# a# r# e# m#  # f# o# r# t# e# m# e# n# t# e#  # d# i# s# t# r# i# b# u# i# d# o# s#  # à#  # e# s# q# u# e# r# d# a#  # d# a#  # c# u# r# v# a# .

# In[None]

# Verificando classes e frequência para variável 'CLNO':
df['CLNO'].value_counts()

# In[None]

# Verificando os valores Nulos: 
df[df['CLNO'].isnull()]

# In[None]

# Verificando as medidas estatísticas:
df['CLNO'].describe()

# In[None]

# Verificando a Mediana:
df['CLNO'].median()

# In[None]

# Verificando o Histograma:
df['CLNO'].plot.hist(bins=50)

# P# a# r# a#  # C# L# N# O#  # u# s# a# r# e# m# o# s#  # a#  # m# e# d# i# a# n# a# .#  # C# o# n# c# e# n# t# r# a# ç# ã# o#  # m# a# i# o# r#  # à#  # e# s# q# u# e# r# d# a# .

# In[None]

# Verificando as classes e distribuição da variável 'DEBTINC':
df['DEBTINC'].value_counts()

# A#  # v# a# r# i# á# v# e# l#  # D# E# B# T# I# N# C#  # é#  # c# o# n# t# í# n# u# a#  # s# e# m#  # c# l# a# s# s# e# s#  # p# r# e# d# o# m# i# n# a# n# t# e# .

# In[None]

# Verificando os valores Nulos: 
df[df['DEBTINC'].isnull()]

# In[None]

# Verificando o resumo estatístico:
df['DEBTINC'].describe()

# In[None]

# Verificando a Mediana: 
df['DEBTINC'].median()

# In[None]

# Verificando o histograma: 
df['DEBTINC'].plot.hist(bins=50)

# V# i# s# t# o#  # o# s#  # d# a# d# o# s#  # n# ã# o#  # e# s# t# a# r# e# m#  # m# u# i# t# o#  # d# i# s# p# e# r# s# o# s# ,#  # p# a# r# a#  # a#  # v# a# r# i# á# v# e# l#  # D# E# B# T# I# N# C#  # u# s# a# r# e# m# o# s#  # a#  # m# é# d# i# a# ,#  # c# o# m# o#  # c# r# i# t# é# r# i# o#  # p# a# r# a#  # a#  # i# m# p# u# t# a# ç# ã# o#  # d# o# s#  # d# a# d# o# s#  # f# a# l# t# a# n# t# e# s# .

# F# i# n# a# l# m# e# n# t# e# ,#  # a# p# ó# s#  # o#  # t# é# r# m# i# n# o#  # d# a#  # a# n# á# l# i# s# e#  # d# a# s#  # s# e# i# s#  # ú# l# t# i# m# a# s#  # v# a# r# i# á# v# e# i# s# ,#  # p# r# o# c# e# d# e# r# e# m# o# s#  # a#  # i# m# p# u# t# a# ç# ã# o#  # c# o# n# f# o# r# m# e#  # a#  # s# e# g# u# i# r# :#  # 
# D# E# R# O# G# :#  # p# o# r#  # z# e# r# o# ;# 
# D# E# L# I# N# Q# :#  # p# o# r#  # z# e# r# o# ;# 
# C# L# A# G# E# :#  # p# e# l# a#  # M# e# d# i# a# n# a# ;# 
# N# I# N# Q# :#  # p# e# l# a#  # M# e# d# i# a# n# a# ;# 
# C# L# N# O# :#  # p# e# l# a#  # M# e# d# i# a# n# a# :# 
# D# E# B# T# I# N# C# :#  # p# e# l# a#  # M# é# d# i# a# .

# In[None]

# Imputação dos dados nulos:
df['DEROG'].fillna(0, inplace=True)
df['DELINQ'].fillna(0, inplace=True)
df['CLAGE'].fillna(173.48, inplace=True)
df['NINQ'].fillna(1, inplace=True)
df['CLNO'].fillna(20, inplace=True)
df['DEBTINC'].fillna(33.79, inplace=True)

# In[None]

# Verificando o dataset após todo o tratamento de Dados 'Missing's':
df.info()

# ## ##  # 2# .# 2# .#  # A# N# Á# L# I# S# E#  # E# X# P# L# O# R# A# T# Ó# R# I# A#  # D# A# S#  # V# A# R# I# Á# V# E# I# S#  # E# X# P# L# I# C# A# T# I# V# A# S#  # E#  # S# U# A# S#  # R# E# L# A# Ç# Õ# E# S#  # C# O# M#  # A#  # V# A# R# I# Á# V# E# L#  # R# E# S# P# O# S# T# A#  # '# B# A# D# '

# ## ## ##  # 2# .# 2# .# 1# .#  # V# e# r# i# f# i# c# a# n# d# o#  # g# r# a# f# i# c# a# m# e# n# t# e#  # a#  # D# i# s# t# r# i# b# u# i# ç# ã# o#  # d# a#  # V# a# r# i# á# v# e# l#  # R# e# s# p# o# s# t# a#  # '# B# A# D# '# :#  

# In[None]

# Importando 
import seaborn as sns


# In[None]

# Verificando inicialmente a Tabela Cruzada

y = df['BAD'].astype(object) 
count = pd.crosstab(index = y, columns="count")
percentage = pd.crosstab(index = y, columns="frequency")/pd.crosstab(index = y, columns="frequency").sum()
pd.concat([count, percentage], axis=1)

# In[None]

# Plotando o gráfico da Frequência da Variável Resposta 'BAD'
ax = sns.countplot(x=y, data=df).set_title("Distribuição da Variável Resposta 'BAD'")

# P# o# d# e# -# s# e#  # p# e# r# c# e# b# e# r#  # q# u# e#  # o#  # í# n# d# i# c# e#  # d# e#  # i# n# a# d# i# m# p# l# ê# n# c# i# a#  # (# '# d# e# f# a# u# l# t# '# )#  # é#  # d# e#  # 1# 9# ,# 7# 0# %

# ## ## ##  # 2# .# 2# .# 2# .#  # V# e# r# i# f# i# c# a# n# d# o#  # g# r# a# f# i# c# a# m# e# n# t# e#  # a#  # r# e# l# a# ç# ã# o#  # d# a#  # v# a# r# i# á# v# e# l#  # r# e# s# p# o# s# t# a#  # '# B# A# D# '#  # e#  # a# l# g# u# m# a# s#  # v# a# r# i# á# v# e# i# s#  # e# x# p# l# i# c# a# t# i# v# a# s

# '# B# A# D# '#  # v# e# r# s# u# s#  # '# J# O# B# '# 
# 


# In[None]

# Plotando o Gráfico de Barras Empilhadas mostrando a relação entre a variável 'BAD' e "JOB":
JOB=pd.crosstab(df['JOB'],df['BAD'])
JOB.div(JOB.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True, title='JOB x BAD', figsize=(4,4))

# N# o#  # g# r# á# f# i# c# o#  # a# c# i# m# a#  # é#  # c# o# n# f# r# o# n# t# a# d# a#  # a#  # i# n# a# d# i# m# p# l# ê# n# c# i# a#  # (# v# a# r# i# á# v# e# l#  # '# B# A# D# '# )#  # c# o# m#  # o#  # t# i# p# o#  # d# e#  # o# c# u# p# a# ç# ã# o#  # (# '# J# O# B# '# )# .#  # V# e# r# i# f# i# c# a# -# s# e#  # q# u# e#  # o#  # s# e# g# m# e# n# t# o#  # v# o# l# t# a# d# o#  # à#  # V# e# n# d# a# s#  # (# S# a# l# e# s# )#  # p# o# s# s# u# i#  # o#  # m# a# i# o# r#  # í# n# d# i# c# e#  # d# e#  # i# n# a# d# i# m# p# l# ê# n# c# i# a# ,#  # c# e# r# c# a#  # d# e#  # 3# 0# %# ,#  # s# e# n# d# o#  # q# u# e#  # o#  # m# e# n# o# r#  # í# n# d# i# c# e#  # d# e#  # d# e# f# a# u# l# t#  # f# o# i#  # d# a#  # c# l# a# s# s# e#  # '# O# f# i# c# c# e# '# .

# '# B# A# D# '#  # v# e# r# s# u# s#  # '# R# E# A# S# O# N# '# :#  # 
# 


# In[None]

REASON=pd.crosstab(df['REASON'],df['BAD'])
REASON.div(REASON.sum(1).astype(float), axis=0).plot(kind="bar", stacked=True, title='REASON x BAD', figsize=(4,4))

# O#  # g# r# á# f# i# c# o#  # a# c# i# m# a#  # m# o# s# t# r# a#  # a#  # r# e# l# a# ç# ã# o#  # e# n# t# r# e#  # a#  # i# n# a# d# i# m# p# l# ê# n# c# i# a#  # e#  # a#  # f# i# n# a# l# i# d# a# d# e#  # d# o#  # c# r# é# d# i# t# o# .#  # V# e# r# i# f# i# c# a# -# s# e#  # q# u# e#  # a#  # i# n# a# d# i# m# p# l# ê# n# c# i# a#  # é#  # l# i# g# e# i# r# a# m# e# n# t# e#  # m# e# n# o# r#  # p# a# r# a#  # a#  # f# i# n# a# l# i# d# a# d# e#  # "# D# e# b# t# C# o# n# f# "# .# 


# '# B# A# D# '#  # v# e# r# s# u# s#  # '# M# O# R# T# D# U# E# '# 
# 


# In[None]

sns.stripplot(x='BAD', y='MORTDUE', data=df, linewidth=1)

# O#  # g# r# á# f# i# c# o#  # a# c# i# m# a#  # m# o# s# t# r# a#  # a#  # r# e# l# a# ç# ã# o#  # e# n# t# r# e#  # a#  # i# n# a# d# i# m# p# l# ê# n# c# i# a#  # e#  # o#  # v# a# l# o# r#  # d# o#  # f# i# n# a# n# c# i# a# m# e# n# t# o# .#  # P# o# d# e# -# s# e#  # c# o# n# s# t# a# t# a# r#  # q# u# e#  # c# o# m#  # a#  # e# x# c# e# ç# ã# o#  # d# e#  # 4#  # o# u# t# l# i# e# s#  # c# o# m#  # v# a# l# o# r# e# s#  # e# l# e# v# a# d# o# s#  # d# e#  # d# í# v# i# d# a# ,#  # n# ã# o#  # e# x# i# s# t# e#  # g# r# a# n# d# e#  # d# i# f# e# r# e# n# ç# a#  # n# o#  # v# a# l# o# r#  # m# é# d# i# o#  # d# o#  # c# r# é# d# i# t# o#  # d# o#  # c# l# i# e# n# t# e#  # i# n# s# o# l# v# e# n# t# e#  # p# a# r# a#  # a# q# u# e# l# e#  # q# u# e#  # c# o# n# s# e# g# u# i# u#  # h# o# n# r# á# -# l# o# ;# 
# 


# '# B# A# D# '# v# e# r# s# u# s#  # '# D# E# B# T# I# N# C# '# :

# In[None]

sns.stripplot(x='BAD', y='DEBTINC', data=df, linewidth=1)

# E# s# t# e#  # g# r# á# f# i# c# o#  # r# e# l# a# c# i# o# n# a#  # a#  # v# a# r# i# á# v# e# l#  # '# B# A# D# '#  # c# o# m#  # a#  # '# D# E# B# T# I# N# C# '# .#  # A#  # v# a# r# i# á# v# e# l#  # '# D# E# B# T# I# N# C#  # r# e# c# e# b# e#  # a#  # r# a# z# ã# o#  # e# n# t# r# e#  # o#  # v# a# l# o# r#  # d# o# s#  # d# é# b# i# t# o# s#  # e#  # o# s#  # r# e# n# d# i# m# e# n# t# o# s#  # d# o#  # f# i# n# a# n# c# i# a# d# o# ,#  # o# u#  # s# e# j# a# ,#  # q# u# a# n# t# o#  # m# a# i# o# r#  # o#  # s# e# u#  # v# a# l# o# r# ,#  # m# a# i# o# r#  # é#  # e# n# d# i# v# i# d# a# m# e# n# t# o#  # d# o#  # c# l# i# e# n# t# e# .#  # G# r# a# f# i# c# a# m# e# n# t# e#  # p# e# r# c# e# b# e# -# s# e#  # q# u# e#  # n# e# n# h# u# m#  # c# l# i# e# n# t# e# s#  # n# a#  # c# l# a# s# s# e#  # q# u# e#  # d# o# s#  # q# u# e#  # c# o# n# s# e# g# u# i# r# a# m#  # p# a# g# a# r#  # s# e# u#  # e# m# p# r# é# s# t# i# m# o#  # p# o# s# s# u# e# m#  # D# E# B# T# I# N# C#  # m# a# i# o# r#  # q# u# e#  # 5# 0# .#  # P# o# r#  # o# u# t# r# o#  # l# a# d# o# ,#  # é#  # g# r# a# n# d# e#  # a#  # q# u# a# n# t# i# d# a# d# e#  # d# e#  # i# n# a# d# i# m# p# l# e# n# t# e# s#  # c# o# m#  # v# a# l# o# r# e# s#  # e# l# e# v# a# d# o# s#  # n# e# s# t# a#  # v# a# r# i# á# v# e# l# .#  # P# o# r# t# a# n# t# o# ,#  # p# r# o# v# a# v# e# l# m# e# n# t# e#  # e# s# t# a#  # v# a# r# i# á# v# e# l#  # t# e# r# á#  # g# r# a# n# d# e#  # i# m# p# a# c# t# o#  # n# o#  # m# o# d# e# l# o#  # d# e#  # p# r# e# d# i# ç# ã# o# .#  

# ## ##  # 2# .# 3# .#  # T# r# a# n# f# o# r# m# a# n# d# o#  # a# s#  # v# a# r# i# á# v# e# i# s#  # c# a# t# e# g# ó# r# i# c# a# s#  # e# m#  # '# d# u# m# m# i# e# s# '

# A#  # b# a# s# e#  # d# e#  # d# a# d# o# s#  # c# o# n# t# a#  # c# o# m#  # d# u# a# s#  # v# a# r# i# á# v# e# i# s#  # d# o#  # t# i# p# o#  # '# o# b# j# e# c# t# '#  # e#  # q# u# e#  # d# e# v# e# r# ã# o#  # s# e# r#  # t# r# a# t# a# d# a# s#  # p# a# r# a#  # q# u# e#  # s# e#  # p# o# s# s# a#  # u# t# i# l# i# z# á# -# l# a# s#  # n# o#  # m# o# d# e# l# o#  # d# e#  # p# r# e# d# i# ç# ã# o# :#  # "# R# E# A# S# O# N# "#  # e#  # "# J# O# B# "# .#  # 
# A#  # o# p# ç# ã# o#  # e# s# c# o# l# h# i# d# a#  # f# o# i#  # a#  # t# r# a# n# s# f# o# r# m# a# ç# ã# o#  # e# m#  # '# d# u# m# m# i# e# s# ,#  # c# o# n# f# o# r# m# e#  # é#  # e# f# e# t# u# a# d# o#  # a#  # s# e# g# u# i# r# :

# In[None]

# Verificando as variáveis do dataset:
df.info()

# In[None]

# Transformando as variáveis 'REASON' e 'JOB' em 'dummies':
df = pd.get_dummies(df, columns=['REASON', 'JOB'])

# In[None]

# Verificando como ficou o dataset após o processo de transformações em 'dummies':
df.info()

# C# o# n# f# o# r# m# e#  # v# e# r# i# f# i# c# a# -# s# e#  # a# c# i# m# a# ,#  # o#  # d# a# t# a# s# e# t#  # f# i# n# a# l# ,#  # t# r# a# t# a# d# o#  # e#  # p# r# o# n# t# o#  # p# a# r# a#  # s# e# r#  # u# t# i# l# i# z# a# d# o#  # n# o#  # m# o# d# e# l# o# ,#  # c# o# n# t# a# r# á#  # c# o# m#  # 1# 9#  # v# a# r# i# á# v# e# i# s# ,#  # t# o# d# a# s#  # n# u# m# é# r# i# c# a# s# .#  

# In[None]

# Visualizando o dataset após o processo de 'dummies':
df.head().T

# ##  # 3# .#  # V# e# r# i# f# i# c# a# ç# ã# o#  # d# a# s#  # C# o# r# r# e# l# a# ç# õ# e# s#  # e# n# t# r# e#  # a# s#  # v# a# r# i# á# v# e# i# s

# P# r# e# v# i# a# m# e# n# t# e#  # à#  # a# p# l# i# c# a# ç# ã# o#  # d# o# s#  # m# o# d# e# l# o# s#  # d# e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # e# s# c# o# l# h# i# d# o# s#  # p# a# r# a#  # a#  # p# r# e# d# i# ç# ã# o# ,#  # é#  # i# m# p# o# r# t# a# n# t# e#  # v# e# r# i# f# i# c# a# r#  # a#  # c# o# l# i# n# e# a# r# i# d# a# d# e#  # e# n# t# r# e#  # a# s#  # v# a# r# i# á# v# e# i# s#  # e# x# p# l# i# c# a# t# i# v# a# s# ,#  # p# a# r# a#  # q# u# e# ,#  # c# o# m#  # a#  # d# e# v# i# d# a#  # e# x# c# l# u# s# ã# o#  # d# a# s#  # v# a# r# i# á# v# e# i# s#  # c# o# r# r# e# l# a# c# i# o# n# a# d# a# s# ,#  # p# o# d# e# r# m# o# s#  # e# v# i# t# a# r#  # o#  # o# v# e# r# f# i# t# t# i# n# g#  # d# o#  # m# o# d# e# l# o# .#  # É#  # o#  # q# u# e#  # s# e# r# á#  # r# e# a# l# i# z# a# d# o#  # n# e# s# t# e#  # t# ó# p# i# c# o# .#  

# In[None]

df.corr()

# In[None]

# Importando o pacote matplotlib
import matplotlib.pyplot as plt

# In[None]

#Create Correlation matrix
corr = df.corr()
#Plot figsize
fig, ax = plt.subplots(figsize=(10,8))
#Generate Color Map
colormap = sns.diverging_palette(220, 10, as_cmap=True)
#Generate Heat Map, allow annotations and place floats in map
sns.heatmap(corr, cmap=colormap, annot=True, fmt=".2f")
#Apply xticks
plt.xticks(range(len(corr.columns)), corr.columns);
#Apply yticks
plt.yticks(range(len(corr.columns)), corr.columns)
#show plot
plt.show()

# A# n# a# l# i# s# a# n# d# o#  # o#  # G# r# á# f# i# c# o#  # d# a#  # M# a# t# r# i# z#  # d# e#  # C# o# r# r# e# l# a# ç# ã# o# ,#  # v# e# r# i# f# i# c# a# -# s# e#  # q# u# e#  # a# s#  # V# a# r# i# á# v# e# i# s#  # '# M# O# R# T# D# U# E# '#  # e#  # '# V# A# L# U# E# '#  # p# o# s# s# u# e# m#  # f# o# r# t# e#  # c# o# r# r# e# l# a# ç# ã# o#  # p# o# s# i# t# i# v# a#  # (# 0# ,# 8# 9# )# .#  # P# a# r# a#  # e# v# i# t# a# r#  # d# i# s# t# o# r# ç# o# e# s#  # n# o#  # m# o# d# e# l# o# ,#  # o# p# t# o# u# -# s# e#  # p# e# l# a#  # e# x# c# l# u# s# ã# o#  # d# e#  # u# m# a#  # d# e# l# a# s# :#  # a#  # '# V# A# L# U# E# '# .# 
# 
# D# a#  # m# e# s# m# a#  # f# o# r# m# a# ,#  # s# e# r# á#  # e# x# c# l# u# í# d# a#  # d# a#  # a# n# á# l# i# s# e#  # d# a#  # v# a# r# i# á# v# e# l#  # d# u# m# m# i# f# i# c# a# d# a#  # R# E# A# S# O# N# _# H# o# m# e# I# m# p# .

# ##  # 4# .#  # A# P# L# I# C# A# Ç# Ã# O#  # D# O#  # M# O# D# E# L# O# 


# A#  # f# i# m#  # d# e#  # c# o# n# s# e# g# u# i# r# m# o# s#  # p# r# e# v# i# s# õ# e# s#  # a# c# e# r# c# a#  # d# a#  # p# o# s# s# i# b# i# l# i# d# a# d# e#  # d# e#  # '# d# e# f# a# u# l# t# '#  # o# u#  # n# ã# o#  # a#  # p# a# r# t# i# r#  # d# o# s#  # d# a# d# o# s#  # d# o#  # d# a# t# a# s# e# t# ,#  # v# a# m# o# s#  # u# t# i# l# i# z# a# r#  # d# o# i# s#  # a# l# g# o# r# i# t# m# o# s#  # d# i# f# e# r# e# n# t# e# s#  # d# e#  # á# r# v# o# r# e# s#  # d# e#  # d# e# c# i# s# ã# o# :#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # e#  # o#  # X# G# B# o# o# s# t# ,#  # a# m# b# o# s#  # m# o# d# e# l# o# s#  # d# e#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g# .#  

# ## ##  # 4# .# 1# .#  # A# p# l# i# c# a# ç# ã# o#  # d# o#  # M# o# d# e# l# o#  # d# e#  # R# a# n# d# o# m#  # F# o# r# e# s# t

# In[None]

# Importando o pacote do Sklearn:
from sklearn.model_selection import train_test_split

# In[None]

# Separando os dados de Treino, Validação e Teste, usando a proporção 80/20:
y_varible = df["BAD"]
x_varible = df.drop(["BAD"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/8861098.npy", { "accuracy_score": score })

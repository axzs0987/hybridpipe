import pandas as pd
# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
#print(os.listdir("../input"))
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report



# In[None]

wines = pd.read_csv("..//input//winequality-red.csv")
wines.info()

# In[None]

sns.countplot('quality', data = wines)

# In[None]

fig , axs = plt.subplots(3,4, figsize=(20,15))
counter = 0
for col in wines.columns:
    sns.barplot(x='quality' ,y = col , data = wines , ax= axs[counter%3][int(counter/3)] )
    counter = counter + 1

# In[None]



# In[None]

plt.subplots(figsize=(20,15))
corrmat = wines.corr()
corrmat = np.abs(corrmat)
cm = np.corrcoef(wines.values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 15}, yticklabels=wines.columns.values, xticklabels=wines.columns.values)
plt.show()

# In[None]

wines['q2'] = pd.cut(wines['quality'],[0,5,10],labels=[0,1])
sns.countplot('q2', data = wines)

# In[None]

wines.q2 = pd.Categorical(wines.q2).codes
print(wines.columns[:-2])

# In[None]

X = wines[wines.columns[:-2]].values
Y = wines['q2'].values

from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2319517.npy", { "accuracy_score": score })

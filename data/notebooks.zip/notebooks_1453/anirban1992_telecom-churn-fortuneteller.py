import numpy as np 
import pandas as pd 
import pandas as pd 
import warnings
warnings.filterwarnings("ignore")
import seaborn as sns
churn_data=pd.read_csv("../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv")
churn_data.info()
churn_data.TotalCharges = pd.to_numeric(churn_data.TotalCharges, errors='coerce')
churn_data.TotalCharges = churn_data.TotalCharges.fillna(method='ffill')
churn_data.TotalCharges = pd.to_numeric(churn_data.TotalCharges, errors='coerce')
churn_data.isnull().sum()
churn_data.info()
churn_data.nunique() 
print(churn_data["Churn"].value_counts()/len(churn_data)*100)
Id_col     = ['customerID']
target_col = ["Churn"]
cat_cols   = churn_data.nunique()[churn_data.nunique() < 6].keys().tolist()
cat_cols   = [x for x in cat_cols if x not in target_col] 
num_cols   = [x for x in churn_data.columns if x not in cat_cols + target_col + Id_col] 
churn = churn_data[churn_data["Churn"] == "Yes"]
not_churn = churn_data[churn_data["Churn"] == "No"]
import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
def plot_pie(column) :
    trace1 = go.Pie(values  = churn[column].value_counts().values.tolist(),                    labels  = churn[column].value_counts().keys().tolist(),                    hoverinfo = "label+percent+name",                    domain  = dict(x = [0,.48]),                    name    = "Churn Customers",                    marker  = dict(line = dict(width = 2,                                               color = "rgb(243,243,243)")),                    hole    = .6                   )
    trace2 = go.Pie(values  = not_churn[column].value_counts().values.tolist(),                    labels  = not_churn[column].value_counts().keys().tolist(),                    hoverinfo = "label+percent+name",                    marker  = dict(line = dict(width = 2,                                               color = "rgb(243,243,243)")                                  ),                    domain  = dict(x = [.52,1]),                    hole    = .6,                    name    = "Non churn customers"                    )
    layout = go.Layout(dict(title = column + " distribution in customer attrition ",                            plot_bgcolor  = "rgb(243,243,243)",                            paper_bgcolor = "rgb(243,243,243)",                            annotations = [dict(text = "churn customers",                                                font = dict(size = 13),                                                showarrow = False,                                                x = .15, y = .5),                                           dict(text = "Non churn customers",                                                font = dict(size = 13),                                                showarrow = False,                                                x = .88,y = .5                                               )                                          ]                           )                      )
    data = [trace1,trace2]
    fig  = go.Figure(data = data,layout = layout)
#    py.iplot(fig)
#for i in cat_cols :
#    plot_pie(i)
#sns.heatmap(pd.crosstab(churn_data.Dependents, churn_data.Partner, normalize='all', margins=True), annot=True, cmap='ocean')
#sns.heatmap(pd.crosstab(churn_data.Dependents, churn_data.SeniorCitizen, normalize='all', margins=True), annot=True, cmap='ocean')
#sns.heatmap(pd.crosstab(churn_data.PhoneService, churn_data.MultipleLines, normalize='all', margins=True), annot=True, cmap='ocean')
#sns.heatmap(pd.crosstab(churn_data.InternetService,churn_data.PaymentMethod, normalize='all', margins=True), annot=True, cmap='ocean')
#sns.heatmap(pd.crosstab(churn_data.InternetService,churn_data.PaperlessBilling, normalize='all', margins=True), annot=True, cmap='ocean')
#sns.heatmap(pd.crosstab(churn_data.SeniorCitizen,churn_data.PaymentMethod, normalize='all', margins=True), annot=True, cmap='ocean')
def plot_histogram(column) :
    trace1 = go.Histogram(x = churn[column],                          histnorm = "percent",                          name = "Churn Customers",                          marker = dict(line = dict(width = .5,                                                    color = "black"                                                    )                                        ),                            opacity = .6                          ) 
    
    trace2 = go.Histogram(x = not_churn[column],                          histnorm = "percent",                          name = "Non churn customers",                          marker = dict(line = dict(width = .5,                                              color = "black"                                             )                                 ),                          opacity = .6                         )         
    
    data = [trace1,trace2]
    layout = go.Layout(dict(title =column + " distribution in customer attrition ",                            plot_bgcolor  = "rgb(243,243,243)",                            paper_bgcolor = "rgb(300,243,243)",                            xaxis = dict(gridcolor = 'rgb(255, 255, 255)',                                             title = column,                                             zerolinewidth=1,                                             ticklen=5,                                             gridwidth=2                                            ),                            yaxis = dict(gridcolor = 'rgb(255, 255, 255)',                                             title = "percent",                                             zerolinewidth=1,                                             ticklen=5,                                             gridwidth=2                                            ),                           ))
    fig  = go.Figure(data=data,layout=layout)
#    py.iplot(fig)
#for i in num_cols :
#    plot_histogram(i)
import plotly.express as px
def plotly_scatterplot(xc, yc, colour, template, trendline=None):
    fig1 = px.scatter(churn_data, x=xc, y=yc,                color=colour, render_mode='svg', template=template,                hover_name="customerID",                marginal_x=None,                marginal_y=None, trendline=trendline)
    return fig1
#plotly_scatterplot(xc='MonthlyCharges', yc='TotalCharges', colour='Churn', template='plotly_dark',trendline='ols')
#plotly_scatterplot(xc='MonthlyCharges', yc='TotalCharges', colour='Contract', template='plotly')
from sklearn.cluster import KMeans 
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
scaler = MinMaxScaler()
churn_data[['MonthlyCharges','tenure']] = scaler.fit_transform(churn_data[['MonthlyCharges','tenure']])
def elbow_plot(data=churn_data[['MonthlyCharges','tenure']]):
    score = []
    for cluster in range(1,11):
        kmeans = KMeans(n_clusters = cluster, init="k-means++", random_state=10)
        kmeans.fit(data)
        score.append(kmeans.inertia_)
    
#    plt.plot(range(1,11), score)
#    plt.title('The Elbow Method')
#    plt.xlabel('no of clusters')
#    plt.ylabel('wcss')
#    plt.grid()
#    return plt.show()
#elbow_plot()
kmeans = KMeans(n_clusters = 4, random_state = 1000).fit(churn_data[['MonthlyCharges','tenure']])
churn_data['cluster'] = kmeans.labels_
churn_data[['MonthlyCharges','tenure']] = scaler.inverse_transform(churn_data[['MonthlyCharges','tenure']])
fig = px.scatter(churn_data, x='MonthlyCharges', y='tenure',                color='cluster', render_mode='svg', template='plotly',                hover_data=['SeniorCitizen','Dependents','Contract','InternetService',                            'PaperlessBilling','PaymentMethod'],                hover_name="customerID",                marginal_x="violin",                marginal_y="violin")
#fig.update_layout(title='Clusters of churned users by monthly charges and tenure',                  paper_bgcolor='LightBlue')
                      
#fig.show()
cluster_charges = pd.pivot_table(churn_data, index=['cluster'], columns=['SeniorCitizen'],                     values=['MonthlyCharges','tenure'], margins=True, aggfunc='mean')
#sns.heatmap(cluster_charges, annot=True, cmap='ocean')
churn_data['cluster'].value_counts() 
#sns.countplot('cluster',hue='Churn',data=churn_data, orient='h')
#sns.countplot('Churn', hue='MultipleLines',data=churn_data, orient='h')
#sns.countplot('cluster',hue='SeniorCitizen',data=churn_data, orient='h')
#sns.countplot('cluster',hue='Contract',data=churn_data, orient='h')
#def plot_boxplot(column):
#    fig = px.box(churn_data, x=column, y="MonthlyCharges", color="Churn",points="outliers",                  hover_name="customerID",template='plotly')
#    fig.update_traces(quartilemethod="inclusive")
#    fig.update_layout(title='Monthly Charges against {} Segregated By Churn and Non-Churn Customers'.format(column))
#    return fig.show()
#for cols in ['MultipleLines','OnlineSecurity','StreamingTV','PaperlessBilling','PaymentMethod','SeniorCitizen']:
#    plot_boxplot(cols)
churn_data['Family_Person'] = np.where((churn_data['Dependents']=='Yes') & (churn_data['Partner']=='Yes'),1,0)
churn_data['Protection'] = np.where((churn_data['TechSupport'] == 'Yes') |                                    (churn_data['OnlineSecurity'] == 'Yes') |                                    (churn_data['OnlineBackup'] == 'Yes') |                                    (churn_data['DeviceProtection'] == 'Yes'),1,0)
churn_data['TotalServices'] = (churn_data[['PhoneService', 'InternetService', 'OnlineSecurity',                                       'OnlineBackup', 'DeviceProtection', 'TechSupport',                                       'StreamingTV', 'StreamingMovies']]== 'Yes').sum(axis=1)
churn_data['Has_Internet']=churn_data['InternetService'].replace(['Fiber optic','DSL','No'], [1,1,0])
churn_data['Streaming'] = np.where((churn_data['StreamingTV']=='Yes') | (churn_data['StreamingMovies']=='Yes'),1,0)
churn_data['Tech_Payment'] = np.where((churn_data['PaymentMethod']!='Mailed check'),1,0)
churn_data['Techie'] = np.where((churn_data['Streaming']==1) | (churn_data['Tech_Payment']==1),1,0)
churn_data['Premium_Services'] = np.where((churn_data['MultipleLines']=='Yes') & (churn_data['InternetService']=='Fiber optic'),1,0)
y=churn_data['Churn']
drop_list=["customerID","Churn","gender","cluster","Partner","Dependents","StreamingTV","StreamingMovies","TechSupport",           "OnlineSecurity","OnlineBackup","DeviceProtection","TotalCharges","MultipleLines","PhoneService","Contract",          "InternetService","PaymentMethod"]
x=churn_data.drop(drop_list, axis=1)
def label_encoder(dataframe, col_name): 
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    le.fit(dataframe[col_name].unique())
    dataframe[col_name] = le.transform(dataframe[col_name])
    
for i in list(x.columns[x.dtypes =='object']):
    label_encoder(x, i)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
print(x_train.shape, x_test.shape, y_train.shape, y_test.shape)
from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(bootstrap=True, oob_score=True, n_estimators=30, random_state=8,                            max_depth=8, class_weight={'No': 1, 'Yes': 1.6},n_jobs=-1,max_features=0.3,min_samples_leaf=3,                           min_samples_split=3)
#rf.fit(x_train, y_train)
#print("Training set score: {:.3f}".format(rf.score(x_train, y_train)))
#print("Test set score: {:.3f}".format(rf.score(x_test, y_test)))
#print("Out of bound score: {:.3f}".format(rf.oob_score_))
#rf_predictions = rf.predict(x_test)
from sklearn.metrics import confusion_matrix
#ax = sns.heatmap(confusion_matrix(y_test, rf_predictions), annot=True, fmt='d')
#ax.set(xlabel='Random Forest Prediction', ylabel='Truth')
from sklearn.metrics import classification_report
#print(classification_report(y_test,rf_predictions))
from sklearn.model_selection import RandomizedSearchCV
param = dict(max_depth = np.arange(6,15,1), max_features = np.arange(0.1,0.9,0.1))
#rf_cv = RandomizedSearchCV(rf, param, cv=5,n_jobs=-1)
#rf_cv.fit(x_train, y_train)
#print("Tuned Random Forest Parameters: {}".format(rf_cv.best_params_))
#print("Best score is {}".format(rf_cv.best_score_))
rf2 = RandomForestClassifier(bootstrap=True, oob_score=True, n_estimators=30, random_state=8,                            max_depth=6, class_weight={'No': 1, 'Yes': 1.6},n_jobs=-1,max_features=0.1,min_samples_leaf=5,                           min_samples_split=5)
#rf2.fit(x_train, y_train)
#rf2_predictions = rf2.predict(x_test)
from sklearn.metrics import confusion_matrix
#ax = sns.heatmap(confusion_matrix(y_test, rf2_predictions), annot=True, fmt='d')
#ax.set(xlabel='Random Forest Prediction', ylabel='Truth')
from sklearn.metrics import classification_report
#print(classification_report(y_test,rf2_predictions))
def plot_feature_importances (model, kind, title, color, dataframe):
    importances = pd.Series(data=model.feature_importances_, index= dataframe.columns)
    
    importances_sorted = importances.sort_values()
    
#    importances_sorted.plot(kind=kind, color=color)
#    plt.title(title)
#    plt.grid()
#    return(plt.show())
#fig,ax=plt.subplots(figsize=(10,10))
#plot_feature_importances (rf2, 'barh', 'Churn Random Forest Classifier Importances', 'green', x_train)
from sklearn.tree import export_graphviz
dotfile = open("dt2.dot", 'w')
#export_graphviz(rf[0], out_file=dotfile,feature_names = x.columns,class_names=['0','1'])
dotfile.close()
from sklearn.tree import export_graphviz
import os
os.environ["PATH"] += os.pathsep + 'C:/Users/anirban/Desktop/customer-churn/codes'
#export_graphviz(rf[0], out_file='tree.dot', feature_names=x.columns,class_names=['0','1'])
from subprocess import call
call(['dot', '-Tpng', 'tree.dot', '-o', 'tree.png', '-Gdpi=600'])
from IPython.display import Image
Image(filename = 'tree.png')
from xgboost import XGBClassifier
xgb=XGBClassifier(objective='reg:squarederror', n_estimators=12, max_depth=4,                  learning_rate=0.5, seed=100,reg_lambda=0, reg_alpha=0.2, colsample_bynode=1,colsample_bytree=1,                  scale_pos_weight=1.6)
#xgb.fit(x_train, y_train)
#print("Training set score: {:.3f}".format(xgb.score(x_train, y_train)))
#print("Test set score: {:.3f}".format(xgb.score(x_test, y_test)))
#xgb_predictions = xgb.predict(x_test)
#ax = sns.heatmap(confusion_matrix(y_test, xgb_predictions), annot=True, fmt='d')
#ax.set(xlabel='XGBoost Prediction', ylabel='Truth')
#print(classification_report(y_test, xgb_predictions))
#fig,ax=plt.subplots(figsize=(10,10))
#plot_feature_importances (xgb, 'barh', 'XGBoost Importances', 'maroon', x_train)
from sklearn.neighbors import KNeighborsClassifier
test_scores = []
train_scores = []
for i in range(1,15):
    knn = KNeighborsClassifier(n_neighbors=i)
#    knn.fit(x_train,y_train)
#    train_scores.append(knn.score(x_train,y_train))
#    test_scores.append(knn.score(x_test,y_test))
#max_train_score = max(train_scores)
#train_scores_ind = [i for i, v in enumerate(train_scores) if v == max_train_score]
#print('Max train score {} % and k = {}'.format(max_train_score*100,list(map(lambda x: x+1, train_scores_ind))))
#max_test_score = max(test_scores)
#test_scores_ind = [i for i, v in enumerate(test_scores) if v == max_test_score]
#print('Max test score {} % and k = {}'.format(max_test_score*100,list(map(lambda x: x+1, test_scores_ind))))
#plt.figure(figsize=(12,5))
#plt.plot(range(1,15),train_scores,marker='*',label='Train Score')
#plt.plot(range(1,15),test_scores,marker='o',label='Test Score')
#plt.grid()
knn = KNeighborsClassifier(11)
#knn.fit(x_train,y_train)
#knn.score(x_test,y_test)
from sklearn.metrics import confusion_matrix
#y_pred = knn.predict(x_test)
#sns.heatmap(pd.crosstab(y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=False), annot=True, fmt='d')
#print(classification_report(y_test,y_pred))
from sklearn.model_selection import GridSearchCV
param_grid = {'n_neighbors':np.arange(1,50)}
knn2 = KNeighborsClassifier()
#knn2_cv= GridSearchCV(knn,param_grid,cv=5)
#knn2_cv.fit(x_train,y_train)
#print("Best Score:" + str(knn2_cv.best_score_))
#print("Best Parameters: " + str(knn2_cv.best_params_))
from sklearn.linear_model import LogisticRegression
#logreg = LogisticRegression(C=0.01,class_weight={'No': 1, 'Yes': 1.8},penalty='l2').fit(x_train, y_train)
#print("Training set score: {:.3f}".format(logreg.score(x_train, y_train)))
#print("Test set score: {:.3f}".format(logreg.score(x_test, y_test)))
#y_pred = logreg.predict(x_test)
#print(sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt="d"))  
#print(classification_report(y_test, y_pred)) 
from sklearn.metrics import plot_roc_curve
#classifiers = [('Random Forest Classifier', rf), ('XGBoost Classifier', xgb), ('KNN Classifier', knn),               ('Logistic Regression', logreg)]
#for name, cls in classifiers:
#    cls_pred = cls.predict_proba(x_test)
#    cls_classifier_disp = plot_roc_curve(cls, x_test, y_test)
#    cls_classifier_disp.figure_.suptitle("{} ROC curve".format(name))
#    plt.plot([0,1],[0,1],'k--', label='no skill')
#    plt.legend()
#    plt.grid()
#    plt.show()
from sklearn import model_selection
results = []
names = []
scoring = 'accuracy'
seed=8
#for name, model in classifiers:
#    kfold = model_selection.KFold(n_splits=10, random_state=seed)
#    cv_results = model_selection.cross_val_score(model, x, y, cv=kfold, scoring=scoring)
#    results.append(cv_results)
#    names.append(name)
#    msg = "%s: mean-%f, std-(%f)" % (name, cv_results.mean(), cv_results.std())
#    print(msg)
    
#fig = plt.figure()
#fig.suptitle('Algorithm Comparison')
#ax = fig.add_subplot(111)
#plt.boxplot(results)
#plt.ylabel("Accuracy Scores", fontsize=15)
#ax.set_xticklabels(names)
#ax.grid()
#plt.xticks(rotation=90)
#plt.show()
from sklearn.model_selection import learning_curve
def plot_learning_curve(estimator, title, X, y, axes=None, ylim=None, cv=None,                        n_jobs=None, train_sizes=np.linspace(.1, 1.0, 5)):
#    if axes is None:
#        _, axes = plt.subplots(1, 2, figsize=(20, 5))
#    axes[0].set_title(title)
#    if ylim is not None:
#        axes[0].set_ylim(*ylim)
#    axes[0].set_xlabel("Training examples")
#    axes[0].set_ylabel("Score")
    train_sizes, train_scores, test_scores, fit_times, _ =         learning_curve(estimator, X, y, cv=cv, n_jobs=n_jobs,                       train_sizes=train_sizes,                       return_times=True)
#    train_scores_mean = np.mean(train_scores, axis=1)
#    train_scores_std = np.std(train_scores, axis=1)
#    test_scores_mean = np.mean(test_scores, axis=1)
#    test_scores_std = np.std(test_scores, axis=1)
    fit_times_mean = np.mean(fit_times, axis=1)
    fit_times_std = np.std(fit_times, axis=1)
    
#    axes[0].grid()
#    axes[0].fill_between(train_sizes, train_scores_mean - train_scores_std,                         train_scores_mean + train_scores_std, alpha=0.1,                         color="r")
#    axes[0].fill_between(train_sizes, test_scores_mean - test_scores_std,                         test_scores_mean + test_scores_std, alpha=0.1,                         color="g")
#    axes[0].plot(train_sizes, train_scores_mean, 'o-', color="r",                 label="Training score")
#    axes[0].plot(train_sizes, test_scores_mean, 'o-', color="g",                 label="Cross-validation score")
#    axes[0].legend(loc="best")
#    axes[0].set_title("Learning curve of the model: {}".format(title))
    
#    axes[1].grid()
#    axes[1].plot(train_sizes, fit_times_mean, 'o-')
#    axes[1].fill_between(train_sizes, fit_times_mean - fit_times_std,                         fit_times_mean + fit_times_std, alpha=0.1)
#    axes[1].set_xlabel("Training examples")
#    axes[1].set_ylabel("fit_times")
#    axes[1].set_title("Scalability of the model: {}".format(title))
    
    return plt
#plot_learning_curve(rf, 'Random Forest Classification', x, y, axes=None, ylim=(0.7, 1.01),cv=5, n_jobs=-1)
#plot_learning_curve(xgb, 'XGBoost Classification', x, y, axes=None, ylim=(0.7, 1.01),cv=5, n_jobs=-1)
#plot_learning_curve(knn, 'KNN Classification', x, y, axes=None, ylim=(0.7, 1.01),cv=5, n_jobs=-1)
#plot_learning_curve(logreg, 'Logistic Regression', x, y, axes=None, ylim=(0.7, 1.01),cv=5, n_jobs=-1)
#plt.show()
import shap
shap.initjs()
#explainerRF = shap.TreeExplainer(rf2)
#shap_values = explainerRF.shap_values(x_test)
#shap.summary_plot(shap_values, x_test)
#shap.force_plot(explainerRF.expected_value[0], shap_values[0], x)
import scikitplot as skplt
#predicted_probabilities = rf2.predict_proba(x_test)
#skplt.metrics.plot_cumulative_gain(y_test, predicted_probabilities)
#skplt.metrics.plot_lift_curve(y_test, predicted_probabilities)
#churn_data['Churn_Predictions'] = rf2.predict(x)
#ax = sns.heatmap(confusion_matrix(churn_data['Churn_Predictions'], churn_data['Churn']), annot=True, fmt='d')
#ax.set(xlabel='Random Forest Predictions', ylabel='Truth')




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anirban1992_telecom-churn-fortuneteller.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/anirban1992_telecom-churn-fortuneteller/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anirban1992_telecom-churn-fortuneteller/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anirban1992_telecom-churn-fortuneteller/testY.csv",encoding="gbk")


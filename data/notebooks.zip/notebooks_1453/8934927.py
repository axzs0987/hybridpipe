import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

from sklearn import tree
from sklearn import svm
from sklearn import ensemble
from sklearn import neighbors
from sklearn import linear_model
from sklearn import metrics
from sklearn import preprocessing
from sklearn import preprocessing
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.datasets import make_blobs
import seaborn as sns

# In[None]

# load the dataset
df= pd.read_csv('../input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv')
print("The dataset has %d rows and %d columns." % df.shape)

# L# e# t# s#  # C# h# e# c# k#  # M# i# s# s# i# n# g#  # v# a# l# u# e# s

# In[None]

percent_missing = df.isnull().sum() * 100 / len(df)
percent_missing

# T# a# r# g# e# t#  # v# a# r# i# a# b# l# e# s

# In[None]

df.Attrition.replace(to_replace = dict(Yes = 1, No = 0), inplace = True)

# In[None]

df['Attrition'].value_counts(normalize=True)

# T# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # i# s#  # i# m# b# a# l# a# n# c# e# d# .#  # W# e#  # c# a# n#  # t# r# y#  # t# o#  # u# s# e#  # s# a# m# p# l# i# n# g#  # t# o#  # f# i# x#  # t# h# i# s#  # b# u# t#  # w# e#  # w# i# l# l#  # d# o#  # t# h# i# s#  # l# a# t# e# r# .

# In[None]

df.head()

# In[None]

df.describe()

# In[None]

fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['Age'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['DailyRate'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['DistanceFromHome'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['Education'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['EnvironmentSatisfaction'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['HourlyRate'], hue=df['Attrition'])
fig, (axis1) = plt.subplots(1,1,figsize=(15,10))
sns.countplot(df['Age'], hue=df['Attrition'])

# In[None]

print("------  Data Types  ----- \n",df.dtypes)

# In[None]

import seaborn as sns
corr = df.corr()
plt.figure(figsize=(15,10))
sns.heatmap(corr,cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10},cmap='YlGnBu')

# In[None]

#Lets drop few variables which doesnt look helpful
df = df.drop(['EmployeeCount','EmployeeNumber'], axis=1)

# O# n# e#  # h# o# t#  # e# n# c# o# d# i# n# g#  # t# o#  # f# i# x#  # t# h# e#  # v# a# r# i# a# b# l# e# s# .

# In[None]

dataset =  df.drop(['OverTime','MaritalStatus','JobRole','Gender','Department','EducationField','BusinessTravel','Over18'], axis=1)
BusinessTravel = pd.get_dummies(df.BusinessTravel).iloc[:,1:]
Department = pd.get_dummies(df.Department).iloc[:,1:]
OverTime = pd.get_dummies(df.OverTime).iloc[:,1:]
MaritalStatus = pd.get_dummies(df.MaritalStatus).iloc[:,1:]
JobRole = pd.get_dummies(df.JobRole).iloc[:,1:]
Gender = pd.get_dummies(df.Gender).iloc[:,1:]
EducationField = pd.get_dummies(df.EducationField).iloc[:,1:]
Over18 = pd.get_dummies(df.Over18).iloc[:,1:]
dataset = pd.concat([dataset,Over18,BusinessTravel,Department,OverTime,MaritalStatus,JobRole,Gender,], axis=1)
dataset

# In[None]

print("------  Data Types  ----- \n",dataset.dtypes)

# In[None]

X =  dataset.drop(['Attrition'], axis=1)
y = dataset['Attrition']

# R# A# N# D# O# M#  # F# o# r# e# s# t#  # M# o# d# e# l

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8934927.npy", { "accuracy_score": score })

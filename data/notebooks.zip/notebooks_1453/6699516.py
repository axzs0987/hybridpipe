import pandas as pd
# ## ## ## ## ## ##  # I# n#  # t# h# i# s#  # n# o# t# e# b# o# o# k# ,#  # F# i# r# s# t#  # I#  # h# a# v# e#  # d# o# n# e#  # s# o# m# e#  # e# x# p# l# o# r# a# t# i# o# n#  # o# n#  # t# h# e#  # d# a# t# a#  # u# s# i# n# g#  # m# a# t# p# l# o# t# l# i# b#  # a# n# d#  # s# e# a# b# o# r# n# .#  # T# h# e# n# ,#  # I#  # u# s# e#  # d# i# f# f# e# r# e# n# t#  # c# l# a# s# s# i# f# i# e# r#  # m# o# d# e# l# s#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # t# h# e#  # w# i# n# e# .# 
# 
# 1# .#  # L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n# 
# 
# 2# .#  # R# a# n# d# o# m#  # F# o# r# e# s# t#  # C# l# a# s# s# i# f# i# e# r# 
#  # 
# 3# .#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # C# l# a# s# s# i# f# i# e# r# (# S# V# C# )# 
# 
# ## ## ## ## ## ##  # t# h# e# n#  # i#  # d# i# d#  # s# o# m# e#  # r# e# s# a# m# p# l# i# n# g#  # i# n#  # t# h# e#  # g# i# v# e# n#  # d# a# t# a#  # a# s#  # t# h# e#  # d# a# t# a#  # i# s#  # i# m# b# a# l# a# n# c# e# d#  # w# h# i# c# h#  # g# a# v# e#  # m# e#  # s# o# m# e#  # d# i# f# f# e# r# e# n# t#  # r# e# s# u# l# t# s# .

# ## ## ## ## ## ##  # i# m# p# o# r# t# i# n# g#  # r# e# q# u# i# r# e# d#  # p# a# c# k# a# g# e# s

# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.svm import SVC

# In[None]

data=pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')

# ## ## ## ## ## ##  # s# o# m# e#  # b# a# s# i# c#  # o# b# s# e# r# v# a# t# i# o# n#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

data.head()

# In[None]

data.shape

# In[None]

data.isnull().sum()

# ## ## ## ## ## ##  # n# o#  # n# u# l# l#  # v# a# l# u# e# s#  # g# r# e# a# t# !# !

# In[None]

data.describe()

# In[None]

data['quality'].unique()

# In[None]

data.info()

# In[None]

sns.countplot(data['quality'])

# a# s#  # w# e#  # c# a# n#  # s# e# e#  # t# h# e#  # d# a# t# a#  # i# s#  # i# m# b# a# l# a# n# c# e# d#  # .# 
# 
# t# h# e#  # q# u# a# l# i# t# y#  # 5#  # a# n# d#  # 6#  # o# f#  # t# h# e#  # w# i# n# e#  # a# r# e#  # i# n#  # l# a# r# g# e#  # n# u# m# b# e# r#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r#  # q# u# a# l# i# t# i# e# s# .# 
# 


# In[None]

data.corr()

# ## ## ## ## ## ##  # s# o# m# e#  # v# i# s# u# a# l# i# s# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # v# a# r# i# o# u# s#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# h# e#  # q# u# a# l# i# t# y#  # o# f#  # t# h# e#  # w# i# n# e# .

# In[None]

data_columns=data.columns

# In[None]

for ele in data_columns:
    fig = plt.figure(figsize = (10,6))
    sns.barplot(x = 'quality', y = ele, data = data)

# ## ## ## ## ## ##  # a# s#  # p# e# r#  # t# h# e#  # p# r# o# b# l# e# m#  # s# t# a# t# e# m# e# n# t#  # w# e#  # h# a# v# e#  # t# o#  # c# l# a# s# s# i# f# y#  # t# h# e#  # w# i# n# e#  # t# y# p# e#  # i# n#  # t# w# o#  # v# a# r# i# t# i# e# s#  # g# o# o# d#  # o# r#  # b# a# d# .# 
# 
# ## ## ## ## ## ##  # 1#  # f# o# r#  # g# o# o# d#  # a# n# d#  # 0#  # f# o# r#  # b# a# d# .# 
# 
# ## ## ## ## ## ##  # t# h# e#  # c# r# i# t# e# r# i# a#  # t# o#  # d# e# c# i# d# e#  # w# h# e# t# h# e# r#  # i# t#  # i# s#  # g# o# o# d#  # o# r#  # b# a# d#  # i# s#  # t# h# a# t#  # i# f#  # t# h# e#  # q# u# a# l# i# t# y#  # s# c# o# r# e#  # i# s#  # l# e# s# s#  # t# h# a# n#  # 6# .# 5#  # i# t#  # i# s#  # a#  # b# a# d#  # w# i# n# e#  # a# n# d#  # i# f#  # i# t#  # i# s#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 6# .# 5#  # i# t#  # i# s#  # c# o# n# s# i# d# e# r# e# d#  # a# s#  # g# o# o# d# .

# ## ## ## ## ## ##  # c# o# n# v# e# r# t# i# n# g#  # t# h# e#  # q# u# a# l# i# t# y#  # t# o#  # 0#  # a# n# d#  # 1#  # d# e# p# e# n# d# i# n# g#  # o# n#  # t# h# e# i# r#  # s# c# o# r# e# .

# In[None]

for i in range(1599):
    if(data['quality'][i]<=6.5):
        data['quality'][i]=0
    else:
        data['quality'][i]=1

# ## ## ## ## ## ##  # n# o# w#  # w# e#  # h# a# v# e#  # t# w# o#  # v# a# r# i# t# i# e# s#  # i# n#  # o# u# r#  # q# u# a# l# i# t# y#  # c# o# l# u# m# n#  # e# i# t# h# e# r#  # 0#  # o# r#  # 1#  # a# n# d#  # t# h# e#  # c# o# u# n# t#  # o# f#  # e# a# c# h#  # v# a# r# i# e# t# y#  # i# s#  # s# h# o# w# n#  # i# n#  # t# h# e#  # c# o# u# n# t# p# l# o# t#  # .

# In[None]

data['quality'].unique()

# In[None]

sns.countplot(data['quality'])

# ## ## ## ## ## ##  # t# h# i# s#  # d# a# t# a#  # i# s#  # a# l# s# o#  # i# m# b# a# l# a# n# c# e# d#  # b# u# t#  # l# e# t# s#  # c# o# n# t# i# n# u# e#  # w# i# t# h#  # t# h# i# s#  # d# a# t# a#  # a# n# d#  # s# e# e#  # w# h# a# t#  # w# e#  # c# a# n#  # d# o# .

# ## ## ## ## ## ##  # u# s# i# n# g#  # l# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l#  # .

# In[None]

model=LogisticRegression(solver='lbfgs',multi_class='auto',max_iter=1000)

# In[None]

y=data['quality']
X=data.drop(['quality'],axis=1)

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6699516.npy", { "accuracy_score": score })

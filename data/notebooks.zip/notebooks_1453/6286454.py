import pandas as pd
# ##  # A# d# u# l# t#  # i# n# c# o# m# e#  # d# a# t# a# s# e# t

# ## ##  # S# t# e# p#  # 1# .#  # W# h# a# t#  # i# s#  # t# h# e#  # g# o# a# l#  # o# f#  # t# h# i# s#  # a# n# a# l# y# s# i# s#  # ?# 
# T# h# e#  # g# o# a# l#  # i# s#  # t# o#  # t# r# a# i# n#  # a#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# e# r#  # o# n#  # t# h# e#  # t# r# a# i# n# i# n# g#  # d# a# t# a# s# e# t#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # c# o# l# u# m# n#  # i# n# c# o# m# e# _# b# r# a# c# k# e# t#  # w# h# i# c# h#  # h# a# s#  # t# w# o#  # p# o# s# s# i# b# l# e#  # v# a# l# u# e# s#  # "# ># 5# 0# K# "#  # a# n# d#  # "# <# =# 5# 0# K# "#  # a# n# d#  # e# v# a# l# u# a# t# e#  # t# h# e#  # a# c# c# u# r# a# c# y#  # o# f#  # t# h# e#  # c# l# a# s# s# i# f# i# e# r#  # w# i# t# h#  # t# h# e#  # t# e# s# t#  # d# a# t# a# s# e# t# .#  

# In[None]

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# In[None]

# default libraries
import numpy as np
import pandas as pd

# for data preprocessing
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# for classifier models
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold, cross_val_score
import xgboost as xgb

# for models evaluation
from sklearn.metrics import confusion_matrix, accuracy_score

# ## ##  # S# t# e# p#  # 2# .#  # L# o# a# d# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t

# In[None]

dataset = pd.read_csv("/kaggle/input/adult-income-dataset/adult.csv")
dataset.head()

# In[None]

dataset.shape

# ## ##  # S# t# e# p#  # 3# .#  # E# x# p# l# o# r# a# t# o# r# y#  # d# a# t# a#  # a# n# a# l# y# s# i# s#  # E# D# A#  # -#  # D# a# t# a#  # c# l# e# a# n# i# n# g#  # a# n# d#  # e# x# p# l# o# r# a# t# i# o# n

# ## ## ##  # a# .#  # C# l# e# a# n# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

dataset.info()

# In[None]

dataset.isnull().sum()

# In[None]

dataset.nunique()

# In[None]

dataset['income'] = dataset['income'].map({'<=50K':0, '>50K':1})

# ## ## ##  # b# .#  # M# a# k# i# n# g#  # c# o# d# e#  # m# o# d# u# l# a# r#  

# In[None]

def init_check(df):
    """
    A function to make initial check for the dataset including the name, data type, 
    number of null values and number of unique varialbes for each feature.
    
    Parameter: dataset(DataFrame)
    Output : DataFrame
    """
    columns = df.columns    
    lst = []
    for feature in columns : 
        dtype = df[feature].dtypes
        num_null = df[feature].isnull().sum()
        num_unique = df[feature].nunique()
        lst.append([feature, dtype, num_null, num_unique])
    
    check_df = pd.DataFrame(lst)
    check_df.columns = ['feature','dtype','num_null','num_unique']
    check_df = check_df.sort_values(by='dtype', axis=0, ascending=True)
    
    return check_df

# In[None]

#init_check?

# In[None]

init_check(df=dataset)

# ## ## ##  # c# .#  # V# i# s# u# a# l# i# z# i# n# g#  # t# h# e#  # d# a# t# a# 
# 
# S# k# i# p

# ## ## ##  # d# .#  # F# e# a# t# u# r# e#  # e# n# g# i# n# e# e# r# i# n# g

# In[None]

def categorical_encoding(df, categorical_cloumns, encoding_method):
    """
    A function to encode categorical features to a one-hot numeric array (one-hot encoding) or 
    an array with value between 0 and n_classes-1 (label encoding).
    
    Parameters:
        df (pd.DataFrame) : dataset
        categorical_cloumns  (string) : list of features 
        encoding_method (string) : 'one-hot' or 'label'
    Output : pd.DataFrame
    """
    
    if encoding_method == 'label':
        print('You choose label encoding for your categorical features')
        encoder = LabelEncoder()
        encoded = df[categorical_cloumns].apply(encoder.fit_transform)
        return encoded
    
    elif encoding_method == 'one-hot':
        print('You choose one-hot encoding for your categorical features') 
        encoded = pd.DataFrame()
        for feature in categorical_cloumns:
            dummies = pd.get_dummies(df[feature], prefix=feature)
            encoded = pd.concat([encoded, dummies], axis=1)
        return encoded

# In[None]

#categorical_encoding?

# In[None]

categorical_encoding(df=dataset, categorical_cloumns=['workclass','education'], encoding_method='one-hot')

# In[None]

categorical_encoding(dataset, categorical_cloumns=['workclass','education'], encoding_method='label')

# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =# =

# In[None]

y = dataset['income']

# In[None]

X = dataset.drop(columns='income', axis=1)
categorical_columns = X.select_dtypes(include=['object']).columns
print(categorical_columns)

# In[None]

encoded = categorical_encoding(X, categorical_cloumns=categorical_columns, encoding_method='one-hot')
encoded.head()

# In[None]

X = X.drop(columns=categorical_columns, axis=1)
X = pd.concat([X, encoded], axis=1)
X.head()

# In[None]

X.shape

# ## ## ##  # e# .#  # D# a# t# a#  # s# p# l# i# t#  # a# n# d#  # d# a# t# a#  # s# c# a# l# i# n# g

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6286454.npy", { "accuracy_score": score })

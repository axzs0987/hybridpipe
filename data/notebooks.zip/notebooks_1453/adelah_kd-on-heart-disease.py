import sklearn 
print('The scikit-learn version is {}.'.format(sklearn.__version__))
import numpy 
print('The scikit-learn version is {}.'.format(numpy.__version__))
import scipy 
print('The scikit-learn version is {}.'.format(scipy.__version__))
import joblib 
print('The scikit-learn version is {}.'.format(joblib.__version__))
import numpy as np 
import pandas as pd 
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler  
from sklearn.neighbors import KNeighborsClassifier   
import seaborn as sns
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
import os
#print(os.listdir("../input"))
df = pd.read_csv("../input/heart.csv")
df.columns
updated_cols = ['Age', 'Sex', 'ChestPainType', 'RestingBP', 'SerumCholestoral', 'FastingBloodSugar', 'RestingECG',                'MaxHeartRate', 'ExeriseEnducedAngina', 'OldPeak', 'SlopeOldPeak', 'MajorVessels', 'Thal', 'Output']
df.columns = updated_cols
df.to_csv("..heart1.csv")
df.head()
X = df.iloc[:, :-1].values  
y = df.iloc[:, -1].values  
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
# error = []
# for i in range(1, 15):  
#     clf = tree.DecisionTreeClassifier(criterion='gini', splitter='best', max_depth=i, min_samples_split=2,                                  min_samples_leaf=1, random_state=0)
#    clf.fit(X_train, y_train)
#    pred_i = clf.predict(X_test)
#    error.append(np.mean(pred_i != y_test))
#plt.figure(figsize=(12, 6))  
#plt.plot(range(1, 15), error, color='red', linestyle='dashed', marker='o',           markerfacecolor='blue', markersize=10)
#plt.title('Error Rate DT Depth')  
#plt.xlabel('Depth')  
#plt.ylabel('Mean Error')  
# clf = tree.DecisionTreeClassifier(criterion='gini', splitter='best', max_depth=4, min_samples_split=2,                                  min_samples_leaf=1, random_state=0)
#clf = clf.fit(X_train, y_train )
#(pd.Series(clf.feature_importances_, index=df.columns[:-1]).nlargest(13).plot(kind='barh'))
# from sklearn.tree import export_graphviz
#export_graphviz(clf, out_file='tree.dot', feature_names = df.columns[:-1],                class_names = df.columns[-1],                rounded = True, proportion = False, precision = 2, filled = True)
# from subprocess import call
# call(['dot', '-Tpng', 'tree.dot', '-o', 'tree.png', '-Gdpi=600'])
#plt.figure(figsize = (37, 45))
#plt.imshow(plt.imread('tree.png'))
#plt.axis('off');
#plt.show();
#plt.savefig('tree.png')
# from sklearn.metrics import accuracy_score
#y_pred = clf.predict(X_test)
#accuracy_score(y_test, y_pred)
# scaler = StandardScaler()  
# scaler.fit(X_train)
# X_train_s = scaler.transform(X_train)  
# X_test_s = scaler.transform(X_test)  
# classifier = KNeighborsClassifier(n_neighbors=4)  
#classifier.fit(X_train_s, y_train)  
#y_pred = classifier.predict(X_test_s)  
# from sklearn.metrics import classification_report, confusion_matrix  
#print(confusion_matrix(y_test, y_pred))  
#print(classification_report(y_test, y_pred))  
# error = []
# for i in range(1, 40):  
#     knn = KNeighborsClassifier(n_neighbors=i)
#    knn.fit(X_train_s, y_train)
#    pred_i = knn.predict(X_test_s)
#    error.append(np.mean(pred_i != y_test))
#plt.figure(figsize=(12, 6))  
#plt.plot(range(1, 40), error, color='red', linestyle='dashed', marker='o',           markerfacecolor='blue', markersize=10)
#plt.title('Error Rate K Value')  
#plt.xlabel('K Value')  
#plt.ylabel('Mean Error')  
#sns.distplot(df['Age'],color='Red',hist_kws={'alpha':1,"linewidth": 2}, kde_kws={"color": "k", "lw": 3, "label": "KDE"})
#plt.figure(figsize=(10,8))
#sns.heatmap(df.corr(),annot=True,cmap='YlGnBu',fmt='.2f',linewidths=2)
#sns.set_style('whitegrid')
#plt.figure(figsize=(30,15))
#sns.pairplot(df, hue='Output', palette='coolwarm')
# import numpy as np
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import ListedColormap
# from sklearn import neighbors, datasets
# n_neighbors = 4
# X = np.c_[X_train[:,0], X_train[:,7]].reshape(len(X_train),2) 
                      
# y = y_train
# h = .02  
# cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA' ])
# cmap_bold = ListedColormap(['#FF0000', '#00FF00'])
# for weights in ['uniform', 'distance']:
    
#     clf = neighbors.KNeighborsClassifier(n_neighbors, weights=weights)
#    clf.fit(X, y)
    
    
    # x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    # y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    # xx, yy = np.meshgrid(np.arange(x_min, x_max, h),                         np.arange(y_min, y_max, h))
#    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    
    
    
#    Z = Z.reshape(xx.shape)
#    plt.figure()
#    plt.pcolormesh(xx, yy, Z, cmap=cmap_light)
    
#    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold)
#    plt.xlim(xx.min(), xx.max())
#    plt.ylim(yy.min(), yy.max())
#    plt.title("2-Class classification (k = %i, weights = '%s')"              % (n_neighbors, weights))
#plt.show()
# from sklearn.cluster import KMeans
# import numpy as np
# X_train_s = np.c_[X_train[:,4], X_train[:,7]].reshape(len(X_train_s),2)
# X_test_s =  np.c_[X_test_s[:,4], X_test_s[:,7]].reshape(len(X_test_s),2)
# kmeans = KMeans(n_clusters=2, random_state=0).fit(X_train_s)
# y_pred = kmeans.predict(X_test_s)
#accuracy_score(y_test, y_pred)
# kmeans.cluster_centers_
# X_train_s
#plt.scatter(X_train_s[:,0], X_train_s[:,1], c=kmeans.labels_, cmap='rainbow')  
#plt.scatter(kmeans.cluster_centers_[:,0] ,kmeans.cluster_centers_[:,1], color='black')  
# from sklearn import datasets
# from sklearn.naive_bayes import GaussianNB
# gnb = GaussianNB()
# y_pred = gnb.fit(X_train, y_train).predict(X_test)
#print("Number of mislabeled points out of a total %d points : %d"     % (X_test.shape[0],(y_test != y_pred).sum()))
# from sklearn import metrics
# y_pred = gnb.predict(X_test)
#print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
# from sklearn import svm
# clf = svm.SVC(gamma='scale')
#clf.fit(X_train, y_train)
#y_pred = clf.predict(X_test)
#accuracy_score(y_test, y_pred)
# from sklearn.ensemble import AdaBoostClassifier
# from sklearn.datasets import make_classification
# ada=AdaBoostClassifier()
# search_grid={'n_estimators':[500,1000,2000],'learning_rate':[.001,0.01,.1]}
# search=GridSearchCV(estimator=ada,param_grid=search_grid,scoring='accuracy',n_jobs=1,cv=5)
# search
# clf = AdaBoostClassifier(algorithm='SAMME.R', base_estimator=None,          learning_rate=1.0, n_estimators=50, random_state=None)
#clf.fit(X_train, y_train)  
#(pd.Series(clf.feature_importances_, index=df.columns[:-1]).nlargest(13).plot(kind='barh'))
#score=np.mean(cross_val_score(clf,X_train,y_train,scoring='accuracy',cv=5,n_jobs=1))
#score




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/adelah_kd-on-heart-disease.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/adelah_kd-on-heart-disease/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/adelah_kd-on-heart-disease/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/adelah_kd-on-heart-disease/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/adelah_kd-on-heart-disease/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/adelah_kd-on-heart-disease/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/adelah_kd-on-heart-disease/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/adelah_kd-on-heart-disease/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/adelah_kd-on-heart-disease/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/adelah_kd-on-heart-disease/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/adelah_kd-on-heart-disease/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/adelah_kd-on-heart-disease/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/adelah_kd-on-heart-disease/testY.csv",encoding="gbk")


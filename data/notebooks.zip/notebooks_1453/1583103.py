import pandas as pd
# I# n#  # t# h# i# s#  # k# e# r# n# e# l#  # I#  # a# m#  # g# o# i# n# g#  # t# o#  # d# o#  # s# o# m# e#  # b# a# s# i# c#  # E# D# A#  # o# n#  # t# h# e#  # d# a# t# a# .#  # A# l# s# o#  # I#  # a# m#  # g# o# i# n# g#  # t# o#  # b# u# i# l# d#  # a#  # c# l# a# s# s# i# f# e# r#  # w# h# i# c# h#  # w# i# l# l#  # p# r# e# d# i# c# t#  # w# h# a# t#  # f# e# a# t# u# r# e# s#  # e# f# f# e# c# t# s#  # c# u# s# t# o# m# e# r#  # r# e# t# e# n# t# i# o# n# .

# In[None]

import pandas as pd

df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')
df.head()

# ## ## ##  # E# x# p# l# o# r# i# n# g#  # R# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # C# h# u# r# n#  # a# n# d#  # F# e# t# u# r# e# s# 
# 
# L# e# t# s#  # t# a# k# e#  # a#  # l# o# o# k#  # a# t#  # w# h# a# t#  # f# a# c# t# o# r# s#  # s# t# r# o# n# g# l# y#  # i# n# f# l# u# e# n# c# e#  # C# h# u# r# n#  # r# a# t# i# o

# In[None]

import numpy as np
import matplotlib.pyplot as plt

SMALL_SIZE = 15
MEDIUM_SIZE = 17
BIGGER_SIZE = 20

plt.rc('font', size=SMALL_SIZE)
plt.rc('axes', titlesize=SMALL_SIZE)
plt.rc('axes', labelsize=MEDIUM_SIZE)
plt.rc('xtick', labelsize=SMALL_SIZE)
plt.rc('ytick', labelsize=SMALL_SIZE)
plt.rc('legend', fontsize=SMALL_SIZE)
plt.rc('figure', titlesize=BIGGER_SIZE)

df_eda = df.copy()
cols = df_eda.columns.tolist()
cols = set(cols) - set(['customerID', 'TotalCharges', 'tenure', 'MonthlyCharges', 'Churn'])

fig, *axes = plt.subplots(nrows=8, ncols=2, figsize=(20,35))
axes = np.array(axes).ravel()

for c,i in enumerate(cols):
    df_eda.groupby(['Churn', i]).size().unstack(level=0).plot(kind='barh', ax=axes[c])
plt.tight_layout()

# ## ## ##  # P# r# e# p# r# o# c# e# s# s# i# n# g# 
# 
# N# e# x# t#  # I#  # a# m#  # g# o# i# n# g#  # t# o#  # d# o#  # s# o# m# e#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # f# o# r#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l# s# .#  

# In[None]

Y = df['Churn'].map({"Yes": 1, "No": 0})
df = df.drop('Churn', 1);
df = df.drop('customerID', 1);

# In[None]

#Check dtypes of columns
df.dtypes

# In[None]

#Cast `TotalCharges` to float
df['TotalCharges'] = df['TotalCharges'].apply(pd.to_numeric, errors='coerce')

# In[None]

#Check NaN values in columns
df.isnull().sum()

# In[None]

#Fill NaN with 0 in `TotalCharges`
df['TotalCharges'] = df['TotalCharges'].fillna(0)

# In[None]

c_single = ('Partner', 'Dependents', 'PhoneService', 'PaperlessBilling', 'gender')
c_all = ('MultipleLines', 'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract', 'PaymentMethod')

df_categorical = df.join(pd.concat([pd.get_dummies(df[col], prefix=col, drop_first=True) for col in c_single] + [pd.get_dummies(df[col], prefix=col) for col in c_all], axis=1))
df_categorical.drop(list((c_single + c_all)), inplace=True, axis=1)
df_categorical.head()

# ## ## ##  # C# h# u# r# n#  # P# r# e# d# i# c# t# i# o# n# 
# 
# I#  # a# m#  # g# o# i# n# g#  # t# o#  # t# e# s# t#  # t# h# r# e# e#  # m# o# d# e# l#  # i# .# e# .#  # *# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# ,#  # D# e# c# i# s# i# o# n#  # T# r# e# e#  # a# n# d#  # R# a# n# d# o# m#  # F# o# r# e# s# t# *#  # w# i# t# h#  # *# R# O# C#  # A# U# C# *#  # a# s#  # e# v# a# l# u# a# t# i# o# n#  # m# e# t# r# i# c# .

# In[None]

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(df_categorical, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1583103.npy", { "accuracy_score": score })

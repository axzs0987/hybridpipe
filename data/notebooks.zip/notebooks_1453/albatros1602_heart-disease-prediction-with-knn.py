import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
dt = pd.read_csv('../input/heart-disease-uci/heart.csv')
dt.head()
dt.info()
Y = dt[dt.target == 1]
N = dt[dt.target == 0]
#plt.scatter(Y.age,Y.thalach, color = "red", label = "Heart Diease Present")
#plt.scatter(N.age,N.thalach, color = "green", label = "Heart Diease NOT Present")
#plt.xlabel("age")
#plt.ylabel("thalach")
#plt.legend()
#plt.show()
y = dt.target.values
x_dt = dt.drop(["target"], axis = 1)
x = (x_dt - np.min(x_dt))/(np.max(x_dt)-np.min(x_dt))
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 3) 
#knn.fit(x_train, y_train)
#prediction = knn.predict(x_test)
#print("{} nn score: {} ".format(3,knn.score(x_test,y_test)))
score_list = []
for each in range(1,30):
    knn2 = KNeighborsClassifier(n_neighbors = each)
#    knn2.fit(x_train,y_train)
#    score_list.append(knn2.score(x_test,y_test))
    
#plt.plot(range(1,30),score_list)
#plt.xlabel("K values")
#plt.ylabel("Accuracy")
#plt.show()



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
print("start running model training........")
model = KNeighborsClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/albatros1602_heart-disease-prediction-with-knn.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/albatros1602_heart-disease-prediction-with-knn/testY.csv",encoding="gbk")


import pandas as pd
# *# *# I# n# t# r# o# d# u# c# t# i# o# n# :# *# *#  # 
#  #  #  #  #  #  #  #  #  #  # I# n#  # t# h# i# s#  # a# t# t# r# i# t# i# o# n#  # d# a# t# a# s# e# t# ,#  # w# i# l# l#  # p# e# r# f# o# r# m#  # t# h# e#  # E# D# A#  # t# o#  # f# i# n# d#  # o# u# t#  # t# h# e#  # m# o# s# t#  # i# m# p# o# r# t# a# n# t#  # m# e# t# r# i# c# s#  # w# h# i# c# h#  # a# r# e#  # a# l# l#  # p# l# a# y# i# n# g#  # m# a# j# o# r#  # r# o# l# e#  # i# n#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n# .#  # 
#  #  #  #  # 
#  #  #  #  # B# a# s# i# c#  # t# h# i# n# g# s#  # n# e# e# d#  # t# o#  # f# i# n# d#  # o# u# t#  # f# r# o# m#  # t# h# i# s#  # d# a# t# a# s# e# t#  # w# o# u# l# d#  # b# e#  # :#  # 
#  #  #  #  # 1# .#  # H# o# w#  # s# a# t# i# s# f# i# e# d#  # o# u# t#  # e# m# p# l# o# y# e# e# s#  # 
#  #  #  #  # 2# .#  # H# o# u# r# l# y#  # r# a# t# e#  # r# e# l# a# t# e# d#  # w# i# t# h#  # e# d# u# c# a# t# i# o# n#  # a# n# d#  # g# e# n# d# e# r#  # 
#  #  #  #  # 3# .#  # H# o# w#  # j# o# b#  # i# n# v# o# v# l# m# e# n# t#  # c# o# r# r# e# l# a# t# e# d#  # w# i# t# h#  # j# o# b#  # s# a# t# i# s# f# a# c# t# i# o# n#  

# 
# !# [# A# t# t# r# i# t# i# o# n# ]# (# h# t# t# p# :# /# /# t# h# e# c# o# n# t# e# x# t# o# f# t# h# i# n# g# s# .# c# o# m# /# w# p# -# c# o# n# t# e# n# t# /# u# p# l# o# a# d# s# /# 2# 0# 1# 7# /# 0# 1# /# e# m# p# l# o# y# e# e# -# a# t# t# r# i# t# i# o# n# .# j# p# g# )

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# *# *# R# e# a# d#  # t# h# e#  # c# s# v#  # f# i# l# e# *# *

# In[None]

data = pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# In[None]

data.head()

# In[None]

data.describe()

# *# *# D# a# t# a#  # o# v# e# r# v# i# e# w# *# *

# In[None]

import seaborn as sns 
import matplotlib.pyplot as plt 

# In[None]

sns.distplot(data['Age'])

# *# *# T# o# t# a# l#  # d# a# i# l# y#  # r# a# t# e#  # b# y#  # d# e# p# a# r# t# m# e# n# t#  # w# i# s# e# *# *

# In[None]

sns.set(style = 'whitegrid')
dailyrate = sns.barplot(x='Department', y='DailyRate' , data = data , estimator = sum  )


# *# *# A# v# e# r# a# g# e#  # d# a# i# l# y#  # r# a# t# e#  # b# y#  # D# e# p# a# r# t# m# e# n# t# *# *

# In[None]

from numpy import mean , median 
sns.set(style = 'whitegrid')
avg = sns.barplot(x='Department', y='DailyRate' , data = data , estimator = np.median  )

# *# *# *# *# M# e# d# i# a# n#  # d# a# i# l# y#  # r# a# t# e#  # b# y#  # g# e# n# d# e# r#  # a# n# d# *# *# *# *#  # d# e# p# a# r# t# m# e# n# t#  # w# i# s# e#  

# In[None]

sns.set(style = 'whitegrid')
sns.barplot(x='Department', y='DailyRate' , data = data , estimator = np.median, hue = data['Gender'])

# *# *# *# *# A# t# t# r# i# t# i# o# n#  # b# a# s# e# d#  # o# n#  # b# u# s# i# n# e# s# s#  # t# r# a# v# e# l# *# *# *# *

# In[None]

sns.barplot(x = data['BusinessTravel'] , y = data['EmployeeCount'],estimator = np.sum, hue = data['Attrition'])

# *# *# *# *# H# o# w#  # s# a# t# i# s# f# i# e# d#  # t# h# e#  # e# m# p# l# o# y# e# e# s#  # a# r# e# ?# *# *# *# *

# In[None]

sns.scatterplot(x= data['MonthlyIncome'], y = data['TotalWorkingYears'], hue = data['Attrition'])

# *# *# P# r# o# p# o# s# i# t# i# o# n#  # o# f#  # a# t# t# r# i# t# i# o# n#  # i# n#  # t# h# i# s#  # d# a# t# a# s# e# t# *# *

# In[None]

sns.countplot(x= data['Attrition'], data = data, hue = data['Gender'])

# *# *# H# o# w#  # m# a# r# i# t# a# l#  # s# t# a# t# u# s#  # i# m# p# a# c# t# s#  # t# h# e#  # a# t# t# r# i# t# i# o# n# *# *

# In[None]

sns.countplot(x = data['MaritalStatus'],hue=data['Attrition'] , data = data)

# *# *# H# o# w#  # m# a# n# y#  # o# f#  # t# h# e# m#  # s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e#  # j# o# b# *# *

# In[None]

sns.barplot(y=data['JobRole'], x=data['JobSatisfaction'],estimator = np.mean, data = data)

# *# *# H# o# u# r# l# y#  # r# a# t# e#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # e# d# u# c# a# t# i# o# n#  # f# i# e# l# d#  # a# n# d#  # g# e# n# d# e# r# *# *

# In[None]

sns.set(style = 'white')
sns.barplot(x=data['EducationField'], y=data['HourlyRate'], estimator = np.median, hue = data['Gender'])

# *# *# A# n# y#  # M# i# s# s# i# n# g#  # v# a# l# u# e# s# *# *

# In[None]

data.isnull().sum()

# *# *# T# r# e# a# t#  # c# a# t# e# g# o# r# i# c# a# l#  # l# a# b# e# l# s#  # a# n# d#  # c# h# a# n# g# e#  # i# n# t# o#  # n# u# m# e# r# i# c#  #  # v# a# l# u# e# s# *# *

# T# y# p# e# s#  # o# f#  # t# e# c# h# n# i# q# u# e# s#  # f# o# r#  # e# n# c# o# d# i# n# g#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # d# a# t# a# 
# 1# .#  # R# e# p# l# a# c# i# n# g#  # v# a# l# u# e# s# 
# 2# .#  # E# n# c# o# d# i# n# g#  # l# a# b# e# l# s# 
# 3# .#  # O# n# e# -# H# o# t#  # e# n# c# o# d# i# n# g# 
# 4# .#  # B# i# n# a# r# y#  # e# n# c# o# d# i# n# g# 
# 5# .#  # B# a# c# k# w# a# r# d#  # d# i# f# f# e# r# e# n# c# e#  # e# n# c# o# d# i# n# g# 
# 6# .#  # M# i# s# c# e# l# l# a# n# e# o# u# s#  # f# e# a# t# u# r# e# s

# In[None]

data.dtypes

# In[None]

data_replace = data.copy()

# In[None]

obj_df = data.select_dtypes(include=['object']).copy()
obj_df.head()

# *# *# A# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # c# o# l# u# m# n# s# *# *

# In[None]

obj_df[obj_df.isnull().any(axis=1)]

# *# *# T# h# e# r# e#  # i# s#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # a# n# y#  # o# f#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # v# a# l# u# e# s# *# *

# *# *# *# *# ## F# i# n# d#  # a# n# d#  # R# e# p# l# a# c# e#  # m# e# t# h# o# d#  # i# n#  # r# e# p# l# a# c# i# n# g#  # c# a# t# e# g# o# r# i# c# a# l#  # t# o#  # n# u# m# e# r# i# c# s#  # v# a# l# u# e# s# *# *#  

# In[None]

obj_df['BusinessTravel'].value_counts()

# In[None]

obj_df['BusinessTravel'] = obj_df['BusinessTravel'].astype('category')
obj_df.dtypes

# In[None]


data['BusinessTravel'] = obj_df['BusinessTravel'].cat.codes
data.head()

# *# *# C# h# e# c# k# i# n# g#  # f# o# r#  # c# o# n# v# e# r# t# i# n# g#  # t# h# e#  # c# a# t# e# g# o# r# i# c# a# l#  # t# o#  # n# u# m# e# r# i# c#  # i# s#  # s# u# c# c# e# s# s# f# u# l# .#  # N# o# w#  # I#  # c# a# n#  # a# p# p# l# y#  # t# h# e#  # s# a# m# e#  # c# o# n# c# e# p# t#  # t# o#  # t# h# e#  # r# e# s# t#  # o# f#  # t# h# e#  # v# a# r# i# a# b# l# e# s# *# *

# In[None]

obj_df['Department'] = obj_df['Department'].astype('category')
obj_df['EducationField'] = obj_df['EducationField'].astype('category')
obj_df['Gender'] = obj_df['Gender'].astype('category')
obj_df['JobRole'] = obj_df['JobRole'].astype('category')
obj_df['MaritalStatus'] = obj_df['MaritalStatus'].astype('category')
obj_df['Over18'] = obj_df['Over18'].astype('category')
obj_df['OverTime'] = obj_df['OverTime'].astype('category')
obj_df['Attrition'] = obj_df['Attrition'].astype('category')

# In[None]

data['Department'] = obj_df['Department'].cat.codes
data['EducationField'] = obj_df['EducationField'].cat.codes
data['Gender'] = obj_df['Gender'].cat.codes
data['JobRole'] = obj_df['JobRole'].cat.codes
data['MaritalStatus'] = obj_df['MaritalStatus'].cat.codes
data['Over18'] = obj_df['Over18'].cat.codes
data['OverTime'] = obj_df['OverTime'].cat.codes
data['Attrition'] = obj_df['Attrition'].cat.codes

data.head()

# *# *# *# *# C# o# r# r# e# l# a# t# i# o# n#  # p# l# o# t# *# *# *# *

# In[None]

data_model = data.copy()

# In[None]

data_model.head()

# In[None]

data_model.dtypes

# In[None]

corr = data_model.corr()
f,ax = plt.subplots(figsize=(16,9))
sns.heatmap(corr, vmax = 0.8,square ='TRUE' )

# *# *# *# *# T# a# k# e#  # t# o# p#  # 1# 0#  # c# o# r# r# e# l# a# t# e# d#  # m# e# t# r# i# c# s# *# *# *# *

# In[None]

k=10
cols=corr.nlargest(k,'Attrition')['Attrition'].index
cm= np.corrcoef(data_model[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar = True ,annot = True,fmt ='.2f',annot_kws ={'size':10}, yticklabels=cols.values, xticklabels=cols.values )
#annot_kws -  provides access to how annotations are displayed, rather than what is displayed
plt.show()

# *# *# F# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n# :# *# *#  # *# U# s# i# n# g#  # P# -# v# a# l# u# e# *

# In[None]

import statsmodels.api as sm

# In[None]

x = data_model.drop(['Attrition'],axis=1)
y = data_model['Attrition']

# In[None]

#using backward elimination method 
X_1 = sm.add_constant(x)

# In[None]

#Fitting sm.OLS method 
model = sm.OLS(y,X_1).fit()
model.pvalues

# In[None]

#Backward elimination 
cols = list(x.columns)
pmax = 1
while (len(cols)>0):
    p =[]
    x_1 = x[cols]
    x_1 = sm.add_constant(x_1)
    model = sm.OLS(y,x_1).fit()
    p= pd.Series(model.pvalues.values[:],index = cols)
    pmax = max(p)
    feature_with_p_max = p.idxmax()
    if (pmax>0.05):
        cols.remove(feature_with_p_max)
    else:
        break 
            
        

# In[None]

selected_features_BE = cols
selected_features_BE

# In[None]

data_new = data_model[selected_features_BE]
data_new.head()

# *# *# N# o#  # m# u# l# t# i# c# o# r# r# e# l# a# t# e# d#  # m# e# t# r# i# c# s# -#  # s# o#  # r# e# a# d# y#  # t# o#  # g# o#  # f# o# r#  # m# o# d# e# l# i# n# g#  #  # t# e# c# h# n# i# q# u# e# s# *# *

# In[None]

#Logistic regression
#x = data_model.drop(['Attrition'],axis=1)
#x.head()
X = data_new




# In[None]

X.shape

# In[None]

Y = y
Y.head()

# *# *# S# p# l# i# t# t# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t# *# *

# In[None]


from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/4020038.npy", { "accuracy_score": score })

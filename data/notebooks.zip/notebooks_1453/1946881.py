import pandas as pd
# ##  # *# *#  # I# n# t# r# o# d# u# c# t# i# o# n#  # *# *# 
# 
# ## ## ##  # H# e# l# l# o# ,#  # i# n#  # t# h# i# s#  # n# o# t# e# b# o# o# k#  # I#  # w# i# l# l#  # d# o#  # s# o# m# e#  # e# x# p# e# r# i# m# e# n# t# s#  # t# o#  # f# i# g# u# r# e#  # o# u# t#  # t# h# e#  # b# e# s# t#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m#  # o# n#  # t# h# i# s#  # d# a# t# a#  # a# n# d#  # t# r# y#  # t# o#  # t# u# n# e#  # t# h# e# m#  # t# o#  # g# e# t#  # h# i# g# h# e# s# t#  # s# u# c# c# e# s# s# .#  #  # A# f# t# e# r#  # t# u# n# i# n# g#  # I#  # w# i# l# l#  # c# o# m# p# a# r# e#  # t# h# e# m#  # t# o#  # f# i# n# d#  # b# e# s# t#  # o# n# e#  # o# f#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # 6#  # m# o# d# e# l# s# .# 
# 
# ## ## ##  # <# a#  # h# r# e# f# =# "# ## e# d# a# "# ># E# D# A# <# /# a# ># 
# ## ## ##  # <# a#  # h# r# e# f# =# "# ## v# i# s# u# a# l# "# ># V# i# s# u# a# l#  # E# D# A# <# /# a# ># 
# ## ## ##  # <# a#  # h# r# e# f# =# "# ## p# r# e# p# "# ># D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# <# /# a# ># 
# 
# ## ## ##  # <# a#  # h# r# e# f# =# "# ## m# l# s# "# ># M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # M# o# d# e# l# s# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## l# r# "# >#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## k# n# n# "# >#  # K# N# N# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## s# v# m# "# ># S# V# M# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## r# f# "# ># R# a# n# d# o# m#  # F# o# r# e# s# t# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## d# c# "# ># D# e# c# i# s# i# o# n#  # T# r# e# e# <# /# a# ># 
# *#  #  # <# a#  # h# r# e# f# =# "# ## n# b# "# ># N# a# i# v# e#  # B# a# y# e# s# <# /# a# ># 
# 
# ## ## ##  # <# a#  # h# r# e# f# =# "# ## r# e# s# "# ># R# e# s# u# l# t# s#  # a# n# d#  # C# o# m# p# a# r# i# s# o# n# s# <# /# a# >

# <# a#  # i# d# =# "# e# d# a# "# ># <# /# a# ># 
# ## ##  # *# *#  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s#  # *# *

# In[None]

import numpy as np # linear algebra
import pandas as pd # data processing
import warnings
warnings.filterwarnings("ignore")

# ## ## ##  # L# o# a# d# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t

# In[None]

DataFrame = pd.read_csv("../input/pulsar_stars.csv")  

# ## ## ##  # I# n# v# e# s# t# i# g# a# t# i# n# g#  # t# h# e#  # D# a# t# a# s# e# t

# In[None]

DataFrame.head()    # first 5 rows of whole columns

# ## ## ##  # L# o# o# k# i# n# g#  # t# o#  # D# t# y# p# e# s#  # a# n# d#  # a# m# o# u# n# t# s#  # o# f#  # v# a# l# u# e# s

# In[None]

DataFrame.info()   # information about data types and amount of non-null rows of our Dataset

# (# B# o# n# u# s# )#  # d# a# t# a#  # t# y# p# e# s#  # a# r# e#  # a# l# l#  # n# u# m# e# r# i# c#  # a# n# d#  # n# o# n# -# n# u# l# l# ,#  # I#  # d# o# n# '# t#  # n# e# e# d#  # t# o#  # d# o#  # a# n# y#  # t# r# a# n# s# f# o# r# m# a# t# i# o# n# s#  # o# r#  # c# l# e# a# n# i# n# g# .

# ## ## ##  # S# t# a# t# i# s# t# i# c# a# l#  # I# n# v# e# s# t# i# g# a# t# i# o# n

# In[None]

DataFrame.describe()   # statistical information about our data

# In[None]

DataFrame.corr()    # correlation between fields

# <# a#  # i# d# =# "# v# i# s# u# a# l# "# ># <# /# a# ># 
# ## ##  # *# *#  # V# i# s# u# a# l#  # E# D# A#  # *# *

# In[None]

import matplotlib.pyplot as plt    # basic plotting library
import seaborn as sns              # more advanced visual plotting library

# ## ## ##  # *# *#  # P# a# i# r# P# l# o# t#  # *# *#  #  # (# e# a# c# h#  # c# o# l# u# m# n#  # i# s#  # c# o# m# p# a# r# e# d#  # t# h# e#  # o# t# h# e# r# s#  # a# n# d#  # i# t# s# e# l# f# )

# In[None]

sns.pairplot(data=DataFrame,
             palette="husl",
             hue="target_class",
             vars=[" Mean of the integrated profile",
                   " Excess kurtosis of the integrated profile",
                   " Skewness of the integrated profile",
                   " Mean of the DM-SNR curve",
                   " Excess kurtosis of the DM-SNR curve",
                   " Skewness of the DM-SNR curve"])

plt.suptitle("PairPlot of Data Without Std. Dev. Fields",fontsize=18)

plt.tight_layout()
plt.show()   # pairplot without standard deviaton fields of data

# w# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # o# u# r#  # d# a# t# a#  # i# s#  # q# u# i# t# e#  # s# e# p# a# r# a# b# l# e#  # o# n#  # m# o# s# t#  # o# f#  # t# h# e#  # c# o# l# u# m# n# s

# ## ## ##  # *# *#  # C# o# r# r# e# l# a# t# i# o# n#  # H# e# a# t# M# a# p#  # *# *

# In[None]

plt.figure(figsize=(16,12))
sns.heatmap(data=DataFrame.corr(),annot=True,cmap="bone",linewidths=1,fmt=".2f",linecolor="gray")
plt.title("Correlation Map",fontsize=20)
plt.tight_layout()
plt.show()      # lightest and darkest cells are most correlated ones

# M# o# s# t#  # o# f#  # o# u# r#  # C# o# l# u# m# n# s#  # a# r# e#  # a# l# r# e# a# d# y#  # r# e# l# a# t# e# d#  # o# r#  # d# e# r# i# v# e# d#  # f# r# o# m#  # o# n# e#  # o# r#  # a# n# o# t# h# e# r# .#  # A# n# d#  # w# e#  # c# a# n#  # s# e# e#  # i# t#  # c# l# e# a# r# l# y#  # o# n#  # s# o# m# e#  # C# e# l# l# s#  # a# b# o# v# e

# ## ## ##  # *# *#  # V# i# o# l# i# n# P# l# o# t#  # *# *#  #  # (# a# c# t#  # a# s#  # a#  # b# o# x# p# l# o# t#  # b# u# t#  # w# e#  # c# a# n#  # s# e# e#  # a# m# o# u# n# t# s#  # t# o# o# )

# In[None]

plt.figure(figsize=(16,10))

plt.subplot(2,2,1)
sns.violinplot(data=DataFrame,y=" Mean of the integrated profile",x="target_class")

plt.subplot(2,2,2)
sns.violinplot(data=DataFrame,y=" Mean of the DM-SNR curve",x="target_class")

plt.subplot(2,2,3)
sns.violinplot(data=DataFrame,y=" Standard deviation of the integrated profile",x="target_class")

plt.subplot(2,2,4)
sns.violinplot(data=DataFrame,y=" Standard deviation of the DM-SNR curve",x="target_class")


plt.suptitle("ViolinPlot",fontsize=20)

plt.show()

# W# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # o# u# r#  # d# a# t# a#  # h# a# s#  # d# i# f# f# e# r# e# n# t#  # k# i# n# d#  # o# f#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # w# h# i# c# h#  # i# s#  # h# e# l# p# f# u# l#  # f# o# r#  # t# r# a# i# n# i# n# g#  # o# u# r#  # m# o# d# e# l# s# .

# <# a#  # i# d# =# "# p# r# e# p# "# ># <# /# a# ># 
# ## ##  # *# *#  # D# a# t# a#  # P# r# e# P# r# o# c# e# s# s# i# n# g#  # *# *

# ## ## ##  # S# p# l# i# t# t# i# n# g#  # t# h# e#  # F# e# a# t# u# r# e#  # a# n# d#  # L# a# b# e# l#  # f# i# e# l# d# s

# In[None]

labels = DataFrame.target_class.values

DataFrame.drop(["target_class"],axis=1,inplace=True)

features = DataFrame.values

# ## ## ##  # S# c# a# l# i# n# g#  # t# h# e#  # F# e# a# t# u# r# e# s#  #  

# In[None]

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(0,1))

features_scaled = scaler.fit_transform(features)

# ## ## ##  #  # S# p# l# i# t# t# i# n# g#  # t# h# e#  # T# r# a# i# n#  # a# n# d#  # t# h# e#  # T# e# s# t#  # r# o# w# s

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(features_scaled, labels, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1946881.npy", { "accuracy_score": score })

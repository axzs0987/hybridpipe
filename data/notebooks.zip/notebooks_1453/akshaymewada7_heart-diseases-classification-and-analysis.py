import numpy as np    
import pandas as pd     
import warnings
warnings.filterwarnings('ignore')
heart_df = pd.read_csv("/kaggle/input/heart.csv")
heart_df.head()
import matplotlib.pyplot as plt    
import seaborn as sns    
#sns.set()
sex_dict = { 0: 'Female',1: 'Male' }
chest_pain_dict = { 0:'Typical Angina', 1:'Atypical Angina', 2:'Non-Anginal Pain', 3:'Asymptomatic'}
fbs_dict = { 0: 'No Blood Sugar', 1: 'Blood Sugar'}
restecg_dict = { 0:'Normal restecg', 1:'ST-T wave abnormality restecg', 2:'ventricular hypertrophy restecg'}
exang_dict = { 0:'Exang No', 1:'Exang Yes'}
slope_dict = { 0:'Upsloping', 1:'flat', 2:'Downsloping'}
ca_dict = { 0:'Major vessel 0', 1:'Major vessel 1', 2:'Major vessel 2', 3:'Major vessel 3', 4:'Major vessel 4'}
thal_dict = { 0: 'None', 1: 'Normal', 2:'Fixed Defect',3:'Reversable Defect'}
target_dict = { 0: 'Not Present', 1: 'Present'}
df = heart_df[['age']]
df['Resting Blood Pressure'] = heart_df['trestbps']
df['Serum Cholestoral'] = heart_df['chol']
#df['Max. Heart Rate'] = heart_df['thalach']
df['ST Depression'] = heart_df['oldpeak']
df['Sex'] = heart_df['sex'].apply(lambda x:sex_dict[x])
df['Thalassemia'] = heart_df['thal'].apply(lambda x:thal_dict[x])
df['Fasting Blood Sugar'] = heart_df['fbs'].apply(lambda x:fbs_dict[x])
df['Chest Pain'] = heart_df['cp'].apply(lambda x:chest_pain_dict[x])
df['Heart Disease'] = heart_df['target'].apply(lambda x:target_dict[x])
def custom_count_barplot(df, col, col_val, gp_val, gp_key):
    
    new_df = df[df[col]==col_val].groupby([gp_val,gp_key])[gp_key].count()
    
    
#    ax = new_df.unstack().plot(kind='bar', fontsize=14, figsize=(14,5))
#    ax.set_title('{0} with {1}'.format(col_val,gp_key), fontsize=18)
#    ax.set_xlabel(gp_val,labelpad=10, fontsize=14)
#    ax.set_ylabel('Count',fontsize=14)
#    ax.legend(fontsize=12)
#    ax.tick_params(labelrotation=0)
    
    
#    for patch in ax.patches:
#        left, bottom, width, height = patch.get_bbox().bounds
#        ax.annotate("{0}".format(int(height)), xy=(left+width/2, bottom+height/2), ha='center', va='center')
    
#    plt.show()
#custom_count_barplot(df=df,col='Sex',col_val='Male',gp_val='Heart Disease',gp_key='Chest Pain')
#custom_count_barplot(df=df,col='Sex',col_val='Female',gp_val='Heart Disease',gp_key='Chest Pain')
#custom_count_barplot(df=df,col='Sex',col_val='Male',gp_val='Heart Disease',gp_key='Thalassemia')
#custom_count_barplot(df=df,col='Sex',col_val='Female',gp_val='Heart Disease',gp_key='Thalassemia')
#custom_count_barplot(df=df,col='Sex',col_val='Male',gp_val='Heart Disease',gp_key='Fasting Blood Sugar')
#custom_count_barplot(df=df,col='Sex',col_val='Female',gp_val='Heart Disease',gp_key='Fasting Blood Sugar')
#sns.catplot(x="target", y="age", hue="sex", kind="violin", split=True, data=heart_df);
#plt.show()
feature = heart_df.drop(['target','age','trestbps','chol','thalach','oldpeak'], axis=1)
label = heart_df[['target']]
def get_dummies_concated(df,key,column_dict):
    tmp = pd.get_dummies(df[key])
    tmp.columns = column_dict.values()
    return pd.concat([df.drop(key, axis=1), tmp], axis=1)
col_resp_dict = {
    'sex':sex_dict,    'cp':chest_pain_dict,    'fbs':fbs_dict,    'restecg':restecg_dict,    'exang':exang_dict,    'slope':slope_dict,    'ca':ca_dict,    'thal':thal_dict
}
for key,value in col_resp_dict.items():
    new_featue = get_dummies_concated(feature,key,value)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler().fit(new_featue)
feature_scale = sc.transform(new_featue)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(new_featue, label, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
models = []
models.append(('LGR',LogisticRegression()))
models.append(('KNN',KNeighborsClassifier()))
models.append(('GNB',GaussianNB()))
models.append(('DT',DecisionTreeClassifier()))
models.append(('SVC',SVC()))
from sklearn.model_selection import cross_val_score
accuray_list = []
name_list = []
for name, model in models:
    
    accuray = cross_val_score(model, X_train, Y_train, scoring='accuracy' )
    name_list.append(name)
    accuray_list.append(accuray)
    
    print("Model: '{0}' | Accurcy: {1:.2f}%".format(name, accuray.mean()*100))
svc_param = {
    "C":[0.1,1,10,100,200],    "gamma":[0.01,0.1,1,10,100]
}
from sklearn.model_selection import GridSearchCV
#clf = GridSearchCV(SVC(),param_grid=svc_param).fit(X_train,Y_train)
#clf.best_params_ 
#cv = SVC(C=1,gamma=0.1).fit(X_train,Y_train)
#print(cv.score(X_train,Y_train))
#print(cv.score(X_test,Y_test))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
print("start running model training........")
model = SVC(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/akshaymewada7_heart-diseases-classification-and-analysis.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testX.csv",encoding="gbk")

if type(Y_train).__name__ == "ndarray":
    np.save("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainY.npy", Y_train)
if type(Y_train).__name__ == "Series":
    Y_train.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainY.csv",encoding="gbk")
if type(Y_train).__name__ == "DataFrame":
    Y_train.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/trainY.csv",encoding="gbk")

if type(Y_test).__name__ == "ndarray":
    np.save("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testY.npy", Y_test)
if type(Y_test).__name__ == "Series":
    Y_test.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testY.csv",encoding="gbk")
if type(Y_test).__name__ == "DataFrame":
    Y_test.to_csv("hi_res_data/akshaymewada7_heart-diseases-classification-and-analysis/testY.csv",encoding="gbk")


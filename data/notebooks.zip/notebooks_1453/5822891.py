import pandas as pd
# In[None]

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.metrics import accuracy_score,f1_score,recall_score,precision_score, confusion_matrix,classification_report

# In[None]

data=pd.read_csv('../input/indian-liver-patient-records/indian_liver_patient.csv')

# In[None]

data.head()

# In[None]

data.rename({'Dataset':'Liver_disorder'},axis=1,inplace=True)

# ## ## ##  # E# D# A

# In[None]

data.isnull().sum()

# In[None]

data.shape

# In[None]

data.dropna().shape

# In[None]

data['Albumin_and_Globulin_Ratio'].unique()

# In[None]

data[data['Albumin_and_Globulin_Ratio'].isnull()]

# ## ## ##  # D# r# o# p# p# i# n# g#  # 4#  # r# o# w# s

# In[None]

data.dropna(inplace=True)

# In[None]

data['Liver_disorder'].value_counts()

# In[None]

data.shape

# In[None]

data.head()

# In[None]

sns.pairplot(data)

# In[None]

data.corr()

# In[None]

data['Gender']=data['Gender'].replace({'Male':0,'Female':1})

# In[None]

data['Gender'].value_counts()

# In[None]

data.info()

# In[None]

data['Gender']=data['Gender'].astype('category')

# ## ## ## ## ##  # l# e# t# s#  # p# e# r# f# o# r# m#  # s# t# a# t# i# s# t# i# c# a# l#  # t# e# s# t#  # o# n#  # G# e# n# d# e# r#  # t# o#  # s# e# e#  # i# f#  # b# o# t# h#  # t# h# e#  # m# e# a# n# s#  # a# r# e#  # s# a# m# e#  # o# r#  # i# t#  # i# s#  # s# i# g# n# i# f# i# c# a# n# t# l# y#  # d# i# f# f# e# r# e# n# t#  # t# o#  # p# r# e# d# i# c# t#  # (# g# o# o# d#  # p# r# e# d# i# c# t# o# r# )# :# A# s#  # g# e# n# d# e# r#  #  # a# n# d#  # L# i# v# e# r# _# d# i# s# o# r# d# e# r#  # b# o# t# h#  # a# r# e#  # c# a# t# e# g# o# r# i# c# a# l#  # w# e#  # w# i# l# l#  # b# e#  # d# o# i# n# g#  # 2#  # s# a# m# p# l# e#  # p# r# o# p# o# r# t# i# o# n#  # t# e# s# t# (# p# o# p# u# l# a# r# l# y#  # c# a# l# l# e# d#  # a# s#  # Z# -# t# e# s# t# )# .

# In[None]

#no_of_MF_with_disorder=data[data['Liver_disorder']==1].groupby('Gender')[['Gender']].count()

# In[None]

#no_of_MF_with_disorder

# ## 3# 2# 3#  # f# e# m# a# l# e#  # h# a# v# e#  # l# i# v# e# r# _# d# i# s# o# r# d# e# r# 
# 
# ## 9# 1#  # M# a# l# e#  # h# a# v# e#  # l# i# v# e# r# _# d# i# s# o# r# d# e# r# 
# 


# In[None]

tab=pd.crosstab(data.Gender,data.Liver_disorder)
print(tab)

# In[None]

#tot=data.groupby('Gender')[['Gender']].count()

# In[None]

#tot

# ## ## ## ##  # H# N# U# L# L# =#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# i# v# e# r#  # d# i# s# o# r# d# e# r#  # i# n#  # m# a# l# e#  # =#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # l# i# v# e# r#  # d# i# s# o# r# d# e# r#  # i# n#  # f# e# m# a# l# e# 
# ## ## ## ##  # H# a# l# t# e# r# n# a# t# i# v# e# =#  # p# r# o# p# o# r# t# i# o# n# s#  # a# r# e#  # n# o# t#  # e# q# u# a# l

# In[None]

tot_male=tab.iloc[1].sum()

# In[None]

male_with_disorder=tab.iloc[1,0]

# In[None]

tot_female=tab.iloc[0].sum()

# In[None]

female_with_disorder=tab.iloc[0,0]

# In[None]

p1=male_with_disorder/tot_male

# In[None]

p2=female_with_disorder/tot_female

# In[None]

p=(male_with_disorder+female_with_disorder)/data.shape[0]

# In[None]

Zstats=(p1-p2)/(np.sqrt(p*(1-p)*((1/tot_male)+(1/tot_female))))

# In[None]

Zstats

# In[None]

import scipy.stats as stats
stats.norm.cdf(Zstats)

# ## ## ##  # p# v# a# l# <# <# 0# .# 0# 5#  # w# e#  # c# a# n#  # r# e# j# e# c# t#  # t# h# e#  # H# _# n# u# l# l#  # i# .# e#  # t# h# e#  # p# r# o# p# o# r# t# i# o# n#  # i# s#  # n# o# t#  # t# h# e#  # s# a# m# e#  # b# e# t# w# e# e# n#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e#  # s# o#  # i# t#  # c# a# n#  # b# e#  # a#  # o# n# e#  # o# f#  # t# h# e#  # g# o# o# d#  # p# r# e# d# i# c# t# o# r#  # o# f#  # Y

# In[None]

cor=data.corr()

# In[None]

cor_target=abs(cor['Liver_disorder'])

# In[None]

Pearson_Coeff=pd.DataFrame(cor_target)
print(Pearson_Coeff)

# ## ## ##  # T# h# i# s#  # i# s#  # t# h# e#  # c# o# -# r# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # X# '# s#  # a# n# d#  # Y

# ## ## ## ## ##  # L# e# t# s#  # d# r# o# p#  # p# r# o# t# e# i# n#  # b# e# a# c# u# s# e#  # i# t# '# s#  # n# o# t#  # s# i# g# n# i# f# i# c# a# n# t#  # p# r# e# d# i# c# t# o# r#  # o# f#  # Y#  # t# h# e#  # c# o# -# r# e# l# a# t# i# o# n#  # c# o# -# e# f# f#  # i# s#  # j# u# s# t#  # 3# %

# In[None]

data.info()

# In[None]

data.drop('Total_Protiens',axis=1,inplace=True)

# ## ## ## ##  # N# o# w#  # l# e# t# s#  # c# h# e# c# k#  # i# f#  # m# u# l# t# i# -# c# o# l# i# n# e# a# r# i# t# y#  # e# x# i# s# t#  # b# e# t# w# e# e# n#  # i# n# d# e# p# e# n# d# e# n# t#  # X# '# s# :# U# s# i# n# g#  # V# I# F

# In[None]

d=data.drop('Liver_disorder',axis=1)

# In[None]

features = "+" .join(d)
#y, X = dmatrices('annual_inc ~' + features, df, return_type='dataframe')

# In[None]

features

# In[None]

from   patsy                                import dmatrices
from   statsmodels.stats.outliers_influence import variance_inflation_factor
y,X=dmatrices('Liver_disorder~'+features,data,return_type='dataframe')

# In[None]

Vif=pd.DataFrame()

# In[None]

Vif['features']=X.columns
Vif['VIF factor']=[variance_inflation_factor(X.values,i) for i in range(X.shape[1])]

print(Vif)

# ## ## ## ##  #  # M# u# l# t# i# -# c# o# -# l# i# n# e# a# r# i# t# y# :#  # T# o# t# a# l# _# B# i# l# i# r# u# b# i# n#  # a# n# d#  # D# i# r# e# c# t#  # B# i# l# i# r# u# b# i# n#  # h# a# v# e#  # H# i# g# h#  # V# I# F#  # s# o#  # l# e# t# s#  # D# r# o# p#  # o# n# e#  # o# f#  # t# h# e#  # C# o# l# u# m# n# .

# In[None]

LData=data.drop('Direct_Bilirubin',axis=1)

# In[None]

LData.head()

# ## ## ##  # T# i# m# e#  # t# o#  # a# p# p# l# y#  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n# :

# L# e# t# s#  # d# o#  # G# r# i# d#  # S# e# a# r# c# h# :#  # T# o#  # f# i# n# d#  # b# e# s# t#  # P# a# r# a# m# e# t# e# r# s# :# U# s# i# n# g#  # k# -# f# o# l# d#  # c# r# o# s# s#  # v# a# l# i# d# a# t# i# o# n

# In[None]

from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
penalty=['l2','l1']
multi_class=['ovr', 'auto']
X=LData.drop('Liver_disorder',axis=1)
y=LData[['Liver_disorder']]
model=LogisticRegression()
grid=GridSearchCV(estimator=model,cv=3,param_grid=dict(penalty=penalty,multi_class=multi_class))
grid.fit(X,y)

# In[None]

print(grid.best_params_)

# In[None]

print('Recall:',grid.best_score_)
print('Accuracy:',grid.best_score_)

# ## ## ## ##  # L# e# t# '# s#  # u# s# e#  # t# r# a# i# n#  # l# e# t# s#  # s# p# l# i# t

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5822891.npy", { "accuracy_score": score })

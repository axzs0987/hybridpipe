import numpy as np 
import pandas as pd 
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_validate
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from matplotlib.colors import ListedColormap
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from xgboost import XGBClassifier
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data = pd.read_csv('/kaggle/input/heart-disease-uci/heart.csv')
target = data.target
data = data.drop(['target'], axis = 'columns')
data.head(10)
scaler = StandardScaler()
data = scaler.fit_transform(data)
def pca_analysis(ncomps, data = data, target = target, plot = False):
    
    pca = PCA(n_components = ncomps)
    principal_comps = pca.fit_transform(data)
    principal_comps_df = pd.concat([pd.DataFrame(data = principal_comps, columns = ['pc' + str(i) for i in range(1, ncomps + 1)]), target],                                    axis = 'columns')
    
#    if plot:
#        if ncomps == 2:
#            plt.figure(figsize = (8, 8))
#            fig = sns.scatterplot(data = principal_comps_df,                                   x = 'pc1',                                   y = 'pc2',                                   hue = 'target')
#            fig.set_title('2 Component PCA')
    return principal_comps_df
principal_comps_2d = pca_analysis(2, plot = False)
h = .02  
names = ["Nearest Neighbors", "Linear SVM", "RBF SVM", "Gaussian Process",         "Decision Tree", "Random Forest", "Neural Net", "AdaBoost",         "Naive Bayes", "QDA", "XGBoost"]
classifiers = [    KNeighborsClassifier(3),    SVC(kernel="linear", C=0.025),    SVC(gamma=2, C=1),    GaussianProcessClassifier(1.0 * RBF(1.0)),    DecisionTreeClassifier(),    RandomForestClassifier(),    MLPClassifier(alpha=1, max_iter=1000),    AdaBoostClassifier(),    GaussianNB(),    QuadraticDiscriminantAnalysis(),     XGBClassifier()]
datasets = [(np.array(principal_comps_2d[['pc1', 'pc2']]), np.array(target))]
#figure = plt.figure(figsize = (15, 15))
i = 1
for ds_cnt, ds in enumerate(datasets):
    
    X, y = ds
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
    x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
    y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),                         np.arange(y_min, y_max, h))
    
#    cm = plt.cm.RdBu
    cm_bright = ListedColormap(['#FF0000', '#0000FF'])
#    ax = plt.subplot(4, 4, i)
#    if ds_cnt == 0:
#        ax.set_title("Input data")
    
#    ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap=cm_bright,               edgecolors='k')
    
#    ax.scatter(X_test[:, 0], X_test[:, 1], c=y_test, cmap=cm_bright, alpha=0.6,               edgecolors='k')
#    ax.set_xlim(xx.min(), xx.max())
#    ax.set_ylim(yy.min(), yy.max())
#    ax.set_xticks(())
#    ax.set_yticks(())
    i += 1
    
#    for name, clf in zip(names, classifiers):
#        ax = plt.subplot(4, 4, i)
#        clf.fit(X_train, y_train)
#        score = clf.score(X_test, y_test)
        
        
#        if hasattr(clf, "decision_function"):
#            Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
#        else:
#            Z = clf.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
        
#        Z = Z.reshape(xx.shape)
#        ax.contourf(xx, yy, Z, cmap=cm, alpha=.8)
        
#        ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap=cm_bright,                   edgecolors='k')
        
#        ax.scatter(X_test[:, 0], X_test[:, 1], c=y_test, cmap=cm_bright,                   edgecolors='k', alpha=0.6)
#        ax.set_xlim(xx.min(), xx.max())
#        ax.set_ylim(yy.min(), yy.max())
#        ax.set_xticks(())
#        ax.set_yticks(())
#        if ds_cnt == 0:
#            ax.set_title(name)
#        ax.text(xx.max() - .3, yy.min() + .3, ('%.2f' % score).lstrip('0'),                size=15, horizontalalignment='right')
#        i += 1
#plt.tight_layout()
#plt.show()



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/acelaya0_heart-disease-uci-pca-with-classifier-comparison.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/acelaya0_heart-disease-uci-pca-with-classifier-comparison/testY.csv",encoding="gbk")


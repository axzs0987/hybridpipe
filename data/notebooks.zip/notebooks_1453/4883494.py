import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

liver_df = pd.read_csv("../input/indian_liver_patient.csv")

# In[None]

liver_df.head()

# In[None]

liver_df.describe()

# In[None]

liver_df.info()

# In[None]

liver_df.isnull().sum()

# In[None]

liver_df[liver_df['Albumin_and_Globulin_Ratio'].isnull()]

# In[None]

import seaborn as sns
sns.countplot(data = liver_df, x = 'Dataset')
Diagnosed, Not_Diagnosed = liver_df['Dataset'].value_counts()
print('No. of patients diagnosed with liver cancer', Diagnosed)
print('No. of patients not diagnosed with liver cancer', Not_Diagnosed)

# In[None]

sns.countplot(data = liver_df, x = 'Gender')
M, F = liver_df['Gender'].value_counts()
print('No. of patients that are Male:', M)
print('No. of patients that are Female:', F)

# In[None]

import matplotlib.pyplot as plt
plt.figure(figsize=(12,6))
sns.heatmap(data = liver_df.corr(), annot = True)

# In[None]

#liver_df['Albumin_and_Globulin_Ratio'].mean()

# In[None]

#liver_df['Albumin_and_Globulin_Ratio'].fillna(0.947063,inplace=True)

# In[None]

liver_df.dropna(axis=0,inplace=True)

# In[None]

liver_df.info()

# In[None]

liver_df.isnull().sum()

# In[None]

liver_df['Dataset'].value_counts()

# In[None]

sex = ['Gender']
final_df = pd.get_dummies(liver_df,columns = sex,drop_first=True)

# In[None]

final_df.head()

# In[None]

from sklearn.model_selection import train_test_split


# In[None]

X = final_df.drop('Dataset',axis=1)
y = final_df['Dataset']

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4883494.npy", { "accuracy_score": score })

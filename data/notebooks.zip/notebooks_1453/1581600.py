import pandas as pd
# *# *# L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  # H# o# m# e# w# o# r# k#  # ## 1# *# *# 
# 
# *# D# a# t# a# s# e# t# :#  # R# e# d#  # W# i# n# e#  # Q# u# a# l# i# t# y# *# 
# 
# *# F# e# a# t# u# r# e# s#  # t# h# a# t#  # a# f# f# e# c# t#  # w# i# n# e#  # q# u# a# l# i# t# y#  # :#  # '# f# i# x# e# d#  # a# c# i# d# i# t# y# '# ,#  #  # '# v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y# '# ,#  # '# c# i# t# r# i# c#  # a# c# i# d# '# ,#  # '# r# e# s# i# d# u# a# l#  # s# u# g# a# r# '# ,#  # '# c# h# l# o# r# i# d# e# s# '# ,#  # '# f# r# e# e#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e# '# ,#  # '# t# o# t# a# l#  # s# u# l# f# u# r#  # d# i# o# x# i# d# e# '# ,#  # '# d# e# n# s# i# t# y# '# ,#  # '# p# H# '# ,#  # '# s# u# l# p# h# a# t# e# s# '# ,#  # '# a# l# c# o# h# o# l# '#  # .# *# 
# 
# *# G# o# a# l# :#  # C# r# e# a# t# i# n# g#  # a#  # m# o# d# e# l#  # t# o#  # p# r# e# d# i# c# t#  # q# u# a# l# i# t# y#  # o# f#  # r# e# d#  # w# i# n# e# s#  # a# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e#  # s# e# v# e# r# a# l#  # f# e# a# t# u# r# e# s#  # a# n# d#  # c# a# l# c# u# l# a# t# i# n# g#  # t# e# s# t#  # s# c# o# r# e# s# .# 
# *# 


# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

# Reading CSV Data
data=pd.read_csv("../input/winequality-red.csv")

#Get info about data
data.info()

# In[None]

# Get top 10 records of data
data.head(10)

# In[None]

# Correlations between features
# Plot Seaborn Heatmap
plt.figure(figsize=(12,12))
sns.heatmap(data.corr(),cmap="BuPu", annot=True, linewidths=0.5)

# A# c# c# o# r# d# i# n# g#  # t# o#  # t# h# e#  # h# e# a# t# m# a# p#  # a# b# o# v# e# ,#  # w# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # t# h# e# r# e#  #  # i# s#  # a#  # p# o# s# i# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # a# l# c# o# h# o# l#  # a# n# d#  # t# h# e#  # q# u# a# l# i# t# y# .#  # A# l# s# o#  # i# t#  # s# e# e# m# s#  # t# h# a# t#  # t# h# e# r# e#  # i# s#  # a#  # n# e# g# a# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # v# o# l# a# t# i# l# e#  # a# c# i# d# i# t# y#  # a# n# d#  # q# u# a# l# i# t# y# .# 
# 
# W# e#  # c# a# n#  # s# e# e#  # t# h# e#  # s# a# m# e#  # r# e# s# u# l# t# s#  # b# y#  # d# r# a# w# i# n# g#  # b# o# x# p# l# o# t# s#  # f# o# r#  # e# a# c# h#  # f# e# a# t# u# r# e# .

# In[None]

# Boxplots of features
fig, axs = plt.subplots(2, 4, figsize = (20,10)) 
ax1 = plt.subplot2grid((5,15), (0,0), rowspan=2, colspan=3) 
ax2 = plt.subplot2grid((5,15), (0,4), rowspan=2, colspan=3)
ax3 = plt.subplot2grid((5,15), (0,8), rowspan=2, colspan=3)
ax4 = plt.subplot2grid((5,15), (0,12), rowspan=2, colspan=3)

ax5 = plt.subplot2grid((5,15), (3,0), rowspan=2, colspan=3) 
ax6 = plt.subplot2grid((5,15), (3,4), rowspan=2, colspan=3)
ax7 = plt.subplot2grid((5,15), (3,8), rowspan=2, colspan=3)
ax8 = plt.subplot2grid((5,15), (3,12), rowspan=3, colspan=3)

sns.boxplot(x='quality',y='volatile acidity', data = data, ax=ax1)
sns.boxplot(x='quality',y='citric acid', data = data, ax=ax2)
sns.boxplot(x='quality',y='sulphates', data = data, ax=ax3)
sns.boxplot(x='quality',y='alcohol', data = data, ax=ax4)

sns.boxplot(x='quality',y='fixed acidity', data = data, ax=ax5)
sns.boxplot(x='quality',y='chlorides', data = data, ax=ax6)
sns.boxplot(x='quality',y='total sulfur dioxide', data = data, ax=ax7)
sns.boxplot(x='quality',y='density', data = data, ax=ax8)

# In[None]

# If we analyse the data quality values range from  3 to 8 . 
sns.countplot(x='quality', data=data)

# In[None]

# But i need a binary result like 0:low/normal quality 1:high quality
# Most of the quality values are 5 and 6 . 
# So let's say values higher than 6 is high quality.
data['quality'] = pd.cut(data['quality'], bins = [1,6,10], labels = [0,1]).astype(int)
data.head(10)

# In[None]

# Let's see how many wines are high quality
sns.countplot(x='quality', data=data)
plt.show()

# In[None]

# Setting x and y before training data
# y=quality values [0 0 1 ... 0]
# x=values of the features, so we need to drop quality column
y=data.quality.values
x=data.drop(["quality"],axis=1)


# In[None]

# Normalisation
# All the values of the features will be in range 0-1
x=((x-np.min(x)) / (np.max(x)-np.min(x)))
print(x)

# In[None]

# train - test split data
# split data , 80% of data to train and create model
# 20% data to test model
# Use sklearn library to prepare train and test data
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1581600.npy", { "accuracy_score": score })

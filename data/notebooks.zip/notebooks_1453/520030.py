import pandas as pd
# In[None]

import numpy as np # 数组常用库
import pandas as pd # 读入csv常用库
from patsy import dmatrices # 可根据离散变量自动生成哑变量
from sklearn.linear_model import LogisticRegression # sk-learn库Logistic Regression模型
from sklearn.model_selection import train_test_split, cross_val_score # sk-learn库训练与测试
from sklearn import metrics # 生成各项测试指标库
import matplotlib.pyplot as plt # 画图常用库

# 从# .# .# /# i# n# p# u# t# /# H# R# _# c# o# m# m# a# _# s# e# p# .# c# s# v# 文# 件# 中# 读# 入# 数# 据

# In[None]

data = pd.read_csv("../input/HR_comma_sep.csv")
data

# In[None]

data.dtypes

# 观# 察# 离# 职# 人# 数# 与# 工# 资# 分# 布# 的# 关# 系

# In[None]

pd.crosstab(data.salary, data.left).plot(kind='bar')
plt.show()

# 观# 察# 离# 职# 比# 例# 与# 工# 资# 分# 布# 的# 关# 系

# In[None]

q = pd.crosstab(data.salary, data.left)
print(q)
print(q.sum(1))
q.div(q.sum(1), axis = 0).plot(kind='bar', stacked = True)
plt.show()

# 观# 察# 员# 工# 满# 意# 度# 的# 分# 布# 图# (# h# i# s# t# o# g# r# a# m# )

# In[None]

data[data.left==0].satisfaction_level.hist()
plt.show()

# In[None]

data[data.left==1].satisfaction_level.hist()
plt.show()

# d# m# a# t# r# i# c# e# s# 将# 数# 据# 中# 的# 离# 散# 变# 量# 变# 成# 哑# 变# 量# ，# 并# 指# 明# 用# s# a# t# i# s# f# a# c# t# i# o# n# _# l# e# v# e# l# ,#  # l# a# s# t# _# e# v# a# l# u# a# t# i# o# n# ,#  # .# .# .#  # 来# 预# 测# l# e# f# t# 
# 然# 后# 重# 命# 名# 列# 的# 名# 字

# In[None]

model = LogisticRegression()
y, X = dmatrices('left~satisfaction_level+last_evaluation+number_project+average_montly_hours+time_spend_company+Work_accident+promotion_last_5years+C(sales)+C(salary)', data, return_type='dataframe')
X = X.rename(columns = {
    'C(sales)[T.RandD]': 'Department: Random',
    'C(sales)[T.accounting]': 'Department: Accounting',
    'C(sales)[T.hr]': 'Department: HR',
    'C(sales)[T.management]': 'Department: Management',
    'C(sales)[T.marketing]': 'Department: Marketing',
    'C(sales)[T.product_mng]': 'Department: Product_Management',
    'C(sales)[T.sales]': 'Department: Sales',
    'C(sales)[T.support]': 'Department: Support',
    'C(sales)[T.technical]': 'Department: Technical',
    'C(salary)[T.low]': 'Salary: Low',
    'C(salary)[T.medium]': 'Salary: Medium'}) 
y = np.ravel(y) # 将y变成np的一维数组

# 用# X# 和# y# 训# 练# 模# 型# ，# 然# 后# 输# 出# X# 中# 每# 一# 项# 自# 变# 量# 对# 于# y# 的# 影# 响# 
# z# i# p# (# a# ,# b# )# 可# 将# a# 的# 每# 一# 个# 元# 素# 和# b# 里# 对# 应# 位# 置# 的# 元# 素# 组# 成# 一# 对

# In[None]

model.fit(X, y)
pd.DataFrame(list(zip(X.columns, np.transpose(model.coef_))))


# m# o# d# e# l# .# s# c# o# r# e# 为# 准# 确# 率# (# 0# 到# 1# 之# 间# )

# In[None]

print(model.score(X,y))

# In[None]

#一个高工资HR，对公司满意度0.5, 上次评审0.7分，做过4个项目，每月平均工作160小时，在公司呆了3年，过去5年没有被晋升，没有工伤
model.predict_proba([[1,0,0,1,0,0,0,0,0,0,0,0, 0.5, 0.7, 4.0, 160, 3.0, 0, 0]])

# In[None]

pred = model.predict(X)
(abs(pred-y)).sum() / len(y)

# 生# 成# 7# :# 3# 的# 训# 练# 测# 试# 集

# In[None]

from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(Xtrain, ytrain)
y_pred = model.predict(Xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/520030.npy", { "accuracy_score": score })

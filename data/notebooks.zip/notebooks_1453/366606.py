import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import tensorflow as tf
import statsmodels.api as sm
import pylab as pl
import matplotlib.pyplot as plt
from patsy import dmatrices
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import train_test_split
from sklearn import metrics
from sklearn.cross_validation import cross_val_score
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[None]

dataframe=pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# In[None]

dataframe.head()

# In[None]

names = dataframe.columns.values 
print(names)

# In[None]

dataframe.describe()

# In[None]

dataframe.info()

# In[None]

dataframe.columns

# In[None]

dataframe.std()

# In[None]

dataframe['Attrition'].value_counts()

# In[None]

dataframe['Attrition'].dtypes

# In[None]

dataframe['Attrition'].replace('Yes',1, inplace=True)
dataframe['Attrition'].replace('No',0, inplace=True)

# In[None]

dataframe.head(10)

# In[None]

dataframe['EducationField'].replace('Life Sciences',1, inplace=True)
dataframe['EducationField'].replace('Medical',2, inplace=True)
dataframe['EducationField'].replace('Marketing', 3, inplace=True)
dataframe['EducationField'].replace('Other',4, inplace=True)
dataframe['EducationField'].replace('Technical Degree',5, inplace=True)
dataframe['EducationField'].replace('Human Resources', 6, inplace=True)


# In[None]

dataframe['EducationField'].value_counts()

# In[None]

dataframe['Department'].value_counts()

# In[None]

dataframe['Department'].replace('Research & Development',1, inplace=True)
dataframe['Department'].replace('Sales',2, inplace=True)
dataframe['Department'].replace('Human Resources', 3, inplace=True)

# In[None]

dataframe['Department'].value_counts()

# In[None]

dataframe.head(10)

# In[None]

dataframe['BusinessTravel'].value_counts()

# In[None]

dataframe['BusinessTravel'].replace('Travel_Rarely',1, inplace=True)
dataframe['BusinessTravel'].replace('Travel_Frequently',2, inplace=True)
dataframe['BusinessTravel'].replace('Non-Travel',3, inplace=True)

# In[None]

dataframe['BusinessTravel'].value_counts()

# In[None]

dataframe['Gender']

# In[None]

dataframe['Gender'].replace('Male',1, inplace=True)
dataframe['Gender'].replace('Female',0, inplace=True)
dataframe['Gender']

# In[None]

dataframe.dtypes

# In[None]

x=dataframe.select_dtypes(include=['int64'])
x.dtypes
x.columns

# In[None]

L = dataframe.columns[1:]
y=dataframe['Attrition']



# In[None]

y, x = dmatrices('Attrition ~ Age + BusinessTravel + DailyRate + Department + \
                  DistanceFromHome + Education + EducationField + YearsAtCompany',
                  dataframe, return_type="dataframe")
print (x.columns)

# In[None]

y = np.ravel(y)

# In[None]

model = LogisticRegression()
model = model.fit(x, y)

# check the accuracy on the training set
model.score(x, y)

# In[None]

y.mean()

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/366606.npy", { "accuracy_score": score })

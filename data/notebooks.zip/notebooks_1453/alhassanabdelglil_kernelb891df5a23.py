import numpy as np
import pandas as pd
dataset = pd.read_csv('../input/Dataset_for_Classification.csv')
dataset.head()
dataset.describe()
dataset.isnull().sum()
y = dataset.loc[:,['Attrition']]
y.describe()
dataset.drop(['Attrition'],inplace=True,axis = 1)
X = dataset.iloc[:,:]
X.head()
X = pd.get_dummies(X,drop_first=True)
X.head()
y = pd.get_dummies(y,drop_first=True)
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X = sc_X.fit_transform(X)
print(pd.DataFrame(y))
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.ensemble import RandomForestClassifier
regressor = RandomForestClassifier(n_estimators = 3, random_state = 0)
#regressor.fit(X_train, y_train)
#y_pred = regressor.predict(X_test)
from sklearn.metrics import confusion_matrix
#cm = confusion_matrix(y_test, y_pred)
#cm
#y=pd.DataFrame(y_pred)
#y.to_csv('out.csv',index=False,header=False)
print('done')



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/alhassanabdelglil_kernelb891df5a23.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/alhassanabdelglil_kernelb891df5a23/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/alhassanabdelglil_kernelb891df5a23/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/alhassanabdelglil_kernelb891df5a23/testY.csv",encoding="gbk")


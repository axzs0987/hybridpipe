import pandas as pd
# ## I# n# t# r# o# d# u# c# t# i# o# n# 
# 
# T# h# i# s#  # n# o# t# e# b# o# o# k#  # w# i# l# l#  # g# o#  # t# h# r# o# u# g# h#  # m# a# k# i# n# g#  # 3#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l# s#  # t# o#  # p# r# e# d# i# c# t#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n#  # b# a# s# e# d#  # o# n#  # k# n# o# w# l# e# d# g# e#  # o# f#  # a# n#  # e# m# p# l# o# y# e# e# s#  # w# o# r# k#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# .

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from collections import Counter

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# In[None]

# Import data

df = pd.read_csv('../input/MFG10YearTerminationData.csv')

# In[None]

# look at the data

# Check size of the dataset
df.shape

# In[None]

# Data types
df.dtypes

# In[None]

# A prelimiary look at the individual columns in the training set
df.head()

# In[None]

df.tail()

# ## ## O# b# s# e# r# v# a# t# i# o# n# s#  # s# o#  # f# a# r# 
# 
# 1# .#  # D# a# t# a#  # i# s#  # a#  # m# i# x#  # o# f#  # s# t# r# i# n# g#  # a# n# d#  # i# n# t# e# g# e# r#  # v# a# l# u# e# s# .#  # 
# 2# .#  # S# o# m# e#  # f# e# a# t# u# r# e# s#  # w# i# t# h#  # s# t# r# i# n# g# s#  # s# h# o# u# l# d#  # b# e#  # d# a# t# e# s# .#  # T# h# e# s# e#  # s# h# o# u# l# d#  # b# e#  # c# o# n# v# e# r# t# e# d#  # t# o#  # d# a# t# e#  # a# n# d#  # t# i# m# e#  # i# f#  # u# s# e# d# .#  #  # T# h# e#  # f# e# a# t# u# r# e# s#  # a# r# e#  # r# e# c# o# r# d# d# a# t# e# _# k# e# y# ,#  # b# i# r# t# h# d# a# t# e# _# k# e# y# ,#  # o# r# i# g# h# i# r# e# d# a# t# e# _# k# e# y# ,#  # a# n# d#  # t# e# r# m# i# n# a# t# i# o# n# d# a# t# e# _# k# e# y# .# 
# 3# .#  # E# m# p# l# o# y# e# e# I# D#  # i# s#  # f# o# r#  # i# d# e# n# t# i# f# i# c# a# t# i# o# n# .#  # I# t#  # s# h# o# u# l# d# n# '# t#  # b# e#  # u# s# e# d#  # f# o# r#  # t# r# a# i# n# i# n# g#  # t# h# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l# ,#  # b# u# t#  # c# a# n#  # b# e#  # u# s# e# f# u# l#  # f# o# r#  # f# i# l# t# e# r# i# n# g#  # r# o# w# s# .# 
# 4# .#  # T# h# e#  # a# g# e#  # c# a# n#  # b# e#  # f# o# u# n# d#  # b# y#  # u# s# n# g#  # t# h# e#  # r# e# c# o# r# d#  # d# a# t# e#  # a# n# d#  # t# h# e#  # b# i# r# t# h#  # d# a# t# e# .#  # S# o#  # o# n# e#  # s# e# t#  # m# a# y#  # b# e#  # d# r# o# p# p# e# d# .# 
# 5# .#  # T# h# e#  # l# e# n# g# t# h#  # o# f#  # s# e# r# v# i# c# e#  # c# a# n#  # b# e#  # f# o# u# n# d#  # u# s# i# n# g#  # t# h# e#  # r# e# c# o# r# d#  # d# a# t# e#  # a# n# d#  # t# h# e#  # o# r# i# g# i# n# a# l#  # h# i# r# e#  # d# a# t# e# .#  # S# o#  # o# n# e#  # s# e# t#  # m# a# y#  # b# e#  # d# r# o# p# p# e# d# .# 
# 6# .#  # T# h# e#  # t# e# r# m# i# n# a# t# i# o# n#  # d# a# t# e#  # u# s# e# s#  # 1# /# 1# /# 1# 9# 0# 0#  # i# f#  # t# h# e#  # e# m# p# l# o# y# e# e#  # i# s#  # s# t# i# l# l#  # a# c# t# i# v# e# .#  # 
# 7# .#  # T# h# e#  # s# t# o# r# e# _# n# a# m# e#  # i# s#  # g# i# v# e# n#  # a# s#  # a#  # n# u# m# b# e# r# ,#  # e# v# e# n#  # t# h# o# u# g# h#  # i# t#  # i# s#  # a#  # n# o# m# i# n# a# l#  # c# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e# .#  # T# h# e#  # s# t# o# r# e#  # n# a# m# e#  # i# t# s# e# l# f#  # i# s#  # u# n# l# i# k# e# l# y#  # t# o#  # b# e#  # c# a# u# s# e#  # o# f#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n# ,#  # b# u# t#  # p# a# r# t# i# c# u# l# a# r#  # f# e# a# t# u# r# e#  # v# a# l# u# e# s#  # m# a# y#  # b# e#  # a# s# s# o# c# i# a# t# e# d#  # w# i# t# h#  # p# a# r# t# i# c# u# l# a# r#  # s# t# o# r# e# s# .#  # I# t#  # c# o# u# l# d#  # b# e#  # a# n#  # i# n# t# e# r# e# s# t# i# n# g#  # s# e# p# a# r# a# t# e#  # i# n# v# e# s# t# i# g# a# t# i# o# n# .# 
# 8# .#  # G# e# n# d# e# r#  # i# s#  # g# i# v# e# n#  # i# n#  # s# h# o# r# t#  # a# n# d#  # f# u# l# l# .#  # O# n# l# y#  # o# n# e#  # o# f#  # t# h# e# m#  # i# s#  # n# e# c# e# s# s# a# r# y#  # s# o#  # o# n# e#  # w# i# l# l#  # b# e#  # d# r# o# p# p# e# d# .# 
# 9# .#  # A# n#  # e# m# p# l# o# y# e# e#  # w# h# o# s# e#  # e# m# p# l# o# y# m# e# n# t#  # i# s#  # t# e# r# m# i# n# a# t# e# d#  # h# a# s#  # v# a# l# i# d#  # e# n# t# r# i# e# s#  # f# o# r#  # t# e# r# m# i# n# a# t# i# o# n#  # d# a# t# e# ,#  # t# e# r# m# i# n# a# t# i# o# n#  # r# e# a# s# o# n#  # a# n# d#  # t# e# r# m# i# n# a# t# i# o# n#  # t# y# p# e# .#  # T# h# e# s# e#  # 3#  # f# e# a# t# u# r# e# s#  # s# h# o# u# l# d#  # n# o# t#  # b# e#  # u# s# e# d#  # f# o# r#  # t# r# a# i# n# i# n# g#  # t# h# e#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # m# o# d# e# l#  # b# e# c# a# u# s# e#  # t# h# e#  # f# e# a# t# u# r# e# s#  # a# r# e#  # r# e# s# u# l# t# s# ,#  # n# o# t#  # p# r# e# d# i# c# t# o# r# s# ,#  # o# f#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n# .#  # T# h# e# y#  # m# a# y#  # b# e#  # i# n# t# e# r# e# s# t# i# n# g#  # a# s#  # l# a# b# e# l# s# ,#  # h# o# w# e# v# e# r# ,#  # i# f#  # t# h# e#  # p# r# e# d# i# c# t# i# o# n#  # g# o# a# l#  # c# h# a# n# g# e# s# .# 
# 1# 0# .#  # T# h# e#  # s# t# a# t# u# s# _# y# e# a# r#  # c# o# l# u# m# n#  # r# e# p# e# a# t# s#  # i# n# f# o# r# m# a# t# i# o# n#  # i# n#  # t# h# e#  # r# e# c# o# r# d#  # d# a# t# e# .# 
# 1# 1# .#  # T# h# e#  # s# t# a# t# u# s#  # c# o# l# u# m# n#  # i# s#  # t# h# e#  # l# a# b# e# l#  # t# o#  # p# r# e# d# i# c# t# .#  # I# t#  # s# h# o# u# l# d#  # b# e#  # c# o# n# v# e# r# t# e# d#  # f# r# o# m#  # s# t# r# i# n# g#  # t# o#  # n# u# m# e# r# i# c# a# l# .

# In[None]

# Summarise the numerical data
df.describe()

# In[None]

# Summarise the non-numerical data
df.describe(include=['O'])

# ## ## A#  # c# o# u# p# l# e#  # m# o# r# e#  # o# b# s# e# r# v# a# t# i# o# n# s#  # a# b# o# u# t#  # t# h# e#  # d# a# t# a# 
# 1# .#  # T# h# e# r# e#  # a# r# e#  # o# n# l# y#  # 2#  # b# u# s# i# n# e# s# s#  # u# n# i# t#  # v# a# l# u# e# s# ,#  # s# o#  # t# h# e#  # f# e# a# t# u# r# e#  # c# a# n#  # b# e#  # c# o# n# v# e# r# t# e# d#  # t# o#  # n# u# m# e# r# i# c# a# l#  # B# o# o# l# e# a# n# .# 
# 2# .#  # T# h# e#  # c# i# t# y# ,#  # d# e# p# a# r# t# m# e# n# t#  # n# a# m# e#  # a# n# d#  # j# o# b#  # t# i# t# l# e#  # f# e# a# t# u# r# e# s#  # h# a# v# e#  # m# u# l# t# i# p# l# e#  # u# n# i# q# u# e#  # v# a# l# u# e# s# .#  # T# h# e# r# e#  # m# a# y#  # b# e#  # a#  # w# a# y#  # t# o#  # c# a# t# e# g# o# r# i# s# e#  # t# h# e# s# e#  # f# e# a# t# u# r# e# s# .

# In[None]

# Create new categories for job titles

# Look at full list of job titles and frequency
df.job_title.value_counts()

# In[None]

# The 47 jobs can be separated according to corporate hierarchy
# Use employee, manager, and combined executives and board 
employee = ['Meat Cutter', 'Dairy Person', 'Produce Clerk', 'Baker', 'Cashier',
            'Shelf Stocker', 'Recruiter', 'HRIS Analyst', 'Accounting Clerk',
            'Benefits Admin', 'Labor Relations Analyst', 'Accounts Receiveable Clerk',
            'Accounts Payable Clerk', 'Auditor', 'Compensation Analyst',
            'Investment Analyst', 'Systems Analyst', 'Corporate Lawyer', 'Legal Counsel']

manager = ['Customer Service Manager', 'Processed Foods Manager', 'Meats Manager',
           'Bakery Manager', 'Produce Manager', 'Store Manager', 'Trainer', 'Dairy Manager']

executive = ['Exec Assistant, Finance', 'Exec Assistant, Legal Counsel',
             'CHief Information Officer', 'CEO', 'Exec Assistant, Human Resources',
             'Exec Assistant, VP Stores']

board = ['VP Stores', 'Director, Recruitment', 'VP Human Resources', 'VP Finance',
         'Director, Accounts Receivable', 'Director, Accounting',
         'Director, Employee Records', 'Director, Accounts Payable',
         'Director, HR Technology', 'Director, Investments',
         'Director, Labor Relations', 'Director, Audit', 'Director, Training',
         'Director, Compensation']

# Check all jobs were entered into the categories
total = len(employee) + len(manager) + len(executive) + len(board)
print('Total jobs categorised:', total, 'out of 47')

# In[None]

# Make a copy of job titles in a new column
df['Hierarchy'] = df.job_title

# Replace the job titles in Hierarchy
# The corporate hierarchy intrinsically has order from small to large, 
# so ordinal numbers may be used
df.Hierarchy = df.Hierarchy.replace(employee, 0)
df.Hierarchy = df.Hierarchy.replace(manager, 1)
df.Hierarchy = df.Hierarchy.replace(executive, 2)
df.Hierarchy = df.Hierarchy.replace(board, 3)

# Check that the replacement went to plan
df.Hierarchy.value_counts()

# In[None]

# Create new categories for department names

# Look at full list of departments and frequency
df.department_name.value_counts()

# In[None]

# The departments can be separated according to whether they serve the customer
# or the business
serve_cus = ['Meats', 'Dairy', 'Produce', 'Bakery', 'Customer Service', 'Processed Foods']

serve_biz = ['Store Management', 'Executive', 'Recruitment', 'HR Technology',
             'Accounting', 'Employee Records', 'Accounts Receiveable',
             'Accounts Payable', 'Labor Relations', 'Training', 'Compensation',
             'Audit', 'Investment', 'Information Technology', 'Legal']

# Check all departments were entered into the categories
total = len(serve_cus) + len(serve_biz)
print('Total departments categorised:', total, 'out of 21')

# In[None]

# Make a copy of department names in a new column
df['Service_to'] = df.department_name

# Replace the department names in Service_to
df.Service_to = df.Service_to.replace(serve_cus, 'Customer')
df.Service_to = df.Service_to.replace(serve_biz, 'Business')

# Check the replacement went to plan
df.Service_to.value_counts()

# In[None]

# Create new categories for city names

# Look at full list of cities and frequency
df.city_name.value_counts()

# In[None]

# The cities are in Canada.
# The cities can be separated according to population size.

# The population data for 2011 was obtained from Statistics Canada
# http://www12.statcan.gc.ca/census-recensement/2016/dp-pd/prof/index.cfm?Lang=E
# Used 2011 as it is the most recent before the last year of this dataset (2015)
city_pop_2011 = {'Vancouver':2313328,
                 'Victoria':344615,
                 'Nanaimo':146574,
                 'New Westminster':65976,
                 'Kelowna':179839,
                 'Burnaby':223218,
                 'Kamloops':85678,
                 'Prince George':71974,
                 'Cranbrook':19319,
                 'Surrey':468251,
                 'Richmond':190473,
                 'Terrace':11486,
                 'Chilliwack':77936,
                 'Trail':7681,
                 'Langley':25081,
                 'Vernon':38180,
                 'Squamish':17479,
                 'Quesnel':10007,
                 'Abbotsford':133497,
                 'North Vancouver':48196,
                 'Fort St John':18609,
                 'Williams Lake':10832,
                 'West Vancouver':42694,
                 'Port Coquitlam':55985,
                 'Aldergrove':12083,
                 'Fort Nelson':3561,
                 'Nelson':10230,
                 'New Westminister':65976,
                 'Grand Forks':3985,
                 'White Rock':19339,
                 'Haney':76052,
                 'Princeton':2724,
                 'Dawson Creek':11583,
                 'Bella Bella':1095,
                 'Ocean Falls':129,
                 'Pitt Meadows':17736,
                 'Cortes Island':1007,
                 'Valemount':1020,
                 'Dease Lake':58,
                 'Blue River':215}
# Population notes
# New Westminister is treated as a misspelling of New Westminster
# Used Haney in Maple Ridge, British Columbia because most of the other cities are in BC
# Used Bella Bella 1 (Indian reserve) for Bella Bella
# Used Central Coast A for Ocean Falls 
# Used Strathcona B for Cortes Island
# Used Dease Lake 9 (Indian reserve) for Dease Lake

# Check dictionary made correctly
print('Cities in dictionary:', len(city_pop_2011), 'out of 40')

# In[None]

# Make a copy of city names
df['Pop'] = df.city_name

# Map from city name to population
df.Pop = df.Pop.map(city_pop_2011)

# Make a new column for population category
df['Pop_category'] = df.Pop

# Categorise according to population size
# >= 100,000 is City
# 10,000 to 99,999 is Rural
# < 10,000 is Remote
# Guidance from Australian Institute of Health and Welfare
# http://www.aihw.gov.au/rural-health-rrma-classification/
city_ix = (df['Pop'] >= 100000)
rural_ix = ((df['Pop'] < 100000) & (df['Pop'] >= 10000))
remote_ix = (df['Pop'] < 10000)
df.loc[city_ix, 'Pop_category'] = 'City'
df.loc[rural_ix, 'Pop_category'] = 'Rural'
df.loc[remote_ix, 'Pop_category'] = 'Remote'

# Check the replacement went to plan
df.Pop_category.value_counts()

# In[None]

# As the category names are based on population size, the data could be represented
# by an ordinal category instead of a nominal category.
# Convert from nominal to ordinal 
df.Pop_category = df.Pop_category.replace('Remote', 0)
df.Pop_category = df.Pop_category.replace('Rural', 1)
df.Pop_category = df.Pop_category.replace('City', 2)

# Check the replacement went to plan
df.Pop_category.value_counts()

# In[None]

# Convert STATUS from string to numerical
df.STATUS = df.STATUS.map({'ACTIVE':1, 'TERMINATED':0})

# In[None]

# Data visualisation

# Separate data to avoid one excessively overlapping the other in plots.
# One set for the terminated (out of company) and working (in company)
out_of_co = df[df.STATUS == 0]
in_co = df[df.STATUS == 1]

# In[None]

# Start with a broad look at each group in terms of age and length of service
f, (ax1, ax2) = plt.subplots(1, 2, sharex=True, sharey=True)

ax1.scatter(out_of_co.age, out_of_co.length_of_service, color='r')
ax1.set_xlabel('Age')
ax1.set_ylabel('Length of service')
ax1.set_title('Out of company')

ax2.scatter(in_co.age, in_co.length_of_service, color='b')
ax2.set_xlabel('Age')
ax2.set_title('In company')

# ## ## O# b# s# e# r# v# a# t# i# o# n# s# 
# P# e# o# p# l# e#  # m# a# y#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # a# f# t# e# r#  # w# o# r# k# i# n# g#  # f# o# r#  # a# n# y#  # l# e# n# g# t# h#  # o# f#  # t# i# m# e#  # f# r# o# m#  # 0#  # t# o#  # 2# 5#  # y# e# a# r# s#  # a# n# d#  # a# n# y#  # a# g# e#  # f# r# o# m#  # 2# 0#  # t# o#  # 6# 0# .#  # T# a# k# e#  # a#  # c# l# o# s# e# r#  # l# o# o# k#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # a# g# e# s#  # a# n# d#  # s# e# r# v# i# c# e#  # t# i# m# e# s#  # f# o# r#  # t# e# r# m# i# n# a# t# i# o# n# s# .

# In[None]

# Scatter plot of out of company dataset, with histograms of the axes
g = sns.jointplot(out_of_co.age, out_of_co.length_of_service, color='r')

# ## ## O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# T# h# e# r# e#  # a# p# p# e# a# r#  # t# o#  # b# e#  # 3#  # p# e# a# k# s#  # i# n#  # t# h# e#  # a# g# e#  # w# h# e# n#  # p# e# o# p# l# e#  # s# t# o# p#  # w# o# r# k# i# n# g# .#  # T# h# e# r# e#  # a# r# e#  # 4#  # m# a# j# o# r#  # p# e# a# k# s#  # i# n#  # t# h# e#  # l# e# n# g# t# h#  # o# f#  # s# e# r# v# i# c# e#  # b# e# f# o# r# e#  # p# e# o# p# l# e#  # s# t# o# p#  # w# o# r# k# i# n# g# .# 
#  # 
# 1# .#  # T# h# e#  # l# a# r# g# e# s# t#  # a# g# e#  # p# e# a# k#  # o# f#  # a# b# o# v# e#  # 6# 0#  # y# e# a# r# s#  # o# l# d#  # o# v# e# r# l# a# p# s#  # t# h# e#  # s# e# r# v# i# c# e#  # p# e# a# k#  # o# f#  # 2# 5#  # y# e# a# r# s# .#  # T# h# i# s#  # w# o# u# l# d#  # b# e#  # p# e# o# p# l# e#  # w# h# o#  # a# r# e#  # r# e# t# i# r# i# n# g#  # f# r# o# m#  # t# h# e#  # w# o# r# k#  # f# o# r# c# e# .# 
# 2# .#  # T# h# e#  # s# e# c# o# n# d#  # l# a# r# g# e# s# t#  # a# g# e#  # p# e# a# k#  # o# f#  # 2# 0# -# 2# 5#  # y# e# a# r# s#  # o# l# d#  # o# v# e# r# l# a# p# s#  # t# h# e#  # s# e# r# v# i# c# e#  # p# e# a# k#  # o# f#  # 0#  # y# e# a# r# s# .#  # T# h# i# s#  # i# s#  # l# i# k# e# l# y#  # p# e# o# p# l# e#  # w# h# o#  # a# r# e#  # t# r# y# i# n# g#  # j# o# b# s#  # t# o#  # f# i# n# d#  # s# o# m# e# t# h# i# n# g#  # t# h# e# y#  # w# o# u# l# d#  # l# i# k# e# .# 
# 3# .#  # T# h# e#  # t# h# i# r# d#  # a# g# e#  # p# e# a# k#  # o# f#  # 2# 9# -# 3# 4#  # o# v# e# r# l# a# p# s#  # t# h# e#  # s# e# r# v# i# c# e#  # p# e# a# k#  # o# f#  # 8#  # y# e# a# r# s# .#  # T# h# i# s#  # i# s#  # l# i# k# e# l# y#  # p# e# o# p# l# e#  # w# h# o#  # h# a# v# e#  # b# e# c# o# m# e#  # t# i# r# e# d#  # o# f#  # t# h# e# i# r#  # w# o# r# k#  # a# n# d#  # w# a# n# t#  # a#  # c# a# r# e# e# r#  # c# h# a# n# g# e# .#  # I# t#  # m# a# y#  # a# l# s# o#  # b# e#  # p# e# o# p# l# e#  # w# h# o#  # h# a# v# e#  # f# a# m# i# l# y#  # c# o# m# m# i# t# m# e# n# t# s#  # t# h# a# t#  # f# o# r# c# e#  # t# h# e# m#  # t# o#  # c# h# a# n# g# e# .# 
# 4# .#  # T# h# e#  # l# a# r# g# e# s# t#  # s# e# r# v# i# c# e#  # p# e# a# k#  # o# f#  # a# r# o# u# n# d#  # 1# 3#  # y# e# a# r# s#  # o# v# e# r# l# a# p# s#  # w# i# t# h#  # t# h# e#  # a# g# e#  # p# e# a# k#  # o# f#  # a# b# o# v# e#  # 6# 0#  # y# e# a# r# s#  # a# n# d#  # w# i# t# h#  # a# g# e# s#  # b# e# t# w# e# e# n#  # 4# 0# -# 5# 0# .#  # T# h# e#  # g# r# o# u# p#  # o# v# e# r#  # 6# 0#  # y# e# a# r# s#  # o# l# d#  # w# o# u# l# d#  # b# e#  # m# i# d# d# l# e#  # a# r# e#  # p# e# o# p# l# e#  # w# h# o#  # c# h# a# n# g# e# d#  # c# a# r# e# e# r# s#  # t# o#  # j# o# i# n#  # t# h# e#  # c# o# m# p# a# n# y# .#  # 
#  

# In[None]

# When someone leaves the company, look at their age, length of service, city size,
# and position in hierarchy. Separated by gender
g = sns.FacetGrid(out_of_co, col='Pop_category', row='Hierarchy', palette='Set1_r', 
                  hue='gender_short', margin_titles=True)
g = (g.map(plt.scatter, 'age', 'length_of_service').add_legend())

# In[None]

# Do the same for people who are working in the company
g = sns.FacetGrid(in_co, col='Pop_category', row='Hierarchy', palette='Set1_r', 
                  hue='gender_short', margin_titles=True)
g = (g.map(plt.scatter, 'age', 'length_of_service').add_legend())

# ## ## O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# 1# .#  # N# o# b# o# d# y#  # h# a# s#  # s# t# o# p# p# e# d#  # e# m# p# l# o# y# m# e# n# t#  # w# h# e# n#  # t# h# e# y#  # w# e# r# e#  # a# t#  # e# x# e# c# u# t# i# v# e#  # l# e# v# e# l# .# 
# 2# .#  # E# x# e# c# u# t# i# v# e# s#  # a# n# d#  # b# o# a# r# d#  # m# e# m# b# e# r# s#  # o# n# l# y#  # w# o# r# k#  # i# n#  # c# i# t# i# e# s# .# 
# 3# .#  # T# h# e# r# e#  # d# o# e# s#  # n# o# t#  # a# p# p# e# a# r#  # t# o#  # b# e#  # a#  # m# a# j# o# r#  # d# i# f# f# e# r# e# n# c# e#  # i# n#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n#  # b# e# t# w# e# e# n#  # m# a# l# e# s#  # a# n# d#  # f# e# m# a# l# e# s# .# 
# 4# .#  # M# a# n# a# g# e# r# s#  # a# n# d#  # b# o# a# r# d#  # m# e# m# b# e# r# s#  # s# t# o# p#  # e# m# p# l# o# y# m# e# n# t#  # a# f# t# e# r#  # a# t#  # l# e# a# s# t#  # 1# 4#  # y# e# a# r# s#  # o# f#  # s# e# r# v# i# c# e# .#  # T# h# i# s#  # m# e# a# n# s#  # t# h# a# t#  # t# h# e# y#  # w# e# r# e#  # l# i# k# e# l# y#  # i# n# t# e# r# n# a# l# l# y#  # p# r# o# m# o# t# e# d#  # t# o#  # t# h# o# s# e#  # p# o# s# i# t# i# o# n# s# .

# In[None]

# Out of interest, look at when termination is voluntary or involuntary
g = sns.FacetGrid(out_of_co, col='Pop_category', row='termreason_desc', palette='Set1_r', 
                  hue='termtype_desc', margin_titles=True)
g = (g.map(plt.scatter, 'age', 'length_of_service').add_legend())

# ## ## O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# 1# .#  # L# a# y# o# f# f# s#  # o# c# c# u# r#  # f# o# r#  # a# l# l#  # a# g# e# s#  # a# n# d#  # a# l# l#  # s# e# r# v# i# c# e#  # l# e# n# g# t# h# s#  # i# n#  # r# e# m# o# t# e#  # a# n# d#  # r# u# r# a# l#  # a# r# e# a# s# .# 
# 2# .#  # R# e# s# i# g# n# a# t# i# o# n# s#  # a# r# e#  # u# n# c# o# m# m# o# n#  # i# n#  # r# e# m# o# t# e#  # a# r# e# a# s# .# 
# 3# .#  # A# s#  # e# x# p# e# c# t# e# d# ,#  # l# a# y# o# f# f# s#  # a# r# e#  # i# n# v# o# l# u# n# t# a# r# y# ,#  # w# h# e# r# e# a# s#  # r# e# s# i# g# n# a# t# i# o# n# s#  # a# n# d#  # r# e# t# i# r# e# m# e# n# t# s#  # a# r# e#  # v# o# l# u# n# t# a# r# y# .

# In[None]

# Out of interest, look at number of terminations per year.
# Count terminations per year
term_per_year = Counter(out_of_co.STATUS_YEAR)
term_per_year_df = pd.DataFrame.from_dict(term_per_year, orient='index')
term_per_year_df = term_per_year_df.sort_index()
term_per_year_df.plot(kind='bar')

# ## ## O# b# s# e# r# v# a# t# i# o# n# s# 
# 
# 1# .#  # 2# 0# 1# 4#  # h# a# d#  # a# n#  # u# n# u# s# u# a# l# l# y#  # h# i# g# h#  # n# u# m# b# e# r#  # o# f#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n# s# .# 
# 2# .#  # T# h# e# r# e#  # w# a# s#  # a#  # p# e# a# k#  # i# n#  # e# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n# s#  # i# n#  # 2# 0# 0# 7# -# 2# 0# 0# 8# ,#  # w# h# e# n#  # t# h# e#  # G# F# C#  # o# c# c# u# r# r# e# d# .# 
# 3# .#  # T# h# e# r# e#  # i# s#  # a# n# o# t# h# e# r#  # p# e# a# k#  # i# n#  # 2# 0# 1# 2# ,#  # b# u# t#  # i# t#  # i# s#  # l# o# w# e# r#  # t# h# a# n#  # t# h# e#  # G# F# C#  # p# e# a# k# .# 
# 4# .#  # E# m# p# l# o# y# m# e# n# t#  # t# e# r# m# i# n# a# t# i# o# n# s#  # i# n#  # 2# 0# 1# 5#  # i# s#  # s# i# m# i# l# a# r#  # t# o#  # t# h# e#  # G# F# C#  # p# e# a# k# ,#  # b# u# t#  # m# u# c# h#  # l# o# w# e# r#  # t# h# a# n#  # t# h# e#  # 2# 0# 1# 4#  # p# e# a# k# .#  # T# h# e#  # d# a# t# a# s# e# t#  # r# e# a# c# h# e# s#  # 3# 1#  # D# e# c# e# m# b# e# r#  # 2# 0# 1# 5# ,#  # s# o#  # t# h# e#  # 2# 0# 1# 5#  # r# e# c# o# r# d#  # i# s#  # c# o# m# p# l# e# t# e# .

# In[None]

# Preprocessing for machine learning models

# Drop the employee ID, record date, birth date, termination date, termination reason, 
# termination type, gender_full, STATUS_YEAR, and store_name features
# Also drop job_title (replaced with Hierarchy), department_name (replaced with Service_to),
# and city_name and Pop (replaced with Pop_category)
drop_cols = ['EmployeeID', 'recorddate_key', 'birthdate_key', 'orighiredate_key',
             'terminationdate_key', 'gender_full', 'termreason_desc',
             'termtype_desc', 'STATUS_YEAR', 'store_name', 'job_title', 'department_name',
             'city_name', 'Pop']

df = df.drop(drop_cols, axis=1)

# In[None]

# The gender, business unit and Service_to categories are nominal, so they will
# be exploded instead of being converted to ordinal values
dummy_cols = ['gender_short', 'BUSINESS_UNIT', 'Service_to']
df = pd.get_dummies(df, columns=dummy_cols)

# In[None]

# Separate the label from the dataset
label = df.STATUS
df = df.drop('STATUS', axis=1)

# In[None]

# Machine learning classification models

# Only age and length of service have double digit values. It should be okay to
# leave the values at their normal scales.

# Split data for training and testing. Specify random state for repeatability.
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df, label, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/246620.npy", { "accuracy_score": score })

import os
import pandas as pd
os.getcwd()
fname = '../input/diabetescsv/diabetes.csv'
patients = pd.read_csv(fname, low_memory=False)
df = pd.DataFrame(patients)
print(df.head())
print(df.shape)
print(df.size)
print(df.columns)
dfworking = df.drop('DiabetesPedigreeFunction', axis =1)
dfworking.mean()
dfworking.std()
dfworking.max()
dfworking.min()
dfworking.quantile(0.25)
dfworking.quantile(0.75)
dfworking.quantile(0.25)*1.5
dfworking.quantile(0.75)*1.5
dfworking.boxplot(figsize=(10,6))
dfworking.plot.box(vert=False)
dfworking.boxplot(column=['Pregnancies','Glucose','BloodPressure','Insulin','BMI','Age'],figsize=(10,6))
dfworking.skew()
dfworking.kurtosis()
dfworking.hist(figsize=(10,6))
dfworking.corr()
my_tab = pd.crosstab(index = df['Outcome'],columns="Count")
my_tab = my_tab.sort_values('Count',ascending=[False])
print(my_tab)
my_tab = pd.crosstab(index = df['Insulin'],columns="Count")
my_tab = my_tab.sort_values('Count',ascending=[False])
print(my_tab)
diabetics = pd.DataFrame(dfworking['Outcome'])
features = pd.DataFrame(dfworking.drop('Outcome',axis=1))
diabetics.columns
features.columns
dfworking.dtypes
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
numerical = ['Age','SkinThickness', 'BMI','Insulin','BloodPressure','Glucose','Pregnancies']
features[numerical] = scaler.fit_transform(dfworking[numerical])
#display(features[numerical].head(n=1))
features = pd.get_dummies(features)
#display(features.head(1),diabetics.head(1))
encoded = list(features.columns)
print("{} total features after one-hot encoding.".format(len(encoded)))
print(encoded)
#display(features.head(1),diabetics.head(1))
print(encoded)
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
features=shuffle(features, random_state=0)
diabetics=shuffle(diabetics, random_state=0)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features, diabetics, train_size=0.8, test_size=1-0.8, random_state=0)
print("Training set has {} samples.".format(X_train.shape[0]))
print("Testing set has {} samples.".format(X_test.shape[0]))
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
seed = 7
models = []
models.append(('LR', LogisticRegression(solver='liblinear',)))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))
models.append(('RFC', RandomForestClassifier()))
results = []
names = []
scoring = 'accuracy'
import warnings
warnings.filterwarnings("ignore")
for name, model in models:
    
    
    kfold = model_selection.KFold(n_splits=10, random_state=seed)
    cv_results = model_selection.cross_val_score(model, X_train, y_train,cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aku0810_diabetes.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aku0810_diabetes/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aku0810_diabetes/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aku0810_diabetes/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aku0810_diabetes/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aku0810_diabetes/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aku0810_diabetes/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aku0810_diabetes/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aku0810_diabetes/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aku0810_diabetes/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aku0810_diabetes/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aku0810_diabetes/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aku0810_diabetes/testY.csv",encoding="gbk")


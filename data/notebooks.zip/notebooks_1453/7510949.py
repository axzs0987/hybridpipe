import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# ## ##  # W# h# a# t#  # w# e#  # w# i# l# l#  # b# e#  # d# o# i# n# g# ?#  # 
# 1# .#  # D# o# i# n# g#  # s# o# m# e#  # b# a# s# i# c#  # E# D# A#  # o# v# e# r#  # t# h# e#  # d# a# t# a# .#  # 
# 3# .#  # F# i# t# t# i# n# g#  # a#  # L# o# g# i# s# t# i# c#  # r# e# g# r# e# s# s# i# o# n#  # m# o# d# e# l#  # o# v# e# r#  # t# h# e#  # m# o# d# e# l# .

# In[None]

import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
import seaborn as sns

# In[None]

data = pd.read_csv("/kaggle/input/predicting-a-pulsar-star/pulsar_stars.csv")
data.head()

# In[None]

data.columns = ["mean_intrgt", "std_intrgt", "kurtosis_intrgt", "skew_intrgt", "mean_dmsnr", "std_dmsnr", "kurtosis_dmsnr", "skew_dmsnr", "class"]

# ## ##  # E# D# A

# In[None]

sns.kdeplot(data[data["class"] == 0]["mean_intrgt"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["mean_intrgt"], label = "Class 1")
plt.title("Mean of the integrated profile")
plt.show()

# In[None]

# DM-SNR curve
sns.kdeplot(data[data["class"] == 0]["mean_dmsnr"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["mean_dmsnr"], label = "Class 1")
plt.title("Mean of the DM-SNR curve")
plt.show()

# In[None]

sns.kdeplot(data[data["class"] == 0]["std_intrgt"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["std_intrgt"], label = "Class 1")
plt.title("Std. Dev. of the integrated profile")
plt.show()

# In[None]

# DM-SNR curve
sns.kdeplot(data[data["class"] == 0]["std_dmsnr"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["std_dmsnr"], label = "Class 1")
plt.title("Std. Dev. of the DM-SNR curve")
plt.show()

# In[None]

sns.kdeplot(data[data["class"] == 0]["kurtosis_intrgt"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["kurtosis_intrgt"], label = "Class 1")
plt.title("Excess Kurtosis of Integrated Profile")
plt.show()

# In[None]

sns.kdeplot(data[data["class"] == 0]["kurtosis_dmsnr"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["kurtosis_dmsnr"], label = "Class 1")
plt.title("Excess Kurtosis of DM-SNR Curve")
plt.show()

# In[None]

sns.kdeplot(data[data["class"] == 0]["skew_intrgt"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["skew_intrgt"], label = "Class 1")
plt.title("Skewness of Integrated Profile")
plt.show()

# In[None]

sns.kdeplot(data[data["class"] == 0]["skew_dmsnr"], label = "Class 0")
sns.kdeplot(data[data["class"] == 1]["skew_dmsnr"], label = "Class 1")
plt.title("Skewness of the DM-SNR Curve")
plt.show()

# In[None]

sns.countplot(data["class"])

# In[None]

from sklearn.decomposition import PCA 
pca = PCA(n_components=2)
pca_data = pca.fit_transform(data.iloc[:, :-1])

pca_data = pd.DataFrame(pca_data)
pca_data["class"] = data["class"]

# In[None]

plt.scatter(pca_data[pca_data["class"] == 1].iloc[:, 0], pca_data[pca_data["class"] == 1].iloc[:, 1], color = "green",label = "Class 1" )
plt.scatter(pca_data[pca_data["class"] == 0].iloc[:, 0], pca_data[pca_data["class"] == 0].iloc[:, 1], color = "red", label = "Class 0" )
plt.legend()
plt.show()

# In[None]

plt.scatter(pca_data[pca_data["class"] == 0].iloc[:, 0], pca_data[pca_data["class"] == 0].iloc[:, 1], color = "red", label = "Class 0" )
plt.scatter(pca_data[pca_data["class"] == 1].iloc[:, 0], pca_data[pca_data["class"] == 1].iloc[:, 1], color = "blue", alpha= .2,label = "Class 1" )
plt.legend()
plt.show()

# In[None]

sns.pairplot(data)

# In[None]

from scipy.stats import pearsonr
for i in data.columns[:-1]:
    for j in data.columns[:-1]:
        corr = pearsonr(data[i], data[j])[0]
        if corr > .7 or corr < -.7:
            print(i, " ", j, pearsonr(data[i], data[j])[0])

# ## ##  # M# o# d# e# l#  

# In[None]

X = data.iloc[:, :-1]
y = data.iloc[:, -1]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7510949.npy", { "accuracy_score": score })

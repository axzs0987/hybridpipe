import pandas as pd
# ##  # C# u# s# t# o# m# e# r#  # C# h# u# r# n#  # R# a# t# e# 
# 
# 
# *# *# W# i# k# i# p# e# d# i# a# *# *#  # d# e# f# i# n# e# s#  # *# *# [# c# h# u# r# n#  # r# a# t# e# ]# (# h# t# t# p# s# :# /# /# e# n# .# w# i# k# i# p# e# d# i# a# .# o# r# g# /# w# i# k# i# /# C# h# u# r# n# _# r# a# t# e# )#  # (# s# o# m# e# t# i# m# e# s#  # c# a# l# l# e# d#  # a# t# t# r# i# t# i# o# n#  # r# a# t# e# )# ,#  # i# n#  # i# t# s#  # b# r# o# a# d# e# s# t#  # s# e# n# s# e# ,#  # i# s#  # a#  # m# e# a# s# u# r# e#  # o# f#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # i# n# d# i# v# i# d# u# a# l# s#  # o# r#  # i# t# e# m# s#  # m# o# v# i# n# g#  # o# u# t#  # o# f#  # a#  # c# o# l# l# e# c# t# i# v# e#  # g# r# o# u# p#  # o# v# e# r#  # a#  # s# p# e# c# i# f# i# c#  # p# e# r# i# o# d# .#  # I# t#  # i# s#  # o# n# e#  # o# f#  # t# w# o#  # p# r# i# m# a# r# y#  # f# a# c# t# o# r# s#  # t# h# a# t#  # d# e# t# e# r# m# i# n# e#  # t# h# e#  # s# t# e# a# d# y# -# s# t# a# t# e#  # l# e# v# e# l#  # o# f#  # c# u# s# t# o# m# e# r# s#  # a#  # b# u# s# i# n# e# s# s#  # w# i# l# l#  # s# u# p# p# o# r# t# .# *# *# 
# 
# T# h# e#  # t# e# r# m#  # i# s#  # u# s# e# d#  # i# n#  # m# a# n# y#  # c# o# n# t# e# x# t# s# ,#  # b# u# t#  # i# s#  # m# o# s# t#  # w# i# d# e# l# y#  # a# p# p# l# i# e# d#  # i# n#  # b# u# s# i# n# e# s# s#  # w# i# t# h#  # r# e# s# p# e# c# t#  # t# o#  # a#  # c# o# n# t# r# a# c# t# u# a# l#  # c# u# s# t# o# m# e# r#  # b# a# s# e# ,#  # f# o# r#  # e# x# a# m# p# l# e#  # i# n#  # b# u# s# i# n# e# s# s# e# s#  # w# i# t# h#  # a#  # s# u# b# s# c# r# i# b# e# r# -# b# a# s# e# d#  # s# e# r# v# i# c# e#  # m# o# d# e# l#  # s# u# c# h#  # a# s#  # m# o# b# i# l# e#  # t# e# l# e# p# h# o# n# e#  # n# e# t# w# o# r# k# s#  # a# n# d#  # p# a# y#  # T# V#  # o# p# e# r# a# t# o# r# s# .#  # T# h# e#  # t# e# r# m#  # i# s#  # a# l# s# o#  # u# s# e# d#  # t# o#  # r# e# f# e# r#  # t# o#  # p# a# r# t# i# c# i# p# a# n# t#  # t# u# r# n# o# v# e# r#  # i# n#  # p# e# e# r# -# t# o# -# p# e# e# r#  # n# e# t# w# o# r# k# s# .#  # C# h# u# r# n#  # r# a# t# e#  # i# s#  # a# n#  # i# n# p# u# t#  # i# n# t# o#  # c# u# s# t# o# m# e# r#  # l# i# f# e# t# i# m# e#  # v# a# l# u# e#  # m# o# d# e# l# i# n# g# ,#  # a# n# d#  # c# a# n#  # b# e#  # p# a# r# t#  # o# f#  # a#  # s# i# m# u# l# a# t# o# r#  # u# s# e# d#  # t# o#  # m# e# a# s# u# r# e#  # r# e# t# u# r# n#  # o# n#  # m# a# r# k# e# t# i# n# g#  # i# n# v# e# s# t# m# e# n# t#  # u# s# i# n# g#  # m# a# r# k# e# t# i# n# g#  # m# i# x#  # m# o# d# e# l# i# n# g# .# 
# 
# -# -# -# 
# 
# ##  # O# b# j# e# c# t# i# v# e# 
# 
# P# r# e# d# i# c# t#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # a# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# e#  # n# e# t# w# o# r# k#  # s# o#  # t# h# a# t#  # w# e#  # c# a# n#  # s# p# e# c# i# f# i# c# a# l# l# y#  # t# a# r# g# e# t#  # t# h# e# m#  # a# n# d#  # t# r# y#  # r# e# t# a# i# n# i# n# g#  # t# h# e# m# .# 
# 
# ##  # B# e# n# e# f# i# t# 
# R# e# t# e# n# t# i# o# n#  # c# o# s# t#  # i# s#  # a# l# w# a# y# s#  # l# e# s# s#  # t# h# a# n#  # c# u# s# t# o# m# e# r#  # a# c# q# u# i# s# i# t# i# o# n#  # c# o# s# t# .#  # I# f#  # w# e#  # f# o# c# u# s#  # a# n# d#  # t# r# y#  # t# o#  # r# e# t# a# i# n#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # m# i# g# h# t#  # l# e# a# v# e#  # b# u# t#  # h# a# v# e#  # n# o# t#  # y# e# t#  # l# e# f# t# ,#  # w# e#  # c# o# u# l# d#  # s# a# v# e#  # a#  # s# u# b# s# t# a# n# t# i# a# l#  # a# m# o# u# n# t#  # o# f#  # m# o# n# e# y# .# 
# 
# -# -# -# 
# 
# ## ## ##  # D# a# t# a# s# e# t#  # i# n# f# o# 
# T# h# i# s#  # d# a# t# a# s# e# t#  # c# o# n# t# a# i# n# s#  # i# n# f# o# r# m# a# t# i# o# n#  # r# e# g# a# r# d# i# n# g#  # t# e# l# e# c# o# m#  # s# u# b# s# c# r# i# b# e# r# s# .#  # B# a# s# e# d#  # o# n#  # t# h# i# s#  # i# n# f# o# r# m# a# t# i# o# n# ,#  # w# e#  # w# i# l# l#  # b# u# i# l# d#  # a#  # m# o# d# e# l#  # t# o#  # i# d# e# n# t# i# f# y#  # c# u# s# t# o# m# e# r# s#  #  # w# h# o#  # a# r# e#  # m# o# s# t#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# e#  # n# e# t# w# o# r# k#  # t# o#  # s# o# m# e#  # o# t# h# e# r#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r# .# 
# 
# T# h# e#  # d# a# t# a# s# e# t# s#  # c# a# n#  # b# e#  # f# o# u# n# d#  # [# h# e# r# e# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# b# l# a# s# t# c# h# a# r# /# t# e# l# c# o# -# c# u# s# t# o# m# e# r# -# c# h# u# r# n# )# .# 
# 
# T# h# e#  # d# a# t# a#  # s# e# t#  # i# n# c# l# u# d# e# s#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t# :# 
# 
# -#  # C# u# s# t# o# m# e# r# s#  # w# h# o#  # l# e# f# t#  # w# i# t# h# i# n#  # t# h# e#  # l# a# s# t#  # m# o# n# t# h#  # –#  # t# h# e#  # c# o# l# u# m# n#  # i# s#  # c# a# l# l# e# d#  # C# h# u# r# n# 
# -#  # S# e# r# v# i# c# e# s#  # t# h# a# t#  # e# a# c# h#  # c# u# s# t# o# m# e# r#  # h# a# s#  # s# i# g# n# e# d#  # u# p#  # f# o# r#  # –#  # p# h# o# n# e# ,#  # m# u# l# t# i# p# l# e#  # l# i# n# e# s# ,#  # i# n# t# e# r# n# e# t# ,#  # o# n# l# i# n# e#  # s# e# c# u# r# i# t# y# ,#  # o# n# l# i# n# e#  # b# a# c# k# u# p# ,#  # d# e# v# i# c# e#  # -# p# r# o# t# e# c# t# i# o# n# ,#  # t# e# c# h#  # s# u# p# p# o# r# t# ,#  # a# n# d#  # s# t# r# e# a# m# i# n# g#  # T# V#  # a# n# d#  # m# o# v# i# e# s# 
# -#  # C# u# s# t# o# m# e# r#  # a# c# c# o# u# n# t#  # i# n# f# o# r# m# a# t# i# o# n#  # –#  # h# o# w#  # l# o# n# g#  # t# h# e# y# ’# v# e#  # b# e# e# n#  # a#  # c# u# s# t# o# m# e# r# ,#  # c# o# n# t# r# a# c# t# ,#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d# ,#  # p# a# p# e# r# l# e# s# s#  # b# i# l# l# i# n# g# ,#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s# ,#  # a# n# d#  # t# o# t# a# l#  # c# h# a# r# g# e# s# 
# -#  # D# e# m# o# g# r# a# p# h# i# c#  # i# n# f# o#  # a# b# o# u# t#  # c# u# s# t# o# m# e# r# s#  # –#  # g# e# n# d# e# r# ,#  # a# g# e#  # r# a# n# g# e# ,#  # a# n# d#  # i# f#  # t# h# e# y#  # h# a# v# e#  # p# a# r# t# n# e# r# s#  # a# n# d#  # d# e# p# e# n# d# e# n# t# s

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pprint #better dictionary printing
import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
import plotly.tools as tls
import plotly.figure_factory as ff
import plotly.express as px

# ##  # D# a# t# a#  # O# v# e# r# v# i# e# w# 
# 
# L# e# t#  # u# s#  # g# e# t#  # t# o#  # k# n# o# w#  # o# u# r#  # d# a# t# a# .

# In[None]

churn = pd.read_csv('../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

churn.head()

# In[None]

churn.info()

# In[None]

print('Rows: ', churn.shape[0])
print('Columns: ', churn.shape[1])
print('\nFeatures:\n ', churn.columns.tolist())
print('\nUnique Value Count:\n ', churn.nunique())
print('\nMissing Value:\n ', churn.isnull().sum())

# In[None]

def values(cols):
    d = {}
    for col in cols:
        x = churn[col].unique()
        d[col] = x
    pprint.pprint(d)

# In[None]

print('Feature Values: \n')
values(churn.columns)

# ##  # D# a# t# a#  # M# a# n# i# p# u# l# a# t# i# o# n

# In[None]

churn.TotalCharges.min()

# T# o# t# a# l# C# h# a# r# g# e# s#  # c# o# l# u# m# n#  # c# o# n# t# a# i# n# s#  # s# p# a# c# e# s#  # w# h# i# c# h#  # w# e#  # w# i# l# l#  # r# e# p# l# a# c# e#  # w# i# t# h#  # n# a# n# .

# In[None]

churn['TotalCharges'] = churn['TotalCharges'].replace(' ',np.nan)

# In[None]

churn.head()

# In[None]

churn = churn[churn['TotalCharges'].notnull()]

# In[None]

churn['TotalCharges'] = churn['TotalCharges'].astype(float)

# R# e# p# l# a# c# i# n# g#  # '# N# o#  # I# n# t# e# r# n# e# t#  # S# e# r# v# i# c# e# '#  # t# o#  # '# N# o# '#  # i# n#  # c# o# l# u# m# n# s# :# 
# -#  # D# e# v# i# c# e# P# r# o# t# e# c# t# i# o# n# 
# -#  # O# n# l# i# n# e# B# a# c# k# u# p# 
# -#  # O# n# l# i# n# e# S# e# c# u# r# i# t# y# 
# -#  # S# t# r# e# a# m# i# n# g# M# o# v# i# e# s# 
# -#  # S# t# r# e# a# m# i# n# g# T# V# 
# -#  # T# e# c# h# S# u# p# p# o# r# t

# In[None]

churn['SeniorCitizen'] = churn['SeniorCitizen'].replace({1: 'Yes', 0: 'No'})

# In[None]

churn['tenure'].min()

# In[None]

churn['tenure'].max()

# In[None]

def tenure_slabs(value):
    if value <= 12:
        return 'ten_0-12'
    elif (value > 12) & (value <= 24):
        return 'ten_12-24'
    elif (value > 24) & (value <= 36):
        return 'ten_24-36'
    elif (value > 36) & (value <= 48):
        return 'ten_36-48'
    elif (value > 48) & (value <= 60):
        return 'ten_48-60'
    elif (value > 60) & (value <= 72):
        return 'ten_60-72'

# In[None]

churn['tenure_duration'] = churn['tenure'].apply(tenure_slabs) #to categorical column

# ##  # E# D# A

# In[None]

def make_df(data, col):
    df = pd.DataFrame(data[col].value_counts(normalize = True)*100)
    df = df.reset_index()
    return df

# In[None]

gen = make_df(churn, 'gender')
gen.head()

# In[None]

px.bar(gen, x = 'index', y = 'gender', title = 'Gender Distribution: Overall data')

# W# e#  # h# a# v# e#  # a# l# m# o# s# t#  # e# q# u# a# l#  # n# u# m# b# e# r#  # o# f#  # m# a# l# e#  # a# n# d#  # f# e# m# a# l# e# s#  # i# n#  # t# h# e#  # d# a# t# a# s# e# t# .

# In[None]

sen = make_df(churn, 'SeniorCitizen')
sen.head()

# In[None]

px.bar(sen, x = 'index', y = 'SeniorCitizen', title = 'Senior Citizen Distribution: Overall data')

# ~# 1# 6# %#  # o# f#  # t# h# e#  # u# s# e# r# s#  # a# r# e#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s# .

# In[None]

labels = churn['Churn'].value_counts().keys().tolist()
vals = churn['Churn'].value_counts().values.tolist()

fig = go.Figure(data = go.Pie(labels = labels, values = vals))
fig.update_traces(hoverinfo = 'label+value', marker = dict(colors = ['rgb(124,185,232)', 'gold']), hole = .5)
fig.update(layout_title_text = 'Customer Churn Data: Overall data', layout_showlegend = True)
fig.show()

# ## ##  # D# e# e# p#  # D# i# v# e

# L# e# t#  # u# s#  # n# o# w#  # d# e# e# p#  # d# i# v# e#  # b# y#  # s# e# p# a# r# a# t# i# n# g#  # t# h# e#  # d# a# t# a# s# e# t#  # b# a# s# e# d#  # o# n#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # l# e# f# t#  # t# h# e#  # t# e# l# e# c# o# m#  # n# e# t# w# o# r# k#  # a# n# d#  # t# h# o# s# e#  # w# h# o#  # h# a# v# e#  # s# t# a# y# e# d#  # w# i# t# h#  # t# h# e#  # n# e# t# w# o# r# k# .

# In[None]

churn.shape

# In[None]

y_churn = churn[churn['Churn'] == 'Yes'] #customers who have left the network
n_churn = churn[churn['Churn'] == 'No'] #customers who have stayed with the network

# In[None]

print('Number of people who left the telecom:', y_churn.shape[0])
print('Number of people who did not left the telecom:', n_churn.shape[0])

# In[None]

def plot_pie(labels, values):
    fig = go.Figure(data = go.Pie(labels = labels, values = values))
    fig.update_traces(hoverinfo='label+value', marker = dict(colors = ['royal blue', 'gold']), hole = .5)
    fig.show()
    
def label(col, churn):
    if churn == 1:
        x = y_churn[col].value_counts().keys().tolist()
        return x
    else:
        x = n_churn[col].value_counts().keys().tolist()
        return x

def values(col, churn):
    if churn == 1:
        x = y_churn[col].value_counts().values.tolist()
        return x
    else: 
        x = n_churn[col].value_counts().values.tolist()
        return x

# In[None]

from plotly.subplots import make_subplots

# In[None]

def make_pies(column, title):
    specs = [[{'type':'domain'}, {'type':'domain'}]]
    colors = ['rgb(124,185,232)','rgb(255,213,0)','rgb(25,77,0)','rgb(255,126,0)','rgb(153,255,102)']
    fig = make_subplots(rows = 1, cols = 2, specs = specs)
    fig.add_trace(go.Pie(labels = label(column, 1), values = values(column, 1), name = 'Churn', marker_colors = colors), 1,1)
    fig.add_trace(go.Pie(labels = label(column, 0), values = values(column, 0), name = 'Non-churn', marker_colors = colors), 1,2)
    fig.update_traces(hoverinfo = 'label+value', hole = 0.6)
    fig.update(layout_title_text = title +': Churn Vs. Non-churn customers')
    fig.update_layout(annotations = [dict(text = 'Churn',x=0.18, y=0.5, font_size=20, showarrow=False),
                                    dict(text = 'Non-churn',x=0.85, y=0.5, font_size=20, showarrow=False)])
    fig.show()

# In[None]

make_pies('gender', 'Gender')

# In[None]

make_pies('SeniorCitizen', 'Senior Citizen')

# L# e# t# '# s#  # p# l# o# t#  # p# e# o# p# l# e#  # w# i# t# h# /# w# i# t# h# o# u# t#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# .

# In[None]

make_pies('DeviceProtection', 'Device Protection')

# In[None]

make_pies('OnlineBackup', 'Online Backup')

# In[None]

make_pies('OnlineSecurity', 'Online Security')

# In[None]

make_pies('StreamingMovies', 'Streaming Movies')

# In[None]

make_pies('StreamingTV','Streaming TV')

# In[None]

make_pies('TechSupport', 'Tech Support')

# In[None]

make_pies('Contract','Contract')

# In[None]

make_pies('SeniorCitizen', 'Senior Citizen')

# In[None]

make_pies('Partner','Partner')

# In[None]

make_pies('Dependents', 'Dependents')

# In[None]

make_pies('PhoneService', 'Phone Service')

# In[None]

make_pies('PaperlessBilling', 'Paperless Billing')

# In[None]

make_pies('PaymentMethod', 'Payment Method')

# In[None]

def make_hist(column, title):
    #fig = make_subplots(rows = 1, cols = 2)
    fig = go.Figure()
    fig.add_trace(go.Histogram(x = n_churn[column], name = 'Non-churn'))
    fig.add_trace(go.Histogram(x = y_churn[column], name = 'Churn'))
    #fig.append_trace(h1, 1,1)
    #fig.append_trace(h2, 1,2)
    fig.update_layout(title_text = title+': Churn Vs. Non-churn customers', 
                      xaxis_title_text = 'Value', yaxis_title_text = 'Count',
                     bargap = 0.2,
                     bargroupgap = 0.1
                     )
    fig.show()

# In[None]

make_hist('TotalCharges', 'Total Charge')

# In[None]

make_hist('tenure_duration', 'Tenure Duration')

# In[None]

avg_charges = churn.groupby('tenure_duration').mean().reset_index()

# ## ##  # c# h# a# n# g# e

# In[None]

fig = px.bar(avg_charges, x = 'tenure_duration', y = 'MonthlyCharges')
fig.show()

# In[None]

churn.columns.tolist()

# ##  # P# r# e# p# r# o# c# e# s# s# i# n# g

# In[None]

churn.nunique()

# In[None]

category_cols = []
for col in churn.columns.tolist():
    if (churn[col].nunique() <= 6):
        category_cols.append(col)
print(category_cols)

# W# e#  # w# i# l# l#  # n# o# w#  # u# s# e#  # L# a# b# e# l# E# n# c# o# d# e# r#  # t# o#  # e# n# c# o# d# e#  # o# u# r#  # d# a# t# a#  # i# n#  # n# u# m# e# r# i# c#  # f# o# r# m#  # w# h# i# c# h#  # i# s#  # n# e# c# e# s# s# a# r# y#  # f# o# r#  # M# L#  # m# o# d# e# l# s# .

# In[None]

from sklearn import preprocessing

churn2 = churn.copy()
le = preprocessing.LabelEncoder()
churn2[category_cols] = churn2[category_cols].apply(le.fit_transform)
churn2.head()

# W# e#  # w# i# l# l#  # s# c# a# l# e#  # n# u# m# e# r# i# c#  # v# a# l# u# e#  # c# o# l# u# m# n# s# .

# In[None]

numeric_cols = ['tenure', 'MonthlyCharges', 'TotalCharges']

# In[None]

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

scaled_values = scaler.fit_transform(churn2[numeric_cols])
scaled_values = pd.DataFrame(scaled_values, columns = numeric_cols)
scaled_values.head()

# In[None]

scaled_values.isnull().sum()

# In[None]

churn2.isnull().sum()

# In[None]

churn2 = churn2.drop(columns = numeric_cols, axis = 1)
churn2 = churn2.merge(scaled_values, how = 'left', left_index = True, right_index = True)
churn2.head()
churn2 = churn2.dropna()

# In[None]

correlation = churn2.corr()
correlation

# In[None]

corr_col = correlation.columns.tolist()


# In[None]

fig = go.Figure(data = go.Heatmap(z = correlation,
                                 x = corr_col,
                                 y = corr_col)
               )

fig.update_layout(title = 'Correlation Matrix', width = 800, height = 800)
fig.update_xaxes(tickangle = 90)
fig.show()

# ##  # M# o# d# e# l# l# i# n# g# 
# 
# N# o# w#  # w# e#  # h# a# v# e#  # c# o# n# v# e# r# t# e# d#  # a# l# l#  # t# h# e#  # c# o# l# u# m# n# s#  # i# n#  # n# u# m# e# r# i# c#  # f# o# r# m#  # a# n# d#  # c# a# n#  # s# t# a# r# t#  # m# o# d# e# l# l# i# n# g# .

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,accuracy_score,classification_report
from sklearn.metrics import roc_auc_score,roc_curve,scorer

# In[None]

t_cols = []
for i in churn2.columns:
    if (i != 'Churn') & (i != 'customerID'):
        t_cols.append(i)

# In[None]

train_data = churn2[t_cols]
target = churn2['Churn']

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(train_data, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5718422.npy", { "accuracy_score": score })

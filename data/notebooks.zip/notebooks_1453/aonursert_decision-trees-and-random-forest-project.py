import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
loans = pd.read_csv("../input/lending-club-data/loan_data.csv")
loans.info()
loans.describe()
loans.head()
#sns.set_style("whitegrid")
#fig = plt.figure(figsize=(15,4))
#sns.distplot(loans[loans["credit.policy"] == 1]["fico"], kde=False, label="Credit Policy = 1")
#sns.distplot(loans[loans["credit.policy"] == 0]["fico"], kde=False, label="Credit Policy = 0")
#plt.legend(loc=0)
#sns.set_style("whitegrid")
#fig = plt.figure(figsize=(15,4))
#sns.distplot(loans[loans["not.fully.paid"] == 0]["fico"], kde=False, label="Not Fully Paid = 0")
#sns.distplot(loans[loans["not.fully.paid"] == 1]["fico"], kde=False, label="Not Fully Paid = 1")
#plt.legend(loc=0)
#fig = plt.figure(figsize=(10,6))
#sns.countplot(x="purpose", data=loans, hue="not.fully.paid")
#sns.jointplot(x="fico", y="int.rate", data=loans)
#sns.lmplot(x="fico", y="int.rate", col="not.fully.paid", data=loans, hue="credit.policy")
loans.info()
loans.head()
cat_feats = ["purpose"]
final_data = pd.get_dummies(loans, columns=cat_feats, drop_first=True)
loans.head()
final_data.head()
final_data.columns
from sklearn.model_selection import train_test_split
X = final_data.drop("not.fully.paid", axis=1)
y = final_data["not.fully.paid"]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.tree import DecisionTreeClassifier
dtree = DecisionTreeClassifier()
#dtree.fit(X_train, y_train)
#predictions = dtree.predict(X_test)
from sklearn.metrics import confusion_matrix, classification_report
#print(confusion_matrix(y_test, predictions))
#print(classification_report(y_test, predictions))
from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=200)
#rfc.fit(X_train, y_train)
#rfc_predictions = rfc.predict(X_test)
#print(classification_report(y_test, rfc_predictions))
#print(confusion_matrix(y_test, rfc_predictions))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aonursert_decision-trees-and-random-forest-project.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_decision-trees-and-random-forest-project/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aonursert_decision-trees-and-random-forest-project/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aonursert_decision-trees-and-random-forest-project/testY.csv",encoding="gbk")


import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[None]

df = pd.read_csv('/kaggle/input/weather-dataset-rattle-package/weatherAUS.csv')

# In[None]

df

# In[None]

import seaborn as sns

# In[None]

sns.countplot(df.RainTomorrow)

# In[None]

df.isnull().sum()

# In[None]

df.MinTemp.value_counts()

# In[None]

df.MinTemp.fillna(9.6,inplace=True)

# In[None]

df.MaxTemp.value_counts()

# In[None]

df.MaxTemp.fillna(20.0,inplace=True)

# In[None]

df.Rainfall.value_counts()

# In[None]

df.Rainfall.fillna(0.0,inplace=True)

# In[None]

df.Evaporation.value_counts()

# In[None]

df.Evaporation.fillna(4.0,inplace=True)

# In[None]

df.Sunshine.value_counts()

# In[None]

df.Sunshine.fillna(0.0,inplace=True)

# In[None]

df.WindGustDir.value_counts()

# In[None]

df.WindGustDir.fillna('W',inplace=True)

# In[None]

df.WindGustSpeed.value_counts()

# In[None]

df.WindGustSpeed.fillna(35.0,inplace=True)

# In[None]

df.WindDir9am.value_counts()

# In[None]

df.WindDir9am.fillna('N',inplace=True)

# In[None]

df.WindDir3pm.value_counts()

# In[None]

df.WindDir3pm.fillna('SE',inplace=True)

# In[None]

df.WindSpeed9am.value_counts()

# In[None]

df.WindSpeed9am.fillna(9.0,inplace=True)

# In[None]

df.WindSpeed3pm.value_counts()

# In[None]

df.WindSpeed3pm.fillna(13.0,inplace=True)

# In[None]

df.Humidity9am.value_counts()

# In[None]

df.Humidity9am.fillna(99.0,inplace=True)

# In[None]

df.Humidity3pm.value_counts()

# In[None]

df.Humidity3pm.fillna(52.0,inplace=True)

# In[None]

df.Pressure9am.value_counts()

# In[None]

df.Pressure9am.fillna(1016.4,inplace=True)

# In[None]

df.Pressure3pm.value_counts()

# In[None]

df.Pressure3pm.fillna(1015.5,inplace=True)

# In[None]

df.Cloud9am.value_counts()

# In[None]

df.Cloud9am.fillna(7.0,inplace=True)

# In[None]

df.Cloud3pm.value_counts()

# In[None]

df.Cloud3pm.fillna(7.0,inplace=True)

# In[None]

df.Temp9am.value_counts()

# In[None]

df.Temp9am.fillna(17.0,inplace=True)

# In[None]

df.Temp3pm.value_counts()

# In[None]

df.Temp3pm.fillna(20.0,inplace=True)

# In[None]

df.RainToday.value_counts()

# In[None]

df.RainToday.fillna('No',inplace=True)

# In[None]

df.info()

# In[None]

from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()
df['RainTomorrow']=label.fit_transform(df.RainTomorrow)
df['RainToday']=label.fit_transform(df.RainToday)
df['WindDir9am']=label.fit_transform(df.WindDir9am)
df['WindDir3pm']=label.fit_transform(df.WindDir3pm)
df['WindGustDir']=label.fit_transform(df.WindGustDir)
df['Location']=label.fit_transform(df.Location)
df['Date']=label.fit_transform(df.Date)

# In[None]

from sklearn.model_selection import train_test_split
y_varible = df["RainTomorrow"]
x_varible = df.drop(["RainTomorrow"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/9412851.npy", { "accuracy_score": score })

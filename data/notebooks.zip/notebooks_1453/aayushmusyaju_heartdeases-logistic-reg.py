import numpy as np 
import pandas as pd 
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import preprocessing
from sklearn.metrics import classification_report, accuracy_score
from sklearn.metrics import accuracy_score, confusion_matrix
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
heart = pd.read_csv('/kaggle/input/heart-disease-prediction-using-logistic-regression/framingham.csv')
heart.head()
#sns.heatmap(heart.isnull())
#sns.heatmap(heart.corr(), cmap='coolwarm')
#sns.heatmap(heart[['diabetes', 'glucose']].corr(), )
diab = heart[heart['diabetes'] == 1]['glucose'].mean()
no_diab = heart[heart['diabetes'] == 0]['glucose'].mean()
def fill(cols):
    if pd.isnull(cols[1]):
        if cols[0] == 1:
            return diab
        else:
            return no_diab
    else:
        return cols[1]
            
heart['glucose'] = heart[['diabetes', 'glucose']].apply(fill, axis=1)
#sns.heatmap(heart.isnull())
heart.dropna(axis=0, inplace=True)
#sns.heatmap(heart.isnull())
logmodel= LogisticRegression()
X = heart.drop('TenYearCHD', axis=1)
y = heart['TenYearCHD']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
X_train_scale = preprocessing.scale(X_train)
X_test_scale = preprocessing.scale(X_test)
#logmodel.fit(X_train_scale, y_train)
#predictions = logmodel.predict(X_test_scale)
#coefficient = pd.DataFrame(np.transpose(logmodel.coef_), X_train.columns, columns=['Coefficient'])
print('classification Report:')
#print(classification_report(y_test, predictions))
#print(confusion_matrix(y_test, predictions))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aayushmusyaju_heartdeases-logistic-reg.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aayushmusyaju_heartdeases-logistic-reg/testY.csv",encoding="gbk")


import pandas as pd
# ##  # A# p# p# r# o# a# c# h# i# n# g#  # (# A# l# m# o# s# t# )#  # A# n# y#  # C# h# u# r# n#  # P# r# e# d# i# c# a# t# i# o# n#  # P# r# o# b# l# e# m#  # f# o# r#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # o# n#  # K# a# g# g# l# e# 
# 
# !# [# ]# (# h# t# t# p# s# :# /# /# i# 0# .# w# p# .# c# o# m# /# w# w# w# .# e# v# e# r# y# t# h# i# n# g# a# i# .# c# o# .# i# n# /# w# p# -# c# o# n# t# e# n# t# /# u# p# l# o# a# d# s# /# 2# 0# 1# 8# /# 0# 1# /# C# h# u# r# n# .# p# n# g# ?# r# e# s# i# z# e# =# 9# 0# 0# %# 2# C# 4# 5# 0# &# s# s# l# =# 1# )# 
# 
# I# n#  # t# h# i# s#  # p# o# s# t# ,#  # I# '# l# l#  # t# a# l# k#  # a# b# o# u# t#  # a# p# p# r# o# a# c# h# i# n# g#  # c# h# u# r# n#  # p# r# e# d# i# c# a# t# i# o# n#  # p# r# o# b# l# e# m# s#  # o# n#  # K# a# g# g# l# e# .#  # A# s#  # a# n#  # e# x# a# m# p# l# e# ,#  # w# e#  # w# i# l# l#  # u# s# e#  # t# h# e#  # d# a# t# a#  # f# r# o# m#  # t# h# i# s#  # c# o# m# p# e# t# i# t# i# o# n# .#  # I#  # h# a# v# e#  # c# r# e# a# t# e#  # a#  # v# e# r# y#  # b# a# s# i# c#  # a# l# l#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # m# o# d# e# l#  # f# i# r# s# t#  # a# n# d#  # t# h# e# n#  # i# m# p# r# o# v# e#  # a# l# g# o# r# i# t# h# m#  # p# a# r# a# m# e# t# e# r# .# 
# 
# ## ##  # C# o# v# e# r#  # a# l# l#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # A# l# g# o# r# i# t# h# m# 
# *#  # L# o# g# i# s# t# i# c# R# e# g# r# e# s# s# i# o# n# 
# *#  # X# G# B# C# l# a# s# s# i# f# i# e# r# 
# *#  # M# u# l# t# i# n# o# m# i# a# l# N# B# 
# *#  # A# d# a# B# o# o# s# t# C# l# a# s# s# i# f# i# e# r# 
# *#  # K# N# e# i# g# h# b# o# r# s# C# l# a# s# s# i# f# i# e# r# 
# *#  # G# r# a# d# i# e# n# t# B# o# o# s# t# i# n# g# C# l# a# s# s# i# f# i# e# r# 
# *#  # E# x# t# r# a# T# r# e# e# s# C# l# a# s# s# i# f# i# e# r# 
# *#  # D# e# c# i# s# i# o# n# T# r# e# e# C# l# a# s# s# i# f# i# e# r

# ## ##  # R# o# a# d#  # M# a# p#  # 
# *#  # L# i# b# r# a# r# y#  # f# o# r#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # C# l# e# a# n# i# n# g# 
# *#  # L# o# a# d#  # a# l# l#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # P# a# c# k# a# g# e# s#  # a# n# d#  # A# c# c# u# r# a# c# y#  # P# a# c# k# a# g# e# s# 
# *#  # L# o# a# d#  # D# a# t# a#  # S# e# t# 
# *#  # A# n# a# l# y# s# e#  # t# h# e#  # D# a# t# a#  # 
# *#  # L# a# b# e# l# E# n# c# o# d# e# r# 
# *#  # S# p# l# i# t#  # t# h# e#  # D# a# t# a#  # T# r# a# i# n#  # a# n# d#  # V# a# l# i# d# a# t# i# o# n# 
# *#  # T# r# a# i# n#  # M# o# d# e# l#  # a# n# d#  # C# h# e# c# k#  # V# a# l# i# d# a# t# i# o# n#  # D# a# t# a#  # A# c# c# u# r# a# c# y

# ## ## ##  # L# i# b# r# a# r# y#  # f# o# r#  # P# r# e# p# r# o# c# e# s# s# i# n# g#  # a# n# d#  # C# l# e# a# n# i# n# g

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split

import matplotlib
import matplotlib.pyplot as plt
from IPython.display import display, HTML
import seaborn as sns

# Any results you write to the current directory are saved as output.

# ## ## ##  # L# o# a# d#  # a# l# l#  # C# l# a# s# s# i# f# i# c# a# t# i# o# n#  # P# a# c# k# a# g# e# s#  # a# n# d#  # A# c# c# u# r# a# c# y#  # P# a# c# k# a# g# e# s

# In[None]

import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier,RadiusNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC,SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier,ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier

from sklearn.metrics import accuracy_score,roc_auc_score

# ## ## ##  # T# h# e#  # I# m# p# o# r# t# a# n# c# e#  # o# f#  # P# r# e# d# i# c# t# i# n# g#  # C# u# s# t# o# m# e# r#  # C# h# u# r# n# 
# 
# T# h# e#  # a# b# i# l# i# t# y#  # t# o#  # p# r# e# d# i# c# t#  # t# h# a# t#  # a#  # p# a# r# t# i# c# u# l# a# r#  # c# u# s# t# o# m# e# r#  # i# s#  # a# t#  # a#  # h# i# g# h#  # r# i# s# k#  # o# f#  # c# h# u# r# n# i# n# g# ,#  # w# h# i# l# e#  # t# h# e# r# e#  # i# s#  # s# t# i# l# l#  # t# i# m# e#  # t# o#  # d# o#  # s# o# m# e# t# h# i# n# g#  # a# b# o# u# t#  # i# t# ,#  # r# e# p# r# e# s# e# n# t# s#  # a#  # h# u# g# e#  # a# d# d# i# t# i# o# n# a# l#  # p# o# t# e# n# t# i# a# l#  # r# e# v# e# n# u# e#  # s# o# u# r# c# e#  # f# o# r#  # e# v# e# r# y#  # o# n# l# i# n# e#  # b# u# s# i# n# e# s# s# .#  # B# e# s# i# d# e# s#  # t# h# e#  # d# i# r# e# c# t#  # l# o# s# s#  # o# f#  # r# e# v# e# n# u# e#  # t# h# a# t#  # r# e# s# u# l# t# s#  # f# r# o# m#  # a#  # c# u# s# t# o# m# e# r#  # a# b# a# n# d# o# n# i# n# g#  # t# h# e#  # b# u# s# i# n# e# s# s# ,#  # t# h# e#  # c# o# s# t# s#  # o# f#  # i# n# i# t# i# a# l# l# y#  # a# c# q# u# i# r# i# n# g#  # t# h# a# t#  # c# u# s# t# o# m# e# r#  # m# a# y#  # n# o# t#  # h# a# v# e#  # a# l# r# e# a# d# y#  # b# e# e# n#  # c# o# v# e# r# e# d#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r# ’# s#  # s# p# e# n# d# i# n# g#  # t# o#  # d# a# t# e# .#  # (# I# n#  # o# t# h# e# r#  # w# o# r# d# s# ,#  # a# c# q# u# i# r# i# n# g#  # t# h# a# t#  # c# u# s# t# o# m# e# r#  # m# a# y#  # h# a# v# e#  # a# c# t# u# a# l# l# y#  # b# e# e# n#  # a#  # l# o# s# i# n# g#  # i# n# v# e# s# t# m# e# n# t# .# )#  # F# u# r# t# h# e# r# m# o# r# e# ,#  # i# t#  # i# s#  # a# l# w# a# y# s#  # m# o# r# e#  # d# i# f# f# i# c# u# l# t#  # a# n# d#  # e# x# p# e# n# s# i# v# e#  # t# o#  # a# c# q# u# i# r# e#  # a#  # n# e# w#  # c# u# s# t# o# m# e# r#  # t# h# a# n#  # i# t#  # i# s#  # t# o#  # r# e# t# a# i# n#  # a#  # c# u# r# r# e# n# t#  # p# a# y# i# n# g#  # c# u# s# t# o# m# e# r# .# 
# 
# R# e# f# e# r# e# n# c# e#  # :#  # [# L# i# n# k# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# o# p# t# i# m# o# v# e# .# c# o# m# /# l# e# a# r# n# i# n# g# -# c# e# n# t# e# r# /# c# u# s# t# o# m# e# r# -# c# h# u# r# n# -# p# r# e# d# i# c# t# i# o# n# -# a# n# d# -# p# r# e# v# e# n# t# i# o# n# )

# ## ## ##  # L# o# a# d#  # D# a# t# a#  # s# e# t

# In[None]

df = pd.read_csv('../input/bigml_59c28831336c6604c800002a.csv')
df.head(5)

# ## ## ##  #  # R# e# m# o# v# e#  # C# o# l# u# m# n# ,#  # S# h# a# p# e# ,#  # N# u# l# l#  # V# a# l# u# e#  # a# n# d#  # D# a# t# a#  # T# y# p# e#  # :# -# -# -# -#  # O# v# e# r# _# V# i# e# w

# In[None]

df = df.drop(['phone number'],axis=1)
df.shape

# In[None]

df.isnull().sum()

# In[None]

print("------  Data Types  ----- \n",df.dtypes)
print("------  Data type Count  ----- \n",df.dtypes.value_counts())

# ## ## ##  # L# a# b# e# l#  # E# n# c# o# d# i# n# g#  # f# o# r#  # C# a# t# e# r# g# o# r# i# c# a# l#  # V# a# r# i# a# b# l# e#  

# In[None]

cate = [key for key in dict(df.dtypes) if dict(df.dtypes)[key] in ['bool', 'object']]

# In[None]

le = preprocessing.LabelEncoder()
for i in cate:
    le.fit(df[i])
    df[i] = le.transform(df[i])
    

# ## ## ##  # C# o# r# r# e# l# a# t# i# o# n#  # P# l# o# t

# In[None]

corrmat = df.corr(method='pearson')
f, ax = plt.subplots(figsize=(8, 8))

# Draw the heatmap using seaborn
sns.heatmap(corrmat, vmax=1., square=True)
plt.title("Important variables correlation map", fontsize=15)
plt.show()

# In[None]

y = df['churn']
df = df = df.drop(['churn'],axis=1)

# ## ## ##  # F# e# a# t# u# r# e#  # I# m# p# o# r# t# a# n# t#  # b# y#  # X# G# B# 
# 
# u# s# i# n# g#  # X# G# B# C# l# a# s# s# i# f# i# e# r#  # i#  # h# a# v# e#  # a# c# h# i# v# e#  # g# r# e# a# t#  # a# c# c# u# r# c# y#  # s# o#  # i#  # h# a# v# e#  # t# a# k# e#  # i# n# s# i# g# h# t#  # o# f#  # w# h# i# c# h#  # o# n# e#  # f# e# a# t# u# r# e#  #  

# In[None]

clf = xgb.XGBClassifier(max_depth=7, n_estimators=200, colsample_bytree=0.8, 
                        subsample=0.8, nthread=10, learning_rate=0.1)
clf.fit(df, y)
# plot the important features #
fig, ax = plt.subplots(figsize=(12,18))
xgb.plot_importance(clf, max_num_features=50, height=0.8, ax=ax)
plt.show()

# ## ## ##  # S# p# l# i# t#  # T# r# a# i# n#  # a# n# d#  # V# a# l# i# d# a# t# i# o# n#  # D# a# t# a# s# e# t

# In[None]

from sklearn.model_selection import train_test_split
xtrain, xvalid, ytrain, yvalid = train_test_split(df, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xvalid)
score = accuracy_score(yvalid, y_pred)
import numpy as np
np.save("prenotebook_res/1716477.npy", { "accuracy_score": score })

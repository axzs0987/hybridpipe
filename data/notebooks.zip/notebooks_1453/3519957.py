import pandas as pd
#  # P# R# E# D# I# C# T# I# N# G#  # A#  # P# U# L# S# A# R#  # S# T# A# R

# P# u# l# s# a# r# s#  # a# r# e#  # a#  # r# a# r# e#  # t# y# p# e#  # o# f#  # N# e# u# t# r# o# n#  # s# t# a# r#  # t# h# a# t#  # p# r# o# d# u# c# e#  # r# a# d# i# o#  # e# m# i# s# s# i# o# n#  # d# e# t# e# c# t# a# b# l# e#  # h# e# r# e#  # o# n#  # E# a# r# t# h# .#  # T# h# e# y#  # a# r# e#  # o# f#  # c# o# n# s# i# d# e# r# a# b# l# e#  # s# c# i# e# n# t# i# f# i# c#  # i# n# t# e# r# e# s# t#  # a# s#  # p# r# o# b# e# s#  # o# f#  # s# p# a# c# e# -# t# i# m# e# ,#  # t# h# e#  # i# n# t# e# r# -# s# t# e# l# l# a# r#  # m# e# d# i# u# m# ,#  # a# n# d#  # s# t# a# t# e# s#  # o# f#  # m# a# t# t# e# r#  # .#  #  # N# e# u# t# r# o# n#  # s# t# a# r# s#  # a# r# e#  # v# e# r# y#  # d# e# n# s# e# ,#  # a# n# d#  # h# a# v# e#  # s# h# o# r# t# ,#  # r# e# g# u# l# a# r#  # r# o# t# a# t# i# o# n# a# l#  # p# e# r# i# o# d# s# .#  # T# h# i# s#  # p# r# o# d# u# c# e# s#  # a#  # v# e# r# y#  # p# r# e# c# i# s# e#  # i# n# t# e# r# v# a# l#  # b# e# t# w# e# e# n#  # p# u# l# s# e# s#  # t# h# a# t#  # r# a# n# g# e# s#  # f# r# o# m#  # m# i# l# l# i# s# e# c# o# n# d# s#  # t# o#  # s# e# c# o# n# d# s#  # f# o# r#  # a# n#  # i# n# d# i# v# i# d# u# a# l#  # p# u# l# s# a# r# .#  # P# u# l# s# a# r# s#  # a# r# e#  # b# e# l# i# e# v# e# d#  # t# o#  # b# e#  # o# n# e#  # o# f#  # t# h# e#  # c# a# n# d# i# d# a# t# e# s#  # f# o# r#  # t# h# e#  # s# o# u# r# c# e#  # o# f#  # u# l# t# r# a# -# h# i# g# h# -# e# n# e# r# g# y#  # c# o# s# m# i# c#  # r# a# y# s# .

# !# [# ]# (# h# t# t# p# s# :# /# /# u# s# e# r# c# o# n# t# e# n# t# 2# .# h# u# b# s# t# a# t# i# c# .# c# o# m# /# 1# 4# 2# 7# 7# 7# 2# 5# _# f# 5# 2# 0# .# j# p# g# )

# T# h# e#  # f# i# r# s# t#  # p# u# l# s# a# r#  # w# a# s#  # o# b# s# e# r# v# e# d#  # o# n#  # N# o# v# e# m# b# e# r#  # 2# 8# ,#  # 1# 9# 6# 7# ,#  # b# y#  # J# o# c# e# l# y# n#  # B# e# l# l#  # B# u# r# n# e# l# l#  # a# n# d#  # A# n# t# o# n# y#  # H# e# w# i# s# h# .#  # T# h# e# y#  # o# b# s# e# r# v# e# d#  # p# u# l# s# e# s#  # s# e# p# a# r# a# t# e# d#  # b# y#  # 1# .# 3# 3#  # s# e# c# o# n# d# s#  # t# h# a# t#  # o# r# i# g# i# n# a# t# e# d#  # f# r# o# m#  # t# h# e#  # s# a# m# e#  # l# o# c# a# t# i# o# n#  # i# n#  # t# h# e#  # s# k# y# ,#  # a# n# d#  # k# e# p# t#  # t# o#  # s# i# d# e# r# e# a# l#  # t# i# m# e# .#  # I# n#  # l# o# o# k# i# n# g#  # f# o# r#  # e# x# p# l# a# n# a# t# i# o# n# s#  # f# o# r#  # t# h# e#  # p# u# l# s# e# s# ,#  # t# h# e#  # s# h# o# r# t#  # p# e# r# i# o# d#  # o# f#  # t# h# e#  # p# u# l# s# e# s#  # e# l# i# m# i# n# a# t# e# d#  # m# o# s# t#  # a# s# t# r# o# p# h# y# s# i# c# a# l#  # s# o# u# r# c# e# s#  # o# f#  # r# a# d# i# a# t# i# o# n# ,#  # s# u# c# h#  # a# s#  # s# t# a# r# s# ,#  # a# n# d#  # s# i# n# c# e#  # t# h# e#  # p# u# l# s# e# s#  # f# o# l# l# o# w# e# d#  # s# i# d# e# r# e# a# l#  # t# i# m# e# ,#  # i# t#  # c# o# u# l# d#  # n# o# t#  # b# e#  # m# a# n# -# m# a# d# e#  # r# a# d# i# o#  # f# r# e# q# u# e# n# c# y#  # i# n# t# e# r# f# e# r# e# n# c# e# .# (# s# o# u# r# c# e# =# W# i# k# i# p# e# d# i# a# )

# I# n#  # t# h# i# s#  # k# e# r# n# e# l# ,#  # I#  # w# i# l# l#  # e# x# p# l# a# i# n#  # w# h# e# t# h# e# r#  # a#  # s# t# a# r#  # i# s#  # a#  # p# u# l# s# a# r#  # s# t# a# r#  # w# i# t# h#  # s# u# p# e# r# v# i# s# e# d#  # l# e# a# r# n# i# n# g#  # m# a# c# h# i# n# e#  # l# e# a# r# n# i# n# g#  # a# l# g# o# r# i# t# h# m# s# .

# ## ## ##  # *# *# C# O# N# T# E# N# T#  # :# *# *# 
# 
# 1# .#  # [# D# A# T# A#  # A# N# A# L# Y# S# I# S# ]# (# ## 1# )# 
# 2# .#  # [# L# O# G# I# S# T# I# C#  # R# E# G# R# E# S# S# I# O# N# ]# (# ## 2# )# 
# 3# .#  # [# K# -# N# E# A# R# E# S# T#  # N# E# I# G# H# B# O# U# R# (# K# N# N# )#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N# ]# (# ## 3# )#  # 
# 4# .#  # [# S# U# P# P# O# R# T#  # V# E# C# T# O# R#  # M# A# C# H# I# N# E# (# S# V# M# )#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N# ]# (# ## 4# )# 
# 5# .#  # [# N# A# I# V# E#  # B# A# Y# E# S#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N# ]# (# ## 5# )# 
# 6# .#  # [# D# E# C# I# S# I# O# N#  # T# R# E# E#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N# ]# (# ## 6# )# 
# 7# .#  # [# R# A# N# D# O# M#  # F# O# R# E# S# T#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N# ]# (# ## 7# )# 
# 8# .#  # [# E# V# A# L# U# A# T# I# N# G#  # A#  # C# L# A# S# S# I# F# I# C# A# T# I# O# N#  # M# O# D# E# L# ]# (# ## 8# )

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
import warnings
warnings.filterwarnings("ignore")
import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# <# a#  # i# d# =# "# 1# "# ># <# /# a# >#  # <# b# r# ># 
# D# A# T# A#  # A# N# A# L# Y# S# I# S#  

# In[None]

data=pd.read_csv("../input/pulsar_stars.csv")

# In[None]

data.info()

# W# e#  # h# a# v# e#  # 9#  # f# e# a# t# u# r# e# s#  # a# n# d#  # l# o# o# k# s#  # l# i# k# e#  # t# h# e# r# e#  # a# r# e#  # n# o#  # n# a# n#  # v# a# l# u# e# s# .#  # H# o# w# e# v# e# r#  # f# e# a# t# u# r# e# s#  # n# a# m# e# s#  # a# r# e#  # a#  # l# i# t# t# l# e#  # b# i# t#  # u# n# t# i# d# y# .#  # I#  # w# i# l# l#  # c# h# a# n# g# e#  # t# h# e# m# .

# In[None]

data = data.rename(columns={' Mean of the integrated profile':"mean_integrated_profile",
       ' Standard deviation of the integrated profile':"std_deviation_integrated_profile",
       ' Excess kurtosis of the integrated profile':"kurtosis_integrated_profile",
       ' Skewness of the integrated profile':"skewness_integrated_profile", 
        ' Mean of the DM-SNR curve':"mean_dm_snr_curve",
       ' Standard deviation of the DM-SNR curve':"std_deviation_dm_snr_curve",
       ' Excess kurtosis of the DM-SNR curve':"kurtosis_dm_snr_curve",
       ' Skewness of the DM-SNR curve':"skewness_dm_snr_curve",
       })

# N# o# w#  # L# e# t# '# s#  # l# o# o# k#  # a# t#  # t# h# e#  # 5#  # e# n# t# r# i# e# s#  # a# t#  # t# h# e#  # t# o# p#  # o# f#  # t# h# e#  # d# a# t# a#  # s# e# t

# In[None]

data.head()

# F# o# l# l# o# w# i# n# g#  # h# e# a# t# m# a# p#  # s# h# o# w# s#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # f# e# a# t# u# r# e# s# .#  # 
# 
# T# h# e# r# e#  # i# s#  # a#  # h# i# g# h#  # p# o# s# i# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # f# o# l# l# o# w# i# n# g#  # f# e# a# t# u# r# e# s# :# 
# -#  # E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # -#  # S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # (# 0# .# 9# 5# )# 
# -#  # M# e# a# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # -#  # S# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e# (# 0# .# 8# 0# )# 
# -#  # E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # -#  # S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # (# 0# .# 9# 2# )# 
# 
# 
# T# h# e# r# e#  # i# s#  # a#  # h# i# g# h#  # n# e# g# a# t# i# v# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # f# o# l# l# o# w# i# n# g#  # f# e# a# t# u# r# e# s# :# 
# -#  # M# e# a# n#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # -#  # E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # (# -# 0# .# 8# 7# )# 
# -#  # M# e# a# n#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # -#  # S# k# e# w# n# e# s# s#  # o# f#  # t# h# e#  # i# n# t# e# g# r# a# t# e# d#  # p# r# o# f# i# l# e#  # (# -# 0# .# 7# 4# )# 
# -#  # S# t# a# n# d# a# r# d#  # d# e# v# i# a# t# i# o# n#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # -#  # E# x# c# e# s# s#  # k# u# r# t# o# s# i# s#  # o# f#  # t# h# e#  # D# M# -# S# N# R#  # c# u# r# v# e#  # (# -# 0# .# 8# 1# )

# In[None]

# f,ax=plt.subplots(figsize=(15,15))
# sns.heatmap(data.corr(),annot=True,linecolor="blue",fmt=".2f",ax=ax)
# plt.show()

# A# n# d#  # f# o# l# l# o# w# i# n# g#  # p# a# i# r# p# l# o# t# s#  # s# h# o# w#  # c# o# r# r# e# l# a# t# i# o# n# s#  # b# e# t# w# e# e# n#  # f# e# a# t# u# r# e# s#  # w# i# t# h#  # c# l# a# s# s# e# s

# In[None]

# g = sns.pairplot(data, hue="target_class",palette="husl",diag_kind = "kde",kind = "scatter")

# In[None]

y = data["target_class"].values
x_data = data.drop(["target_class"],axis=1)
x = (x_data - np.min(x_data))/(np.max(x_data)-np.min(x_data))

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3519957.npy", { "accuracy_score": score })

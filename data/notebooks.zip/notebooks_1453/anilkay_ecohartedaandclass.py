import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("/kaggle/input/echocardiogram-uci/echocardiogram.csv")
data.head()
del data["name"]
del data["group"]
data.dtypes
from fancyimpute import KNN
deyta=KNN(k=2).fit_transform(data)
deyta.shape
deyta=pd.DataFrame(deyta)
deyta.columns=data.columns
deyta.head()
deyta.isnull().sum()
import seaborn as sns
import matplotlib.pyplot as plt
correlation=deyta.corr()
#plt.figure(figsize=(16, 16))
#sns.heatmap(correlation,annot=True)
y=deyta["alive"]
x=deyta.loc[:,(deyta.columns!="alive") & (data.columns!="aliveat1")]
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()    
from sklearn.model_selection import cross_val_score
print(cross_val_score(rfc,x, y, cv=4))
from sklearn.tree import DecisionTreeClassifier
print(cross_val_score(DecisionTreeClassifier(),x, y, cv=4))
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from tpot import TPOTClassifier
tpot = TPOTClassifier(verbosity=2,max_time_mins=40)
#tpot.fit(X_train, y_train)
#print(tpot.score(X_test, y_test))
#tpot.export("classifierpipeline.py")
#ypred=tpot.predict(X_test)
import sklearn.metrics as metrik
#print(metrik.accuracy_score(y_pred=ypred,y_true=y_test))
#print(metrik.confusion_matrix(y_pred=ypred,y_true=y_test))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
print("start running model training........")
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_ecohartedaandclass.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_ecohartedaandclass/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/anilkay_ecohartedaandclass/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/anilkay_ecohartedaandclass/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_ecohartedaandclass/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/anilkay_ecohartedaandclass/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/anilkay_ecohartedaandclass/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_ecohartedaandclass/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_ecohartedaandclass/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_ecohartedaandclass/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_ecohartedaandclass/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_ecohartedaandclass/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_ecohartedaandclass/testY.csv",encoding="gbk")


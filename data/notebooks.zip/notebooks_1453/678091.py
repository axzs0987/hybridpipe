import pandas as pd
# W# e# l# c# o# m# e# ,#  # a# n# d#  # t# h# a# n# k#  # y# o# u#  # f# o# r#  # o# p# e# n# i# n# g#  # t# h# i# s#  # N# o# t# e# b# o# o# k# .# 
# T# h# i# s#  # N# o# t# e# b# o# o# k#  # w# i# l# l#  # p# r# o# v# i# d# e#  # k# n# o# w# l# e# d# g# e#  # t# o#  # n# o# v# i# c# e#  # D# a# t# a#  # S# c# i# e# n# t# i# s# t# s#  # w# i# t# h#  # b# a# s# i# c#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # c# o# n# c# e# p# t# s#  # l# i# k# e#  # -#  # 
# 1# .#  # D# a# t# a#  # E# x# p# l# o# r# a# t# o# r# y#  # A# n# a# n# l# y# s# i# s# 
# 2# .#  # P# r# i# n# c# i# p# l# e#  # C# o# m# p# o# n# e# n# t#  # A# n# a# l# y# s# i# s# 
# 3# .#  # P# r# e# d# i# c# t# i# o# n#  # a# n# d#  # M# o# d# e# l#  # s# e# l# e# c# t# i# o# n

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[1]

import pandas as pd
import numpy as np
import sklearn
import seaborn as sns
import matplotlib.pyplot as plt


# In[2]

data = pd.read_csv("../input/winequality-red.csv")

# In[3]

data.head()

# C# h# e# c# k#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # f# o# r#  # e# a# c# h#  # o# f#  # t# h# e#  # f# i# e# l# d# s

# In[5]

data.corr

# In[6]

data.columns

# In[7]

data.info()

# In[8]

data['quality'].unique()

# In[10]

#Check correleation between the variables using Seaborn's pairplot. 
sns.pairplot(data)

# N# o#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # f# i# e# l# d# s#  # a# s#  # s# e# e# n#  # o# n#  # t# h# e#  # p# a# i# r# p# l# o# t

# In[11]

#count of each target variable
from collections import Counter
Counter(data['quality'])

# In[12]

#count of the target variable
sns.countplot(x='quality', data=data)

# In[13]

#Plot a boxplot to check for Outliers
#Target variable is Quality. So will plot a boxplot each column against target variable
sns.boxplot('quality', 'fixed acidity', data = data)

# In[14]

sns.boxplot('quality', 'volatile acidity', data = data)

# In[15]

sns.boxplot('quality', 'citric acid', data = data)

# In[16]

sns.boxplot('quality', 'residual sugar', data = data)

# In[17]

sns.boxplot('quality', 'chlorides', data = data)

# In[18]

sns.boxplot('quality', 'free sulfur dioxide', data = data)

# In[19]

sns.boxplot('quality', 'total sulfur dioxide', data = data)

# In[20]

sns.boxplot('quality', 'density', data = data)

# In[21]

sns.boxplot('quality', 'pH', data = data)

# In[22]

sns.boxplot('quality', 'sulphates', data = data)

# In[23]

sns.boxplot('quality', 'alcohol', data = data)

# In[24]

#boxplots show many outliers for quite a few columns. Describe the dataset to get a better idea on what's happening
data.describe()
#fixed acidity - 25% - 7.1 and 50% - 7.9. Not much of a variance. Could explain the huge number of outliers
#volatile acididty - similar reasoning
#citric acid - seems to be somewhat uniformly distributed
#residual sugar - min - 0.9, max - 15!! Waaaaay too much difference. Could explain the outliers.
#chlorides - same as residual sugar. Min - 0.012, max - 0.611
#free sulfur dioxide, total suflur dioxide - same explanation as above

# In[25]

#next we shall create a new column called Review. This column will contain the values of 1,2, and 3. 
#1 - Bad
#2 - Average
#3 - Excellent
#This will be split in the following way. 
#1,2,3 --> Bad
#4,5,6,7 --> Average
#8,9,10 --> Excellent
#Create an empty list called Reviews
reviews = []
for i in data['quality']:
    if i >= 1 and i <= 3:
        reviews.append('1')
    elif i >= 4 and i <= 7:
        reviews.append('2')
    elif i >= 8 and i <= 10:
        reviews.append('3')
data['Reviews'] = reviews

# In[26]

#view final data
data.columns

# In[27]

data['Reviews'].unique()

# In[28]

Counter(data['Reviews'])

# S# p# l# i# t#  # t# h# e#  # x#  # a# n# d#  # y#  # v# a# r# i# a# b# l# e# s# 


# In[29]

x = data.iloc[:,:11]
y = data['Reviews']

# In[30]

x.head(10)

# In[31]

y.head(10)

# N# o# w#  # s# c# a# l# e#  # t# h# e#  # d# a# t# a#  # u# s# i# n# g#  # S# t# a# n# d# a# r# d# S# c# a# l# a# r#  # f# o# r#  # P# C# A

# In[32]

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
x = sc.fit_transform(x)


# In[33]

#view the scaled features
print(x)

# P# r# o# c# e# e# d#  # t# o#  # p# e# r# f# o# r# m#  # P# C# A# 


# In[34]

from sklearn.decomposition import PCA
pca = PCA()
x_pca = pca.fit_transform(x)

# In[35]

#plot the graph to find the principal components
plt.figure(figsize=(10,10))
plt.plot(np.cumsum(pca.explained_variance_ratio_), 'ro-')
plt.grid()

# In[36]

#AS per the graph, we can see that 8 principal components attribute for 90% of variation in the data. 
#we shall pick the first 8 components for our prediction.
pca_new = PCA(n_components=8)
x_new = pca_new.fit_transform(x)

# In[37]

print(x_new)

# S# p# l# i# t#  # t# h# e#  # d# a# t# a#  # i# n# t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # d# a# t# a

# In[38]

from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_new, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/678091.npy", { "accuracy_score": score })

import pandas as pd
# ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# T# h# i# s#  # p# r# o# j# e# c# t#  # w# a# s#  # d# o# n# e#  # p# u# r# e# l# y#  # w# i# t# h#  # e# d# u# c# a# t# i# o# n# a# l#  # p# u# r# p# o# s# e# s# .#  # I#  # w# a# n# t# e# d#  # t# o#  # t# r# y#  # a# n# d#  # i# m# p# l# e# m# e# n# t#  # s# e# v# e# r# a# l#  # c# l# a# s# s# i# f# y# i# n# g#  # a# l# g# o# r# i# t# h# m# s#  # w# i# t# h#  # p# a# r# a# m# e# t# e# r#  # t# w# e# a# k# i# n# g#  # o# n#  # a#  # d# a# t# a# s# e# t#  # t# h# a# t#  # s# e# e# m# e# d#  # v# e# r# y#  # i# n# t# e# r# e# s# t# i# n# g#  # t# o#  # m# e# .#  # W# h# e# n#  # l# o# o# k# i# n# g#  # a# t#  # t# h# e#  # d# a# t# a# s# e# t# ,#  # o# n# e#  # o# f#  # t# h# e#  # s# u# g# g# e# s# t# i# o# n# s#  # t# h# a# t#  # t# h# e#  # p# u# b# l# i# s# h# e# r#  # h# a# d#  # w# a# s#  # t# r# y# i# n# g#  # t# o#  # p# r# e# d# i# c# t#  # t# h# e#  # a# t# t# i# t# u# d# e# s#  # t# o# w# a# r# d# s#  # m# e# n# t# a# l#  # h# e# a# l# t# h#  # w# i# t# h# i# n#  # a#  # w# o# r# k# p# l# a# c# e# ,#  # a# n# d#  # t# h# a# t#  # i# s#  # w# h# a# t#  # I#  # d# e# c# i# d# e# d#  # t# o#  # l# o# o# k#  # i# n# t# o# .#  # T# h# e#  # s# u# r# v# e# y#  # d# i# d#  # n# o# t#  # h# a# v# e#  # a# n#  # e# x# p# l# i# c# i# t#  # q# u# e# s# t# i# o# n#  # a# b# o# u# t#  # t# h# e#  # a# t# t# i# t# u# d# e# s# ,#  # t# h# a# t#  # i# s#  # w# h# y#  # I#  # d# e# c# i# d# e# d#  # t# o#  # t# r# e# a# t#  # t# h# e#  # q# u# e# s# t# i# o# n#  # "# D# o#  # y# o# u#  # t# h# i# n# k#  # t# h# a# t#  # d# i# s# c# u# s# s# i# n# g#  # a#  # m# e# n# t# a# l#  # h# e# a# l# t# h#  # i# s# s# u# e#  # w# i# t# h#  # y# o# u# r#  # e# m# p# l# o# y# e# r#  # w# o# u# l# d#  # h# a# v# e#  # n# e# g# a# t# i# v# e#  # c# o# n# s# e# q# u# e# n# c# e# s# ?# "#  # a# s#  # "# I# s#  # t# h# e#  # a# t# t# i# t# u# d# e#  # w# i# t# h# i# n#  # y# o# u# r#  # w# o# r# k# p# l# a# c# e#  # n# e# g# a# t# i# v# e# ?# "#  # 
# 
# I#  # d# e# c# i# d# e# d#  # t# h# a# t#  # I#  # w# o# u# l# d#  # i# m# p# l# e# m# e# n# t#  # t# h# e#  # a# l# g# o# r# i# t# h# m# s#  # i# n#  # a#  # b# i# n# a# r# y#  # s# e# t# t# i# n# g#  # w# h# e# r# e#  # I#  # g# o# t#  # r# i# d#  # o# f#  # '# M# a# y# b# e# '#  # i# n#  # t# h# e#  # a# n# s# w# e# r# s#  # t# o#  # t# h# e#  # q# u# e# s# t# i# o# n#  # a# n# d#  # t# h# e# n#  # a# d# d#  # i# t#  # b# a# c# k#  # i# n#  # f# o# r#  # a#  # m# u# l# t# i# c# l# a# s# s#  # s# e# t# t# i# n# g# .# 
# 
# O# v# e# r# a# l# l# ,#  # t# h# i# s#  # w# a# s#  # a#  # g# r# e# a# t#  # l# e# a# r# n# i# n# g#  # e# x# p# e# r# i# e# n# c# e# .#  # T# h# e#  # b# e# s# t#  # a# c# c# u# r# a# c# y#  # r# a# t# e#  # f# r# o# m#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# e# r# s#  # w# a# s#  # a# r# o# u# n# d#  # 9# 0# %#  # a# n# d#  # f# r# o# m#  # m# u# l# t# i# c# l# a# s# s#  # c# l# a# s# s# i# f# i# e# r# s#  # w# a# s#  # a# r# o# u# n# d#  # 6# 3# %# .#  # I# n# i# t# i# a# l# l# y# ,#  # I#  # w# a# s#  # a# s# s# u# m# i# n# g#  # t# h# a# t#  # w# h# e# n#  # a# d# d# i# n# g#  # b# a# c# k#  # '# M# a# y# b# e# ,# '#  # I#  # w# o# u# l# d#  # g# e# t#  # a# n#  # a# c# c# u# r# a# c# y#  # r# a# t# e#  # o# f#  # 5# 0# %# .#  # I#  # w# a# s#  # s# u# r# p# r# i# s# e# d#  # t# o#  # s# e# e#  # t# h# a# t#  # I#  # c# o# u# l# d#  # p# u# s# h#  # i# t#  # t# i# l# l#  # 6# 0# %# .#  # 
# 
# O# n# e#  # o# f#  # t# h# e#  # i# m# p# l# i# c# a# t# i# o# n# s#  # o# f#  # t# h# i# s#  # m# o# d# e# l#  # i# s#  # s# e# e# i# n# g#  # t# h# a# t#  # t# a# l# k# i# n# g#  # w# i# t# h#  # s# u# p# e# r# v# i# s# o# r# s#  # a# n# d#  # c# o# w# o# r# k# e# r# s#  # a# b# o# u# t#  # m# e# n# t# a# l#  # h# e# a# l# t# h#  # i# s#  # r# e# a# l# l# y#  # i# m# p# o# r# t# a# n# t# .#  # E# v# e# n#  # t# h# e# n# ,#  # i# t#  # i# s#  # i# m# p# o# r# t# a# n# t#  # t# o#  # r# e# c# o# g# n# i# z# e#  # t# h# a# t# ,#  # e# s# s# e# n# t# i# a# l# l# y# ,#  # s# u# p# e# r# v# i# s# o# r# s#  # a# r# e#  # t# h# e#  # o# n# e# s#  # w# h# o#  # s# e# t#  # t# h# e#  # e# n# v# i# r# o# n# m# e# n# t# .#  

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import LabelEncoder
from collections import defaultdict

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.multiclass import OneVsRestClassifier, OneVsOneClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, chi2

data = pd.read_csv('/kaggle/input/mental-health-in-tech-survey/survey.csv')
data.head()

# ## ##  # I# n# i# t# i# a# l#  # D# a# t# a#  # C# l# e# a# n# i# n# g

# I#  # d# e# c# i# d# e# d#  # t# o#  # g# e# t#  # r# i# d#  # o# f#  # c# o# u# n# t# r# i# e# s#  # w# i# t# h#  # v# a# l# u# e# s#  # l# e# s# s#  # t# h# a# n#  # 1# 0# ,#  # s# i# n# c# e#  # i# t#  # s# e# e# m# e# d#  # t# h# a# t#  # h# a# v# i# n# g#  # t# h# o# s# e#  # c# o# u# n# t# r# i# e# s#  # w# o# u# l# d#  # h# a# v# e#  # a#  # s# i# g# n# i# f# i# c# a# n# t#  # i# m# p# a# c# t#  # o# n#  # t# h# e#  # m# o# d# e# l# s# .

# In[None]

data = data.drop(columns=['self_employed'])
data = data[data.Country.map(data.Country.value_counts()) >= 10]

# I#  # c# r# e# a# t# e# d#  # t# w# o#  # v# e# r# s# i# o# n# s#  # o# f#  # X#  # a# n# d#  # y# ,#  # w# h# e# r# e#  # X# 2#  # a# n# d#  # y# 2#  # a# r# e#  # t# h# e#  # d# a# t# a#  # f# o# r#  # a#  # b# i# n# a# r# y#  # c# l# a# s# s# i# f# i# e# r# .# 
# 
# I#  # a# l# s# o#  # g# o# t#  # r# i# d#  # o# f#  # c# o# l# u# m# n# s#  # t# h# a# t#  # I#  # t# h# o# u# g# h# t#  # w# e# r# e#  # u# n# n# e# c# e# s# s# a# r# y#  # t# o#  # t# h# e#  # m# o# d# e# l# .

# In[None]

data2 = data[data.mental_health_consequence != 'Maybe']

y = data.mental_health_consequence
y2 = data2.mental_health_consequence

data = data.drop(columns=['mental_health_consequence', 'Timestamp', 'state','comments', 'Age', 'Gender'])
data2 = data2.drop(columns=['mental_health_consequence', 'Timestamp', 'state','comments', 'Age', 'Gender'])

X = data
X2 = data2

# ## ##  # S# o# m# e#  # E# D# A

# In[None]

f,ax = plt.subplots(3,2,figsize=(10,10))

X2.Country.value_counts().plot(kind='bar', ax=ax[0,0])
ax[0,0].set_title('Frequency of Countries')

y.value_counts().plot(kind='bar', ax=ax[0,1])
ax[0,1].set_title('Do you think that discussing a mental health issue \n with your employer would have negative consequences?')

X2.supervisor.value_counts().plot(kind='bar', ax=ax[1,0])
ax[1,0].set_title('Would you be willing to discuss a mental health issue \n with your direct supervisor(s)?')

X2.coworkers.value_counts().plot(kind='bar', ax=ax[1,1])
ax[1,1].set_title('Would you be willing to discuss a mental health issue \n with your coworkers?')

X2.obs_consequence.value_counts().plot(kind='bar', ax=ax[2,0])
ax[2,0].set_title('Have you heard of or observed negative consequences for coworkers \n with mental health conditions in your workplace?')
ax[2,0].title.set_size(10)

X2.anonymity.value_counts().plot(kind='bar', ax=ax[2,1])
ax[2,1].set_title('Is your anonymity protected if you choose to take advantage of \n mental health or substance abuse treatment resources?')
ax[2,1].title.set_size(10)

f.tight_layout()

# ## ##  # M# o# r# e#  # D# a# t# a#  # C# l# e# a# n# i# n# g

# In[None]

dict1 = {'No':0,
            'Maybe':1,
             'Yes':2
            }
y = y.map(dict1)

dict2 = {'No':0,
            'Yes':1,
            }
y2 = y2.map(dict2)

X.work_interfere = X.work_interfere.fillna('Never')
encoder_dict = defaultdict(LabelEncoder)
X = X.apply(lambda a: encoder_dict[a.name].fit_transform(a))
X2 = X2.apply(lambda a: encoder_dict[a.name].fit_transform(a.astype(str)))

# ##  # M# o# d# e# l# i# n# g# 
# ## ##  # B# i# n# a# r# y#  # V# e# r# s# i# o# n# 
# I#  # f# o# u# n# d#  # t# h# i# s#  # c# o# d# e#  # (# [# h# e# r# e# ]# (# h# t# t# p# s# :# /# /# t# o# w# a# r# d# s# d# a# t# a# s# c# i# e# n# c# e# .# c# o# m# /# f# e# a# t# u# r# e# -# s# e# l# e# c# t# i# o# n# -# t# e# c# h# n# i# q# u# e# s# -# i# n# -# m# a# c# h# i# n# e# -# l# e# a# r# n# i# n# g# -# w# i# t# h# -# p# y# t# h# o# n# -# f# 2# 4# e# 7# d# a# 3# f# 3# 6# e# )# )#  # w# h# e# n#  # l# o# o# k# i# n# g#  # f# o# r#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # a# n# d#  # d# e# c# i# d# e# d#  # t# o#  # u# s# e#  # i# t# .#  # T# h# i# s#  # s# h# o# w# s#  # a# l# l#  # t# h# e#  # f# e# a# t# u# r# e# s#  # f# r# o# m#  # t# h# e#  # m# o# s# t#  # i# m# p# a# c# t# f# u# l#  # t# o#  # l# e# a# s# t# .#  # I#  # t# h# e# n#  # d# e# c# i# d# e# d#  # t# o#  # g# e# t#  # r# i# d#  # o# f#  # f# e# a# t# u# r# e# s#  # w# i# t# h#  # a#  # s# c# o# r# e#  # l# e# s# s#  # t# h# a# n#  # 1# 0# .

# In[None]

#apply SelectKBest class to extract top 10 best features
bestfeatures = SelectKBest(score_func=chi2, k=20)
fit = bestfeatures.fit(X2,y2)
dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(X.columns)
#concat two dataframes for better visualization 
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
featureScores.columns = ['Feature','Score']  #naming the dataframe columns
print(featureScores.nlargest(20,'Score'))  #print 20 best features

# In[None]

X2 = X2.drop(columns=featureScores.Feature[featureScores.Score < 10].values)

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X2, y2, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7217186.npy", { "accuracy_score": score })

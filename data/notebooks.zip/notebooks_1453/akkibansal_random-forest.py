import numpy as np 
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import os
#print(os.listdir("../input"))
data = pd.read_csv("../input/heart.csv")
'''Exploratory Data Analysis'''
data.head()
data.tail()
data.info() 
data.describe()
#fig, ax = plt.subplots(figsize=(10,10)) 
#sns.set(font_scale=1.25)
#hm = sns.heatmap(data.corr(), cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10})
#plt.show()
'''Machine Learning'''
y=data.iloc[:,-1]
data=data.iloc[:,:-1]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(data, y, train_size=0.8, test_size=1-0.8, random_state=0)
RF = RandomForestClassifier()
#RF.fit(X_train,y_train)
#y_pred = RF.predict(X_test)
#print(accuracy_score(y_test, y_pred))
#print(confusion_matrix(y_test, y_pred))




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/akkibansal_random-forest.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/akkibansal_random-forest/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/akkibansal_random-forest/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/akkibansal_random-forest/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/akkibansal_random-forest/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/akkibansal_random-forest/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/akkibansal_random-forest/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/akkibansal_random-forest/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/akkibansal_random-forest/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/akkibansal_random-forest/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/akkibansal_random-forest/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/akkibansal_random-forest/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/akkibansal_random-forest/testY.csv",encoding="gbk")


import pandas as pd
# *# *# P# r# e# d# i# c# i# t# i# n# g#  # P# u# l# s# a# r# s#  # w# i# t# h#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e# s# *# *

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, classification_report

# In[None]

df = pd.read_csv('../input/pulsar_stars.csv')
df.head()

# In[None]

df.shape

# In[None]

df.describe()

# W# e#  # n# e# e# d#  # t# o#  # m# a# k# e#  # s# u# r# e#  # t# h# e# r# e#  # a# r# e# n# '# t#  # a# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# .

# In[None]

df.isnull().sum()

# I#  # w# a# n# t#  # t# o#  # s# h# o# r# t# e# n#  # a# n# d#  # m# o# d# i# f# y#  # t# h# e#  # c# o# l# u# m# n#  # n# a# m# e# s# .

# In[None]

cols = ['mean_profile', 'std_profile', 'Excess_kurtosis_profile', 'skew_profile', 'mean_dmsnr', 'std_dmsnr', 'excess_kurtosis_dmsnr', 'skew_dmsnr', 'target_class']
print(len(cols))

# In[None]

data = np.array(df)
df = pd.DataFrame(data, columns = cols)
df.head()

# In[None]

df.shape

# L# e# t# '# s#  # g# e# t#  # a# n#  # i# d# e# a#  # o# f#  # h# o# w#  # m# a# n# y#  # p# u# l# s# a# r# s#  # a# n# d#  # n# o# n# -# p# u# l# s# a# r# s#  # w# e#  # h# a# v# e#  # u# s# i# n# g#  # a#  # h# i# s# t# o# g# r# a# m

# In[None]

targets = np.array(df["target_class"])
sns.distplot(targets, kde = False, color = "r", axlabel = "Target Class").set_title("Pulsar (1) vs Non-Pulsar (0) Count")


# N# o# n# -# P# u# l# s# a# r# s#  # a# r# e#  # w# a# y#  # o# v# e# r# r# e# p# r# e# s# e# n# t# e# d# ,#  # w# h# i# c# h#  # i# s#  # t# o#  # b# e#  # e# x# p# e# c# t# e# d# .#  # H# o# p# e# f# u# l# l# y#  # t# h# i# s#  # d# o# e# s# n# '# t#  # l# e# a# d#  # t# o#  # a# c# c# u# r# a# c# y#  # p# r# o# b# l# e# m# s# .#  # L# e# t# '# s#  # p# l# o# t#  # t# h# e#  # o# t# h# e# r#  # 8#  # f# e# a# t# u# r# e#  # d# i# s# t# r# i# b# u# t# i# o# n# s# ,#  # s# e# p# a# r# a# t# e# d#  # b# y#  # t# a# r# g# e# t#  # c# l# a# s# s# .#  # W# e#  # f# i# r# s# t#  # w# i# l# l#  # c# r# e# a# t# e#  # a#  # d# a# t# a# f# r# a# m# e#  # f# o# r#  # e# a# c# h#  # t# a# r# g# e# t#  # c# l# a# s# s#  # a# n# d#  # t# h# e# n#  # p# l# o# t#  # t# h# e#  # d# i# s# t# i# b# u# t# i# o# n# s#  # f# o# r#  # e# a# c# h#  # f# e# a# t# u# r# e# .

# In[None]

star_data = []
notstar_data =[]

for i in range(df["target_class"].count()):
    if df["target_class"][i] == 1:
        star_data.append(df.loc[i])
    else:
        notstar_data.append(df.loc[i])
    

# In[None]

len(star_data) + len(notstar_data)

# In[None]

dfstar = pd.DataFrame(star_data, columns = cols )
dfnotstar = pd.DataFrame(notstar_data, columns = cols)

# In[None]

dfstar.head()

# In[None]

dfstar = dfstar.reset_index(drop = True)
dfnotstar = dfnotstar.reset_index(drop = True)

# In[None]

dfstar.head()

# In[None]

dfnotstar.head()

# In[None]

dfnotstar.describe()

# In[None]

dfstar.describe()

# In[None]

mean_star_profile = np.array(dfstar["mean_profile"])
mean_notstar_profile = np.array(dfnotstar["mean_profile"])
sns.distplot(mean_star_profile, color = "b", label = "Pulsar", axlabel = "Mean").set_title("Means of Integrated Profiles")
sns.distplot(mean_notstar_profile, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

std_star_profile = np.array(dfstar["std_profile"])
std_notstar_profile = np.array(dfnotstar["std_profile"])
sns.distplot(std_star_profile, color = "b", label = "Pulsar", axlabel = "Standard Deviation").set_title("Standard Deviations of Integrated Profiles")
sns.distplot(std_notstar_profile, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

exkurt_star_profile = np.array(dfstar["Excess_kurtosis_profile"])
exkurt_notstar_profile = np.array(dfnotstar["Excess_kurtosis_profile"])
sns.distplot(exkurt_star_profile, color = "b", axlabel = "Excess Kurtosis", label = "Pulsar").set_title("Excess Kurtosis for Integrated Profiles")
sns.distplot(exkurt_notstar_profile, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

skew_star_profile = np.array(dfstar["skew_profile"])
skew_notstar_profile = np.array(dfnotstar["skew_profile"])
sns.distplot(skew_star_profile, color = "b", axlabel = "Skewness", label = "Pulsar").set_title("Skewness for Integrated Profiles")
sns.distplot(skew_notstar_profile, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

mean_star_dmsnr = np.array(dfstar["mean_dmsnr"])
mean_notstar_dmsnr = np.array(dfnotstar["mean_dmsnr"])
sns.distplot(mean_star_dmsnr, color = "b", axlabel = "Mean", label = "Pulsar").set_title("Means for DM-SNR Curves")
sns.distplot(mean_notstar_dmsnr, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

std_star_dmsnr = np.array(dfstar["std_dmsnr"])
std_notstar_dmsnr = np.array(dfnotstar["std_dmsnr"])
sns.distplot(std_star_dmsnr, color = "b", axlabel = "Standard Deviation", label = "Pulsar").set_title("Standard Deviations for DM-SNR Curves")
sns.distplot(std_notstar_dmsnr, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

exkurt_star_dmsnr = np.array(dfstar["excess_kurtosis_dmsnr"])
exkurt_notstar_dmsnr = np.array(dfnotstar["excess_kurtosis_dmsnr"])
sns.distplot(exkurt_star_dmsnr, color = "b", axlabel = "Excess Kurtosis", label = "Pulsar").set_title("Excess Kurtosis for DM-SNR Curves")
sns.distplot(exkurt_notstar_dmsnr, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

skew_star_dmsnr = np.array(dfstar["skew_dmsnr"])
skew_notstar_dmsnr = np.array(dfnotstar["skew_dmsnr"])
sns.distplot(skew_star_dmsnr, color = "b", axlabel = "Skewness", label = "Pulsar").set_title("Skewness for DM-SNR Curves")
sns.distplot(skew_notstar_dmsnr, color = "r", label = "Not Pulsar")
plt.legend()

# In[None]

df.head()

# W# e#  # c# a# n#  # a# l# s# o#  # s# e# e#  # h# o# w#  # f# e# a# t# u# r# e# s#  # a# r# e#  # c# o# r# r# e# l# a# t# e# d# .

# In[None]

sns.heatmap(df[["mean_profile", "std_profile", "Excess_kurtosis_profile", "skew_profile", "mean_dmsnr", "std_dmsnr", "excess_kurtosis_dmsnr", "skew_dmsnr", "target_class"]].corr(), annot = True)
sns.set(style = "dark")

# B# y#  # l# o# o# k# i# n# g#  # a# t#  # t# h# e#  # d# i# s# t# r# i# b# u# t# i# o# n# s#  # f# o# r#  # e# a# c# h#  # f# e# a# t# u# r# e# ,#  # t# h# e# r# e#  # i# s# n# '# t#  # a#  # t# o# n#  # o# f#  # o# v# e# r# l# a# p#  # (# w# i# t# h#  # m# a# y# b# e#  # t# w# o#  # e# x# c# e# p# t# i# o# n# s# )# .#  # T# h# e# r# e# f# o# r# e# ,#  # w# e#  # m# i# g# h# t#  # b# e#  # a# b# l# e#  # t# o#  # g# e# t#  # a# c# c# u# r# a# t# e#  # r# e# s# u# l# t# s#  # w# i# t# h#  # a#  # s# u# p# p# o# r# t#  # v# e# c# t# o# r#  # m# a# c# h# i# n# e#  # w# i# t# h#  # a#  # l# i# n# e# a# r#  # k# e# r# n# e# l# .

# In[None]

from sklearn import svm
from sklearn.model_selection import train_test_split


# In[None]

X = np.array(df.drop("target_class", axis = 1))
y = np.array(df["target_class"])

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_true = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_true, y_pred)
import numpy as np
np.save("prenotebook_res/2637520.npy", { "accuracy_score": score })

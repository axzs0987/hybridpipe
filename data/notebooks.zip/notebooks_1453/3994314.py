import pandas as pd
# ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 
# G# r# e# e# t# i# n# g# s#  # f# r# o# m#  # t# h# e#  # K# a# g# g# l# e#  # b# o# t# !#  # T# h# i# s#  # i# s#  # a# n#  # a# u# t# o# m# a# t# i# c# a# l# l# y# -# g# e# n# e# r# a# t# e# d#  # k# e# r# n# e# l#  # w# i# t# h#  # s# t# a# r# t# e# r#  # c# o# d# e#  # d# e# m# o# n# s# t# r# a# t# i# n# g#  # h# o# w#  # t# o#  # r# e# a# d#  # i# n#  # t# h# e#  # d# a# t# a#  # a# n# d#  # b# e# g# i# n#  # e# x# p# l# o# r# i# n# g# .#  # C# l# i# c# k#  # t# h# e#  # b# l# u# e#  # "# E# d# i# t#  # N# o# t# e# b# o# o# k# "#  # o# r#  # "# F# o# r# k#  # N# o# t# e# b# o# o# k# "#  # b# u# t# t# o# n#  # a# t#  # t# h# e#  # t# o# p#  # o# f#  # t# h# i# s#  # k# e# r# n# e# l#  # t# o#  # b# e# g# i# n#  # e# d# i# t# i# n# g# .

# ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # A# n# a# l# y# s# i# s# 
# T# o#  # b# e# g# i# n#  # t# h# i# s#  # e# x# p# l# o# r# a# t# o# r# y#  # a# n# a# l# y# s# i# s# ,#  # f# i# r# s# t#  # u# s# e#  # `# m# a# t# p# l# o# t# l# i# b# `#  # t# o#  # i# m# p# o# r# t#  # l# i# b# r# a# r# i# e# s#  # a# n# d#  # d# e# f# i# n# e#  # f# u# n# c# t# i# o# n# s#  # f# o# r#  # p# l# o# t# t# i# n# g#  # t# h# e#  # d# a# t# a# .#  # D# e# p# e# n# d# i# n# g#  # o# n#  # t# h# e#  # d# a# t# a# ,#  # n# o# t#  # a# l# l#  # p# l# o# t# s#  # w# i# l# l#  # b# e#  # m# a# d# e# .#  # (# H# e# y# ,#  # I# '# m#  # j# u# s# t#  # a#  # k# e# r# n# e# l# i# n# g#  # b# o# t# ,#  # n# o# t#  # a#  # K# a# g# g# l# e#  # C# o# m# p# e# t# i# t# i# o# n# s#  # G# r# a# n# d# m# a# s# t# e# r# !# )

# In[109]

from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt # plotting
import numpy as np # linear algebra
import os # accessing directory structure
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns


# T# h# e# r# e#  # i# s#  # 1#  # c# s# v#  # f# i# l# e#  # i# n#  # t# h# e#  # c# u# r# r# e# n# t#  # v# e# r# s# i# o# n#  # o# f#  # t# h# e#  # d# a# t# a# s# e# t# :# 


# In[110]

print(os.listdir('../input'))

# T# h# e#  # n# e# x# t#  # h# i# d# d# e# n#  # c# o# d# e#  # c# e# l# l# s#  # d# e# f# i# n# e#  # f# u# n# c# t# i# o# n# s#  # f# o# r#  # p# l# o# t# t# i# n# g#  # d# a# t# a# .#  # C# l# i# c# k#  # o# n#  # t# h# e#  # "# C# o# d# e# "#  # b# u# t# t# o# n#  # i# n#  # t# h# e#  # p# u# b# l# i# s# h# e# d#  # k# e# r# n# e# l#  # t# o#  # r# e# v# e# a# l#  # t# h# e#  # h# i# d# d# e# n#  # c# o# d# e# .

# In[111]

# Distribution graphs (histogram/bar graph) of column data
def plotPerColumnDistribution(df, nGraphShown, nGraphPerRow):
    nunique = df.nunique()
    df = df[[col for col in df if nunique[col] > 1 and nunique[col] < 50]] # For displaying purposes, pick columns that have between 1 and 50 unique values
    nRow, nCol = df.shape
    columnNames = list(df)
    nGraphRow = (nCol + nGraphPerRow - 1) / nGraphPerRow
    plt.figure(num = None, figsize = (6 * nGraphPerRow, 8 * nGraphRow), dpi = 80, facecolor = 'w', edgecolor = 'k')
    for i in range(min(nCol, nGraphShown)):
        plt.subplot(nGraphRow, nGraphPerRow, i + 1)
        columnDf = df.iloc[:, i]
        if (not np.issubdtype(type(columnDf.iloc[0]), np.number)):
            valueCounts = columnDf.value_counts()
            valueCounts.plot.bar()
        else:
            columnDf.hist()
        plt.ylabel('counts')
        plt.xticks(rotation = 90)
        plt.title(f'{columnNames[i]} (column {i})')
    plt.tight_layout(pad = 1.0, w_pad = 1.0, h_pad = 1.0)
    plt.show()


# In[112]

# Correlation matrix
def plotCorrelationMatrix(df, graphWidth):
    filename = df.dataframeName
    df = df.dropna('columns') # drop columns with NaN
    df = df[[col for col in df if df[col].nunique() > 1]] # keep columns where there are more than 1 unique values
    if df.shape[1] < 2:
        print(f'No correlation plots shown: The number of non-NaN or constant columns ({df.shape[1]}) is less than 2')
        return
    corr = df.corr()
    plt.figure(num=None, figsize=(graphWidth, graphWidth), dpi=80, facecolor='w', edgecolor='k')
    corrMat = plt.matshow(corr, fignum = 1)
    plt.xticks(range(len(corr.columns)), corr.columns, rotation=90)
    plt.yticks(range(len(corr.columns)), corr.columns)
    plt.gca().xaxis.tick_bottom()
    plt.colorbar(corrMat)
    plt.title(f'Correlation Matrix for {filename}', fontsize=15)
    plt.show()


# In[113]

# Scatter and density plots
def plotScatterMatrix(df, plotSize, textSize):
    df = df.select_dtypes(include =[np.number]) # keep only numerical columns
    # Remove rows and columns that would lead to df being singular
    df = df.dropna('columns')
    df = df[[col for col in df if df[col].nunique() > 1]] # keep columns where there are more than 1 unique values
    columnNames = list(df)
    if len(columnNames) > 10: # reduce the number of columns for matrix inversion of kernel density plots
        columnNames = columnNames[:10]
    df = df[columnNames]
    ax = pd.plotting.scatter_matrix(df, alpha=0.75, figsize=[plotSize, plotSize], diagonal='kde')
    corrs = df.corr().values
    for i, j in zip(*plt.np.triu_indices_from(ax, k = 1)):
        ax[i, j].annotate('Corr. coef = %.3f' % corrs[i, j], (0.8, 0.2), xycoords='axes fraction', ha='center', va='center', size=textSize)
    plt.suptitle('Scatter and Density Plot')
    plt.show()


# N# o# w#  # y# o# u# '# r# e#  # r# e# a# d# y#  # t# o#  # r# e# a# d#  # i# n#  # t# h# e#  # d# a# t# a#  # a# n# d#  # u# s# e#  # t# h# e#  # p# l# o# t# t# i# n# g#  # f# u# n# c# t# i# o# n# s#  # t# o#  # v# i# s# u# a# l# i# z# e#  # t# h# e#  # d# a# t# a# .

# ## ## ##  # L# e# t# '# s#  # c# h# e# c# k#  # 1# s# t#  # f# i# l# e# :#  # .# .# /# i# n# p# u# t# /# a# d# v# e# r# t# i# s# i# n# g# .# c# s# v

# In[114]

nRowsRead = 1000 # specify 'None' if want to read whole file
df1 = pd.read_csv('../input/advertising.csv', delimiter=',', nrows = nRowsRead)
df1.dataframeName = 'advertising.csv'
nRow, nCol = df1.shape
print(f'There are {nRow} rows and {nCol} columns')

# L# e# t# '# s#  # t# a# k# e#  # a#  # q# u# i# c# k#  # l# o# o# k#  # a# t#  # w# h# a# t#  # t# h# e#  # d# a# t# a#  # l# o# o# k# s#  # l# i# k# e# :

# In[115]

df1.head(5)

# ## ## ## ##  # I# n#  # t# h# i# s#  # p# r# o# j# e# c# t#  # w# e#  # w# i# l# l#  # b# e#  # w# o# r# k# i# n# g#  # w# i# t# h#  # a#  # f# a# k# e#  # a# d# v# e# r# t# i# s# i# n# g#  # d# a# t# a#  # s# e# t# ,#  # i# n# d# i# c# a# t# i# n# g#  # w# h# e# t# h# e# r#  # o# r#  # n# o# t#  # a#  # p# a# r# t# i# c# u# l# a# r#  # i# n# t# e# r# n# e# t#  # u# s# e# r#  # c# l# i# c# k# e# d#  # o# n#  # a# n#  # A# d# v# e# r# t# i# s# e# m# e# n# t# .#  # W# e#  # w# i# l# l#  # t# r# y#  # t# o#  # c# r# e# a# t# e#  # a#  # m# o# d# e# l#  # t# h# a# t#  # w# i# l# l#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # o# r#  # n# o# t#  # t# h# e# y#  # w# i# l# l#  # c# l# i# c# k#  # o# n#  # a# n#  # a# d#  # b# a# s# e# d#  # o# f# f#  # t# h# e#  # f# e# a# t# u# r# e# s#  # o# f#  # t# h# a# t#  # u# s# e# r# .# 
#  #  #  #  # T# h# i# s#  # d# a# t# a#  # s# e# t#  # c# o# n# t# a# i# n# s#  # t# h# e#  # f# o# l# l# o# w# i# n# g#  # f# e# a# t# u# r# e# s# :# 
# 
#  #  #  #  # '# D# a# i# l# y#  # T# i# m# e#  # S# p# e# n# t#  # o# n#  # S# i# t# e# '# :#  # c# o# n# s# u# m# e# r#  # t# i# m# e#  # o# n#  # s# i# t# e#  # i# n#  # m# i# n# u# t# e# s# 
#  #  #  #  # '# A# g# e# '# :#  # c# u# t# o# m# e# r#  # a# g# e#  # i# n#  # y# e# a# r# s# 
#  #  #  #  # '# A# r# e# a#  # I# n# c# o# m# e# '# :#  # A# v# g# .#  # I# n# c# o# m# e#  # o# f#  # g# e# o# g# r# a# p# h# i# c# a# l#  # a# r# e# a#  # o# f#  # c# o# n# s# u# m# e# r# 
#  #  #  #  #  #  #  #  # '# D# a# i# l# y#  # I# n# t# e# r# n# e# t#  # U# s# a# g# e# '# :#  # A# v# g# .#  # m# i# n# u# t# e# s#  # a#  # d# a# y#  # c# o# n# s# u# m# e# r#  # i# s#  # o# n#  # t# h# e#  # i# n# t# e# r# n# e# t# 
#  #  #  #  # '# A# d#  # T# o# p# i# c#  # L# i# n# e# '# :#  # H# e# a# d# l# i# n# e#  # o# f#  # t# h# e#  # a# d# v# e# r# t# i# s# e# m# e# n# t# 
#  #  #  #  # '# C# i# t# y# '# :#  # C# i# t# y#  # o# f#  # c# o# n# s# u# m# e# r# 
#  #  #  #  # '# M# a# l# e# '# :#  # W# h# e# t# h# e# r#  # o# r#  # n# o# t#  # c# o# n# s# u# m# e# r#  # w# a# s#  # m# a# l# e# 
#  #  #  #  # '# C# o# u# n# t# r# y# '# :#  # C# o# u# n# t# r# y#  # o# f#  # c# o# n# s# u# m# e# r# 
#  #  #  #  # '# T# i# m# e# s# t# a# m# p# '# :#  # T# i# m# e#  # a# t#  # w# h# i# c# h#  # c# o# n# s# u# m# e# r#  # c# l# i# c# k# e# d#  # o# n#  # A# d#  # o# r#  # c# l# o# s# e# d#  # w# i# n# d# o# w# 
#  #  #  #  # '# C# l# i# c# k# e# d#  # o# n#  # A# d# '# :#  # 0#  # o# r#  # 1#  # i# n# d# i# c# a# t# e# d#  # c# l# i# c# k# i# n# g#  # o# n#  # A# d

# ## ## ##  # s# o# u# r# c# e# :# 
#  #  #  #  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# f# a# y# o# m# i# /# a# d# v# e# r# t# i# s# i# n# g# 
#  #  #  #  # F# A# S# T#  # A# I#  # h# t# t# p# :# /# /# c# o# u# r# s# e# 1# 8# .# f# a# s# t# .# a# i# /# m# l

# In[116]

df1.head()# check all file colums feature

# ## ##  # Q# u# e# s# t# i# o# s#  # n# e# e# d#  # t# o#  # a# n# s# w# e# r# :# 
#  #  #  #  # w# h# i# c# h#  # a# d# v# e# r# t# i# s# e#  # t# o# p# i# c#  # t# a# r# g# e# t#  # w# h# i# c# h#  # r# e# g# i# n# ,#  # a# g# e# ,#  # i# n# c# o# m# e# ?# 
#  #  #  #  # w# h# i# c# h#  # a# d# v# e# r# t# i# s# e#  # t# o# p# i# c#  # c# l# i# c# k# e# d#  # b# y#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e# ?

# ##  # "# C# l# i# c# k# e# d#  # o# n#  # A# d# "#  # c# o# l# u# m# n#  # f# e# a# t# u# r# e# .

# In[117]

sns.pairplot(df1,hue='Clicked on Ad',palette='bwr')

# ## ##  # E# a# c# h#  # f# e# a# t# u# r# e#  # g# r# a# p# h#  # v# e# s# u# a# l# i# z# e# 


# In[118]

print("Age range")
sns.set_style('whitegrid')
df1['Age'].hist(bins=30)
plt.xlabel('Age')

# In[119]

print("Age vs Area Income")
sns.jointplot(x='Age',y='Area Income',data=df1)

# In[120]

sns.jointplot(x='Age',y='Daily Time Spent on Site',data=df1)

# In[121]

df1.describe() 

# In[122]

df1.isnull().sum() # Check if there is missing values on each column

# In[123]

X_Catagoric = df1.select_dtypes(include = ['object'])
X_Catagoric.head()

# In[124]

X = df1[['Daily Time Spent on Site', 'Age', 'Area Income','Daily Internet Usage', 'Male']]
y = df1['Clicked on Ad'].values

# In[125]

# X_Catagoric.head()
# X.head()
# y.shape

# ## ## ##  # n# u# m# b# e# r#  #  # o# f#  # c# o# u# n# t# r# i# e# s#  # o# n#  # d# a# t# a

# In[126]

pd.crosstab(df1['Country'], df1['Clicked on Ad']).sort_values(1,0, ascending = False).head(10)

# In[127]

df1.groupby(['Ad Topic Line','Male'])['Clicked on Ad'].count().head() #what type of advertise are man and woman interested

# ## ## ## ##  # F# o# l# l# o# w# i# n# g#  # t# h# i# s#  # l# i# n# k#  # t# o#  # h# e# l# p#  # t# i# m# e# t# a# m# p#  # c# o# n# v# e# r# s# i# o# n#  # t# o#  # n# u# m# e# r# i# c# a# l# :# 
#  #  #  #  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# k# o# n# c# h# a# d# a# /# l# o# g# i# s# t# i# c# -# v# s# -# r# a# n# d# o# m# -# f# o# r# e# s# t# -# m# o# d# e# l# -# f# o# r# -# a# d# -# c# l# i# c# k

# In[128]

df1['Timestamp'] = pd.to_datetime(df1['Timestamp']) 
# Converting timestamp column into datatime object in order to extract new features
df1['Month'] = df1['Timestamp'].dt.month 
# Creates a new column called Month
df1['Day'] = df1['Timestamp'].dt.day     
# Creates a new column called Day
df1['Hour'] = df1['Timestamp'].dt.hour   
# Creates a new column called Hour
df1["Weekday"] = df1['Timestamp'].dt.dayofweek 
# Creates a new column called Weekday with sunday as 6 and monday as 0
# Other way to create a weekday column
#df['weekday'] = df['Timestamp'].apply(lambda x: x.weekday()) # Monday 0 .. sunday 6
# Dropping timestamp column to avoid redundancy
df1 = df1.drop(['Timestamp'], axis=1) # deleting timestamp

# In[129]

df1.head()

# ## ## ## ##  # T# o# t# a# l#  # N# u# m# b# e# r#  # o# f#  # M# a# l# e# =# 1#  # a# n# d#  # f# e# m# a# l# e# =# 0#  # w# h# o#  # c# l# i# c# k#  # a# n#  # a# d# s# 


# In[130]

df1.groupby(['Male'])['Clicked on Ad'].sum()

# In[131]

df1.groupby(['Male','Clicked on Ad'])['Clicked on Ad'].count().unstack()

# In[132]

sns.factorplot('Hour', 'Clicked on Ad', hue='Male', data = df1)
plt.show()

# ##  # L# o# g# i# s# t# i# c#  # R# e# g# r# e# s# s# i# o# n#  

# In[133]

from sklearn.model_selection import train_test_split

# In[134]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3994314.npy", { "accuracy_score": score })

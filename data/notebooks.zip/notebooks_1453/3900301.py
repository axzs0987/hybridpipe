import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

df.head().T


# In[None]

# Fazendo um cópia do dataframe
df_raw = df.copy()

# In[None]

# Verificar o dataframe
df.info()

# In[None]

# Corrigindo a coluna TotalCharges e convertendo em FLOAT
df['TotalCharges'] = df['TotalCharges'].str.replace(' ','-1').astype(float)

# In[None]

df.info()

# ##  # P# r# e# p# a# r# a# r#  # o# s#  # d# a# d# o# s# 


# In[None]

# Transformando dados categorias em números
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].astype('category').cat.codes

# In[None]

df.info()

# In[None]

df.head()

# In[None]


# Importandoa função
from sklearn.model_selection import train_test_split

# In[None]

# Separação do dataframe em treino e teste
y_varible = df["Churn"]
x_varible = df.drop(["Churn"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/3900301.npy", { "accuracy_score": score })

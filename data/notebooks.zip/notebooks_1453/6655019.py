import pandas as pd
# In[None]

import pandas as pd
import matplotlib.pyplot as plt
import os
#print(os.listdir("../input"))

# In[None]

data = pd.read_csv("../input/predicting-a-pulsar-star/pulsar_stars.csv") 

# In[None]

data.head()

# In[None]

print(data.columns)

# In[None]

#visualize and explore the data
print(data.loc[20])

# Print the shape of the dataset
print(data.shape)

# In[None]

data['target_class'].value_counts().plot(kind='bar')

# In[None]

classes = data['target_class']
print(classes.value_counts())

# In[None]

df = pd.DataFrame(data)

# In[None]

df.notnull()

# In[None]

data.describe()

# In[None]

#Plotting the data
data.hist(figsize=(15,15))
plt.show()

# In[None]

import seaborn as sns

# In[None]

# Correlation matrix
corrmat = data.corr()
plt.figure(figsize=(10,10))
sns.heatmap(corrmat,cmap='viridis',annot=True,linewidths=0.5,)

# In[None]

sns.pairplot(data, hue="target_class",palette="husl",diag_kind = "kde",kind = "scatter")
plt.suptitle("PairPlot of Data Without Std. Dev. Fields",fontsize=18)
plt.show() 


# In[None]

# Get all the columns from the dataFrame
columns = data.columns.tolist()

# Filter the columns to remove data we do not want
columns = [c for c in columns if c not in ["target_class"]]

# Store the variable we'll be predicting on
target = "target_class"

X = data[columns]
y = data[target]

# Print shapes
print(X.shape)
print(y.shape)

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(0,1))

features_scaled = scaler.fit_transform(X)

# In[None]

print(X.loc[10])
print(y.loc[10])

# In[None]

from sklearn import model_selection
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features_scaled, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/6655019.npy", { "accuracy_score": score })

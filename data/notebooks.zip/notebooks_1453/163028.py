import pandas as pd
# I# n#  # t# h# i# s#  # n# o# t# e# b# o# o# k# ,# K# N# N#  # a# l# g# o# r# i# t# h# m#  # a# r# e#  # u# s# e# d#  # o# n#  # t# h# e#  # v# o# i# c# e# .# c# s# v#  # d# a# t# a# s# e# t#  # w# h# i# c# h#  # c# o# n# s# i# s# t# s#  # o# f#  # o# f#  # v# a# r# i# o# u# s#  # f# e# a# t# u# r# e# s#  # o# f#  # v# o# i# c# e# :# m# e# a# n#  # f# r# e# q# u# e# n# c# y#  # e# t# c# .#  # H# e# r# e#  # w# e#  # w# i# l# l#  # u# s# e#  # f# e# a# t# u# r# e# _# s# e# l# e# c# t# i# o# n#  # f# r# o# m#  # s# k# l# e# a# r# n#  # t# o#  # i# m# p# r# o# v# e#  # o# u# r#  # l# e# a# r# n# i# n# g#  # d# a# t# a# s# e# t# .# 
# =# =# =# =# =# =# =

# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# I# m# p# o# r# t# i# n# g# :# 
# =# =# =# =# =# =# =

# In[None]

import pandas as pd
import numpy as np
from sklearn import preprocessing, neighbors
from sklearn.cross_validation import train_test_split
from sklearn.linear_model import LogisticRegression
import seaborn as sns
import matplotlib.pyplot as plt

# In[None]

# Reading and uploading the file
df = pd.read_csv('../input/voice.csv')
df.head(5)

# V# i# s# u# a# l# i# z# i# n# g#  # t# h# e#  # c# o# r# r# e# l# a# t# i# o# n#  # a# m# o# n# g#  # t# h# e#  # f# e# a# t# u# r# e# s# .# 
# =# =# =# =# =# =# =

# In[None]

corrmat=df.corr()
sns.heatmap(corrmat,linewidths=0.25,vmax=1.0, square=True, cmap="YlGnBu", linecolor='black')

# In[None]

# Name of the columns
col_names = list(df.columns.values)
print(col_names)
print (type(df.columns.values))

# In[None]

df = df.rename(columns={'label': 'gender'})
df.columns.values

# In[None]

#Lets use logistic Regression:

#Producing X and y
X = np.array(df.drop(['gender'], 1))
y = np.array(df['gender'])

#Dividing the data randomly into training and test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/163028.npy", { "accuracy_score": score })

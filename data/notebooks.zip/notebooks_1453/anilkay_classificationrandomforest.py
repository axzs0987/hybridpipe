import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
data=pd.read_csv("/kaggle/input/run-or-walk/dataset.csv")
data.head()
set(data["username"])
del data["username"]
set(data["date"])
set(data["wrist"])
set(data["activity"])
import seaborn as sns
#sns.relplot(data=data,x="gyro_x",y="gyro_z",hue="activity")
newframe=pd.DataFrame({    "gyrox":data["gyro_x"].abs(),    "gyroz":data["gyro_z"].abs(),    "activity":data["activity"]})
#sns.relplot(data=newframe,x="gyrox",y="gyroz",hue="activity")
x=data.iloc[:,4:]
xadd=data["wrist"]
x["wrist"]=xadd
y=data["activity"]
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier()
#print(cross_val_score(rfc, x, y, cv=10)) 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import confusion_matrix,accuracy_score,classification_report
rfc=RandomForestClassifier()
#rfc.fit(x_train,y_train)
#ypred=rfc.predict(x_test)
#print(confusion_matrix(y_pred=ypred,y_true=y_test))
#print(accuracy_score(y_pred=ypred,y_true=y_test))
#print(classification_report(y_pred=ypred,y_true=y_test))
rfc=RandomForestClassifier(n_estimators=100)
#rfc.fit(x_train,y_train)
#ypred=rfc.predict(x_test)
#print(confusion_matrix(y_pred=ypred,y_true=y_test))
#print(accuracy_score(y_pred=ypred,y_true=y_test))
#print(classification_report(y_pred=ypred,y_true=y_test))



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/anilkay_classificationrandomforest.npy", { "accuracy_score": score })
import pandas as pd
if type(x_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationrandomforest/trainX.npy", x_train)
if type(x_train).__name__ == "Series":
    x_train.to_csv("hi_res_data/anilkay_classificationrandomforest/trainX.csv",encoding="gbk")
if type(x_train).__name__ == "DataFrame":
    x_train.to_csv("hi_res_data/anilkay_classificationrandomforest/trainX.csv",encoding="gbk")

if type(x_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationrandomforest/testX.npy", x_test)
if type(x_test).__name__ == "Series":
    x_test.to_csv("hi_res_data/anilkay_classificationrandomforest/testX.csv",encoding="gbk")
if type(x_test).__name__ == "DataFrame":
    x_test.to_csv("hi_res_data/anilkay_classificationrandomforest/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationrandomforest/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/anilkay_classificationrandomforest/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/anilkay_classificationrandomforest/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/anilkay_classificationrandomforest/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/anilkay_classificationrandomforest/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/anilkay_classificationrandomforest/testY.csv",encoding="gbk")


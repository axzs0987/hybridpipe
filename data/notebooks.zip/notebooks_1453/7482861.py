import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv("../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv")

# In[None]

data

# In[None]

data.isnull()

# In[None]

data.isnull().sum()

# In[None]

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

# In[None]

data.head()

# In[None]

print('Rows = ', data.shape[0])
print('Columns = ', data.shape[1])
print('\nMissing values =\n', data.isnull().sum())
print('\nName of columns =\n', data.columns)
print('\nUnique values =\n', data.nunique())

# In[None]

data['gender'] = data['gender'].map({'Male':1, 'Female':0})
data.head()

# In[None]

data['Partner'] = data['Partner'].map({'Yes':1, 'No':0})
data['Dependents'] = data['Dependents'].map({'Yes':1, 'No':0})
data['PhoneService'] = data['PhoneService'].map({'Yes':1, 'No':0})
data['PaperlessBilling'] = data['PaperlessBilling'].map({'Yes':1, 'No':0})
data['MultipleLines'] = data['MultipleLines'].map({'Yes':1, 'No':0, 'No phone service':0})
data['Churn'] = data['Churn'].map({'Yes':1, 'No':0})
pdinternetservice = pd.get_dummies(data['InternetService'])
data = pd.concat([data, pdinternetservice], axis = 1)
pdcontract = pd.get_dummies(data['Contract'])
data = pd.concat([data, pdcontract], axis = 1)
pdpaymentmethod  = pd.get_dummies(data['PaymentMethod'])
data = pd.concat([data, pdpaymentmethod], axis = 1)
data.head()

# In[None]

data.rename(columns ={'No':'No internet service'}, inplace = True)

# In[None]

data.Contract.unique()

# In[None]

data.drop('customerID', inplace = True, axis =1)
data.drop('OnlineSecurity', inplace = True, axis =1)
data.drop('OnlineBackup', inplace = True, axis =1)
data.drop('DeviceProtection', inplace = True, axis =1)
data.drop('TechSupport', inplace = True, axis =1)
data.drop('StreamingTV', inplace = True, axis =1)
data.drop('StreamingMovies', inplace = True, axis =1)
data.drop('Contract', inplace = True, axis =1)
data.drop('InternetService', inplace = True, axis =1)
data.drop('PaymentMethod', inplace = True, axis =1)
data.head()

# In[None]

target = data['Churn']
target.head()

# In[None]

data.drop('Churn', inplace = True, axis =1)

# In[None]

data.dtypes.sample(20)

# In[None]

data

# In[None]

data['TotalCharges'] = data["TotalCharges"].replace(" ",np.nan)
data['TotalCharges'] = data.TotalCharges.median()
data['TotalCharges'] = pd.to_numeric(data['TotalCharges'])

# In[None]

data.TotalCharges.isnull().sum()

# In[None]

from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble.gradient_boosting import GradientBoostingClassifier
from sklearn.feature_selection import SelectKBest
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
def compute_score(clf, X, y, scoring='accuracy'):
    xval = cross_val_score(clf, X, y, cv = 5, scoring=scoring)
    return np.mean(xval)
clf = RandomForestClassifier(n_estimators=50, max_features='sqrt')
clf = clf.fit(data, target)
features = pd.DataFrame()
features['feature'] = data.columns
features['importance'] = clf.feature_importances_
features.sort_values(by=['importance'], ascending=True, inplace=True)
features.set_index('feature', inplace=True)

# In[None]

features.importance

# In[None]

features.plot(kind='barh', figsize=(25, 25))

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(data, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/7482861.npy", { "accuracy_score": score })

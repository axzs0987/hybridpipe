import pandas as pd
# T# h# i# s#  # d# a# t# a# s# e# t#  # i# s#  # p# r# o# b# a# b# l# y#  # b# e# s# t#  # s# u# i# t# e# d#  # f# o# r#  # u# n# s# u# p# e# r# v# i# s# e# d#  # M# L#  # t# e# c# h# n# i# q# u# e# s# ,#  # b# u# t#  # I#  # w# a# s#  # c# u# r# i# o# u# s#  # t# o#  # s# e# e#  # w# h# e# t# h# e# r#  # t# h# e# r# e#  # a# r# e#  # a# t# t# r# i# b# u# t# e# s#  # t# h# a# t#  # c# a# n#  # h# e# l# p#  # p# r# e# d# i# c# t#  # w# h# e# t# h# e# r#  # a#  # c# u# s# t# o# m# e# r#  # i# s#  # m# a# l# e#  # o# r#  # f# e# m# a# l# e# .#  # T# h# e#  # a# t# t# r# i# b# u# t# e# s#  # i# n#  # q# u# e# s# t# i# o# n#  # a# r# e#  # A# g# e# ,#  # I# n# c# o# m# e#  # a# n# d#  # S# c# o# r# e# .#  # I# t# '# s#  # a#  # s# m# a# l# l#  # d# a# t# a# s# e# t#  # (# b# o# t# h#  # i# n#  # t# e# r# m# s#  # o# f#  # f# e# a# t# u# r# e# s#  # a# n# d#  # n# u# m# b# e# r#  # o# f#  # c# u# s# t# o# m# e# r# s# )# ,#  # h# o# w# e# v# e# r#  # I#  # t# h# i# n# k#  # t# h# i# s#  # n# o# t# e# b# o# o# k#  # g# i# v# e# s#  # a#  # u# s# e# f# u# l#  # i# n# t# r# o# d# u# c# t# i# o# n#  # t# o#  # a# p# p# l# y# i# n# g#  # M# L#  # a# l# g# o# r# i# t# h# m# s#  # s# u# c# h#  # a# s#  # R# a# n# d# o# m#  # F# o# r# e# s# t# ,#  # S# V# M#  # a# n# d#  # K# N# N# .

# In[None]

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

sns.set_style('darkgrid')

# ## ##  # *# *# D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g# *# *

# In[None]

columns = ['CustomerID', 'Gender', 'Age', 'Income', 'Score']
df = pd.read_csv('../input/Mall_Customers.csv', index_col='CustomerID', names=columns, header=0)
df = df[['Age', 'Income', 'Score', 'Gender']] # Putting Gender (target variable) at the end
df.head()

# In[None]

df.shape

# W# e#  # h# a# v# e#  # d# a# t# a#  # o# n#  # 2# 0# 0#  # c# u# s# t# o# m# e# r# s# .#  # T# h# i# s#  # i# s#  # n# o# t#  # v# e# r# y#  # m# u# c# h# .#  

# In[None]

df.describe()

# A# g# e#  # r# a# n# g# e# s#  # b# e# t# w# e# e# n#  # 1# 8# -# 7# 0# ,#  # i# n# c# o# m# e#  # r# a# n# g# e# s#  # b# e# t# w# e# e# n#  # 1# 5# K# -# 1# 3# 7# K# ,#  # a# n# d#  # s# c# o# r# e#  # r# a# n# g# e# s#  # b# e# t# w# e# e# n#  # 1# -# 9# 9# .

# In[None]

# % share of gender in dataset
df.Gender.value_counts(normalize=True)

# ## ##  # *# *# E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# *# *# 
# 
# L# e# t# '# s#  # l# o# o# k#  # i# n# t# o#  # t# h# e#  # d# a# t# a# .#  # W# e#  # s# t# a# r# t#  # o# f# f#  # b# y#  # i# s# o# l# a# t# i# n# g#  # t# h# e#  # a# t# t# r# i# b# u# t# e# s#  # a# n# d#  # l# o# o# k#  # a# t#  # d# i# f# f# e# r# e# n# c# e# s#  # b# e# t# w# e# e# n#  # t# h# e#  # g# e# n# d# e# r# s# .

# In[None]

fig, (ax1, ax2) = plt.subplots(1,2, figsize=(9,4))

female = df[df.Gender == 'Female']
male = df[df.Gender == 'Male']

sns.distplot(female.Age, bins=12 ,ax=ax1)
sns.distplot(male.Age, bins=12, ax=ax2)

ax1.set_title('Age distr among females')
ax2.set_title('Age distr among males')

# In[None]

fig, (ax1, ax2) = plt.subplots(1,2, figsize=(9,4))

female = df[df.Gender == 'Female']
male = df[df.Gender == 'Male']

sns.distplot(female.Income, bins=12 ,ax=ax1)
sns.distplot(male.Income, bins=12, ax=ax2)

ax1.set_title('Income distr among females')
ax2.set_title('Income distr among males')

# In[None]

fig, (ax1, ax2) = plt.subplots(1,2, figsize=(9,4))

female = df[df.Gender == 'Female']
male = df[df.Gender == 'Male']

sns.distplot(female.Score, bins=12 ,ax=ax1)
sns.distplot(male.Score, bins=12, ax=ax2)

ax1.set_title('Score distr among females')
ax2.set_title('Score distr among males')

# I# n# t# e# r# e# s# t# i# n# g# l# y# ,#  # f# e# m# a# l# e# s# '#  # s# c# o# r# e# s#  # a# r# e#  # c# l# u# s# t# e# r# e# d#  # r# e# l# a# t# i# v# e# l# y#  # s# y# m# e# t# r# i# c# a# l# l# y#  # a# r# o# u# n# d#  # t# h# e#  # m# i# d# p# o# i# n# t# .#  # M# a# l# e# s# ,#  # h# o# w# e# v# e# r# ,#  # p# e# a# k#  # a# t#  # t# h# e#  # v# e# r# y#  # b# o# t# t# o# m# ,#  # v# e# r# y#  # t# o# p# ,#  # a# n# d#  # t# h# e#  # m# i# d# d# l# e# .

# In[None]

# Map Gender to 1 for female and 0 for male

mapping = {'Female': 1, 'Male': 0}
df.Gender.replace(mapping, inplace=True)
df.head()

# In[None]

# Comparing pairwise correlations between variables
sns.pairplot(df[['Age', 'Income', 'Score']])

# N# o#  # s# i# g# n# i# f# i# c# a# n# t#  # c# o# r# r# e# l# a# t# i# o# n# s#  # b# e# t# w# e# e# n#  # t# h# e#  # v# a# r# i# a# b# l# e# s# .

# In[None]

sns.lmplot('Score', 'Income', hue='Gender', data=df, fit_reg=False)

# W# e#  # s# e# e#  # a#  # p# a# t# t# e# r# n# ,#  # a# l# t# h# o# u# g# h#  # t# h# i# s#  # i# s#  # n# o# t#  # a#  # l# i# n# e# a# r#  # o# n# e# .#  # I# n# t# e# r# e# s# t# i# n# g# l# y#  # t# h# e# r# e#  # s# e# e# m# s#  # t# o#  # b# e#  # a#  # c# l# u# s# t# e# r#  # w# h# e# r# e#  # m# o# s# t#  # p# e# o# p# l# e#  # w# h# o#  # h# a# v# e#  # i# n# c# o# m# e#  # i# n#  # t# h# e#  # 4# 0# k# -# 6# 0# k#  # r# a# n# g# e#  # h# a# v# e#  # a#  # s# c# o# r# e#  # b# e# t# w# e# e# n#  # 4# 0# -# 6# 0# .#  # A# n# y# o# n# e#  # w# i# t# h#  # i# n# c# o# m# e#  # a# b# o# v# e#  # o# r#  # b# e# l# o# w#  # t# h# i# s#  # r# a# n# g# e#  # s# e# e# m# s#  # t# o#  # b# e#  # a# t#  # t# h# e#  # e# x# t# r# e# m# e# s#  # o# f#  # t# h# e#  # S# c# o# r# e#  # r# a# n# g# e#  # -#  # e# i# t# h# e# r#  # v# e# r# y#  # h# i# g# h#  # o# r#  # v# e# r# y#  # l# o# w# .

# ## ##  # *# *# M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g# *# *# 
# 
# C# a# n#  # w# e#  # p# r# e# d# i# c# t#  # t# h# e#  # g# e# n# d# e# r#  # o# f#  # a#  # c# u# s# t# o# m# e# r#  # (# t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# )#  # b# a# s# e# d#  # o# n#  # a# t# t# r# i# b# u# t# e# s#  # s# u# c# h#  # a# s#  # a# g# e# ,#  # i# n# c# o# m# e#  # a# n# d#  # s# c# o# r# e# ?#  # W# e#  # t# r# y#  # t# r# a# i# n# i# n# g#  # 3#  # d# i# f# f# e# r# e# n# t#  # a# l# g# o# r# i# t# h# m# s#  # f# o# r#  # t# h# i# s#  # t# a# s# k#  # -#  # K# N# N# ,#  # R# a# n# d# o# m#  # F# o# r# e# s# t# ,#  # a# n# d#  # S# V# M# .

# ## ## ##  # *# *# F# e# a# t# u# r# e#  # s# c# a# l# i# n# g#  # -#  # s# t# a# n# d# a# r# d# i# z# i# n# g#  # t# h# e#  # d# a# t# a# *# *

# In[None]

# Standardize the data to all be the same unit

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
scaler.fit(df.drop('Gender', axis=1))

# Transforming the data
scaled_features = scaler.transform(df.drop('Gender', axis=1))
scaled_features

# In[None]

# Use the scaler to create scaler dataframe
# This gives us a standardized version of our data

df_feat = pd.DataFrame(scaled_features, columns=df.columns[:-1])
df_feat.head()

# ## ## ##  # *# *# T# r# a# i# n#  # t# e# s# t#  # s# p# l# i# t# *# *

# In[None]

from sklearn.model_selection import train_test_split, GridSearchCV

X = df_feat
y = df['Gender']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/3811691.npy", { "accuracy_score": score })

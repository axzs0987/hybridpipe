import pandas as pd
# In[None]

import numpy as np
import pandas as pd

import os

# I# m# p# o# r# t#  # d# a# t# a

# In[None]

data = pd.read_csv("../input/voice.csv")

# R# e# v# i# e# w#  # t# h# e#  # d# a# t# a

# In[None]

data.head()

# C# o# n# v# e# r# t#  # "# m# a# l# e# "#  # t# o#  # 1# ,#  # "# f# e# m# a# l# e# "#  # t# o#  # 0

# In[None]

data.label = [1 if each == "male" else 0 for each in data.label]
data.head() # check if binary conversion worked

# E# x# t# r# a# c# t#  # g# e# n# d# e# r#  # a# n# d#  # f# e# a# t# u# r# e# s#  # d# a# t# a

# In[None]

gender = data.label.values
features = data.drop(["label"], axis = 1)
features = (features-features.min())/(features.max()-features.min()) # normalization

# S# p# l# i# t#  # d# a# t# a#  # f# o# r#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t#  # p# u# r# p# o# s# e

# In[None]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(features, gender, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1958005.npy", { "accuracy_score": score })

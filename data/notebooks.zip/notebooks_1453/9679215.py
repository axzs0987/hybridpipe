import pandas as pd
# In[None]

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# In[None]

# Importing the dataset
df = pd.read_csv(r"../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv")
df.info()

# In[None]

# Taking care of missing data using 'mean' and convert 'TotalCharges' from object type to float
from sklearn.impute import SimpleImputer
df['TotalCharges']=df['TotalCharges'].str.strip().replace('',np.nan)
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
df['TotalCharges'] = imputer.fit_transform(df['TotalCharges'].values.reshape(-1,1))

# ## ## ##  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s

# In[None]

def autolabel(rects,total):
    """Attach a text label above each bar in *rects*, displaying its percentage."""
    for j in range(len(rects)):
        height = rects[j].get_height()
        percentage = '{:.1f}%'.format(100 * rects[j].get_height() / total)
        ax.annotate(percentage,
                    xy=(rects[j].get_x() + rects[j].get_width() / 2, height),
                    xytext=(0, 0.5),
                    textcoords="offset points",
                    ha='center', va='bottom')
# Churn
total = len(df['Churn'])        
colors1 =['#C03028','#78C850']#Fighting,Grass
colors2 = ['#6890F0','#F08030','#F8D030','#A8A878']#Water,Fire,Electric,Normal
ax = sns.countplot(x='Churn',hue='Churn',data=df,palette=colors1)
plt.ylabel('Number of Occurrences')
autolabel(ax.patches,total)

# 2# 6# .# 5# %#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r# s#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y# .

# In[None]

# Gender
f, axes = plt.subplots(1, 3,figsize=(15, 10))
# Male - Female Countplot
ax = sns.countplot(x='gender',hue='Churn',data=df,ax=axes[0],palette=colors1)
ax.set(xlabel="Gender", ylabel="Number of Occurrences")
autolabel(ax.patches,total)
 
# Male - Female Pies Charts 
group = df.groupby(['gender', 'Churn']).size().unstack()
axes[1].pie(group.iloc[:,0], labels=group.index, autopct='%1.1f%%',colors=colors2)
axes[1].legend(title='Gender',fontsize='x-small')
axes[1].set_title('NO CHURN',color=colors1[0], weight='bold')
axes[2].pie(group.iloc[:,1], labels=group.index, autopct='%1.1f%%',colors=colors2)
axes[2].legend(title='Gender',fontsize='x-small')
axes[2].set_title('CHURN',color=colors1[1],weight='bold')

# C# h# u# r# n# i# n# g#  # r# a# t# e# s#  # f# o# r#  # m# e# n#  # e# n# d#  # w# o# m# e# n#  # a# r# e#  # a# l# o# m# s# t#  # e# q# u# a# l# .#  # W# e#  # c# a# n#  # s# a# y#  # t# h# a# t#  # g# e# n# d# e# r#  # h# a# s#  # n# o# t#  # b# i# g#  # i# m# p# o# r# t# a# n# c# e# .

# In[None]

# OnlineSecurity-OnlineBackup-DeviceProtection-TechSupport-StreamingTV-StreamingMovies
fig = plt.figure(figsize=(15, 10))
IVs = ['OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies']
OnlineServices = df[IVs].replace({'No internet service':2,'No': 0, 'Yes': 1})
OnlineServicesSum = OnlineServices.sum(axis=1)
ax = sns.countplot(x=OnlineServicesSum,hue='Churn',data=df,palette=colors1)
plt.ylabel("Number of Occurrences")
plt.xlabel('Number of OnlineServices')
plt.xticks(np.arange(8),(0,1,2,3,4,5,6,'No internet service'))
autolabel(ax.patches,total)

# In[None]

OnlineServicesSum = pd.crosstab(OnlineServicesSum,df.Churn)
OnlineServicesSum.rename(index={12:'No Internet service'}, inplace=True)
f, axes = plt.subplots(1,2,figsize=(15, 10))
colors3 = ['#6890F0','#F08030','#F8D030','#98D8D8','#A8A878','#C03028','#78C850','#F85888']
axes[0].pie(OnlineServicesSum.iloc[:,0], labels=OnlineServicesSum.index, autopct='%1.1f%%',colors=colors3)
axes[0].legend(title='Gender',fontsize='x-small')
axes[0].set_title('NO CHURN',color=colors1[0], weight='bold')
axes[1].pie(OnlineServicesSum.iloc[:,1], labels=OnlineServicesSum.index, autopct='%1.1f%%',colors=colors3)
axes[1].legend(title='Gender',fontsize='x-small')
axes[1].set_title('CHURN',color=colors1[1],weight='bold')

# T# h# e# r# e#  # a# r# e#  # 6#  # O# n# l# i# n# e#  # S# e# r# v# i# c# e# s# .#  # C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # 0#  # O# n# l# i# n# e# S# e# r# v# i# c# e# s#  # a# r# e#  # d# e# n# o# t# e# d#  # w# i# t# h#  # '# 0# '# .#  # T# h# e#  # c# h# u# r# n# i# n# g#  # p# e# r# c# e# n# t# a# g# e# s#  # a# r# e#  # l# a# r# g# e# r#  # f# o# r#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # 0# ,# 1#  # a# n# d#  # 2#  # O# n# l# i# n# e# S# e# r# v# i# c# e# s# .#  # A# l# s# o# ,#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # t# e# n# d#  # t# o#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# .

# In[None]

for i in range(len(IVs)):
 f, axes = plt.subplots(1,3,figsize=(10, 5))
 # Countplot
 ax = sns.countplot(x=IVs[i],hue='Churn',data=df,ax=axes[0],palette=colors1)
 ax.set(xlabel=IVs[i], ylabel="Number of Occurrences")
 autolabel(ax.patches,total)
 
 # Pie Charts 
 group = df.groupby([IVs[i], 'Churn']).size().unstack()
 axes[1].pie(group.iloc[:,0], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[1].legend(title=IVs[i],fontsize='xx-small',title_fontsize=6)
 axes[1].set_title('NO CHURN',color=colors1[0], weight='bold')
 axes[2].pie(group.iloc[:,1], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[2].legend(title=IVs[i],fontsize='xx-small',title_fontsize=6)
 axes[2].set_title('CHURN',color=colors1[1], weight='bold')

# C# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # n# o#  # O# n# l# i# n# e# S# e# c# u# r# i# t# y# ,# O# n# l# i# n# e# B# a# c# k# u# p# ,# D# e# v# i# c# e# P# r# o# t# e# c# t# i# o# n# ,# T# e# c# h# S# u# p# p# o# r# t#  # a# r# e#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .# 
# C# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # a# n# d#  # w# i# t# h# o# u# t#  # S# t# r# e# a# m# i# n# g# M# o# v# i# e# s#  # a# n# d#  # S# t# r# e# a# m# i# n# g# T# V#  # h# a# v# e#  # s# i# m# i# l# a# r#  # p# e# r# c# e# n# t# a# g# e# s# .#  

# In[None]

#SeniorCitizen-Partner-Dependents
IVs = ['SeniorCitizen','Partner','Dependents']
for i in range(len(IVs)):
 f, axes = plt.subplots(1, 3,figsize=(10, 5))
 # Countplot
 ax = sns.countplot(x=IVs[i],hue='Churn',data=df,ax=axes[0],palette=colors1)
 ax.set(xlabel=IVs[i], ylabel="Number of Occurrences")
 autolabel(ax.patches,total)
 
 # Pie Charts 
 group = df.groupby([IVs[i], 'Churn']).size().unstack()
 axes[1].pie(group.iloc[:,0], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[1].legend(title=IVs[i],fontsize='x-small')
 axes[1].set_title('NO CHURN',color=colors1[0], weight='bold')
 axes[2].pie(group.iloc[:,1], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[2].legend(title=IVs[i],fontsize='x-small')
 axes[2].set_title('CHURN',color=colors1[1], weight='bold')

# 7# 5# .# 4# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # a# r# e# n# '# t#  # S# e# n# i# o# r# S# i# t# i# z# e# n# s# .# 
# 6# 4# .# 2# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # d# o# n# '# t#  # h# a# v# e#  # p# a# r# t# n# e# r# s# .# 
# 8# 2# .# 6# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # d# o# n# '# t#  # h# a# v# e#  # d# e# p# e# n# d# e# n# t# s# .

# In[None]

# Contract-PaperlessBilling-PaymentMethod
IVs = ['Contract','PaperlessBilling','PaymentMethod']
for i in range(len(IVs)):
 f, axes = plt.subplots(1, 3,figsize=(18, 10))
 # Countplot
 ax = sns.countplot(x=IVs[i],hue='Churn',data=df,ax=axes[0],palette=colors1)
 ax.set(xlabel=IVs[i], ylabel="Number of Occurrences")
 if i == 2:
     ax.set_xticklabels(labels=['Electronic check','Mailed check','Bank transfer','Credit card'],fontsize=7)
 autolabel(ax.patches,total)
 
 # Pie Charts 
 group = df.groupby([IVs[i], 'Churn']).size().unstack()
 axes[1].pie(group.iloc[:,0], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[1].legend(title=IVs[i],fontsize='x-small')
 axes[1].set_title('NO CHURN',color=colors1[0], weight='bold')
 axes[2].pie(group.iloc[:,1], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[2].legend(title=IVs[i],fontsize='x-small')
 axes[2].set_title('CHURN',color=colors1[1], weight='bold')

# 8# 8# .# 6# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # a#  # M# o# n# t# h#  # t# o#  # M# o# n# t# h#  # C# o# n# t# r# a# c# t# .# 
# 7# 4# .# 9# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # P# a# p# e# r# l# e# s# s#  # B# i# l# l# i# n# g# .# 
# 5# 7# .# 3# %#  # o# f#  # t# h# e#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # E# l# e# c# t# r# o# n# i# c#  # c# h# e# c# k#  # a# s#  # a#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d# .

# In[None]

# PhoneService-MultipleLines-InternetService
IVs = ['PhoneService','MultipleLines','InternetService']
for i in range(len(IVs)):
 f, axes = plt.subplots(1, 3,figsize=(10, 5))
 # Countplot
 ax = sns.countplot(x=IVs[i],hue='Churn',data=df,ax=axes[0],palette=colors1)
 ax.set(xlabel=IVs[i], ylabel="Number of Occurrences")
 autolabel(ax.patches,total)
 
 # Pie Charts 
 group = df.groupby([IVs[i], 'Churn']).size().unstack()
 axes[1].pie(group.iloc[:,0], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[1].legend(title=IVs[i],fontsize='x-small')
 axes[1].set_title('NO CHURN',color=colors1[0], weight='bold')
 axes[2].pie(group.iloc[:,1], labels=group.index, autopct='%1.1f%%',colors=colors2)
 axes[2].legend(title=IVs[i],fontsize='x-small')
 axes[2].set_title('CHURN',color=colors1[1], weight='bold')

# 9# /# 1# 0#  # c# u# s# t# o# m# e# r# s#  # h# a# v# e#  # a#  # p# h# o# n# e#  # s# e# r# v# i# c# e# .# 
# C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # a# n# d#  # w# i# t# h# o# u# t#  # M# u# l# t# i# p# l# e# L# i# n# e# s#  # h# a# v# e#  # s# i# i# l# a# r#  # r# a# t# e# s#  # o# f#  # c# h# u# r# n# i# n# g#  # a# n# d#  # n# o#  # c# h# u# r# n# i# n# g# .# 
# C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # F# i# b# e# r#  # O# p# t# i# c#  # I# n# t# e# r# n# e# t#  # S# e# r# v# i# c# e#  # t# e# n# d#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .

# In[None]

# Tenure
fig = plt.figure(figsize=(15, 10))
T = df.groupby(['tenure', 'Churn']).size().unstack().fillna(0)
plt.bar(T.index,T['Yes'],color = '#78C850')
plt.bar(T.index,T['No'],color = '#C03028',bottom=T['Yes'])
plt.legend(['Yes', 'No'],loc='upper right')
plt.ylabel("Number of Occurrences")
plt.xlabel('Tenure in months')  

# A# s#  # t# h# e#  # t# e# n# u# r# e#  # i# n# c# r# e# a# s# e# s#  # t# h# e#  # c# u# s# t# o# m# e# s#  # t# e# n# d#  # t# o#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# .#  # O# n#  # t# h# e#  # o# t# h# e# r#  # h# a# n# d#  # n# e# w#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # s# m# a# l# l#  # t# e# n# u# r# e# s#  # l# e# f# t#  # t# h# e#  # b# a# n# k# .

# In[None]

# MonthlyCharges
plt.figure(figsize=(15, 10))
bins = np.arange(0,df['MonthlyCharges'].max(), 1)
df['bins'] = pd.cut(df['MonthlyCharges'], bins)
bins = bins[:-1]
M = df.groupby(['bins','Churn']).size().unstack().fillna(0)
M.index = bins.astype(int)
plt.bar(M.index,M['Yes'],color = '#78C850')
plt.bar(M.index,M['No'],color = '#C03028',bottom=M['Yes'])
plt.legend(['Yes', 'No'],loc='upper right')
plt.ylabel("Number of Occurrences")
plt.xlabel('MonthlyCharges')

# C# u# s# t# o# m# e# r# s#  # w# i# t# h#  # M# o# n# t# h# l# y#  # C# h# a# r# g# e# s#  # b# e# t# w# e# e# n#  # 7# 0#  # a# n# d#  # 1# 1# 0#  # t# e# n# d#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y# .

# In[None]

# TotalCharges
plt.figure(figsize=(15, 10))
bins = np.arange(0,df['TotalCharges'].max(), 120)
df['bins'] = pd.cut(df['TotalCharges'], bins)
bins = bins[:-1]
C = df.groupby(['bins','Churn']).size().unstack().fillna(0)
C.index = bins.astype(int)/120
plt.bar(C.index,C['Yes'],color = '#78C850')
plt.bar(C.index,C['No'],color = '#C03028',bottom=C['Yes'])
plt.legend(['Yes', 'No'],loc='upper right')
plt.ylabel("Number of Occurrences")
plt.xlabel('TotalCharges * 100 ')

# T# h# e#  # n# u# m# b# e# r#  # o# f#  # c# h# u# r# n# i# n# g#  # c# u# s# t# o# m# e# r# s#  # d# e# c# r# e# a# s# e# s#  # a# s#  # t# h# e#  # T# o# t# a# l#  # C# h# a# r# g# e# s#  # i# n# c# r# e# a# s# e# .# 
# M# a# n# y#  # n# e# w#  # c# u# s# t# o# m# e# r# s#  # w# i# t# h#  # s# m# a# l# l#  # T# o# t# a# l#  # C# h# a# r# g# e# s#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y# .#  

# ## ## ##  # D# a# t# a#  # P# r# e# p# r# o# c# e# s# s# i# n# g

# In[None]

# Dataset split to Categorical (Nominal,Ordinal,Binary) and Numeric Vars
# Living outside the features ['gender','Parter','StreamingMovies','StreamingTV']
df_Cat_Bin = df[['SeniorCitizen','Dependents','PhoneService','PaperlessBilling']]
df_Cat_Nom = df[['MultipleLines','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','Contract','PaymentMethod']]
df_Num = df[['tenure','MonthlyCharges','TotalCharges']]

# Categorical Output
y = df['Churn']

# In[None]

# LABEL ENCODING - ONE HOT ENCODING
from sklearn.preprocessing import LabelEncoder

# Categorical Binary Features Encoding
df_Cat_Bin_Ld = df_Cat_Bin.apply(LabelEncoder().fit_transform)

# Categorical Nominal Features Encoding

df_Cat_Nom_OHEd = pd.get_dummies(df_Cat_Nom)

# Remove one variable from each One Hot Encoded feature
df_Cat_Nom_OHEd = df_Cat_Nom_OHEd.drop(['InternetService_No','OnlineSecurity_No internet service',
                      'OnlineBackup_No internet service','DeviceProtection_No internet service','TechSupport_No internet service',
                      'Contract_One year','MultipleLines_No phone service',
                      'PaymentMethod_Credit card (automatic)'],axis=1)

# All Categorical Features
df_Cat = pd.concat([df_Cat_Bin_Ld,df_Cat_Nom_OHEd],axis=1)

# Categorical Outpout Encoding
y_Ld = y.replace({'No': 0, 'Yes': 1})

# In[None]

# Correlation Matrix
corr = pd.concat([df_Cat,df_Num],axis=1)
corr = corr.corr()
plt.figure(figsize=(10, 10),dpi=80)
sns.heatmap(corr, xticklabels=corr.columns,yticklabels=corr.columns)

# In[None]

# For Numeric IVs, calculate VIF and save in dataframe
from statsmodels.stats.outliers_influence import variance_inflation_factor
V = df_Num
vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(V.values, i) for i in range(V.shape[1])]
vif["features"] = V.columns
print(vif)

#TotalCharges and Tenure are strongly correlated. Remove TotalCharges
df_Num = df_Num.drop(['TotalCharges'],axis=1)

# In[None]

# ALL the Selected IVs
X = pd.concat([df_Num,df_Cat],axis=1)
columns=X.columns
#print(X)

# In[None]

# Feature Scaling
from sklearn.preprocessing import StandardScaler,MinMaxScaler
X = StandardScaler().fit_transform(X)

# In[None]

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y_Ld, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9679215.npy", { "accuracy_score": score })

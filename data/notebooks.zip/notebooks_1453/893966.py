import pandas as pd
# In[1]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[2]

data = pd.read_csv('../input/Social_Network_Ads.csv')
print(data.shape)

# In[3]

data.keys()

# In[4]

data = data.drop(['User ID'] , axis = 1)
print(data)

# In[5]

data= pd.get_dummies(data)

# In[6]

import matplotlib.pyplot as plt 
import seaborn as sns
corr = data.corr()
corr_mat=data.corr(method='pearson')
plt.figure(figsize=(5,5))
sns.heatmap(corr_mat,vmax=1,square=True,annot=True,cmap='cubehelix')

# In[7]

from sklearn.model_selection import train_test_split
y_varible = data["Purchased"]
x_varible = data.drop(["Purchased"], 1)
from sklearn.model_selection import train_test_split
x_train_varible, x_test_varible, y_train_varible, y_test_varible = train_test_split(x_varible, y_varible, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train_varible, y_train_varible)
y_pred = model.predict(x_test_varible)
score = accuracy_score(y_test_varible, y_pred)
import numpy as np
np.save("prenotebook_res/893966.npy", { "accuracy_score": score })

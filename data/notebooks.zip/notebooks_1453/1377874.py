import pandas as pd
# *# *# Y# a# p# a# c# a# ğ# ı# n# ı# z#  # y# o# r# u# m# l# a# r#  # i# ç# i# n#  # ş# i# m# d# i# d# e# n#  # t# e# ş# e# k# k# ü# r#  # e# d# e# r# i# m# .#  # Ç# a# l# ı# ş# m# a# y# ı#  # b# e# ğ# e# n# i# r# s# e# n# i# z#  # o# y# l# a# m# a# y# ı#  # u# n# u# t# m# a# y# ı# n#  # :# :# ># .#  #  # S# o# r# u# l# a# r# a#  # e# l# i# m# d# e# n#  # g# e# l# d# i# ğ# i#  # k# a# d# a# r# ı# y# l# a#  # c# e# v# a# p#  # v# e# r# m# e# y# e#  # ç# a# l# ı# ş# a# c# a# ğ# ı# m# .#  # Ç# a# l# ı# ş# m# a# d# a# ;#  # s# o# r# u# l# a# r# a#  # v# e#  # g# e# r# i#  # b# i# l# d# i# r# i# m# l# e# r# e#  # g# ö# r# e#  # d# ü# z# e# l# t# m# e#  # v# e#  # e# k# l# e# m# e#  # y# a# p# a# c# a# ğ# ı# m# .# *# *# 
# 
# *# *# Ç# a# l# ı# ş# m# a# n# ı# n#  # Ö# z# e# t# i# :# *# *# 
# *#  # V# e# r# i#  # S# e# r# i# n# i# n#  # Y# ü# k# l# e# n# m# e# s# i# 
# *#  # V# e# r# i#  # S# e# t# i# n# i# n#  # G# ö# r# s# e# l# l# e# ş# t# i# r# i# l# m# e# s# i# 
# *#  # Ö# l# ç# e# k# l# e# n# d# i# r# m# e# 
# *#  # E# n#  # İ# y# i#  # S# ı# n# ı# f# l# a# n# d# ı# r# ı# c# ı# n# ı# n#  # B# u# l# u# n# m# a# s# ı# 
# *#  # E# n#  # İ# y# i#  # S# ı# n# ı# f# ı# l# a# n# d# ı# r# ı# c# ı# n# ı# n#  # O# p# t# i# m# i# z# a# s# y# o# n# u# 
# 
# *# *# Y# a# p# a# c# a# ğ# ı# n# ı# z#  # y# o# r# u# m# l# a# r# ;#  # ç# a# l# ı# ş# m# a# n# ı# n#  # d# a# h# a#  # i# y# i#  # v# e#  # a# n# l# a# ş# ı# l# ı# r#  # o# l# m# a# s# ı# n# ı#  # s# a# ğ# l# a# y# a# c# a# k# t# ı# r# .# *# *

# In[None]

# Gerekli Kütüphaneleri Yüklenmesi Yapılıyor


import numpy as np # linear algebra
import pandas as pd # veri işleme

#Görselleştirme Kütüphaneleri
import seaborn as sns
import matplotlib.pyplot as plt

#Machine Learning tools
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix,classification_report

import os
import warnings

# Çıktılarda karmaşıklığa sebep olduğu için uyarılırı iptal ediyoruz
warnings.filterwarnings("ignore")
#print(os.listdir("../input"))

# *# *# B# a# ğ# l# a# m# *# *# 
# V# e# r# i#  # s# e# t# i# ,#  # P# o# r# t# e# k# i# z#  # "# V# i# n# h# o#  # V# e# r# d# e# "#  # ş# a# r# a# b# ı# n# ı# n#  # k# ı# r# m# ı# z# ı#  # v# e#  # b# e# y# a# z#  # ç# e# ş# i# t# l# e# r# i#  # i# l# e#  # i# l# g# i# l# i# d# i# r# .#  # D# a# h# a#  # f# a# z# l# a#  # b# i# l# g# i#  # i# ç# i# n#  # C# o# r# t# e# z#  # v# e#  # d# i# ğ# .# ,#  # (# M# o# d# e# l# i# n# g#  # w# i# n# e#  # p# r# e# f# e# r# e# n# c# e# s#  # b# y#  # d# a# t# a#  # m# i# n# i# n# g#  # f# r# o# m#  # p# h# y# s# i# c# o# c# h# e# m# i# c# a# l#  # p# r# o# p# e# r# t# i# e# s# ,#  # 2# 0# 0# 9# )#  # ç# a# l# ı# ş# m# a# y# a#  # b# a# k# a# b# i# l# i# r# s# i# n# i# z# .#  #  # G# i# z# l# i# l# i# k#  # v# e#  # l# o# j# i# s# t# i# k#  # k# o# n# u# l# a# r# d# a# n#  # d# o# l# a# y# ı# ,#  # s# a# d# e# c# e#  # f# i# z# i# k# o# k# i# m# y# a# s# a# l#  # (# g# i# r# i# ş# l# e# r# )#  # v# e#  # d# u# y# u# s# a# l#  # (# ç# ı# k# t# ı# )#  # d# e# ğ# i# ş# k# e# n# l# e# r#  # m# e# v# c# u# t# t# u# r#  # (# ö# r# n# e# ğ# i# n#  # ü# z# ü# m#  # t# ü# r# l# e# r# i# ,#  # ş# a# r# a# p#  # m# a# r# k# a# s# ı# ,#  # ş# a# r# a# p#  # s# a# t# ı# ş#  # f# i# y# a# t# ı#  # v# b# .#  # H# a# k# k# ı# n# d# a#  # v# e# r# i#  # y# o# k# t# u# r# )# .# 
# 
# B# u#  # v# e# r# i#  # k# ü# m# e# l# e# r# i# ,#  # s# ı# n# ı# f# l# a# n# d# ı# r# m# a#  # v# e# y# a#  # r# e# g# r# e# s# y# o# n#  # g# ö# r# e# v# l# e# r# i#  # i# ç# i# n#  # k# u# l# l# a# n# ı# l# a# b# i# l# i# r# .# .#  # S# ı# n# ı# f# l# a# r#  # s# ı# r# a# l# ı# d# ı# r#  # v# e#  # d# e# n# g# e# d# e#  # d# e# ğ# i# l# d# i# r#  # (# ö# r# n# e# ğ# i# n# ,#  # m# ü# k# e# m# m# e# l#  # v# e# y# a#  # k# ö# t# ü#  # o# l# a# n# l# a# r# d# a# n#  # ç# o# k#  # d# a# h# a#  # n# o# r# m# a# l#  # ş# a# r# a# p# l# a# r#  # v# a# r# d# ı# r# )# .# 
# 
# *# *# i# ç# e# r# i# k# *# *# 
# G# i# r# i# ş#  # d# e# ğ# i# ş# k# e# n# l# e# r# i#  # (# f# i# z# i# k# o# k# i# m# y# a# s# a# l#  # t# e# s# t# l# e# r# e#  # d# a# y# a# n# a# r# a# k# )# :# 
# 1#  # -#  # s# a# b# i# t#  # a# s# i# t# 
# 2#  # -#  # u# ç# u# c# u#  # a# s# i# t# l# i# ğ# i# 
# 3#  # -#  # s# i# t# r# i# k#  # a# s# i# t# 
# 4#  # -#  # a# r# t# ı# k#  # ş# e# k# e# r# 
# 5#  # -#  # k# l# o# r# ü# r# l# e# r# 
# 6#  # -#  # s# e# r# b# e# s# t#  # s# ü# l# f# ü# r#  # d# i# o# k# s# i# t# 
# 7#  # -#  # t# o# p# l# a# m#  # s# ü# l# f# ü# r#  # d# i# o# k# s# i# t# 
# 8#  # -#  # y# o# ğ# u# n# l# u# k# 
# 9#  # -#  # p# H# 
# 1# 0#  # -#  # s# ü# l# f# a# t# l# a# r# 
# 1# 1#  # -#  # a# l# k# o# l# 
# Ç# ı# k# ı# ş#  # d# e# ğ# i# ş# k# e# n# i#  # (# d# u# y# u# s# a# l#  # v# e# r# i# l# e# r# e#  # g# ö# r# e# )# :# 
# 1# 2#  # -#  # k# a# l# i# t# e#  # (# 0#  # i# l# e#  # 1# 0#  # a# r# a# s# ı# n# d# a#  # p# u# a# n# )# .#  # V# a# r#  # o# l# a# b#  # k# a# l# i# t# e#  # p# u# a# n# l# a# r# ;# 3# ,#  # 4# ,#  # 5# ,#  # 6# ,#  # 7# ,#  # 8# .# 
# 


# In[None]

#Veri setinin yüklemesi yapılıyor
dataset=pd.read_csv("../input/winequality-red.csv")
dataset.head()

# In[None]

#Kaç farklı kalite puanı olduğunu öğrenelim
print("Kalite puanları:",dataset['quality'].unique())
dataset.info()

# V# e# r# i#  # s# e# t# i# n# d# e#  # t# o# p# l# a# m#  # 1# 5# 9# 9#  # ö# r# n# e# k#  # y# e# r#  # a# l# m# a# k# t# a# d# ı# r# 
# V# e# r# i#  # s# e# t# i# d# e# n# d# e#  # e# k# s# i# k#  # b# i# l# g# i#  # y# o# k# t# u# r# .# 
# V# e# r# i#  # s# e# t# i# d# e# k# i#  # t# ü# m#  # ö# z# e# l# l# i# k# l# e# r#  # s# a# y# ı# s# a# y# l#  # d# e# ğ# e# r#  # i# ç# e# r# m# e# k# t# e# d# i# r# 
# Ş# a# r# a# p# l# a# r# ı# n#  # i# ç# i# n#  # b# e# ş#  # a# y# r# ı#  # k# a# l# i# t# e#  # s# e# v# i# y# e# s# i#  # b# e# l# i# r# l# e# n# m# i# ş# t# i# r# ;#  # 3# ,#  # 4# ,#  # 5# ,#  # 6# ,#  # 7# ,#  # 8# .#  # E# n#  # d# ü# ş# ü# k#  # d# e# ğ# e# r#  # 3#  # v# e#  # e# n#  # y# ü# k# s# e# k#  # d# e# ğ# e# r#  # 8# '# d# i# r# .#  

# In[None]

#Farklı kalite puanlarının görselleştirilmesi
sns.countplot(dataset['quality'])

# V# e# r# i#  # s# e# t# i# n# d# e# k# i#  # ö# r# n# e# k# l# e# r# i# n#  # s# ı# n# ı# f#  # d# a# ğ# ı# l# ı# m# ı#  # d# e# n# g# e# s# i# z# d# i# r# .#  # D# e# n# g# e# s# i# z#  # s# ı# n# ı# f#  # d# a# ğ# ı# l# ı# m# ı# ,#  # m# a# k# i# n# e#  # ö# ğ# r# e# n# m# e# s# i#  # m# o# d# e# l# l# e# r# i#  # i# ç# i# n#  # i# s# t# e# n# m# y# e# n#  # b# i# r#  # d# u# r# u# m# d# u# r# .

# In[None]

#Özelliklerin kalite puanları ile ilişkisini göstermek için kullanılacak
#çizim türleri
def draw_multivarient_plot(dataset, rows, cols, plot_type):
    column_names=dataset.columns.values
    number_of_column=len(column_names)
    fig, axarr=plt.subplots(rows,cols, figsize=(22,16))

    counter=0
    for i in range(rows):
        for j in range(cols):
            if 'violin' in plot_type:
                sns.violinplot(x='quality', y=column_names[counter],data=dataset, ax=axarr[i][j])
            elif 'box'in plot_type :
                sns.boxplot(x='quality', y=column_names[counter],data=dataset, ax=axarr[i][j])
            elif 'point' in plot_type:
                sns.pointplot(x='quality',y=column_names[counter],data=dataset, ax=axarr[i][j])
            elif 'bar' in plot_type:
                sns.barplot(x='quality',y=column_names[counter],data=dataset, ax=axarr[i][j])
                
            counter+=1
            if counter==(number_of_column-1,):
                break

# V# e# r# i#  # s# e# t# i# n# d# e# k# i#  # ö# z# e# l# l# i# k# l# e# r# i# n#  # k# a# l# i# t# e#  # i# l# e#  # i# l# i# ş# k# i# l# e# r# i# n# i#  # y# o# r# u# m# l# a# m# a# k#  # i# ç# i# n#  # k# u# l# l# a# n# ı# l# a# b# i# l# e# c# e# k#  # g# r# a# f# i# k#  # t# ü# r# l# e# r# i#  # ş# ö# y# l# e# d# i# r# :# 
# K# e# m# a# n#  # G# r# a# f# i# ğ# i#  # (# V# i# o# l# i# n#  # P# l# o# t# )# 
# K# u# r# u#  # G# r# a# f# i# ğ# i#  # (# B# o# x#  # P# l# o# t# )# 
# N# o# k# t# a#  # G# r# a# f# i# ğ# i#  # (# P# o# i# n# t#  # P# l# o# t# )# 
# B# a# r#  # G# r# a# f# i# ğ# i#  # (# B# a# r#  # P# l# o# t# )

# In[None]

draw_multivarient_plot(dataset,4,3,"box")

# Y# u# k# a# r# ı# d# a#  # g# ö# s# t# e# r# i# l# e# n#  # d# a# ğ# ı# t# ı# m# l# a# r# ı# n#  # m# e# r# k# e# z# i# ,#  # b# o# x# p# l# o# t# t# a# k# i#  # "# k# u# t# u# "#  # d# u# r# .#  # K# u# t# u# n# u# n#  # ü# s# t#  # k# ı# s# m# ı#  # 7# 5# .#  # p# e# r# s# e# n# t# i# l# ,#  # a# l# t#  # i# s# e#  # 2# 5#  # p# e# r# s# e# n# t# i# l# d# i# r# .#  # D# i# ğ# e# r#  # b# i# r#  # d# e# y# i# ş# l# e# ,#  # v# e# r# i# l# e# r# i# n#  # y# a# r# ı# s# ı#  # k# u# t# u#  # i# ç# i# n# d# e#  # d# a# ğ# ı# t# ı# l# ı# r# !#  # O# r# t# a# d# a# k# i#  # y# e# ş# i# l#  # ç# i# z# g# i#  # o# r# t# a# n# c# a# d# ı# r# .# 
# 
# P# a# r# s# e# l# i# n#  # d# i# ğ# e# r#  # k# ı# s# m# ı# ,#  # "# b# ı# y# ı# k# "# ,#  # d# a# ğ# ı# t# ı# m#  # m# e# r# k# e# z# i# n# i# n#  # ö# t# e# s# i# n# d# e# k# i#  # n# o# k# t# a# l# a# r# ı# n#  # k# a# p# s# a# m# ı# n# ı#  # g# ö# s# t# e# r# i# r# .#  # B# u# n# u# n#  # ö# t# e# s# i# n# d# e#  # b# i# r# e# y# s# e# l#  # d# a# i# r# e# l# e# r#  # a# y# k# ı# r# ı#  # d# e# ğ# e# r# l# e# r# d# i# r# .# 
# 
# 
# B# o# x# l# o# t# '# l# a# r# ,#  # b# i# r# ç# o# k#  # v# e# r# i#  # k# ü# m# e# s# i# n# i# n#  # ş# e# k# l# i# n# i#  # ö# z# e# t# l# e# m# e# k#  # i# ç# i# n#  # h# a# r# i# k# a# d# ı# r# .#  # A# y# r# ı# c# a# ,#  # s# a# y# ı#  # b# a# k# ı# m# ı# n# d# a# n#  # b# i# r#  # s# ı# n# ı# r# ı#  # d# a#  # y# o# k# t# u# r# :#  # s# a# y# f# a#  # ü# z# e# r# i# n# d# e#  # r# a# h# a# t# ç# a#  # s# ı# k# ı# ş# m# a#  # y# a# p# t# ı# ğ# ı# n# ı# z#  # i# ç# i# n#  # a# l# a# n# a#  # ç# o# k#  # s# a# y# ı# d# a#  # k# u# t# u#  # y# e# r# l# e# ş# t# i# r# e# b# i# l# i# r# s# i# n# i# z# .# 
# 
# B# u# n# u# n# l# a#  # b# i# r# l# i# k# t# e# ,#  # s# a# d# e# c# e#  # ç# o# k#  # s# a# y# ı# d# a#  # o# l# a# s# ı#  # d# e# ğ# i# ş# k# e# n#  # i# l# e#  # a# r# a# l# ı# k#  # d# e# ğ# i# ş# k# e# n# l# e# r# i#  # v# e#  # n# o# m# i# n# a# l#  # d# e# ğ# i# ş# k# e# n# l# e# r#  # i# ç# i# n#  # ç# a# l# ı# ş# ı# r# l# a# r# ;#  # V# e# r# i# l# e# r# i# n# i# z# i# n#  # n# o# r# m# a# l#  # o# l# a# r# a# k#  # d# a# ğ# ı# l# m# ı# ş#  # o# l# d# u# ğ# u# n# u#  # v# a# r# s# a# y# a# r# l# a# r#  # (# a# k# s# i#  # t# a# k# d# i# r# d# e#  # t# a# s# a# r# ı# m# l# a# r# ı#  # ç# o# k#  # a# n# l# a# m# l# ı#  # d# e# ğ# i# l# d# i# r# )# ;#  # v# e#  # b# i# r# e# y# s# e# l#  # d# e# ğ# e# r# l# e# r#  # h# a# k# k# ı# n# d# a#  # h# e# r# h# a# n# g# i#  # b# i# r#  # b# i# l# g# i#  # t# a# ş# ı# m# a# z# l# a# r# ,#  # s# a# d# e# c# e#  # d# a# ğ# ı# t# ı# m# ı#  # b# i# r#  # b# ü# t# ü# n#  # o# l# a# r# a# k#  # e# l# e#  # a# l# ı# r# l# a# r# .# 
# 
# K# a# y# n# a# k# :# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# r# e# s# i# d# e# n# t# m# a# r# i# o# /# p# l# o# t# t# i# n# g# -# w# i# t# h# -# s# e# a# b# o# r# n

# In[None]

draw_multivarient_plot(dataset,4,3,"violin")

# B# i# r#  # k# e# m# a# n#  # p# l# o# t# u# ,#  # b# o# x# p# l# o# t# '# t# a# k# i#  # k# u# t# u# y# u# ,#  # v# e# r# i# l# e# r#  # i# ç# i# n#  # b# i# r#  # ç# e# k# i# r# d# e# k#  # y# o# ğ# u# n# l# u# k#  # t# a# h# m# i# n# i#  # i# l# e#  # a# k# ı# l# l# ı# c# a#  # d# e# ğ# i# ş# t# i# r# i# r# .#  # T# e# m# e# l# d# e#  # a# y# n# ı#  # v# e# r# i# l# e# r# i#  # g# ö# s# t# e# r# i# r# ,#  # a# n# c# a# k#  # y# a# n# l# ı# ş#  # y# o# r# u# m# l# a# m# a#  # y# a# p# m# a# y# ı#  # e# n# g# e# l# l# e# r# .#  # A# y# r# ı# c# a# ,#  # b# o# x# p# l# o# t# '# t# a# n#  # d# a# h# a#  # z# a# r# i# f# t# i# r# .# 
# 
# K# a# y# n# a# k# :# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# r# e# s# i# d# e# n# t# m# a# r# i# o# /# p# l# o# t# t# i# n# g# -# w# i# t# h# -# s# e# a# b# o# r# n

# In[None]

draw_multivarient_plot(dataset,4,3,"pointplot")

# B# i# r#  # n# o# k# t# a#  # g# r# a# f# i# ğ# i# (# p# o# i# n# t#  # p# l# o# t# )# ,#  # d# a# ğ# ı# l# ı# m#  # d# i# y# a# g# r# a# m# ı#  # n# o# k# t# a# l# a# r# ı# n# ı# n#  # k# o# n# u# m# u# y# l# a#  # s# a# y# ı# s# a# l#  # b# i# r#  # d# e# ğ# i# ş# k# e# n#  # i# ç# i# n#  # m# e# r# k# e# z# i#  # e# ğ# i# l# i# m# i# n#  # b# i# r#  # t# a# h# m# i# n# i# n# i#  # t# e# m# s# i# l#  # e# d# e# r#  # v# e#  # h# a# t# a#  # ç# u# b# u# k# l# a# r# ı#  # k# u# l# l# a# n# a# r# a# k#  # b# u#  # t# a# h# m# i# n# i# n#  # e# t# r# a# f# ı# n# d# a# k# i#  # b# e# l# i# r# s# i# z# l# i# ğ# i# n#  # b# i# r#  # m# i# k# t# a# r# ı# n# ı#  # g# ö# s# t# e# r# i# r# .# 
# 
# N# o# k# t# a#  # g# r# a# f# i# k# l# e# r# i# ,#  # b# i# r#  # v# e# y# a#  # d# a# h# a#  # f# a# z# l# a#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# i# ş# k# e# n# i# n#  # f# a# r# k# l# ı#  # s# e# v# i# y# e# l# e# r# i#  # a# r# a# s# ı# n# d# a# k# i#  # k# a# r# ş# ı# l# a# ş# t# ı# r# m# a# l# a# r# ı#  # o# d# a# k# l# a# m# a# k#  # i# ç# i# n#  # ç# u# b# u# k#  # ç# i# z# i# m# l# e# r# d# e# n# (# b# a# r#  # p# l# o# r# )#  # d# a# h# a#  # k# u# l# l# a# n# ı# ş# l# ı#  # o# l# a# b# i# l# i# r# .#  # B# u# n# l# a# r#  # e# t# k# i# l# e# ş# i# m# l# e# r# i#  # g# ö# s# t# e# r# m# e# d# e#  # ö# z# e# l# l# i# k# l# e#  # u# s# t# a# d# ı# r# :#  # B# i# r#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# i# ş# k# e# n# i# n#  # s# e# v# i# y# e# l# e# r# i#  # a# r# a# s# ı# n# d# a# k# i#  # i# l# i# ş# k# i# n# i# n#  # i# k# i# n# c# i#  # k# a# t# e# g# o# r# i# k#  # b# i# r#  # d# e# ğ# i# ş# k# e# n# i# n#  # s# e# v# i# y# e# l# e# r# i#  # a# r# a# s# ı# n# d# a#  # n# a# s# ı# l#  # d# e# ğ# i# ş# t# i# ğ# i# .#  # H# e# r#  # b# i# r#  # n# o# k# t# a# y# ı#  # a# y# n# ı#  # r# e# n# k#  # t# o# n# u# n# d# a# n#  # b# i# r# l# e# ş# t# i# r# e# n#  # ç# i# z# g# i# l# e# r# ,#  # f# a# r# k# l# ı#  # n# o# k# t# a#  # v# e# y# a#  # ç# u# b# u# k#  # g# r# u# p# l# a# r# ı# n# ı# n#  # y# ü# k# s# e# k# l# i# k# l# e# r# i# n# i#  # k# a# r# ş# ı# l# a# ş# t# ı# r# m# a# k# t# a# n#  # z# i# y# a# d# e# ,#  # g# ö# z# l# e# r#  # i# ç# i# n#  # d# a# h# a#  # k# o# l# a# y#  # o# l# a# n#  # e# ğ# i# m# d# e# k# i#  # f# a# r# k# l# ı# l# ı# k# l# a# r#  # t# a# r# a# f# ı# n# d# a# n#  # d# e# ğ# e# r# l# e# n# d# i# r# i# l# m# e# s# i# n# e#  # i# z# i# n#  # v# e# r# i# r# .# 
# 
# B# i# r#  # n# o# k# t# a#  # ç# i# z# i# m# i# n# i# n#  # s# a# d# e# c# e#  # o# r# t# a# l# a# m# a#  # (# y# a#  # d# a#  # d# i# ğ# e# r#  # t# a# h# m# i# n#  # e# d# i# c# i# )#  # d# e# ğ# e# r# i# n# i#  # g# ö# s# t# e# r# d# i# ğ# i# n# i# ,#  # a# n# c# a# k#  # ç# o# ğ# u#  # d# u# r# u# m# d# a#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# i# ş# k# e# n# l# e# r# i# n#  # h# e# r#  # d# ü# z# e# y# i# n# d# e# k# i#  # d# e# ğ# e# r# l# e# r# i# n#  # d# a# ğ# ı# l# ı# m# ı# n# ı#  # g# ö# s# t# e# r# m# e# k#  # i# ç# i# n#  # d# a# h# a#  # b# i# l# g# i# l# e# n# d# i# r# i# c# i#  # o# l# a# b# i# l# e# c# e# ğ# i# n# i#  # a# k# ı# l# d# a#  # t# u# t# m# a# k#  # ö# n# e# m# l# i# d# i# r# .#  # B# u#  # d# u# r# u# m# d# a# ,#  # b# i# r#  # k# u# t# u#  # v# e# y# a#  # k# e# m# a# n#  # g# r# a# f# i# k# l# e# r# i#  #  # g# i# b# i#  # d# i# ğ# e# r#  # y# a# k# l# a# ş# ı# m# l# a# r#  # d# a# h# a#  # u# y# g# u# n#  # o# l# a# b# i# l# i# r# .# 
# 
# K# a# y# n# a# k# :# h# t# t# p# s# :# /# /# s# e# a# b# o# r# n# .# p# y# d# a# t# a# .# o# r# g# /# g# e# n# e# r# a# t# e# d# /# s# e# a# b# o# r# n# .# p# o# i# n# t# p# l# o# t# .# h# t# m# l

# In[None]

draw_multivarient_plot(dataset,4,3,"bar")

# 
# *# *# B# a# r# p# l# o# t# *# *# 
# 
# D# i# k# d# ö# r# t# g# e# n#  # ç# u# b# u# k#  # g# r# a# f# i# ğ# i# ,#  # n# o# k# t# a#  # t# a# h# m# i# n# l# e# r# i#  # v# e#  # g# ü# v# e# n#  # a# r# a# l# ı# k# l# a# r# ı# n# ı#  # g# ö# s# t# e# r# e# n#  # b# i# r#  # g# r# a# f# i# k#  # t# ü# r# ü# d# ü# r# .# 
# 
# B# i# r#  # ç# u# b# u# k#  # g# r# a# f# i# ğ# i# ,#  # h# e# r#  # b# i# r#  # d# i# k# d# ö# r# t# g# e# n# i# n#  # y# ü# k# s# e# k# l# i# ğ# i#  # i# l# e#  # s# a# y# ı# s# a# l#  # b# i# r#  # d# e# ğ# i# ş# k# e# n#  # i# ç# i# n#  # b# i# r#  # m# e# r# k# e# z# i#  # e# ğ# i# l# i# m#  # t# a# h# m# i# n# i# n# i#  # t# e# m# s# i# l#  # e# d# e# r#  # v# e#  # h# a# t# a#  # ç# u# b# u# k# l# a# r# ı# n# ı#  # k# u# l# l# a# n# a# r# a# k#  # b# u#  # t# a# h# m# i# n# i# n#  # e# t# r# a# f# ı# n# d# a# k# i#  # b# e# l# i# r# s# i# z# l# i# ğ# i# n#  # b# i# r#  # m# i# k# t# a# r# ı# n# ı#  # g# ö# s# t# e# r# i# r# .#  # Ç# u# b# u# k#  # p# a# r# s# e# l# l# e# r#  # k# a# n# t# i# t# a# t# i# f#  # e# k# s# e# n#  # a# r# a# l# ı# ğ# ı# n# d# a#  # 0#  # i# ç# e# r# i# r#  # v# e#  # n# i# c# e# l# i# k# s# e# l#  # d# e# ğ# i# ş# k# e# n#  # i# ç# i# n#  # 0#  # a# n# l# a# m# l# ı#  # b# i# r#  # d# e# ğ# e# r#  # o# l# d# u# ğ# u# n# d# a#  # i# y# i#  # b# i# r#  # s# e# ç# i# m# d# i# r#  # v# e#  # o# n# a#  # k# a# r# ş# ı#  # k# a# r# ş# ı# l# a# ş# t# ı# r# m# a# l# a# r#  # y# a# p# m# a# k#  # i# s# t# e# r# s# i# n# i# z# .# 
# 
# 0# '# ı# n#  # a# n# l# a# m# l# ı#  # b# i# r#  # d# e# ğ# e# r#  # o# l# m# a# d# ı# ğ# ı#  # v# e# r# i#  # k# ü# m# e# l# e# r# i#  # i# ç# i# n# ,#  # b# i# r#  # n# o# k# t# a#  # g# r# a# f# i# ğ# i#  # b# i# r#  # v# e# y# a#  # d# a# h# a#  # f# a# z# l# a#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# i# ş# k# e# n# i# n#  # s# e# v# i# y# e# l# e# r# i#  # a# r# a# s# ı# n# d# a# k# i#  # f# a# r# k# l# a# r# a#  # o# d# a# k# l# a# n# m# a# n# ı# z# a#  # i# z# i# n#  # v# e# r# e# c# e# k# t# i# r# .# 
# 
# B# i# r#  # ç# u# b# u# k#  # ç# i# z# i# m# i# n# i# n#  # s# a# d# e# c# e#  # o# r# t# a# l# a# m# a#  # (# v# e# y# a#  # b# a# ş# k# a#  # b# i# r#  # t# a# h# m# i# n#  # e# d# i# c# i# )#  # d# e# ğ# e# r# i#  # o# l# d# u# ğ# u# n# u#  # a# k# ı# l# d# a#  # t# u# t# m# a# k#  # ö# n# e# m# l# i# d# i# r# ,#  # a# n# c# a# k#  # ç# o# ğ# u#  # d# u# r# u# m# d# a#  # k# a# t# e# g# o# r# i# k#  # d# e# ğ# i# ş# k# e# n# l# e# r# i# n#  # h# e# r#  # s# e# v# i# y# e# s# i# n# d# e#  # d# e# ğ# e# r#  # d# a# ğ# ı# l# ı# m# ı# n# ı#  # g# ö# s# t# e# r# m# e# k#  # d# a# h# a#  # b# i# l# g# i# l# e# n# d# i# r# i# c# i#  # o# l# a# b# i# l# i# r# .#  # B# u#  # d# u# r# u# m# d# a# ,#  # b# i# r#  # k# u# t# u#  # v# e# y# a#  # k# e# m# a# n#  # g# r# a# f# i# k# l# e# r# i#  #  # g# i# b# i#  # d# i# ğ# e# r#  # y# a# k# l# a# ş# ı# m# l# a# r#  # d# a# h# a#  # u# y# g# u# n#  # o# l# a# b# i# l# i# r# .# 
# 
# K# a# y# n# a# k# :#  # h# t# t# p# s# :# /# /# s# e# a# b# o# r# n# .# p# y# d# a# t# a# .# o# r# g# /# g# e# n# e# r# a# t# e# d# /# s# e# a# b# o# r# n# .# b# a# r# p# l# o# t# .# h# t# m# l# ## s# e# a# b# o# r# n# .# b# a# r# p# l# o# t

# In[None]


def get_models():
    models=[]
    models.append(("LR",LogisticRegression()))
    models.append(("NB",GaussianNB()))
    models.append(("KNN",KNeighborsClassifier()))
    models.append(("DT",DecisionTreeClassifier()))
    models.append(("SVM rbf",SVC()))
    models.append(("SVM linear",SVC(kernel='linear')))
    
    return models

def cross_validation_scores_for_various_ml_models(X_cv, y_cv):
    print("Çapraz Doğrulama Başarı Oranları".upper())
    models=get_models()


    results=[]
    names= []

    for name, model in models:
        kfold=KFold(n_splits=10,random_state=22)
        cv_result=cross_val_score(model,X_cv, y_cv, cv=kfold,scoring="accuracy")
        names.append(name)
        results.append(cv_result)
        print("{} modelinin çapraz doğrulaması yapıldı, başarı oranı:{:0.2f}".format(name, cv_result.mean()))

   

# In[None]

dataset_temp=dataset.copy(deep=True)
X=dataset.drop('quality', axis=1)
y=dataset['quality']

X=StandardScaler().fit_transform(X)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1377874.npy", { "accuracy_score": score })

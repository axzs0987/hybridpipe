import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy as sp
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
import warnings
import warnings
warnings.filterwarnings('ignore')
from IPython.display import HTML

# ##  # D# a# t# a#  # e# x# p# l# o# r# a# t# i# o# n

# ## ## ##  # I# m# p# o# r# t# i# n# g#  # d# a# t# a# s# e# t

# In[None]

df = pd.read_csv('../input/winequality-red.csv')

# In[None]

df.head()

# *#  # T# h# e# r# e#  # a# r# e#  # 1# 1#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# a# r# g# e# t

# In[None]

df.info()

# *#  # T# h# e# r# e#  # i# s#  # n# o#  # n# u# l# l#  # v# a# l# u# e# s

# In[None]

df.describe()

# *#  # T# h# e#  # f# e# a# t# u# r# e# s#  # a# r# e#  # n# o# t#  # i# n#  # t# h# e#  # s# a# m# e#  # m# a# g# n# i# t# u# d# e#  # o# r# d# e# r# .

# ## ##  # R# e# l# a# t# i# o# n# s# h# i# p#  # b# e# t# w# e# e# n#  # f# e# a# t# u# r# e# s

# In[None]

sns.pairplot(df, height=2.5);

# *#  # T# h# e# r# e#  # s# e# e# m#  # t# o#  # b# e#  # n# o# n# l# i# n# e# a# r#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # f# e# a# t# u# r# e# s# .

# In[None]

corr = df.corr()
plt.figure(figsize = (16,10))
sns.heatmap(corr,annot=True, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
plt.show()

# *#  # T# h# e# r# e#  # s# e# e# m#  # t# o#  # b# e#  # n# o#  # d# i# s# t# i# n# c# t#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # f# e# a# t# u# r# e# s# .

# ## ## ##  # S# p# l# i# t#  # t# o#  # f# e# a# t# u# r# e# s#  # a# n# d#  # t# a# r# g# e# t#  # (# X# ,#  # Y# )

# In[None]

X = df.iloc[:,:-1]
y = df.iloc[:,-1]

# ## ## ##  # D# i# s# t# r# i# b# u# t# i# o# n#  # o# f#  # t# a# r# g# e# t#  # v# a# l# u# e# s

# In[None]

plt.hist(y,bins=len(set(y)))
plt.title('Distribution of target values')
plt.xlabel('Classes')
plt.ylabel('count')
plt.show()

# *#  # T# h# e#  # d# i# v# i# s# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # c# l# a# s# s# e# s#  # i# s#  # n# o# t#  # b# a# l# a# n# c# e# d# ,# a# n# d#  # c# a# n#  # l# e# a# d#  # t# o#  # p# o# o# r#  # c# l# a# s# s# i# f# i# c# a# t# i# o# n#  # r# e# s# u# l# t# s# .

# In[None]

print(y.value_counts())

# ## ##  # S# p# l# i# t#  # d# a# t# a# s# e# t#  # t# o#  # t# r# a# i# n#  # a# n# d#  # t# e# s# t

# In[None]

random_state=10
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/4981237.npy", { "accuracy_score": score })

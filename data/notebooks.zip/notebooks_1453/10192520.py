import pandas as pd
# In[None]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# In[None]

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# In[None]

from sklearn.linear_model import LogisticRegression

# In[None]

dataset = pd.read_csv("/kaggle/input/weather-dataset-rattle-package/weatherAUS.csv")

# In[None]

dataset.head()

# In[None]

dataset.shape

# In[None]

dataset.dtypes

# In[None]

dataset.isnull().sum()

# In[None]

dataset["Location"].value_counts().plot(kind='bar', figsize=(10,10))

# In[None]

for col in dataset.columns:
    if (dataset[col].isnull().sum()) > 20000:
        print("'"+col+"',")

# In[None]

work_data = dataset.drop(['Evaporation','Sunshine','Cloud9am','Cloud3pm'], axis = 1)

# In[None]

work_data.shape

# In[None]

work_data.dtypes

# In[None]

work_data_object = work_data.select_dtypes(include="object")
work_data_number = work_data.select_dtypes(exclude="object")

# In[None]

print(work_data_object.shape)
print(work_data_number.shape)

# In[None]

for col in work_data_number.columns:
    mean = work_data_number[col].mean()
    work_data_number[col].fillna(mean, inplace = True)

# In[None]

for col in work_data_object.columns:
    mode = work_data_object[col].mode()[0]
    work_data_object[col].fillna(mode, inplace = True)

# In[None]

work_data_number.isnull().sum().plot()

# In[None]

work_data_object.isnull().sum()

# In[None]

label = LabelEncoder()
work_data_object = work_data_object.astype(str).apply(label.fit_transform)
# for col in work_data_object.columns:
#     work_data_object[col] = label.fit_transform(work_data_object[col].astype(str))

# In[None]

work_data_object.isnull().sum()

# In[None]

work_data = pd.concat([work_data_object, work_data_number], axis = 1)

# In[None]

work_data.shape

# In[None]

work_data.head()

# In[None]

work_data["WindGustDir"].unique()

# In[None]

corr_value = work_data.corr()["RainTomorrow"].values

# In[None]

for index, value in enumerate(corr_value):
    value = value * 100
    if(value > 20 or value < -20):
        print(index+1, value)
print("last index value :", index+1)

# In[None]

work_data.drop(work_data.columns[[1,2,3,4,5,7,8,9,12,13,18,19]], axis= 1, inplace = True)

# In[None]

X = work_data.drop(["RainTomorrow"], axis = 1)
Y = work_data[["RainTomorrow"]]

# In[None]

X.head()

# In[None]

Y.head()

# In[None]

Y.shape

# In[None]

from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(xtrain, ytrain)
y_pred = model.predict(xtest)
score = accuracy_score(ytest, y_pred)
import numpy as np
np.save("prenotebook_res/10192520.npy", { "accuracy_score": score })

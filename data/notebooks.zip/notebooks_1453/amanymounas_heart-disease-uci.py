import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
Heart_data =  pd.read_csv("/kaggle/input/heart-disease-uci/heart.csv")
Heart_data.head(10)
Heart_data.describe()
Heart_data.info()
Heart_data.shape
Heart_data.isnull().sum()
import seaborn as sns
import matplotlib.pyplot as plt
#plt.style.available
#plt.figure(figsize=(25,35))
#for i, col in enumerate(['trestbps', 'chol','thalach','oldpeak', 'trestbps', 'ca','thal', 'exang']):
#    plt.subplot(4,2,i+1)
#    sns.kdeplot(Heart_data[col],shade=True)
#plt.show()
#plt.style.use('ggplot')
#plt.figure(figsize=(14, 10))
#sns.heatmap(data=Heart_data.corr(), annot = True)
#plt.title('Heatmap for the Dataset', fontsize = 20)
#plt.show()
new_values={"sex":{1:"Male",0:"Female"},         "cp":{0:"typical angina",1: "non-anginal pain" ,2: "atypical angina" ,3: "asymptomatic"},         "fbs":{0:"<=120",1:">120"},         "exang":{0:"no",1:"yes"},         "restecg" :{0:"normal" ,1:"ST-T wave abnormality",2:"probable or definite left ventricular hypertrophy"},         "target" :{ 0:"No Heart Disease",1 : "heart-disease"},         "thal" :{ 1 : "fixed defect",0 : "normal",2 : "reversable defect",3:"NA"}
         
}
Heart_data_copy = Heart_data.copy()
Heart_data_copy.replace(new_values,inplace=True)
#sns.countplot(Heart_data_copy['target'])
Heart_data_copy.head()
#sns.countplot(Heart_data_copy['sex'])
#sns.catplot('target',col='sex',data=Heart_data_copy,kind='count')
pd.crosstab(Heart_data_copy.target, Heart_data_copy.sex)
#sns.catplot(x="target", y="age", hue="sex",data=Heart_data_copy, palette='rainbow', kind='box') 
#plt.figure(figsize=(20,7))
#sns.countplot("age", hue="target",data=Heart_data_copy, palette='rainbow') 
#plt.figure(figsize=(10,10))
#sns.countplot("target", hue='cp', data=Heart_data_copy, palette='rainbow')
#sns.lmplot(x='age',y='thalach', hue='target', data=Heart_data_copy)
#plt.title("Heart Disease in function of Age and Max Heart Rate")
#plt.figure(figsize=(15,7))
#sns.lineplot(x='age',y='thalach', hue='target', data=Heart_data_copy)
#sns.boxplot(x='target',y='thalach', data=Heart_data_copy, palette='rainbow')
#plt.figure(figsize=(12,10))
#sns.countplot("target", hue='restecg' , data=Heart_data_copy, palette='rainbow')
#sns.countplot("target", hue='thal' , data=Heart_data_copy, palette='rainbow')
#sns.catplot(x="target",y="trestbps",data=Heart_data_copy, palette='rainbow' ,kind='violin')
#plt.show()
#sns.catplot(x="target",y="chol",data=Heart_data_copy, palette='rainbow' ,kind='box')
#sns.countplot("target", hue='fbs' , data=Heart_data_copy, palette='rainbow')
#sns.countplot("target", hue='exang' , data=Heart_data_copy, palette='rainbow')
#sns.catplot(x="target",y="oldpeak",data=Heart_data_copy, palette='rainbow', kind="box")
from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler
scaler = MinMaxScaler()
MinMaxScaled = scaler.fit_transform(Heart_data)
#fig, ax = plt.subplots(1,2)
#sns.distplot(Heart_data, ax=ax[0])
#ax[0].set_title("Original Data")
#sns.distplot(MinMaxScaled, ax=ax[1])
#ax[1].set_title("MinMaxScaled data")
MinMaxScaled
scaler = RobustScaler()
RobustScaled = scaler.fit_transform(Heart_data)
#fig, ax = plt.subplots(1,2)
#sns.distplot(Heart_data, ax=ax[0])
#ax[0].set_title("Original Data")
#sns.distplot(RobustScaled, ax=ax[1])
#ax[1].set_title("RobustScaled data")
RobustScaled
scaler = StandardScaler()
StandardScaled = scaler.fit_transform(Heart_data)
#fig, ax = plt.subplots(1,2)
#sns.distplot(Heart_data, ax=ax[0])
#ax[0].set_title("Original Data")
#sns.distplot(StandardScaled, ax=ax[1])
#ax[1].set_title("StandardScaled data")
StandardScaled
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.model_selection import train_test_split
X = Heart_data.drop('target',axis=1)
y = Heart_data['target']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.10, random_state=42)
selector = SelectKBest(f_classif, k=5)
X_new = selector.fit_transform(X_train, y_train)
X_new
selected_features = pd.DataFrame(selector.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
selected_columns = selected_features.columns[selected_features.var() != 0.0]
X_test[selected_columns].head()
selector = SelectKBest(f_classif, k=9)
X_new = selector.fit_transform(X_train, y_train)
X_new
selected_features = pd.DataFrame(selector.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
selected_columns = selected_features.columns[selected_features.var() != 0.0]
X_test[selected_columns].head()
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectFromModel
X = Heart_data.drop('target',axis=1)
y = Heart_data['target']
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
#logistic = LogisticRegression(C=0.1, penalty="l1", solver='liblinear', random_state=7).fit(X, y)
#model = SelectFromModel(logistic, prefit=True)
#X_new = model.transform(X)
#X_new
#selected_features = pd.DataFrame(model.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
#selected_columns = selected_features.columns[selected_features.var() != 0]
#X_test[selected_columns].head()
#logistic = LogisticRegression(C=0.5, penalty="l1", solver='liblinear', random_state=7).fit(X, y)
#model = SelectFromModel(logistic, prefit=True)
#X_new = model.transform(X)
#selected_features = pd.DataFrame(model.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
#selected_columns = selected_features.columns[selected_features.var() != 0]
#X_test[selected_columns].head()
#logistic = LogisticRegression(C=0.1, penalty="l2", solver='liblinear', random_state=7).fit(X, y)
#model = SelectFromModel(logistic, prefit=True)
#X_new = model.transform(X)
#selected_features = pd.DataFrame(model.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
#selected_columns = selected_features.columns[selected_features.var() != 0]
#X_test[selected_columns].head()
#logistic = LogisticRegression(C=1, penalty="l2", solver='liblinear', random_state=7).fit(X, y)
#model = SelectFromModel(logistic, prefit=True)
#X_new = model.transform(X)
#selected_features = pd.DataFrame(model.inverse_transform(X_new),                                  columns=Heart_data.columns.drop('target'))
#selected_columns = selected_features.columns[selected_features.var() != 0]
#X_test[selected_columns].head()




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
print("start running model training........")
model = LogisticRegression(solver='liblinear', random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/amanymounas_heart-disease-uci.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/amanymounas_heart-disease-uci/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/amanymounas_heart-disease-uci/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/amanymounas_heart-disease-uci/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/amanymounas_heart-disease-uci/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/amanymounas_heart-disease-uci/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/amanymounas_heart-disease-uci/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/amanymounas_heart-disease-uci/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/amanymounas_heart-disease-uci/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/amanymounas_heart-disease-uci/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/amanymounas_heart-disease-uci/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/amanymounas_heart-disease-uci/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/amanymounas_heart-disease-uci/testY.csv",encoding="gbk")


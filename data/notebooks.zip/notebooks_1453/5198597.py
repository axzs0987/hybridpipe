import pandas as pd
# ##  # E# j# e# m# p# l# o#  # d# e#  # M# o# d# e# l# o# s#  # S# u# p# e# r# v# i# a# d# o# s

# L# o# s#  # d# a# t# o# s#  # f# u# e# r# o# n#  # d# e# s# c# a# r# g# a# d# o# s#  # d# e# :#  # h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# b# l# a# s# t# c# h# a# r# /# t# e# l# c# o# -# c# u# s# t# o# m# e# r# -# c# h# u# r# n

# ## ## ##  # I# m# p# o# r# t# a# m# o# s#  # l# a# s#  # l# i# b# r# e# r# í# a# s#  # n# e# c# e# s# a# r# i# a# s

# In[None]

# Importar las librerías necesarias
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split # Para separar Train y Test
from sklearn import metrics # Para medir la efectividad de los modelos
from sklearn.linear_model import LogisticRegression 
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier

import matplotlib.pyplot as plt 
from IPython.display import Image
import pydotplus # Si no lo tienen instalado: conda install -c conda-forge pydotplus

# ## ## ##  # I# m# p# o# r# t# a# m# o# s#  # l# o# s#  # d# a# t# o# s

# In[None]

data = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')

# In[None]

#Imputamos los nulos que figuran como "vacios"
data['TotalCharges'] = data['TotalCharges'].replace(' ',-1).astype(float)

# ## ## ##  # C# o# n# v# e# r# t# i# r# m# o# s#  # l# a# s#  # v# a# r# i# a# b# l# e# s#  # c# a# t# e# g# ó# r# i# c# a# s#  # a#  # D# u# m# m# i# e# s

# In[None]

# Seleccionamos las variables categóricas
cat_vars = ['gender', 'Partner', 'Dependents', 'PhoneService','MultipleLines', 'InternetService',
           'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport',
           'StreamingTV', 'StreamingMovies', 'Contract', 'PaperlessBilling',
           'PaymentMethod']

# In[None]

# Iteramos sobre cada variable creando su dummie         
for var in cat_vars:
    cat_list='var'+'_'+var
    cat_list = pd.get_dummies(data[var], prefix=var)
    data1=data.join(cat_list)
    data=data1

# In[None]

# Descartamos las variables originales
data = data.drop(cat_vars, axis = 1)

# In[None]

# El target también los convertimos en una variable numérica dummie
data['target'] = np.where(data.Churn == 'Yes',1,0)

# In[None]

# Eliminamos la variable Target y el ID de cliente que no arroja información (realmente no tiene información?)
data = data.drop(['Churn', 'customerID'], axis = 1)

# In[None]

data.head()

# ## ## ##  # S# e# p# a# r# a# m# o# s#  # l# a# s#  # b# a# s# e# s#  # e# n#  # E# n# t# r# e# n# a# m# i# e# n# t# o#  # y#  # T# e# s# t# e# o

# In[None]

# Separamos la base en las columnas Independientes y la Dependiente (X e Y)
X, y = data.drop(data.columns[-1], axis=1), data.iloc[:,-1]

# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5198597.npy", { "accuracy_score": score })

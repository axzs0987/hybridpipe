import pandas as pd
# ##  # S# U# P# P# O# R# T#  # V# E# C# T# O# R#  # M# A# C# H# I# N# E

# ## ##  # C# O# N# T# E# N# T# 
# <# b# r# ># 
# 
# 1# .#  # [# W# h# a# t#  # i# s#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e# (# S# V# M# )# ]# (# ## 1# )# 
# 1# .#  # [# S# V# M#  # P# a# r# a# m# e# t# e# r# s# ]# (# ## 2# )# 
# 1# .#  # [# I# m# p# o# r# t#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # R# e# a# d#  # D# a# t# a# ]# (# ## 3# )# 
# 1# .#  # [# V# i# s# u# a# l# i# z# e#  # D# a# t# a# ]# (# ## 4# )# 
# 1# .#  # [# C# r# e# a# t# e#  # a# n# d#  # E# v# a# l# u# a# t# e#  # M# o# d# e# l# ]# (# ## 5# )

# ## ##  # <# a#  # i# d# =# 1# ># <# /# a# ># W# h# a# t#  # i# s#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # (# S# V# M# )

# [# ]# (# h# t# t# p# :# /# /# )# S# V# M#  # o# r#  # S# u# p# p# o# r# t#  # V# e# c# t# o# r#  # M# a# c# h# i# n# e#  # a# l# g# o# r# i# t# h# m#  # t# r# i# e# s#  # t# o#  # d# r# a# w#  # a#  # h# y# p# e# r# p# l# a# n# e#  # b# e# t# w# e# e# n#  # t# w# o#  # c# l# a# s# s# e# s#  # t# o#  # s# e# p# e# r# a# t# e#  # t# h# e# m# .#  # T# h# e# r# e#  # c# a# n#  # b# e#  # m# a# n# y#  # h# y# p# e# r# p# l# a# n# e#  # b# u# t#  # S# V# M# '# s#  # p# u# r# p# o# s# e#  # i# s#  # f# i# n# d# i# n# g#  # m# a# x# i# m# u# m#  # m# a# r# g# i# n#  # o# r#  # f# i# n# d# i# n# g#  # m# a# x# i# m# u# m#  # d# i# s# t# a# n# c# e#  # b# e# t# w# e# e# n#  # d# a# t# a#  # p# o# i# n# t# s#  # f# r# o# m#  # e# a# c# h#  # c# l# a# s# s# e# s# .#  # T# h# i# s#  # d# a# t# a#  # p# o# i# n# t# s#  # a# r# e#  # n# e# a# r# e# s# t#  # d# a# t# a#  # p# o# i# n# t# s#  # t# o#  # h# y# p# e# r# l# a# n# e#  # f# r# o# m#  # e# a# c# h#  # c# l# a# s# s# e# s# .#  # L# e# t# '# s#  # l# o# o# k#  # i# m# a# g# e#  # b# e# l# o# w#  # i# t#  # e# x# p# l# a# i# n# s#  # b# e# t# t# e# r# .# 
# <# b# r# ># 
# <# i# m# g#  # s# r# c# =# "# h# t# t# p# s# :# /# /# l# h# 6# .# g# o# o# g# l# e# u# s# e# r# c# o# n# t# e# n# t# .# c# o# m# /# r# 0# d# B# 9# n# t# N# r# 6# F# W# O# O# L# f# 6# G# q# V# U# F# 7# 2# K# 4# i# B# V# _# o# R# 7# I# g# A# l# 3# R# O# 6# 1# W# p# D# n# I# p# g# k# w# N# h# m# j# x# j# t# M# w# N# I# N# -# 2# 3# M# M# l# J# A# n# T# F# e# 0# a# 2# Z# q# X# x# M# N# F# 0# W# u# r# s# G# w# V# 5# b# H# a# q# R# M# m# i# C# y# E# y# H# 2# 1# k# 4# e# 6# T# j# 5# D# F# B# r# 2# c# k# 4# D# M# g# S# -# F# k# N# z# 5# f# l# "#  # w# i# d# t# h# =# 4# 0# 0#  # /# >

# A# l# s# o#  # S# V# M#  # u# s# e# s#  # a#  # t# e# c# h# n# i# q# u# e#  # c# a# l# l# e# d#  # *# *# k# e# r# n# e# l#  # t# r# i# c# k# *# *#  # t# o#  # t# r# a# n# s# f# o# r# m#  # t# h# e#  # d# a# t# a# .#  # I# f#  # d# a# t# a# p# o# i# n# t# s#  # h# a# v# e#  # l# o# w#  # d# i# m# e# n# s# i# o# n# a# l#  # s# p# a# c# e#  # a# n# d#  # i# t#  # w# o# u# l# d# n# '# t#  # b# e#  # a# b# l# e#  # t# o#  # d# r# a# w#  # a#  # h# y# p# e# r# p# l# a# n# e#  # i# t#  # t# r# i# e# s#  # t# o#  # a# d# d#  # a#  # n# e# w#  # d# i# m# e# n# s# i# o# n#  # t# o#  # d# a# t# a# .# 
# <# b# r# ># 
# <# i# m# g#  # s# r# c# =# "# h# t# t# p# s# :# /# /# q# p# h# .# f# s# .# q# u# o# r# a# c# d# n# .# n# e# t# /# m# a# i# n# -# q# i# m# g# -# 8# a# 4# a# 3# 0# 4# 2# 1# 3# 4# 2# f# e# d# b# 9# b# d# d# a# 3# 8# f# b# d# 2# 5# 2# 9# a# 8# "#  # /# ># 
# N# o# w#  # I# '# l# l#  # e# x# p# l# a# i# n#  # s# o# m# e#  # p# a# r# a# m# e# t# e# r# s#  # i# n#  # S# V# M#  # a# n# d#  # w# e# '# l# l#  # t# r# y#  # t# o#  # u# s# e#  # S# V# M#  # t# o#  # c# l# a# s# s# i# f# y#  # v# o# i# c# e# s#  # a# c# c# o# r# d# i# n# g#  # t# o#  # f# e# a# t# u# r# e# s# .

# ## ##  # <# a#  # i# d# =# 2# ># <# /# a# ># S# V# M#  # -#  # P# a# r# a# m# e# t# e# r# s

# *# *# C#  # P# a# r# a# m# e# t# e# r# *# *# 
# <# b# r# ># 
# C#  # p# a# r# a# m# e# t# e# r#  # c# o# n# t# r# o# l# s#  # t# r# a# d# e# -# o# f# f#  # b# e# t# w# e# e# n#  # t# r# a# i# n# i# n# g#  # p# o# i# n# t# s# .# 
# -#  # S# m# a# l# l#  # C# :#  # L# a# r# g# e#  # m# a# r# g# i# n# 
# -#  # L# a# r# g# e#  # C# :#  # S# m# a# l# l#  # m# a# r# g# i# n# ,#  # i# t#  # h# a# s#  # p# o# t# e# n# t# i# a# l#  # t# o#  # o# v# e# r# f# i# t# .# 
# <# b# r# ># 
# I# f#  # y# o# u#  # a# s# k#  # w# h# i# c# h#  # i# s#  # b# e# t# t# e# r#  # t# o#  # u# s# e# ,#  # a# n# s# w# e# r#  # i# s#  # '# i# t#  # d# e# p# e# n# d# s#  # o# n#  # y# o# u# r#  # d# a# t# a# '# .#  # I# t#  # w# o# u# l# d#  # b# e#  # b# e# t# t# e# r#  # i# f#  # y# o# u#  # t# r# y#  # d# i# f# f# e# r# e# n# t#  # C#  # v# a# l# u# e# s#  # t# o#  # f# i# n# d#  # b# e# s# t#  # s# c# o# r# e# .# 
# <# b# r# ># 
# <# i# m# g#  # s# r# c# =# "# h# t# t# p# s# :# /# /# w# w# w# .# l# e# a# r# n# o# p# e# n# c# v# .# c# o# m# /# w# p# -# c# o# n# t# e# n# t# /# u# p# l# o# a# d# s# /# 2# 0# 1# 8# /# 0# 7# /# s# v# m# -# p# a# r# a# m# e# t# e# r# -# c# -# e# x# a# m# p# l# e# .# p# n# g# "#  # /# >

# *# *# K# e# r# n# e# l# *# *# 
# <# b# r# ># 
# Y# o# u#  # c# a# n#  # c# h# o# o# s# e#  # t# h# e#  # k# e# r# n# e# l#  # t# y# p# e#  # u# s# e# d#  # b# y#  # S# V# M# .#  # I# t#  # c# a# n#  # b# e#  # ‘# l# i# n# e# a# r# ’# ,#  # ‘# r# b# f# ’# ,#  # ‘# p# o# l# y# ’# ,#  # ‘# s# i# g# m# o# i# d# ’# ,#  # ‘# p# r# e# c# o# m# p# u# t# e# d# ’# .# 
# A# n# d#  # y# e# s# ,#  # a# n# s# w# e# r#  # i# s#  # s# t# i# l# l#  # s# a# m# e#  # '# i# t#  # d# e# p# e# n# d# s#  # y# o# u# r#  # d# a# t# a# '# .# 
# <# b# r# ># 
# <# i# m# g#  # s# r# c# =# "# h# t# t# p# :# /# /# d# a# t# a# a# s# p# i# r# a# n# t# .# c# o# m# /# w# p# -# c# o# n# t# e# n# t# /# u# p# l# o# a# d# s# /# 2# 0# 1# 7# /# 0# 1# /# I# r# i# s# _# P# e# t# a# l# _# S# v# m# .# p# n# g# "#  # /# >

# *# *# G# a# m# m# a#  # P# a# r# a# m# e# t# e# r# *# *# 
# <# b# r# ># 
# I# t#  # i# s#  # k# e# r# n# e# l#  # c# o# e# f# f# i# c# i# e# n# t# .#  # Y# o# u#  # u# s# e#  # i# t#  # i# f#  # y# o# u#  # c# h# o# o# s# e#  # '# r# b# f# '# ,#  # '# p# o# l# y# '#  # o# r#  # '# s# i# g# m# o# i# d# '#  # a# s#  # a#  # k# e# r# n# e# l# .

# A# l# s# o#  # t# h# e# r# e#  # i# s#  # '# d# e# g# r# e# e# '#  # p# a# r# a# m# e# t# e# r# s# .#  # I# t#  # i# s#  # u# s# e# d#  # f# o# r#  # '# p# o# l# y# '#  # k# e# r# n# e# l#  # t# o#  # d# e# f# i# n# e#  # d# e# g# r# e# e#  # o# f#  # p# o# l# y# n# o# m# i# a# l#  # k# e# r# n# e# l# .#  # I# t#  # i# s#  # 3#  # b# y#  # d# e# f# a# u# l# t# .

# ## ##  # <# a#  # i# d# =# 3# ># <# /# a# >#  # I# m# p# o# r# t#  # L# i# b# r# a# r# i# e# s#  # a# n# d#  # R# e# a# d#  # D# a# t# a

# In[None]

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import os
#print(os.listdir("../input"))


# In[None]

# Read Data
df = pd.read_csv("../input/voice.csv")

# In[None]

# First 5 Rows of Data
df.head()

# In[None]

df.columns

# In[None]

df.info()

# ## ##  # <# a#  # i# d# =# 4# ># <# /# a# ># V# i# s# u# a# l# i# z# e#  # D# a# t# a

# In[None]

sns.pairplot(df, hue='label', vars=['skew', 'kurt',
       'sp.ent', 'sfm', 'mode','meanfun',
       'meandom','dfrange'])
plt.show()

# In[None]

sns.countplot(df.label)
plt.show()

# In[None]

sns.scatterplot(x = 'skew', y = 'kurt', hue = 'label', data = df)
plt.show()

# In[None]

plt.figure(figsize=(20,10))
sns.heatmap(df.corr(), annot=True, linewidth=.5, fmt='.2f', linecolor = 'grey')
plt.show()

# ## ##  # <# a#  # i# d# =# 5# ># <# /# a# ># C# r# e# a# t# e#  # a# n# d#  # E# v# a# l# u# a# t# e#  # M# o# d# e# l

# In[None]

X = df.drop(['label'],axis=1)
y = df.label

# W# e# '# l# l#  # u# s# e#  # 7# 0# %#  # o# f#  # o# u# r#  # d# a# t# a#  # t# o#  # t# r# a# i# n#  # o# u# r#  # m# o# d# e# l#  # a# n# d#  # w# e# '# l# l#  # t# e# s# t#  # i# t#  # w# i# t# h#  # 3# 0# %#  # o# f#  # t# h# e#  # d# a# t# a# .

# In[None]

from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/2453703.npy", { "accuracy_score": score })

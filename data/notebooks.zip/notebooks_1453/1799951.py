import pandas as pd
# ##  # C# u# s# t# o# m# e# r#  # T# u# r# n# o# v# e# r#  # 
# I# n#  # t# h# e#  # c# u# s# t# o# m# e# r#  # m# a# n# a# g# e# m# e# n# t#  # l# i# f# e# c# y# c# l# e# ,#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n#  # r# e# f# e# r# s#  # t# o#  # a#  # d# e# c# i# s# i# o# n#  # m# a# d# e#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r#  # a# b# o# u# t#  # e# n# d# i# n# g#  # t# h# e#  # b# u# s# i# n# e# s# s#  # r# e# l# a# t# i# o# n# s# h# i# p# .#  # I# t#  # i# s#  # a# l# s# o#  # r# e# f# e# r# r# e# d#  # a# s#  # l# o# s# s#  # o# f#  # c# l# i# e# n# t# s#  # o# r#  # c# u# s# t# o# m# e# r# s# .# 
# 
# !# [# W# h# i# c# h#  # c# u# s# t# o# m# e# r# s#  # s# t# a# y#  # a# n# d#  # w# h# i# c# h#  # l# e# a# v# e# ?# ]# (# h# t# t# p# :# /# /# w# w# w# .# b# s# a# i# t# e# c# h# n# o# s# a# l# e# s# .# c# o# m# /# w# p# -# c# o# n# t# e# n# t# /# u# p# l# o# a# d# s# /# 2# 0# 1# 8# /# 0# 3# /# c# u# s# t# o# m# e# r# _# c# h# u# r# n# _# t# e# l# e# c# o# m# _# s# e# r# v# i# c# e# .# j# p# g# )# 
# 
# 
# G# D# P# R#  # c# a# m# e#  # i# n#  # e# f# f# e# c# t#  # f# r# o# m#  # M# a# y#  # 2# 5# t# h# ,#  # 2# 0# 1# 8#  # o# n# w# a# r# d# s#  # i# n#  # E# u# r# o# p# e# .#  # 
# 
# !# [# G# D# P# R# ]# (# h# t# t# p# s# :# /# /# z# d# n# e# t# 1# .# c# b# s# i# s# t# a# t# i# c# .# c# o# m# /# h# u# b# /# i# /# 2# 0# 1# 7# /# 1# 1# /# 1# 5# /# b# e# 5# d# 1# e# a# 8# -# 0# a# d# 7# -# 4# 5# e# 6# -# 8# 5# 8# 8# -# e# 2# c# 7# e# a# f# e# c# d# 7# 9# /# b# b# 9# 0# 2# 4# 0# 9# c# 2# 9# d# c# e# 9# 8# 4# f# 6# 0# a# e# 1# 6# 2# b# 6# 7# f# 4# 2# 0# /# i# s# t# o# c# k# -# g# d# p# r# -# c# o# n# c# e# p# t# -# i# m# a# g# e# .# j# p# g# )# 
# 
# O# n# e#  # o# f#  # t# h# e#  # f# u# n# d# a# m# e# n# t# a# l#  # i# s# s# u# e# s#  # a# d# d# r# e# s# s# e# d#  # i# n#  # G# D# P# R#  # i# s#  # w# h# e# t# h# e# r#  # t# h# e#  # d# a# t# a#  # h# o# l# d# e# r#  # h# a# s#  # a#  # l# e# g# i# t# i# m# a# t# e#  # r# e# a# s# o# n#  # f# o# r#  # h# o# l# d# i# n# g#  # t# h# e#  # d# a# t# a# .#  # T# e# l# e# c# o# m#  # c# o# m# p# a# n# i# e# s#  # s# h# o# u# l# d#  # o# n# l# y#  # u# s# e#  # a# s#  # m# u# c# h#  # d# a# t# a#  # a# s#  # i# s#  # r# e# q# u# i# r# e# d#  # t# o#  # g# e# t#  # a#  # t# a# s# k#  # d# o# n# e# .#  # D# a# t# a#  # m# i# n# i# m# i# s# a# t# i# o# n#  # i# f#  # r# e# f# e# r# r# e# d#  # i# n#  # f# i# v# e#  # s# e# p# a# r# a# t# e#  # c# h# a# p# t# e# r# s# .#  # T# h# e# r# e# f# o# r# e# ,#  # i# t#  # i# s#  # i# m# p# o# s# s# i# b# l# e#  # t# o#  # c# o# m# p# l# y#  # w# i# t# h#  # t# h# e#  # G# D# P# R#  # w# i# t# h# o# u# t#  # a# p# p# l# y# i# n# g#  # t# h# e#  # c# o# n# c# e# p# t# s# .# 
# 
# I#  # n# o# t# i# c# e# d#  # t# h# a# t#  # t# h# e#  # g# i# v# e# n#  # d# a# t# a#  # h# o# l# d# s#  # f# i# v# e#  # v# a# r# i# a# b# l# e# s#  # t# h# a# t#  # c# o# u# l# d#  # b# e#  # c# o# n# s# i# d# e# r# e# d#  # p# e# r# s# o# n# a# l# .#  # N# a# m# e# l# y#  # t# h# e#  # g# e# n# d# e# r# ,#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s# h# i# p#  # s# t# a# t# u# s# ,#  # p# a# r# t# n# e# r# ,#  # d# e# p# e# n# d# e# n# t# ,#  # a# n# d#  # t# e# n# u# r# e# .#  # E# s# p# e# c# i# a# l# l# y#  # t# h# e#  # g# e# n# d# e# r#  # a# n# d#  # w# h# e# t# h# e# r#  # t# h# e#  # c# u# s# t# o# m# e# r#  # h# a# s#  # a#  # p# a# r# t# n# e# r#  # o# r#  # a#  # d# e# p# e# n# d# e# n# t# ,#  # w# e# r# e#  # i# n# t# e# r# e# s# t# i# n# g#  # v# a# r# i# a# b# l# e# s# .#  # T# h# e# r# e#  # i# s#  # a# l# s# o#  # s# o# m# e#  # s# p# e# c# u# l# a# t# i# o# n#  # h# o# w#  # s# e# n# i# o# r#  # s# t# a# t# u# s#  # a# f# f# e# c# t# s#  # t# h# e#  # l# i# k# e# l# i# h# o# o# d#  # o# f#  # v# o# l# u# n# t# a# r# y#  # c# h# u# r# n# .#  # 
# 
# ## ## ##  # M# y#  # p# r# i# m# a# r# y#  # q# u# e# s# t# i# o# n#  # w# h# i# c# h#  # I#  # h# o# p# e#  # t# o#  # h# a# v# e#  # a# n#  # a# n# s# w# e# r#  # t# o#  # i# s#  # t# h# e#  # f# o# l# l# o# w# i# n# g# :#  # 
# 
# ## ## ## ##  # 1# )#  # T# o#  # w# h# a# t#  # d# e# g# r# e# e#  # d# o#  # p# e# r# s# o# n# a# l#  # d# e# t# a# i# l# s#  # o# f#  # g# e# n# d# e# r# ,#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# s# h# i# p#  # s# t# a# t# u# s# ,#  # e# x# i# s# t# e# n# c# e#  # o# f#  # a#  # p# a# r# t# n# e# r# ,#  # e# x# i# s# t# a# n# c# e#  # o# f#  # a#  # d# e# p# e# n# d# e# n# t# ,#  # a# n# d#  # t# e# n# u# r# e#  # a# f# f# e# c# t#  # t# h# e#  # m# o# d# e# l# '# s#  # p# r# e# d# i# c# t# i# v# e#  # p# o# w# e# r#  # o# f#  # p# r# e# d# i# c# t# i# n# g#  # c# h# u# r# n# ?# 
# 


# In[None]

# Libraries 
import pandas as pd
import numpy as np
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.metrics import f1_score
import matplotlib.pyplot as plt

#pd.set_option('display.max_columns', 70) # Since we're dealing with moderately sized dataframe,
#pd.set_option('display.max_rows', 13)# max 13 columns and rows will be shown

# In[None]

# Read
df = pd.read_csv(r"../input/WA_Fn-UseC_-Telco-Customer-Churn.csv")
df.head()


# C# r# e# d# i# t# s#  # f# o# r#  # d# a# t# a#  # p# r# e# p# r# o# c# e# s# s# i# n# g#  # g# o#  # t# o#  # P# a# v# a# n#  # R# a# j#  # a# n# d#  # h# i# s#  # [# K# e# r# n# e# l# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# k# a# g# g# l# e# .# c# o# m# /# p# a# v# a# n# r# a# j# 1# 5# 9# /# t# e# l# e# c# o# m# -# c# u# s# t# o# m# e# r# -# c# h# u# r# n# -# p# r# e# d# i# c# t# i# o# n# )

# In[None]

#Data Manipulation
#Replacing spaces with null values in total charges column
df['TotalCharges'] = df["TotalCharges"].replace(" ",np.nan)

#Dropping null values from total charges column which contain .15% missing data 
df = df[df["TotalCharges"].notnull()]
df = df.reset_index()[df.columns]

#convert to float type
df["TotalCharges"] = df["TotalCharges"].astype(float)

#replace 'No internet service' to No for the following columns
replace_cols = [ 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
                'TechSupport','StreamingTV', 'StreamingMovies']
for i in replace_cols : 
    df[i]  = df[i].replace({'No internet service' : 'No'})
    
#replace values
df["SeniorCitizen"] = df["SeniorCitizen"].replace({1:"Yes",0:"No"})

#Tenure to categorical column
def tenure_lab(df) :
    
    if df["tenure"] <= 12 :
        return "Tenure_0-12"
    elif (df["tenure"] > 12) & (df["tenure"] <= 24 ):
        return "Tenure_12-24"
    elif (df["tenure"] > 24) & (df["tenure"] <= 48) :
        return "Tenure_24-48"
    elif (df["tenure"] > 48) & (df["tenure"] <= 60) :
        return "Tenure_48-60"
    elif df["tenure"] > 60 :
        return "Tenure_gt_60"
df["tenure_group"] = df.apply(lambda df:tenure_lab(df),
                                      axis = 1)

#Separating churn and non churn customers
churn     = df[df["Churn"] == "Yes"]
not_churn = df[df["Churn"] == "No"]

#Separating catagorical and numerical columns
Id_col     = ['customerID']
target_col = ["Churn"]
cat_cols   = df.nunique()[df.nunique() < 6].keys().tolist()
cat_cols   = [x for x in cat_cols if x not in target_col]
num_cols   = [x for x in df.columns if x not in cat_cols + target_col + Id_col]

# In[None]

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

#customer id col
Id_col     = ['customerID']
#Target columns
target_col = ["Churn"]
#categorical columns
cat_cols   = df.nunique()[df.nunique() < 6].keys().tolist()
cat_cols   = [x for x in cat_cols if x not in target_col]
#numerical columns
num_cols   = [x for x in df.columns if x not in cat_cols + target_col + Id_col]
#Binary columns with 2 values
bin_cols   = df.nunique()[df.nunique() == 2].keys().tolist()
#Columns more than 2 values
multi_cols = [i for i in cat_cols if i not in bin_cols]

#Label encoding Binary columns
le = LabelEncoder()
for i in bin_cols :
    df[i] = le.fit_transform(df[i])
    
#Duplicating columns for multi value columns
df = pd.get_dummies(data = df,columns = multi_cols )

#Scaling Numerical columns
std = StandardScaler()
scaled = std.fit_transform(df[num_cols])
scaled = pd.DataFrame(scaled,columns=num_cols)

#dropping original values merging scaled values for numerical columns
df_df_og = df.copy()
df = df.drop(columns = num_cols,axis = 1)
df = df.merge(scaled,left_index=True,right_index=True,how = "left")

# In[None]

df.head()

# In[None]

df1= df[[
       'PhoneService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
       'TechSupport', 'StreamingTV', 'StreamingMovies', 'PaperlessBilling',
       'Churn', 'MultipleLines_No', 'MultipleLines_No phone service',
       'MultipleLines_Yes', 'InternetService_DSL',
       'InternetService_Fiber optic', 'InternetService_No',
       'Contract_Month-to-month', 'Contract_One year', 'Contract_Two year',
       'PaymentMethod_Bank transfer (automatic)',
       'PaymentMethod_Credit card (automatic)',
       'PaymentMethod_Electronic check', 'PaymentMethod_Mailed check',
       'tenure_group_Tenure_0-12', 'tenure_group_Tenure_12-24',
       'tenure_group_Tenure_24-48', 'tenure_group_Tenure_48-60',
       'tenure_group_Tenure_gt_60', 'tenure', 'MonthlyCharges',
       'TotalCharges']]
# df1 without personal details
df2= df[[ 'gender', 'SeniorCitizen', 'Partner', 'Dependents',
       'PhoneService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
       'TechSupport', 'StreamingTV', 'StreamingMovies', 'PaperlessBilling',
       'Churn', 'MultipleLines_No', 'MultipleLines_No phone service',
       'MultipleLines_Yes', 'InternetService_DSL',
       'InternetService_Fiber optic', 'InternetService_No',
       'Contract_Month-to-month', 'Contract_One year', 'Contract_Two year',
       'PaymentMethod_Bank transfer (automatic)',
       'PaymentMethod_Credit card (automatic)',
       'PaymentMethod_Electronic check', 'PaymentMethod_Mailed check',
       'tenure_group_Tenure_0-12', 'tenure_group_Tenure_12-24',
       'tenure_group_Tenure_24-48', 'tenure_group_Tenure_48-60',
       'tenure_group_Tenure_gt_60', 'tenure', 'MonthlyCharges',
       'TotalCharges']]
#df2 with everything

# In[None]

Y = df2.Churn.values
Y1 = df1.Churn.values
Y

# In[None]

cols = df2.shape[1]
X = df2.loc[:, df2.columns != 'Churn']
X1 = df1.loc[:, df1.columns != 'Churn']
X.columns;

# In[None]

Y.shape
Y1.shape

# In[None]

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import Perceptron
from sklearn.linear_model import SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

from sklearn.model_selection import train_test_split
X_train1, X_test1, Y_train1, Y_test1 = train_test_split(X1, Y1, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train1, Y_train1)
y_pred = model.predict(X_test1)
score = accuracy_score(Y_test1, y_pred)
import numpy as np
np.save("prenotebook_res/1799951.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, recall_score
from sklearn.metrics import accuracy_score, precision_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import Perceptron
from sklearn.svm import SVC

import warnings
warnings.filterwarnings('ignore')

# In[None]

data = pd.read_csv('../input/indian_liver_patient.csv')

# In[None]

data.head()

# In[None]

data.info()

# In[None]

data['Age'].plot(kind='hist')
plt.show()

# In[None]

data['Gender'].value_counts()

# In[None]

mean_albumin_and_globulin_ratio = data['Albumin_and_Globulin_Ratio'].mean()
data['Albumin_and_Globulin_Ratio'] = data['Albumin_and_Globulin_Ratio'].fillna(mean_albumin_and_globulin_ratio)

# In[None]

data['Gender'] = data['Gender'].astype('category')
data = pd.get_dummies(data)

# In[None]

corr_matrix = data.corr()
sns.heatmap(corr_matrix, annot=True, fmt=".1f", linewidths=.5);

# In[None]

# cols=['Albumin', 'Albumin_and_Globulin_Ratio', 'Gender_Female']
cols=['Albumin','Total_Bilirubin', 'Gender_Female']
# cols = data.columns[data.columns != 'Dataset']
from sklearn.model_selection import train_test_split
x_train, x_valid, y_train, y_valid = train_test_split(data[cols], data['Dataset'], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_valid)
score = accuracy_score(y_valid, y_pred)
import numpy as np
np.save("prenotebook_res/3147493.npy", { "accuracy_score": score })

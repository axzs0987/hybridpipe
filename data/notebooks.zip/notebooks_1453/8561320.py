import pandas as pd
# 
# ##  # C# u# s# t# o# m# e# r#  # A# t# t# r# i# t# i# o# n# 
# 
# C# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n# ,#  # a# l# s# o#  # k# n# o# w# n#  # a# s#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n# ,#  # c# u# s# t# o# m# e# r#  # t# u# r# n# o# v# e# r# ,#  # o# r#  # c# u# s# t# o# m# e# r#  # d# e# f# e# c# t# i# o# n# ,#  # i# s#  # t# h# e#  # l# o# s# s#  # o# f#  # c# l# i# e# n# t# s#  # o# r#  # c# u# s# t# o# m# e# r# s# .# 
# 
# T# e# l# e# p# h# o# n# e#  # s# e# r# v# i# c# e#  # c# o# m# p# a# n# i# e# s# ,#  # I# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r# s# ,#  # p# a# y#  # T# V#  # c# o# m# p# a# n# i# e# s# ,#  # i# n# s# u# r# a# n# c# e#  # f# i# r# m# s# ,#  # a# n# d#  # a# l# a# r# m#  # m# o# n# i# t# o# r# i# n# g#  # s# e# r# v# i# c# e# s# ,#  # o# f# t# e# n#  # u# s# e#  # c# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n#  # a# n# a# l# y# s# i# s#  # a# n# d#  # c# u# s# t# o# m# e# r#  # a# t# t# r# i# t# i# o# n#  # r# a# t# e# s#  # a# s#  # o# n# e#  # o# f#  # t# h# e# i# r#  # k# e# y#  # b# u# s# i# n# e# s# s#  # m# e# t# r# i# c# s#  # b# e# c# a# u# s# e#  # t# h# e#  # c# o# s# t#  # o# f#  # r# e# t# a# i# n# i# n# g#  # a# n#  # e# x# i# s# t# i# n# g#  # c# u# s# t# o# m# e# r#  # i# s#  # f# a# r#  # l# e# s# s#  # t# h# a# n#  # a# c# q# u# i# r# i# n# g#  # a#  # n# e# w#  # o# n# e# .#  # C# o# m# p# a# n# i# e# s#  # f# r# o# m#  # t# h# e# s# e#  # s# e# c# t# o# r# s#  # o# f# t# e# n#  # h# a# v# e#  # c# u# s# t# o# m# e# r#  # s# e# r# v# i# c# e#  # b# r# a# n# c# h# e# s#  # w# h# i# c# h#  # a# t# t# e# m# p# t#  # t# o#  # w# i# n#  # b# a# c# k#  # d# e# f# e# c# t# i# n# g#  # c# l# i# e# n# t# s# ,#  # b# e# c# a# u# s# e#  # r# e# c# o# v# e# r# e# d#  # l# o# n# g# -# t# e# r# m#  # c# u# s# t# o# m# e# r# s#  # c# a# n#  # b# e#  # w# o# r# t# h#  # m# u# c# h#  # m# o# r# e#  # t# o#  # a#  # c# o# m# p# a# n# y#  # t# h# a# n#  # n# e# w# l# y#  # r# e# c# r# u# i# t# e# d#  # c# l# i# e# n# t# s# .# 
# 
# C# o# m# p# a# n# i# e# s#  # u# s# u# a# l# l# y#  # m# a# k# e#  # a#  # d# i# s# t# i# n# c# t# i# o# n#  # b# e# t# w# e# e# n#  # v# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # a# n# d#  # i# n# v# o# l# u# n# t# a# r# y#  # c# h# u# r# n# .#  # V# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # a#  # d# e# c# i# s# i# o# n#  # b# y#  # t# h# e#  # c# u# s# t# o# m# e# r#  # t# o#  # s# w# i# t# c# h#  # t# o#  # a# n# o# t# h# e# r#  # c# o# m# p# a# n# y#  # o# r#  # s# e# r# v# i# c# e#  # p# r# o# v# i# d# e# r# ,#  # i# n# v# o# l# u# n# t# a# r# y#  # c# h# u# r# n#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # c# i# r# c# u# m# s# t# a# n# c# e# s#  # s# u# c# h#  # a# s#  # a#  # c# u# s# t# o# m# e# r# '# s#  # r# e# l# o# c# a# t# i# o# n#  # t# o#  # a#  # l# o# n# g# -# t# e# r# m#  # c# a# r# e#  # f# a# c# i# l# i# t# y# ,#  # d# e# a# t# h# ,#  # o# r#  # t# h# e#  # r# e# l# o# c# a# t# i# o# n#  # t# o#  # a#  # d# i# s# t# a# n# t#  # l# o# c# a# t# i# o# n# .#  # I# n#  # m# o# s# t#  # a# p# p# l# i# c# a# t# i# o# n# s# ,#  # i# n# v# o# l# u# n# t# a# r# y#  # r# e# a# s# o# n# s#  # f# o# r#  # c# h# u# r# n#  # a# r# e#  # e# x# c# l# u# d# e# d#  # f# r# o# m#  # t# h# e#  # a# n# a# l# y# t# i# c# a# l#  # m# o# d# e# l# s# .#  # A# n# a# l# y# s# t# s#  # t# e# n# d#  # t# o#  # c# o# n# c# e# n# t# r# a# t# e#  # o# n#  # v# o# l# u# n# t# a# r# y#  # c# h# u# r# n# ,#  # b# e# c# a# u# s# e#  # i# t#  # t# y# p# i# c# a# l# l# y#  # o# c# c# u# r# s#  # d# u# e#  # t# o#  # f# a# c# t# o# r# s#  # o# f#  # t# h# e#  # c# o# m# p# a# n# y# -# c# u# s# t# o# m# e# r#  # r# e# l# a# t# i# o# n# s# h# i# p#  # w# h# i# c# h#  # c# o# m# p# a# n# i# e# s#  # c# o# n# t# r# o# l# ,#  # s# u# c# h#  # a# s#  # h# o# w#  # b# i# l# l# i# n# g#  # i# n# t# e# r# a# c# t# i# o# n# s#  # a# r# e#  # h# a# n# d# l# e# d#  # o# r#  # h# o# w#  # a# f# t# e# r# -# s# a# l# e# s#  # h# e# l# p#  # i# s#  # p# r# o# v# i# d# e# d# .# 
# 
# p# r# e# d# i# c# t# i# v# e#  # a# n# a# l# y# t# i# c# s#  # u# s# e#  # c# h# u# r# n#  # p# r# e# d# i# c# t# i# o# n#  # m# o# d# e# l# s#  # t# h# a# t#  # p# r# e# d# i# c# t#  # c# u# s# t# o# m# e# r#  # c# h# u# r# n#  # b# y#  # a# s# s# e# s# s# i# n# g#  # t# h# e# i# r#  # p# r# o# p# e# n# s# i# t# y#  # o# f#  # r# i# s# k#  # t# o#  # c# h# u# r# n# .#  # S# i# n# c# e#  # t# h# e# s# e#  # m# o# d# e# l# s#  # g# e# n# e# r# a# t# e#  # a#  # s# m# a# l# l#  # p# r# i# o# r# i# t# i# z# e# d#  # l# i# s# t#  # o# f#  # p# o# t# e# n# t# i# a# l#  # d# e# f# e# c# t# o# r# s# ,#  # t# h# e# y#  # a# r# e#  # e# f# f# e# c# t# i# v# e#  # a# t#  # f# o# c# u# s# i# n# g#  # c# u# s# t# o# m# e# r#  # r# e# t# e# n# t# i# o# n#  # m# a# r# k# e# t# i# n# g#  # p# r# o# g# r# a# m# s#  # o# n#  # t# h# e#  # s# u# b# s# e# t#  # o# f#  # t# h# e#  # c# u# s# t# o# m# e# r#  # b# a# s# e#  # w# h# o#  # a# r# e#  # m# o# s# t#  # v# u# l# n# e# r# a# b# l# e#  # t# o#  # c# h# u# r# n# .# 


# ## ## ##  # I# m# p# o# r# t# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

# Library for DataFrame and Data manipulation
import pandas as pd
# Matrix operations and statistical functions
import numpy as np
# Plotting and dependency for seaborn
import matplotlib.pyplot as plt
# Graphs and chart used in this notebook
import seaborn as sns
# to convert categorical values into numerical value
from sklearn.preprocessing import LabelEncoder
# these imports are self explanatory
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

# ## ## ##  # U# n# d# e# r# s# t# a# n# d# i# n# g#  # t# h# e#  # d# a# t# a

# In[None]

# Reading Data from csv file
data = pd.read_csv('../input/telco-customer-churn/WA_Fn-UseC_-Telco-Customer-Churn.csv')


# In[None]

data.head()

# In[None]

# Describe some stats of numerical features apperantly there should be  numerical features
data.describe()

# In[None]

# Describe data type of the features , or the type of value they contain
data.info()

# In[None]

# There are some missing values in 'TotalCharges' but insted of representing it by 'NAN' it represents it by blank space
data[data['TotalCharges']==' ']

# ## ## ##  # D# a# t# a#  # M# a# n# i# p# u# l# a# t# i# o# n

# In[None]

# extracting index of rows where TotalCharges has a white space 
ws = data[data['TotalCharges']==' '].index
# removing all those rows whose index have been extracted just now
data.drop(ws,axis=0,inplace=True)
# converting 'TotalCharges' data type from object to float, because it contains real values
data['TotalCharges'] = data.TotalCharges.astype('float')

# In[None]

# standardization , all values will me subtracted by column's mean and divided by cloumn's standard deviation
def standardized(data,col):
    mean = data[col].mean()
    std = data[col].std()
    data[col] = (data[col]-mean)/std
    


# In[None]

# this function is to plot countplot, since majority of features are categorical, i would stick to countplot most of the time
def plot_comparison(col,val,some=None):
    sub_data = data[data[col]==val]
    value = sub_data[sub_data['Churn']=='Yes']
    print('In '+str(col)+' = '+str(val)+' , it is {:.2f} % likely that customer will leave'.format((len(value)/len(sub_data)*100)))
    sns.countplot(sub_data['Churn'],palette="bright",ax=some)

# ## ## ##  # D# a# t# a#  # V# i# s# u# a# l# i# z# a# t# i# o# n

# In[None]

data

# ##  # L# e# t# '# s#  # d# i# s# c# u# s# s#  # t# h# e#  # e# f# f# e# c# t#  # o# f#  # s# o# m# e#  # o# f#  # t# h# e#  # v# a# r# i# a# b# l# e# s# ,#  # t# h# a# t#  # m# a# y#  # h# e# l# p#  # i# n#  # c# h# u# r# n#  # p# r# e# d# i# c# t# i# o# n#  

# ## ##  # 0# .#  # C# h# u# r# n#  # 
# *# *# T# a# r# g# e# t#  # v# a# r# i# a# b# l# e#  # o# r#  # s# o# m# e# t# h# i# n# g#  # w# e#  # h# a# v# e#  # t# o#  # p# r# e# d# i# c# t#  # a# b# o# u# t#  # u# n# k# o# w# n#  # c# u# s# t# o# m# e# r# s# *# *

# In[None]

sns.countplot(data['Churn'])
print(len(data[data['Churn']=='Yes'])/len(data)*100)

# *# *# A# l# m# o# s# t#  # 2# 6# %#  # o# f#  # c# u# s# t# o# m# e# r# s#  # c# h# u# r# n#  # o# r#  # l# e# a# v# e#  # t# h# e#  # t# e# l# e# c# o# m# e#  # c# o# m# p# a# n# y#  # a# s#  # a#  # r# e# s# u# l# t#  # o# f#  # c# u# t# -# t# h# r# o# a# t#  # c# o# m# p# e# t# i# t# i# o# n# *# *

# ## ##  # 1# .#  # C# u# s# t# o# m# e# r# I# D# 
# *# *# T# h# i# s#  # v# a# r# i# a# b# l# e#  # d# o# e# s# n# '# t#  # g# i# v# e#  # a# n# y#  # e# x# t# r# a#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # t# h# e#  # c# u# s# t# o# m# e# r#  # o# r#  # a# b# o# u# t#  # c# h# u# r# n# i# n# g# ,#  # s# o#  # t# h# e#  # b# e# s# t#  # o# p# t# i# o# n#  # i# s#  # t# o#  # g# e# t#  # r# i# d#  # o# f# f#  # t# h# i# s#  # v# a# r# i# a# b# l# e# *# *

# In[None]

data = data.drop('customerID',axis=1)

# ## ##  # 2# .#  # G# e# n# d# e# r# 
# *# *# w# e#  # c# a# n#  # c# h# e# c# k#  # w# h# e# t# h# e# r#  # m# a# l# e# s#  # a# r# e#  # m# o# r# e#  # p# o# t# e# n# t# i# a# l#  # c# h# u# r# n# e# r#  # t# h# a# n#  # f# e# m# a# l# e# s# *# *

# In[None]


fig,ax1 = plt.subplots(figsize=(12,6))
sns.countplot(x='gender',data=data,hue='Churn')


# *# *# A# s#  # w# e#  # c# a# n#  # o# b# s# e# r# v# e#  # t# h# a# t#  # t# h# e#  # r# a# t# e#  # o# f#  # c# h# u# r# n#  # i# s#  # a# l# m# o# s# t#  # e# q# u# a# l#  # i# n#  # M# a# l# e#  # a# n# d#  # F# e# m# a# l# e#  # s# o#  # g# e# n# d# e# r#  # d# o# e# s# n# '# t#  # s# e# e# m# s#  # t# o#  # g# i# v# e#  # a# n# y#  # s# i# n# g# n# i# f# i# c# a# n# t#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# *# *

# ## ##  # 3# .#  # S# e# n# i# o# r# C# i# t# i# z# e# n# 
# *# *# a# .#  # H# o# w#  # m# a# n# y#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n#  # d# a# t# a# s# e# t#  # h# a# v# e# *# *

# In[None]

sns.countplot(data['SeniorCitizen'])

# *# *# b# .#  # A# m# o# n# g#  # S# e# n# i# o# r#  # a# n# d#  # n# o# n# -# s# e# n# i# o# r#  # c# i# t# e# z# e# n#  # w# h# o#  # i# s#  # c# h# u# r# n# i# n# g#  # m# o# r# e#  # f# r# e# q# u# e# n# t# l# y# *# *

# In[None]

plot_comparison('SeniorCitizen',1)

# In[None]

plot_comparison('SeniorCitizen',0)

# In[None]

# no. of non-senior citizen churning
data['SeniorCitizen'].value_counts()[0]*23/100

# In[None]

# no. of senior citizen churning
data['SeniorCitizen'].value_counts()[1]*45/100

# *# *# I# t#  # i# s#  # q# u# i# t# e#  # c# l# e# a# r#  # f# r# o# m#  # a# b# o# v# e#  # 2#  # c# o# u# n# t# p# l# o# t# s#  # t# h# a# t#  # S# e# n# i# o# r#  # c# i# t# z# e# n#  # a# r# e#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # c# o# m# p# a# n# y# ,# b# u# t#  # a#  # n# o# n#  # s# e# n# i# o# r#  # c# i# t# i# z# e# n# '# s#  # 2# 3# %#  # i# s#  # h# i# g# h# e# r#  # i# n#  # n# o# .# s# .# *# *

# ## ##  # 4# .#  # P# a# r# t# n# e# r# 
# *# *# P# i# e#  # p# l# o# t#  # i# s#  # t# o#  # d# e# s# c# r# i# b# e#  # o# v# e# r# a# l# l#  # c# o# u# n# t# *# *

# In[None]

fig,ax1 = plt.subplots(1,3,figsize=(12,4))
# A pie plot to show the share of Yes and No 
data['Partner'].value_counts().plot(kind='pie')
# first plot from right shows no. of Potential Churners among Partner = 'Yes' category 
plot_comparison('Partner','Yes',ax1[0])
# plot in middle shows no. of Potential Churners among Partner = 'No' category 
plot_comparison('Partner','No',ax1[1])

# *# *# S# i# n# c# e# ,#  # n# o# .#  # o# f#  # P# a# r# t# n# e# r# s#  # a# n# d#  # n# o# n# -#  # p# a# r# t# n# e# r# s#  # a# r# e#  # a# l# m# o# s# t#  # e# q# u# a# l# ,#  # W# e#  # c# a# n#  # c# o# n# c# l# u# d# e#  # t# h# a# t#  # N# o# n# -# p# a# r# t# n# e# r# s#  # a# r# e#  # m# o# r# e#  # f# r# e# q# u# e# n# t#  # c# h# u# r# n# e# r# s# *# *

# ## ##  # 5# .#  # D# e# p# e# n# d# e# n# t

# In[None]

fig,ax1 = plt.subplots(1,3,figsize=(12,4))
data['Dependents'].value_counts().plot(kind='pie')
plot_comparison('Dependents','Yes',ax1[0])
plot_comparison('Dependents','No',ax1[1])

# In[None]

# No. of Non-dependent churning
data['Dependents'].value_counts()[0]*31.28/100

# *# *# N# e# e# d#  # l# e# s# s#  # t# o#  # s# a# y#  # N# o# n# -# d# e# p# e# n# d# e# n# t#  # i# s#  # a#  # h# u# g# e#  # n# o# .#  # o# f#  # c# h# u# r# n# e# r# s# *# *

# In[None]

sns.catplot(hue='Partner',x='Dependents',col='Churn',kind="count",data=data)

# *# *# S# o# ,#  # f# a# r#  # N# o# n# -# d# e# p# e# n# d# e# n# t#  # n# o# n# -# p# a# r# t# n# e# r# s#  # a# r# e#  # d# a# n# g# e# r# o# u# s#  # c# a# t# e# g# o# r# y# *# *

# ## ##  # 6# .#  # t# e# n# u# r# e# 
# *# *# a# .#  # i# t#  # i# s#  # n# u# m# e# r# i# c# a# l#  # v# a# r# i# a# b# l# e#  # a# n# d#  # i# f#  # i#  # a# m#  # n# o# t#  # w# r# o# n# g#  # i# t#  # r# e# p# r# e# s# e# n# t# s# ,#  # n# o# .#  # o# f#  # y# e# a# r# s#  # a# n#  # i# n# d# i# v# i# d# u# a# l#  # u# s# i# n# g#  # c# o# m# p# a# n# y# '# s#  # s# e# r# v# i# c# e# *# *

# In[None]

#distribution plot
sns.distplot(data['tenure'],rug=False,hist=False)

# *# *# T# h# i# s#  # g# i# v# e# s#  # u# s#  # s# o# m# e#  # i# n# f# o#  # a# b# o# u# t#  # h# o# w#  # d# a# t# a#  # i# s#  # s# p# r# e# a# d# e# d# *# *

# In[None]

# to check mean,standard deviation,Qurtile and minimum maximum value in this feature 
data['tenure'].describe()

# In[None]

sns.boxplot(y=data['tenure'],x=data['Churn'])

# *# *# I# f#  # t# e# n# u# r# e#  # i# s#  # l# e# s# s#  # o# r#  # e# x# t# r# e# m# e# l# y#  # h# i# g# h#  # t# h# e#  # c# h# a# n# c# e# s#  # o# f#  # c# h# u# r# n# i# n# g#  # i# s#  # m# o# r# e#  # a# n# d#  # a# l# s# o# 
# A# s#  # y# o# u#  # c# a# n#  # s# e# e#  # i# n#  # t# h# e#  # a# b# o# v# e#  # b# o# x# p# l# o# t# ,#  # t# h# e# r# e#  # a# r# e#  # f# e# w#  # o# u# t# l# i# e# r# s#  # i# n#  # C# h# u# r# n#  # =#  # y# e# s#  # c# a# t# e# g# o# r# y# .# t# h# e# y#  # c# a# n#  # b# e#  # c# o# n# s# i# d# e# r# e# d#  # P# o# t# e# n# t# i# a# l#  # O# u# t# l# i# e# r# s# *# *#  

# In[None]

# all rows where Churn=='Yes'
churn = data[data['Churn']=='Yes'] 
# Finding first and third quartile
Q1,Q3 = churn['tenure'].quantile([.25,.75])
# Inter Quartile range
IQR = Q3-Q1
# all the values greater than Q3+1.5*IQR and less than Q1-1.5*IQR are considered outliers 
outliers = Q3+1.5*IQR
outliers

# In[None]

data['tenure'].max()

# *# *# O# u# t# l# i# e# r#  # i# s#  # t# u# r# n# e# d#  # o# u# t#  # t# o#  # b# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 6# 9# .# 5#  # b# u# t#  # t# e# n# u# r# e#  # h# a# s#  # m# a# x# i# m# u# m#  # v# a# l# u# e#  # a# s#  # 7# 2# .#  # I#  # g# u# e# s# s# ,#  # w# e#  # c# a# n#  # a# f# f# o# r# d#  # t# o#  # h# a# v# e#  # t# h# i# s#  # v# a# l# u# e#  # s# o#  # w# e# '# l# l#  #  # n# o# t#  # r# e# m# o# v# e#  # t# h# e# m# .# *# *

# In[None]

# A scatter plot between every Numerical variable in the dataset
sns.pairplot(data)

# *# *# T# h# e# r# e#  # a# r# e#  # 4#  # n# u# m# e# r# i# c# a# l#  # f# e# a# t# u# r# e# s# ,#  # w# h# e# r# e#  # S# e# n# i# o# r# C# i# t# i# z# e# n#  # w# i# l# l#  # b# e#  # c# o# n# s# i# d# e# r# e# d#  # a# s#  # C# a# t# e# g# o# r# i# c# a# l#  # f# e# a# t# u# r# e#  # b# e# c# u# a# s# e#  # i# t#  # c# o# n# s# i# s# t# s#  # o# f#  # 0#  # a# n# d#  # 1#  # o# n# l# y#  # w# h# i# c# h#  # r# e# p# r# e# s# e# n# t# s#  # '# N# o# '#  # a# n# d#  # '# Y# e# s# '#  # r# e# s# p# e# c# t# i# v# e# l# y# .# T# h# e# r# e#  # i# s#  # n# o# t#  # q# u# i# t# e#  # v# i# s# i# b# l# e#  # r# e# l# a# t# i# o# n#  # b# u# t#  # t# h# e# r# e#  # i# s#  # s# o# m# e#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # T# o# t# a# l# C# h# a# r# g# e# s#  # a# n# d#  # t# e# n# u# r# e#  # a# n# d#  # b# e# t# w# e# e# n#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s#  # a# n# d#  # T# o# t# a# l# C# h# a# r# g# e# s# .# *# *#  

# In[None]

data

# ## ##  # 7# .#  # P# h# o# n# e# S# e# r# v# i# c# e

# In[None]

fig,ax1 = plt.subplots(1,3,figsize=(12,4))
plot_comparison('PhoneService','Yes',ax1[1])
plot_comparison('PhoneService','No',ax1[2])
sns.countplot(data['PhoneService'],ax=ax1[0])

# *# *# H# o# w# e# v# e# r# ,#  # N# o# .#  # o# f#  # c# u# s# t# o# m# e# r# s#  # w# h# o#  # h# a# v# e#  # p# h# o# n# e#  # s# e# r# v# i# c# e#  # a# r# e#  # m# o# r# e# ,#  # t# h# i# s#  # f# a# c# t#  # d# o# e# s# n# '# t#  # s# e# e# m# s#  # t# o#  # h# e# l# p#  # e# i# t# h# e# r# *# *

# ## ##  # 8# .#  # M# u# l# t# i# p# l# e# L# i# n# e# s

# In[None]

data['MultipleLines'] = data['MultipleLines'].map(lambda x: 'Yes' if x=='Yes' else 'No')

fig,ax1 = plt.subplots(1,3,figsize=(12,4))
plot_comparison('MultipleLines','Yes',ax1[1])
plot_comparison('MultipleLines','No',ax1[2])

sns.countplot(data['MultipleLines'],ax=ax1[0])

# *# *# E# v# e# n#  # a# f# t# e# r#  # h# a# v# i# n# g#  # m# u# l# t# i# p# l# e#  # L# i# n# e# s#  # o# f#  # p# h# o# n# e# s# ,#  # p# e# o# p# l# e#  # q# u# i# t# i# n# g#  # m# o# r# e# .#  # s# i# n# c# e#  # d# i# f# f# e# r# e# n# c# e#  # b# e# t# w# e# e# n#  # t# w# o#  # c# l# a# s# s# e# s#  # i# s#  # l# e# s# s#  # w# e#  # w# o# n# '# t#  # c# o# n# s# i# d# e# r#  # t# h# i# s#  # f# e# a# t# u# r# e#  # f# o# r#  # m# o# d# e# l#  # b# u# i# l# d# i# n# g# *# *

# *# *# C# h# i#  # s# q# u# a# r# e#  # t# e# s# t#  # b# e# t# w# e# e# n#  # M# u# l# t# i# p# l# e# L# i# n# e# s#  # a# n# d#  # P# h# o# n# e# S# e# r# v# i# c# e# *# *

# In[None]

# Preparing Contingency table for Chi_square test 
yes = data[data['MultipleLines']=='Yes']
no = data[data['MultipleLines']=='No']
yyes = len(yes[yes['PhoneService']=='Yes'])
yno = len(yes[yes['PhoneService']=='No'])
nyes = len(no[no['PhoneService']=='Yes'])
nno = len(no[no['PhoneService']=='No'])
table = [[yyes,yno],[nyes,nno]]

# In[None]

# H0 : two features are dependent
# H1 : two features are Independent
from scipy.stats import chi2_contingency
from scipy.stats import chi2
# Observed Frequency table
print('Table :',table)

stat, p, dof, expected = chi2_contingency(table)
# (nrows-1)*(ncols-1) in our case (2-1)*(2-1) = 1
print('degree of Freedom=%d' % dof)
# Expeceted Frequency table
print("Expected :",expected)

prob = 0.95
# tabulated value of chi-square at 5% of significance 
critical = chi2.ppf(prob, dof)
print('probability=%.3f, critical=%.3f, stat=%.3f' % (prob, critical, stat))
if abs(stat) >= critical:
    print('Dependent (reject H0)')
else:
    print('Independent (fail to reject H0)')
# interpret p-value
alpha = 1.0 - prob
print('significance=%.3f, p=%.3f' % (alpha, p))
if p <= alpha:
    print('Dependent (reject H0)')
else:
    print('Independent (fail to reject H0)')

# *# *# W# e#  # k# n# o# w#  # C# h# i# -# S# q# u# a# r# e#  # i# s#  # n# o# t#  # v# a# l# i# d#  # b# e# c# u# a# s# e#  # e# v# e# r# y#  # e# n# t# e# r# y#  # i# n# t# o#  # c# o# n# t# i# n# g# e# n# c# y#  # t# a# b# l# e#  # m# u# s# t#  # b# e#  # g# r# e# a# t# e# r#  # t# h# a# n#  # 5#  # b# u# t#  # w# e#  # a# l# s# o#  # k# n# o# w#  # t# h# a# t#  # M# u# l# t# i# p# l# e# L# i# n# e# s#  # a# r# e#  # h# i# g# h# l# y#  # d# e# p# e# n# d# e# n# t#  # o# n#  # P# h# o# n# e# S# e# r# v# i# c# e# .# *# *

# ## ##  # 9# .#  # I# n# t# e# r# n# e# t# S# e# r# v# i# c# e

# In[None]

data['InternetService'].value_counts()

# In[None]

fig,ax1 = plt.subplots(2,2,figsize=(12,10))
sns.countplot(data['InternetService'],ax=ax1[0,0])
plot_comparison('InternetService','DSL',ax1[0,1])
plot_comparison('InternetService','Fiber optic',ax1[1,0])
plot_comparison('InternetService','No',ax1[1,1])

# *# *# D# S# L#  # i# s#  # a# n#  # o# u# t# d# a# t# e# d#  # t# e# c# h# n# o# l# o# g# y# ,#  # c# u# s# t# o# m# e# r#  # o# f#  # t# h# i# s#  # c# a# t# e# g# o# r# y#  # m# i# g# h# t#  # c# o# n# s# i# d# e# r#  # s# w# i# t# c# h# i# n# g#  # c# o# m# p# a# n# y#  # b# u# t#  # f# i# b# r# e#  # o# p# t# i# c#  # i# s#  # l# a# t# e# s# t#  # t# e# c# h# n# o# l# o# g# y#  # a# n# d#  # i# f#  # c# u# s# t# o# m# e# r#  # o# f#  # t# h# i# s#  # c# a# t# e# g# o# r# y#  # c# h# u# r# n# i# n# g#  # m# o# r# e#  # t# h# a# n#  # a# n# y# o# n# e#  # e# l# s# e#  # t# h# i# s#  # c# o# u# l# d#  # b# e#  # a# n#  # a# l# a# r# m# i# n# g#  # s# i# t# u# a# t# i# o# n#  # f# o# r#  # t# e# l# o# c# o# m# e#  # c# o# m# p# a# n# y# .# *# *

# In[None]

sns.catplot(hue='InternetService',x='PhoneService',col='Churn',kind="count",data=data)

# *# *# C# o# m# p# a# n# y# '# s#  # D# S# L#  # s# e# r# v# i# c# e#  # i# s#  # f# i# n# e#  # I# t# '# s#  # P# h# o# n# e#  # S# e# r# v# i# c# e#  # a# n# d#  # F# i# b# r# e#  # o# p# t# i# c#  # s# e# r# v# i# c# e#  # t# h# a# t#  # c# o# m# p# a# n# y#  # n# e# e# d# s#  # t# o#  # w# o# r# k#  # o# n# *# *# 


# ## ##  # 1# 0# .#  # O# n# l# i# n# e# S# e# c# u# r# i# t# y

# In[None]

fig,ax1 = plt.subplots(2,2,figsize=(12,10))
sns.countplot(data['OnlineSecurity'],ax=ax1[0,0])
plot_comparison('OnlineSecurity','Yes',ax1[0,1])
plot_comparison('OnlineSecurity','No',ax1[1,0])
plot_comparison('OnlineSecurity','No internet service',ax1[1,1])

# *# *# '# N# o#  # i# n# t# e# r# n# e# t#  # s# e# r# v# i# c# e# '#  # c# a# n#  # a# l# s# o#  # b# e#  # v# i# e# w# e# d#  # a# s#  # a#  # '# N# o# '#  # w# h# i# c# h#  # a# d# d# s#  # u# p# t# o#  # 4# 9# %#  # i# n#  # o# t# h# e# r#  # w# o# r# d# s#  # c# u# s# t# o# m# e# r# s#  # a# r# e#  # u# s# i# n# g#  # P# h# o# n# e#  # s# e# r# v# i# c# e# s#  # o# n# l# y# *# *

# ## ##  # 1# 1# .#  # O# n# l# i# n# e# B# a# c# k# u# p

# In[None]

fig,ax1 = plt.subplots(2,2,figsize=(12,10))
sns.countplot(data['OnlineBackup'],ax=ax1[0,0])
plot_comparison('OnlineBackup','Yes',ax1[0,1])
plot_comparison('OnlineBackup','No',ax1[1,0])
plot_comparison('OnlineBackup','No internet service',ax1[1,1])


# *# *# O# n# l# i# n# e#  # B# a# c# k# u# p#  # s# e# r# v# i# c# e#  # i# s#  # w# o# r# s# e#  # t# h# a# n#  # s# e# c# u# r# i# t# y#  # s# e# r# v# i# c# e# *# *

# ## ##  # 1# 2# .#  # D# e# v# i# c# e# P# r# o# t# e# c# t# i# o# n

# In[None]

fig,ax1 = plt.subplots(2,2,figsize=(12,10))
sns.countplot(data['DeviceProtection'],ax=ax1[0,0])
plot_comparison('DeviceProtection','Yes',ax1[0,1])
plot_comparison('DeviceProtection','No',ax1[1,0])
plot_comparison('DeviceProtection','No internet service',ax1[1,1])

# *# *# w# e#  # c# a# n#  # s# e# e#  # t# h# e#  # s# i# m# i# l# a# r#  # t# r# e# n# d#  # i# n#  # a# l# l#  # i# n# t# e# r# n# e# t#  # r# e# l# a# t# e# d#  # s# e# r# v# i# c# e# s# *# *

# ## ##  # 1# 3# .#  # C# o# n# t# r# a# c# t

# In[None]


fig,ax1 = plt.subplots(2,2,figsize=(12,10))
sns.countplot(data['Contract'],ax=ax1[0,0])
plot_comparison('Contract','Month-to-month',ax1[0,1])
plot_comparison('Contract','Two year',ax1[1,0])
plot_comparison('Contract','One year',ax1[1,1])

# *# *# N# o#  # n# e# e# d#  # t# o#  # w# o# r# r# y#  # a# b# o# u# t#  # 2#  # y# e# a# r# s#  # c# o# n# t# r# a# c# t# o# r# s# ,#  # t# h# e# y#  # a# r# e#  # g# o# i# n# g#  # t# o#  # s# t# a# y# ,#  # w# h# i# c# h#  # i# s#  # p# r# e# t# t# y#  # o# b# v# i# o# u# s# *# *#  #  

# ## ##  # 1# 4# .#  # P# a# p# e# r# l# e# s# s# B# i# l# l# i# n# g

# In[None]


fig,ax1 = plt.subplots(1,3,figsize=(12,4))
plot_comparison('PaperlessBilling','Yes',ax1[1])
plot_comparison('PaperlessBilling','No',ax1[2])

sns.countplot(data['PaperlessBilling'],ax=ax1[0])

# In[None]

fig,ax1 = plt.subplots(1,2,figsize=(12,5))
sns.boxplot(x='PaperlessBilling',y='MonthlyCharges',data=data,ax=ax1[0])
sns.boxplot(x='PaperlessBilling',y='TotalCharges',data=data,ax=ax1[1])

# *# *# I# t#  # m# a# y#  # b# e#  # j# u# s# t#  # a#  # c# o# i# n# c# i# d# e# n# c# e#  # b# u# t#  # t# h# o# s# e#  # w# h# o#  # a# r# e#  # o# p# t# i# n# g#  # P# a# p# e# r# l# e# s# s# B# i# l# l# i# n# g#  # t# h# e# i# r#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s#  # a# n# d#  # T# o# t# a# l# C# h# a# r# g# e# s#  # a# r# e#  # h# i# g# h# *# *

# ## ##  # 1# 5# .#  # P# a# y# m# e# n# t# M# e# t# h# o# d

# In[None]

f,ax = plt.subplots(figsize=(12,6))
sns.countplot(data['PaymentMethod'])

# In[None]


fig,ax1 = plt.subplots(2,2,figsize=(12,10))
plot_comparison('PaymentMethod','Electronic check',ax1[0,0])
plot_comparison('PaymentMethod','Mailed check',ax1[0,1])
plot_comparison('PaymentMethod','Bank transfer (automatic)',ax1[1,0])
plot_comparison('PaymentMethod','Credit card (automatic)',ax1[1,1])

# ## ##  # 1# 6# .#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s

# In[None]

sns.distplot(data['MonthlyCharges'])

# In[None]

sns.boxplot(data['MonthlyCharges'],data['Churn'])

# *# *# N# e# e# d# l# e# s# s#  # t# o#  # s# a# y#  # M# o# n# t# h# l# y# C# h# a# r# g# e# s#  # a# r# e#  # h# i# g# h#  # f# o# r#  # c# h# u# r# n# e# r# s# *# *

# In[None]

sns.distplot(data['TotalCharges'])

# In[None]

sns.boxplot(y=data['TotalCharges'],x=data['Churn'])

# *# *# S# u# r# p# r# i# s# i# n# g# l# y# ,#  # T# o# t# a# l#  # c# h# a# r# g# e# s#  # s# h# o# w# s#  # a#  # v# e# r# y#  # d# i# f# f# e# r# e# n# t#  # b# e# h# a# v# i# o# u# r#  # t# h# a# n#  # m# o# n# t# h# l# y#  # c# h# a# r# g# e# s#  # p# r# o# b# a# b# l# y#  # b# e# c# a# u# s# e#  # i# t#  # i# s#  # r# i# g# h# t#  # s# k# e# w# e# d# *# *

# ## ## ##  # C# o# n# c# l# u# s# i# o# n# :#  # 
# 
# 1# .#  # C# u# s# t# o# m# e# r# s#  # a# r# e#  # n# o# t#  # g# e# n# d# e# r#  # b# i# a# s# 
# 2# .#  # S# e# n# i# o# r#  # C# i# t# i# z# e# n# s# ,#  # n# o# n# -# p# a# r# t# n# e# r# ,#  # N# o# n# -# d# e# p# e# n# d# e# n# t#  # a# r# e#  # m# o# r# e#  # f# r# e# q# u# e# n# t#  # C# h# u# r# n# e# r# s# 
# 3# .#  # I# f#  # t# e# n# u# r# e#  # o# f#  # c# u# s# t# o# m# e# r#  # i# s#  # l# e# s# s#  # o# r#  # e# x# t# r# e# m# e# l# y#  # h# i# g# h# ,#  # c# h# a# n# c# e# s#  # o# f#  # t# h# e# i# r#  # o# p# t# i# n# g#  # o# u# t#  # a# r# e#  # h# i# g# e# r# 
# 4# .#  # P# h# o# n# e#  # S# e# r# v# i# c# e#  # a# n# d#  # h# a# v# i# n# g#  # M# u# l# t# i# p# l# e#  # l# i# n# e# s#  # h# a# s#  # n# o# t# h# i# n# g#  # t# o#  # d# o#  # w# i# t# h#  # C# h# u# r# n#  # p# r# e# d# i# c# t# i# o# n# (# a# c# o# r# d# i# n# g#  # t# o#  # d# a# t# a# )# 
# 5# .#  # O# n# l# i# n# e#  # B# a# c# k# u# p#  # s# e# r# v# i# c# e#  # i# s#  # w# o# r# s# e#  # t# h# a# n#  # O# n# l# i# n# e#  # s# e# c# u# r# i# t# y# 
# 6# .#  # L# o# n# g#  # t# e# r# m#  # c# o# n# t# r# a# c# t#  # c# a# n#  # h# e# l# p#  # r# e# t# a# i# n# i# n# g#  # c# u# s# t# o# m# e# r# s# 
# 7# .#  # t# h# o# s# e#  # w# h# o#  # a# r# e#  # o# p# t# i# n# g#  # p# a# p# e# r# l# e# s# s#  # B# i# l# l# i# n# g#  # t# h# e# y#  # m# i# g# h# t#  # h# a# v# e#  # h# a# v# i# n# g#  # s# o# m# e#  # p# r# o# b# l# e# m# 
# 8# .#  # p# a# y# m# e# n# t#  # m# e# t# h# o# d#  # =# =#  # E# l# e# c# t# r# o# n# i# c#  # c# h# e# c# k#  # h# a# s#  # h# i# g# h#  # r# a# t# e#  # o# f#  # c# h# u# r# n# e# r# s#  

# ## ## ##  # I# m# p# l# e# m# e# n# t#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # M# o# d# e# l# s

# In[None]

# don't want to alter original dataset
copy = data.copy(deep=True)

# In[None]

# label encoder to change categorical values into Numerical values
le = LabelEncoder()
for col in copy.columns:
    #if data type of column is object then and only apply label encoder
    if copy[col].dtypes =='object':
        copy[col] = le.fit_transform(copy[col])
        
# seperating Independent and dependent features
X = copy.drop('Churn',axis=1)
y = copy['Churn']

# In[None]

# to select k no. of best features from the available list of features 
from sklearn.feature_selection import SelectKBest
#using chi-square test
from sklearn.feature_selection import chi2

bestfeatures = SelectKBest(score_func=chi2, k=12)
fit = bestfeatures.fit(X,y)
dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(X.columns)

# In[None]

#concat two dataframes for better visualization 
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
featureScores.columns = ['Specs','Score']  #naming the dataframe columns

# In[None]

print(featureScores.nlargest(15,'Score'))  #print 10 best features

# In[None]

# will build model based on these 12 features becuase there chi-square is very high
features = ['TotalCharges','tenure','MonthlyCharges','Contract','OnlineSecurity','TechSupport','OnlineBackup','DeviceProtection',
           'SeniorCitizen','Dependents','PaperlessBilling','Partner']

# In[None]

# Standardization 
X = copy[features]
y = copy['Churn']
standardized(X,'tenure')
standardized(X,'TotalCharges')
standardized(X,'MonthlyCharges')


# In[None]



# In[None]

from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(X_train, Y_train)
y_pred = model.predict(X_test)
score = accuracy_score(Y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8561320.npy", { "accuracy_score": score })

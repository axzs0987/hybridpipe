import pandas as pd
# In[None]

#Importing libraries
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

# In[None]

# reading the csv file, del 2 columns from the file, checking first few rows of the file
data = pd.read_csv('../input/Social_Network_Ads.csv')
data.drop(columns=['User ID','Gender',],axis=1,inplace=True)
data.head()

# In[None]

#Declare label as last column in the source file
y = data.iloc[:,-1].values

# In[None]

#Declaring X as all columns excluding last
X = data.iloc[:,:-1].values

# In[None]

# Splitting data
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/1395715.npy", { "accuracy_score": score })

import pandas as pd
# In[67]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[68]

df = pd.read_csv("../input/WA_Fn-UseC_-HR-Employee-Attrition.csv")

# In[69]

df.head()

# In[70]

df.shape

# In[71]

df.Attrition.value_counts()

# In[72]

df["BusinessTravel"].value_counts()

# In[73]

df.columns

# In[74]

df.drop(columns=["Department","EducationField","Education","EmployeeCount","BusinessTravel",\
                 "HourlyRate","Over18","MonthlyIncome","OverTime","StockOptionLevel","StandardHours"], inplace = True)

# In[75]

plt.hist(df.Age)

# In[76]

df.head()

# In[77]

after_df = df.groupby(["Attrition","Gender","MaritalStatus"]).mean().reset_index().drop(columns = ["EmployeeNumber"])

# In[78]

after_df.sample(5)

# In[79]

sns.barplot(x="Attrition", y = "WorkLifeBalance", hue = "Gender", data = after_df)

# In[80]

def plotmatrix(start,end):
    fig, axs = plt.subplots(nrows = 2, ncols=2)
    i = 0
    cols = after_df.columns[start:end]
    fig.set_size_inches(14, 10)
    for indi in range(2):
        for indj in range(2):
                sns.barplot(x="Attrition",y=str(cols[i]),data = after_df,ax = axs[indi][indj],hue = "MaritalStatus")\
                .set_title("affect of "+str(cols[i]))
                print("column : "+str(cols[i]))
                i+=1

# In[81]

plotmatrix(3,7)

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # f# i# g# u# r# e# s# ,#  # w# e#  # c# a# n#  # c# o# n# c# l# u# d# e#  # t# h# a# t# ,#  # 
# 1# .#  # A# v# e# r# a# g# e#  # A# g# e#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 2# .#  # A# v# e# r# a# g# e#  # D# a# i# l# y#  # R# a# t# e#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 3# .#  # A# v# e# r# a# g# e#  # D# i# s# t# a# n# c# e#  # f# r# o# m#  # H# o# m# e#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # m# o# r# e#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 4# .#  # A# v# e# r# a# g# e#  # E# n# v# i# r# o# n# m# e# n# t#  # S# a# t# i# s# f# a# c# t# i# o# n#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s

# In[82]

plotmatrix(8,12)

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # f# i# g# u# r# e# s# ,#  # w# e#  # c# a# n#  # c# o# n# c# l# u# d# e#  # t# h# a# t# ,#  # 
# 1# .#  # A# v# e# r# a# g# e#  # J# o# b#  # L# e# v# e# l#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 2# .#  # A# v# e# r# a# g# e#  # J# o# b#  # S# a# t# i# s# f# a# c# t# i# o# n#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 3# .#  # s# e# e# m# s#  # l# i# k# e#  # M# o# n# t# h# l# y#  # r# a# t# e#  # d# o# e# s# n# '# t#  # a# f# f# e# c# t#  # m# u# c# h#  # f# o# r#  # t# h# e#  # a# t# t# r# i# t# i# o# n#  # r# a# t# e# 
# 4# .#  # A# v# e# r# a# g# e#  # N# o# .# o# f#  # C# o# m# p# a# n# i# e# s#  # w# o# r# k# e# d#  # b# y#  # t# h# e#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # m# o# r# e#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s

# In[83]

plotmatrix(13,17)

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # f# i# g# u# r# e# s# ,#  # w# e#  # c# a# n#  # c# o# n# c# l# u# d# e#  # t# h# a# t# ,#  # 
# 1# .#  # S# e# e# m# s#  # l# i# k# e#  # o# n# l# y#  # T# o# t# a# l#  # W# o# r# k# i# n# g#  # Y# e# a# r# s#  # i# s#  # a# f# f# e# c# t# i# n# g#  # t# h# e#  # a# t# t# r# i# t# i# o# n#  # r# a# t# e# .

# In[84]

plotmatrix(18,22)

# F# r# o# m#  # t# h# e#  # a# b# o# v# e#  # f# i# g# u# r# e# s# ,#  # w# e#  # c# a# n#  # c# o# n# c# l# u# d# e#  # t# h# a# t# ,#  # 
# 1# .#  # A# v# e# r# a# g# e#  # y# e# a# r# s#  # a# t#  # I# B# M#  # o# f#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 2# .#  # A# v# e# r# a# g# e#  # y# e# a# r# s#  # i# n#  # c# u# r# r# e# n# t#  # R# o# l# e#  # a# t#  # I# B# M#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 3# .#  # A# v# e# r# a# g# e#  # y# e# a# r# s#  # s# i# n# c# e#  # L# a# s# t# P# r# o# m# o# t# i# o# n#  # a# t#  # I# B# M#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s# .# 
# 4# .#  # A# v# e# r# a# g# e#  # y# e# a# r# s#  # w# i# t# h#  # C# u# r# r# e# n# t#  # M# a# n# a# g# e# r#  # a# t#  # I# B# M#  # o# f#  # e# m# p# l# o# y# e# e# s#  # t# h# o# s# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # I# B# M#  # i# s#  # l# e# s# s#  # c# o# m# p# a# r# e# d#  # t# o#  # o# t# h# e# r# s

# (# w# e#  # h# a# v# e#  # t# o#  # b# u# i# l# d#  # t# h# e#  # m# o# d# e# l#  # b# a# s# e# d#  # o# n#  # t# h# e#  # s# e# l# e# c# t# e# d#  # f# e# a# t# u# r# e# s#  # f# r# o# m#  # t# h# e#  # a# b# o# v# e#  # a# n# a# l# y# s# i# s# )# (# u# n# d# e# r#  # e# d# i# t# i# n# g# *# )

# In[85]

df["Gender"] = df.Gender.map({"Female" : 0, "Male" : 1})
df["MaritalStatus"] = df.MaritalStatus.map({"Divorced":0,"Married":1,"Single":2})

# In[86]

final_df = df[after_df.drop(columns=["MonthlyRate","PerformanceRating"]).columns]
final_df.head()
final_X = final_df.drop(columns=["Attrition"])
final_Y = final_df["Attrition"]



# In[96]

from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(final_X, final_Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/3987430.npy", { "accuracy_score": score })

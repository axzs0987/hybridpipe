import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input/'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
fake_news = pd.read_csv("/kaggle/input/fake-news-detection/data.csv")
fake_news.head()
fake_news=  fake_news.drop(['URLs'], axis=1)
fake_news = fake_news.dropna()
fake_news.head()
fake_news=fake_news[0:3500]
X = fake_news.iloc[:,:-1].values
y = fake_news.iloc[:,-1].values
X[0]
y[0]
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(max_features=5000)
News_body = cv.fit_transform(X[:,1]).todense()
News_body
cv_head = CountVectorizer(max_features=5000)
News_head = cv_head.fit_transform(X[:,0]).todense()
News_head
X_mat = np.hstack(( News_head, News_body))
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_mat, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.tree import DecisionTreeClassifier
dtc = DecisionTreeClassifier(criterion='entropy')
#dtc.fit(X_train, y_train)
#y_pred=dtc.predict(X_test)
from sklearn.metrics import confusion_matrix
#confusion_matrix(y_test, y_pred)
Accuracy =(98+87)/(98+87+8+7)
Accuracy



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
print("start running model training........")
model = DecisionTreeClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ajaynthakur_fake-news-detection-decisiontreeclassifier.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ajaynthakur_fake-news-detection-decisiontreeclassifier/testY.csv",encoding="gbk")


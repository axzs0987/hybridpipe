import pandas as pd
# T# h# i# s#  # p# r# o# j# e# c# t#  # i# s#  # s# t# i# l# l#  # i# n#  # d# e# v# e# l# o# p# m# e# n# t# .#  # N# e# w#  # a# d# d# i# t# i# o# n# s#  # w# i# l# l#  # b# e#  # a# d# d# e# d#  # s# e# q# u# e# n# t# i# a# l# l# y# .

# >#  # ## ##  # I# n# t# r# o# d# u# c# t# i# o# n# 


# -# A#  # G# e# n# e# r# i# c#  # M# a# c# h# i# n# e#  # L# e# a# r# n# i# n# g#  # R# e# s# e# a# r# c# h#  # O# n#  # S# t# a# r#  # C# r# a# f# t#  # I# I# .# 
# -# A# t#  # t# h# e#  # e# n# d#  # o# f#  # t# h# e#  # r# e# s# e# a# r# c# h# ,#  # e# x# p# e# c# t# e# d#  # o# u# t# c# o# m# e#  # w# i# l# l#  # b# e#  # a#  # c# o# n# c# l# u# s# i# o# n#  # o# f#  # d# i# f# f# e# r# e# n# t#  # a# p# p# r# o# a# c# h# e# s#  # i# n#  # l# e# a# g# u# e#  # p# r# e# d# i# c# t# i# o# n# .

# ## ##  # R# e# q# u# i# r# e# d#  # P# a# c# k# a# g# e# s# 


# In[None]

import numpy as np
import pandas as pd
##################################################
###################Classsifiers###################
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
###################################################
################Processing and EDA#################
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, precision_score, recall_score,f1_score, average_precision_score
import matplotlib.pyplot as plt
import seaborn as sns
##################################################
##############Disable Warnings####################
import warnings  
warnings.filterwarnings('ignore')
##################################################
import os

# *# *# B# r# i# e# f#  # i# n# f# o# r# m# a# t# i# o# n#  # a# b# o# u# t#  # c# o# l# u# m# n# s#  # f# o# r#  # m# a# k# i# n# g#  # e# a# s# y#  # t# o#  # w# o# r# k#  # w# i# t# h# *# *# 


# G# a# m# e# I# D# :#  # U# n# i# q# u# e#  # I# D#  # f# o# r#  # e# a# c# h#  # g# a# m# e# 
# 
# L# e# a# g# u# e# I# n# d# e# x# :#  # 1# -# 8#  # f# o# r#  # B# r# o# n# z# e# ,#  # S# i# l# v# e# r# ,#  # G# o# l# d# ,#  # D# i# a# m# o# n# d# ,#  # M# a# s# t# e# r# ,#  # G# r# a# n# d# M# a# s# t# e# r# ,#  # P# r# o# f# e# s# s# i# o# n# a# l#  # l# e# a# g# u# e# s# 
# 
# A# g# e# :#  # A# g# e#  # o# f#  # e# a# c# h#  # p# l# a# y# e# r# 
# 
# H# o# u# r# s# P# e# r# W# e# e# k# :#  # H# o# u# r# s#  # s# p# e# n# t#  # p# l# a# y# i# n# g#  # p# e# r#  # w# e# e# k# 
# 
# T# o# t# a# l# H# o# u# r# s# :#  # T# o# t# a# l#  # h# o# u# r# s#  # s# p# e# n# t#  # p# l# a# y# i# n# g# 
# 
# A# P# M# :#  # A# c# t# i# o# n#  # p# e# r#  # m# i# n# u# t# e# 
# 
# S# e# l# e# c# t# B# y# H# o# t# k# e# y# s# :#  # N# u# m# b# e# r#  # o# f#  # u# n# i# t#  # s# e# l# e# c# t# i# o# n# s#  # m# a# d# e#  # u# s# i# n# g#  # h# o# t# k# e# y# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# A# s# s# i# g# n# T# o# H# o# t# k# e# y# s# :#  # N# u# m# b# e# r#  # o# f#  # u# n# i# t# s#  # a# s# s# i# g# n# e# d#  # t# o#  # h# o# t# k# e# y# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# U# n# i# q# u# e# H# o# t# k# e# y# s# :#  # N# u# m# b# e# r#  # o# f#  # u# n# i# q# u# e#  # h# o# t# k# e# y# s#  # u# s# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# M# i# n# i# m# a# p# A# t# t# a# c# k# s# :#  # N# u# m# b# e# r#  # o# f#  # a# t# t# a# c# k#  # a# c# t# i# o# n# s#  # o# n#  # m# i# n# i# m# a# l#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# M# i# n# i# m# a# p# R# i# g# h# t# C# l# i# c# k# s# :#  # N# u# m# b# e# r#  # o# f#  # r# i# g# h# t# -# c# l# i# c# k# s#  # o# n#  # m# i# n# i# m# a# l#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# N# u# m# b# e# r# O# f# P# A# C# s# :#  # N# u# m# b# e# r#  # o# f#  # P# A# C# s#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# G# a# p# B# e# t# w# e# e# n# P# A# C# s# :#  # M# e# a# n#  # d# u# r# a# t# i# o# n#  # b# e# t# w# e# e# n#  # P# A# C# s#  # (# m# i# l# l# i# s# e# c# o# n# d# s# )# 
# 
# A# c# t# i# o# n# L# a# t# e# n# c# y# :#  # M# e# a# n#  # l# a# t# e# n# c# y#  # f# r# o# m#  # t# h# e#  # o# n# s# e# t#  # o# f#  # P# A# C# s#  # t# o#  # t# h# e# i# r#  # f# i# r# s# t#  # a# c# t# i# o# n#  # (# m# i# l# l# i# s# e# c# o# n# d# s# )# 
# 
# A# c# t# i# o# n# s# I# n# P# A# C# :#  # M# e# a# n#  # n# u# m# b# e# r#  # o# f#  # a# c# t# i# o# n# s#  # w# i# t# h# i# n#  # e# a# c# h#  # P# A# C# 
# 
# T# o# t# a# l# M# a# p# E# x# p# l# o# r# e# d# :#  # N# u# m# b# e# r#  # o# f#  # 2# 4# x# 2# 4#  # g# a# m# e#  # c# o# o# r# d# i# n# a# t# e#  # g# r# i# d# s#  # v# i# e# w# e# d#  # b# y#  # p# l# a# y# e# r#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# W# o# r# k# e# r# s# M# a# d# e# :#  # N# u# m# b# e# r#  # o# f#  # S# C# V# s# ,#  # d# r# o# n# e# s# ,#  # p# r# o# b# e# s#  # t# r# a# i# n# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# U# n# i# q# u# e# U# n# i# t# s# M# a# d# e# :#  # U# n# i# q# u# e#  # u# n# i# t# s#  # m# a# d# e#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# C# o# m# p# l# e# x# U# n# i# t# s# M# a# d# e# :#  # N# u# m# b# e# r#  # o# f#  # g# h# o# s# t# s# ,#  # i# n# v# e# s# t# o# r# s# ,#  # a# n# d#  # h# i# g# h#  # t# e# m# p# l# a# r# s#  # t# r# a# i# n# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# C# o# m# p# l# e# x# A# b# i# l# i# t# y# U# s# e# d# :#  # A# b# i# l# i# t# i# e# s#  # r# e# q# u# i# r# i# n# g#  # s# p# e# c# i# f# i# c#  # t# a# r# g# e# t# i# n# g#  # i# n# s# t# r# u# c# t# i# o# n# s#  # u# s# e# d#  # p# e# r#  # t# i# m# e# s# t# a# m# p# 
# 
# M# a# x# T# i# m# e# S# t# a# m# p# :#  # T# i# m# e#  # s# t# a# m# p#  # o# f#  # g# a# m# e# '# s#  # l# a# s# t#  # r# e# c# o# r# d# e# d#  # e# v# e# n# t

# In[None]

#Total playing time is not chosen due to a player can give a long break to 
#his/her playing career, then they can start playing again
relatedColumnsList=["LeagueIndex","Age","HoursPerWeek","APM","SelectByHotkeys",
                    "AssignToHotkeys","UniqueHotkeys",
                    "MinimapAttacks","MinimapRightClicks","NumberOfPACs",
                    "GapBetweenPACs","ActionLatency",
                    "ActionsInPAC","TotalMapExplored","WorkersMade","UniqueUnitsMade",
                    "ComplexUnitsMade","ComplexAbilityUsed","MaxTimeStamp"]
df=pd.read_csv('../input/starcraft.csv')
df = df[relatedColumnsList]
df.dropna()
df = df[df['LeagueIndex']!=8]
df.head(n=6)

# In[None]

leagueOne=df[df['LeagueIndex']==1]['Age']
leagueTwo=df[df['LeagueIndex']==2]['Age']
leagueThree=df[df['LeagueIndex']==3]['Age']
leagueFour=df[df['LeagueIndex']==4]['Age']
leagueFive=df[df['LeagueIndex']==5]['Age']
leagueSix=df[df['LeagueIndex']==6]['Age']
leagueSeven=df[df['LeagueIndex']==7]['Age']

# In[None]

print("Percentages of leagues in total data:\n")
df['LeagueIndex'].value_counts(normalize=True)*100

# In[None]

plt.style.use('ggplot')
fig, ax = plt.subplots(1, figsize = (14,8))
fig.suptitle('League-Player Percentage', fontweight='bold', fontsize = 22,ha='center')
bins = np.arange(0, 9, 1)
weights = np.ones_like(df['LeagueIndex']) / len(df['LeagueIndex'])
p2 = plt.subplot(1,2,2)
p2.hist(df['LeagueIndex'], bins=bins, weights = weights, align='left')
plt.xlabel('League Index', fontweight='bold')
plt.title('Percentage',loc='left')
yvals = plt.subplot(1,2,2).get_yticks()
plt.subplot(1,2,2).set_yticklabels(['{:3.1f}%'.format(y*100) for y in yvals])
plt.show()

# In[None]

leagues=[leagueOne,leagueTwo,leagueThree,leagueFour,
         leagueFive,leagueSix,leagueSeven]
newLabels=["Bronze", "Silver", "Gold", "Platinum",
           "Diamond", "Master", "Grandmaster"]

# In[None]

fig=plt.figure(figsize=(25,15))
plt.title("Player League Number - Age Distribution")
for i in range(len(leagues)):
    leagues[i].hist(alpha=0.9,bins=60,label=newLabels[i])
    plt.legend(loc="best")

# In[None]

leagueOne=df[df['LeagueIndex']==1]['APM']
leagueTwo=df[df['LeagueIndex']==2]['APM']
leagueThree=df[df['LeagueIndex']==3]['APM']
leagueFour=df[df['LeagueIndex']==4]['APM']
leagueFive=df[df['LeagueIndex']==5]['APM']
leagueSix=df[df['LeagueIndex']==6]['APM']
leagueSeven=df[df['LeagueIndex']==7]['APM']

# In[None]

leagues=[leagueOne,leagueTwo,leagueThree,leagueFour,
         leagueFive,leagueSix,leagueSeven]

# In[None]

fig=plt.figure(figsize=(25,15))
plt.title("Player League Number - Action Per Minute Distribution")
for i in range(len(leagues)):
    leagues[i].hist(alpha=0.8,bins=80,label=newLabels[i])
    plt.legend(loc="best")

# In[None]

plt.style.use(['seaborn-dark'])
fig, axes = plt.subplots(nrows=1, ncols = 1, figsize = (15,8))
fig.suptitle('Attribute Relationships', fontsize=25, fontweight='bold')
mask = np.zeros_like(df.corr(), dtype=np.bool)
mask[np.triu_indices_from(mask)] = True
r_matrix = df.corr().round(decimals=1)
sns.heatmap(r_matrix, mask=mask, annot=True, fmt='g',
            annot_kws={'size':10},linewidths=.3,cmap='coolwarm')
plt.show()


# In[None]

willBeFocusedColumns = ['APM','SelectByHotkeys', 'AssignToHotkeys',
                        'NumberOfPACs','GapBetweenPACs', 'ActionLatency']

# In[None]

ySelected = df['LeagueIndex']
xSelected = df[willBeFocusedColumns]

# In[None]

from sklearn.model_selection import train_test_split
xTrain, xTest, yTrain, yTest = train_test_split(xSelected, ySelected, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(xTrain, yTrain)
y_pred = model.predict(xTest)
score = accuracy_score(yTest, y_pred)
import numpy as np
np.save("prenotebook_res/3408906.npy", { "accuracy_score": score })

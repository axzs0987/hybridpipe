import pandas as pd
# In[None]

#importing libraries
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# In[None]

data = pd.read_csv("../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")

# In[None]

print("The feature attributes present in the data set are \n{} \nTotal of which are {} features ".format(data.columns, len(data.columns)))

# In[None]

data.info()

# In[None]

data.head(3)

# In[None]

X = data.iloc[:, :-1]
Y = data.iloc[:, -1:]
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/9581464.npy", { "accuracy_score": score })

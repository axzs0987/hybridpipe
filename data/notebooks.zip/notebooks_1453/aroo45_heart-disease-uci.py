import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
df = pd.read_csv("/kaggle/input/heart-disease-uci/heart.csv")
print(df.head())
df.describe()
df["age"].hist()
features = df.drop(["target","trestbps"],axis=1)
labels = df["target"]
print(labels.head())
from sklearn.preprocessing import StandardScaler
std_scl = StandardScaler()
features = std_scl.fit_transform(features)
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(features, labels, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100)
#clf.fit(X_train,y_train)
importances = []
names = list(df)
#for i, imp in enumerate(clf.feature_importances_):
#    importances.append( (imp, names[i]) )
importances = sorted(importances)
importances.reverse()
for v in importances:
    print("%s: %s" % (v[1],round(v[0],6)))
#preds = clf.predict(X_test)
from sklearn.metrics import confusion_matrix, accuracy_score
#cm = confusion_matrix(preds,y_test)
#acc = accuracy_score(preds,y_test)
#print("Confusion matrix is \n %s" % cm)
#print("Model accuracy is %s" % acc)



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/aroo45_heart-disease-uci.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/aroo45_heart-disease-uci/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/aroo45_heart-disease-uci/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/aroo45_heart-disease-uci/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/aroo45_heart-disease-uci/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/aroo45_heart-disease-uci/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/aroo45_heart-disease-uci/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/aroo45_heart-disease-uci/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/aroo45_heart-disease-uci/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/aroo45_heart-disease-uci/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/aroo45_heart-disease-uci/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/aroo45_heart-disease-uci/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/aroo45_heart-disease-uci/testY.csv",encoding="gbk")


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble.gradient_boosting import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
df = pd.read_csv('../input/heart.csv')
df = df.fillna(0)
df.columns
y = df['target'].values
df = df.fillna(0)
X = df.drop(columns=['target'], axis=1).values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=39)
model = GradientBoostingClassifier(random_state=39, n_estimators=50)
#model.fit(X_train, y_train)
#pred = model.predict(X_test)
#accuracy = np.mean(pred == y_test)
#print('accuracy: ', accuracy*100, '%')
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=39)
model = RandomForestClassifier(random_state=39, n_estimators=100)
#model.fit(X_train, y_train)
#pred = model.predict(X_test)
#accuracy = np.mean(pred == y_test)
#print('accuracy: ', accuracy*100, '%')
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
model = RandomForestClassifier(random_state=33, n_estimators=100)
#model.fit(X_train, y_train)
#pred = model.predict(X_test)
#accuracy = np.mean(pred == y_test)
#print('accuracy: ', accuracy*100, '%')



import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/altanarsol_basic-prediction.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/altanarsol_basic-prediction/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/altanarsol_basic-prediction/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/altanarsol_basic-prediction/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/altanarsol_basic-prediction/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/altanarsol_basic-prediction/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/altanarsol_basic-prediction/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/altanarsol_basic-prediction/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/altanarsol_basic-prediction/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/altanarsol_basic-prediction/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/altanarsol_basic-prediction/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/altanarsol_basic-prediction/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/altanarsol_basic-prediction/testY.csv",encoding="gbk")


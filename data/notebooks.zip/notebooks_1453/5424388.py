import pandas as pd
# ##  # E# m# p# l# o# y# e# e#  # A# t# t# r# i# t# i# o# n#  # s# t# u# d# y# 
# 
# E# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n#  # i# s#  # a#  # s# e# r# i# o# u# s#  # p# r# o# b# l# e# m#  # f# o# r#  # a#  # c# o# m# p# a# n# y# ,#  # m# a# i# n# t# i# n# i# n# g#  # i# t# s#  # t# o# p#  # t# a# l# e# n# t# s#  # c# a# n#  # l# e# a# d#  # t# o#  # a#  # g# r# e# a# t#  # r# e# d# u# c# t# i# o# n#  # i# n#  # c# o# s# t# s# .# 
# 
# G# i# v# e# n#  # t# h# a# t#  # t# h# e#  # e# m# p# l# o# y# e# e# '# s#  # p# r# o# d# u# c# t# i# v# i# t# y#  # t# e# n# d# s#  # t# o#  # d# i# m# i# n# i# s# h#  # w# h# e# n#  # t# h# e# y#  # d# e# c# i# d# e#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # a# n# d#  # g# i# v# e# n#  # t# h# a# t#  # t# h# e# r# e# '# s#  # a# n#  # o# v# e# r# h# e# a# d#  # c# o# s# t#  # i# n#  # r# e# p# l# a# c# i# n# g#  # a# n#  # e# m# p# l# o# y# e# e#  # a# n# d#  # g# i# v# i# n# g#  # h# i# m#  # t# h# e#  # p# r# o# p# p# e# r#  # f# o# r# m# a# t# i# o# n#  # a# n# d#  # t# i# m# e#  # t# o#  # a# d# j# u# s# t#  # t# o#  # t# h# e#  # n# e# w#  # p# o# s# i# t# i# o# n# ,#  # i# t# '# s#  # s# a# f# e#  # t# o#  # s# a# y#  # t# h# a# t#  # t# h# i# s#  # i# s#  # a#  # c# o# s# t# l# y#  # e# v# e# n# t# .#  # G# r# a# n# t# e# d#  # n# o# t#  # a# l# l#  # a# t# t# r# i# t# i# o# n# s#  # a# r# e#  # b# a# d# ,#  # s# o# m# e#  # e# m# p# l# o# y# e# e# s#  # a# r# e#  # j# u# s# t#  # d# i# s# r# u# p# t# i# n# g# ,#  # b# u# t#  # i# n#  # g# e# n# e# r# a# l#  # m# a# i# n# t# i# n# i# n# g#  # t# h# e#  # m# a# x# i# m# u# m#  # n# u# m# b# e# r#  # o# f#  # e# m# p# l# o# y# e# e# s#  # a# s#  # p# o# s# s# i# b# l# e#  # i# s#  # a#  # s# o# u# n# d#  # s# t# r# a# t# e# g# y# ,#  # a# s#  # d# e# s# c# r# i# b# e# d#  # [# h# e# r# e# ]# (# h# t# t# p# s# :# /# /# i# n# v# e# n# t# i# v# .# i# o# /# w# h# a# t# -# i# s# -# t# h# e# -# c# o# s# t# -# o# f# -# r# e# p# l# a# c# i# n# g# -# a# n# -# e# m# p# l# o# y# e# e# /# )# ,#  # [# h# e# r# e# ]# (# h# t# t# p# s# :# /# /# w# w# w# .# e# m# p# l# o# y# e# e# c# o# n# n# e# c# t# .# c# o# m# /# b# l# o# g# /# f# l# i# g# h# t# -# r# i# s# k# -# s# i# g# n# a# l# s# -# w# h# a# t# -# m# a# k# e# s# -# e# m# p# l# o# y# e# e# s# -# l# e# a# v# e# /# )#  # a# n# d#  # [# h# e# r# e# ]# (# h# t# t# p# :# /# /# a# n# a# l# y# t# i# c# s# -# m# a# g# a# z# i# n# e# .# o# r# g# /# p# r# e# d# i# c# t# i# v# e# -# a# n# a# l# y# t# i# c# s# -# t# h# e# -# p# r# i# v# a# c# y# -# p# i# c# k# l# e# -# h# e# w# l# e# t# t# -# p# a# c# k# a# r# d# s# -# p# r# e# d# i# c# t# i# o# n# -# o# f# -# e# m# p# l# o# y# e# e# -# b# e# h# a# v# i# o# r# /# )# 
# 
# W# i# t# h#  # t# h# i# s#  # c# o# n# t# e# x# t#  # i# n#  # m# i# n# d#  # w# e# '# l# l#  # t# r# y#  # t# o#  # c# r# e# a# t# e#  # a#  # m# o# d# e# l#  # t# o#  # p# r# e# d# i# c# t#  # w# h# o# '# s#  # a# b# o# u# t#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # s# o#  # w# e#  # c# o# u# l# d#  # r# e# p# o# r# t#  # i# t#  # t# o#  # H# R#  # a# n# d#  # t# h# e# y#  # c# a# n#  # d# e# c# i# d#  # t# o#  # d# o#  # s# o# m# e# t# h# i# n# g#  # a# b# o# u# t#  # i# t# 
# 
# ##  # T# a# b# l# e#  # O# f#  # C# o# n# t# e# n# t# s# 
#  # 1# .#  # E# x# p# l# o# r# a# t# o# r# y#  # D# a# t# a#  # A# n# a# l# y# s# i# s# 
#  #  #  #  #  # -#  # C# h# e# c# k# i# n# g#  # f# o# r#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# 
#  #  #  #  #  # -#  # C# r# e# a# t# i# n# g#  # s# o# m# e#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s#  # t# o#  # g# e# t#  # f# a# m# i# l# i# a# r#  # w# i# t# h#  # t# h# e#  # d# a# t# a# 
#  # 2# .#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n# 
#  # 3# .#  # M# o# d# e# l# i# n# g# 
#  # 4# .#  # I# n# t# e# r# p# r# e# t# i# n# g#  # r# e# s# u# l# t# s# 
#  #  #  #  #  # -#  # C# a# l# c# u# l# a# t# i# n# g#  # t# o# t# a# l#  # c# o# m# p# a# n# y#  # c# o# s# t# s#  # r# e# d# u# c# t# i# o# n# 
#  #  #  #  #  # -#  # P# e# r# m# u# t# e# d#  # f# e# a# t# u# r# e#  # i# m# p# o# r# t# a# n# c# e# 
#  #  #  #  #  # -#  # P# a# r# t# i# a# l#  # d# e# p# e# n# d# e# n# c# e#  # p# l# o# t# s

# In[None]

# Loading required libraries
import eli5
import lime
import numpy as np
import pandas as pd
import seaborn as sns
import lime.lime_tabular
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from eli5.sklearn import PermutationImportance
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.inspection import plot_partial_dependence
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, roc_auc_score



# Loading the dataset
df = pd.read_csv("../input/ibm-hr-analytics-attrition-dataset/WA_Fn-UseC_-HR-Employee-Attrition.csv")

print(df.shape)
df.head()

# G# r# e# a# t# !#  # w# e#  # g# o# t#  # o# u# r#  # d# a# t# a# s# e# t#  # l# o# a# d# e# d# ,#  # l# e# t# '# s#  # d# o#  # a#  # q# u# i# c# k#  # c# h# e# c# k#  # t# o#  # s# e# e#  # h# o# w#  # m# a# n# y#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # w# e# '# r# e#  # d# e# a# l# i# n# g#  # w# i# t# h

# In[None]

df.isna().sum()

# I# t#  # s# e# e# m# s#  # t# o#  # b# e#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s# ,#  # w# h# i# c# h#  # i# s#  # p# e# r# f# e# c# t# !#  # w# e# '# l# l#  # g# o#  # a# h# e# a# d#  # a# n# d#  # g# e# t#  # f# a# m# i# l# i# a# r# i# z# e# d#  # w# i# t# h#  # t# h# e#  # d# a# t# a# s# e# t# 
# 
# ##  # 1# .#  # E# x# p# l# o# r# a# t# o# r# y#  # d# a# t# a#  # a# n# a# l# y# s# i# s# 
# T# h# i# s#  # s# e# c# t# i# o# n#  # a# i# m# s#  # t# o#  # e# x# p# l# o# r# a# t# e#  # t# h# e#  # d# a# t# a#  # a#  # b# i# t# ,#  # t# r# y#  # t# o#  # g# e# t#  # a#  # f# e# e# l#  # o# f#  # t# h# e#  # p# r# o# b# l# e# m#  # a# n# d#  # m# a# y# b# e#  # f# i# n# d#  # s# o# m# e#  # k# e# y#  # i# n# s# i# g# h# t# s#  # t# h# a# t#  # m# i# g# h# t#  # b# e#  # u# s# e# f# u# l#  # l# a# t# e# r#  # o# n# 
# 
# F# i# r# s# t#  # o# f#  # a# l# l# ,#  # l# e# t# s#  # l# e# t# '# s#  # j# u# s# t#  # s# e# e#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # l# e# f# t#  # a# n# d#  # w# h# o#  # d# i# d# n# '# t

# In[None]

# Create just a simple lambda to calculate the proportion of each group 
prop_func = lambda x: round(len(x) / df.shape[0], 5) * 100

df.groupby("Attrition")["Attrition"].agg(["count", prop_func])

# S# o#  # w# e#  # h# a# v# e#  # 2# 3# 7#  # c# a# s# e# s#  # o# f#  # e# m# p# l# o# y# e# e# s#  # w# h# o#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y#  # w# h# i# c# h#  # i# s#  # a# r# o# u# n# d#  # 1# 6# ,# 1# 2# 2# %#  # o# f#  # t# h# e#  # e# n# t# i# r# e#  # d# a# t# a# s# e# t# ,#  # t# h# i# s#  # m# e# a# n# s#  # t# h# a# t#  # o# u# r#  # c# l# a# s# s# e# s#  # a# r# e#  # f# a# i# r# l# y#  # *# *# i# n# b# a# l# a# n# c# e# d# *# *# ,#  # s# o#  # w# e# '# l# l#  # s# e# e#  # s# o# m# e#  # w# a# y# s#  # t# o#  # w# o# r# k#  # a# r# o# u# n# d#  # t# h# i# s#  # i# s# s# u# e# 
# 
# L# e# t# '# s#  # c# o# n# t# i# n# u# e#  # w# i# t# h#  # o# u# r#  # a# n# a# l# y# s# i# s# 
# 
# ## ##  # W# h# a# t# s#  # t# h# e#  # a# g# e#  # d# i# s# t# r# i# b# u# t# i# o# n#  # o# n#  # e# a# c# h#  # g# r# o# u# p# ?

# In[None]

f,ax = plt.subplots(figsize=(15,8))
sns.kdeplot(df.loc[df.Attrition == "Yes", "Age"], shade = True, label = "Left")
sns.kdeplot(df.loc[df.Attrition == "No", "Age"], shade = True, label = "Stayed")
ax.set(xlabel = "Age", ylabel = "Density",title = "Age density colored by wether or not the employee left")
ax.set_xticks(range(10, 70, 2))
plt.show()

# S# o#  # i# t#  # a# p# p# e# a# r# s#  # y# o# u# n# g# e# r#  # p# e# o# p# l# e#  # t# e# n# d#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # m# o# r# e#  # o# f# t# e# n#  # w# h# i# c# h#  # i# s#  # t# o#  # b# e#  # e# x# p# e# c# t# e# d#  # s# i# n# c# e#  # t# h# e# y#  # p# r# o# b# a# b# l# y#  # h# a# v# e# n# '# t#  # s# e# t# t# l# e# d#  # o# n#  # a#  # h# o# u# s# e# /# f# a# m# i# l# y#  # o# r#  # t# h# e# y#  # m# i# g# h# t#  # g# e# t#  # m# o# r# e#  # j# o# b#  # o# f# f# e# r# i# n# g# s# .#  # T# h# i# s#  # f# e# a# t# u# r# e#  # i# s#  # p# r# o# b# a# b# l# y#  # a#  # g# o# o# d#  # f# e# a# t# u# r# e#  # t# o#  # u# s# e#  # i# n#  # o# u# r#  # m# o# d# e# l# 
# 
# N# o# t# e# :#  # d# o# n# '# t#  # w# o# r# r# y#  # t# h# e# r# e#  # a# r# e#  # n# o#  # 1# 0#  # y# e# a# r# -# o# l# d# s#  # w# o# r# k# i# n# g#  # i# n#  # t# h# i# s#  # c# o# m# p# a# n# y# ,#  # i# t# s#  # j# u# s# t#  # t# h# e#  # w# a# y#  # t# h# e#  # k# d# e#  # p# l# o# t# s#  # t# h# i# s#  # g# r# a# p# h#  # (# :# 
# 
# ## ##  # W# h# i# c# h#  # g# e# n# d# e# r#  # i# s#  # m# o# r# e#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e# ?

# In[None]

f,ax = plt.subplots(figsize=(15,8))

# Get the proportion of the genders grouped by the attrition status
grouped_data = df["Gender"].groupby(df["Attrition"]).value_counts(normalize = True).rename("Percentage of group").reset_index()

# Plot the result
sns.barplot(x = "Attrition", y = "Percentage of group", hue = "Gender", data = grouped_data)

# Convert y axis to percentage format
vals = ax.get_yticks()
ax.set_yticklabels(['{:,.0%}'.format(x) for x in vals])

ax.set(title = "Distribution of gender by each of the groups")
plt.show()

# T# h# i# s#  # c# o# m# p# a# n# y#  # h# a# s#  # m# o# r# e#  # m# e# n#  # t# h# e#  # w# o# m# e# n#  # a# n# d#  # s# o#  # t# h# i# s#  # p# l# o# t#  # s# h# o# w# s#  # u# s#  # t# h# a# t#  # m# e# n#  # t# e# n# d#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # m# o# r# e#  # b# u# t#  # o# n# l# y#  # b# e# c# a# u# s# e#  # t# h# e# y# '# r# e#  # i# n#  # a#  # l# a# r# g# e# r#  # n# u# m# b# e# r# .#  # T# h# i# s#  # a# l# s# o#  # i# n# d# i# c# a# t# e# s#  # t# h# a# t#  # g# e# n# d# e# r#  # m# i# g# h# t#  # n# o# t#  # b# e#  # a#  # k# e# y#  # f# a# c# t# o# r#  # f# o# r#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n# 
# 
# ## ##  # A# r# e#  # l# e# a# v# e# r# s#  # m# o# r# e#  # d# i# s# s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e# i# r#  # j# o# b# s# ?

# In[None]

f,ax = plt.subplots(figsize=(15,8))
grouped_data = df["JobSatisfaction"].groupby(df["Attrition"]).value_counts(normalize = True).rename("Percentage of group").reset_index()
sns.barplot(x = "JobSatisfaction", y = "Percentage of group", hue = "Attrition", data = grouped_data)

# Convert y axis to percentage format
vals = ax.get_yticks()
ax.set_yticklabels(['{:,.0%}'.format(x) for x in vals])

ax.set(title = "Distribution of job satisfaction by each of the groups")
plt.show()

# I# t#  # a# p# p# e# a# r# s#  # t# o#  # b# e#  # s# o# .#  # A# r# o# u# n# d#  # 2# 7# %#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # l# e# f# t#  # t# h# e#  # c# o# m# p# a# n# y#  # f# e# l# t#  # r# e# a# l# l# y#  # d# i# s# s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e# i# r#  # j# o# b# s# ,#  # w# h# i# l# e#  # o# n# l# y#  # n# e# a# r# l# y#  # 1# 7# %#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # s# t# a# y# e# d#  # s# a# i# d#  # t# h# e#  # s# a# m# e#  # t# h# i# n# g# .# 
# 
# I# n#  # c# o# n# t# r# a# s# t#  # p# e# o# p# l# e#  # w# h# o#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # s# e# e# m#  # t# o#  # b# e# ,#  # i# n#  # g# e# n# e# r# a# l# ,#  # s# a# t# i# s# f# i# e# d#  # w# i# t# h#  # t# h# e# i# r#  # j# o# b# s# .# 
# 
# I# t# '# s#  # a# l# s# o#  # i# n# t# e# r# e# s# t# i# n# g#  # t# o#  # s# e# e#  # t# h# e# r# e# '# s#  # a#  # l# a# r# g# e#  # p# o# r# t# i# o# n#  # o# f#  # l# e# a# v# e# r# s#  # t# h# a# t#  # h# a# v# e#  # a#  # l# e# v# e# l#  # 3#  # o# f#  # s# a# t# i# s# f# a# c# t# i# o# n# .#  # T# h# i# s#  # m# i# g# h# t#  # b# e#  # e# i# t# h# e# r#  # b# e# c# a# u# s# e#  # o# f#  # t# h# e#  # s# c# o# r# i# n# g#  # m# e# c# h# a# n# i# s# m#  # (# i# .# e# ,#  # 3#  # i# s#  # a#  # s# o# m# e# w# h# a# t#  # n# e# u# t# r# a# l#  # j# o# b#  # s# t# a# t# i# s# f# a# c# t# i# o# n#  # l# e# v# e# l# )#  # o# r#  # t# h# e# y# '# r# e#  # c# a# s# e# s#  # w# h# e# r# e#  # a#  # p# e# r# s# o# n#  # d# o# e# s#  # n# o# t#  # l# e# a# v# e#  # t# h# e#  # j# o# b#  # b# e# c# a# u# s# e#  # t# h# e# y#  # d# o# n# '# t#  # l# i# k# e#  # i# t#  # b# u# t#  # m# a# y# b# e#  # t# h# e# y#  # r# e# c# e# i# v# e# d#  # a#  # b# e# t# t# e# r#  # o# f# f# e# r# 
# 
# ## ##  # D# o#  # p# e# o# p# l# e#  # w# h# o#  # l# e# a# v# e#  # t# e# n# d#  # t# o#  # h# a# v# e#  # m# o# r# e#  # o# v# e# r# t# i# m# e# ?

# In[None]

f,ax = plt.subplots(figsize=(15,8))
grouped_data = df["OverTime"].groupby(df["Attrition"]).value_counts(normalize = True).rename("Percentage of group").reset_index()
sns.barplot(x = "OverTime", y = "Percentage of group", hue = "Attrition", data = grouped_data)

# Convert y axis to percentage format
vals = ax.get_yticks()
ax.set_yticklabels(['{:,.0%}'.format(x) for x in vals])

ax.set(title = "Distribution of overtime by each of the groups")
plt.show()

# S# o#  # t# h# e# r# e# '# s#  # a#  # n# e# a# r#  # 5# 0# -# 5# 0#  # s# p# l# i# t#  # i# n#  # p# e# o# p# l# e#  # w# h# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # r# e# a# g# a# r# d# i# n# g#  # o# v# e# r# t# i# m# e# ,#  # m# e# a# n# i# n# g#  # s# o# m# e#  # w# o# r# k#  # o# v# e# r# t# i# m# e#  # a# n# d#  # s# o# m# e#  # d# o# n# '# t# .# 
# 
# B# u# t#  # t# h# e#  # f# i# n# d# i# n# g#  # w# e#  # c# a# n#  # t# a# k# e#  # f# r# o# m#  # h# e# r# e#  # i# s#  # t# h# a# t#  # j# u# s# t#  # a#  # s# m# a# l# l#  # p# o# r# t# i# o# n#  # (# a# r# o# u# n# d#  # 2# 7# %# )#  # o# f#  # p# e# o# p# l# e#  # w# h# o#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # w# o# r# k#  # o# v# e# r# t# i# m# e# .#  # M# e# a# n# i# n# g#  # t# h# i# s#  # m# i# g# h# t#  # b# e#  # a# n# o# t# h# e# r#  # u# s# e# f# u# l# l#  # f# e# a# t# u# r# e#  # f# o# r#  # o# u# r#  # m# o# d# e# l# ,#  # i# f#  # a# n#  # o# b# s# e# r# v# a# t# i# o# n#  # s# t# a# t# e# s#  # t# h# a# t#  # a#  # p# e# r# s# o# n#  # w# o# r# k# s#  # o# v# e# r# t# i# m# e#  # w# e# '# l# l#  # b# e#  # m# o# r# e#  # i# n# c# l# i# n# e# d#  # t# o#  # s# a# y#  # t# h# a# t#  # t# h# i# s#  # p# e# r# s# o# n#  # i# s#  # l# i# k# e# l# y#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # (# s# o#  # g# o#  # a# h# e# a# d#  # a# n# d#  # t# e# l# l#  # y# o# u# r#  # b# o# s# s# e# s#  # y# o# u# '# r# e#  # n# o# t#  # w# o# r# k# i# n# g#  # o# v# e# r# t# i# m# e#  # b# e# c# a# u# s# e#  # y# o# u#  # d# o# n# '# t#  # w# a# n# t#  # t# o#  # l# e# a# v# e#  # t# h# e#  # c# o# m# p# a# n# y#  # (# :#  # )# 
# 
# T# h# e# r# e# '# s#  # m# a# n# y#  # m# o# r# e#  # p# l# o# t# s#  # w# e#  # c# o# u# l# d#  # m# a# k# e#  # t# o#  # a# n# s# w# e# r#  # s# o# m# e#  # b# a# s# i# c#  # q# u# e# s# t# i# o# n# s#  # l# i# k# e#  # t# h# e# s# e#  # o# n# e# s# ,#  # b# u# t#  # t# h# e# s# e#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s#  # a# r# e#  # o# n# l# y#  # o# n# e# -# d# i# m# e# n# s# i# o# n# a# l#  # (# f# o# r#  # e# a# c# h#  # a# t# t# r# i# t# i# o# n#  # g# r# o# u# p# )#  # s# o# ,#  # a# l# t# h# o# u# g# h#  # t# h# e# y# '# r# e#  # h# e# l# p# f# u# l# ,#  # w# e#  # m# i# g# h# t#  # g# e# t#  # s# o# m# e#  # e# x# t# r# a#  # i# n# f# o# r# m# a# t# i# o# n#  # w# h# e# n#  # w# e#  # s# e# e#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# w# o#  # o# r#  # m# o# r# e#  # v# a# r# i# a# b# l# e# s# 
# 
# ## ##  # A# g# e#  # v# s#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e#  # w# i# t# h#  # s# a# l# a# r# y#  # h# i# k# e#  # c# o# n# t# r# o# l# i# n# g#  # t# h# e#  # s# i# z# e# 
# 
# T# h# i# s#  # i# s#  # a#  # g# o# o# d#  # c# o# m# p# a# n# y#  # t# o#  # b# e#  # i# n#  # s# i# n# c# e#  # e# v# e# r# y# o# n# e#  # g# o# t#  # a#  # i# n# c# r# e# a# s# e#  # i# n#  # i# t# '# s#  # s# a# l# a# r# y# ,#  # b# u# t#  # s# o# m# e#  # r# e# c# e# i# v# e# d#  # m# o# r# e#  # t# h# a# n#  # o# t# h# e# r# s# ,#  # l# e# t# '# s#  # l# o# o# k#  # a# t#  # w# h# a# t# '# s#  # t# h# e#  # r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # a# g# e#  # a# n# d#  # t# h# e#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e#  # a# n# d#  # l# e# t# '# s#  # m# a# k# e#  # t# h# e#  # p# o# i# n# t# s#  # b# i# g# g# e# r#  # w# h# e# r# e#  # a#  # p# e# r# s# o# n#  # r# e# c# e# i# v# e# d#  # a#  # s# a# l# a# r# y#  # h# i# k# e#  # a# b# o# v# e#  # t# h# e#  # a# v# e# r# a# g# e#  # (# w# h# i# c# h#  # i# s#  # a# r# o# u# n# d#  # 1# 5# %# )

# In[None]

df["Salary hike above average"] = df.PercentSalaryHike > df.PercentSalaryHike.mean()

df_reordered = df.sort_values(by=['Attrition'])

f,ax = plt.subplots(figsize=(20,10))
ax = sns.scatterplot(x="Age", y="MonthlyIncome", hue="Attrition", size = "Salary hike above average", data=df_reordered, alpha = 0.8, sizes = (80,20))
ax.set(ylabel = "Monthly Income", title = "Distribution of overtime by each of the groups")
ax.set_xticks(range(10, 70, 2))
plt.show()

# O# k# a# y#  # s# o#  # t# h# e# r# e# '# s#  # a#  # l# o# t#  # o# f#  # s# t# u# f# f#  # h# e# r# e#  # (# m# a# y# b# e#  # t# o# o#  # m# u# c# h# ,#  # u# p# s# )#  # b# u# t#  # l# e# t# s#  # b# r# e# a# k#  # i# t#  # d# o# w# n# :# 
# 
# 1# .#  # W# e#  # c# a# n#  # s# e# e#  # t# h# a# t#  # l# e# a# v# e# r# s#  # a# r# e#  # i# n#  # t# h# e#  # y# o# u# n# g# e# r#  # a# g# e#  # g# r# o# u# p#  # (# a# s#  # w# e#  # s# a# w#  # b# e# f# o# r# e# )#  # b# u# t#  # w# e#  # a# c# t# u# a# l# l# y#  # s# e# e#  # t# h# a# t#  # t# h# e# y#  # t# e# n# d#  # t# o#  # h# a# v# e#  # l# o# w# e# r#  # s# a# l# l# a# r# i# e# s#  # t# h# e# n#  # p# e# r# s# o# n# s#  # w# h# o#  # s# t# a# y# e# d#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y# 
# 
# 2# .#  # A# s#  # a#  # p# e# r# s# o# n#  # g# e# t# s#  # o# l# d# e# r#  # t# h# e# y#  # t# e# n# d#  # t# o#  # g# e# t#  # a#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e#  # (# p# r# o# b# a# b# l# y#  # b# e# c# a# u# s# e#  # t# h# e# i# r#  # t# e# n# u# r# e#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # i# n# c# r# e# a# s# e# s#  # a# s#  # w# e# l# l# )# 
# 
# 3# .#  # I# t#  # a# p# p# e# a# r# s#  # t# h# a# t#  # r# e# c# e# i# v# i# n# g#  # a#  # s# a# l# a# r# y#  # h# i# k# e#  # a# b# o# v# e#  # t# h# e#  # a# v# e# r# a# g# e#  # h# a# s#  # n# o#  # e# f# f# e# c# t#  # o# n#  # m# a# k# i# n# g#  # a#  # p# e# r# s# o# n#  # s# t# a# y#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # s# i# n# c# e#  # t# h# e# '# r# e#  # s# o#  # m# a# n# y#  # l# e# a# v# e# r# s#  # w# i# t# h#  # a# b# o# v# e#  # a# v# e# r# a# g# e#  # s# a# l# a# r# y#  # h# i# k# e# s# 
# 
# 4# .#  # T# h# i# s#  # e# f# f# e# c# t#  # m# i# g# h# t#  # o# n# l# y#  # b# e#  # n# o# t# i# c# e# a# b# l# e#  # f# o# r#  # p# e# r# s# o# n# s#  # w# i# t# h#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e# s#  # (# a# b# o# v# e#  # 1# 0# 0# 0# 0# )#  # b# u# t#  # m# o# r# e#  # i# n# v# e# s# t# i# g# a# t# i# o# n#  # w# o# u# l# d#  # b# e#  # n# e# e# d# e# d#  # t# o#  # s# a# y#  # t# h# e#  # f# o# r#  # c# e# r# t# a# i# n# 
# 
# l# a# s# t# l# y#  # l# e# t# '# s#  # j# u# s# t#  # s# e# e#  # t# h# e#  # o# v# e# r# a# l# l#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # v# a# r# i# a# b# l# e# s

# In[None]

# I'm also removing these columns because they're either an ID or constant and have no variation
correlation = df.drop(["EmployeeCount", "EmployeeNumber", "StandardHours", "Salary hike above average"], axis = 1).corr()

# Generate a mask for the upper triangle
mask = np.zeros_like(correlation, dtype = np.bool)
mask[np.triu_indices_from(mask)] = True

f,ax = plt.subplots(figsize=(20,10))
sns.heatmap(correlation, annot = True, cmap = sns.color_palette("Reds", 11), mask = mask)
plt.show()

# T# h# i# s#  # h# e# a# t# m# a# p#  # s# a# y# s#  # a# l# o# t#  # a# b# o# u# t#  # t# h# e#  # c# o# m# p# a# n# y# :# 
# 
# 1# .#  # H# i# g# h# e# r#  # l# o# b#  # l# e# v# e# l# s#  # m# e# a# n# s#  # h# i# g# h# e# r#  # m# o# n# t# h# l# y#  # i# n# c# o# m# e# s#  # (# w# h# i# c# h#  # i# s#  # o# b# v# i# o# u# s# )# 
# 
# 2# .#  # T# h# e# r# e# s#  # a#  # s# t# r# o# n# g#  # c# o# r# r# e# l# a# t# i# o# n#  # b# e# t# w# e# e# n#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # y# e# a# r# s#  # a# t#  # t# h# e#  # c# o# m# p# a# n# y#  # a# n# d#  # t# h# e#  # n# u# m# b# e# r#  # o# f#  # y# e# a# r# s#  # w# i# t# h#  # a#  # g# i# v# e# n#  # m# a# n# a# g# e# r#  # a# n# d#  # r# o# l# e# ,#  # m# e# a# n# i# n# g#  # t# h# a# t#  # p# e# o# p# l# e#  # i# n#  # t# h# i# s#  # c# o# m# p# a# n# y#  # d# o# n# '# t#  # o# f# t# e# n#  # c# h# a# n# g# e#  # m# a# n# a# g# e# r# s# /# r# o# l# e# s# 
# 
# 3# .#  # P# e# o# p# l# e#  # w# i# t# h#  # h# i# g# h# e# r#  # p# e# r# f# o# r# m# a# n# c# e#  # r# a# t# i# n# g# s#  # r# e# c# e# i# v# e#  # h# i# g# h# e# r#  # s# a# l# a# r# y#  # h# i# k# e# s#  # (# w# h# i# c# h#  # i# s#  # a# l# s# o#  # o# b# v# i# o# u# s# )#  # b# u# t#  # w# h# e# n#  # w# e#  # c# o# n# t# r# a# s# t#  # t# h# i# s#  # w# i# t# h#  # t# h# e#  # p# r# e# v# i# o# u# s#  # p# l# o# t#  # w# h# e# r# e#  # w# e#  # s# a# y#  # t# h# e# r# e#  # w# h# e# r# e#  # a#  # l# o# t#  # o# f#  # l# e# a# v# e# r# s#  # w# i# t# h#  # a# b# o# v# e#  # a# v# e# r# a# g# e#  # s# a# l# a# r# y#  # h# i# k# e# s# ,#  # w# e#  # g# e# t#  # t# h# e#  # s# e# n# s# e#  # t# h# a# t#  # m# a# n# y#  # o# f#  # o# u# r#  # l# e# a# v# e# r# s#  # a# r# e#  # h# a# v# e#  # a#  # g# o# o# d#  # p# e# r# f# o# r# m# a# n# c# e# ,#  # w# h# i# c# h#  # a# g# g# r# a# v# a# t# e# s#  # t# h# e#  # c# o# s# t#  # o# f#  # e# m# p# l# o# y# e# e#  # a# t# t# r# i# t# i# o# n# 
# 
# L# e# t# s#  # m# o# v# e#  # o# n#  # t# o#  # a#  # d# i# f# f# e# r# e# n# t#  # a# n# a# l# y# s# i# s#  # o# t# h# e# r#  # t# h# a# n#  # v# i# s# u# a# l# i# z# a# t# i# o# n# s#  # a# n# d#  # l# e# t# '# s#  # w# h# i# c# h#  # v# a# r# i# a# b# l# e# s#  # h# a# v# e#  # a#  # g# r# e# a# t# e# r#  # i# m# p# a# c# t#  # i# n#  # o# u# r#  # o# u# t# c# o# m# e#  # v# a# r# i# a# b# l# e#  # t# h# r# o# u# g# h#  # m# e# a# n# s#  # o# f#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n# 
# 
# ##  # 2# .#  # F# e# a# t# u# r# e#  # S# e# l# e# c# t# i# o# n# 
# 
# W# e# '# l# l#  # b# e#  # u# s# i# n# g#  # a#  # u# n# i# v# a# r# i# a# t# e#  # f# i# l# t# e# r# .#  # W# h# a# t#  # t# h# i# s#  # m# e# a# n# s#  # i# s#  # t# h# a# t#  # f# o# r#  # e# v# e# r# y#  # v# a# r# i# a# b# l# e#  # w# e# '# l# l#  # d# o#  # a#  # u# n# i# v# a# r# i# a# t# e#  # s# t# a# t# i# s# t# i# c# a# l#  # t# e# s# t#  # a# n# d#  # d# e# t# e# r# m# i# n# e#  # w# e# t# h# e# r#  # t# h# e#  # v# a# r# i# a# b# l# e#  # i# s#  # r# e# l# e# v# a# n# t#  # t# o#  # p# r# e# d# i# c# t#  # l# e# a# v# i# n# g#  # e# m# p# l# o# y# e# e# s#  # o# r#  # n# o# t# .#  # F# i# r# s# t#  # w# e# '# l# l#  # o# n# e# -# h# o# t#  # e# n# c# o# d# e#  # t# h# e#  # n# e# c# e# s# s# a# r# y#  # f# e# a# t# u# r# e# s#  # a# n# d#  # s# c# a# l# e#  # e# v# e# r# y# t# h# i# n# g# 
# 
# S# o# m# e#  # f# e# a# t# u# r# e# s#  # d# o# n# '# t#  # n# e# e# d#  # t# o#  # b# e#  # o# n# e# -# h# o# t#  # e# n# c# o# d# e# d#  # a# s#  # t# h# e# y#  # h# a# v# e#  # a#  # s# e# n# s# e#  # o# f#  # o# r# d# e# r#  # t# o#  # t# h# e# m#  # (# l# i# k# e#  # E# d# u# c# a# t# i# o# n#  # o# r#  #  # P# e# r# f# o# r# m# a# n# c# e# R# a# t# i# n# g# )#  # s# o#  # w# e#  # w# o# u# n# t#  # o# n# e# -# h# o# t#  # e# n# c# o# d# e#  # t# h# e# s# e#  # f# e# a# t# u# r# e# s

# In[None]

#Lets deal with the categorical cloumns now
# simply change yes/no to 1/0 for Attrition, Gender, OverTime
df['Attrition'].replace({'No': 0, 'Yes': 1},inplace = True)
df['Gender'].replace({'Male': 0, 'Female': 1},inplace = True)
df['OverTime'].replace({'No': 0, 'Yes': 1},inplace = True)

# specifying names of categorical columns to be one-hot encoded
categorical_columns = ['BusinessTravel', 'Department', 'EducationField', "JobRole", "MaritalStatus"]

# transform the categorical columns
df = pd.get_dummies(df, columns=categorical_columns)

# Removing unecessary features
df.drop(["EmployeeNumber", "EmployeeCount", "Over18", "Salary hike above average", "StandardHours"], axis = 1, inplace = True)

df.head()

# In[None]

scaler = MinMaxScaler()
df = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
df.head()

# M# i# n# M# a# x# S# c# a# l# e# r#  # m# a# k# e# s#  # s# u# r# e#  # t# h# a# t#  # e# v# e# r# y#  # f# e# a# t# u# r# e#  # v# a# l# u# e# s#  # r# a# n# g# e# s#  # f# r# o# m#  # 0#  # t# o#  # 1#  # s# o#  # t# h# a# t#  # t# h# e# r# e# '# s#  # n# o#  # d# i# s# c# r# e# p# a# n# c# y#  # i# n#  # t# h# e#  # d# i# f# f# e# r# e# n# t#  # f# e# a# t# u# r# e#  # s# c# a# l# e# s# ,#  # t# h# i# s#  # s# c# a# l# e# r#  # d# o# e# s#  # n# o# t# ,#  # h# o# w# e# v# e# r# ,#  # h# a# n# d# l# e#  # o# u# t# l# i# e# r# s#  # s# o#  # t# h# a# t#  # m# i# g# h# t#  # b# e#  # s# o# m# e# t# h# i# n# g#  # w# e#  # s# h# o# u# l# d#  # w# a# t# c# h#  # o# u# t#  # f# o# r#  # a# n# d#  # m# a# y# b# e#  # c# o# r# r# e# c# t#  # w# i# t# h#  # a#  # d# i# f# f# e# r# e# n# t#  # s# c# a# l# e# r# ,#  # b# u# t#  # I#  # d# o# n# '# t#  # t# h# i# n# k#  # i# t# '# l# l#  # b# e#  # w# o# r# t# h#  # t# h# e#  # h# a# s# s# l# e# .# 
# 
# N# o# w#  # t# h# a# t#  # w# e#  # h# a# v# e#  # o# u# r#  # f# e# a# t# u# r# e# s#  # c# l# e# a# n# e# d#  # u# p#  # w# e#  # c# a# n#  # p# e# r# f# o# r# m#  # o# u# r#  # f# e# a# t# u# r# e#  # s# e# l# e# c# t# i# o# n#  # t# e# s# t

# In[None]

# specify our x and y variables
x, y = df.drop(["Attrition"], axis = 1), df.Attrition

# instantiate our selector to select the top 10 features
selector = SelectKBest(f_classif, k = 10)

# fit our selector to the data
x = pd.DataFrame(selector.fit_transform(x, y), index = x.index, columns = x.columns[selector.get_support(indices = True)])

# see what are the top selected features from our univariate filter
x.columns

# W# e#  # p# r# e# v# i# o# u# s# l# y#  # s# a# w#  # t# h# a# t#  # o# n# l# y#  # a#  # s# m# a# l# l#  # p# o# r# t# i# o# n#  # o# f#  # s# t# a# y# e# r# s#  # a# c# t# u# a# l# l# y#  # w# o# r# k# e# d#  # o# v# e# r# t# i# m# e#  # s# o#  # i# t# '# s#  # n# o#  # s# u# r# p# r# i# s# e#  # i# t#  # w# a# s#  # s# e# l# e# c# t# e# d# .# 
# T# h# e#  # r# e# m# a# n# i# n# g#  # f# e# a# t# u# r# e# s#  # a# r# e#  # p# r# e# t# t# y#  # o# b# v# i# o# u# s#  # t# o#  # a# n# d#  # o# n# e#  # c# a# n#  # h# y# p# o# t# h# e# s# i# z# e#  # t# h# a# t#  # a#  # l# e# a# v# e# r#  # i# s#  # a#  # p# e# r# s# o# n#  # w# h# o#  # w# o# r# k# s#  # *# *# O# v# e# r# T# i# m# e# *# *#  # i# s#  # *# *# S# i# n# g# l# e# *# *# ,#  # h# a# s#  # s# p# e# n# t#  # a# l# o# t#  # o# f#  # t# i# m# e#  # i# n#  # t# h# e#  # s# a# m# e#  # *# *# R# o# l# e# *# *#  # w# h# i# c# h#  # i# s#  # p# r# o# b# a# b# l# y#  # *# *# S# a# l# e# s#  # R# e# p# r# e# s# e# n# t# a# t# i# v# e# *# *# ,#  # p# r# o# b# a# b# l# y#  # h# a# s# n# '# t#  # w# o# r# k# e# d#  # i# n#  # t# h# e#  # c# o# m# p# a# n# y#  # f# o# r#  # v# e# r# y#  # l# o# n# g#  # a# n# d#  # h# a# s#  # a#  # l# o# w#  # *# *# J# o# b# L# e# v# e# l# *# *# ,#  # h# a# s#  # a#  # l# o# w# e# r#  # *# *# A# g# e# *# *# ,#  # h# a# s#  # n# o#  # *# *# S# t# o# c# k# O# p# t# i# o# n# L# e# v# e# l# *# *#  # a# n# d#  # h# a# s#  # a#  # l# o# w# e# r#  # *# *# M# o# n# t# h# l# y# I# n# c# o# m# e# *# *# .#  # O# f#  # c# o# u# r# s# e#  # t# h# i# s#  # o# n# l# y#  # o# f#  # t# h# e#  # t# o# p#  # o# f#  # m# y#  # h# e# a# d#  # b# u# t#  # a# t#  # l# e# a# s# t#  # w# e#  # h# a# v# e#  # a# n#  # A# N# O# V# A#  # t# e# s# t#  # t# o#  # b# a# c# k#  # o# u# r#  # f# i# n# d# i# n# g# s#  # :# )# 
# 
# S# i# n# c# e#  # w# e#  # d# o# n# '# t#  # h# a# v# e#  # m# a# n# y#  # o# b# s# e# r# v# a# t# i# o# n# s#  # i# n#  # o# u# r#  # d# a# t# a# s# e# t# ,#  # h# a# v# i# n# g#  # t# o# o#  # m# a# n# y#  # f# e# a# t# u# r# e# s#  # l# i# k# e#  # w# e#  # d# o#  # m# i# g# h# t#  # p# r# o# v# e#  # t# h# e#  # l# e# a# r# n# i# n# g#  # p# r# o# c# e# s# s#  # d# i# f# i# c# u# l# t# ,#  # a# n# d#  # s# o#  # s# e# l# e# c# t# i# n# g#  # f# e# a# t# u# r# e# s#  # t# h# i# s#  # w# a# y#  # m# a# y#  # b# e#  # b# e# n# e# f# i# c# i# a# l# !# 
# 
# ##  # 3# .#  # M# o# d# e# l# i# n# g# 
# 
# W# e# '# l# l#  # b# e#  # m# o# d# e# l# i# n# g#  # o# u# r#  # t# h# a# t#  # w# i# t# h#  # s# t# r# a# t# i# f# i# e# d#  # 5# -# F# o# l# d#  # c# r# o# s# s#  # v# a# l# i# d# a# t# i# o# n#  # t# o#  # t# r# y#  # a# n# d#  # m# i# n# i# m# i# z# e#  # o# v# e# r# f# i# t# t# i# n# g# .#  # W# e# '# l# l#  # a# l# s# o#  # l# e# a# v# e#  # 2# 0# %#  # o# f#  # o# u# r#  # d# a# t# a# s# e# t#  # f# o# r#  # t# e# s# t# i# n# g#  # o# u# r#  # f# i# n# a# l#  # m# o# d# e# l# .#  # W# e# '# r# e#  # u# s# i# n# g#  # s# t# r# a# t# i# f# i# e# d#  # K# -# F# o# l# d# t# o#  # m# a# i# n# t# a# i# n#  # t# h# e#  # s# a# m# e#  # p# r# o# p# o# r# t# i# o# n#  # o# f#  # o# b# s# e# r# v# a# t# i# o# n# s#  # i# n#  # e# a# c# h#  # c# l# a# s# s#  # f# o# r#  # e# v# e# r# y#  # f# o# l# d

# In[None]

# Splitting our total dataset so that we have 20% of it in the test set
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
model = SVC(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5424388.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# Any results you write to the current directory are saved as output.

# In[None]

data = pd.read_csv('../input/weather-dataset-rattle-package/weatherAUS.csv')

# In[None]

#import the libraries for data cleaning and data visualising
import numpy as np
import scipy as sp
import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import operator
warnings.filterwarnings('ignore')

# In[None]

#a quick look at the data
data.describe()

# In[None]

data.head()

# In[None]

print(data.columns)

# In[None]

print(data.shape)

# In[None]

#Finding the null count of each feature and removing the features with less data
data.isnull().sum()

# In[None]

data.shape

# In[None]

#Removing the feature which contain more null values
data = data.drop(columns = ['Sunshine','Evaporation','Cloud3pm','Cloud9am'], axis = 1)

# In[None]

data.shape

# In[None]

#let's see the correlation between all the columns
data_correlate = data.corr()
plt.figure(figsize = (15,15))
sns.heatmap(data_correlate, linewidth = 3, linecolor = 'black')
plt.show()

# In[None]

#Risk_MM can influnence the output. So droping that column too and date and location too.
data = data.drop(columns = ['Date', 'Location', 'RISK_MM'])

# In[None]

#Now looking at the columns
print(data.columns)

# In[None]

#Converting the RainToday and RainTomorrow data into binary
data['RainToday'].replace('No', 0, inplace = True)
data['RainToday'].replace('Yes', 1, inplace = True)
data['RainTomorrow'].replace('No', 0, inplace = True)
data['RainTomorrow'].replace('Yes', 1, inplace = True)


# In[None]

#Removing all the null values 
data = data.dropna(axis = 0)

# In[None]

data.shape

# In[None]

#Some columns needs to be changed into numeical values as they are categorical
non_numerical = ['WindGustDir', 'WindDir3pm', 'WindDir9am']
data = pd.get_dummies(data, columns= non_numerical)
rain_index = data.columns.get_loc('RainTomorrow')

# In[None]

data_1 = data

# In[None]

#standardizing the data.
from sklearn import preprocessing
standardizing = preprocessing.MinMaxScaler()
standardizing.fit(data_1)
data_standard = standardizing.transform(data_1)
data_standard = pd.DataFrame(data_standard, index=data_1.index, columns=data_1.columns)


# In[None]

data_standard.head()

# In[None]



# In[None]

#now on of the most important part. Feature selection
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
X = data_standard.loc[:,data_standard.columns!='RainTomorrow']
Y = data_standard[['RainTomorrow']]
selector = SelectKBest(chi2, k=3)
selector.fit(X, Y)
X_new = selector.transform(X)
print(X.columns[selector.get_support(indices=True)]) #top 3 columns

# In[None]

#the classification data:
data_classification = data_standard[['Rainfall', 'Humidity3pm', 'RainToday', 'RainTomorrow']]

# In[None]

#Spliting up the data:
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(data_standard[['Rainfall', 'Humidity3pm', 'RainToday']], data_standard['RainTomorrow'], train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/5753518.npy", { "accuracy_score": score })

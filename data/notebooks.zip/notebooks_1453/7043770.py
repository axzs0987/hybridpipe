import pandas as pd
# ##  # F# i# n# a# l#  # P# r# o# j# e# c# t#  # "# П# р# о# г# н# о# з# и# р# о# в# а# н# и# е#  # в# л# и# я# н# и# я#  # х# и# м# и# ч# е# с# к# и# х#  # п# о# к# а# з# а# т# е# л# е# й#  # с# о# с# т# а# в# а#  # в# и# н# а#  # н# а#  # е# г# о#  # к# а# ч# е# с# т# в# о# "

# В#  # с# в# о# е# м#  # и# с# с# л# е# д# о# в# а# н# и# и# ,#  # я#  # х# о# ч# у#  # п# р# о# д# е# м# о# н# с# т# р# и# р# о# в# а# т# ь#  # т# о# ,#  # к# а# к# и# е#  # п# о# к# а# з# а# т# е# л# и#  # в# л# и# я# ю# т#  # н# а#  # к# а# ч# е# с# т# в# о#  # к# р# а# с# н# о# г# о#  # в# и# н# а#  # V# i# n# h# o#  # V# e# r# d# e# .# 
# Х# о# ч# е# т# с# я#  # о# т# м# е# т# и# т# ь# ,#  # ч# т# о#  # в#  # д# а# н# н# о# й#  # м# о# д# е# л# и#  # н# е#  # х# в# а# т# а# е# т#  # н# е# к# о# т# о# р# ы# х#  # и# н# ы# х#  # п# о# к# а# з# а# т# е# л# е# й#  # д# л# я#  # м# а# к# с# и# м# а# л# ь# н# о#  # п# р# и# м# е# н# и# м# о# й#  # н# а#  # п# р# а# к# т# и# к# е#  # м# о# д# е# л# и# ,#  # н# о#  # в# с# е#  # п# о# к# а# з# а# т# е# л# и#  # к# а# с# а# т# е# л# ь# н# о#  # х# и# м# и# ч# е# с# к# о# г# о#  # с# о# с# т# а# в# а# ,#  # м# о# г# у# т#  # б# ы# т# ь#  # и# с# п# о# л# ь# з# о# в# а# н# ы#  # п# р# о# и# з# в# о# д# и# т# е# л# я# м# и#  # д# л# я#  # у# в# е# л# и# ч# е# н# и# я#  # в# е# р# о# я# т# н# о# с# т# и#  # п# о# п# а# д# а# н# и# я#  # и# х#  # в# и# н# а#  # в#  # с# а# м# ы# е#  # в# ы# с# о# к# и# е#  # р# е# й# т# и# н# г# и# ,#  # п# о# с# к# о# л# ь# к# у#  # о# ц# е# н# к# а#  # с# у# б# ъ# е# к# т# и# в# н# а# .# 
# С# н# а# ч# а# л# а# ,#  # я#  # п# о# с# м# о# т# р# ю#  # о# с# н# о# в# н# ы# е#  # д# а# н# н# ы# е#  # и#  # п# о# с# т# р# о# ю#  # б# а# з# о# в# у# ю#  # р# е# г# р# е# с# с# и# о# н# н# у# ю#  # м# о# д# е# л# ь# ,#  # а#  # д# а# л# ь# ш# е#  # е# щ# е#  # т# р# и#  # м# о# д# е# л# и#  # и#  # о# д# н# у#  # к# л# а# с# с# и# ф# и# к# а# ц# и# ю# .

# In[None]

#импортирую библиотеки
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn.dummy import DummyRegressor
df = pd.read_csv("../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv")

# In[None]

df.shape

# In[None]

df.head()

# In[None]

df.describe()

# In[None]

#имя столбцов
column = df.columns
names = column[:-1]

# In[None]

#загружаю данные с 11 признаками/качествами
features = np.array(df[column[:-1]])
#ну и отдельно оценку вина = целевую функцию
target = np.array(df[column[-1]])
#и делю на тренировочные и тестовые данные
from sklearn.model_selection import train_test_split
features_train, features_test, target_train, target_test = train_test_split(features, target, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(features_train, target_train)
y_pred = model.predict(features_test)
score = accuracy_score(target_test, y_pred)
import numpy as np
np.save("prenotebook_res/7043770.npy", { "accuracy_score": score })

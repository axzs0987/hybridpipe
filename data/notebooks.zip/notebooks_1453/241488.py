import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[None]

full = pd.read_csv('../input/WA_Fn-UseC_-HR-Employee-Attrition.csv')
full.head()

# In[None]

full.isnull().sum()
full=full.replace({"Attrition": {"Yes":1, "No":0}})

# In[None]

full=full.drop("Over18",axis=1)
full=full.replace({
    "OverTime": {"Yes":1, "No":0}
})
full=full.drop("StandardHours",axis=1)
full["Male"]=full["Gender"].map(lambda x: 1 if x=="Male" else 0)
full=full.drop("Gender",axis=1)

# In[None]

categorical_features = full.select_dtypes(include = ["object"]).columns
numerical_features = full.select_dtypes(exclude = ["object"]).columns
numerical_features = numerical_features.drop("Attrition")
print("Numerical features : " + str(len(numerical_features)))
print("Categorical features : " + str(len(categorical_features)))

# In[None]

full_num = full[numerical_features]
full_cat = full[categorical_features]

# In[None]

from scipy.stats import skew
skewness = full_num.apply(lambda x: skew(x))
skewness = skewness[abs(skewness) > 0.5]
print(str(skewness.shape[0]) + " skewed numerical features to log transform")

# In[None]

skewed_features = skewness.index
full_num[skewed_features] = np.log1p(full_num[skewed_features])

# In[None]

full_cat = pd.get_dummies(full_cat)
#
X=pd.concat([full_num,full_cat],axis=1)
print("New Features:"+str(X.shape[1]))
Y=full.Attrition

# In[None]

from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/241488.npy", { "accuracy_score": score })

import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

import os
#print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# In[None]

from sklearn.model_selection import KFold, train_test_split, StratifiedKFold
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import log_loss

# In[None]

df = pd.read_csv('../input/WA_Fn-UseC_-Telco-Customer-Churn.csv')
df = df.drop('customerID',axis=1)

# In[None]

df.head()

# In[None]

df.describe()

# In[None]

df.dtypes

# In[None]

df.TotalCharges = df.TotalCharges.apply(lambda x: x.strip())
df.TotalCharges[df.TotalCharges == '' ] = np.NAN
df.TotalCharges = df.TotalCharges.astype('float')


# In[None]

for col in df.columns:
    if df[col].dtypes == 'object':
        print(df.groupby(col)['Churn'].count())

# In[None]

df = df.dropna()
# Shufle
df = df.sample(frac=1)
df_x = df.drop('Churn',axis = 1) 
df['Churn'] = df['Churn'].astype('category')
df_y = df['Churn'].cat.codes

# In[None]

for col in df_x.columns:
    if df_x[col].dtypes == 'object':
        df_x = pd.concat([df_x,pd.get_dummies(df_x[col],prefix=col)],axis=1)
        df_x = df_x.drop(col,axis=1)

# In[None]

from sklearn.model_selection import train_test_split
train_x, test_x, train_y, test_y = train_test_split(df_x, df_y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = accuracy_score(test_y, y_pred)
import numpy as np
np.save("prenotebook_res/2445057.npy", { "accuracy_score": score })

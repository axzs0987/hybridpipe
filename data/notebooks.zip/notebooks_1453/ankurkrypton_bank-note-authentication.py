import numpy as np 
import pandas as pd 
import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import pandas as pd
import numpy as np
df = pd.read_csv("../input/bank-note-authentication-uci-data/BankNote_Authentication.csv")
df.head()
X = df.iloc[:,:-1]
y = df.iloc[:,-1]
X.head()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier()
#classifier.fit(X_train, y_train)
#y_pred = classifier.predict(X_test)
from sklearn.metrics import accuracy_score
#score = accuracy_score(y_test, y_pred)
#score
from sklearn.pipeline import Pipeline
#output = pd.DataFrame({'Id': X_test.variance,                      "SalePrice": y_pred})
#output.to_csv("submission", index = False)
print("successful")




import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
print("start running model training........")
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("new_data/prenotebook_res/ankurkrypton_bank-note-authentication.npy", { "accuracy_score": score })
import pandas as pd
if type(X_train).__name__ == "ndarray":
    np.save("hi_res_data/ankurkrypton_bank-note-authentication/trainX.npy", X_train)
if type(X_train).__name__ == "Series":
    X_train.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/trainX.csv",encoding="gbk")
if type(X_train).__name__ == "DataFrame":
    X_train.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/trainX.csv",encoding="gbk")

if type(X_test).__name__ == "ndarray":
    np.save("hi_res_data/ankurkrypton_bank-note-authentication/testX.npy", X_test)
if type(X_test).__name__ == "Series":
    X_test.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/testX.csv",encoding="gbk")
if type(X_test).__name__ == "DataFrame":
    X_test.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/testX.csv",encoding="gbk")

if type(y_train).__name__ == "ndarray":
    np.save("hi_res_data/ankurkrypton_bank-note-authentication/trainY.npy", y_train)
if type(y_train).__name__ == "Series":
    y_train.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/trainY.csv",encoding="gbk")
if type(y_train).__name__ == "DataFrame":
    y_train.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/trainY.csv",encoding="gbk")

if type(y_test).__name__ == "ndarray":
    np.save("hi_res_data/ankurkrypton_bank-note-authentication/testY.npy", y_test)
if type(y_test).__name__ == "Series":
    y_test.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/testY.csv",encoding="gbk")
if type(y_test).__name__ == "DataFrame":
    y_test.to_csv("hi_res_data/ankurkrypton_bank-note-authentication/testY.csv",encoding="gbk")


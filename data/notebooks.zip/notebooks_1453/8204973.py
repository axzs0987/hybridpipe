import pandas as pd
# ## ## ##  # L# o# a# d#  # L# i# b# r# a# r# i# e# s#  

# In[None]

# Basics
import pandas as pd
import numpy as np

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Preprocssing
import missingno as msno
from sklearn.preprocessing import StandardScaler, MinMaxScaler, binarize

# Model Selection 
from sklearn.model_selection import train_test_split, cross_val_score, KFold, GridSearchCV

# Models
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
# Ensemble
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier, ExtraTreesClassifier

# Metrics
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score, roc_curve, accuracy_score

# Feature Selection
from sklearn.feature_selection import SelectKBest, chi2

# Warnings
import warnings as ws
ws.filterwarnings('ignore')

# In[None]

# Load dataset
data = pd.read_csv('/kaggle/input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')
data.head()

# In[None]

# Summary
def summary(data):
    df = {
     'Count' : data.shape[0],
     'NA values' : data.isna().sum(),
     '% NA' : round((data.isna().sum()/data.shape[0]) * 100, 2),
     'Unique' : data.nunique(),
     'Dtype' : data.dtypes,
     'min' : round(data.min(),2),
     '25%' : round(data.quantile(.25),2),
     '50%' : round(data.quantile(.50),2),
     'mean' : round(data.mean(),2),
     '75%' : round(data.quantile(.75),2),   
     'max' : round(data.max(),2)
    } 
    return(pd.DataFrame(df))

print('Shape is :', data.shape)
summary(data)

# T# h# e# r# e#  # i# s#  # n# o#  # m# i# s# s# i# n# g#  # v# a# l# u# e# s#  # i# n#  # t# h# i# s#  # d# a# t# a# s# e# t# .#  # A# l# l#  # v# a# r# i# a# b# l# e# s#  # a# r# e#  # n# u# m# e# r# i# c#  # a# n# d#  # w# e#  # f# o# u# n# d#  # o# u# r#  # t# a# r# g# e# t#  # v# a# r# i# b# a# l# e#  # h# a# v# e#  # 6#  # u# n# i# q# u# e#  # v# a# l# u# e# s# .# 
# 
# ## ## ##  # V# i# s# u# a# l# i# z# a# t# i# o# n

# In[None]

data.hist(figsize = (10,10))
plt.show()

# In[None]

# Target Variables
data['quality'].value_counts()

# In[None]

# Convert Target variable into binary
bins = [2,6.5, 8]
labels = ['Bad','Good']
data['quality'] = pd.cut(data['quality'], bins = bins, labels = labels)

data['quality'].value_counts()

# T# h# i# s#  # d# a# t# a# s# e# t#  # s# e# e# m# s#  # l# i# k# e#  # i# m# b# a# l# a# n# c# e# d#  # d# a# t# a# s# e# t#  

# In[None]

col_names = data.drop('quality', axis = 1).columns.tolist()

plt.figure(figsize = (15,10))
i=0
for col in col_names:
    plt.subplot(3,4, i+1)
    plt.grid(True, alpha = 0.5)
    sns.kdeplot(data[col][data['quality'] == 'Bad'], label = 'Bad Quality')
    sns.kdeplot(data[col][data['quality'] == 'Good'], label = 'Good Quality')
    plt.title(col + ' vs Quality', size = 15)
    plt.xlabel(col, size = 12)
    plt.ylabel('Density')    
    plt.tight_layout()
    i+=1
plt.show()

# ## ## ##  # T# r# a# i# n#  # T# e# s# t#  # S# p# l# i# t

# In[None]

X = data.drop('quality', axis = 1)
Y = data['quality'].replace({'Bad':0, 'Good' : 1})

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, Y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/8204973.npy", { "accuracy_score": score })

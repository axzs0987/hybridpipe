import pandas as pd
# In[None]

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# I# m# p# o# r# t#  # p# a# c# k# a# g# e# s

# In[None]

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,confusion_matrix
import warnings
warnings.filterwarnings('ignore')

# I# m# p# o# r# t#  # D# a# t# a# s# e# t

# In[None]

data = pd.read_csv('../input/red-wine-quality-cortez-et-al-2009/winequality-red.csv')
data.head()

# I# n# s# p# e# c# t#  # t# h# e#  # d# a# t# a

# In[None]

data.describe()

# In[None]

data.info()

# In[None]

corr= data.corr()
fig = plt.figure()
ax = fig.add_subplot()
cax = ax.matshow(corr, cmap='coolwarm')
fig.colorbar(cax)
ticks = np.arange(0,len(corr.columns),1)
ax.set_xticks(ticks)
ax.set_yticks(ticks)
plt.xticks(rotation=90)
ax.set_xticklabels(corr.columns)
ax.set_yticklabels(corr.columns)
plt.show()

# n# o#  # n# u# l# l#  # v# a# l# u# e# s#  # f# o# u# n# d# 
# 
# q# u# a# l# i# t# y#  # i# s#  # t# a# r# g# e# t#  # v# a# r# i# a# b# l# e# 
# 
# a# l# l#  # c# o# l# u# m# n# s#  # a# r# e#  # n# u# m# e# r# i# c# 
# 
# q# u# a# l# i# t# y#  # l# i# e# s#  # b# e# t# w# e# e# n#  # 3#  # a# n# d#  # 8

# In[None]

#binning the quality column into into parts i.e good quality and bad quality 
#bins = np.linspace(3, 8, 3)
bin_name = ['bad','good']
bins = (2,6.5,8)
data['quality'] = pd.cut(data['quality'],bins=bins,labels=bin_name)

# In[None]

le = LabelEncoder()
le.fit(data['quality'])
data['quality'] = le.fit_transform(data['quality'])

# In[None]

x = data.drop('quality',axis=1).values
y = data['quality'].values.reshape(-1,1)
y.shape

# In[None]

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=1-0.8, random_state=0)
from sklearn.metrics import accuracy_score
from sklearn.linear_model.logistic import LogisticRegression
model = LogisticRegression(random_state=0)
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
score = accuracy_score(y_test, y_pred)
import numpy as np
np.save("prenotebook_res/11369636.npy", { "accuracy_score": score })
